<?php
	class AgenteComercial{
		function __construct( $controller ){
			parent::__construct( $controller );		
		}
	}