<?php
/**
 * Julio
 * Classe para log de eventos no sistema
 */
class Api extends Main
{
	protected
	$info_curl,
	$api_externa,
	$codigo,
	$url,
	$port,
	$hash,
	$token,
	$secret,
	$key,
	$dev_id,
	$user_name,
	$password,
	$obj_log,
	$usar_cert,
	$cert_path,
	$return,
	$cert_key,
	$security_key,
	$path_root,
	$controller;

	public
	$response_http_code;

	function __construct($controller = null, $param = null)
	{
		if ($param) {
			$this->codigo = (isset($param['codigo'])) ? $param['codigo'] : null;
			$this->url = (isset($param['url'])) ? $param['url'] : null;
			$this->port = (isset($param['port'])) ? $param['port'] : null;
			$this->token = (isset($param['token'])) ? $param['token'] : null;
			$this->secret = (isset($param['secret'])) ? $param['secret'] : null;
			$this->key = (isset($param['key'])) ? $param['key'] : null;
			$this->dev_id = (isset($param['dev_id'])) ? $param['dev_id'] : null;
			$this->user_name = (isset($param['user'])) ? $param['user'] : null;
			$this->password = (isset($param['password'])) ? $param['password'] : null;
			$this->usar_cert = (isset($param['usar_cert'])) ? $param['usar_cert'] : null;
			$this->channel = (isset($param['channel'])) ? $param['channel'] : null;
			$this->manager = (isset($param['manager'])) ? $param['manager'] : null;
			$this->cert_path = (isset($param['cert_path'])) ? $param['cert_path'] : null;
			$this->cert_key = (isset($param['cert_key'])) ? $param['cert_key'] : null;
			$this->path_root = (isset($param['path_root'])) ? $param['path_root'] : null;
			$this->security_key = (isset($param['security_key'])) ? $param['security_key'] : null;
		}
		parent::__construct($controller);
	}

	function setToken($token)
	{
		$this->token = $token;
	}

	function connect($nome, $token = null, $key = null)
	{
		try {
			switch ($nome) {
				case 'pipedrive':
					$this->url = URL_PIPEDRIVE;
					if ($token) {
						$this->token = $token;
					}

					if ($key) {
						$this->key = $key;
					}
					break;
				case 'slack':
					if ($token) {
						$this->token = $token;
					}
					require_once ABSPATH . '/libs/slack-api/Slack.php';
					$this->api_externa = new Slack($this->token);
					break;
				default:
					$retorno_erro['mensagem'] = 'Nome api desconhecido';
					$retorno_erro['dados'] = $nome;
					break;
			}
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	function action($nome, $objeto, $acao, $parametros = null, $timer = null)
	{
		try {
			switch (strtolower($nome)) {
				case 'pipedrive':
					switch ($objeto) {
						case 'users':
							if ($acao == 'allusers') {
								$url = $this->url . $objeto . '/?api_token=' . $this->token;
								$dados = json_decode($this->CurlExec($url));
							} elseif ($acao == 'find') {
								$url = $this->url . $objeto . '/' . $acao . '/?term=' . $parametros['email'] . '&search_by_email=1&api_token=' . $this->token;
							} elseif ($acao == 'id') {
								$url = $this->url . $objeto . '/' . $parametros['id'] . '/' . '?api_token=' . $this->token;
							}

							$dados = json_decode($this->CurlExec($url));
							if (isset($dados->success) && !empty($dados->data)) {
								$retorno['codigo'] = 0;
								$retorno['tipo'] = 'success';
								$retorno['mensagem'] = 'Dados retornado com sucesso';
								$retorno['dados'] = $dados->data;
							} else {
								$retorno['codigo'] = 2;
								$retorno['tipo'] = 'danger';
								$retorno['mensagem'] = 'Nenhum usuario encontrado - API';
								$retorno['dados'] = $dados;
							}
							break;
						case 'deals':
							if ($acao == 'find') {
								if (isset($parametros['id_user'])) {
									$url = $this->url . $objeto . '?user_id=' . $parametros['id_user'] . 'status=all_not_deleted&start=0&api_token=' . $this->token;
								} else {
									$url = $this->url . $objeto . '?status=all_not_deleted&start=0&api_token=' . $this->token;
								}
							} elseif ($acao == 'timeline') {
								$url = $this->url . $objeto . '/' . $acao . '?start_date=' . $parametros['start'] . '&interval=' . $parametros['interval'] . '&amount=' . $parametros['amount'] . '&field_key=' . $parametros['field_key'] . '&user_id=' . $parametros['id_user'] . '&api_token=' . $this->token;
							} elseif ($acao == 'estagnados') {
								$url = $this->url . $objeto . '?filter_id=5&status=all_not_deleted&start=0&api_token=' . $this->token;
							} elseif ($acao == 'lost') {
								$url = $this->url . 'deals?status=lost&start=0&api_token=442de6ee762d73dea5ae3defc7b71fbbafa01e60';
							}
							if (isset($url)) {
								$dados = json_decode($this->CurlExec($url));
							} else {
								$dados = null;
							}

							if (isset($dados->success) && !empty($dados->data)) {
								$retorno['codigo'] = 0;
								$retorno['tipo'] = 'success';
								$retorno['mensagem'] = 'Dados retornado com sucesso';
								$retorno['dados'] = $dados->data;
							} else {
								$retorno['codigo'] = 2;
								$retorno['tipo'] = 'danger';
								$retorno['mensagem'] = 'Nenhum usuario encontrado - API';
								$retorno['dados'] = $dados;
							}
							return json_encode($retorno);
							break;
						case 'pipelines':
							$extra_param = 'everyone=0&start=0';
							if ($acao == 'pipeline') {
								$url = $this->url . $objeto . '/1/deals?' . $extra_param;
							} elseif ($acao == 'upselling') {
								$url = $this->url . $objeto . '/2/deals?' . $extra_param;
							} elseif ($acao == 'mmr') {
								$url = $this->url . 'deals/timeline?start_date=' . $parametros['data_ini'] . '&interval=' . $parametros['interval'] . '&amount=' . $parametros['amount'] . '&field_key=' . $parametros['field_key'] . '&pipeline_id=' . $parametros['pipeline_id'];
							} elseif ($acao == 'closers') {
								$url = $this->url . 'deals/timeline?start_date=' . $parametros['data_ini'] . '&interval=' . $parametros['interval'] . '&amount=' . $parametros['amount'] . '&field_key=' . $parametros['field_key'] . '&pipeline_id=' . $parametros['pipeline_id'];
							} elseif ($acao == 'produto') {
								$url = $this->url . 'deals/' . $parametros['deal_id'] . '/products?start=' . $parametros['products'];
							}

							if (isset($parametros['id_user'])) {
								$url .= 'user_id=' . $parametros['id_user'] . '&';
							}

							$url .= '&api_token=' . $this->token;
							$dados = json_decode($this->CurlExec($url));
							if (isset($dados->success) && !empty($dados->data)) {
								$retorno['codigo'] = 0;
								$retorno['tipo'] = 'success';
								$retorno['mensagem'] = 'Dados retornado com sucesso';
								$retorno['dados'] = $dados->data;
							} else {
								$retorno['codigo'] = 2;
								$retorno['tipo'] = 'danger';
								$retorno['mensagem'] = 'Nenhum Pipeline encontrado - API';
								$retorno['dados'] = $dados;
							}
							return json_encode($retorno);
							break;
						case 'organizations':
							if ($acao == 'find') {
								if (isset($parametros['id_user'])) {
									$url = $this->url . $objeto . '?user_id=' . $parametros['id_user'] . '&start=0&api_token=' . $this->token;
								} else {
									$url = $this->url . $objeto . '?status=all_not_deleted&start=0&api_token=' . $this->token;
								}
								$dados = json_decode($this->CurlExec($url));
								if (isset($dados->success) && !empty($dados->data)) {
									$retorno['codigo'] = 0;
									$retorno['tipo'] = 'success';
									$retorno['mensagem'] = 'Dados retornado com sucesso';
									$retorno['dados'] = $dados->data;
								} else {
									$retorno['codigo'] = 2;
									$retorno['tipo'] = 'danger';
									$retorno['mensagem'] = 'Nenhum usuario encontrado - API';
									$retorno['dados'] = $dados;
								}
								return json_encode($retorno);
							}
							break;
						case 'activities':
							$url = $this->url . $objeto . '?';
							if ($acao == 'list') {
								if (isset($parametros['id_user'])) {
									$url .= 'user_id=' . $parametros['id_user'] . '&';
								}

								if (isset($parametros['type'])) {
									$url .= 'type=' . $parametros['type'] . '&';
								}

								if (isset($parametros['start'])) {
									$url .= 'start=0&start_date=' . $parametros['start'] . '&';
								}

								if (isset($parametros['end'])) {
									$url .= 'end_date=' . $parametros['end'] . '&';
								}

								$url .= 'api_token=' . $this->token;
								$dados = json_decode($this->CurlExec($url));
								if (isset($dados->success) && !empty($dados->data)) {
									$retorno['codigo'] = 0;
									$retorno['tipo'] = 'success';
									$retorno['mensagem'] = 'Dados retornado com sucesso';
									$retorno['dados'] = $dados->data;
								} else {
									$retorno['codigo'] = 2;
									$retorno['tipo'] = 'danger';
									$retorno['mensagem'] = 'Nenhum Atividade encontrado - API';
									$retorno['dados'] = $dados;
								}
								return json_encode($retorno);
							}
							break;
						default:
							$retorno['codigo'] = 1;
							$retorno['tipo'] = "warning";
							$retorno['mensagem'] = 'Nome api desconhecido - API';
							$retorno['dados'] = $nome;
							break;
					}// fim switch $objeto
					break;
				case 'slack':
					$this->connect('slack', TOKEN_SLACK, null);
					$tokens = null;
					switch ($objeto) {
						case 'users':
							if ($acao == 'findByEmail') {
								$this->api_externa = new Slack(TOKEN_SLACK);
								$dados = $this->api_externa->call('users.lookupByEmail', $parametros);
								if ($dados['ok']) {
									$retorno['codigo'] = 0;
									$retorno['tipo'] = 'success';
									$retorno['mensagem'] = 'Dados retornado com sucesso';
									$retorno['dados'] = $dados['user'];
								} else {
									$retorno['codigo'] = 2;
									$retorno['tipo'] = 'danger';
									$retorno['mensagem'] = 'Nenhum usuario encontrado - API';
									$retorno['dados'] = $dados;
								}
								return json_encode($retorno);
							} elseif ($acao == 'sendmessagetochannel') {
								if (is_array($parametros['channel'])) {
									$tokens = $parametros['channel'];
								} else {
									$tokens[] = $parametros['channel'];
								}
								if ($tokens) {
									foreach ($tokens as $key => $value) {
										$post_data = 'channel=' . $value . '&text=' . $parametros['mensagem'];
										$param['channel'] = $value;
										$param['text'] = $parametros['mensagem'];
										$slack = new Slack(TOKEN_SLACK);
										$result = $slack->call('chat.meMessage', $param);
										if ($result['ok']) {
											$retorno['codigo'] = 0;
											$retorno['tipo'] = 'success';
											$retorno['mensagem'] = 'Mensagem enviada com sucesso';
											$retorno['dados'] = $parametros;
											$retorno['retorno'] = $result;
										} else {
											$retorno['codigo'] = 2;
											$retorno['tipo'] = 'danger';
											$retorno['mensagem'] = 'Erro ao enviar mensagem';
											$retorno['dados'] = $parametros;
											$retorno['retorno'] = $result;
											return json_encode($retorno);
										}
									}
								}
								return json_encode($retorno);
							} elseif ($acao == 'sendmessagetouser') {
								if (is_array($parametros['channel'])) {
									$tokens = $parametros['channel'];
								} else {
									$tokens[] = $parametros['channel'];
								}

								if ($tokens) {
									foreach ($tokens as $key => $value) {
										$post_data = 'channel=' . $value . '&text=' . $parametros['mensagem'];
										$param['channel'] = $value;
										$param['text'] = $parametros['mensagem'];
										$slack = new Slack(TOKEN_SLACK);
										$result = $slack->call('chat.postMessage', $param);
										if ($result['ok']) {
											$retorno['codigo'] = 0;
											$retorno['tipo'] = 'success';
											$retorno['mensagem'] = 'Mensagem enviada com sucesso';
											$retorno['dados'] = $parametros;
											$retorno['retorno'] = $result;
										} else {
											$retorno['codigo'] = 2;
											$retorno['tipo'] = 'danger';
											$retorno['mensagem'] = 'Erro ao enviar mensagem';
											$retorno['dados'] = $parametros;
											$retorno['retorno'] = $result;
											return json_encode($retorno);
										}
									}
								}
								return json_encode($retorno);
							}
							break;
						case 'webhook':
							if ($acao == 'sendmessage') {
								if (is_array($parametros['webhook'])) {
									$tokens = $parametros['webhook'];
								} else {
									$tokens[] = $parametros['webhook'];
								}

								$post_data = '{
										"text": "' . $parametros['mensagem'] . '"
									}';

								if ($tokens) {
									foreach ($tokens as $key => $value) {
										$url = URL_WEBHOOK_SLACK . trim($value);
										$result = file_get_contents($url, false, stream_context_create(array(
											"ssl" => array(
												"verify_peer" => false,
												"verify_peer_name" => false,
											),
											'http' => array(
												'protocol_version' => 1.1,
												'method' => 'POST',
												'header' => "Content-type: application/x-www-form-urlencoded\r\n" . "Content-length: " . strlen($post_data) . "\r\n" . "Connection: close\r\n",
												'content' => $post_data
											),
										)));

										if ($result == 'ok') {
											$retorno[$key]['codigo'] = 0;
											$retorno[$key]['tipo'] = 'success';
											$retorno[$key]['mensagem'] = 'Mensagem enviada com sucesso';
											$retorno[$key]['dados'] = $parametros;
											$retorno[$key]['retorno'] = $result;
										} else {
											$retorno[$key]['codigo'] = 2;
											$retorno[$key]['tipo'] = 'danger';
											$retorno[$key]['mensagem'] = 'Erro ao enviar mensagem';
											$retorno[$key]['dados'] = $parametros;
											$retorno[$key]['retorno'] = $result;
										}
									}
								}
								$msg = json_encode($retorno);
								// $this->obj_log->writeLog($msg, 'jobs', 'jobs', null, false);
								return $msg;
							}
							break;
						default:
							$retorno['codigo'] = 1;
							$retorno['tipo'] = "warning";
							$retorno['mensagem'] = 'Nome api desconhecido';
							$retorno['dados'] = $nome;
							break;
					}// fim switch $objeto
					break;
				case 'rpa':
					$retorno = null;
					$result = null;
					$parametros['usuario'] = WS_RPA_USUARIO_NFE;
					$parametros['senha'] = WS_RPA_SENHA_NFE;
					$parametros['codigo_empresa'] = WS_RPA_FLUXO_EMPRESA;

					if (TIPO_AMBIENTE == 'producao') {
						$parametros['ambiente'] = 'P';
					} else {
						$parametros['ambiente'] = 'H';
					}

					if ($objeto == 'arquivo') {
						if ($acao == 'enviar' || $acao == 'retorno') {
							$endpoint = 'https://wsrpa.cmsw.com/newtask/9997';
							if ($acao == 'enviar') {
								$parametros['provedor'] = WS_RPA_FLUXO_SEND;
							} elseif ($acao == 'retorno') {
								$parametros['provedor'] = WS_RPA_FLUXO_STATUS;
							}

							$ch = curl_init();
							$cOption = array(
								CURLOPT_URL => $endpoint,
								CURLOPT_HEADER => 0,
								//CURLOPT_USERPWD      => "$email:$password",
								CURLOPT_HTTPHEADER => array('Content-Type: application/json'),
								CURLOPT_SSL_VERIFYPEER => false,
								CURLOPT_RETURNTRANSFER => 1,
								CURLOPT_POST => true,
								CURLOPT_POSTFIELDS => json_encode($parametros),
							);

							curl_setopt_array($ch, $cOption);

							$request = curl_exec($ch);

							if ($timer) {
								sleep($timer);
							}

							$request = json_decode($request);

							if ('999' == $request->codigo) {
								$retorno['codigo'] = 2;
								$retorno['tipo'] = "danger";
								$retorno['provedor'] = $parametros['provedor'];
								$retorno['mensagem'] = $request->status . ' hash: ' . $request->hash . ' ticket: ' . $request->ticket;
								$retorno['dados'] = $parametros;
								$retonro['request'] = $ch;
								throw new Exception(json_encode($retorno), 1);
							}

							if (!curl_errno($ch)) {
								$retorno['codigo'] = 0;
								$retorno['tipo'] = "success";
								$retorno['provedor'] = $parametros['provedor'];
								$retorno['mensagem'] = 'Requisição bem sucedida';
								$retorno['dados'] = $request;
								$retonro['request'] = $ch;
							} else {
								$retorno['codigo'] = 2;
								$retorno['tipo'] = "danger";
								$retorno['provedor'] = $parametros['provedor'];
								$retorno['mensagem'] = 'Erro na chamada - ' . curl_error($ch) . ' - ' . curl_errno($ch);
								$retorno['dados'] = $parametros;
								$retonro['request'] = $ch;
							}
							curl_close($ch);
						} elseif ($acao == 'status') {
							$endpoint = 'https://wsrpa.cmsw.com/status_task/' . $parametros['id_work'];
							$ch = curl_init();
							$cOption = array(
								CURLOPT_URL => $endpoint,
								CURLOPT_SSL_VERIFYPEER => false,
								CURLOPT_RETURNTRANSFER => 1,
							);
							curl_setopt_array($ch, $cOption);
							$request = curl_exec($ch);
							if (!curl_errno($ch) && $request) {
								$retorno['codigo'] = 0;
								$retorno['tipo'] = "success";
								$retorno['provedor'] = 'status';
								$retorno['mensagem'] = 'Requisição bem sucedida';
								$retorno['dados'] = json_decode($request);
								$retonro['request'] = $ch;
							} else {
								$retorno['codigo'] = 2;
								$retorno['tipo'] = "danger";
								$retorno['provedor'] = 'status';
								$retorno['mensagem'] = 'Erro na chamada - ' . curl_error($ch) . ' - ' . curl_errno($ch);
								$retorno['dados'] = $parametros;
								$retonro['request'] = $ch;
							}
							curl_close($ch);
						}
					} else {
						$retorno['codigo'] = 2;
						$retorno['tipo'] = "danger";
						$retorno['provedor'] = null;
						$retorno['mensagem'] = 'Objeto desconhecido';
						$retorno['dados'] = $objeto;
						$retonro['request'] = null;
					}
					break;
				case 'cnpj':
					if (!$this->url) {
						$this->url = URL_CONSULTA_CNPJ;
					}
					switch ($objeto) {
						case 'cnpj':
							switch ($acao) {
								case 'consultar':
									$dados_cnpj = json_decode(CurlExec($this->url .= removeCaracteres($parametros['cnpj'], 'char')));
									if ($dados_cnpj) {
										if (!isset($dados_cnpj->status) || $dados_cnpj->status != 'ERROR') {
											$retorno['codigo'] = 0;
											$retorno['tipo'] = 'sucesso';
											$retorno['input'] = $parametros;
											$retorno['output'] = $dados_cnpj;
											$retorno['mensagem'] = 'Sucesso';
										} else {
											$retorno['codigo'] = 1;
											$retorno['tipo'] = 'error';
											$retorno['input'] = $parametros;
											$retorno['output'] = $dados_cnpj;
											$retorno['mensagem'] = $dados_cnpj->message;
										}
									} else {
										$retorno['codigo'] = 1;
										$retorno['tipo'] = 'error';
										$retorno['input'] = $parametros;
										$retorno['output'] = $dados_cnpj;
										$retorno['mensagem'] = 'Erro na consulta CNPJ';
									}
									return json_encode($retorno);
									break;
								default:
									# code...
									break;
							}
							break;
						default:
							# code...
							break;
					}
					break;
				case 'location':
					$param_curl[CURLOPT_RETURNTRANSFER] = true;
					$param_curl[CURLOPT_SSL_VERIFYPEER] = false;
					$param_curl[CURLOPT_SSL_VERIFYHOST] = false;
					$param_curl[CURLOPT_HTTP_VERSION] = 'CURL_HTTP_VERSION_1_1';
					$param_curl[CURLOPT_CUSTOMREQUEST] = 'GET';
					switch ($objeto) {
						case 'ip':
							switch ($acao) {
								case 'getipv4':
									$url = "https://api.ip2location.com/v2/?ip=" . $parametros['ip'] . "&key=73249106EE&package=WS8";
									$param_curl[CURLOPT_URL] = $url;
									$response = $this->CurlExec($url, $param_curl);
									$array_response = json_decode($response);
									if ($array_response->response != "OK") {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $array_response;
										$retorno['mensagem'] = 'Erro';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $array_response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
							}
							break;
					}
					break;
			}

			if (isset($retorno)) {
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			$result = json_decode($e->getMessage());
			if (isset($result->message)) {
				$retorno['codigo'] = 2;
				$retorno['tipo'] = "erro";
				$retorno['mensagem'] = 'Erro na API';
				$retorno['dados'] = $result;
				return json_encode($retorno);
			} else {
				return $e->getMessage();
			}
		}
	}

	function Conectar()
	{
		try {
			switch ($this->codigo) {
				case 'COR001':
				case 'COR002':
					$retorno_erro['codigo'] = 1;
					$retorno_erro['input'] = null;
					$retorno_erro['output'] = null;
					$retorno_erro['mensagem'] = '';
					$retorno_ok['codigo'] = 0;
					$retorno_ok['input'] = null;
					$retorno_ok['output'] = null;
					$retorno_ok['mensagem'] = '';
					$postvars['ConectarRequest'] = array(
						"ISPB" => $this->dev_id,
						"Usuario" => $this->user_name,
						"Senha" => $this->password,
					);
					$param_curl[CURLOPT_URL] = $this->url . '/api/Conectar';
					$param_curl[CURLOPT_RETURNTRANSFER] = true;
					$param_curl[CURLOPT_ENCODING] = '';
					$param_curl[CURLOPT_MAXREDIRS] = 10;
					$param_curl[CURLOPT_TIMEOUT] = 10;
					$param_curl[CURLOPT_FOLLOWLOCATION] = true;
					$param_curl[CURLOPT_HTTP_VERSION] = CURL_HTTP_VERSION_1_1;
					$param_curl[CURLOPT_SSL_VERIFYPEER] = 0;
					$param_curl[CURLOPT_CUSTOMREQUEST] = 'POST';
					$param_curl[CURLOPT_POSTFIELDS] = json_encode($postvars);
					$param_curl[CURLOPT_HTTPHEADER] = array(
						'Content-Type: application/json',
					);

					if ($this->usar_cert) {
						if (file_exists(ABSPATH . DS . $this->cert_path) && file_exists(ABSPATH . DS . $this->cert_key)) {
							if (!is_readable(ABSPATH . DS . $this->cert_path) || !is_readable(ABSPATH . DS . $this->cert_key)) {
								$retorno_erro['input'] = ABSPATH . DS . $this->cert_path . ' - ' . ABSPATH . DS . $this->cert_key;
								$retorno_erro['mensagem'] = 'Não foi possivel ler o arquivo do certificado, verifique as permissões';
								throw new Exception(json_encode($retorno_erro), 1);
							}
							$param_curl[CURLOPT_SSLCERT] = ABSPATH . DS . $this->cert_path;
							$param_curl[CURLOPT_SSLKEY] = ABSPATH . DS . $this->cert_key;
							$param_curl[CURLOPT_SSLCERTPASSWD] = 'cmsoftware';
						} else {
							$retorno_erro['input'] = ABSPATH . DS . $this->cert_path . ' - ' . ABSPATH . DS . $this->cert_key;
							$retorno_erro['output'] = null;
							$retorno_erro['mensagem'] = 'Certificado digital não encontrado';
							throw new Exception(json_encode($retorno_erro), 1);
						}
					}

					$response = json_decode($this->CurlExec($this->url, $param_curl));
					// CORNER PIX NÃO ESTA FUNCIONANDO MAIS DEVIDO A SAIDA DA CARTOS COMO CLIENTE CM, USAVAMOS A ESTRUTURA DELES
					// echo 'Finalizando autenticação corner '.$this->controller->data_hora_atual->format('Y-m-d H:i:s').'<br>';
					if (isset($response->ConectarResponse->Hash) && !empty($response->ConectarResponse->Hash)) {
						$this->hash = $response->ConectarResponse->Hash;
						$retorno_ok['input'] = $param_curl;
						$retorno_ok['output'] = $response;
						$retorno_ok['mensagem'] = 'ok';
						throw new Exception(json_encode($retorno_ok), 1);
					} else {
						if (!empty($this->codigo)) {
							$prefix_name = $this->codigo;
						} else {
							$prefix_name = 'api_exec';
						}
						$file_name = ABSPATH . '/logs/' . strtolower($prefix_name) . '_' . $this->data_atual->format('Ymd') . '.log';
						$fp = fopen($file_name, 'a+');
						fwrite($fp, $this->url . "/api/Conectar \n");
						fclose($fp);
						if (isset($response->ConectarResponse) && !empty($response->ConectarResponse)) {
							$retorno_erro['input'] = ABSPATH . DS . $this->cert_path . ' - ' . ABSPATH . DS . $this->cert_key;
							$retorno_erro['output'] = $response;
							$retorno_erro['mensagem'] = 'Erro ao conectar na DICT - Retorno: ' . $response->ConectarResponse->Retorno . ' - Problem: ' . $response->ConectarResponse->Problem->status;
						} else {
							$retorno_erro['input'] = ABSPATH . DS . $this->cert_path . ' - ' . ABSPATH . DS . $this->cert_key;
							$retorno_erro['output'] = $response;
							$retorno_erro['mensagem'] = 'Erro na conexão com a dict';
						}
						throw new Exception(json_encode($retorno_erro), 1);
					}
					break;
				case 'CAR001':
					$retorno_erro['codigo'] = 1;
					$retorno_erro['input'] = null;
					$retorno_erro['output'] = null;
					$retorno_erro['mensagem'] = '';

					$retorno_ok['codigo'] = 0;
					$retorno_ok['input'] = null;
					$retorno_ok['output'] = null;
					$retorno_ok['mensagem'] = '';
					$postvars = [
						"username" => $this->user_name,
						"password" => $this->password,
						"migrate" => false,
					];
					$param_curl[CURLOPT_URL] = $this->url . 'users/v1/login';
					$param_curl[CURLOPT_RETURNTRANSFER] = true;
					$param_curl[CURLOPT_SSL_VERIFYPEER] = false;
					$param_curl[CURLOPT_SSL_VERIFYHOST] = false;
					$param_curl[CURLOPT_HTTP_VERSION] = 'CURL_HTTP_VERSION_1_1';
					$param_curl[CURLOPT_CUSTOMREQUEST] = 'POST';
					$param_curl[CURLOPT_POSTFIELDS] = json_encode($postvars);
					$param_curl[CURLOPT_HTTPHEADER] = array(
						'x-api-key: 2segigP6Jg2lG30HuQuL03iJKU5QXC8m9MJHOCxX',
						'device_id: 54653186',
						'Content-Type: application/json',
					);

					$response = $this->CurlExec($this->url, $param_curl);
					$response = json_decode($response);
					if (isset($response->token) && !empty($response->token)) {
						$this->token = $response->token;
						$retorno_ok['input'] = $param_curl;
						$retorno_ok['output'] = $response;
						$retorno_ok['mensagem'] = 'ok';
						throw new Exception(json_encode($retorno_ok), 1);
					} else {
						$retorno_erro['input'] = ABSPATH . DS . $this->cert_path . ' - ' . ABSPATH . DS . $this->cert_key;
						$retorno_erro['output'] = $response;
						$retorno_erro['mensagem'] = $response->message;
						throw new Exception(json_encode($retorno_erro), 1);
					}
					break;
			}
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	function Exec($codigo, $objeto, $acao, $parametros = null, $timer = null)
	{
		try {
			switch ($codigo) {
				case 'BRD0001':
					switch ($objeto) {
						case 'token':
							switch ($acao) {
								case 'gerar':
									if (!file_exists(ABSPATH . DS . $this->cert_path)) {
										die('Erro: O arquivo do certificado não existe.');
									}

									// Verifica se o arquivo é legível
									if (!is_readable(ABSPATH . DS . $this->cert_path)) {
										die('Erro: O arquivo do certificado não pode ser lido.');
									}
									// Basic encodeBase64(client_id:client_secret)
									$headers = array(
										'Authorization: Basic ' . base64_encode($this->security_key . ':' . $this->user_name),
										'Content-Type: application/x-www-form-urlencoded'
									);
									$data = [
										'grant_type' => 'client_credentials',
										'scope' => 'transferencia.write'
									];
									$url = $this->url . 'oauth/token';
									$param_curl[CURLOPT_URL] = $url;
									$param_curl[CURLOPT_HTTPHEADER] = $headers;
									// $param_curl[CURLOPT_POST] 			= true;
									$param_curl[CURLOPT_RETURNTRANSFER] = true;
									$param_curl[CURLOPT_SSLCERT] = ABSPATH . DS . $this->cert_path;
									$param_curl[CURLOPT_SSLKEY] = ABSPATH . DS . $this->cert_key;
									$param_curl[CURLOPT_SSLCERTPASSWD] = $this->password;
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'POST';
									// $param_curl[CURLOPT_SSL_VERIFYPEER] = 0;
									// $param_curl[CURLOPT_KEYPASSWD]  	= $this->password;
									$param_curl[CURLOPT_POSTFIELDS] = http_build_query($data);
									$param_curl[CURLOPT_POSTFIELDS] = "grant_type=client_credentials&scope=transferencia.write";
									$param_curl[CURLOPT_VERBOSE] = true;
									$param_curl[CURLOPT_CERTINFO] = true;
									$response = json_decode($this->CurlExec($url, $param_curl));
									if (isset($response->access_token) && !empty($response->access_token)) {
										$retorno['status'] = 'ok';
										$retorno['output'] = $response->access_token;
										$retorno['mensagem'] = null;
									} else {
										$retorno['status'] = 'erro';
										$retorno['mensagem'] = 'Erro ao obter o token de acesso bradesco';
									}
									throw new Exception(json_encode($retorno), 1);
									break;
							}
							break;
						case 'pix':
							switch ($acao) {
								case 'enviar':
									$token_bradesco = $parametros['token_bradesco'];
									unset($parametros['token_bradesco']);
									$headers = array(
										'Authorization: Bearer ' . $token_bradesco,
										'Content-Type: application/json'
									);
									$url = $this->url . 'v1/spi/solicitar-transferencia';
									$param_curl[CURLOPT_URL] = $url;
									$param_curl[CURLOPT_HTTPHEADER] = $headers;
									if (!file_exists(ABSPATH . DS . $this->cert_path)) {
										die('Erro: O arquivo do certificado não existe.');
									}

									// Verifica se o arquivo é legível
									if (!is_readable(ABSPATH . DS . $this->cert_path)) {
										die('Erro: O arquivo do certificado não pode ser lido.');
									}
									$param_curl[CURLOPT_SSLCERT] = ABSPATH . $this->cert_path;
									$param_curl[CURLOPT_SSLKEY] = ABSPATH . $this->cert_key;
									$param_curl[CURLOPT_SSLCERTPASSWD] = $this->password;
									$param_curl[CURLOPT_RETURNTRANSFER] = 1;
									$param_curl[CURLOPT_POST] = true;
									$param_curl[CURLOPT_VERBOSE] = true;
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'POST';
									$param_curl[CURLOPT_TIMEOUT] = 0;
									$param_curl[CURLOPT_POSTFIELDS] = json_encode($parametros);
									$response = json_decode($this->CurlExec($url, $param_curl));
									if (isset($response->idTransacao) && !empty(isset($response->idTransacao))) {
										$retorno['status'] = 'ok';
										$retorno['output'] = $response;
									} else {
										$retorno['status'] = 'erro';
										$retorno['output'] = $response->violacoes;
										$retorno['mensagem'] = $response->detail;
									}
									throw new Exception(json_encode($retorno), 1);
									break;
							}
							break;
					}
					break;
				case 'CRY0001':
				case 'CRY0002':
				case 'CRY0003':
					switch ($objeto) {
						case 'agente':
							switch ($acao) {
								case 'cadastrar':
									$url = $this->url . '/v0/tarifador/commercial-agents';
									$json_param = json_encode($parametros);
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array('ContenT-Type: application/json; charset=utf-8'),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_POST => true,
										CURLOPT_POSTFIELDS => $json_param,
										CURLOPT_TIMEOUT => 0,
									);

									$response = json_decode($this->CurlExec($url, $options));
									if (!$response || $this->response_http_code == 422) {
										$retorno['codigo'] = 1;
										if (isset($response->anonymized_tax_id_number)) {
											$retorno['mensagem'] = $response->anonymized_tax_id_number[0];
										} else {
											$retorno['mensagem'] = 'Erro desconhecido ao integrar com Crystal';
										}
									} elseif ($this->response_http_code == 201) {
										$retorno['codigo'] = 0;
										$retorno['mensagem'] = 'Sucesso';
									} else {
										$retorno['codigo'] = 1;
										$retorno['mensagem'] = 'Erro codigo 748';
									}
									throw new Exception(json_encode($retorno), 1);
									break;
								default:
									$retorno['codigo'] = 1;
									$retorno['mensagem'] = 'Erro codigo 754';
									throw new Exception(json_encode($retorno), 1);
									break;
							}
							break;
						case 'cliente':
							switch ($acao) {
								case 'ativar':
									$url = $this->url . '/v0/tarifador/clients/activate?tax_id_number=' . $parametros['tax_id_number'];
									$json_param = json_encode($parametros);
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array('ContenT-Type: application/json; charset=utf-8'),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_CUSTOMREQUEST => 'PATCH',
										CURLOPT_POST => true,
										CURLOPT_TIMEOUT => 0,
									);

									$response = json_decode($this->CurlExec($url, $options));
									if (!$response || $this->response_http_code == 422) {
										$retorno['codigo'] = 1;
										if (isset($response->anonymized_tax_id_number)) {
											$retorno['mensagem'] = $response->anonymized_tax_id_number[0];
										} else {
											$retorno['mensagem'] = 'Erro desconhecido ao integrar com Crystal';
										}
									} elseif ($this->response_http_code == 201) {
										$retorno['codigo'] = 0;
										$retorno['mensagem'] = 'Sucesso';
									} else {
										$retorno['codigo'] = 1;
										$retorno['mensagem'] = 'Erro codigo 748';
									}
									throw new Exception(json_encode($retorno), 1);
									break;
								case 'onboarding':
									$json_cliente['name'] = $parametros['razao_social'];
									$json_cliente['documentNumber'] = $parametros['cnpj'];
									$json_cliente['phone'] = removeCaracteres(trim($parametros['telefone_representante']), 'all');
									$json_cliente['representativeName'] = trim($parametros['contato']);
									$json_cliente['documentNumberRepresentative'] = $parametros['cnpj'];
									$json_cliente['address']['zipCode'] = $parametros['cep'];
									$json_cliente['address']['street'] = $parametros['endereco'];
									$json_cliente['address']['number'] = $parametros['numero'];
									$json_cliente['address']['complement'] = $parametros['complemento'];
									$json_cliente['address']['district'] = $parametros['bairro'];
									$json_cliente['address']['city'] = $parametros['cidade'];
									$json_cliente['address']['state'] = $parametros['estado'];
									$json_cliente['witness']['tax_id_number'] = $parametros['cnpj'];
									$json_cliente['witness']['name'] = $parametros['razao_social'];
									$json_cliente['witness']['email'] = $parametros['email_contato'];
									$json_cliente['witness']['phone'] = removeCaracteres(trim($parametros['telefone_representante']), 'all');
									$url_auth = $this->url . 'commercial-agents/authenticate';
									$json_auth['documentNumber'] = '07003180000104';
									$json_auth['password'] = 'Senha@2023';
									$options_auth = array(
										CURLOPT_URL => $url_auth,
										CURLOPT_HTTPHEADER => array('ContenT-Type: application/json'),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_ENCODING => '',
										CURLOPT_MAXREDIRS => 10,
										CURLOPT_TIMEOUT => 0,
										CURLOPT_FOLLOWLOCATION => true,
										CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
										CURLOPT_CUSTOMREQUEST => 'POST',
										CURLOPT_POST => true,
										CURLOPT_POSTFIELDS => json_encode($json_auth),
										CURLOPT_TIMEOUT => 0,
									);
									$auth = json_decode($this->CurlExec($url_auth, $options_auth));
									if (isset($auth->accessToken) && !empty($auth->accessToken)) {
										$url = $this->url . 'licensees/';
										$options = array(
											CURLOPT_URL => $url,
											CURLOPT_HTTPHEADER => array(
												'ContenT-Type: application/json',
												'Authorization: Bearer ' . $auth->accessToken
											),
											CURLOPT_RETURNTRANSFER => 1,
											CURLOPT_ENCODING => '',
											CURLOPT_MAXREDIRS => 10,
											CURLOPT_TIMEOUT => 0,
											CURLOPT_FOLLOWLOCATION => true,
											CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
											CURLOPT_CUSTOMREQUEST => 'POST',
											CURLOPT_POST => true,
											CURLOPT_POSTFIELDS => json_encode($json_cliente),
											CURLOPT_TIMEOUT => 0,
										);
										$ativacao = json_decode($this->CurlExec($url, $options));
										if ($this->response_http_code == 200) {
											$retorno['codigo'] = 0;
											$retorno['mensagem'] = 'Sucesso';
											throw new Exception(json_encode($retorno), 1);
										} else {
											$retorno['codigo'] = 1;
											$retorno['output'] = $ativacao;
											$retorno['mensagem'] = 'Erro na autenticação COD: 848';
											throw new Exception(json_encode($retorno), 1);
										}
									} else {
										$retorno['codigo'] = 1;
										$retorno['mensagem'] = 'Erro na autenticação COD: 848';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								default:
									$retorno['codigo'] = 1;
									$retorno['mensagem'] = 'Erro codigo 754';
									throw new Exception(json_encode($retorno), 1);
									break;
							}
							break;
						default:
							# code...
							break;
					}
					break;
				case 'FRA0143':
					switch ($objeto) {
						case 'fraude':
							switch ($acao) {
								case 'incluir':
									header('Content-Type: application/xml');
									// $xmlString = '
									// 	<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:int="http://interfaces.webservice.rocket.cmsoftware.com.br">
									// 	<soapenv:Header/>
									// ';
									$xmlString = '
											<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:int="http://interfaces.webservice.rocket.cmsoftware.com.br">
											<soapenv:Header/>
											<soapenv:Body>
												<int:' . $this->manager . '>
													<int:TIPO_CHAVE>' . strtolower($parametros->tipo_chave) . '</int:TIPO_CHAVE>
													<int:CHAVE_PIX>' . strtolower($parametros->chave) . '</int:CHAVE_PIX>
													<int:EMAIL>' . strtolower($parametros->email) . '</int:EMAIL>
													<int:VALOR>' . strtolower($parametros->valor) . '</int:VALOR>
													<int:TOKEN>' . strtolower($parametros->token) . '</int:TOKEN>
													<int:header>
														<empresa>' . $this->dev_id . '</empresa>
														<usuario>' . $this->user_name . '</usuario>
														<senha>' . $this->password . '</senha>
														<hash></hash>
														<fluxo>' . $this->manager . '</fluxo>
														<ticket></ticket>
													</int:header>
												</int:' . $this->manager . '>
											</soapenv:Body>
											</soapenv:Envelope>
										';
									$param_curl[CURLOPT_URL] = $this->url;
									$param_curl[CURLOPT_HTTPHEADER] = array('ContenT-Type: text/xml; charset=utf-8');
									$param_curl[CURLOPT_SSLCERT] = ABSPATH . DS . $this->cert_path;
									$param_curl[CURLOPT_SSLKEY] = ABSPATH . DS . $this->cert_key;
									$param_curl[CURLOPT_SSLCERTPASSWD] = $this->password;
									$param_curl[CURLOPT_RETURNTRANSFER] = 1;
									$param_curl[CURLOPT_POST] = true;
									$param_curl[CURLOPT_VERBOSE] = false;
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'POST';
									$param_curl[CURLOPT_TIMEOUT] = 0;
									$param_curl[CURLOPT_POSTFIELDS] = $xmlString;
									$response = $this->CurlExec($this->url, $param_curl);
									$dom = new DOMDocument;
									$dom->loadXML($response);
									$faultReturn = $dom->getElementsByTagName('faultstring')->item(0);
									$processReturn = $dom->getElementsByTagName('processReturn')->item(0);
									if (isset($processReturn->nodeValue) && !empty($processReturn->nodeValue)) {
										$retorno['codigo'] = 0;
										$retorno['mensagem'] = $processReturn->nodeValue;
									} else {
										$fault = $dom->getElementsByTagName('faultstring')->item(0);
										$retorno['codigo'] = 1;
										$retorno['mensagem'] = 'Erro ao enviar para o rocket ' . $fault->nodeValue;
									}
									throw new Exception(json_encode($retorno), 1);
									break;
							}
							break;
					}
					break;
				case 'NFE0001':
				case 'NFE0002':
				case 'NFE0003':
				case 'NFE0004':
					if (!isset($parametros['validar']) || $parametros['validar'] == true) {
						$parametros['validar'] = 1;
					} else {
						$parametros['validar'] = 0;
					}

					$param_curl[CURLOPT_URL] = $this->url;
					$param_curl[CURLOPT_HTTPHEADER] = array('ContenT-Type: text/xml; charset=utf-8');
					$param_curl[CURLOPT_SSLCERT] = ABSPATH . DS . $this->cert_path;
					$param_curl[CURLOPT_SSLKEY] = ABSPATH . DS . $this->cert_key;
					$param_curl[CURLOPT_SSLCERTPASSWD] = $this->password;
					$param_curl[CURLOPT_RETURNTRANSFER] = 1;
					$param_curl[CURLOPT_POST] = true;
					$param_curl[CURLOPT_VERBOSE] = false;
					$param_curl[CURLOPT_CUSTOMREQUEST] = 'POST';
					$param_curl[CURLOPT_TIMEOUT] = 0;
					switch ($objeto) {
						case 'arquivo':
							switch ($acao) {
								case 'enviar':
									$xml = '
											<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:nfe="http://www.barueri.sp.gov.br/nfe">
											<soap:Header/>
												<soap:Body>
													<nfe:NFeLoteEnviarArquivo>
														<nfe:VersaoSchema>1</nfe:VersaoSchema>
														<!--Optional:-->
														<nfe:MensagemXML>
															<![CDATA[
																<NFeLoteEnviarArquivo xmlns="http://www.barueri.sp.gov.br/nfe">
																<InscricaoMunicipal>' . $parametros['inscricao_municipal'] . '</InscricaoMunicipal>
																<CPFCNPJContrib>' . $parametros['cnpj'] . '</CPFCNPJContrib>
																<NomeArquivoRPS>' . $parametros['nome_arquivo'] . '</NomeArquivoRPS>
																<ApenasValidaArq>' . $parametros['validar'] . '</ApenasValidaArq>
																<ArquivoRPSBase64>' . $parametros['base64_arquivo'] . '</ArquivoRPSBase64>
															</NFeLoteEnviarArquivo>
														]]>
														</nfe:MensagemXML>
													</nfe:NFeLoteEnviarArquivo>
												</soap:Body>
											</soap:Envelope>
										';

									$param_curl[CURLOPT_POSTFIELDS] = $xml;
									$response = $this->CurlExec($this->url, $param_curl);
									if ($response) {
										$response = simplexml_load_string($response, 'SimpleXMLElement', LIBXML_NOCDATA);
										$result = $this->removeSoapEnvelope($response);
										if ($result->NFeLoteEnviarArquivoResponse->NFeLoteEnviarArquivoResult->ListaMensagemRetorno->Codigo->{0} == 'OK200') {
											$retorno['codigo'] = 0;
											$retorno['output'] = (String) $result->NFeLoteEnviarArquivoResponse->NFeLoteEnviarArquivoResult->ProtocoloRemessa->{0};
											$retorno['mensagem'] = (string) $result->NFeLoteEnviarArquivoResponse->NFeLoteEnviarArquivoResult->ListaMensagemRetorno->Mensagem;
										} else {
											$retorno['codigo'] = 1;
											$retorno['output'] = (String) $result->NFeLoteEnviarArquivoResponse->NFeLoteEnviarArquivoResult->ListaMensagemRetorno->Codigo->{0};
											$retorno['mensagem'] = (string) $result->NFeLoteEnviarArquivoResponse->NFeLoteEnviarArquivoResult->ListaMensagemRetorno->Mensagem;
										}
									} else {
										$retorno['codigo'] = 1;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Erro ao enviar o arquivo';
									}
									throw new Exception(json_encode($retorno), 1);
									break;
								case 'status':
									$xml = '
											<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:nfe="http://www.barueri.sp.gov.br/nfe">
											<soap:Header/>
												<soap:Body>
													<nfe:NFeLoteStatusArquivo>
														<nfe:VersaoSchema>1</nfe:VersaoSchema>
														<!--Optional:-->
														<nfe:MensagemXML>
															<![CDATA[
																<NFeLoteStatusArquivo xmlns="http://www.barueri.sp.gov.br/nfe">
																<InscricaoMunicipal>' . $parametros['inscricao_municipal'] . '</InscricaoMunicipal>
																<CPFCNPJContrib>' . $parametros['cnpj'] . '</CPFCNPJContrib>
																<ProtocoloRemessa>' . $parametros['ProtocoloRemessa'] . '</ProtocoloRemessa>
															</NFeLoteStatusArquivo>
														]]>
														</nfe:MensagemXML>
													</nfe:NFeLoteStatusArquivo>
												</soap:Body>
											</soap:Envelope>
										';
									$param_curl[CURLOPT_POSTFIELDS] = $xml;
									$response = $this->CurlExec($this->url, $param_curl);
									$response = simplexml_load_string($response, 'SimpleXMLElement', LIBXML_NOCDATA);
									$result = $this->removeSoapEnvelope($response);
									if ($result->NFeLoteStatusArquivoResponse->NFeLoteStatusArquivoResult->ListaMensagemRetorno->Codigo->{0} == 'OK200') {
										if (isset($result->NFeLoteStatusArquivoResponse->NFeLoteStatusArquivoResult->ListaNfeArquivosRPS->SituacaoArq->{0})) {
											$retorno['info']['SituacaoArq'] = (string) $result->NFeLoteStatusArquivoResponse->NFeLoteStatusArquivoResult->ListaNfeArquivosRPS->SituacaoArq->{0};
											$retorno['info']['NomeArqRetorno'] = $result->NFeLoteStatusArquivoResponse->NFeLoteStatusArquivoResult->ListaNfeArquivosRPS->NomeArqRetorno;
										} else {
											$retorno['info']['SituacaoArq'] = 'erro';
											$retorno['info']['NomeArqRetorno'] = null;
										}

										if ('2' == (String) $result->NFeLoteStatusArquivoResponse->NFeLoteStatusArquivoResult->ListaNfeArquivosRPS->SituacaoArq) {
											$retorno['codigo'] = 1;
											$retorno['output'] = (String) $result->NFeLoteStatusArquivoResponse->NFeLoteStatusArquivoResult->ListaNfeArquivosRPS->SituacaoArq;
											$retorno['mensagem'] = 'Arquivo com erros';
										} else {
											$retorno['codigo'] = 0;
											$retorno['output'] = (String) $result->NFeLoteStatusArquivoResponse->NFeLoteStatusArquivoResult->ListaNfeArquivosRPS->SituacaoArq;
											$retorno['mensagem'] = (string) $result->NFeLoteStatusArquivoResponse->NFeLoteStatusArquivoResult->ListaMensagemRetorno->Mensagem;
										}
									} else {
										$retorno['codigo'] = 1;
										$retorno['output'] = (String) $result->NFeLoteStatusArquivoResponse->NFeLoteStatusArquivoResult->ListaMensagemRetorno->Codigo->{0};
										$retorno['mensagem'] = (string) $result->NFeLoteStatusArquivoResponse->NFeLoteStatusArquivoResult->ListaMensagemRetorno->Mensagem;
									}
									throw new Exception(json_encode($retorno), 1);
									break;
								case 'download':
									$xml = '
											<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:nfe="http://www.barueri.sp.gov.br/nfe">
											<soap:Header/>
												<soap:Body>
													<nfe:NFeLoteBaixarArquivo>
														<nfe:VersaoSchema>1</nfe:VersaoSchema>
														<!--Optional:-->
														<nfe:MensagemXML>
															<![CDATA[
																<NFeLoteBaixarArquivo xmlns="http://www.barueri.sp.gov.br/nfe">
																<InscricaoMunicipal>' . $parametros['inscricao_municipal'] . '</InscricaoMunicipal>
																<CPFCNPJContrib>' . $parametros['cnpj'] . '</CPFCNPJContrib>
																<NomeArqRetorno>' . $parametros['NomeArqRetorno'] . '</NomeArqRetorno>
															</NFeLoteBaixarArquivo>
														]]>
														</nfe:MensagemXML>
													</nfe:NFeLoteBaixarArquivo>
												</soap:Body>
											</soap:Envelope>
										';
									$param_curl[CURLOPT_POSTFIELDS] = $xml;
									$response = $this->CurlExec($this->url, $param_curl);
									$response = simplexml_load_string($response, 'SimpleXMLElement', LIBXML_NOCDATA);
									$result = $this->removeSoapEnvelope($response);
									if ($result->NFeLoteBaixarArquivoResponse->NFeLoteBaixarArquivoResult->ListaMensagemRetorno->Codigo->{0} == 'OK200') {
										$retorno['codigo'] = 0;
										$retorno['info'] = $result->NFeLoteBaixarArquivoResponse->NFeLoteBaixarArquivoResult->ArquivoRPSBase64->{0};
										$retorno['output'] = (String) $result->NFeLoteBaixarArquivoResponse->NFeLoteBaixarArquivoResult->ListaMensagemRetorno->Codigo->{0};
										$retorno['mensagem'] = (string) $result->NFeLoteBaixarArquivoResponse->NFeLoteBaixarArquivoResult->ListaMensagemRetorno->Mensagem;
									} else {
										$retorno['codigo'] = 1;
										$retorno['info'] = null;
										$retorno['output'] = (String) $result->NFeLoteBaixarArquivoResponse->NFeLoteBaixarArquivoResult->ListaMensagemRetorno->Codigo->{0};
										$retorno['mensagem'] = (string) $result->NFeLoteBaixarArquivoResponse->NFeLoteBaixarArquivoResult->ListaMensagemRetorno->Mensagem;
									}
									throw new Exception(json_encode($retorno), 1);
									break;
								case 'listar':
									# code...
									break;
								case 'retorno':
									# code...
									break;
							}
							break;
					}
					break;
				case 'RCK001':
					switch ($objeto) {
						case 'mq':
							switch ($acao) {
								case 'getMessage':
									# code...
									break;
								case 'inputMessage':
									# code...
									break;
							}
							break;
					}
					break;
				case 'CAR001':
					if (!$this->token) {
						$this->Conectar();
					}
					$param_curl[CURLOPT_RETURNTRANSFER] = true;
					$param_curl[CURLOPT_SSL_VERIFYPEER] = false;
					$param_curl[CURLOPT_SSL_VERIFYHOST] = false;
					$param_curl[CURLOPT_HTTP_VERSION] = 'CURL_HTTP_VERSION_1_1';
					switch ($objeto) {
						case 'user':
							# code...
							break;
						case 'pix':
							switch ($acao) {
								case 'sendByKey':
									$url = $this->url . 'account-digital/v1/transfers';
									$param_curl[CURLOPT_HTTPHEADER] = array(
										'x-api-key: 2segigP6Jg2lG30HuQuL03iJKU5QXC8m9MJHOCxX',
										'transaction-security-token: 7892',
										'Content-Type: application/json',
										'Authorization: Bearer ' . $this->token
									);
									$postvars = [
										"amount" => $parametros['amount'],
										"category" => 'PIX',
										"sourceKey" => $parametros['sourceKey'],
										"targetKey" => $parametros['targetKey'],
										"description" => $parametros['description'],
										"tradeName" => 'TOKEN PIX',
									];
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'POST';
									$param_curl[CURLOPT_POSTFIELDS] = json_encode($postvars);
									$param_curl[CURLOPT_URL] = $url;

									$response = $this->CurlExec($url, $param_curl);
									// echo 'Iniciando envio de pix por chave Cartos '.$this->controller->data_hora_atual->format('Y-m-d H:i:s').'<br>';
									$response = json_decode($response);
									if (isset($response->transactionId)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->message;
									}
									throw new Exception(json_encode($retorno), 1);
									break;
								case 'sendByAccount':
									$url = $this->url . 'account-digital/v1/transfers';
									$param_curl[CURLOPT_HTTPHEADER] = array(
										'x-api-key: ' . $this->key,
										'transaction-security-token: ' . $parametros['transaction_security'],
										'Content-Type: application/json',
										'Authorization: Bearer ' . $this->token
									);
									$postvars = [
										"recept_cpf_cnpj" => $parametros['recept_cpf_cnpj'],
										"recept_account" => $parametros['recept_account'],
										"recept_agency" => $parametros['recept_agency'],
										"recept_account_type" => strtoupper($parametros['recept_account_type']),
										"recept_code_bank" => $parametros['recept_code_bank'],
										"amount" => $parametros['amount'],
										"category" => 'PIXBANKDATA',
										"description" => $parametros['description'],
									];
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'POST';
									$param_curl[CURLOPT_POSTFIELDS] = json_encode($postvars);
									$param_curl[CURLOPT_URL] = $url;
									// $file_name = ABSPATH.'/logs/teste_conta_'.$this->data_atual->format('Ymd').'.log';
									// $fp        = fopen($file_name, 'a+');
									// fwrite($fp, json_encode($param_curl)."\n");
									// fclose($fp);
									$response = $this->CurlExec($url, $param_curl);
									$response = json_decode($response);
									if (!isset($response->code)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'ok';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->message;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'find':
									$url = $this->url . '/digital-account/v1/pix-keys/' . $parametros['pix_key'];
									$param_curl[CURLOPT_HTTPHEADER] = array(
										'x-api-key: ' . $this->key,
										'Content-Type: application/json',
										'Authorization: Bearer ' . $this->token
									);
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'GET';
									$param_curl[CURLOPT_URL] = $url;
									$response = $this->CurlExec($url, $param_curl);
									$response = json_decode($response);
									if (isset($response->code)) {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros['pix_key'];
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->details->message;
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros['pix_key'];
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'list_pix':
									$url = $this->url . '/digital-account/v1/pix-keys';
									$param_curl[CURLOPT_HTTPHEADER] = array(
										'x-api-key: ' . $this->key,
										'Content-Type: application/json',
										'Authorization: Bearer ' . $this->token
									);
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'GET';
									$param_curl[CURLOPT_URL] = $url;
									$response = $this->CurlExec($url, $param_curl);
									$response = json_decode($response);
									if (isset($response->code)) {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros['pix_key'];
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->details->message;
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros['pix_key'];
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
							}
							break;
						case 'transacao':
							switch ($acao) {
								case 'extrato':
									$url = $this->url . 'account-digital/v1/extract?page=1&perPage=10000000';
									$param_curl[CURLOPT_HTTPHEADER] = array(
										'x-api-key: ' . $this->key,
										'Content-Type: application/json',
										'Authorization: Bearer ' . $this->token
									);
									$param_curl[CURLOPT_URL] = $url;
									$response = $this->CurlExec($url, $param_curl);
									$response = json_decode($response);
									if (isset($response->count)) {
										$retorno['codigo'] = 0;
										$retorno['tipo'] = "sucesso";
										$retorno['mensagem'] = 'ok';
										$retorno['dados'] = $response;
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['tipo'] = "erro";
										$retorno['mensagem'] = 'Sem resposta';
										$retorno['dados'] = $response;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'balanco':
									$param_curl[CURLOPT_HTTPHEADER] = array(
										'x-api-key: ' . $this->key,
										'Content-Type: application/json',
										'Authorization: Bearer ' . $this->token
									);
									$url = $this->url . '/account-digital/v1/balance';
									$param_curl[CURLOPT_URL] = $url;
									$response = $this->CurlExec($url, $param_curl);
									$response = json_decode($response);
									if ($response) {
										$retorno['codigo'] = 0;
										$retorno['tipo'] = "sucesso";
										$retorno['mensagem'] = 'ok';
										$retorno['dados'] = $response;
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['tipo'] = "erro";
										$retorno['mensagem'] = 'Sem resposta';
										$retorno['dados'] = $response;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'consulta':
									$param_curl[CURLOPT_HTTPHEADER] = array(
										'x-api-key: ' . $this->key,
										'Content-Type: application/json',
										'Authorization: Bearer ' . $this->token
									);
									$url = $this->url . '/account-digital/v1/transfers/' . $parametros['transactionId'];
									// $url = $this->url.'/account-digital/v1/balance';
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'GET';
									$param_curl[CURLOPT_URL] = $url;
									$response = $this->CurlExec($url, $param_curl);
									$response = json_decode($response);
									if (isset($response->transactionId) && !empty($response->transactionId)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->message;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
							}
							break;
						case 'pin':
							switch ($acao) {
								case 'create_pin':
									$param_curl[CURLOPT_HTTPHEADER] = array(
										'x-api-key: ' . $this->key,
										'password: ' . $this->password,
										'Content-Type: application/json',
										'Authorization: Bearer ' . $this->token
									);
									$postvars = [
										"transactionPassword" => $parametros['transactionPassword'],
									];

									$url = $this->url . 'digital-account/v1/users/transaction-password';
									$param_curl[CURLOPT_POSTFIELDS] = json_encode($postvars);
									$param_curl[CURLOPT_URL] = $url;
									$response = $this->CurlExec($this->url, $param_curl);
									// echo 'Iniciando criação de pin Cartos '.$this->controller->data_hora_atual->format('Y-m-d H:i:s').'<br>';
									$response = json_decode($response);
									if (!isset($response->code)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'ok';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->message;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'create_transaction_token':
									$retorno['codigo'] = 0;
									$retorno['input'] = $parametros;
									$retorno['output'] = $this->token;
									$retorno['mensagem'] = 'ok';
									throw new Exception(json_encode($retorno), 1);
									/*
									$param_curl[CURLOPT_HTTPHEADER] = array(
										'x-api-key: 2segigP6Jg2lG30HuQuL03iJKU5QXC8m9MJHOCxX',
										'password: C&M@1234',
										'Content-Type: application/json',
										'Authorization: Bearer '.$this->token
									);
									$postvars = [
										"transactionPassword" => $parametros['transactionPassword']
									];
									$url = $this->url.'digital-account/v1/users/transaction-password/verify';
									$param_curl[CURLOPT_POSTFIELDS] = json_encode($postvars);
									$param_curl[CURLOPT_URL]        = $url;
									$response = $this->CurlExec($url, $param_curl);
									$response = json_decode($response);
									if(isset($response->tokenTransaction) && !empty($response->tokenTransaction)){
										$retorno['codigo']   = 0;
										$retorno['input']    = $parametros;
										$retorno['output']   = $response;
										$retorno['mensagem'] = 'ok';
										throw new Exception(json_encode($retorno), 1);
									}else{
										$retorno['codigo']   = 1;
										$retorno['input']    = $parametros;
										$retorno['output']   = $response;
										$retorno['mensagem'] = $response->message;
										throw new Exception(json_encode($retorno), 1);
									}
									*/
									break;
							}
							break;
					}
					break;
				case 'COR001':
				case 'COR002':
					$retorno_erro['codigo'] = 1;
					$retorno_erro['input'] = null;
					$retorno_erro['output'] = null;
					$retorno_erro['mensagem'] = '';

					$retorno_ok['codigo'] = 0;
					$retorno_ok['input'] = null;
					$retorno_ok['mensagem'] = '';
					$con = json_decode($this->Conectar());
					if (isset($con->codigo) && $con->codigo == 0) {
						switch ($objeto) {
							case 'pix':
								switch ($acao) {
									case 'consultar_chave':
										if ($this->hash) {
											/*
												{
													"DictConsultarRequest": {
														"Hash": "070AC3FA8707F0D6",
														"Key": "05838749911",
														"piPayerId": "12345678901",
														"EndToEndId": ""
													}
												}
											*/
											$postvars['DictConsultarRequest'] = array(
												"Hash" => $this->hash,
												"Key" => $parametros['chave'], // chave pix
												"piPayerId" => $parametros['cnpj_cpf'], // CPF ou CNPJ
												"EndToEndId" => ""
											);
											$param_curl[CURLOPT_URL] = $this->url . '/api/DictConsultar';
											$param_curl[CURLOPT_RETURNTRANSFER] = true;
											$param_curl[CURLOPT_ENCODING] = '';
											$param_curl[CURLOPT_MAXREDIRS] = 10;
											$param_curl[CURLOPT_TIMEOUT] = 10;
											$param_curl[CURLOPT_FOLLOWLOCATION] = true;
											$param_curl[CURLOPT_HTTP_VERSION] = CURL_HTTP_VERSION_1_1;
											$param_curl[CURLOPT_SSL_VERIFYPEER] = 0;
											$param_curl[CURLOPT_CUSTOMREQUEST] = 'POST';
											$param_curl[CURLOPT_POSTFIELDS] = json_encode($postvars);
											$param_curl[CURLOPT_HTTPHEADER] = array(
												'Content-Type: application/json',
											);

											if ($this->usar_cert) {
												if (file_exists(ABSPATH . DS . $this->cert_path) && file_exists(ABSPATH . DS . $this->cert_key)) {
													if (!file_exists(ABSPATH . DS . $this->cert_path) || !is_readable(ABSPATH . DS . $this->cert_key)) {
														$retorno_erro['input'] = ABSPATH . DS . $this->cert_path . ' - ' . ABSPATH . DS . $this->cert_key;
														$retorno_erro['mensagem'] = 'Não foi possivel ler o arquivo do certificado, verifique as permissões';
														throw new Exception(json_encode($retorno_erro), 1);
													}
													$param_curl[CURLOPT_SSLCERT] = ABSPATH . DS . $this->cert_path;
													$param_curl[CURLOPT_SSLKEY] = ABSPATH . DS . $this->cert_key;
													$param_curl[CURLOPT_SSLCERTPASSWD] = 'cmsoftware';
												} else {
													$retorno_erro['input'] = ABSPATH . DS . $this->cert_path . ' - ' . ABSPATH . DS . $this->cert_key;
													$retorno_erro['mensagem'] = 'Certificado digital não encontrado';
													throw new Exception(json_encode($retorno_erro), 1);
												}
											}
											$response = json_decode($this->CurlExec($this->url, $param_curl));
											if (!isset($response->DictConsultarResponse->Problem)) {
												$retorno_ok['input'] = $param_curl;
												$retorno_ok['output'] = $response;
												$retorno_ok['mensagem'] = 'ok';
												throw new Exception(json_encode($retorno_ok), 1);
											} else {
												$retorno_erro['input'] = $postvars;
												$retorno_erro['output'] = $response;
												$retorno_erro['mensagem'] = $response->DictConsultarResponse->Problem->detail;
												throw new Exception(json_encode($retorno_erro), 1);
											}
										} else {
											$retorno_erro['mensagem'] = 'Hash de conexao nao encontrado DICT - codigo HTTP: ' . $this->response_http_code;
											$this->return = json_encode($retorno_erro);
											throw new Exception(json_encode($retorno_erro), 1);
										}
										break;
								}
								break;
						}
					} else {
						if (isset($con->output->ConectarResponse->Retorno)) {
							$retorno_erro['mensagem'] = $con->mensagem;
						} else {
							$retorno_erro['mensagem'] = 'Conexão DICT não encontrada - codigo HTTP: ' . $this->response_http_code;
						}
						$this->return = json_encode($retorno_erro);
						throw new Exception(json_encode($retorno_erro), 1);
					}
					break;
				case 'CLI001':
					switch ($objeto) {
						case 'documento':
							switch ($acao) {
								case 'info':
									$url = $this->url . "/api/v1/documents/" . $parametros['document_key'] . "?access_token=" . $this->token;
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_TIMEOUT => 0,
									);
									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response) {
										$retorno['codigo'] = 0;
										$retorno['tipo'] = "sucesso";
										$retorno['mensagem'] = 'ok';
										$retorno['dados'] = $response;
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['tipo'] = "erro";
										$retorno['mensagem'] = 'Sem resposta';
										$retorno['dados'] = $response;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'listAll':
									$url = $this->url . "/api/v1/documents?page=100&access_token=" . $this->token;
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_TIMEOUT => 0,
									);
									$response = $this->CurlExec($this->url, $options);
									if ($response) {
										$retorno['codigo'] = 0;
										$retorno['tipo'] = "sucesso";
										$retorno['mensagem'] = 'ok';
										$retorno['dados'] = $response;
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['tipo'] = "erro";
										$retorno['mensagem'] = 'Sem resposta';
										$retorno['dados'] = $response;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'upload':
									$url = $this->url . "/api/v1/documents?access_token=" . $this->token;
									$dados['document']['path'] = $parametros['path'];
									$dados['document']['content_base64'] = $parametros['content_base64'];
									$dados['document']['deadline_at'] = $parametros['deadline_at'];
									$dados['document']['auto_close'] = $parametros['auto_close'];
									$dados['document']['locale'] = $parametros['locale'];
									$dados['document']['sequence_enabled'] = $parametros['sequence_enabled'];
									$dados['document']['block_after_refusal'] = $parametros['block_after_refusal'];
									$json_param = json_encode($dados);
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_POST => true,
										CURLOPT_POSTFIELDS => $json_param,
										CURLOPT_TIMEOUT => 0,
									);
									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response) {
										if (!isset($response->errors)) {
											$retorno['codigo'] = 0;
											$retorno['input'] = null;
											$retorno['output'] = $response;
											$retorno['mensagem'] = 'ok';
											throw new Exception(json_encode($retorno), 1);
										} else {
											$retorno['codigo'] = 1;
											$retorno['input'] = null;
											$retorno['output'] = $response;
											$retorno['mensagem'] = $response->errors[0];
											throw new Exception(json_encode($retorno), 1);
										}
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = null;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Erro ao tentar fazer upload';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
							}
							break;
						case 'assinatura':
							switch ($acao) {
								case 'assinar':
									break;
								case 'visualizar_assinante':
									$url = $this->url . "/api/v1/signers/" . $parametros['signer_key'] . "?access_token=" . $this->token;
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										// CURLOPT_CUSTOMREQUEST  => 'GET',
										// CURLOPT_POST           => false,
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_TIMEOUT => 0,
									);

									$response = $this->CurlExec($url, $options);
									if ($response) {
										$retorno['codigo'] = 0;
										$retorno['input'] = 'ok';
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $url;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Erro ao tentar localizar signatario';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'criarsignatario':
									$url = $this->url . "/api/v1/signers?access_token=" . $this->token;
									$dados['signer']['email'] = $parametros['email'];
									$dados['signer']['phone_number'] = $parametros['phone_number'];
									$dados['signer']['auths'] = $parametros['auths'];
									$dados['signer']['name'] = $parametros['name'];
									$dados['signer']['documentation'] = $parametros['documentation'];
									$dados['signer']['birthday'] = $parametros['birthday'];
									$dados['signer']['has_documentation'] = true;
									$dados['signer']['selfie_enabled'] = false;
									$dados['signer']['handwritten_enabled'] = false;
									$dados['signer']['official_document_enabled'] = false;
									$dados['signer']['liveness_enabled'] = false;
									$dados['signer']['facial_biometrics_enabled'] = false;
									$json_param = json_encode($dados);
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_POST => true,
										CURLOPT_POSTFIELDS => $json_param,
										CURLOPT_TIMEOUT => 0,
									);

									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response) {
										if (!isset($response->errors)) {
											$retorno['codigo'] = 0;
											$retorno['input'] = $dados;
											$retorno['output'] = $response;
											$retorno['mensagem'] = 'ok';
										} else {
											$retorno['codigo'] = 1;
											$retorno['input'] = $dados;
											$retorno['output'] = $response;
											$retorno['mensagem'] = $response->errors[0];
										}
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $dados;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sem resposta';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'apagarsignatario':
									$url = $this->url . "documents?access_token=" . $this->token;
									$dados['signer']['email'] = $parametros['email'];
									$dados['signer']['phone_number'] = $parametros['phone_number'];
									$dados['signer']['auths'] = $parametros['auths'];
									$dados['signer']['name'] = $parametros['name'];
									$dados['signer']['documentation'] = $parametros['documentation'];
									$dados['signer']['birthday'] = $parametros['birthday'];
									$dados['signer']['selfie_enabled'] = false;
									$dados['signer']['handwritten_enabled'] = false;
									$dados['signer']['official_document_enabled'] = false;
									$dados['signer']['liveness_enabled'] = false;
									$dados['signer']['facial_biometrics_enabled'] = false;
									$json_param = json_encode($dados);
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_POST => true,
										CURLOPT_POSTFIELDS => $json_param,
										CURLOPT_TIMEOUT => 0,
									);

									$response = $this->CurlExec($this->url, $options);
									if ($response) {
										$retorno['codigo'] = 0;
										$retorno['tipo'] = "sucesso";
										$retorno['mensagem'] = 'ok';
										$retorno['dados'] = $response;
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['tipo'] = "erro";
										$retorno['mensagem'] = 'Sem resposta';
										$retorno['dados'] = $response;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'addsigndocument':
									$url = $this->url . "/api/v1/lists?access_token=" . $this->token;
									$dados['list']['document_key'] = $parametros['document_key'];
									$dados['list']['signer_key'] = $parametros['signer_key'];
									$dados['list']['sign_as'] = $parametros['sign_as'];
									$dados['list']['group'] = $parametros['group'];
									$dados['list']['refusable'] = false;
									$json_param = json_encode($dados);
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_POST => true,
										CURLOPT_POSTFIELDS => $json_param,
										CURLOPT_TIMEOUT => 0,
									);

									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response) {
										if (!isset($response->errors)) {
											$retorno['codigo'] = 0;
											$retorno['input'] = $dados;
											$retorno['output'] = $response;
											$retorno['mensagem'] = 'ok';
										} else {
											$retorno['codigo'] = 1;
											$retorno['input'] = $dados;
											$retorno['output'] = $response;
											$retorno['mensagem'] = $response->errors[0];
										}
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $dados;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sem resposta';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'removesigndocument':
									$url = $this->url . "documents?access_token=" . $this->token;
									$dados['list']['document_key'] = $parametros['document_key'];
									$dados['list']['signer_key'] = $parametros['signer_key'];
									$dados['list']['sign_as'] = $parametros['sign_as'];
									$dados['list']['group'] = $parametros['group'];
									$dados['list']['refusable'] = false;
									$json_param = json_encode($dados);
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_POST => true,
										CURLOPT_POSTFIELDS => $json_param,
										CURLOPT_TIMEOUT => 0,
									);

									$response = $this->CurlExec($this->url, $options);
									if ($response) {
										$retorno['codigo'] = 0;
										$retorno['tipo'] = "sucesso";
										$retorno['mensagem'] = 'ok';
										$retorno['dados'] = $response;
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['tipo'] = "erro";
										$retorno['mensagem'] = 'Sem resposta';
										$retorno['dados'] = $response;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'solicitar_assinatura':
									$url = $this->url . "api/v1/notifications?access_token=" . $this->token;
									$dados['request_signature_key'] = $parametros['request_signature_key'];
									$dados['message'] = (isset($parametros['message'])) ? $parametros['message'] : null;
									$dados['url'] = null;
									$json_param = json_encode($dados);
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json',
											'Accept: application/json'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_POST => true,
										CURLOPT_POSTFIELDS => $json_param,
										CURLOPT_TIMEOUT => 0,
										CURLOPT_HEADER => 1,
									);

									$response = $this->CurlExec($this->url, $options);
									$retorno_api = strripos($response, "HTTP/1.1 202 Accepted");
									if ($retorno_api === false) {
										$retorno['codigo'] = 1;
										$retorno['tipo'] = "erro";
										$retorno['mensagem'] = 'Sem resposta API.';
										$retorno['dados'] = $response;
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 0;
										$retorno['tipo'] = "sucesso";
										$retorno['mensagem'] = 'ok';
										$retorno['dados'] = $response;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
							}
							break;
					}
					break;
				case 'D4S001':
				case 'D4S002':
					switch ($objeto) {
						case 'cofre':
							switch ($acao) {
								case 'listar':
									$url = $this->url . "/safes/?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_TIMEOUT => 0,
									);
									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response && $this->response_http_code == 200) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Nenhum cofre encontrado';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'pastas':
									$url = $this->url . "/folders/" . $parametros['id_cofre'] . "/find?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_TIMEOUT => 0,
									);
									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response && $this->response_http_code == 200) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';

										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Nenhum cofre encontrado';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'listarDocumentos':
									$url = $this->url . "/documents/" . $parametros['id_cofre'] . "/safe";
									if (isset($parametros['id_pasta']) && !empty($parametros['id_pasta'])) {
										$url .= "/" . $parametros['id_pasta'] . "?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									} else {
										$url .= "?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									}
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_TIMEOUT => 0,
									);
									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response && $this->response_http_code == 200) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Nenhum cofre encontrado';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
							}
							break;
						case 'pastas':
							switch ($acao) {
								case 'listar':
									$url = $this->url . "/folders/" . $parametros['id_cofre'] . "/find?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_TIMEOUT => 0,
									);
									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response && is_array($response)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Nenhuma pasta encontrada no cofre informado';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'criar':
									$url = $this->url . "/folders/" . $this->path_root . "/create?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									$postvars['folder_name'] = $parametros['folder_name'];
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_TIMEOUT => 0,
										CURLOPT_POSTFIELDS => json_encode($postvars),
									);
									$response = json_decode($this->CurlExec($this->url, $options));

									if (isset($response->uuid) && !empty($response->uuid)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->message;
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->message;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
							}
							break;
						case 'documento':
							switch ($acao) {
								case 'upload':
									$url = $this->url . "/documents/" . $parametros['id_cofre'] . "/upload";
									// $postvars['file']     = '@'.$parametros['file'];
									$postvars['file'] = new CURLFILE($parametros['file'], $parametros['mime_type']);
									$postvars['uuid_folder'] = $parametros['uuid_folder'];
									$postvars['tokenAPI'] = $this->token;
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: multipart/form-data',
											'charset=utf-8',
											'cryptKey: ' . $this->security_key
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_CUSTOMREQUEST => 'POST',
										CURLOPT_POSTFIELDS => $postvars,
									);
									$response = json_decode($this->CurlExec($this->url, $options));
									if (isset($response->uuid) && !empty($response->uuid)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										if (!isset($response->error)) {
											$response->error = 'Erro no upload do arquivo';
										}
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->error;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'upload_anexo':
									$url = $this->url . "/documents/" . $parametros['key_documento'] . "/uploadslave";
									// $postvars['file']     = '@'.$parametros['file'];
									$postvars['file'] = new CURLFILE($parametros['file'], $parametros['mime_type']);
									// $postvars['uuid_folder'] = $parametros['uuid_folder'];
									$postvars['tokenAPI'] = $this->token;
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: multipart/form-data',
											'charset=utf-8',
											'cryptKey: ' . $this->security_key
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_CUSTOMREQUEST => 'POST',
										CURLOPT_POSTFIELDS => $postvars,
									);

									$response = json_decode($this->CurlExec($this->url, $options));
									if (isset($response) && !empty($response)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->error;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'download':
									$url = $this->url . "/documents/" . $parametros['document_key'] . "/download?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									$postvars['type'] = 'pdf';
									$postvars['language'] = 'pt';
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'Accept' => 'application/json',
											'Content-Type' => 'application/json'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_CUSTOMREQUEST => 'POST',
										CURLOPT_POSTFIELDS => $postvars,
									);

									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response && $this->response_http_code == 200) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->message;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'cancelar':
									$url = $this->url . "/documents/" . $parametros['document_key'] . "/cancel?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									$postvars['comment'] = $parametros['comment'];
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'Accept' => 'application/json',
											'Content-Type' => 'application/json'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_CUSTOMREQUEST => 'POST',
										CURLOPT_POSTFIELDS => $postvars,
									);

									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response && $this->response_http_code == 200) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->message;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'info':
									$url = $this->url . "/documents/" . $parametros['document_key'] . "?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_TIMEOUT => 0,
									);
									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response && is_array($response)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Nenhuma pasta encontrada no cofre informado';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'listarDocumentosPorStatus':
									$url = $this->url . "/documents/" . $parametros['status_doc'] . "/status?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_TIMEOUT => 0,
									);
									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response && is_array($response)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Nenhuma pasta encontrada no cofre informado - listar documento';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'listarDocumentos':
									$url = $this->url . "/documents/?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_TIMEOUT => 0,
									);
									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response && is_array($response)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Nenhuma pasta encontrada no cofre informado';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'listarSignatarios':
									$url = $this->url . "/documents/" . $parametros['document_key'] . "/list?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_TIMEOUT => 0,
									);
									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response && $this->response_http_code == 200) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Erro ao buscar signatarios';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'enviarAssinatura':
									$url = $this->url . "/documents/" . $parametros['document_key'] . "/sendtosigner?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									$postvars['skip_email'] = $parametros['skip_email'];
									$postvars['workflow'] = $parametros['workflow'];
									$postvars['message'] = $parametros['message'];

									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_TIMEOUT => 0,
										CURLOPT_POSTFIELDS => json_encode($postvars),
									);


									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Erro a enviar para assinatura';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'reenviarLinkAssinatura':
									$url = $this->url . "/documents/" . $parametros['document_key'] . "/resend?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									$postvars['email'] = $parametros['email'];
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_RETURNTRANSFER => true,
										CURLOPT_ENCODING => '',
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_MAXREDIRS => 10,
										CURLOPT_TIMEOUT => 0,
										CURLOPT_FOLLOWLOCATION => true,
										CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
										CURLOPT_CUSTOMREQUEST => 'POST',
										CURLOPT_POSTFIELDS => $postvars,
									);
									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response && $this->response_http_code == 200) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->message;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'cadastrarWebhook':
									$url = $this->url . "/documents/" . $parametros['document_key'] . "/webhooks?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									// $url_webhook = "http://projetos4.local/ws_erpcmsw.php?target=tarifador&objeto=crystal&evento=status_assinatura";
									// $url_webhook = "http://tarifa-h.cmsw.com/ws_erpcmsw.php?target=tarifador&objeto=crystal&evento=status_assinatura";
									$url_webhook = "https://erp.cmsw.com/ws.php?target=tarifador&objeto=webhook&evento=status_assinatura";

									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_RETURNTRANSFER => true,
										CURLOPT_ENCODING => '',
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_MAXREDIRS => 10,
										CURLOPT_TIMEOUT => 30,
										CURLOPT_FOLLOWLOCATION => true,
										CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
										CURLOPT_CUSTOMREQUEST => 'POST',
										CURLOPT_POSTFIELDS => "{\"url\":\"" . $url_webhook . "\"}",
										CURLOPT_HTTPHEADER => [
											"accept: application/json",
											"content-type: application/json"
										],
									);


									$response = json_decode($this->CurlExec($url, $options));
									if ($response && $this->response_http_code == 200) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->message;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case 'listWebhook':
									$url = $this->url . "/documents/" . $parametros['document_key'] . "/webhooks?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_RETURNTRANSFER => false,
										CURLOPT_ENCODING => '',
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_MAXREDIRS => 10,
										CURLOPT_TIMEOUT => 30,
										CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
										CURLOPT_CUSTOMREQUEST => 'GET',
										CURLOPT_HTTPHEADER => [
											"accept: application/json"
										],
									);

									$response = json_decode($this->CurlExec($url, $options));
									if ($response && $this->response_http_code == 200) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->message;
										throw new Exception(json_encode($retorno), 1);
									}
									break;
							}
							break;
						case 'signatario':
							switch ($acao) {
								case 'criar':
									$url = $this->url . "/documents/" . $parametros['document_key'] . "/createlist?tokenAPI=" . $this->token . "&cryptKey=" . $this->security_key;
									$postvars['signers'] = $parametros['signers'];
									$options = array(
										CURLOPT_URL => $url,
										CURLOPT_HTTPHEADER => array(
											'ContenT-Type: application/json; charset=utf-8'
										),
										CURLOPT_RETURNTRANSFER => 1,
										CURLOPT_SSL_VERIFYPEER => false,
										CURLOPT_TIMEOUT => 0,
										CURLOPT_POSTFIELDS => json_encode($postvars),
									);
									$response = json_decode($this->CurlExec($this->url, $options));
									if ($response && $this->response_http_code == '200') {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = (isset($response->message)) ? $response->message : 'Erro ao criar lista de signatarios - Api';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
							}
							break;
					}
					break;
				case 'PIPE001':
					switch ($objeto) {
						case 'pipedrive':
							switch ($acao) {
								case 'pipelines10':
									$url = $this->url . 'pipelines/10/deals?api_token=' . $this->token;
									$dados = json_decode($this->CurlExec($url));
									if (isset($dados->success) && !empty($dados->data)) {
										$retorno['codigo'] = 0;
										$retorno['tipo'] = 'success';
										$retorno['mensagem'] = 'Dados retornado com sucesso';
										$retorno['dados'] = $dados->data;
									} else {
										$retorno['codigo'] = 1;
										$retorno['tipo'] = 'danger';
										$retorno['mensagem'] = 'Nenhum Pipeline encontrado - API';
										$retorno['dados'] = $dados;
									}
									return json_encode($retorno);
									break;
								case 'pipelines11':
									$url = $this->url . 'pipelines/11/deals?api_token=' . $this->token;
									$dados = json_decode($this->CurlExec($url));
									if (isset($dados->success) && !empty($dados->data)) {
										$retorno['codigo'] = 0;
										$retorno['tipo'] = 'success';
										$retorno['mensagem'] = 'Dados retornado com sucesso';
										$retorno['dados'] = $dados->data;
									} else {
										$retorno['codigo'] = 1;
										$retorno['tipo'] = 'danger';
										$retorno['mensagem'] = 'Nenhum Pipeline encontrado - API';
										$retorno['dados'] = $dados;
									}
									return json_encode($retorno);
									break;
							}
							break;
					}
					break;
				case 'TEAM001':
					switch ($objeto) {
						case 'token':
							switch ($acao) {
								case 'getTokenApplication':
									$url = 'https://login.microsoftonline.com/07c74f1b-9c61-4995-807a-c7942b88271b/oauth2/v2.0/token';
									// $param_curl[CURLOPT_HTTPHEADER] = array(
									// 	'x-api-key: '.$this->key,
									// 	'transaction-security-token: '.$parametros['transaction_security'],
									// 	'Content-Type: application/json',
									// 	'Authorization: Bearer '.$this->token
									// );
									$postvars = [
										"client_id" => '617e5547-f091-4732-8097-7c5458b00cb2',
										"scope" => 'https://graph.microsoft.com/.default',
										"client_secret" => 'Hhx8Q~4Wh2_qJmsonJRFaF_xt..GqqCPjOFDlcr6',
										"grant_type" => 'client_credentials',
									];
									$param_curl[CURLOPT_SSL_VERIFYPEER] = false;
									$param_curl[CURLOPT_RETURNTRANSFER] = true;
									$param_curl[CURLOPT_ENCODING] = '';
									$param_curl[CURLOPT_MAXREDIRS] = 10;
									$param_curl[CURLOPT_TIMEOUT] = 0;
									$param_curl[CURLOPT_FOLLOWLOCATION] = true;
									$param_curl[CURLOPT_HTTP_VERSION] = CURL_HTTP_VERSION_1_1;
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'GET';
									$param_curl[CURLOPT_VERBOSE] = true;
									$param_curl[CURLOPT_POSTFIELDS] = $postvars;
									$param_curl[CURLOPT_URL] = $url;
									$response = $this->CurlExec($url, $param_curl);
									// echo 'Iniciando envio de pix por chave Cartos '.$this->controller->data_hora_atual->format('Y-m-d H:i:s').'<br>';
									$response = json_decode($response);
									if ($response && !isset($response->error)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->error_description;
									}
									throw new Exception(json_encode($retorno), 1);
									break;
								case 'getTokenUser':
									$url = 'https://login.microsoftonline.com/organizations/oauth2/v2.0/token';
									$postvars = [
										"client_id" => '617e5547-f091-4732-8097-7c5458b00cb2',
										"scope" => 'ChannelMessage.Send user.read openid profile offline_access',
										"client_secret" => 'Hhx8Q~4Wh2_qJmsonJRFaF_xt..GqqCPjOFDlcr6',
										// "username"		=> 'julio.gomes@cmsw.com',
										// "password"		=> 'Ju@011261',
										"username" => 'integracao.tarifador@cmsw.com',
										"password" => 'F^737657141448op',
										"grant_type" => 'password',
									];
									$param_curl[CURLOPT_SSL_VERIFYPEER] = false;
									$param_curl[CURLOPT_RETURNTRANSFER] = true;
									$param_curl[CURLOPT_ENCODING] = '';
									$param_curl[CURLOPT_MAXREDIRS] = 10;
									$param_curl[CURLOPT_TIMEOUT] = 0;
									$param_curl[CURLOPT_FOLLOWLOCATION] = true;
									$param_curl[CURLOPT_HTTP_VERSION] = CURL_HTTP_VERSION_1_1;
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'POST';
									$param_curl[CURLOPT_VERBOSE] = true;
									$param_curl[CURLOPT_POSTFIELDS] = $postvars;
									$param_curl[CURLOPT_URL] = $url;
									$response = $this->CurlExec($url, $param_curl);
									// echo 'Iniciando envio de pix por chave Cartos '.$this->controller->data_hora_atual->format('Y-m-d H:i:s').'<br>';
									$response = json_decode($response);
									if ($response && !isset($response->error)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->error_description;
									}
									throw new Exception(json_encode($retorno), 1);
									break;
							}
							break;
						case 'chat':
							switch ($acao) {
								case '	':
									$url = $this->url . 'chats/';
									$param_curl[CURLOPT_HTTPHEADER] = array(
										'Content-Type: application/json',
										'Authorization: Bearer ' . $parametros['token']
									);
									$members['chatType'] = 'group';
									foreach ($parametros['members'] as $key => $value) {
										$members['members'][$key]['@odata.type'] = "#microsoft.graph.aadUserConversationMember";
										$members['members'][$key]['roles'][] = "owner";
										$members['members'][$key]['user@odata.bind'] = "https://graph.microsoft.com/v1.0/users('$value')";
									}
									$param_curl[CURLOPT_POSTFIELDS] = json_encode($members);
									$param_curl[CURLOPT_SSL_VERIFYPEER] = false;
									$param_curl[CURLOPT_RETURNTRANSFER] = true;
									$param_curl[CURLOPT_ENCODING] = '';
									$param_curl[CURLOPT_MAXREDIRS] = 10;
									$param_curl[CURLOPT_TIMEOUT] = 0;
									$param_curl[CURLOPT_FOLLOWLOCATION] = true;
									$param_curl[CURLOPT_HTTP_VERSION] = CURL_HTTP_VERSION_1_1;
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'POST';
									$param_curl[CURLOPT_URL] = $url;
									$response = $this->CurlExec($url, $param_curl);
									$response = json_decode($response);
									if (!isset($response->error)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->error->message;
									}
									throw new Exception(json_encode($retorno), 1);
									break;
								case 'createOne':
									$url = $this->url . 'chats/';
									$param_curl[CURLOPT_HTTPHEADER] = array(
										'Content-Type: application/json',
										'Authorization: Bearer ' . $parametros['token']
									);
									$members['chatType'] = 'oneOnOne';
									$members['members'][0]['@odata.type'] = "#microsoft.graph.aadUserConversationMember";
									$members['members'][0]['roles'][] = "owner";
									$members['members'][0]['user@odata.bind'] = "https://graph.microsoft.com/v1.0/users('integracao.tarifador@cmsw.com')";

									$members['members'][1]['@odata.type'] = "#microsoft.graph.aadUserConversationMember";
									$members['members'][1]['roles'][] = "owner";
									$members['members'][1]['user@odata.bind'] = "https://graph.microsoft.com/v1.0/users('" . $parametros['members'][1] . "')";

									$param_curl[CURLOPT_POSTFIELDS] = json_encode($members);
									$param_curl[CURLOPT_SSL_VERIFYPEER] = false;
									$param_curl[CURLOPT_RETURNTRANSFER] = true;
									$param_curl[CURLOPT_ENCODING] = '';
									$param_curl[CURLOPT_MAXREDIRS] = 10;
									$param_curl[CURLOPT_TIMEOUT] = 0;
									$param_curl[CURLOPT_FOLLOWLOCATION] = true;
									$param_curl[CURLOPT_HTTP_VERSION] = CURL_HTTP_VERSION_1_1;
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'POST';
									$param_curl[CURLOPT_URL] = $url;
									$response = $this->CurlExec($url, $param_curl);
									$response = json_decode($response);
									if (!isset($response->error)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->error->message;
									}
									throw new Exception(json_encode($retorno), 1);
									break;
								case 'sendMessageChat':
									$url = $this->url . 'chats/' . $parametros['chat_id'] . '/messages';
									if ($parametros['isHMTL'] == true) {
										$mensagem = $parametros['mensagem'];
										$postvars = json_encode($mensagem);
									} else {
										$mensagem['body']['content'] = $parametros['mensagem'];
										$postvars = json_encode($mensagem);
									}
									$param_curl[CURLOPT_HTTPHEADER] = array(
										'Content-Type: application/json',
										'Authorization: Bearer ' . $parametros['token']
									);
									$param_curl[CURLOPT_SSL_VERIFYPEER] = false;
									$param_curl[CURLOPT_RETURNTRANSFER] = true;
									$param_curl[CURLOPT_ENCODING] = '';
									$param_curl[CURLOPT_MAXREDIRS] = 10;
									$param_curl[CURLOPT_TIMEOUT] = 0;
									$param_curl[CURLOPT_FOLLOWLOCATION] = true;
									$param_curl[CURLOPT_HTTP_VERSION] = CURL_HTTP_VERSION_1_1;
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'POST';
									$param_curl[CURLOPT_POSTFIELDS] = $postvars;
									$param_curl[CURLOPT_URL] = $url;
									$response = $this->CurlExec($url, $param_curl);
									$response = json_decode($response);
									if (!isset($response->error) || empty($response->error)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->error->message;
									}
									throw new Exception(json_encode($retorno), 1);
									break;
								case 'sendMessageChannel':
									$url = $this->url . 'teams/' . $parametros['id_grupo'] . '/channels/' . $parametros['id_canal'] . '/messages';
									$param_curl[CURLOPT_HTTPHEADER] = array(
										'Content-Type: application/json',
										'Authorization: Bearer ' . $parametros['token']
									);
									$postvar['body']['content'] = $parametros['mensagem'];
									$param_curl[CURLOPT_POSTFIELDS] = json_encode($postvar);
									$param_curl[CURLOPT_SSL_VERIFYPEER] = false;
									$param_curl[CURLOPT_RETURNTRANSFER] = true;
									$param_curl[CURLOPT_ENCODING] = '';
									$param_curl[CURLOPT_MAXREDIRS] = 10;
									$param_curl[CURLOPT_TIMEOUT] = 0;
									$param_curl[CURLOPT_FOLLOWLOCATION] = true;
									$param_curl[CURLOPT_HTTP_VERSION] = CURL_HTTP_VERSION_1_1;
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'POST';
									$param_curl[CURLOPT_URL] = $url;
									$response = $this->CurlExec($url, $param_curl);
									$response = json_decode($response);
									if (!isset($response->error) || empty($response->error)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
									} else {
										if ($response->error->code == 'Forbidden') {
											$msg_erro = json_decode($response->error->message);
											$sub_msg = json_decode($msg_erro->message);
											$retorno['codigo'] = 1;
											$retorno['input'] = $parametros;
											$retorno['output'] = $response;
											$retorno['mensagem'] = $sub_msg->details;
										} else {
											$retorno['codigo'] = 1;
											$retorno['input'] = $parametros;
											$retorno['output'] = $response;
											$retorno['mensagem'] = $response->error->message;
										}
									}
									throw new Exception(json_encode($retorno), 1);
									break;
								case 'sendMessageWebHook':
									$url = $parametros['webhook'];
									$param_curl[CURLOPT_HTTPHEADER] = array(
										'Content-Type: application/json',
									);
									$postvar['text'] = $parametros['mensagem'];
									$param_curl[CURLOPT_POSTFIELDS] = json_encode($postvar);
									$param_curl[CURLOPT_SSL_VERIFYPEER] = false;
									$param_curl[CURLOPT_RETURNTRANSFER] = true;
									$param_curl[CURLOPT_ENCODING] = '';
									$param_curl[CURLOPT_MAXREDIRS] = 10;
									$param_curl[CURLOPT_TIMEOUT] = 0;
									$param_curl[CURLOPT_FOLLOWLOCATION] = true;
									$param_curl[CURLOPT_HTTP_VERSION] = CURL_HTTP_VERSION_1_1;
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'POST';
									$param_curl[CURLOPT_URL] = $url;
									$response = $this->CurlExec($url, $param_curl);
									if ($response == 1) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response;
									}
									throw new Exception(json_encode($retorno), 1);
									break;
							}
							break;
						case 'user':
							switch ($acao) {
								case 'me':
									$url = $this->url . 'me/photo';
									$param_curl[CURLOPT_HTTPHEADER] = array(
										'Content-Type: application/json',
										'Authorization: Bearer ' . $parametros['token']
									);
									$param_curl[CURLOPT_SSL_VERIFYPEER] = false;
									$param_curl[CURLOPT_RETURNTRANSFER] = true;
									$param_curl[CURLOPT_ENCODING] = '';
									$param_curl[CURLOPT_MAXREDIRS] = 10;
									$param_curl[CURLOPT_TIMEOUT] = 0;
									$param_curl[CURLOPT_FOLLOWLOCATION] = true;
									$param_curl[CURLOPT_HTTP_VERSION] = CURL_HTTP_VERSION_1_1;
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'GET';
									$param_curl[CURLOPT_URL] = $url;
									$response = $this->CurlExec($url, $param_curl);
									$response = json_decode($response);
									if (!isset($response->error)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->error->message;
									}
									throw new Exception(json_encode($retorno), 1);
									break;
								case 'getByEmail':
									$url = $this->url . 'users/' . $parametros['email'];
									$param_curl[CURLOPT_HTTPHEADER] = array(
										'Content-Type: application/json',
										'Authorization: Bearer ' . $parametros['token']
									);
									$param_curl[CURLOPT_SSL_VERIFYPEER] = false;
									$param_curl[CURLOPT_RETURNTRANSFER] = true;
									$param_curl[CURLOPT_ENCODING] = '';
									$param_curl[CURLOPT_MAXREDIRS] = 10;
									$param_curl[CURLOPT_TIMEOUT] = 0;
									$param_curl[CURLOPT_FOLLOWLOCATION] = true;
									$param_curl[CURLOPT_HTTP_VERSION] = CURL_HTTP_VERSION_1_1;
									$param_curl[CURLOPT_CUSTOMREQUEST] = 'GET';
									$param_curl[CURLOPT_URL] = $url;
									$response = $this->CurlExec($url, $param_curl);
									$response = json_decode($response);
									if (!isset($response->error)) {
										$retorno['codigo'] = 0;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = 'Sucesso';
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response;
										$retorno['mensagem'] = $response->error->message;
									}
									throw new Exception(json_encode($retorno), 1);
									break;
							}
							break;
					}
					break;
				case 'BING001':
					switch ($objeto) {
						case 'maps':
							switch ($acao) {
								case 'calcularKm':
									define('KEY', 'eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6IjI3MmNiNmU5ZWIwZDQ5MTQ5N2MzZTQ4MjU5NWI5MDQ5IiwiaCI6Im11cm11cjY0In0=');
									define('URL_LAT_LONG', 'https://api.openrouteservice.org/geocode/search?');
									define('URL_ROTA', 'https://api.openrouteservice.org/v2/directions/driving-car?');
									//DESCONTINUADA API BING
									// 	define( 'URL_BING',      'http://dev.virtualearth.net/REST/v1/Routes');
									// 	define( 'KEY_BING', 	 'AgADLWiIdsrnkuaB4wrSI_Y0xkevyW8hFMCSEe0Mkp2z6I8xFiQok-idNLEGMDQu');
									// $origem = $parametros['numero_origem'] . ' ' . $parametros['endereco_origem'] . ', ' . $parametros['bairro_origem'] . ', ' . $parametros['cidade_origem'] . ' - ' . $parametros['estado_origem'] . ', ' . $parametros['cep_origem'] . ', Brasil';
									$origem = $parametros['endereco_origem'] . ',' . $parametros['numero_origem'] . ',' . $parametros['cidade_origem'] . ',' . $parametros['estado_origem'] . ', Brasil';
									$destino = $parametros['endereco_destino'] . ',' . $parametros['numero_destino'] . ',' . $parametros['cidade_destino'] . ',' . $parametros['estado_destino'] . ', Brasil';
									// $destino = $parametros['numero_destino'] . ' ' . $parametros['endereco_destino'] . ', ' . $parametros['bairro_destino'] . ', ' . $parametros['cidade_destino'] . ' - ' . $parametros['estado_destino'] . ', ' . $parametros['cep_destino'] . ', Brasil';
									$url_origem = URL_LAT_LONG . http_build_query([
										"api_key" => KEY,
										"text" => $origem,
										"size" => 1
									]);
									$response_origem = file_get_contents($url_origem);
									$data_origem = json_decode($response_origem, true);
									if (!empty($data_origem['features'][0]['geometry']['coordinates'])) {

										$lon_origem = $data_origem['features'][0]['geometry']['coordinates'][0];
										$lat_origem = $data_origem['features'][0]['geometry']['coordinates'][1];
										$origem = [
											'longitude' => $lon_origem,
											'latitude' => $lat_origem
										];

										$url_destino = URL_LAT_LONG . http_build_query([
											"api_key" => KEY,
											"text" => $destino,
											"size" => 1
										]);

										$response_destino = file_get_contents($url_destino);
										$data_destino = json_decode($response_destino, true);
										if (!empty($data_destino['features'][0]['geometry']['coordinates'])) {
											$lon_destino = $data_destino['features'][0]['geometry']['coordinates'][0];
											$lat_destino = $data_destino['features'][0]['geometry']['coordinates'][1];
											$destino = [
												'longitude' => $lon_destino,
												'latitude' => $lat_destino
											];

											$url_rota = URL_ROTA . 'api_key=' . KEY . '&start=' . $origem['longitude'] . ',' . $origem['latitude'] . '&end=' . $destino['longitude'] . ',' . $destino['latitude'] . '&size=1';

											$response_rota = file_get_contents($url_rota);
											$data_rota = json_decode($response_rota, true);
											$res = $data_rota['features'][0]['properties']['segments'][0]['distance'];
											if (empty($res) || !is_numeric($res) || !$res) {
												$retorno['codigo'] = 1;
												$retorno['input'] = $parametros;
												$retorno['output'] = $response_destino;
												$retorno['mensagem'] = 'Erro ao calular rota';
												throw new Exception(json_encode($retorno), 1);
											}

											return $res / 1000;
										} else {
											$retorno['codigo'] = 1;
											$retorno['input'] = $parametros;
											$retorno['output'] = $response_destino;
											$retorno['mensagem'] = 'Erro ao calular rota';
											throw new Exception(json_encode($retorno), 1);
										}

									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = $response_origem;
										$retorno['mensagem'] = 'Erro ao calular rota';
										throw new Exception(json_encode($retorno), 1);
									}

									$distancia = 0;

									if (1 == 1) {
										$retorno['codigo'] = 0;
										$retorno['output'] = '';
										$retorno['mensagem'] = 'Sucesso';
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $parametros;
										$retorno['output'] = '';
										$retorno['mensagem'] = 'Erro ao calular rota';
									}
									throw new Exception(json_encode($retorno), 1);
									break;
							}
							break;
					}
					break;
			}
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	function CurlExec($url, $param = null)
	{
		//GET request
		$ch = curl_init();
		if ($param) {
			curl_setopt_array($ch, $param);
		} else {
			curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0");
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		}
		$output = curl_exec($ch);
		$this->info_curl = curl_getinfo($ch);
		$this->response_http_code = $this->info_curl['http_code'];
		curl_close($ch);
		if (!empty($this->codigo)) {
			$prefix_name = $this->codigo;
		} else {
			$prefix_name = 'api_exec';
		}
		$file_name = ABSPATH . '/logs/' . strtolower($prefix_name) . '_' . $this->data_atual->format('Ymd') . '.log';
		$fp = fopen($file_name, 'a+');
		fwrite($fp, $output . "\n");
		fclose($fp);
		return $output;
	}

	function removeSoapEnvelope($xml)
	{
		$return = null;
		if ($xml === false) {
			echo "Failed to load XML: ";
			foreach (libxml_get_errors() as $error) {
				$return = $error->message;
			}
		} else {
			// Search for the Body element (this is in the SOAP-ENV namespace)
			$xml->registerXPathNamespace("soap:Envelope", "http://schemas.xmlsoap.org/soap/envelope/");
			$bodyBlock = $xml->xpath("//soap:Body")[0];
			// If the content does not have a namespace, extract the children from the default namespace
			$body = $bodyBlock->children();
			if ($body) {
				$return = $body;
			} else {
				$return = $error->message;
			}
			// You can now access the content.
			// echo $body->BodyContent.PHP_EOL;
			// echo $body->OtherContent;
		}
		return $return;
	}
}