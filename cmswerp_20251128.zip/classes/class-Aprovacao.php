<?php

	/**
	 * Luciano Damasceno
	 * 21/11/2025
	 */
	class Aprovacao{
		private
			$controller,
			$id_user_sesssao,
			$aprovadoresAtuais = [],
			$grupo,
			$model_aprovacoes;

		public $grupos;
		function __construct($controller, $id_origem, $id_proposta)
		{
			$this->controller = $controller;
			$this->id_user_sesssao = $_SESSION['cmswerp']['userdata']->id;
			$this->model_aprovacoes = $controller->load_model('aprovacoes/aprovacoes', true);

			$this->setObjetoFluxo($id_origem, $id_proposta);
			$this->setAprovadoresAtuais();
		}

		private function setObjetoFluxo($id_origem, $id_proposta)
		{
			$gruposNaoOrganizados = json_decode($this->model_aprovacoes->getGrupos($id_origem, $id_proposta));
			if (!$gruposNaoOrganizados) {
				return false;
			}

			$this->grupo = $gruposNaoOrganizados[0]->id_grupo;


			foreach ($gruposNaoOrganizados as $key => $value) {
				$this->grupos[$value->ordem][] = $value;
			};

			foreach ($this->grupos as $k => $grupo) {
				$aprovado = false;
				if (count($grupo) == 1) {
					$this->grupos[$k]['aprovacao'] = $grupo[0]->status ? $grupo[0]->status : 'aguardando';
					continue;
				}

				$aprovado  = 0;
				$reprovado = 0;
				$pendente  = 0;

				foreach ($grupo as $key => $value) {
					if ($value->status == 'a') {
						$aprovado++;
					} elseif ($value->status == 'r') {
						$reprovado++;
					} else if ($value->status == 'p') {
						$pendente++;
					}
				}

				$this->grupos[$k]['aprovacao'] = 'aguardando';

				if ($aprovado || $reprovado || $pendente) {
					if ($grupo[0]->e_ou == 'e') {
						if ($aprovado == count($grupo)) {
							$this->grupos[$k]['aprovacao'] = 'aprovado';
						} else if ($reprovado > 0) {
							$this->grupos[$k]['aprovacao'] = 'reprovado';
						} else {
							$this->grupos[$k]['aprovacao'] = 'pendente';
						}
					} else if ($grupo[0]->e_ou == 'ou') {
						$this->grupos[$k]['aprovacao'] = $aprovado >= 1;
						if ($aprovado >= 1) {
							$this->grupos[$k]['aprovacao'] = 'aprovado';
						} else if ($aprovado == 0 && count($grupo) == $reprovado) {
							$this->grupos[$k]['aprovacao'] = 'reprovado';
						} else {
							$this->grupos[$k]['aprovacao'] = 'pendente';
						}
					} else {
						// if($aprovado == count($grupo)){
						// 	$this->grupos[$k]['aprovacao'] = 'aprovado';
						// }else if($reprovado > 0){
						// 	$this->grupos[$k]['aprovacao'] = 'reprovado';
						// }else if($pendente > 0){
						// 	$this->grupos[$k]['aprovacao'] = 'pendente';
						// }
					}
				}
			};

			ksort($this->grupos);
		}

		private function setAprovadoresAtuais()
		{
			foreach ($this->grupos as $key => $value) {
				if ($value['aprovacao'] == 'pendente') {
					foreach ($value as $k => $v) {
						if (gettype($v) == 'object') {
							if ($v->status == 'p') {
								$this->aprovadoresAtuais[] = $v->id_usuario;
							}
						}
					}
				}
			}
		}
		public function getGrupos()
		{
			return $this->grupos;
		}

		public function getAprovadores()
		{
			return $this->aprovadoresAtuais;
		}

		public function ordemFluxoAprovacao($id_contrato = null, $id_proposta = null)
		{
			$contrato = json_decode($this->controller->modelo->getIfContrato($id_contrato, $id_proposta));
			if (isset($contrato) && !empty($contrato)) {
				$status = json_decode($this->controller->modelo->allFluxoAprovacao("minuta", $contrato[0]->id));
				if (isset($status) && is_array($status)) {
					foreach ($status as $key => $value) {
						if ($value->status == 1) {
							$ordem = $value->ordem;
						}
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
			if (isset($ordem)) {
				return $ordem;
			} else {
				return false;
			}
		}

		public function criaProximaAprovacao($data)
		{
			$this->model_aprovacoes->setTable('grupo_aprovacoes');
			$proximosAprovadores = $this->obtemProximosAprovadores();

			if (empty($proximosAprovadores)) {
				return [];
			}

			foreach ($proximosAprovadores as $aprovador) {
				$nova_aprovacao = [
					'id_grupo' => $this->grupo,
					'id_usuario' => $aprovador,
					'id_item' => $data['id'],
					'status' => 'p',
					'justificativa' => ''
				];
				// $this->model_aprovacoes->save($nova_aprovacao);
			}
		}

		private function obtemProximosAprovadores()
		{
			$proximosAprovadores = [];

			foreach ($this->grupos as $key => $value) {
				if ($key == 0) continue;
				if ($proximosAprovadores) break;

				if ($value['aprovacao' == 'aguardando']) {
					foreach ($value as $k => $v) {
						if (gettype($v) == 'object') {
							$proximosAprovadores[] = $v->id_usuario;
						}
					}
				}
			}
			return $proximosAprovadores;
		}
	}
