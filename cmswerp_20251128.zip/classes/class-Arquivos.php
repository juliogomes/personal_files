<?php
	class Arquivos extends Main{
		protected
			$id_origem,
			$empresa_origem,
			$origem,
			$tipo,
			$modalidade,
			$nome,
			$path,
			$data_envio,
			$data_retorno,
			$status_envio,
			$status_retorno,
			$info_retorno,
			$mensagem;

		function __construct( $controller = null, $param = null ){
			parent::__construct( $controller );
			$this->modelo = $this->controller->load_model('arquivos/arquivos', true);
		}

		function saveDb( $parametros, $id = null ){
			$this->modelo->setTable('envios_arquivos');
			return $this->modelo->save( $parametros, $id );
		}
	}