<?php
    /**
    * Caio Freitas
    * 20/07/2022
    * Classe para aprovação em etapas da barra de progresso
    */    
    class Assinatura extends Ged{
        protected
            $tipos_assinatura,
            $ordem_assinatura,
            $documento,
            $modelo_proposta;
        public
            $output,
            $erro,
            $info;
        function __construct($controller){
            parent::__construct($controller);
            $this->modelo_proposta  = $this->controller->load_model('propostas/propostas', true);
        }

        function getOutPut(){
            return $this->output;
        }

        function getErro(){
            return $this->erro;
        }

        function getInfo(){
            return $this->info;
        }

        function ordemAssinatura( $id_objeto = null, $id_empresa = null ){
            $assinatura['cliente'] = json_decode($this->modelo_proposta->getContatoSign( 'minuta', $id_objeto ) );
            if(isset($assinatura['cliente']) && is_array($assinatura['cliente'])){
                $contador = 0;
                foreach ($assinatura['cliente'] as $key => $value) {
                    if( strtoupper($value->tipo_contato) == "JURIDICO" ){
                        $ordem[$contador] = $value;  
                        $contador++;                  
                    }                
                }  
                foreach ($assinatura['cliente'] as $key => $value) {
                    if( strtoupper($value->tipo_contato) == "RESPONSAVEL_LEGAL" ){
                        $ordem[$contador] = $value;  
                        $contador++;                  
                    }                
                }  
                foreach ($assinatura['cliente'] as $key => $value) {
                    if( strtoupper($value->tipo_contato) == "TESTEMUNHA" || strtoupper($value->tipo_contato) == "TESTEMUNHA_2"
                    ){
                        $ordem[$contador] = $value;  
                        $contador++;                  
                    }                
                }         
            }           
        
            $assinatura['cm'] = json_decode( $this->modelo_proposta->getContatoSign( "sign_cm", null, null, true ) );
            if( isset( $assinatura['cm'] ) && is_array( $assinatura['cm'] ) ){
                foreach ( $assinatura['cm'] as $key => $value ) {
                    $value->nome        = strtoupper($value->nome);
                    $value->cargo_setor = strtoupper($value->cargo_setor);
                    $contador           = count($ordem);      
                    if( strtoupper( $value->tipo_contato ) == "JURIDICO" ){
                        $value->tipo_contato = strtoupper( $value->tipo_contato );
                        $ordem[$contador] = $value;    
                        $juridico[] = $value;                
                    }else{
                        if( strtoupper( $value->tipo_contato ) == "RESPONSAVEL_LEGAL"){
                            $value->tipo_contato = str_replace("_"," ",strtoupper($value->tipo_contato));
                            if( $value->id_cm == $id_empresa ){
                                $responsavel_legal[] = $value;
                            }
                        }else{
                            if( strtoupper( $value->tipo_contato ) == "TESTEMUNHA" ){
                                $value->tipo_contato = strtoupper($value->tipo_contato);
                                $testemunhas_cm[] = $value;   
                            }
                        }                    
                    }                         
                }
            
                if( !isset( $juridico ) || empty( $juridico ) ){
                    if( isset( $testemunhas_cm ) && is_array( $testemunhas_cm ) ){
                        $contador_testemunha = 0;
                        foreach( $testemunhas_cm as $key => $value ) {
                            $contador = count( $ordem );  
                            if( $contador_testemunha == 0 ){
                                $ordem[$contador] = $value; 
                            }
                            $contador_testemunha++;
                        }
                    }                
                }
                
                if( isset( $responsavel_legal ) && !empty( $responsavel_legal ) ){
                    $contador = count( $ordem ); 
                    $ordem[ $contador ] = $responsavel_legal[0];
                }
            }
            return $ordem;
        }

        function getAssinatura( $ordem_assinatura = null, $ged_assinatura = null ){
            if(isset($ordem_assinatura) && isset($ged_assinatura)){
                foreach ($ordem_assinatura as $key_ordem => $value_ordem) {                
                    foreach ($ged_assinatura as $key_ass => $value_ass) {
                        if($value_ordem->id_usuario == $value_ass->id_usuario && $value_ass->status == "assinado"){
                            $assinado[$value_ordem->id_usuario] = true;
                        }
                    }
                }
            }
            return $assinado;
        }
    }