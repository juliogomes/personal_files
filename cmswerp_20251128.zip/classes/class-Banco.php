<?php

class Banco{
	public  $data_atual;
	protected $model_banco, $controller, $model_conta_bancaria, $boleto_model, $arquivo_model, $codigo_banco, $nome_banco, $error, $error_info, $tipo_inscricao_banco, $cnpj_banco;
	function __construct($controller, $cliente = null){
		$this->data_atual = $controller->data_hora_atual;
		$this->controller = $controller;
		
		// debug_print_backtrace();
		$this->arquivo_model        = $this->controller->load_model('arquivos/arquivos', true);
		$this->model_banco          = $this->controller->load_model('banco/banco', true);
		$this->model_conta_bancaria = $this->controller->load_model('contabancaria/contabancaria', true);
		$this->boleto_model         = $this->controller->load_model('boleto/boleto', true);
		
		if(is_array($cliente)){
			$cliente = convertToObject($cliente);
		}

		if($cliente){
			$this->setBanco($cliente);
		}
	}

	function getBancoByCodigo($codigo){
		return $this->model_banco->getBancoByCodigo($codigo);
	}

	function getBanco(){
		return $this->model_banco->getBanco();
	}

	function getBancoByNome($nome){
		return $this->model_banco->getBancoByNome($nome);
	}

	function setBanco($cliente){
		if(is_array($cliente)){
			$cliente = convertToObject($cliente);
		}
		$this->codigo_banco = $cliente->codigo_banco;
		$this->nome_banco   = $cliente->nome_banco;
		$this->setTipoIncricaoBanco($cliente->tipo_inscricao);
		$this->setCnpjBanco($cliente->cnpj_cpf);

	}

	function setTipoIncricaoBanco($tipo_inscricao_banco){
		$this->tipo_inscricao_banco = $tipo_inscricao_banco;
	}

	function getTipoIncricaoBanco(){
		return $this->tipo_inscricao_banco;
	}

	function setCnpjBanco($cnpj_banco){
		$this->cnpj_banco = $cnpj_banco;
	}

	function getCnpjBanco(){
		return $this->cnpj_banco;
	}

	function setNomeBanco($nome_banco){
		$this->nome_banco = $nome_banco;
	}

	function getNomeBanco(){
		return $this->nome_banco;
	}

	// function getBanco(){
	// 	return $this;
	// }

	function setError($error = false){
		$this->error = $error;
	}

	function getError(){
		return $this->error;
	}

	function setErrorInfo($mensagem, $tipo_error = 'erro'){
		if($tipo_error = 'erro'){
			$json['codigo'] = 1;
			$json['tipo']   = 'error';
		}elseif($tipo_error = 'erro'){
			$json['codigo'] = 2;
			$json['tipo']   = 'warning';
		}
		
		$json['mensagem'] = $mensagem;
		$this->error_info = json_encode($json, 1);
	}

	function getErrorInfo(){
		return $this->error_info;
	}

	function __destruct()
	{
		$this->controller    = null;
	 	$this->model_arquivo = null;
	}
}