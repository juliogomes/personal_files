<?php
require_once ABSPATH.'/libs/openboleto/vendor/autoload.php';
require_once ABSPATH.'/libs/h2p/vendor/autoload.php';
require_once ABSPATH.'/libs/mpdf/vendor/autoload.php';
require_once ABSPATH.'/libs/remessa-bradesco/src/Funcoes.php';
require_once ABSPATH.'/libs/remessa-bradesco/src/HeaderLabel.php';
require_once ABSPATH.'/libs/remessa-bradesco/src/Arquivo.php';
require_once ABSPATH.'/libs/remessa-bradesco/src/Detalhes.php';
require_once ABSPATH.'/libs/remessa-bradesco/src/Trailler.php';

class Boleto extends Banco{
	private $now;
	function __construct()
	{
		parent::__construct();
		// $this->now = getDataAtual();	
	}

	function criarRemessa($dados){
		//$this->tratarDados($dados);
	}

	function getBoleto($id = null, $id_remessa = null){
		return $this->boleto_model->getBoleto($id, $id_remessa);
	}

	function getBoletosByRemessa($id_remessa){
		return $this->boleto_model->getBoletosByRemessa($id_remessa);
	}

	function getRemessa($id = null){
		return $this->boleto_model->getRemessa($id);
	}

	function gerarBoleto($id_banco, $dados_nota){
		try {
			$codigo_arquivo			  = null;
			$num_seq_remessa		  = null;
			$ultima_remessa			  = null;
			$is_save_remessa		  = null;	
			$retorno['erro_processo'] = false;
			// var_dump($this->boleto_model);
			$banco = json_decode($this->banco_model->getBanco($id_banco));
			if(!$banco){
				$retorno['erro_processo'] = true;
				$retorno[0]['codigo']     = 2;
				$retorno[0]['tipo']	      = 'danger';
				$retorno[0]['mensagem']   = 'Banco selecionado nao encontrado';
				$retorno[0]['dados']      = $id_banco;
				throw new Exception(json_encode($retorno), 1);
			}
			
			if(!$banco[0]->codigo_convenio_cnab240 && !$banco[0]->codigo_convenio_cnab400){
				$retorno['erro_processo'] = true;
				$retorno[0]['codigo']     = 2;
				$retorno[0]['tipo']	      = 'danger';
				$retorno[0]['mensagem']   = 'Banco selecionado não possui convenio';
				$retorno[0]['dados']      = $id_banco;
				throw new Exception(json_encode($retorno), 1);
			}

			if(!$dados_nota || !is_array($dados_nota)){
				$retorno['erro_processo'] = true;
				$retorno[0]['codigo']     = 2;
				$retorno[0]['tipo']	      = 'danger';
				$retorno[0]['mensagem']   = 'Informe as notas referente aos boletos';
				$retorno[0]['dados']      = $id_banco;
				throw new Exception(json_encode($retorno), 1);
			}

			$ultima_remessa = json_decode($this->arquivo_model->getLastRemessaByConvenio($banco[0]->codigo_convenio_cnab400, 'remessa', 'boleto'));

			if($ultima_remessa){
				$codigo_arquivo  = ($ultima_remessa[0]->codigo_arquivo + 1);
				$num_seq_remessa = ($ultima_remessa[0]->num_seq_remessa + 1);
			}else{
				$codigo_arquivo  = 1;
				$num_seq_remessa = 1;
			}

			$this->boleto_model->table = 'remessa_arquivo';
			
			$param_remessa['codigo_empresa']   = $banco[0]->id_empresa;
			$param_remessa['codigo_convenio']  = $banco[0]->codigo_convenio_cnab400;
			$param_remessa['num_seq_remessa']  = $num_seq_remessa;
			$param_remessa['codigo_arquivo']   = $codigo_arquivo;
			$param_remessa['num_seq_remessa']  = $num_seq_remessa;
			$param_remessa['nome_arquivo']     = 'CB'.$this->data_atual->format('dm').mb_str_pad($codigo_arquivo, 9, 0, STR_PAD_LEFT).'.REM';
			$param_remessa['tipo_inscricao']   = 2;
			$param_remessa['numero_inscricao'] = $banco[0]->cnpj_cm;
			$param_remessa['nome_empresa']     = $banco[0]->razao_social;
			$param_remessa['codigo_banco']     = $banco[0]->codigo_banco;
			$param_remessa['agencia']          = $banco[0]->numero_agencia;
			$param_remessa['agencia_dv']       = $banco[0]->digito_agencia;
			$param_remessa['conta']            = $banco[0]->numero_conta;
			$param_remessa['conta_dv']         = $banco[0]->digito_conta;
			$param_remessa['nome_banco']       = $banco[0]->nome_banco;
			$param_remessa['data_gravacao']    = $this->data_atual->format('Y-m-d');
	
			$is_save_remessa = $this->boleto_model->save($param_remessa);
			
			if($is_save_remessa){
				$num_seq_boleto = 0;
				foreach ($dados_nota as $key => $value) {
					$num_seq_boleto++;
					$data_vencimento = new DateTime($value->data_vencimento);
					$vr_multa = (($value->valor_total / 100) * $value->multa);
					$vr_juros = (($value->valor_total / 100) * $value->juros);
					$vr_juros = ($vr_juros / 30);

					$ultimo_boleto  = json_decode($this->boleto_model->getLastBoleto());
					if($ultimo_boleto){
						$nosso_numero = ($ultimo_boleto[0]->nosso_numero + 1);
					}else{
						$nosso_numero = 1;
					}

					//adicionando boleto
					if(isset($value->id)){
						$boleto['id_nf'] = $value->id;
					}elseif(isset($value->id_nf)){
						$boleto['id_nf'] = $value->id_nf;
					}else{
						$boleto['id_nf'] = null;
					}
					
					$boleto['id_remessa']   		      	= $is_save_remessa;
					$boleto['id_banco']		      			= $id_banco;
					$boleto['id_cliente']					= $value->id_cliente;
					$boleto['carteira']   		      		= '09';
					$boleto['habilitar_debito_compensacao'] = '0';
					$boleto['habilitar_multa'] 				= '1';
					$boleto['percentual_multa'] 			= $value->multa;
					$boleto['percentual_juros_mes'] 		= $value->juros;
					$boleto['valor_dia_atraso'] 			= round($vr_juros, '2');
					$boleto['valor_multa'] 					= $vr_multa;
					$boleto['num_seq_boleto'] 				= $num_seq_boleto;
					$boleto['desconto_dia']	 				= '0';
					$boleto['rateio'] 						= '0';
					$boleto['nosso_numero'] 				= $nosso_numero;
					$boleto['numero_documento'] 			= 'C'.$nosso_numero;
					$boleto['vencimento'] 					= $value->data_vencimento;
					$boleto['valor'] 						= $value->valor_total;
					$boleto['emitido_em'] 					= $this->data_atual->format('Y-m-d');
					$boleto['data_limite_desconto'] 		= $value->data_vencimento;
					$boleto['valor_desconto'] 				= '0';
					$boleto['valor_iof'] 					= '0';
					$boleto['valor_abatimento_concedido'] 	= '0';
					$boleto['tipo_cedente'] 			    = '2';
					$boleto['cnpj_cedente'] 			    = $banco[0]->cnpj_cm;
					$boleto['razao_social_cedente'] 		= removeCaracteres(substr($banco[0]->razao_social, 0, 30), 'char_especiais');
					$boleto['endereco_cedente'] 			= $banco[0]->endereco.', '.$banco[0]->numero.' '.$banco[0]->complemento;
					$boleto['cep_cedente'] 				    = removeCaracteres($banco[0]->cep, 'char');;
					$boleto['bairro_cedente'] 				= $banco[0]->bairro;
					$boleto['cidade_cedente'] 				= $banco[0]->cidade;
					$boleto['uf_cedente'] 				    = $banco[0]->estado;
					$boleto['tipo_sacado'] 		            = '2';
					$boleto['cnpj_sacado'] 				    = $value->cnpj_cpf_cliente;
					$boleto['razao_social_sacado'] 		    = substr(removeCaracteres($value->cliente, 'char_especiais'), 0, 30);
					$boleto['endereco_sacado'] 			    = removeCaracteres($value->endereco_cliente.', '.$value->numero_cliente, 'char_especiais');
					$boleto['complemento_sacado']    		= removeCaracteres($value->complemento_cliente, 'char_especiais');
					$boleto['cep_sacado'] 					= removeCaracteres($value->cep_cliente, 'char');
					$boleto['bairro_sacado'] 				= removeCaracteres($value->bairro_cliente, 'char_especiais');
					$boleto['cidade_sacado'] 				= removeCaracteres($value->municipio_cliente, 'char_especiais');
					$boleto['uf_sacado'] 				    = $value->uf_cliente;
					$boleto['primeira_mensagem'] 			= '';
					$boleto['segunda_mensagem'] 			= '';
					$boleto['email_nf'] 			        = $value->email_nf;
					$this->boleto_model->table              = 'remessa_boletos';
					
					$is_save_boleto = $this->boleto_model->save($boleto);

					if($is_save_boleto){
						$dados_boleto = $boleto;
						$dados_boleto['id_boleto'] = $is_save_boleto;
						$dados_boleto['email']     = $is_save_boleto;
						$retorno['codigo']   = 0;
						$retorno['tipo']	 = 'success';
						$retorno['mensagem'] = 'Boleto gravado com sucesso';
						$retorno['dados'][]    = $dados_boleto;
					}else{
						$retorno['erro_processo']  = true;
						$retorno['codigo']   = 2;
						$retorno['tipo']	   = 'danger';
						$retorno['mensagem'] = 'Erro ao gravar boleto';
						$retorno['dados']    = $boleto;
						$retorno['erro'][]   = $this->boleto_model->error;
					}
				}
			}else{
				$retorno['erro_processo']  = true;
				$retorno['codigo']   = 2;
				$retorno['tipo']	 = 'danger';
				$retorno['mensagem'] = 'Erro ao salvar remessa';
				$retorno['dados']    = $param_remessa;
				$retorno['erro'][0]  = $this->boleto_model->error;
			}
			// mb_convert_encoding($retorno['dados'], "UTF-8", "UTF-8");
			// $teste = json_encode(mb_convert_encoding($retorno, "UTF-8", "UTF-8"));

			switch (json_last_error()) {
				case JSON_ERROR_NONE:
					echo ' - No errors';
				break;
				case JSON_ERROR_DEPTH:
					echo ' - Maximum stack depth exceeded';
				break;
				case JSON_ERROR_STATE_MISMATCH:
					echo ' - Underflow or the modes mismatch';
				break;
				case JSON_ERROR_CTRL_CHAR:
					echo ' - Unexpected control character found';
				break;
				case JSON_ERROR_SYNTAX:
					echo ' - Syntax error, malformed JSON';
				break;
				case JSON_ERROR_UTF8:
					echo ' - Malformed UTF-8 characters, possibly incorrectly encoded';
				break;
				default:
					echo ' - Unknown error';
				break;
			}
			// echo '<pre>';
			// var_dump($retorno);
			// echo '</pre>';
			throw new Exception(mb_convert_encoding(json_encode($retorno), "UTF-8", "UTF-8"));
		} catch (Exception $e) {
			// echo $e->getMessage();
			return $e->getMessage();
		}		
	}

	function gerarArquivo($id_remessa){
		try {
	 		if($id_remessa){
				$remessas = json_decode($this->getRemessa($id_remessa));
				$boletos = json_decode($this->getBoletosByRemessa($id_remessa));
				if(!$remessas){
					$retorno[0]['codigo']   = 0;
					$retorno[0]['tipo']	    = 'danger';
					$retorno[0]['mensagem'] = 'Nenhuma remessa encotrada';
					$retorno[0]['dados']    = $remessas;
					$retorno[0]['erro']     = null;
					throw new Exception(json_encode($retorno), 1);
				}

				if(!$boletos){
					$retorno[0]['codigo']   = 0;
					$retorno[0]['tipo']	    = 'danger';
					$retorno[0]['mensagem'] = 'Nenhum boleto encontrado';
					$retorno[0]['dados']    = $remessas;
					$retorno[0]['erro']     = null;
					throw new Exception(json_encode($retorno), 1);
				}
				
				if(!is_dir(UP_ABSPATH.DS."remessa-boleto".DS.$remessas[0]->codigo_convenio)){
					mkdir(UP_ABSPATH.DS."remessa-boleto".DS.$remessas[0]->codigo_convenio);
				}

				if(file_exists(UP_ABSPATH.DS."remessa-boleto".DS.$remessas[0]->codigo_convenio.DS.$remessas[0]->nome_arquivo)){
					$retorno[0]['codigo']   = 0;
					$retorno[0]['tipo']	    = 'success';
					$retorno[0]['mensagem'] = 'Arquivo gerado com sucesso';
					$retorno[0]['dados']    = $remessas;
					$retorno[0]['erro']     = $this->boleto_model->error;
				}else{
					$obj_arquivo = new Hmarinjr\RemessaBradesco\Arquivo();
					$config['codigo_empresa'] = $remessas[0]->codigo_convenio;
					$config['razao_social']   = substr($remessas[0]->nome_empresa, 0, 30);
					$config['numero_remessa'] = $remessas[0]->num_seq_remessa;
					$config['data_gravacao']  = $this->data_atual->format('dmy');
					$obj_arquivo->config($config);
					
					foreach ($boletos as $key => $value) {
						$data_vencimento = new DateTime($value->vencimento);
						$param_boleto['carteira']   		      		= '09';
						$param_boleto['agencia'] 					    = $value->agencia;
						$param_boleto['agencia_dv'] 					= $value->agencia_dv;
						//$param_boleto['razao_conta_corrente']		    = '1250';
						$param_boleto['conta'] 						    = $value->conta;
						$param_boleto['conta_dv'] 					    = $value->conta_dv;
						$param_boleto['numero_controle'] 				= $value->nosso_numero;
						$param_boleto['habilitar_debito_compensacao']   = 0;
						$param_boleto['habilitar_multa'] 				= 1;
						$param_boleto['percentual_juros_mes'] 		    = $value->percentual_juros_mes;
						$param_boleto['valor_multa'] 					= $value->valor_multa;
						$param_boleto['nosso_numero'] 				    = $value->nosso_numero;
						$param_boleto['desconto_dia']	 				= '0';
						$param_boleto['rateio'] 						= false;
						$param_boleto['numero_documento'] 			    = 'C'.$value->nosso_numero;
						$param_boleto['vencimento'] 					= $value->vencimento;
						$param_boleto['data_limite_desconto'] 		    = $value->vencimento;
						$param_boleto['emitido_em'] 					= $this->data_atual->format('Y-m-d');
						$param_boleto['valor_desconto'] 				= '0';
						$param_boleto['valor_iof'] 					    = '0';
						$param_boleto['valor_abatimento_concedido'] 	= '0';
						$param_boleto['tipo_inscricao_pagador'] 		= 'CNPJ';
						$param_boleto['numero_inscricao'] 			    = str_pad($value->cnpj_sacado, 14, '0', STR_PAD_LEFT);
						$param_boleto['nome_pagador'] 				    = substr($value->razao_social_sacado, 0, 30);
						$param_boleto['endereco_pagador'] 			    = $value->endereco_sacado;
						$param_boleto['primeira_mensagem'] 	   		= '';
						$param_boleto['sacador_segunda_mensagem']   	= '';
						$param_boleto['valor'] 				            = removeCaracteres($value->valor, 'char');
						$param_boleto['valor_dia_atraso'] 	            = removeCaracteres($value->valor_dia_atraso, 'char');
						$param_boleto['percentual_multa'] 	            = removeCaracteres($value->percentual_multa, 'char');
						$param_boleto['data_emissao_titulo'] 	        = $this->data_atual->format('dmy');
						$param_boleto['vencimento'] 			        = $data_vencimento->format('dmy');
						$param_boleto['data_limite_desconto']           = $data_vencimento->format('dmy');
						$param_boleto['nosso_numero_dv'] 		        = 'P';
						$param_boleto['primeira_mensagem'] 	            = '';
						$param_boleto['cep_pagador'] 			        = substr($value->cep_sacado, 0, 5);
						$param_boleto['sufixo_cep_pagador'] 	        = substr($value->cep_sacado, 5, 3);
						$obj_arquivo->addboleto($param_boleto);
					}
					$obj_arquivo->setFilename(UP_ABSPATH.DS."remessa-boleto".DS.$remessas[0]->codigo_convenio.DS.$remessas[0]->nome_arquivo);
					//echo $obj_arquivo->getText();
					$obj_arquivo->save(false);
					if(file_exists($obj_arquivo->getFilename())){
						$retorno[0]['codigo']   = 0;
						$retorno[0]['tipo']	    = 'success';
						$retorno[0]['mensagem'] = 'Arquivo gerado com sucesso';
						$retorno[0]['dados']    = $remessas;
						$retorno[0]['erro']     = $this->boleto_model->error;
					}else{
						$retorno[0]['codigo']   = 0;
						$retorno[0]['tipo']	    = 'danger';
						$retorno[0]['mensagem'] = 'Erro ao gerar aquivo';
						$retorno[0]['dados']    = $remessas;
						$retorno[0]['erro']     = null;
					}
				}
	 		}else{
	 			$retorno[0]['codigo']   = 0;
				$retorno[0]['tipo']	    = 'danger';
				$retorno[0]['mensagem'] = 'Dados faltando para gerar aquivo';
				$retorno[0]['dados']    = $remessas;
				$retorno[0]['erro']     = null;
	 		}
	 		throw new Exception(json_encode($retorno), 1);
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	function downloadArquivo($path, $nome_arquivo){
		$path_full = UP_ABSPATH.'remessa-boleto'.DS.$path.DS.$nome_arquivo;
		header('Cache-control:private');
		header('Content-Type:application/octet-stream');
		header('Content-Length:'.filesize($path_full));
		header('Content-Disposition:filename='.$nome_arquivo);
		header("Content-Disposition:attachment; filename=".$nome_arquivo);
		readfile($path_full);
	}

	function gerarMidiaBoleto($id_boleto){
		try{	
			$boletos         = json_decode($this->getBoleto($id_boleto));
			$url             = URL_SISTEMA.'/boletos/viewpdf/id/'.$id_boleto.'/';
			// echo URL_SISTEMA.'/libs/openboleto/resources/css/styles.css';
			$css_boleto = '<style>'.file_get_contents(URL_SISTEMA.'/libs/openboleto/resources/css/styles.css').'</style>';
			$conteudo   = file_get_contents($url);
			if(!$conteudo){
				$retorno['codigo']   = 2;
				$retorno['tipo']     = 'danger';
				$retorno['mensagem'] = 'Erro ao carregar conteudo html para gerar o boleto';
				$retorno['dados']    = $boletos;
				throw new Exception(json_encode($retorno), 1);
			}

			if(!$boletos){
				$retorno['codigo']   = 2;
				$retorno['tipo']     = 'danger';
				$retorno['mensagem'] = 'Nenhum boleto encontrado';
				$retorno['dados']    = $boletos;
				throw new Exception(json_encode($retorno), 1);
			}
			
			$file_name = 'BC'.$boletos[0]->id.'.pdf';
			$path_full = UP_ABSPATH."remessa-boleto".DS.$boletos[0]->codigo_convenio.DS.$file_name;
			$mpdf      = new \Mpdf\Mpdf();
			$mpdf->allow_charset_conversion = true;
			$mpdf->SetDisplayMode('fullpage');
			// $mpdf->debug = true;
			$mpdf->showImageErrors = true;
			$mpdf->img_dpi = 96;
			$mpdf->use_kwt = true;
			$mpdf->SetTitle('BOLETO DE COBRANÇA'); 
			$mpdf->WriteHTML($css_boleto, 1);//aqui vc envia o CSS para o PDF
			$mpdf->WriteHTML($conteudo);
			
			$is_create = $mpdf->Output($path_full);

			if(file_exists($path_full)){
				// $arquivos['cliente'] = $path_full;
				// $arquivos['email']   = $path_full;
				//$arquivos['path_full']  = $path_full;
				$retorno['codigo']      = 0;

				$retorno['tipo']        = 'success';
				$retorno['mensagem']    = 'PDF para o boleto gerado com sucesso';
				$retorno['dados']       = $path_full;
			}else{
				$retorno['codigo']   = 2;
				$retorno['tipo']     = 'danger';
				$retorno['mensagem'] = 'Erro ao gerar PDF para o boleto COD: 406';
				$retorno['dados']    = $boletos;
			}
			throw new Exception(json_encode($retorno), 1);
		}catch (Exception $e) {
			return $e->getMessage();
		}
	}
}