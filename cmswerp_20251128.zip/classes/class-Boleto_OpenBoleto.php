<?php
require_once 'libs\openboleto\vendor\autoload.php';
class Boleto extends Banco{
	function criarRemessa($dados){
		$codigo_arquivo = null;
		$save_remessa 	= null;
		$obj_arquivo 	= null;
		if($dados){
			foreach ($dados as $key => $value) {
				$i = $value->id_banco;
				if($i && is_numeric($i)){
					$remessa[$i]['dados']['codigo_empresa']   = $value->codigo_convenio;
					$remessa[$i]['dados']['tipo_inscricao']   = '02';
					$remessa[$i]['dados']['numero_inscricao'] = $value->cnpj_cpf_prestador;
					$remessa[$i]['dados']['nome_empresa'] 	  = $value->prestador_servico;
					$remessa[$i]['dados']['codigo_banco'] 	  = $value->codigo_banco;
					$remessa[$i]['dados']['agencia'] 	  	  = $value->numero_agencia;	
					$remessa[$i]['dados']['agencia_dv'] 	  = $value->digito_agencia;
					$remessa[$i]['dados']['conta'] 	  		  = $value->numero_conta;
					$remessa[$i]['dados']['conta_dv'] 	  	  = $value->digito_conta;
					$remessa[$i]['dados']['nome_banco'] 	  = $value->nome_banco;
					$remessa[$i]['dados']['codigo_convenio']  = $value->codigo_convenio;
					$remessa[$i]['dados']['data_gravacao'] 	  = $this->data_hora_atual->format('Y-m-d');
					$remessa[$i]['boletos'][] = $value;
				}else{
					//implementar erro
				}
			}
			if($remessa){
				$ultima_remessa = null;
				$ultimo_boleto 	= null;
				foreach ($remessa as $remessa) {

					$obj_arquivo = null;

					$ultima_remessa = json_decode($this->boleto_model->getLastRemessaByConvenio($remessa['dados']['codigo_empresa']));
					$ultimo_boleto  = json_decode($this->getLastBoleto());
					
					if($ultima_remessa){
						$codigo_arquivo  = ($ultima_remessa[0]->codigo_arquivo + 1);
						$num_seq_remessa = ($ultima_remessa[0]->num_seq_remessa + 1);
					}else{
						$codigo_arquivo  = 1;
						$num_seq_remessa = 1;
					}
					if($ultimo_boleto){
						$nosso_numero = ($ultimo_boleto[0]->nosso_numero + 1);
					}else{
						$nosso_numero = 1;
					}

					$remessa['dados']['codigo_arquivo']  = $codigo_arquivo;
					$remessa['dados']['num_seq_remessa'] = $num_seq_remessa;
					$remessa['dados']['nome_arquivo'] 	 =  'CB'.$this->data_hora_atual->format('dm').mb_str_pad($codigo_arquivo, 2, 0, STR_PAD_LEFT).'.REM';
					$this->boleto_model->table = 'arquivo_remessa_boleto';
					$save_remessa = $this->boleto_model->save($remessa['dados']);
					if($save_remessa){
						$lote        = null;
						$sacado = new OpenBoleto\Agente('Fernando Maia', '023.434.234-34', 'ABC 302 Bloco N', '72000-000', 'Brasília', 'DF');
						$cedente = new OpenBoleto\Agente($remessa['dados']['nome_empresa'], '02.123.123/0001-11', 'CLS 403 Lj 23', '71000-000', 'Brasília', 'DF');
						$boleto = new OpenBoleto\Banco\Bradesco(array(
						    // Parâmetros obrigatórios
						    'dataVencimento' => new DateTime('2013-01-01'),
						    'valor' => 10.50,
						    'sequencial' => $nosso_numero, // Até 11 dígitos
						    'sacado' => $sacado,
						    'cedente' => $cedente,
						    'agencia' => 1172, // Até 4 dígitos
						    'carteira' => 6, // 3, 6 ou 9
						    'conta' => 0403005, // Até 7 dígitos

						    // Parâmetros recomendáveis
						    //'logoPath' => 'http://empresa.com.br/logo.jpg', // Logo da sua empresa
						    'contaDv' => 2,
						    'agenciaDv' => 1,
						    'carteiraDv' => 1,
						    'descricaoDemonstrativo' => array( // Até 5
						        'Compra de materiais cosméticos',
						        'Compra de alicate',
						    ),
						    'instrucoes' => array( // Até 8
						        'Após o dia 30/11 cobrar 2% de mora e 1% de juros ao dia.',
						        'Não receber após o vencimento.',
						    ),

						    // Parâmetros opcionais
						    //'resourcePath' => '../resources',
						    //'cip' => '000', // Apenas para o Bradesco
						    //'moeda' => Bradesco::MOEDA_REAL,
						    //'dataDocumento' => new DateTime(),
						    //'dataProcessamento' => new DateTime(),
						    //'contraApresentacao' => true,
						    //'pagamentoMinimo' => 23.00,
						    //'aceite' => 'N',
						    //'especieDoc' => 'ABC',
						    //'numeroDocumento' => '123.456.789',
						    //'usoBanco' => 'Uso banco',
						    //'layout' => 'layout.phtml',
						    //'logoPath' => 'http://boletophp.com.br/img/opensource-55x48-t.png',
						    //'sacadorAvalista' => new Agente('Antônio da Silva', '02.123.123/0001-11'),
						    //'descontosAbatimentos' => 123.12,
						    //'moraMulta' => 123.12,
						    //'outrasDeducoes' => 123.12,
						    //'outrosAcrescimos' => 123.12,
						    //'valorCobrado' => 123.12,
						    //'valorUnitario' => 123.12,
						    //'quantidade' => 1,
						));
						echo $boleto->getOutput();
						// foreach ($remessa['boletos'] as $key => $value) {
						// 	// var_dump($value);
						// 	// $obj_arquivo = new CnabPHP\Remessa($remessa['dados']['codigo_banco'],'cnab400',array(
						// 	//     'nome_empresa' =>$remessa['dados']['nome_empresa'], // seu nome de empresa
						// 	//     'tipo_inscricao'  => $remessa['dados']['nome_empresa'], // 1 para cpf, 2 cnpj 
						// 	//     'numero_inscricao' => $remessa['dados']['numero_inscricao'], // seu cpf ou cnpj completo
						// 	//     'agencia'       => $remessa['dados']['agencia'], // agencia sem o digito verificador 
						// 	//     'agencia_dv'    => $remessa['dados']['agencia_dv'], // somente o digito verificador da agencia 
						// 	//     'conta'         => $remessa['dados']['conta'], // número da conta
						// 	//     'conta_dv'     => $remessa['dados']['conta_dv'], // digito da conta
						// 	//     'posto' => '0', // codigo forncecido pelo sicredi obs: como o dv da agencia não é informado eu armazeno no banco de dados essa valor no dv da agencia
						// 	//     'codigo_beneficiario'     => $remessa['dados']['codigo_convenio'], // codigo fornecido pelo banco
						// 	//     'codigo_beneficiario_dv'     => '0', // codigo fornecido pelo banco
						// 	//     'numero_sequencial_arquivo'     => $remessa['dados']['num_seq_remessa'],
						// 	//     'situacao_arquivo' =>'P', // use T para teste e P para produ��o
						// 	//     'mensagem_1'=>'Sua mensagem personalizada para todos os boletos do arquivo aqui', // suportado somente para SICOOB cnab400, mudar o numero 1 para 2,3,4,5 para incluir mais mensagens
						// 	// ));
						// 	// var_dump($obj_arquivo);
						// 	// $lote = $obj_arquivo->addLote(array('tipo_servico'=> 1)); // tipo_servico  = 1 para cobrança registrada, 2 para sem registro
						// 	// var_dump($lote);
						// 	$data_vencimento = new DateTime($value->data_vencimento);
						// 	$data_multa		 = clone($data_vencimento);
						// 	$data_multa->add(new DateInterval('P1D'));
						// 	$vr_multa = (($value->valor_total / 100) * $value->multa);
						// 	$vr_juros = (($value->valor_total / 100) * $value->juros);
						// 	$vr_juros = ($vr_juros / 30);

						// 	$boleto['id_nf']      		      		= $value->id;
						// 	$boleto['habilitar_debito_compensacao'] = 0;
						// 	$boleto['desconto_dia'] 				= 0;
						// 	$boleto['emissao_boleto'] 				= 2;
						// 	$boleto['numero_documento'] 			= 'documento';
						// 	$boleto['valor_iof'] 					= 0;
						// 	$boleto['valor_abatimento_concedido'] 	= 0;
						// 	$boleto['rateio'] 						= null;
						// 	$boleto['especie_titulo']    		    = 12;
						// 	$boleto['agencia']    		      		= 0;
						// 	$boleto['agencia_dv'] 		      		= 0;
						// 	$boleto['conta'] 	  		      		= 0;
						// 	$boleto['conta_dv']   		      		= 0;
						// 	$boleto['carteira']   		      		= '09';
						// 	$boleto['id_empresa_banco']       		= '009'.$value->numero_agencia.$value->numero_conta.$value->digito_conta;
						// 	$boleto['numero_controle']        		= '009'.$this->data_hora_atual->format('YmdHis').$value->id;
						// 	$boleto['codigo_banco_debito']    		= '003';
						// 	$boleto['habilitar_multa']        		= 2;
						// 	$boleto['percentual_multa']       		= $value->multa;
						// 	$boleto['nosso_numero']    	      		= $nosso_numero;
						// 	$boleto['dg_nosso_numero'] 	   	  		= null;
						// 	$boleto['vencimento']    	   	  		= $value->data_vencimento;
						// 	$boleto['valor']    	   	   	  		= $value->valor_total;
						// 	$boleto['data_emissao_titulo'] 	  		= $this->data_hora_atual->format('Y-m-d');
						// 	$boleto['instrucao1']    	   	  		= null;
						// 	$boleto['instrucao2']    	   	  		= null;
						// 	$boleto['valor_dia_atraso']   	  		= round($vr_juros, '2');
						// 	$boleto['data_limite_desconto']	  		= null;
						// 	$boleto['valor_desconto']      	  		= 0;
						// 	$boleto['tipo_inscricao_pagador'] 		= 2;
						// 	$boleto['numero_inscricao']    	  		= $value->cnpj_cpf_cliente;
						// 	$boleto['nome_pagador']    	  	  		= $value->cliente;
						// 	$boleto['endereco_pagador']    	  		= $value->endereco_cliente.' '.$value->numero_cliente.' '.$value->complemento_cliente;
						// 	$boleto['primeira_mensagem']      		= null;
						// 	$boleto['sacador_segunda_mensagem'] 	= null;
						// 	$boleto['cep_pagador']    	   	  		= removeCaracteres($value->cep_cliente, 'char');
						// 	$this->boleto_model->table = 'boletos';
						// 	$save_boleto = $this->boleto_model->save($boleto);
						// 	if($save_boleto){
						// 		$lote->inserirDetalhe(array(
						// 		    'codigo_movimento' => 1, //1 = Entrada de título, para outras opções ver nota explicativa C004 manual Cnab_SIGCB na pasta docs
						// 		    'nosso_numero'      => $nosso_numero, // numero sequencial de boleto
						// 		    'seu_numero'        => 1,// se nao informado usarei o nosso numero 

						// 		    /* campos necessarios somente para itau e siccob,  não precisa comentar se for outro layout    */
						// 		    'carteira_banco'    => $boleto['carteira'], // codigo da carteira ex: 109,RG esse vai o nome da carteira no banco
						// 		    'cod_carteira'      => "01", // I para a maioria ddas carteiras do itau
						// 		     /* campos necessarios somente para itau,  não precisa comentar se for outro layout    */
								     
						// 		    'especie_titulo'    => $boleto['especie_titulo'], // informar dm e sera convertido para codigo em qualquer laytou conferir em especie.php
						// 		    'valor'             => $boleto['valor'], // Valor do boleto como float valido em php
						// 		    'emissao_boleto'    => $boleto['emissao_boleto'], // tipo de emissao do boleto informar 2 para emissao pelo beneficiario e 1 para emissao pelo banco
						// 		    'protestar'         => 3, // 1 = Protestar com (Prazo) dias, 3 = Devolver após (Prazo) dias
						// 		    'prazo_protesto'    => 5, // Informar o numero de dias apos o vencimento para iniciar o protesto
						// 		    'nome_pagador'      => $boleto['nome_pagador'], // O Pagador é o cliente, preste atenção nos campos abaixo
						// 		    'tipo_inscricao'    => $boleto['tipo_inscricao_pagador'], //campo fixo, escreva '1' se for pessoa fisica, 2 se for pessoa juridica
						// 		    'numero_inscricao'  => $boleto['numero_inscricao'],//cpf ou ncpj do pagador
						// 		    'endereco_pagador'  => $boleto['endereco_pagador'],
						// 		    'bairro_pagador'    => $value->bairro_cliente,
						// 		    'cep_pagador'       => $value->cep_cliente, // com hífem
						// 		    'cidade_pagador'    => $value->municipio_cliente,
						// 		    'uf_pagador'        => $value->uf_cliente,
						// 		    'data_vencimento'   => $data_vencimento->format('Y-m-d'), // informar a data neste formato
						// 		    'data_emissao'      => $this->data_hora_atual->format('Y-m-d'), // informar a data neste formato
						// 		    'vlr_juros'         => round($vr_juros, 2), // Valor do juros de 1 dia'
						// 		    'data_desconto'     => $data_vencimento->format('Y-m-d'), // informar a data neste formato
						// 		    'vlr_desconto'      => '0', // Valor do desconto
						// 		    'baixar'            => 2, // codigo para indicar o tipo de baixa '1' (Baixar/ Devolver) ou '2' (Não Baixar / Não Devolver)
						// 		    'prazo_baixa'       => 90, // prazo de dias para o cliente pagar após o vencimento
						// 		    'mensagem'          => 'JUROS R$ '.round($vr_juros, 2).PHP_EOL."Não receber apos 30 dias",
						// 		    'email_pagador'     => 'julio.gomes@cmsw.com', // data da multa
						// 		    'data_multa'        => $data_multa->format('Y-m-d'), // informar a data neste formato, // data da multa
						// 		    'vlr_multa'         => round($vr_multa, 2), // valor da multa
						// 		    // campos necessários somente para o sicoob
						// 		    //'cod_instrucao1'     => 1, //instrução para cobrar juros novas regras da base de boletos unificada 
						// 		    //'cod_instrucao2'     => 1, //instrução para cobrar juros novas regras da base de boletos unificada 
						// 		    //'taxa_multa'         => 0.00, // taxa de multa em percentual
						// 		    //'taxa_juros'         => 0.00, // taxa de juros em percentual
						// 		));
						// 		var_dump($lote);
						// 	}else{
						// 		//implementar erro salvar boleto
						// 	}
						// 	$nosso_numero++;
						// 	//var_dump($obj_arquivo, $lote);
						// }
						
						// echo $obj_arquivo->getText();
						// unset($obj_arquivo);
						// unset($lote);
						// $fp = fopen(UP_ABSPATH."/remessa-boleto/".$remessa['dados']['nome_arquivo'], 'w');
						// fwrite($fp, $obj_arquivo->getText());
						// fclose($fp);
						// header("Content-Disposition: attachment;filename=" . $remessa['dados']['nome_arquivo'] .";");
						// echo utf8_decode($obj_arquivo->getText()); // observar a header do seu php para não gerar comflitos de codificação de caracteres
					}else{
						//implementar erro
					}
				}
			}else{
				//implementar erro
			}
		}else{
			//implementar erro
		}
	}
}