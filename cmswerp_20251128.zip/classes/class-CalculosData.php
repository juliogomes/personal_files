<?php

class DiasUteis {
    function dias_uteis($datainicial,$datafinal=null){
          
          if (!isset($datainicial)) return false;
            $segundos_datainicial = strtotime(str_replace("/","-",$datainicial));
          if (!isset($datafinal)) 
                $segundos_datafinal=time();
          else 
                $segundos_datafinal = strtotime(str_replace("/","-",$datafinal));
          $dias = abs(floor(floor(($segundos_datafinal-$segundos_datainicial)/3600)/24 ) );
          $uteis=0;
          
          for($i=1;$i<=$dias;$i++)
          {
            $diai = $segundos_datainicial+($i*3600*24);
            $w = date('w',$diai);
                if ($w>0 && $w<6){
                     $uteis++; 
                 }
          }
          return $uteis;
    }
}