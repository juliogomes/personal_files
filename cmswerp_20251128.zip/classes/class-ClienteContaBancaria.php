<?php

class ClienteContaBancaria extends ContaBancaria{
	private $model_cliente;
	protected $id_conta, $nome_cliente, $tipo_pessoa, $cnpj_cpf, $email, $logradouro, $numero, $complemento, $bairro, $cidade, $uf, $cep;
	function __construct($controller, $cliente = null){
		if(is_array($cliente)){
			$cliente = convertToObject($cliente);
		}
        parent::__construct($controller, $cliente);
		if($cliente){
			$this->setCliente($cliente);
		}
	}

	function setCliente($cliente){
        if(is_array($cliente)){
			$cliente = convertToObject($cliente);
		}
		
        $this->id_conta     = $cliente->id_empresa;
        $this->nome_cliente = $cliente->razao_social;
		$this->tipo_pessoa  = $cliente->tipo_inscricao; // 1 = cnpj, 2 = cpf
		$this->cnpj_cpf     = $cliente->cnpj_cpf;
		$this->email        = $cliente->email;
        $this->logradouro   = $cliente->logradouro;
        $this->numero       = $cliente->numero;
        $this->complemento  = $cliente->complemento;
        $this->bairro       = $cliente->bairro;
        $this->cidade       = $cliente->cidade;
        $this->uf           = $cliente->uf;
        $this->cep          = $cliente->cep;
	}

	// function getCliente($cnpj_cpf){
	// 	$this->model_cliente = $controller()
	// 	return $this;
	// }
}