<?php
	
class Cobranca extends Main{
	function __construct( $controller, $parametros = null ){
        parent::__construct( $controller );
	}

	function importLpDefault(){
        try {
            // args[0] = id do contrato;
            // args[1] = faixa de preco;
            $args = func_get_args();
            if(!$args){
                $retorno['codigo']   = 1;
				$retorno['input']    = $args;
				$retorno['output']   = null;
				$retorno['mensagem'] = "Argumentos não encontrados";
				throw new Exception(json_encode($retorno), 1);
            }

            if(!$args[0]){
                $retorno['codigo']   = 1;
				$retorno['input']    = $args;
				$retorno['output']   = null;
				$retorno['mensagem'] = "ID do contrato não informado";
				throw new Exception(json_encode($retorno), 1);
            }

            if(!$args[1]){
                $retorno['codigo']   = 1;
				$retorno['input']    = $args;
				$retorno['output']   = null;
				$retorno['mensagem'] = "Faixa de preço não informada";
				throw new Exception(json_encode($retorno), 1);
            }
            $error = null;
            foreach ($args[1] as $key => $value){
                unset($value->id);
                unset($value->editavel);
                unset($value->editada);
                $param['id_contrato']  = $args[0];
                $param['alterado_em']  = $this->data_atual->format('Y-m-d H:i:s');
                $param['alterado_por'] = $this->controller->userdata->id;
                foreach ($value as $k1 => $v1){
                    $param[$k1] = $v1;
                }
                $save_faixa = $this->controller->lpModel->save($param);
                $info = $this->controller->lpModel->info;
                if(!$save_faixa){
                    $error = true;
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $args;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = $this->controller->lpModel->info->mensagem;
                }
            }

            if(!$error){
                $retorno['codigo']   = 0;
                $retorno['input']    = $args;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Importação executada com sucesso";
            }
            throw new Exception(json_encode($retorno), 1);
        } catch (Exception $e) {
			echo $e->getMessage();
		}
    }

    function listaPreco( $action, $dados ){
        try {
            switch ( $action ) {
                case 'migrar_pacote':
                    $pacote      = json_decode( $this->controller->modelo->getPacote( $dados['id_contrato'], $dados['id_modulo'] ) );
                    $lista_preco = json_decode( $this->controller->lpModel->getLpByCustomer( $dados['id_contrato'], $dados['id_modulo'] ) );
                    if( $pacote ){
                        if( !$lista_preco ){
                            $dados_lista['id_contrato']   = $_POST['id_contrato'];
                            $dados_lista['id_produto'] 	  = $_POST['id_produto'];
                            $dados_lista['id_modulo'] 	  = $_POST['id_modulo'];
                            $dados_lista['tipo_cobranca'] = $_POST['tipo_cobranca'];
                            $dados_lista['qtd_de'] 		  = 0;
                            $dados_lista['qtd_ate'] 	  = 0;
                            $dados_lista['valor_total']   = removeCaracteres( trim( $pacote[0]->preco_pkt ), "moeda4" );
                            $dados_lista['valor_real'] 	  = removeCaracteres( trim( $pacote[0]->preco_pkt ), "moeda4" );
                            $dados_lista['status'] 		  = $pacote[0]->status;
                            $is_save = json_decode( $this->listaPreco( 'save', $dados_lista ) );
                            if( $is_save->codigo == 0 ){
                                $param_pacote['status']          = 'inativo';
                                $param_pacote['id_pacote']       = $pacote[0]->id;
                                $param_pacote['status_contrato'] = $pacote[0]->id_contrato;
                                $this->pacote( 'status', $param_pacote );
                            }else{
                                throw new Exception( json_encode( $is_save ), 1 );
                            }
                        }else{
                            $retorno['codigo']   = '1';
                            $retorno['output']   = null;
                            $retorno['mensagem'] = 'Conflito entre pacote e lista para valor fixo, acione o admin';
                            throw new Exception( json_encode( $retorno ), 1 );
                        }
                    }else{
                        $retorno['codigo']   = '1';
                        $retorno['output']   = null;
                        $retorno['mensagem'] = 'Pacote não encontrado';
                        throw new Exception( json_encode( $retorno ), 1 );
                    }
                break;
                case 'faixa':
                    if( isset( $dados['id_faixa'] ) && !empty( $dados['id_faixa'] ) && is_numeric( $dados['id_faixa'] ) ){
                        $id_faixa = $dados['id_faixa'];
                    }else{
                        $retorno['codigo']   = 1; 
                        $retorno['mensagem'] = "Informe o ID da lista.";
                        throw new Exception(json_encode($retorno), 1);
                    }
                   
                    $lista = json_decode( $this->controller->modelo->getFaixa( $id_faixa ) );
                    if( $lista ){
                        foreach ( $lista as $key => $value) {
                            $value->valor_real = number_format( $value->valor_real, '6', ',', '.' );
                        }
                    }

                    if( $lista ){
                        $retorno['codigo']   = 0;
                        $retorno['output']   = $lista;
                        $retorno['mensagem'] = 'Sucesso';
                        throw new Exception( json_encode( $retorno ), 1 );
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['output']   = null;
                        $retorno['mensagem'] = 'Erro ao apagar lista de preço';
                        throw new Exception( json_encode( $retorno ), 1 );
                    }
                break;
                // case 'editar':
                //     if( isset( $dados['id_faixa'] ) && !empty( $dados['id_faixa'] ) && is_numeric( (int)$dados['id_faixa'] ) ){
                //         $id_faixa = $dados['id_faixa'];
                //         $lp_antiga = json_decode( $this->controller->modelo->getFaixa( $id_faixa ) );
                //         if( !isset( $dados['modalidade'] ) || empty( !isset( $dados['modalidade'] ) ) ){
                //             $dados['modalidade'] = 'TRANSACAO';
                //         }
                //     }else{
                //         $id_faixa = null;
                //     }
                //     unset( $dados['id_faixa'] );

                //     if( !isset( $dados['id_contrato'] ) || empty( $dados['id_contrato'] ) || !is_numeric( (int)$dados['id_contrato'] ) ){
                //         $retorno['codigo']   = 1;
                //         $retorno['mensagem'] = 'Informe o contrato';
                //         throw new Exception( json_encode( $retorno ), 1 );
                //     }

                //     if( !isset( $dados['id_produto'] ) || empty( $dados['id_produto'] ) || !is_numeric( (int)$dados['id_produto'] ) ){
                //         $retorno['codigo']   = 1;
                //         $retorno['mensagem'] = 'Informe o produto';
                //         throw new Exception( json_encode( $retorno ), 1 );
                //     }

                //     if( !isset( $dados['id_modulo'] ) || empty( $dados['id_modulo'] ) || !is_numeric( (int)$dados['id_modulo'] ) ){
                //         $retorno['codigo']   = 1;
                //         $retorno['mensagem'] = 'Informe o modeulo';
                //         throw new Exception( json_encode( $retorno ), 1 );
                //     }

                //     $dados['qtd_de']   	  = removeCaracteres($dados['qtd_de'],     'moeda2');
                //     $dados['qtd_ate']     = removeCaracteres($dados['qtd_ate'],    'moeda2');
                //     $dados['valor_real']  = removeCaracteres($dados['valor_real'], 'moeda2');
                //     $dados['status'] 	  = 'ativo';
                //     $this->controller->modelo->setTable('lp_clientes');
                //     $is_save = $this->controller->modelo->save( $dados, $id_faixa );
                //     if( $is_save ){
                //         if( $lp_antiga ){
                //             $lp_old['id_lp']            = $id_faixa;
                //             $lp_old['id_contrato']      = $lp_antiga[0]->id_contrato;
                //             $lp_old['id_produto']       = $lp_antiga[0]->id_produto;
                //             $lp_old['id_modulo']        = $lp_antiga[0]->id_modulo;
                //             $lp_old['tipo_cobranca']    = $lp_antiga[0]->tipo_cobranca;
                //             $lp_old['qtd_de']   	    = $lp_antiga[0]->qtd_de;
                //             $lp_old['qtd_ate']          = $lp_antiga[0]->qtd_ate;
                //             $lp_old['valor_real']       = $lp_antiga[0]->valor_real;
                //             $lp_old['valor_antigo']     = $lp_antiga[0]->valor_real;
                //             $lp_old['valor_atualizado'] = $dados['valor_real'];
                //         }else{
                //             $lp_old['id_lp']            = $is_save;
                //             $lp_old['id_contrato']      = $dados['id_contrato'];
                //             $lp_old['id_produto']       = $dados['id_produto'];
                //             $lp_old['id_modulo']        = $dados['id_modulo'];
                //             $lp_old['tipo_cobranca']    = $dados['tipo_cobranca'];
                //             $lp_old['qtd_de']   	    = $dados['qtd_de'];
                //             $lp_old['qtd_ate']          = $dados['qtd_ate'];
                //             $lp_old['valor_real']       = $dados['valor_real'];
                //             $lp_old['valor_antigo']     = $dados['valor_real'];
                //             $lp_old['valor_atualizado'] = $dados['valor_real'];
                //         }
                        
                //         $lp_old['alterado_por']     = $_SESSION['cmswerp']['userdata']->id;
                //         $lp_old['alterado_em']      = $this->data_atual->format('Y-m-d H:i:s');	
                //         $lp_old['tipo_atualizacao'] = 'manual';
                //         return $this->historico( 'listaDePreco', 'save', $lp_old );
                //     }else{
                //         $retorno['codigo']   = 1;
                //         $retorno['mensagem'] = 'Erro ao salvar lista de preço';
                //         throw new Exception( json_encode( $retorno ), 1 );
                //     }
                // break;
                case 'editar':
                case 'save':
                    $error = false;
                    if( isset( $dados['id_faixa'] ) && !empty( $dados['id_faixa'] ) && is_numeric( (int)$dados['id_faixa'] ) ){
                        $id_faixa = $dados['id_faixa'];
                        $lp_antiga = json_decode( $this->controller->modelo->getFaixa( $id_faixa ) );
                        if( !isset( $dados['modalidade'] ) || empty( !isset( $dados['modalidade'] ) ) ){
                            $dados['modalidade'] = 'TRANSACAO';
                        }
                    }else{
                        $id_faixa = null;
                    }
                    unset( $dados['id_faixa'] );

                    if( !isset( $dados['id_contrato'] ) || empty( $dados['id_contrato'] ) || !is_numeric( $dados['id_contrato'] ) ){
                        $error = true;
                        $retorno['mensagem'] = 'ID do contrato não informado';
                    }

                    if( !isset( $dados['id_produto'] ) || empty( $dados['id_produto'] ) || !is_numeric( $dados['id_produto'] ) ){
                        $error = true;
                        $retorno['mensagem'] = 'ID do produto não informado';
                    }

                    if( !isset( $dados['id_modulo'] ) || empty( $dados['id_modulo'] ) || !is_numeric( $dados['id_modulo'] )){
                        $error = true;
                        $retorno['mensagem'] = 'ID do modulo não informado';
                    }

                    if( isset( $dados['valor_real'] ) && !empty( $dados['valor_real'] ) && is_numeric( removeCaracteres( trim( $dados["valor_real"] ), "moeda2" ) ) ){
                        $valor_real = removeCaracteres( trim( $dados["valor_real"] ), "moeda2" );
                    }else{
                        $valor_real = 0;
                    }

                    if( isset( $dados['valor_total'] ) && !empty( $dados['valor_total'] ) && is_numeric( removeCaracteres( trim( $dados["valor_total"] ), "moeda2" ) ) ){
                        $valor_total = removeCaracteres( trim( $dados["valor_total"] ), "moeda2" );
                    }else{
                        $valor_total = 0;
                    }

                    if( !$valor_real && $valor_total ){
                        $valor_real = $valor_total;
                    }elseif( $valor_real && !$valor_total ){
                        $valor_total = $valor_real;
                    }

                    if( isset( $dados['qtd_de'] ) && !empty( $dados['qtd_de'] ) ){
                        $qtd_de = removeCaracteres( trim( $dados["qtd_de"] ), "moeda2" );
                    }else{
                        $qtd_de = 0;
                    }

                    if( isset( $dados['qtd_ate'] ) && !empty( $dados['qtd_ate'] ) ){
                        $qtd_ate = removeCaracteres( trim( $dados["qtd_ate"] ), "moeda2" );
                    }else{
                        $qtd_ate = 0;
                    }

                    if( !isset( $dados['tipo_cobranca'] ) || empty( $dados['tipo_cobranca'] ) ){
                        $error = true;
                        $retorno['mensagem'] = 'Tipo de cobrança desconhecido';
                    }

                    if( isset( $dados['status'] ) && !empty( $dados['status'] ) ){
                        $status = $dados['status'];
                    }else{
                        $status = 'ativo';
                    }

                    if( $error ){
                        $retorno['codigo'] = 1;
                        throw new Exception( json_encode( $retorno ), 1);
                    }

                    $param_lp['id_contrato'] 	= $dados['id_contrato'];
                    $param_lp['id_produto'] 	= $dados['id_produto'];
                    $param_lp['id_modulo'] 		= $dados['id_modulo'];
                    $param_lp['tipo_cobranca'] 	= $dados['tipo_cobranca'];
                    $param_lp['qtd_de'] 		= $qtd_de;
                    $param_lp['qtd_ate'] 		= $qtd_ate;
                    $param_lp['valor_total'] 	= $valor_total;
                    $param_lp['valor_real'] 	= $valor_real;
                    $param_lp['status'] 		= $status;
                    $param_lp['deleted'] 		= 0;
                    $is_save = $this->controller->lpModel->save( $param_lp, $id_faixa );
                    if( $is_save ){
                        if( $lp_antiga ){
                            $lp_old['id_lp']            = $id_faixa;
                            $lp_old['id_contrato']      = $lp_antiga[0]->id_contrato;
                            $lp_old['id_produto']       = $lp_antiga[0]->id_produto;
                            $lp_old['id_modulo']        = $lp_antiga[0]->id_modulo;
                            $lp_old['tipo_cobranca']    = $lp_antiga[0]->tipo_cobranca;
                            $lp_old['qtd_de']   	    = $lp_antiga[0]->qtd_de;
                            $lp_old['qtd_ate']          = $lp_antiga[0]->qtd_ate;
                            $lp_old['valor_real']       = $valor_real;
                            $lp_old['valor_antigo']     = $lp_antiga[0]->valor_real;
                            $lp_old['valor_atualizado'] = $valor_real;
                        }else{
                            $lp_old['id_lp']            = $is_save;
                            $lp_old['id_contrato']      = $dados['id_contrato'];
                            $lp_old['id_produto']       = $dados['id_produto'];
                            $lp_old['id_modulo']        = $dados['id_modulo'];
                            $lp_old['tipo_cobranca']    = $dados['tipo_cobranca'];
                            $lp_old['qtd_de']   	    = $dados['qtd_de'];
                            $lp_old['qtd_ate']          = $dados['qtd_ate'];
                            $lp_old['valor_real']       = $valor_real;
                            $lp_old['valor_antigo']     = 0;
                            $lp_old['valor_atualizado'] = $valor_real;
                        }
                        $lp_old['alterado_por']     = $_SESSION['cmswerp']['userdata']->id;
                        $lp_old['alterado_em']      = $this->data_atual->format('Y-m-d H:i:s');	
                        $lp_old['tipo_atualizacao'] = 'manual';
                        return $this->historico( 'listaDePreco', 'save', $lp_old );
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['mensagem'] = 'Erro ao salvar lista de preço';
                        throw new Exception( json_encode( $retorno ), 1 );
                    }

                break;
                case 'apagar':
                    if( !isset( $dados['id_faixa'] ) || empty( $dados['id_faixa'] ) || !is_numeric( (int)$dados['id_faixa'] ) ){
                        $retorno['codigo']   = 1;
                        $retorno['mensagem'] = 'ID lista invalido';
                        throw new Exception( json_encode( $retorno ), 1 );
                    }
                    
                    $deleted = $this->controller->modelo->deletar( $dados['id_faixa'] );
                    if( $deleted ){
                        $retorno['codigo']   = 0;
                        $retorno['mensagem'] = 'Sucesso';
                        throw new Exception( json_encode( $retorno ), 1 );
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['mensagem'] = 'Erro ao apagar lista de preço';
                        throw new Exception( json_encode( $retorno ), 1 );
                    }
                break;
            }
        } catch ( Exception $e ) {
            return $e->getMessage();
        }
    }

    function pacote( $action, $dados ){
        $this->controller->modelo->setTable( 'pacote_contratado' );
        try {
            switch ( $action ) {
                case 'status':
                    if( isset( $dados['id_pacote'] ) && !empty( $dados['id_pacote'] ) && is_numeric( $dados['id_pacote'] ) ){
                        $id_pacote = $dados['id_pacote'];
                    }else{
                        $id_pacote = null;
                    }

                    if( !isset( $dados['id_pacote'] ) || empty( $dados['id_pacote'] ) || !is_numeric( $dados['id_pacote'] ) ){
                        $retorno['codigo']   = '1';
                        $retorno['mensagem'] = 'Informe o numero do contrato';
                        throw new Exception( json_encode( $retorno ), 1 );
                    }

                    switch ( $dados['status'] ) {
                        case 'inativo':
                            $param_pacote['status'] = 'inativo';
                        break;
                        default:
                            $param_pacote['status'] = 'ativo';
                        break;
                    }

                    $is_save = $this->controller->modelo->save( $param_pacote, $id_pacote );
                    if( $is_save ){
                        $retorno['codigo']   = '0';
                        $retorno['mensagem'] = 'Sucesso';
                        throw new Exception( json_encode( $retorno ), 1 );
                    }else{
                        $retorno['codigo']   = '1';
                        $retorno['mensagem'] = 'Erro ao inativar o pacote';
                        throw new Exception( json_encode( $retorno ), 1 );
                    }
                break;
                case 'save':
                    if( !isset( $dados['tipo_pacote'] ) || empty( $dados['tipo_pacote'] ) ){
                        $dados['tipo_pacote'] = 'cliente';
                    }

                    if( !isset( $dados['id_modulo'] ) || !is_numeric( $dados['id_modulo'] ) || empty( $dados['id_modulo'] ) ){
                        $retorno['codigo']   = 1;
                        $retorno['tipo']     = 'danger';
                        $retorno['mensagem'] = 'Modulo invalido';
                        $retorno['dados']    = $dados;
                        throw new Exception(json_encode($retorno), 1);
                    }

                    if( !isset( $dados['id_contrato'] ) || !is_numeric($dados['id_contrato'] ) || empty( $dados['id_contrato'] ) ){
                        $retorno['codigo']   = 1;
                        $retorno['tipo']     = 'danger';
                        $retorno['mensagem'] = 'Contrato invalido';
                        $retorno['dados']    = $dados;
                        throw new Exception(json_encode($retorno), 1);
                    }

                    if( !isset( $dados['id_produto'] ) || !is_numeric( $dados['id_produto'] ) || empty( $dados['id_produto'] ) ){
                        $retorno['codigo']   = 1;
                        $retorno['tipo']     = 'danger';
                        $retorno['mensagem'] = 'Produto invalido';
                        $retorno['dados']    = $dados;
                        throw new Exception( json_encode( $retorno), 1 );
                    }

                    if( isset( $dados['preco_pkt'] ) ){
                        $preco_pkt = removeCaracteres($dados['preco_pkt'],'moeda2');
                        if(empty($preco_pkt)){
                            $preco_pkt = 0;
                        }

                        if( !is_numeric( $preco_pkt ) ){
                            $retorno['codigo']   = 1;
                            $retorno['tipo']     = 'danger';
                            $retorno['mensagem'] = 'Erro no preço do pacote';
                            $retorno['dados']    = $dados;
                            throw new Exception(json_encode($retorno), 1);
                        }
                    }

                    if( isset( $dados['qdt_garantido'] ) ){
                        $qdt_garantido = removeCaracteres( $dados['qdt_garantido'],'moeda2' );
                        if( !is_numeric( $qdt_garantido ) || empty( $qdt_garantido ) ){
                            $retorno['codigo']   = 1;
                            $retorno['tipo']     = 'danger';
                            $retorno['mensagem'] = 'Informe a quantidade de transações para o pacote';
                            $retorno['dados']    = $dados;
                            throw new Exception(json_encode($retorno), 1);
                        }
                    }

                    if( isset( $dados['status_pacote'] ) && $dados['status_pacote'] == 'ativo' ){
                        $status = 'ativo';
                    }else{
                        $status = 'inativo';
                    }

                    if( isset( $dados['percentual'] ) && !empty( $dados['percentual'] ) ){
                        $percentual = removeCaracteres( $dados['percentual'], 'moeda2' );
                        if( empty( $percentual ) ){
                            $percentual = 0;
                        }

                        if( !is_numeric( $percentual ) ){
                            $retorno['codigo']   = 1;
                            $retorno['tipo']     = 'danger';
                            $retorno['mensagem'] = 'Erro no preço do pacote';
                            $retorno['dados']    = $dados;
                            throw new Exception(json_encode($retorno), 1);
                        }
                    }else{
                        $percentual = 0;
                    }

                    switch ( $dados['flag'] ) {
                        case 'CD':
                            $flag = 'CD';
                        break;
                        case 'RF':
                            $flag = 'RF';
                        break;
                        default:
                            $flag = 'SD';
                        break;
                    }

                    if( isset( $dados['id_pacote'] ) && is_numeric( $dados['id_pacote'] ) ){
                        $pacote     = json_decode($this->controller->modelo->getPacote($dados['id_contrato'], $dados['id_modulo'], true));
                        $id_pacote  = $pacote[0]->id;
                        $param_historico['preco_atual'] = $pacote[0]->preco_pkt;
                        $param_historico['qdt_atual']   = $pacote[0]->qdt_garantido;
                    }else{
                        $pacote     = null;
                        $id_pacote  = null;
                        $param_historico['preco_atual'] = 0;
                        $param_historico['qdt_atual']   = 0;
                    }

                    if( count( $pacote ) > 1 ){
                        $retorno['codigo']   = 1;
                        $retorno['tipo']     = 'danger';
                        $retorno['mensagem'] = 'Pacotes duplicados para esse modulo, verifique com o adm do sistema!';
                        $retorno['dados']    = $dados;
                        throw new Exception(json_encode($retorno), 1);
                    }
                    
                    $param['id_contrato']           = $dados['id_contrato'];
                    $param['id_modulos_tarifaveis'] = $dados['id_modulo'];
                    $param['preco_pkt']             = $preco_pkt;
                    $param['qdt_garantido']         = $qdt_garantido;
                    $param['status']                = $status;
                    $param['flag']                  = $flag;
                    $this->controller->lpModel->setTable( 'pacote_contratado' );	
                    $is_save_pacote = $this->controller->lpModel->save( $param, $id_pacote );
                    if( $is_save_pacote ){
                        $param_historico['tipo_pacote']             = $dados['tipo_pacote'];
                        $param_historico['id_pacote']               = $is_save_pacote;
                        $param_historico['id_contrato']             = $dados['id_contrato'];
                        $param_historico['id_modulos_tarifaveis']   = $dados['id_modulo'];
                        $param_historico['qdt_atualizada']          = $qdt_garantido;
                        $param_historico['preco_atualizado']        = $preco_pkt;
                        $param_historico['percentual']              = $percentual;
                        $param_historico['flag']                    = $flag;
                        $param_historico['tipo_atualizacao']        = $dados['tipo_atualizacao'];
                        return $this->historico( 'pacote', 'save', $param_historico );
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['tipo']     = 'danger';
                        $retorno['mensagem'] = 'Erro ao cadastrar pacote';
                        $retorno['dados']    = $dados;
                        throw new Exception(json_encode($retorno), 1);
                    }
                break;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function historico( $tipo, $action, $dados ){
        try {
            switch ( $tipo ) {
                case 'listaDePreco':
                    $this->controller->modelo->setTable('lp_historico');
                    switch ( $action ) {
                        case 'save':
                            $dados['alterado_por']     = $_SESSION['cmswerp']['userdata']->id;
                            $dados['alterado_em']      = $this->data_atual->format('Y-m-d H:i:s');
                            $dados['deleted']          = 0;
                            $is_save_old = $this->controller->modelo->save( $dados );
                            if( $is_save_old ){
                                $retorno['codigo']   = 0;
                                $retorno['mensagem'] = 'Sucesso';
                                throw new Exception( json_encode( $retorno ), 1 );
                            }else{
                                $retorno['codigo']   = 1;
                                $retorno['mensagem'] = 'Erro ao salvar historico lista de preço';
                                throw new Exception( json_encode( $retorno ), 1 );
                            }
                        break;
                        case 'listar':
                            if( isset( $dados['id_faixa'] ) && !empty( $dados['id_faixa'] ) && is_numeric( $dados['id_faixa'] ) ){
                                $id_faixa = $dados['id_faixa'];
                                $lista_historico = json_decode( $this->controller->modelo->getLpHistorico( $id_faixa ) );
                                if( isset( $lista_historico ) && !empty( $lista_historico ) ){
                                    foreach ( $lista_historico as $key => $value ) {
                                        $value->qtd_de 			 = funcValor( $value->qtd_de, "C", 0 );
                                        $value->qtd_ate 		 = funcValor( $value->qtd_ate, "C", 0 );
                                        $value->valor_antigo 	 = funcValor( $value->valor_antigo, "C", 6 );
                                        $value->valor_atualizado = funcValor( $value->valor_atualizado, "C", 6 );
                                        $value->indice 			 = strtoupper( $value->indice );
                                        if( !empty( $value->percentual ) ){
                                            $value->percentual = funcValor( $value->percentual, "C", 6 );
                                        }
                                        $value->tipo_atualizacao = strtoupper( $value->tipo_atualizacao );
                                        $data_explode 			 = explode( " ", $value->alterado_em );
                                        $value->alterado_em 	 = convertDate( $data_explode[0] )." ".$data_explode[1];
                                        $nome 					 = explode( " ", $value->nome );
                                        $value->nome 			 = strtoupper( $nome[0] );
                                    }
                                    $retorno['codigo'] 	 = 0;
                                    $retorno['input'] 	 = $id_faixa;
                                    $retorno['output'] 	 = $lista_historico;
                                    $retorno['mensagem'] = "Sucesso.";
                                    throw new Exception( json_encode( $retorno ), 1 );
                                }else{
                                    $retorno['codigo'] 	 = 1; 
                                    $retorno['input'] 	 = $id_lp;
                                    $retorno['output'] 	 = null;
                                    $retorno['mensagem'] = "Sem histórico.";
                                    throw new Exception( json_encode( $retorno ), 1 );
                                }
                            }else{
                                $retorno['codigo']   = 1; 
                                $retorno['mensagem'] = "Nenhum historico encontrado";
                                throw new Exception(json_encode($retorno), 1);
                            }
                        break;
                    }
                break;
                case 'pacote':
                    switch ( $action ) {
                        case 'save':
                            $dados['alterado_por']  = $_SESSION['cmswerp']['userdata']->id;
                            $dados['alterado_em']   = $this->data_atual->format('Y-m-d H:i:s');
                            $dados['deleted']       = 0;
                            $this->controller->lpModel->setTable( 'pacote_historico' );
                            $is_save_historico = $this->controller->lpModel->save( $dados );
                            if( $is_save_historico ){
                                $retorno['codigo']   = 0;
                                $retorno['mensagem'] = 'Sucesso';
                                throw new Exception( json_encode( $retorno ), 1 );
                            }else{
                                $retorno['codigo']   = 1;
                                $retorno['mensagem'] = 'Erro ao salvar  historico lista de preço';
                                throw new Exception( json_encode( $retorno ), 1 );
                            }
                        break;
                        case 'listar':
                            if( isset( $dados['id_contrato'] ) && !empty($dados['id_contrato'] ) ){
                                $id_contrato = $dados['id_contrato'];
                            }else{
                                $retorno['codigo']	 = 1; 
                                $retorno['input']	 = $this->parametros;
                                $retorno['output'] 	 = null;
                                $retorno['mensagem'] = "Requisição com erro nos parametros.";
                                throw new Exception(json_encode($retorno), 1);
                            }

                            if( isset( $dados['id_modulo'] ) && !empty( $dados['id_modulo'] ) ){
                                $id_modulo = $dados['id_modulo'];
                            }else{
                                $retorno['codigo']	 = 1; 
                                $retorno['input']	 = $this->parametros;
                                $retorno['output']	 = null;
                                $retorno['mensagem'] = "Requisição com erro nos parametros.";
                                throw new Exception(json_encode($retorno), 1);
                            }
                            $get_pacote = json_decode( $this->controller->modelo->getPacoteHistorico( $id_contrato, $id_modulo) );
                            foreach ( $get_pacote as $key => $value ) {
                                $value->qdt_atual 		 = funcValor( $value->qdt_atual, "C", 0 );
                                $value->qdt_atualizada   = funcValor( $value->qdt_atualizada, "C", 0 );
                                $value->preco_atual 	 = funcValor( $value->preco_atual, "C", 2);
                                $value->preco_atualizado = funcValor( $value->preco_atualizado, "C", 2 );

                                if( !empty( $value->percentual ) ){
                                    $value->percentual = funcValor( $value->percentual, "C", 2 );
                                }

                                if( !empty( $value->tipo_atualizacao ) ){
                                    $value->tipo_atualizacao = strtoupper( $value->tipo_atualizacao );
                                }

                                $data_explode 		= explode(" ", $value->alterado_em );
                                $value->alterado_em = convertDate($data_explode[0])." ".$data_explode[1];
                                $nome 				=	explode( " ", $value->nome );
                                $value->nome 		= strtoupper( $nome[0] );			
                            }
                            
                            if( isset( $get_pacote ) && !empty( $get_pacote ) ){
                                $retorno['codigo'] 	 = 0;
                                $retorno['input']	 = $id_pacote;
                                $retorno['output']   = $get_pacote;
                                $retorno['mensagem'] = "Sucesso.";
                                throw new Exception(json_encode($retorno),1);
                            }else{
                                $retorno['codigo']	 = 1; 
                                $retorno['input']	 = $id_pacote;
                                $retorno['output']	 = null;
                                $retorno['mensagem'] = "Sem histórico.";
                                throw new Exception(json_encode($retorno), 1);
                            }
                        break;
                    }
                break;
            }
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }
}