<?php
	/**
	* Julio	
	* Classe para log de eventos no sistema
	*/

class Consolidador
{
	protected $log;
	protected $obj_movimento;
	protected $obj_contrato;
	protected $contrato;
	protected $date_atual;
	protected $date;
	protected $controller;

	function __construct($controller, $param = null){
		$this->date_atual = new DateTime('now', new DateTimeZone( 'America/Sao_Paulo'));
		//Objeto com acesso a base de dados de cadastros;
		$this->controller = $controller;
		$this->controller->nome_modulo = 'consolidador';
		$this->obj_contrato = $this->controller->load_model('cadastros/cadastros', true);

		//objeto com acesso a base de dados de movimento diario;
		$controller = new MainController();
		$controller->nome_modulo = 'consolidador';
		$controller->Db = new Db(DB_NAME_MOVIMENTO);// Configurando o banco de dados movimento 
		$this->obj_movimento = $controller->load_model('movimento/movimento', true);
	}

	function getMovResumeByDate($date){
		$mov_diario = json_decode($this->obj_movimento->getMovByDate($date));
		if($mov_diario){
			return $mov_diario;
		}else{
			return false;
		}
	}

	function getContratosByCodigo($codigo_cliente)
	{
		$contrato = json_decode($this->obj_contrato->customGetRecords($id =  $codigo_cliente, $type='codigo'));
		if($contrato){
			return $contrato;
		}else{
			return false;
		}
	}

	function setDate($date){
		$this->date = new DateTime($date, new DateTimeZone( 'America/Sao_Paulo'));
	}

	function getDataCorte($dia_corte){
		$ano_mes_corte = $this->date_atual->format('Y-m');
		$data_corte = $ano_mes_corte.'-'.$dia_corte;
		$this->setDate($data_corte);
		return $this->date->format('Y-m-d');
	}

	function calcDataFaturamento($dia_corte){
		$ano_mes_corte = $this->date_atual->format('Y-m');
		$data_corte = $ano_mes_corte.'-'.$dia_corte;
		$this->setDate($data_corte);
		if($this->date->format('l') == 'Saturday'){
			$this->date->add( new DateInterval( "P2D" ) );
		}elseif($this->date->format('l') == 'Sunday'){
			$this->date->add( new DateInterval( "P1D" ) );
		}
		return $this->date->format('Y-m-d');
	}

	function checkExiste($data, $codigo_cliente, $codigo_produto, $codigo_modulo){
		$isCheck = json_decode($this->obj_movimento->getConsolidado($data, $codigo_cliente, $codigo_produto, $codigo_modulo));
		if($isCheck){
			return $isCheck[0]->id_consolidado;
		}else{
			return false;
		}
	}

	function saveConsolidado($dados){
		$this->obj_movimento->insertConsolidado($dados);
	}

	function exec($date){
		$x =0 ;
		$consolidado;
		$mov_diario = $this->getMovResumeByDate($date->format('Y-m-d'));
		if($mov_diario){
			foreach ($mov_diario as $key => $value) {
				
				$contratos_list = $this->getContratosByCodigo($value->codigo_cliente);
				if($contratos_list){
					$consolidado[$x]['data_consolidado'] = $date->format('Y-m-d');	
					$consolidado[$x]['codigo_cliente'] = $contratos_list[0]->codigo_cliente;
					$consolidado[$x]['nome_fantasia'] = $contratos_list[0]->nome_fantasia;
					$consolidado[$x]['nome_produto'] = $contratos_list[0]->nome_produto;
					$consolidado[$x]['codigo_produto'] = $contratos_list[0]->codigo_produto;
					$consolidado[$x]['codigo_modulo'] = $value->codigo_modulo;
					$consolidado[$x]['qtd_transacoes'] = 	$value->qtd_tarifacoes;
					$consolidado[$x]['total_faturamento'] = $value->valor_total_transacoes;
					$consolidado[$x]['data_corte_faturamento'] = $this->getDataCorte($contratos_list[0]->data_corte_faturamento);
					$consolidado[$x]['data_faturamento'] = $this->calcDataFaturamento($contratos_list[0]->numero_dias_apos_corte);
				}
				$x++;
			}
			
			if($consolidado){
				foreach($consolidado as $key => $value){
					$isCheck = $this->checkExiste($date->format('Y-m-d'), $value['codigo_cliente'],$value['codigo_produto'], $value['codigo_modulo']);
					if(!$isCheck){
						$this->saveConsolidado($value);
					}
				}
			}
		}else{
			return false;
		}

	}
}


