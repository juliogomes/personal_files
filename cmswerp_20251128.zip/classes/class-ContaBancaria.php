<?php

class ContaBancaria extends Banco{
	protected $model_conta_bancaria, $tipo_conta, $agencia, $agencia_dig, $conta, $conta_dig, $codigo_convenio;
	function __construct($controller, $cliente = null){
		parent::__construct($controller, $cliente);
		$this->model_conta_bancaria = $this->controller->load_model('contabancaria/contabancaria', true);
		if(is_array($cliente)){
			$cliente = convertToObject($cliente);
		}
		
		if($cliente){
			$this->setConta($cliente);
		}
	}

	function getBanco(){
		return parent::getBanco();
	}

	function getContaBancariaConvenio(){
		return $this->model_conta_bancaria->getContaBancariaConvenio();
	}

	function getContaBancarias($id = null){
		if(is_numeric($id) && $id > 0){
			$id_conta = $id;
		}else{
			$id_conta = null;
		}
		return $this->model_conta_bancaria->getContaBancarias($id_conta);
	}
	
	function getContaByFornecedor($id_fornecedor = null){
		return $this->model_conta_bancaria->getContaByFornecedor($id_fornecedor);
	}

	function getContaByEmpresa($id_empresa, $id_banco = null, $default = true){
		return $this->model_conta_bancaria->getContaByEmpresa($id_empresa, $id_banco, $default);
	}

	function getContaByIdConta($id_conta, $id_banco = null, $default = true){
		return $this->model_conta_bancaria->getContaByIdConta($id_conta, $id_banco, $default);
	}

	function getContaByDespesa($id_despesa){
		return $this->model_conta_bancaria->getContaByDespesa($id_despesa);
	}

	function getContaConvenio(){
		return $this->model_conta_bancaria->getContaConvenio();
	}

	function setConta($cliente){
		if(is_array($cliente)){
			$cliente = convertToObject($cliente);
		}
		$this->tipo_conta      = $cliente->tipo_conta;
		$this->agencia         = $cliente->agencia;
		$this->agencia_dig     = $cliente->agencia_dig;
		$this->conta           = $cliente->conta;
		$this->conta_dig       = $cliente->dig_conta;
		$this->codigo_convenio = $cliente->codigo_convenio;
	}

	// function getconta($id){
	// 	return $this;
	// }
}