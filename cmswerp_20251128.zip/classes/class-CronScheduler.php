<?php
    class CronScheduler{
        public static function calcularProximaExecucao($t)
        {
            $agora = new DateTime();

            switch ($t->tipo_execucao) {

                case 'a_cada_minutos':
                    return self::addMinutos($agora, $t->intervalo_minutos);

                case 'hora':
                    return self::proximaHora($agora, $t->hora_execucao);

                case 'diario':
                    return self::proximoDiario($agora, $t->hora_execucao);

                case 'semanal':
                    return self::proximoSemanal($agora, $t->dias_semana, $t->hora_execucao);

                case 'mensal':
                    return self::proximoMensal($agora, $t->dia_mes, $t->hora_execucao);

                case 'dia_util':
                    return self::proximoDiaUtil($agora, $t->hora_execucao);

                case 'dia_util_mensal':
                    return self::proximoDiaUtilMensal($agora, $t);

                case 'customizado':
                    return self::custom($t);

                default:
                    return null;
            }
        }

        private static function addMinutos($data, $min)
        {
            $d = clone $data;
            $d->modify("+{$min} minutes");
            return $d;
        }

        private static function proximoDiario($agora, $hora)
        {
            $h = new DateTime(date("Y-m-d {$hora}"));
            if ($h <= $agora) $h->modify("+1 day");
            return $h;
        }

        private static function proximaHora($agora, $hora)
        {
            return self::proximoDiario($agora, $hora);
        }

        private static function proximoSemanal($agora, $dias, $hora)
        {
            $dias = explode(',', $dias); // ex: 1,2,3
            sort($dias);

            foreach ($dias as $d) {
                $data = new DateTime("next " . self::diaSemanaNumero($d));
                $data->setTime(
                    substr($hora, 0, 2),
                    substr($hora, 3, 2),
                    0
                );
                if ($data > $agora) return $data;
            }

            // Nenhum dia serviu → pega o primeiro da próxima semana
            $data = new DateTime("next " . self::diaSemanaNumero($dias[0]));
            $data->setTime(substr($hora,0,2), substr($hora,3,2),0);
            return $data;
        }

        private static function diaSemanaNumero($num)
        {
            $map = [
                0=>'sunday',
                1=>'monday',
                2=>'tuesday',
                3=>'wednesday',
                4=>'thursday',
                5=>'friday',
                6=>'saturday'
            ];
            return $map[$num];
        }

        private static function proximoMensal($agora, $diaMes, $hora)
        {
            $m = new DateTime();        
            $m->setDate($m->format('Y'), $m->format('m'), $diaMes);
            $m->setTime(substr($hora,0,2), substr($hora,3,2), 0);

            if ($m <= $agora)
                $m->modify("+1 month");

            return $m;
        }

        private static function proximoDiaUtil($agora, $hora)
        {
            $d = clone $agora;

            do {
                $d->modify("+1 day");
            } while (in_array($d->format("N"), [6,7])); // 6=sab,7=dom

            $d->setTime(substr($hora,0,2), substr($hora,3,2), 0);
            return $d;
        }

        private static function proximoDiaUtilMensal($agora, $t)
        {
            $ano = $agora->format("Y");
            $mes = $agora->format("m");

            $ultimo = new DateTime("last day of {$ano}-{$mes}");
            while (in_array($ultimo->format("N"), [6,7])) {
                $ultimo->modify("-1 day");
            }

            if ($t->regra_dia_util == 'primeiro') {

                $primeiro = new DateTime("first day of {$ano}-{$mes}");
                while (in_array($primeiro->format("N"), [6,7])) {
                    $primeiro->modify("+1 day");
                }

                if ($primeiro <= $agora)
                    return self::proximoDiaUtilMensal($agora->modify("+1 month"), $t);

                $primeiro->setTime(substr($t->hora_execucao,0,2), substr($t->hora_execucao,3,2),0);
                return $primeiro;
            }

            if ($t->regra_dia_util == 'ultimo') {
                if ($ultimo <= $agora)
                    return self::proximoDiaUtilMensal($agora->modify("+1 month"), $t);

                $ultimo->setTime(substr($t->hora_execucao, 0, 2), substr($t->hora_execucao, 3, 2), 0);
                return $ultimo;
            }

            return null;
        }

        private static function custom($t)
        {
            // Ex: você pode criar callbacks internas
            return new DateTime("+1 hour");
        }
    }
