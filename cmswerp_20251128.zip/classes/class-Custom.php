<?php

class Custom extends stdClass
{
    public function __get($name)
    {
        // Se a propriedade não existir, inicializa como um novo stdClass
        if (!isset($this->$name)) {
            $this->$name = new stdClass();
        }
        return $this->$name;
    }
}
