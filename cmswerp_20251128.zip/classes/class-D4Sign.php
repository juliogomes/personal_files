<?php
	/**
	* Caio Freitas
    * 20/07/2022
	* Classe para aprovação em etapas da barra de progresso
	*/    
    class D4Sign extends Assinatura{
        protected
            $allow_files,
            $param_signer,
            $obj_integracao;
            
        function __construct($controller, $codigo = null){
            parent::__construct($controller);
            $this->setListaTipoAssinatura();
            $this->setListaStatusAssinatura();
            $this->setOrdemAssinatura();
            $this->setAllowFile();
            if( $codigo ){
                $this->setIntegracao( $codigo );    
            }
        }

        function setIntegracao($codigo = null){
            if(isset($codigo) && !empty($codigo)){
                $this->obj_integracao = new Integracoes( $this->controller, $codigo );
            }else{
                $this->obj_integracao = new Integracoes( $this->controller, 'D4S001' );
            }
        }

        function getListaTipoAssinatura(){
            return $this->lista_tipos_assinatura;
        }

        function getParam(){
            return $this->param_signer;
        }

        function setListaTipoAssinatura(){
            $this->lista_tipos_assinatura = array(
                '1' => 'Assinar',
                '2' => 'Aprovar',
                '3' => 'Reconhecer',
                '4' => 'Assinar como parte',
                '5' => 'Assinar como testemunha',
                '6' => 'Assinar como interveniente',
                '7' => 'Acusar recebimento',
                '8' => 'Assinar como Emissor, Endossante e Avalista',
                '9' => 'Assinar como Emissor, Endossante, Avalista, Fiador',
                '10' => 'Assinar como fiador',
                '11' => 'Assinar como parte e fiador',
                '12' => 'Assinar como responsável solidário',
                '13' => 'Assinar como parte e responsável solidário'
            );
        }
        
        function setListaStatusAssinatura(){
            $this->lista_status_assinatura = array(
                '1' => 'processando',
                '2' => 'aguardando_signatarios',
                '3' => 'aguardando_assinaturas',
                '4' => 'finalizado',
                '5' => 'arquivado',
                '6' => 'cancelado',
                '7' => 'editando',
            );
        }

        function getlistaStatus($n, $desc = false){
            return $this->lista_status_assinatura;
        }

        function getNomeStatus($n, $desc = false){
            return $this->lista_status_assinatura[$n];
        }

        function getIdStatus($nome, $desc = false){
            return $this->lista_status_assinatura[$n];
        }

        function setOrdemAssinatura(){
            $this->ordem_assinatura = array(
                'accept' => 'Recebimento',
            );
        }

        function getOrdemAssinatura(){
            return $this->ordem_assinatura;
        }

        function setAllowFile(){
            $this->allow_files = array(
                'doc',
                'pdf',
                'docx',
                'jpg',
                'png',
                'bmp'
            );
        }

        function checkDocsAssinados(){
            return $this->obj_integracao->Exec('documento', 'listarDocumentos');
        }

        function setParam($param){

            if(!isset($param['email_assinatura']) || empty($param['email_assinatura'])){
                $this->erro = true;
                $this->info = 'Email do signatario não informado';
                return false;
            }
            if(!isset($param['tipo_assinatura']) || empty($param['tipo_assinatura'])){
                $this->erro = true;
                $this->info = 'Tipo da assinatura não informado';
                return false;
            }

            if(!isset($param['metodo_assinatura']) || empty($param['metodo_assinatura'])){
                $this->erro = true;
                $this->info = 'Metodo da assinatura não informado';
                return false;
            }

            switch ($param['metodo_assinatura']) {
                case 'icp_brasil':
                $param_signer['certificadoicpbr'] = 1;
                break;
                case 'email':
                    $param_signer['embed_methodauth'] = 'email';
                break;
                case 'password':
                    $param_signer['embed_methodauth'] = 'password';
                break;
                case 'sms':
                    $param_signer['embed_methodauth'] = 'sms';
                break;
                case 'whats ':
                    $param_signer['embed_methodauth'] = 'whats ';
                break;
                default:
                    $param_signer['certificadoicpbr'] = 0;
                break;
            }
            $this->param_signer[0]['email']                   = (isset($param['email_assinatura']))?$param['email_assinatura']:null;
            $this->param_signer[0]['act']                     = (isset($param['tipo_assinatura']))?$param['tipo_assinatura']:null;
            $this->param_signer[0]['foreign']                 = (isset($param['foreign']))?$param['foreign']:0;
            $this->param_signer[0]['foreign_lang']            = (isset($param['foreign_lang']))?$param['foreign_lang']:'ptBR';
            $this->param_signer[0]['metodo_assinatura']       = (isset($param['metodo_assinatura']))?$param['metodo_assinatura']:null;
            $this->param_signer[0]['ordem_assinatura']        = (isset($param['ordem_assinatura']))?$param['ordem_assinatura']:null;
            $this->param_signer[0]['assinatura_presencial']   = (isset($param['assinatura_presencial']))?$param['assinatura_presencial']:0;
            $this->param_signer[0]['docauth']                 = (isset($param['docauth']))?$param['docauth']:0;
            $this->param_signer[0]['docauthandselfie']        = (isset($param['docauthandselfie']))?$param['docauthandselfie']:0;
            $this->param_signer[0]['embed_smsnumber']         = (isset($param['telefone']))?$param['telefone']:null;
            $this->param_signer[0]['upload_allow']            = (isset($param['upload_allow']))?$param['upload_allow']:null;
            $this->param_signer[0]['upload_obs']              = (isset($param['upload_obs']))?$param['upload_obs']:null;
            $this->param_signer[0]['after_position']          = (isset($param['ordem_assinatura']))?$param['ordem_assinatura']:null;
            $this->param_signer[0]['skipemail']               = (isset($param['skipemail']))?$param['skipemail']:0;
            $this->param_signer[0]['whatsapp_number']         = (isset($param['whatsapp_number']))?$param['whatsapp_number']:null;
            $this->param_signer[0]['uuid_grupo']              = (isset($param['uuid_grupo']))?$param['uuid_grupo']:null;
            
            $this->param_signer[0]['certificadoicpbr']        = (isset($param_signer['certificadoicpbr']))?$param_signer['certificadoicpbr']:null;
            
            $this->param_signer[0]['certificadoicpbr_tipo']   = (isset($param['certificadoicpbr_tipo']))?$param['certificadoicpbr_tipo']:null;
            $this->param_signer[0]['certificadoicpbr_cpf']    = (isset($param['certificadoicpbr_cpf']))?$param['certificadoicpbr_cpf']:null;
            $this->param_signer[0]['certificadoicpbr_cnpj']   = (isset($param['certificadoicpbr_cnpj']))?$param['certificadoicpbr_cnpj']:null;
            $this->param_signer[0]['password_code']           = (isset($param['password_code']))?$param['password_code']:null;
            $this->param_signer[0]['auth_pix']                = (isset($param['auth_pix']))?$param['auth_pix']:null;
            $this->param_signer[0]['auth_pix_nome']           = (isset($param['auth_pix_nome']))?$param['auth_pix_nome']:null;
            $this->param_signer[0]['auth_pix_cpf']            = (isset($param['auth_pix_cpf']))?$param['auth_pix_cpf']:null;
            $this->param_signer[0]['videoselfie']             = (isset($param['videoselfie']))?$param['videoselfie']:null;
            $this->param_signer[0]['d4sign_score']            = (isset($param['d4sign_score']))?$param['d4sign_score']:null;
            $this->param_signer[0]['d4sign_score_nome']       = (isset($param['d4sign_score_nome']))?$param['d4sign_score_nome']:null;
            $this->param_signer[0]['d4sign_score_cpf']        = (isset($param['d4sign_score_cpf']))?$param['d4sign_score_cpf']:null;
            $this->param_signer[0]['d4sign_score_similarity'] = (isset($param['d4sign_score_similarity']))?$param['d4sign_score_similarity']:null;
        }

        function checkDocumento($document_key){
            if($document_key){
                $retorno_api = json_decode($this->obj_integracao->Exec('documento', 'info', array('document_key' => $document_key)));
                if($retorno_api->codigo == 0){
                    $this->erro   = false;
                    $this->output = $retorno_api->output;
                    return true;
                }else{
                    $this->erro = true;
                    $this->info = $retorno_api->mensagem;
                    return false;
                }
            }else{
                $this->erro = true;
                $this->info = 'Document key não informado para checar o documento';
                return false;
            }
        }

        function chkSigExistInD4Sign($document_key, $dados){
            $chk_assinante = $this->listarSignatarios($document_key);
            if(isset($chk_assinante->output[0]->list)){
                foreach ($chk_assinante->output[0]->list as $key => $value) {
                    if($value->email == $dados['email_assinatura']){
                        $this->erro   = false;
                        $this->output = $value->key_signer;
                        return true;
                    }
                }
                return false;
            }else{
                return false;
            }
        }

        function checkSignExistInBdByKey($document_key){
            return json_decode($this->controller->modelo->gedAnexosToAssinaturaByKey($document_key));
        }

        function addSignatario($document_key, $dados = null){
            $this->checkDocumento($document_key);
            if( $this->output[0]->statusId > 2 ){
                $this->erro = true;
                $this->info = 'Não é possivel add signatario para o documento na fase: '.$this->output[0]->statusName;
                return false;
            }

            $chk_assinante = $this->listarSignatarios($document_key);
            if(isset($chk_assinante->output[0]->list)){
                foreach ($chk_assinante->output[0]->list as $key => $value) {
                    if($value->email == $dados['email_assinatura']){
                        $this->erro = true;
                        $this->info = 'O email '.$value->email.' já está incluido para assinar o documento!';
                        return false;
                    }
                }
            }
            
            $retorno_api = json_decode($this->obj_integracao->Exec('signatario', 'criar', array('document_key' => $document_key, 'signers' => $this->param_signer)));
            if($retorno_api->codigo == 0){
                if(isset($retorno_api->output->message[0]->key_signer)){
                    $this->output = $retorno_api->output->message[0]->key_signer;
                    return $retorno_api;
                }else{
                    $this->erro = true;
                    $this->info = $retorno_api->mensagem." / ".$this->param_signer[0]['email'];
                    return false;    
                }
            }else{
                $this->erro = true;
                $this->info = $retorno_api->output->message[0]->status." / ".$this->param_signer[0]['email'];
                return false;
            }
        }
        
        function listarSignatarios( $document_key ){
            $retorno_api = json_decode($this->obj_integracao->Exec('documento', 'listarSignatarios', array('document_key' => $document_key)));        
            if($retorno_api->codigo == 0){
                $this->erro = false;
                $this->output = $retorno_api->output;
                return $retorno_api;    
            }else{
                $this->erro = true;
                $this->info = 'Erro ao add signatario';
                return false;
            }
        }

        function enviarParaAssinatura($documento, $extra = null){
            if($documento->document_key){
                if($this->checkDocumento($documento->document_key)){
                    $documento->statusId = $this->output[0]->statusId;
                    $documento->status   = $this->lista_status_assinatura[3];
                    switch ($this->output[0]->statusId) {
                        case '2':
                            $param['document_key'] = $documento->document_key;
                            $param['skip_email']   = $extra['skip_email'];
                            $param['workflow']     = $extra['workflow'];
                            $param['message']      = $extra['message'];
                            return json_decode($this->obj_integracao->Exec('documento', 'enviarAssinatura', $param));
                        break;
                        case '3':
                            $signatarios  = json_decode($this->controller->modelo->getSignatarios($documento->document_key));
                            if($signatarios){
                                foreach ($signatarios as $key => $value) {
                                    if(!$this->reenviarEmail($documento->document_key, $value->email_assinante)){
                                        return false;
                                    }
                                }
                            }else{
                                $this->erro = 'Nenhum signatario encontrado';
                                $this->info = $signatarios;
                                return false;
                            }
                            return true;
                        break;
                        default:
                            $this->erro = 'Não é possivel enviar para assinatura o documento na fase: '.$this->lista_status_assinatura[ $this->output[0]->statusId ];
                            $this->info = $documento;
                            return false;
                        break;
                    }
                }else{
                    return false;    
                }
            }else{
                $this->info = null;
                $this->erro = 'Document KEY não informado';
                return false;
            }
        }

        function reenviarEmail($document_key, $email){
            $param['document_key']  = $document_key;
            $param['email']         = $email;
            $retorno_api            = json_decode($this->obj_integracao->Exec('documento', 'reenviarLinkAssinatura', $param));
            if($retorno_api->codigo == 0){
                $this->erro   = false;
                $this->info   = 'Sucesso';
                return true;  
            }else{
                $this->erro = $retorno_api->output->message;
                $this->info = $retorno_api->output;
                return false;    
            }
        }

        function checkExtArquivo($ext){
            if(array_search($ext, $this->allow_files)){
                return true;
            }else{
                return false;
            } 
        }

        function checkFolderExist($nome_pasta, $id_cofre = null){
            if(!$id_cofre){
                $id_cofre = $this->obj_integracao->getPathRoot();
            }
            $lista_pasta = json_decode($this->obj_integracao->Exec('pastas', 'listar', array('id_cofre' => $id_cofre)));
            if($lista_pasta->codigo == 0){
                foreach ($lista_pasta->output as $key => $value) {
                    if($value->name == $nome_pasta){
                        $this->output = $value;
                        return true;
                    }
                }
                return false;
            }else{
                $this->erro = true;
                if(isset($lista_pasta->output->error)){
                    $this->info = $lista_pasta->mensagem;    
                }else{
                    $this->info = $lista_pasta->mensagem;
                }
                return false;    
            }
        }
        
        function createFolder($cpf){
            $retorno_api = json_decode($this->obj_integracao->Exec('pastas', 'criar', array('folder_name' => $cpf)));
            if($retorno_api->codigo == 0){
                $this->erro   = false;
                $this->output = $retorno_api->output;
                $this->info   = 'Diretorio criado';
                return true;
            }else{
                $this->erro = true;
                $this->info = $retorno_api->mensagem;          
                return false;
            }
        }

        function upload($documento){
            $ext = pathinfo($documento->nome_documento, PATHINFO_EXTENSION);
            if($this->checkExtArquivo($ext)){
                if(!$this->checkFolderExist($documento->cpf_owner)){ 
                    if(!$this->createFolder($documento->cpf_owner)){    
                        $this->erro = true;
                        $this->info = $this->output->mensagem_pt;
                        $retorno->codigo = 1;
                        $retorno->mensagem = "Erro ao criar diretório D4Sing";
                        $retorno->input = null;
                        $retorno->output =  $this->info;
                        return  $retorno;
                    }
                }
                if(!isset($this->output->uuid_folder) || empty($this->output->uuid_folder)){
                    $this->output->uuid_folder = $this->output->uuid;
                }

                if(isset($this->output->uuid_folder)){
                    $path_file = $documento->path_root.DS.$documento->path_objeto.$documento->nome_hash;
                    // $path_file = 'C:\Users\julio.gomes\Documents\projetos\tarifador\web\www_producao_20221213\dir_ged\pessoal/'.$documento->path_objeto.'/'.$documento->nome_hash;
                    $mime_type = mime_content_type($path_file);
                    $param_upload = array(
                        'id_cofre'    => $this->obj_integracao->getPathRoot(),
                        'file'        => $path_file,
                        'mime_type'   => $mime_type, 
                        'uuid_folder' => $this->output->uuid_folder
                    );                
                    $retorno_api = json_decode($this->obj_integracao->Exec('documento', 'upload', $param_upload));
                    if($retorno_api->codigo == 0){
                        $this->erro   = false;
                        $this->output = $retorno_api;
                        $this->info   = 'Sucesso';        

                        return $retorno_api;  
                    }else{                    
                        $retorno->codigo = 1;
                        $retorno->mensagem = $retorno_api->output->message;
                        $retorno->input = $retorno_api->output;
                        $retorno->output =  $retorno_api->input;
                        $this->erro = true;
                        $this->info = $retorno_api->mensagem;     
                                    
                        return $retorno;    
                    }
                }else{
                    $retorno_api->mensagem = 'Erro ao encontrar UIID do diretorio';
                    $this->erro = true;
                    $this->info = 'Erro ao encontrar UIID do diretorio';
                    return $retorno_api;
                }
            }else{
                $retorno_api->mensagem = 'Tipo de arquivo permitido';
                $this->erro = true;
                $this->info = 'Tipo de arquivo permitido';
                return $retorno_api;
            }
        }

        function anexarDocumento($documento, $documento_key, $path_file = null, $tipo = null){
            if(isset($documento->nome_documento) && !empty($documento->nome_documento)){            
                $ext = pathinfo($documento->nome_documento, PATHINFO_EXTENSION);
            }else{            
                $ext = pathinfo($path_file, PATHINFO_EXTENSION);
            }        
            if($this->checkExtArquivo($ext)){           
                if(!isset($path_file) || empty($path_file)){  
                    if($tipo == "proposta"){                       
                        $path_file = $documento->path_root.$documento->path_objeto.$documento->nome_hash;
                    }else{
                        $path_file = $documento->path_root.DS.$documento->path_objeto.$documento->nome_hash;
                    }
                }else{
                    $path_file = $path_file;
                }           
                $mime_type = mime_content_type($path_file);
                $param = array(
                    'id_cofre'      => $this->obj_integracao->getPathRoot(),
                    'file'          => $path_file,
                    'mime_type'     => $mime_type,    
                    'key_documento' => $documento_key,                 
                );      
                    
                $retorno_api = json_decode($this->obj_integracao->Exec('documento', 'upload_anexo', $param)); 
                if($retorno_api->codigo == 0){
                    $retorno['codigo']   = 0;
                    $retorno['output']   = $retorno_api;
                    $retorno['input']    = $documento;
                    $retorno['mensagem'] = "Sucesso"; 
                    $this->erro   = false;
                    $this->output = $retorno_api;
                    $this->info   = 'Sucesso';
                    return $retorno;  
                }else{   
                    $retorno['codigo']   = 1;
                    $retorno['output']   = $retorno_api;
                    $retorno['input']    = $documento;
                    $retorno['mensagem'] = $retorno_api->output->mensagem;                    
                    $this->erro = true;
                    $this->info = $retorno_api->mensagem;                            
                    return $retorno;    
                }           
            }else{   
                
                $retorno_api->mensagem = 'Tipo de arquivo permitido';
                $this->erro = true;
                $this->info = 'Tipo de arquivo permitido';
                $retorno['codigo']   = 1;
                $retorno['output']   = $retorno_api;
                $retorno['input']    = $documento;
                $retorno['mensagem'] = 'Tipo de arquivo permitido';
                return $retorno;
            }
        }

        function download($document_key){
            $retorno_api = json_decode($this->obj_integracao->Exec('documento', 'download', array('document_key' => $document_key)));       
            if($retorno_api->codigo == 0){
                $this->erro   = false;
                $this->output = $retorno_api->output;
                return $this->output; 
            }else{
                $this->erro = true;
                $this->info = $retorno_api->mensagem;
                return false;    
            }
        }

        function cancelarDocumento( $document_key ){
            try{
                $retorno_api = json_decode($this->obj_integracao->Exec('documento', 'cancelar', array('document_key' => $document_key)));                      
                if($retorno_api->codigo == 0){
                    $this->erro   = false;
                    $this->output = $retorno_api->output;                
                    $retorno['codigo']  = 0;
                    $retorno['input']   = $document_key;
                    $retorno['output']  = $retorno_api->output;
                    $retorno['mensagem']= "Sucesso";
                    throw new Exception(json_encode($retorno), 1);
                }else{
                    $this->erro = true;
                    $this->info = $retorno_api->mensagem;
                    $retorno['codigo']  = 1;
                    $retorno['input']   = $document_key;
                    $retorno['output']  = $retorno_api;
                    $retorno['mensagem']= $retorno_api->mensagem;
                    throw new Exception(json_encode($retorno), 1);                  
                }
            }catch(Exception $e){
                return $e->getMessage();
            }
        }

        function saveDocAssBd($dados, $id = null){
            $this->controller->modelo->setTable('ged_clicksign_documento');
            return $this->controller->modelo->save($dados, $id);
        }

        function saveAnexoAssBd($dados, $id = null){
            $this->controller->modelo->setTable('ged_clicksign_assinatura');
            return $this->controller->modelo->save($dados, $id);
        }
        
        function listTodosDocumentos($page = null){
            return $this->obj_integracao->Exec('documento', 'listarDocumentos', array('page' => $page));
        }
        
        function listarCofres(){
            return json_decode($this->obj_integracao->Exec('cofre', 'listar'));
        }

        function viewDocumento($id_documento){
            return $this->obj_integracao->Exec('documento', 'download', array('document_key' => $id_documento));
        }

        function viewDocumentoPorStatus($status_doc){
            return $this->obj_integracao->Exec('documento', 'listarDocumentosPorStatus', array('status_doc' => $status_doc));
        }

        function listarDocumentosCofre($id_cofre, $id_pasta = null){
            $parametros = array(
                'id_cofre' => $id_cofre,
                'id_pasta' => $id_pasta,
            );
            return $this->obj_integracao->Exec('cofre', 'listarDocumentos', $parametros);
        }

        function listarPastasCofre($id_cofre){
            return $this->obj_integracao->Exec('cofre', 'pastas', array('id_cofre' => $id_cofre));
        }

        //By: Caio Freitas - 28/11/2022
        function saveFile($url = null, $file_name = null, $cnpj = null){
            try{          
                $url       = $url;
                $file_name = $file_name;
                    
                $fp        = fopen($file_name, 'wb');
                $curl_options[CURLOPT_URL]           = $url;
                $curl_options[CURLOPT_CUSTOMREQUEST] = 'GET';
                $curl_options[CURLOPT_POSTFIELDS]    = 'FALSE';
                $curl_options[CURLOPT_FILE]          = $fp;
                $curl_options[CURLOPT_HEADER]        = '0';

                $upload = CurlExec($url, null, $curl_options);           
                fclose($fp);

                if($upload){
                    if(!file_exists(UP_GED.DS.'clientes'.DS.$cnpj.DS)){
                        mkdir(UP_GED.DS.'clientes'.DS.$cnpj.DS);
                    }
                    rename($file_name, UP_GED.DS.'clientes'.DS.$cnpj.DS.$file_name);
                    if(file_exists(UP_GED.DS.'clientes'.DS.$cnpj.DS.$file_name)){
                        $retorno['codigo']  = 0;
                        $retorno['status']  = 'ok';
                        $retorno['output']  = $upload;
                        $retorno['mensagem']= "Sucesso";
                        throw new Exception(json_encode($retorno), 1);
                    }else{
                        $retorno['codigo']  = 1;
                        $retorno['status']  = 'error';
                        $retorno['output']  = null;
                        $retorno['mensagem']= 'Erro ao savar arquivo';
                        throw new Exception(json_encode($retorno), 1);
                    }
                }else{
                    $retorno['codigo']  = 1;
                    $retorno['status']  = 'error';
                    $retorno['output']  = null;
                    $retorno['mensagem']= 'Erro ao fazer upload do arquivo';
                    throw new Exception(json_encode($retorno), 1);
                }

            }catch(Exception $e){
                return $e->getMessage();
            }
        }
        
        function webhook($document_key){
            $retorno_api = json_decode($this->obj_integracao->Exec('documento', 'cadastrarWebhook', array('document_key' => $document_key)));       
            if($retorno_api->codigo == 0){
                $this->erro   = false;
                $this->output = $retorno_api->output;
                $this->info   = 'Webhook criado';
                return true;
            }else{
                $this->erro = true;
                $this->info = $retorno_api->mensagem;          
                return false;
            }
        }

        function listWebhook($document_key){
            $retorno_api = json_decode($this->obj_integracao->Exec('documento', 'listWebhook', array('document_key' => $document_key)));
            if($retorno_api->codigo == 0){
                $this->erro   = false;
                $this->output = $retorno_api->output;
                $this->info   = 'Webhook criado';
                return true;
            }else{
                $this->erro = true;
                $this->info = $retorno_api->mensagem;          
                return false;
            }
        }
        
        
    }