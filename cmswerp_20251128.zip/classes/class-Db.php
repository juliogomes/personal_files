<?php
class Db
{
	/** DB properties */
	public
		$host      = null, // Host da base de dados
		$last_query = null,
		$port      = null, // Host da base de dados
		$db_name   = null,   // Nome do banco de dados
		$password  = null,          // Senha do usuário da base de dados
		$user      = null,      // Usuário da base de dados
		$charset   = null,      // Charset da base de dados
		$pdo       = null,        // Nossa conexão com o BD
		$error     = null,        // Configura o erro
		$debug     = true,       // Mostra todos os erros
		$log	   = null,
		$last_id   = null,        // Último ID inserido
		$prepare   = null;
	private $hoje;
	/**
	 * Construtor da classe
	 *
	 * @since 0.1
	 * @access public
	 * @param string $host
	 * @param string $db_name
	 * @param string $password
	 * @param string $user
	 * @param string $charset
	 * @param string $debug
	 */
	public function __construct($parametros = null)
	{
		$this->hoje = date('Y-m-d H:m:s');
		// Configura as propriedades novamente.
		// Se você fez isso no início dessa classe, as constantes não serão
		// necessárias. Você escolhe...
		$this->db_name    = !empty($parametros['db_name']) ? $parametros['db_name'] : DB_NAME;
		$this->host       = !empty($parametros['host']) ? $parametros['host'] : HOSTNAME;
		$this->port       = !empty($parametros['port']) ? $parametros['port'] : DB_PORT;
		$this->user       = !empty($parametros['user']) ? $parametros['user'] : DB_USER;
		$this->password   = !empty($parametros['password']) ? $parametros['password'] : DB_PASSWORD;
		$this->charset    = !empty($parametros['charset']) ? $parametros['charset'] : DB_CHARSET;
		$this->debug      = !empty($parametros['debug']) ? $parametros['debug'] : DEBUG;
		// exit;
		// Conecta
		$this->connect();
	} // __construct
	/**
	 * Cria a conexão PDO
	 *
	 * @since 0.1
	 * @final
	 * @access protected
	 */
	final protected function connect()
	{
		/* Os detalhes da nossa conexão PDO */
		$pdo_details  = "mysql:host={$this->host};";
		if ($this->port) {
			$pdo_details  .= "port={$this->port};";
		} else {
			$pdo_details  .= "port=3306;";
		}
		$pdo_details .= "dbname={$this->db_name};";
		$pdo_details .= "charset={$this->charset};";
		// Tenta conectar
		try {

			// $test = @fsockopen($this->host, $this->port, $errno, $errstr, 2);
			// if (!$test) {
			// 	throw new PDOException("⚠️ Servidor MySQL inacessível");
			// }
			// fclose($test);

			// stream_set_timeout($test, 1);
			// $handshake = fread($test, 4); // lê primeiros bytes da resposta
			// fclose($test);

			// if (strlen($handshake) > 0) {
			// } else {
			// 	throw new PDOException("⚠️ Porta aberta, mas MySQL não respondeu (pode estar travado ou desligado).");
			// }

			$this->pdo = new PDO(
				$pdo_details,
				$this->user,
				$this->password,
				[
					PDO::ATTR_PERSISTENT => true,
				]
			);
			$this->pdo->setAttribute(PDO::ATTR_AUTOCOMMIT, 1);
			//$this->pdo = new PDO($pdo_details, $this->user, $this->password);
			// Verifica se devemos debugar
			if ($this->debug === true) {
				// Configura o PDO ERROR MODE
				$this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
			}
			// Não precisamos mais dessas propriedades
			// unset( $this->host     );
			// unset( $this->db_name  );
			// unset( $this->password );
			// unset( $this->user     );
			// unset( $this->charset  );

		} catch (PDOException $e) {
			// Verifica se devemos debugar
			if ($this->debug === true) {
				// Mostra a mensagem de erro
				echo "Erro 1: " . $e->getMessage();
			}
			// Kills the script
			die('Erro DB');
		} finally {
		}
	} // connect
	/**
	 * query - Consulta PDO
	 *
	 * @since 0.1
	 * @access public
	 * @return object|bool Retorna a consulta ou falso
	 */
	public function getDbName()
	{
		return $this->db_name;
	}

	public function query($stmt, $data_array = null)
	{
		//Prepara e executa
		$start 		= microtime(true);
		$query      = $this->pdo->prepare($stmt);
		$check_exec = $query->execute($data_array);
		$elapsed 	= microtime(true) - $start;
		if (DB_MONITORING) {
			$userId		= (isset($_SESSION['cmswerp']['userdata']->id)) ? $_SESSION['cmswerp']['userdata']->id : null;
			$userNome	= (isset($_SESSION['cmswerp']['userdata']->nome)) ? $_SESSION['cmswerp']['userdata']->nome : null;
			$file_name  = ABSPATH . '/logs/debug/query.txt';
			$fp 	    = fopen($file_name, 'a+');
			fwrite($fp, "[Data: $this->hoje User: $userId - $userNome] [SQL] {$stmt} tempo: " . number_format($elapsed, 4) . "s" . "\n");
			fclose($fp);
		}

		// Verifica se a consulta aconteceu
		if ($check_exec) {
			// Retorna a consulta
			if (empty($query->rowCount())) {
				// echo "A";
				return false;
			} else {
				// echo "B";
				return $query;
			}
		} else {
			// Configura o erro
			$error            = $query->errorInfo();
			$this->last_query = $stmt;
			$this->error 	  = $error[2];
			// Retorna falso
			return false;
		}
	}
	/**
	 * insert - Insere valores
	 *
	 * Insere os valores e tenta retornar o último id enviado
	 *
	 * @since 0.1
	 * @access public
	 * @param string $table O nome da tabela
	 * @param array ... Ilimitado número de arrays com chaves e valores
	 * @return object|bool Retorna a consulta ou falso
	 */
	public function insert($table)
	{
		// Configura o array de colunas
		$cols = array();
		// Configura o valor inicial do modelo
		$place_holders = '(';
		// Configura o array de valores
		$values = array();
		// O $j will assegura que colunas serão configuradas apenas uma vez
		$j = 1;
		// Obtém os argumentos enviados
		$data = func_get_args();
		// É preciso enviar pelo menos um array de chaves e valores
		if (! isset($data[1]) || ! is_array($data[1])) {
			return;
		}

		// Faz um laço nos argumentos
		for ($i = 1; $i < count($data); $i++) {
			// Obtém as chaves como colunas e valores como valores
			foreach ($data[$i] as $col => $val) {
				// A primeira volta do laço configura as colunas
				if ($i === 1) {
					$cols[] = "`$col`";
				}
				if ($j <> $i) {
					// Configura os divisores
					$place_holders .= '), (';
				}
				// Configura os place holders do PDO
				$place_holders .= '?, ';
				// Configura os valores que vamos enviar
				$values[] = $val;
				$j = $i;
			}
			// Remove os caracteres extra dos place holders
			$place_holders = substr($place_holders, 0, strlen($place_holders) - 2);
		}
		// $place_holders .= " ,?, ?";
		// Separa as colunas por vírgula
		//array_push($cols, $this->hoje, $_SESSION['cmswerp']['userdata']->id);
		$cols = implode(', ', $cols);
		//incluindo owner

		// $cols .= " , owner ";
		// $place_holders .= " ,?";
		// $values[] = $_SESSION['cmswerp']['userdata']->id;

		//inclui os dados de sessão
		if (!array_key_exists("alterado_por", $data[1])) {
			$cols .= " , alterado_por";
			$place_holders .= " ,?";
			if (isset($_SESSION['cmswerp']['userdata']->id)) {
				$values[] = $_SESSION['cmswerp']['userdata']->id;
			} else {
				$values[] = null;
			}
		}

		if (!array_key_exists("alterado_em", $data[1])) {
			$cols .= " , alterado_em ";
			$place_holders .= " ,?";
			$values[] = $this->hoje;
		}

		// $cols .= " , alterado_em, alterado_por ";
		// Cria a declaração para enviar ao PDO
		$stmt = "INSERT INTO `$table` ( $cols ) VALUES $place_holders) ";
		// INSERT INTO cust (ID, ORDERS) VALUES (7214, 5) ON DUPLICATE KEY UPDATE ORDERS = VALUES(ORDERS) + 1;
		// Insere os valores
		$insert = $this->query($stmt, $values);
		// Verifica se a consulta foi realizada com sucesso
		if ($insert) {
			// Verifica se temos o último ID enviado
			if ($this->pdo->lastInsertId()) {
				// Configura o último ID
				$this->last_id = $this->pdo->lastInsertId();
			}
			// Retorna a consulta
			return $this->last_id;
		}
		// The end :)
		return;
	} // insert
	/**
	 * Update simples
	 *
	 * Atualiza uma linha da tabela baseada em um campo
	 *
	 * @since 0.1
	 * @access protected
	 * @param string $table Nome da tabela
	 * @param string $where_field WHERE $where_field = $where_field_value
	 * @param string $where_field_value WHERE $where_field = $where_field_value
	 * @param array $values Um array com os novos valores
	 * @return object|bool Retorna a consulta ou falso
	 */
	public function update($table, $where_field, $where_field_value, $values)
	{
		// Você tem que enviar todos os parâmetros
		if (empty($table) || empty($where_field) || empty($where_field_value)) {
			return;
		}

		// Começa a declaração
		$stmt = " UPDATE `$table` SET ";
		// Configura o array de valores
		$set = array();
		// Configura a declaração do WHERE campo=valor
		if (is_array($where_field) && is_array($where_field_value)) {
			$where  = " WHERE ";
			$where .= implode(' and ', $where_field);
			if (count($where_field) == count($where_field_value)) {
				$where = " WHERE ";
				for ($i = 0; $i < count($where_field); $i++) {
					if ((count($where_field) - 1) == $i) {
						$where .= $where_field[$i] . " = '" . $where_field_value[$i] . "' ";
					} else {
						$where .= $where_field[$i] . " = '" . $where_field_value[$i] . "' and ";
					}
				}
			} else {
				return;
			}
		} elseif (!is_array($where_field) && is_array($where_field_value)) {
			$where  = " WHERE $where_field in (";
			$where .= implode(',', $where_field_value) . ')';
		} else {
			$where = " WHERE `$where_field` = ? ";
		}

		// Você precisa enviar um array com valores
		if (! is_array($values)) {
			return;
		}

		// Configura as colunas a atualizar
		foreach ($values as $column => $value) {
			$set[] = " `$column` = ?";
		}

		// Separa as colunas por vírgula
		$set = implode(', ', $set);
		// $set .= " , alterado_em = ?, alterado_por = ? ";

		// Garante apenas números nas chaves do array
		if (!array_key_exists('alterado_por', $values)) {
			$set .= " , alterado_por = ?";
			if (isset($_SESSION['cmswerp']['userdata']->id)) {
				$values['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
			} else {
				$values['alterado_por'] = null;
			}
		}

		if (!isset($values['alterado_em'])) {
			$set .= " , alterado_em = ? ";
			$values['alterado_em'] = $this->hoje;
		}

		$values = array_values($values);
		// Configura o valor do campo que vamos buscar
		if (!is_array($where_field_value)) {
			$values[] = $where_field_value;
		}

		// Concatena a declaração
		$stmt .= $set . $where;
		// Atualiza
		$update = $this->query($stmt, $values);
		// Verifica se a consulta está OK
		if ($update) {
			// Retorna a consulta
			return $update;
		}
		// The end :)
		return;
	} // update

	/**
	 * Delete
	 *
	 * Deleta uma linha da tabela
	 *
	 * @since 0.1
	 * @access protected
	 * @param string $table Nome da tabela
	 * @param string $where_field WHERE $where_field = $where_field_value
	 * @param string $where_field_value WHERE $where_field = $where_field_value
	 * @return object|bool Retorna a consulta ou falso
	 */
	// public function delete( $table, $where_field, $where_field_value ) {
	// 	// Você precisa enviar todos os parâmetros
	// 	if ( empty($table) || empty($where_field) || empty($where_field_value)  ) {
	// 		return;
	// 	}
	// 	// Inicia a declaração
	// 	$stmt = "DELETE FROM `$table` ";
	// 	// Configura a declaração WHERE campo=valor
	// 	$where = " WHERE `$where_field` = ? ";
	// 	// Concatena tudo
	// 	$stmt .= $where;
	// 	// O valor que vamos buscar para apagar
	// 	$values = array( $where_field_value );
	// 	// Apaga
	// 	$delete = $this->query( $stmt, $values );
	// 	// Verifica se a consulta está OK
	// 	if ( $delete ) {
	// 		// Retorna a consulta
	// 		return $delete;
	// 	}
	// 	// The end :)
	// 	return;
	// } // delete

	function exec($stmt, $data_array = null, $tp_retorno = 'json')
	{
		$exec = $this->query($stmt, $data_array);
		// $exec = $this->query(mysql_real_escape_string(addslashes($stmt)), $data_array);
		if ($exec) {
			// Retorna
			$return = $exec->fetchAll(PDO::FETCH_ASSOC);
			if ($tp_retorno == 'json') {
				return json_encode($return);
			} else {
				return $return;
			}
		} else {
			return false;
		}
	}
}
