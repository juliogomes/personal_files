<?php
	/**
	* Julio
	* Classe para log de eventos no sistema
	*/
class Despesas extends Main{
	
	function __construct($controller){
		$this->controller = $controller;
	}

	function insert($param, $id = null){
		try {
			switch ($param["meio_pagamento"]) {
                case "boleto_cc":
                    $codigo_barras = removeCaracteres(trim($param["codigo_barra"]),"all");
                    $tam_cb = strlen($codigo_barras);
                    if ($param["tipo_despesa"] == "tributo") {
                        if ($tam_cb != 48) {
                            $retorno["codigo"]   = 1;
                            $retorno["input"]    = $param;
                            $retorno["output"]   = $codigo_barras;
                            $retorno["mensagem"] = "Codigo de barras parece estar inválido para pagamento de tributos";
                            throw new Exception(json_encode($retorno), 1);
                        }
                    } else {
                        if ($param["tipo_cobranca"] == "concessionaria") {
                            if ($tam_cb != 48) {
                                $retorno["codigo"]   = 1;
                                $retorno["input"]    = $param;
                                $retorno["output"]   = $codigo_barras;
                                $retorno["mensagem"] ="Codigo de barras parece estar inválido para pagamento de tributos";
                                throw new Exception(json_encode($retorno), 1);
                            }
                        } else {
                            if ($tam_cb != 47) {
                                $retorno["codigo"]   = 1;
                                $retorno["input"]    = $param;
                                $retorno["output"]   = $codigo_barras;
                                $retorno["mensagem"] ="Codigo de barras parece estar inválido para pagamento de fornecedores";
                                throw new Exception(json_encode($retorno), 1);
                            }
                        }
                    }

                    if (empty($codigo_barras)) {
                        $retorno["codigo"]   = 1;
                        $retorno["input"]    = $param;
                        $retorno["output"]   = $codigo_barras;
                        $retorno["mensagem"] = "Informe o codigo de barras";
                        throw new Exception(json_encode($retorno), 1);
                    }

                    if (!is_numeric($codigo_barras)){
                        $retorno["codigo"]   = 1;
                        $retorno["input"]    = $param;
                        $retorno["output"]   = $codigo_barras;
                        $retorno["mensagem"] = "Codigo de barras deve ser numerico";
                        throw new Exception(json_encode($retorno), 1);
                    }
                    break;
                case "transferencia":
                    $conta_fornecedor = json_decode($this->controller->objContabancaria->getContaByFornecedor($param["id_fornecedor"]));
                    if($id){
						$conta_despesa    = json_decode($this->controller->objContabancaria->getContaByDespesa($id));
					}
                   
					if (!$conta_fornecedor && !$conta_despesa) {
                        if (empty($codigo_barras)) {
                            $retorno["codigo"] = 1;
                            $retorno["tipo"] = "error";
                            $retorno["input"] = $param;
                            $retorno["output"] = null;
                            $retorno["mensagem"] = "Este fornecedor não possui conta bancaria cadastrada";
                            throw new Exception(json_encode($retorno), 1);
                        }
                    }
                    break;
                case "pix":
                    $conta_fornecedor = json_decode($this->objContabancaria->getContaByFornecedor($param["id_fornecedor"],true));
					$conta_despesa = json_decode($this->objContabancaria->getContaByDespesa($id, true));
                    
					if (!$conta_fornecedor && !$conta_despesa) {
                        $retorno["codigo"]   = 1;
                        $retorno["input"]    = $param;
                        $retorno["output"]   = null;
                        $retorno["mensagem"] = "Nenhuma chave pix cadastrada para este fornecedor";
                        throw new Exception(json_encode($retorno), 1);
                    }
                    break;
                case "guia_recolhimento":
                    switch ($param["tipo_cobranca"]) {
                        case "gps":
                        case "gps_parc":
                        case "darf_normal":
                        case "darf_simples":
                            $identificacao_contribuinte = trim(removeCaracteres($param["identificacao_contribuinte"],"char"));
                            // var_dump($identificacao_contribuinte);
                            if (empty($identificacao_contribuinte)) {
                                $retorno["codigo"] = 1;
                                $retorno["tipo"] = "error";
                                $retorno["input"] = $param;
                                $retorno["output"] = $identificacao_contribuinte;
                                $retorno["mensagem"] ="Informe o identificador do contribuinte";
                                throw new Exception(json_encode($retorno), 1);
                            }

                            if (!is_numeric($identificacao_contribuinte)) {
                                $retorno["codigo"] = 1;
                                $retorno["tipo"] = "error";
                                $retorno["input"] = $param;
                                $retorno["output"] = $identificacao_contribuinte;
                                $retorno["mensagem"] ="identificador do contribuinte deve ser numerico";
                                throw new Exception(json_encode($retorno), 1);
                            }
                            break;
                    }
                    break;
            }

           

			if(!isset($param["data_vencimento"]) || empty($param["data_vencimento"])){
                $retorno["codigo"]   = 1;
                $retorno["input"]    = $param;
                $retorno["output"]   = null;
                $retorno["mensagem"] = "Informe a data de vencimento";
                throw new Exception(json_encode($retorno), 1);
            }else{
                $param_save["data_vencimento"] = convertDate($param["data_vencimento"]);
				$obj_dt_vencimento        = getDataAtual($param["data_vencimento"]);
				$dif_dias = $this->controller->data_hora_atual->diff($obj_dt_vencimento);
            }

           

			// Regra desativada temporariamente
			// if($dif_dias->days < 10){
			// 	$msg = base64_encode('Necessario no minimo mais de quinze dias para a data de vencimento, quantidade dias = '.$dif_dias->days);
			// }

			if (isset($param["periodo_apuracao"]) && !empty($param["periodo_apuracao"])){
                $param_save["periodo_apuracao"] = convertDate( $param["periodo_apuracao"]);
            }

            
            $param['valor'] = str_replace("R$","",$param['valor']);          
            if (isset($param["valor"]) && removeCaracteres(trim($param["valor"]), "moeda2") > 0){
				$param_save["valor"] = removeCaracteres(trim($param["valor"]), "moeda2");
            } else {               
                $retorno["codigo"]   = 1;
                $retorno["tipo"]     = "error";
                $retorno["input"]    = $param;
                $retorno["output"]   = null;
                $retorno["mensagem"] = "Necessario informar o valor da despesa";
                throw new Exception(json_encode($retorno), 1);
            }      

			if ( $param["status"] == "pago" && (!isset($param["data_pagamento"]) || empty($param["data_pagamento"])) ){
                $retorno["codigo"] = 1;
                $retorno["tipo"] = "error";
                $retorno["input"] = $param;
                $retorno["output"] = null;
                $retorno["mensagem"] = "informe a data de pagamento";
                throw new Exception(json_encode($retorno), 1);
            } elseif ( $param["status"] == "pago" && isset($param["data_pagamento"]) && !empty($param["data_pagamento"])){
                $param_save["data_pagamento"] = convertDate( $param["data_pagamento"]);
            } else {
                $param_save["data_pagamento"] = null;
            }
			if (!isset($id) || empty($id)){
                $last_iddoc = json_decode($this->controller->modelo->getLastIdDoc());
                if ($last_iddoc) {
                    $param_save["id_doc"] = $last_iddoc[0]->id_doc + 1;
                } else {
                    $param_save["id_doc"] = 1;
                }
            }

			$param_save["descricao"]        = $param["descricao"];
			$param_save["id_cm"]            = $param["id_cm"];
            $param_save["numero_documento"] = $param["numero_documento"];
            $param_save["id_fornecedor"]    = $param["id_fornecedor"];
            $param_save["id_grupo"]         = $param["id_grupo"];
            $param_save["id_conta"]         = $param["id_conta"];
            $param_save["id_subconta"]      = $param["id_subconta"];
            $param_save["id_centro_custo"]  = $param["id_centro_custo"];
            $param_save["prioridade"]       = $param["prioridade"];
            $param_save["meio_pagamento"]   = $param["meio_pagamento"];
            $param_save["periodo_apuracao"] = $param["periodo_apuracao"];
            $param_save["tipo_cobranca"]    = $param["tipo_cobranca"];
            $param_save["historico"]        = $param["historico"];
            $param_save["status"]           = $param["status"];
            $param_save["tipo"]             = $param["tipo"];
            $param_save["codigo_barra"]     = $param["codigo_barra"];
            $param_save["tipo_despesa"]     = $param["tipo_despesa"];
            $param_save["parcelado"]        = $param["parcelado"];
            $param_save["multa"]            = removeCaracteres($param["multa"], "moeda2");
            $param_save["juros"]            = removeCaracteres($param["juros"], "moeda2");
            $param_save["outros_valores"]   = removeCaracteres($param["outros_valores"],"moeda2");
            $param_save["abatimento"]       = removeCaracteres($param["abatimento"],"moeda2");
            $param_save["desconto"]         = removeCaracteres($param["desconto"], "moeda2");
            $param_save["codigo_receita"]   = $param["codigo_receita"];
            $param_save["divida_ativa"]     = $param["divida_ativa"];
            $param_save["identificacao_contribuinte"] = $param["identificacao_contribuinte"];
            $param_save["codigo_tributo"]    = $param["codigo_tributo"];
            $param_save["competencia"]       = $param["competencia"];
            $param_save["numero_referencia"] = $param["numero_referencia"];
            $param_save["atualizacao_monetaria"] = $param["atualizacao_monetaria"];
            $param_save["percentual_receita"]    = removeCaracteres($param["percentual_receita"],"moeda2");
            $param_save["parcela_numero"]        = $param["parcela_numero"];
            $param_save["numero_parcelas"]       = $param["numero_parcelas"];

			$param_save["parcela_numero"]  = $param["parcela_numero"];
            $param_save["numero_parcelas"] = $param["numero_parcelas"];
            $param_save["tipo_arquivo"]    = $param['tipo_arquivo'];
        
			if ($param["status"] == "pago") {
                $param_save["status_autorizacao"] = "aprovado";
                $param_save["requer_autorizacao"] = 0;
            } else {
                $param_save["status_autorizacao"] = "pendente";
                $param_save["requer_autorizacao"] = 1;
            }

			if (empty($param["numero_parcelas"])) {
                $param_save["numero_parcelas"] = 0;
            } else {
                $param_save["numero_parcelas"] = $param["numero_parcelas"];
            }

			if (!isset($param["requer_autorizacao"])) {
				$param_save["requer_autorizacao"] = 1;
			}

			if (!isset($param["status_autorizacao"])) {
				$param_save["status_autorizacao"] = "pendente";
			}
          								
			// quando a despesa é parcelada
			if ( $id < 1 && $param["parcelado"] == 1 && $param["numero_parcelas"] > 1){
                $num_parcelas = $param["numero_parcelas"];
                $obj_dt_vencimento = new DateTime($param["data_vencimento"]);
                for ($i = 1; $i <= $num_parcelas; $i++) {
                    $param_save["data_vencimento"] = $obj_dt_vencimento->format( "Ymd" );
                    $is_save = json_decode($this->saveBD($param_save));
                    $obj_dt_vencimento->add(new DateInterval("P1M"));
                }
            } else {
				// quando a despesa não é parcelada
				$is_save = json_decode($this->saveBD($param_save, $id));
            }

			if($is_save->codigo == 0){
				$retorno["codigo"]   = 0;
				$retorno["input"]    = $param_save;
				$retorno["output"]   = $is_save;
				$retorno["mensagem"] = $is_save->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}else{
				$retorno["codigo"]   = 1;
				$retorno["input"]    = $param_save;
				$retorno["output"]   = $is_save;
				$retorno["mensagem"] = $is_save->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}

		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	function saveBD($param, $id = null){
		try{
			$is_save = $this->controller->modelo->save($param, $id);
            if ($is_save){
				// if ("pago" == $param["status"]) {
				// 	$fornecedor     = json_decode($this->fornecedor->getFornecedores($param["id_fornecedor"]));
				// 	$destinatario   = explode(";", SYSTEM_NOTIFY_TO);
				// 	$mensagem_email = " <p><b>Despesa baixada com sucesso, segue os dados</b></p>
				// 		<p>ID: " . $id . " <br> Fornecedor: " . $fornecedor[0]->razao_social ." <br> Valor: " .funcValor($param["valor"], "C") . "<br> Vencimento: " . convertDate($param["data_vencimento"]) ." <br> Status    : " . $param["status"] ." <br>Alterada por: " .$_SESSION["cmswerp"]["userdata"]->nome ." <br>Alterada em: " .$this->data_hora_atual->format("d/m/Y H:i:s") ." </p> 
				// 	";
				// 	$param_envio["email"]["assunto"] = "Aviso Despesa paga"; // emails separados por;
				// 	$param_envio["email"]["destinatario"] = $destinatario; // emails separados por;
				// 	$param_envio["email"]["mensagem"] = $mensagem_email;
				// 	$mensagem_slack = " Despesa baixada com sucesso, segue os dados \n ID: " . $id . " \n Fornecedor: " . $fornecedor[0]->razao_social . " \n Valor: " . funcValor($param["valor"], "C") . "\n Vencimento: " . convertDate($param["data_vencimento"]) ." \n Status: " .$param["status"] ." Aprovado por: " . $_SESSION["cmswerp"]["userdata"]->nome . " \n Alterada em: " . $this->data_hora_atual->format("d/m/Y H:i:s") ." \n ";
				// 	$param_envio["slack"]["mensagem"] = $mensagem_slack;
				// 	$is_send = json_decode( $this->cl_notify->sendAlertas($param_envio));
					
				// 	$result["codigo"] = 0;
				// 	$result["input"] = $param_aprovacao;
				// 	$result["output"] = ["id_despesa" => $is_save];
				// 	$result["mensagem"] = "Despesa aprovada com sucesso";
				// 	// $this->cl_log->logInDb('action', 'despesas', $value->id_despesa, 'atualizar', $value, $param, true);
				// }

				// $despesa = json_decode($this->modelo->getDespesas($is_save));
				// $param_envio["slack"]["url_webhook"][] = URL_WEBHOOK_SLACK_TARIFADOR_AVISOS;
				// $param_envio["slack"]["url_webhook"][] = URL_WEBHOOK_SLACK_TARIFADOR;
				// $mensagem_slack ="Despesa cadastrada ou alterada \n ID: " .$despesa[0]->id_despesa ." \n Empresa Pagadora: " .$despesa[0]->nome_cm ." Fornecedor: " .$despesa[0]->nome_fornecedor . " \n	Vencimento: " . convertDate($despesa[0]->data_vencimento) . " \n ";
				// $param_envio["slack"]["mensagem"] = $mensagem_slack;
				// $is_send = json_decode($this->cl_notify->sendAlertas($param_envio));


				$retorno["codigo"] = 0;
				$retorno["tipo"] = "sucesso";
				$retorno["input"] = $param;
				$retorno["output"] = $is_save;
				$retorno["mensagem"] = "Sucesso";
				throw new Exception(json_encode($retorno), 1);

			} else {
				$retorno["codigo"] = 1;
				$retorno["tipo"] = "error";
				$retorno["input"] = $param;
				$retorno["output"] = null;
				$retorno["mensagem"] = "Erro ao salvar a despesa";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}
}