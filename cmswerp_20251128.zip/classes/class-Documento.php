<?php
	class Documento extends Main{
		protected
			$controller,
			$cobranca_model,
			$obj_email,
			$ultima_propostas,
			$id_usuario_sessao,
			$obj_aprovacao;

		public
			$usuario_model, 
			$produtos_model,
			$list_user,
			$id_faturamento,
			$lista_produto_modulos,
			$list_empresa,
			$texto_da_proposta,
			$data_texto,
			$data_hora_atual;
		
		function __construct ($controller, $parametros = null){
			parent::__construct($controller);
			$this->data_hora_atual 	 = getDataAtual();
			$this->parametros 		 = $parametros;
			$this->id_usuario_sessao = $_SESSION['cmswerp']['userdata']->id;
			$this->modelo  		  	 = $this->controller->load_model('propostas/propostas', true);
			$this->usuario_model  	 = $this->controller->load_model('usuarios/usuarios', true);
			$this->produtos_model 	 = $this->controller->load_model('produtos/produtos', true);
			$this->cobranca_model 	 = $this->controller->load_model('cobranca/cobranca', true);
			// $this->obj_aprovacao  	 = new Aprovacao($this);
			$this->notificacao    	 = new Notificacoes($this);
		}
		
		function texto(){
			set_time_limit(1800);
			if( isset($this->parametros[1]) && !empty($this->parametros[1]) ){
				$records = json_decode( $this->modelo->getPropostasTexto($this->parametros[2]) );
				$data = implode('/', array_reverse(explode('-', $records[0]->data_pagamento))); 
				$data2 = implode('/', array_reverse(explode('-', $records[0]->data_segundo_pagamento))); 
				$data3 = implode('/', array_reverse(explode('-', $records[0]->data_terceiro_pagamento)));
				$lp_propostas2 = json_decode( $this->modelo->getPropostasProdutoModulo($this->parametros[2], $records[0]->id_produto, null, true) );
				$modulos_ativos = json_decode($this->produtos_model->getAllCodigoModulosAtivos($records[0]->id_produto));
				$pacote = json_decode($this->modelo->getPacotePropostas($this->parametros[2]));
				// setando configuração de idioma para o uso de strftime
				setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
				$lp_fora_padrao = json_decode( $this->modelo->getLpForaPadrao( $records[0]->id ));
				$pacote_fora_padrao = json_decode( $this->modelo->getPacotePropostasEditada($records[0]->id ));
			}
			require_once ABSPATH . '/views/'.$this->nome_view.'/propostas-editar-view.php';
		}

		function atualizarPacoteProposta( $post = array(), $parametros = array() ){
			set_time_limit(1800);
			$this->parametros = $parametros;
			if( $this->parametros[0] == "id_propostas" ){
				$this->propostas = json_decode($this->modelo->getPropostasID( $this->parametros[3] ) );
				$records_produto = json_decode( $this->modelo->getProdutosProposta($this->parametros[3]) );
			}else if( $this->parametros[0] == "id"){
				$this->propostas = json_decode($this->modelo->getPropostasID($this->parametros[3]));
				$records_produto = json_decode( $this->modelo->getProdutosProposta($this->parametros[3]) );
			}

			$post['quantidade_garantido'] = removeCaracteres($post['quantidade_garantido'], true);
			$post['preco_pkt'] = removeCaracteres($post['preco_pkt'], 'moeda2');
			$post['valor_excedente'] = removeCaracteres($post['valor_excedente'], 'moeda3');
			
			if( $records_produto[0]->codigo_produto == "RCK0001" ){
				if($post['preco_pkt'] == "2000.00" && $post['quantidade_garantido'] == 500){
					$post['flag'] = "SD";
				}else{
					$post['flag'] = 1;
				}	
			}else{
				$post['flag'] = 1;
			}
					
			try{
				if($records_produto[0]->nome_produto != "CornerPIX Anti Fraude" && $records_produto[0]->nome_produto != "Exclusive Collocation Service"){
					if( !$post['quantidade_garantido'] || empty($post['quantidade_garantido']) ){
						$retorno['codigo'] = 1;
						$retorno['input'] = $post;
						$retorno['output'] = null;
						$retorno['mensagem'] = "* Quantidade de transaçoes vaziaa";
						throw new Exception(json_encode($retorno), 1); 
					}
				}

				if(  !$post['preco_pkt'] || empty($post['preco_pkt']) ){
					$retorno['codigo'] = 1;
					$retorno['input'] = $post;
					$retorno['output'] = null;
					$retorno['mensagem'] = "* Valor do pacote vazio";
					throw new Exception(json_encode($retorno), 1); 
				}
				$this->modelo->setTable('pacote_propostas');
				$save_pacote = $this->modelo->save($post, $post['id']);
				$id_modulo = json_decode($this->modelo->getIdModulo($post['modulo']));
				$post['id_propostas'] = $this->propostas[0]->id;
				$post['id_modulos_tarifaveis'] = $this->parametros[2];
				$post['id_produto'] = $this->parametros[1];
				if( $save_pacote ){
					$retorno['codigo'] = 0;
					$retorno['input'] = $post;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Sucesso ao atualizar pacote";
					throw new Exception(json_encode($retorno), 1); 
				}else{
					$retorno['codigo'] = 1;
					$retorno['input'] = $post;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro ao atualizar pacote";
					throw new Exception(json_encode($retorno), 1); 
				}
			}catch(Exception $e){
				return $e->getMessage();
			}
		}
		
		function insertPacote($parametros = array()){
			$this->parametros = $parametros;
			if(isset($this->parametros[1]) && !empty($this->parametros[1])){
				$id_produto = $this->parametros[1];
			}		
			$this->ultima_propostas = json_decode($this->modelo->getPropostasID($this->parametros[2]));
			$produto				= json_decode($this->modelo->produtos($id_produto));
			$insert['id_propostas'] = $this->ultima_propostas[0]->id;
			$insert['id_produto'] = $this->ultima_propostas[0]->id_produto;
			if($this->parametros[0] == "id_propostas"){			
				if($this->ultima_propostas[0]->id_produto == 13){
					$records = json_decode($this->produtos_model->getModulosEmpacotavel($this->parametros[2], true, 8));
				}else{
					$records = json_decode($this->produtos_model->getModulosEmpacotavel($this->parametros[2], true));
				}
			}else{
				if($this->ultima_propostas[0]->id_produto == 13){
					$records = json_decode($this->produtos_model->getModulosEmpacotavel($this->parametros[1], true, 8));
				}else{
					$records = json_decode($this->produtos_model->getModulosEmpacotavel($this->parametros[1], true));
				}			
			}

			if($this->ultima_propostas[0]->id_produto == 13){
				$pacote_padrao = json_decode($this->modelo->getPacoteDefault($this->parametros[1],8));
			}else{
				if(isset($produto) && $produto[0]->codigo == "CRY0002"){
					$pacote_padrao = json_decode($this->modelo->newPacoteDefault($produto[0]->codigo));
				}else{
					$pacote_padrao = json_decode($this->modelo->getPacoteDefault($this->parametros[1],8));
				}
			}
				
			$this->modelo->setTable('pacote_propostas');
			foreach($pacote_padrao as $key => $value){
				$insert['modulo'] = $value->descricao;
				$insert['id_modulos_tarifaveis'] = $value->id_modulos_tarifaveis;
				$insert['id_pacote'] = $value->id;
				$insert['quantidade_garantido'] = $value->qdt_garantido;
				$insert['preco_pkt'] = $value->preco_pkt; 
				$insert['status'] = $value->status;
				
				$save_pacote = $this->modelo->save($insert);
			}
		}

		function addPacote( $post = array(), $parametros = array() ){
			$this->parametros = $parametros;
			$id_modulo = json_decode($this->modelo->getIdModulo($post['modulo']));
			
			if( $this->parametros[0] == "id_propostas" && count($this->parametros) == 4 ){
				$this->propostas = json_decode($this->modelo->getPropostasID($this->parametros[2]));
				$records_produto = json_decode($this->modelo->getProdutosProposta($this->parametros[2]));
			}else if( $this->parametros[0] == "id_propostas"  && count($this->parametros) == 5){
				$this->propostas = json_decode($this->modelo->getPropostasID( $this->parametros[3]));
				$records_produto = json_decode($this->modelo->getProdutosProposta($this->parametros[3]));
			}else if($this->parametros[0] == "id"  && count($this->parametros) == 5){
				$this->propostas = json_decode($this->modelo->getPropostasID( $this->parametros[3] ) );
				$records_produto = json_decode( $this->modelo->getProdutosProposta($this->parametros[3]) );
			}else{
				$this->propostas = json_decode($this->modelo->getPropostasID($this->parametros[2]));
				$records_produto = json_decode( $this->modelo->getProdutosProposta($this->parametros[2]));			
			}
					
			$post['id_propostas'] = $this->propostas[0]->id;
			$post['id_modulos_tarifaveis'] = $id_modulo[0]->id;
			$post['id_produto'] = $this->parametros[1];

			//Formatando os dados do formulario 
			$post['quantidade_garantido'] = removeCaracteres($post['quantidade_garantido'], true);
			$post['preco_pkt'] 			  = removeCaracteres($post['preco_pkt'], 'moeda2');		
			$post['valor_excedente']      = removeCaracteres($post['valor_excedente'], 'moeda3');
					
			if( $records_produto[0]->codigo_produto == "RCK0001" &&  $post['preco_pkt'] == "2.000,00" && $post['quantidade_garantido'] == 500){
				$post['flag'] = "SD";
			}else{
				$post['flag'] = 1;
			}
			
			try{
				if($records_produto[0]->nome_produto != "CornerPIX Anti Fraude" && $records_produto[0]->nome_produto != "Exclusive Collocation Service"){
					if(!$post['quantidade_garantido'] || empty($post['quantidade_garantido'])){
						$retorno['codigo'] = 1;
						$retorno['input'] = $post;
						$retorno['output'] = null;
						$retorno['mensagem'] = "* Quantidade de transaçoes vazia";
						throw new Exception(json_encode($retorno), 1);
					}
				}

				if(!$post['preco_pkt'] || empty($post['preco_pkt'])){
					$retorno['codigo'] = 1;
					$retorno['input'] = $post;
					$retorno['output'] = null;
					$retorno['mensagem'] = "* Valor do pacote vazio";
					throw new Exception(json_encode($retorno), 1);
				}
							
				$this->modelo->setTable('pacote_propostas');
				$save_pacote = $this->modelo->save($post);				
				if($save_pacote){
					$retorno['codigo'] = 0;
					$retorno['input'] = $post;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Sucesso a salvar pacote";
					throw new Exception(json_encode($retorno), 1);						
				}else{
					$retorno['codigo'] = 1;
					$retorno['input'] = $post;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "* Erro ao salvar pacote";
					throw new Exception(json_encode($retorno), 1);				
				}
			}catch(Exception $e){
				return $e->getMessage();
			}
		}

		function saveModulosTexto($parametros = array()){
			set_time_limit(1800);
			$this->parametros = $parametros;
			if( !empty($this->parametros[2]) ) {
				$id_modulo = str_replace(",", ",/", $this->parametros[1]);
				$id_modulo = explode("/", $id_modulo);
				$this->modelo->setTable('lp_propostas');
				$array_lp = json_decode($this->modelo->getLpPropostaByModuloPropostaArray($this->parametros[2], $id_modulo));
				$array_not_lp = json_decode($this->modelo->getLpPropostaByModuloPropostaArrayZero( $this->parametros[2], $id_modulo ));
				$insert['texto_proposta'] = 1;
				foreach($array_lp as $key => $value){
					$save_texto_proposta = $this->modelo->save($insert, $value->id);
				};

				$insert2['texto_proposta'] = 0;
				foreach($array_not_lp  as $key => $value){

					$save_texto_proposta2 = $this->modelo->save($insert2, $value->id);

				}
			
			}else{
				$insert2['texto_proposta'] = 0;
				$lp_proposta_zero = json_decode($this->modelo->getLpPropostasId($this->parametros[1]));
				$this->modelo->setTable('lp_propostas');
				foreach($lp_proposta_zero as $key => $value){
					
					$save_texto_proposta_zero = $this->modelo->save($insert2, $value->id);

				};
			}

			try{
				if( $save_texto_proposta && $save_texto_proposta2 ){
					// if($this->parametros[0] == "id_propostas"){

					// 	// $this->modelo->setTable('propostas');

					// 	// //$descricao['descricao'] = $this->criarTexto($this->parametros[2]);

					// 	// $save_texto = $this->modelo->save($descricao, $this->parametros[2]);

					// 	if($save_texto){

					// 		$retorno['codigo'] = 0;
					// 		$retorno['input'] = $save_texto;
					// 		$retorno['output'] = null;
					// 		$retorno['mensagem'] = "Sucesso ao atualizar slide";
					// 		throw new Exception(json_encode($retorno), 1);

					// 	}else{

					// 		$retorno['codigo'] = 1;
					// 		$retorno['input'] = null;
					// 		$retorno['output'] = $this->modelo->info;
					// 		$retorno['mensagem'] = "Erro ao atualizar slide";
					// 		throw new Exception(json_encode($retorno), 1);

					// 	}

					// }

					$retorno['codigo'] = 0;
					$retorno['input'] = $save_texto_proposta;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno), 1);
				}else{
					if($save_texto_proposta_zero){
						$retorno['codigo'] = 0;
						$retorno['input'] = $save_texto_proposta_zero;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Sucesso";
						throw new Exception(json_encode($retorno), 1);
					}else{
						$retorno['codigo'] = 1;
						$retorno['input'] = $save_texto_proposta;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Erro ao selecionar texto da proposta";
						throw new Exception(json_encode($retorno), 1);
					};
				}
			}catch(Exception $e){
				return $e->getMessage();
			}
		}
	
		function excluirPacoteProposta($parametros = array()){
			///CORRIGIR ENVIAR E-MAIL QUANDO EXLUIR PACOTE PADRÃO 
			set_time_limit(1800);
			$this->parametros = $parametros;			
			$insert['deleted'] = 1;
			$id_pacote = $this->parametros[0];		
			// ID_PROPOSTAS 
			if(!empty($this->parametros[2])){
				$get_pacote = json_decode( $this->modelo->getPacotePropostasPadrao($id_pacote, true));
			}		
			$pacote_propostas = json_decode($this->modelo->getPacotePropostas(null,null,null,$id_pacote));					
			$this->modelo->setTable('pacote_propostas');
			$save = $this->modelo->save($insert, $id_pacote);
			try{
				if($save){
					$retorno['codigo'] = 0;
					$retorno['input'] = $pacote_propostas[0];
					$retorno['output'] = $save;
					$retorno['mensagem'] = "Sucesso";	
					throw new Exception(json_encode($retorno), 1);			
				}else{
					$retorno['codigo'] = 1;
					$retorno['input'] = $pacote_propostas[0];
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro em excluir pacote do id='$id_pacote'";
					throw new Exception(json_encode($retorno), 1);
				}
			}catch(Exception $e){
				return $e->getMessage();
			}	
		}

		function insertTable( $parametros = array() ){
			$this->parametros = $parametros;
			$this->ultima_propostas = json_decode($this->modelo->getPropostasID($this->parametros[2]));		
			$modulos_ativos = json_decode($this->produtos_model->getAllCodigoModulosAtivos($this->ultima_propostas[0]->id_produto));		
			$this->modelo->setTable('lp_propostas');
			$insert['id_propostas'] = $this->ultima_propostas[0]->id;
			$insert['id_produto'] = $this->ultima_propostas[0]->id_produto;	
			if(isset($modulos_ativos) && is_array($modulos_ativos)){
				foreach($modulos_ativos as $key => $value){				
					$lista_precos = json_decode($this->cobranca_model->getListaPrecoPadraoIdProduto($this->parametros[1], $value->id_modulo));				
					$insert['id_modulo'] = $value->id_modulo;
					$insert['cod_modulo'] 	= $value->codigo_modulo;
					$insert['cod_produto'] 	= $value->codigo_produto;
					$insert['tipo_cobranca'] = $lista_precos[0]->tipo_cobranca;					
					foreach($lista_precos as $key => $value){					
						$insert['editavel'] 	= $value->editavel;
						$insert['valor_real'] 	= $value->valor_real;
						$insert['qtd_de'] 		= $value->qtd_de;
						$insert['qtd_ate'] 		= $value->qtd_ate;
						$insert['percentual'] 	= $value->percentual;					
						$save_lp_propostas 		= $this->modelo->save($insert);
					}
				}
			}
		}

		function finalizar($parametros = array()){
			setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
			set_time_limit(1800);	
			try{
				if(!isset($parametros) || empty($parametros)){
					$retorno['codigo']   = 1 ;
					$retorno['input'] 	 = $parametros;
					$retorno['output'] 	 = null;
					$retorno['mensagem'] = "Erro parâmetros";
					throw new Exception(json_encode($retorno),1);
				}else{
					$this->parametros = $parametros;
					$id_proposta 	  = $this->parametros[1];
				}					
				
				$records = json_decode( $this->modelo->getPropostasTexto($id_proposta));
				$insert["propostas_finalizada"] = 'sim';
				// apagar
				$enviar_email = 0;
				// $enviar_email = $this->enviarEmail($this->parametros);
				
				if($enviar_email == 0){
					$parametros["id"] = $records[0]->id;
					if($records[0]->codigo == "YLW0001"){
						$parametros["codigo_produto"] = $records[0]->codigo;							
						// apagar
						// $this->notificacao->alertaTeams('proposta_criada',$parametros);																	
					}else{
						// apagar
						// $this->notificacao->alertaTeams('proposta_criada',$parametros);	
					}

					$save_finalizar = $this->modelo->save($insert, $id_proposta);
					if($save_finalizar){
						$retorno['codigo'] = 0;
						$retorno['input'] = $enviar_email;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Sucesso ao finalizar proposta.";
						throw new Exception(json_encode($retorno),1);
					}else{
						$retorno['codigo'] = 1 ;
						$retorno['input'] = $insert;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Erro ao finalizar proposta";
						throw new Exception(json_encode($retorno),1);					
					}
				}else{
					$retorno['codigo'] = 1;
					$retorno['input'] = $enviar_email;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro ao finalizar proposta, entrar em contato com o suporte";	
					throw new Exception(json_encode($retorno),1);			
				}			
			}catch(Exception $e){
				return $e->getMessage();
			}
		}

		function setObjectEmail(){
			$this->obj_email  = new Email();
		}
		
		function enviarEmail($parametros = array()){
			$bcc = array(
				0 => 'caio.freitas@cmsw.com',
			);
			$this->parametros = $parametros;		
			if($this->parametros[0] == "id_propostas" && count($this->parametros) == 3){
				$this->ultima_propostas = json_decode($this->modelo->getPropostas($this->parametros[1]));
				$lp_fora_padrao = json_decode( $this->modelo->getLpForaPadrao( $this->ultima_propostas[0]->id ));
				$pacote_fora_padrao = json_decode( $this->modelo->getPacotePropostasEditada( $this->ultima_propostas[0]->id ));
			}else if($this->parametros[0] == "id_propostas" && count($this->parametros) == 4){
				$this->ultima_propostas = json_decode($this->modelo->getPropostas($this->parametros[2]));
				$lp_fora_padrao = json_decode( $this->modelo->getLpForaPadrao( $this->ultima_propostas[0]->id ));
				$pacote_fora_padrao = json_decode( $this->modelo->getPacotePropostasEditada( $this->ultima_propostas[0]->id ));							
			}else if($this->parametros[0] == "id_propostas" && count($this->parametros) == 5){
				$this->ultima_propostas = json_decode($this->modelo->getPropostas($this->parametros[3]));
				$lp_fora_padrao = json_decode( $this->modelo->getLpForaPadrao( $this->ultima_propostas[0]->id ));
				$pacote_fora_padrao = json_decode( $this->modelo->getPacotePropostasEditada( $this->ultima_propostas[0]->id ));		
			}else if( $this->parametros[2] == "deletar_pacote" ){
				$pacote_padrao_excluido = "pacote_padrao_excluido";
			}else{
				$this->ultima_propostas = json_decode($this->modelo->getPropostasNaoFinalizada($this->parametros[1]));
				$lp_fora_padrao = json_decode( $this->modelo->getLpForaPadrao( $this->ultima_propostas[0]->id ));
				$pacote_fora_padrao = json_decode( $this->modelo->getPacotePropostasEditada($this->ultima_propostas[0]->id ));
			}

			$lp_padrao_excluida = json_decode( $this->modelo->getLpPadraoExcluida($this->ultima_propostas[0]->id));
			$implantacao = funcValor($this->ultima_propostas[0]->valor_implantacao, 'C', 2);		
			$implantacao_fora_padrao = $this->verificarImplantacao($this->ultima_propostas);
			
			// if(isset($this->ultima_propostas) && $this->ultima_propostas[0]->codigo == "YLW0001"){
			// 	$to  =  [
			// 		"0" => "kamal.zogheib@cmsw.com",
			// 		"1" => "caio.freitas@cmsw.com",
			// 		"2" => "beatriz.silva@cmsw.com",
			// 	];
			// }else{
			// 	$to  =  [
			// 		"0" => "kamal.zogheib@cmsw.com",
			// 		"1" => "caio.freitas@cmsw.com",
			// 	];
			// }
			$to  =  [			
				"0" => "caio.freitas@cmsw.com",
			];
					
			$this->setObjectEmail();
			if($lp_fora_padrao || $pacote_fora_padrao || $pacote_padrao_excluido || $implantacao_fora_padrao || $lp_padrao_excluida){
				$mensagem = "Proposta fora do padrão! <br>";
				if($lp_fora_padrao){
					foreach ($lp_fora_padrao as $key => $value) {
						$mensagem .= "Lista de preço $value->descricao. <br>";
					}				
				}

				if($pacote_fora_padrao){
					foreach ($pacote_fora_padrao as $key => $value) {
						$mensagem .= "Pacote $value->modulo. <br>";
					}
				}

				if($implantacao_fora_padrao){
					$mensagem .= "Implantação fora do padrão. <br>";
				}

				if($lp_padrao_excluida){
					$mensagem .= "Faixa de preço padrão excluida. <br>";
				}

				if($pacote_padrao_excluido){
					$get_pacote_padrao_excluido = json_decode( $this->modelo->getPacotePropostasPadrao( $this->parametros[0], true ));
					$this->ultima_propostas = json_decode($this->modelo->getPropostas($this->parametros[1]));					
				}

				$mensagem .= "<br> Link da proposta: ".URL_SISTEMA."propostas/texto/editar/id/".$this->ultima_propostas[0]->id;							
				$mensagem .=
				"<br></br> <b>Dados da proposta:</b> <br>
				ID da proposta: " . $this->ultima_propostas[0]->id.'<br> Owner da proposta: '.$this->ultima_propostas[0]->nome . '<br> Empresa: ' . $this->ultima_propostas[0]->empresa . '<br> Produto: ' . $this->ultima_propostas[0]->nome_produto . 
				'<br> Cliente: ' . $this->ultima_propostas[0]->cliente . '<br> Data de criação: ' . convertDate($this->ultima_propostas[0]->data_criacao) . '<br> E-mail de contato: ' . $this->ultima_propostas[0]->email . 
				'<br> Valor de implantação: ' . funcValor($this->ultima_propostas[0]->valor_implantacao, 'C', 2);									
			}else{		
				$mensagem = "Link da proposta: ".URL_SISTEMA."propostas/texto/editar/id/".$this->ultima_propostas[0]->id.'<br></br>
				<b>Dados da proposta:</b> <br>
				ID da proposta: '.$this->ultima_propostas[0]->id.'<br> Owner da proposta: '.$this->ultima_propostas[0]->nome . '<br> Empresa: ' . $this->ultima_propostas[0]->empresa . '<br> Produto: ' . $this->ultima_propostas[0]->nome_produto . 
				'<br> Cliente: ' . $this->ultima_propostas[0]->cliente . '<br> Data de criação: ' . convertDate($this->ultima_propostas[0]->data_criacao) . '<br> E-mail de contato: ' . $this->ultima_propostas[0]->email . 
				'<br> Valor de implantação: ' .  funcValor($this->ultima_propostas[0]->valor_implantacao, 'C', 2);
			}
			
			$send = $this->obj_email->sendMail($to, 'NOVA PROPOSTA CADASTRADA', $mensagem);		
			$resultado = json_decode($send);		
			if($resultado){
				return $resultado->codigo;
			}else{
				return $resultado->codigo;
			}
		}

		function verificarImplantacao($records){
			$implantacao = funcValor($records[0]->valor_implantacao, 'C', 2);
			switch ($records[0]->codigo) {
				//YELLOW
				case 'YLW0001':
					$codigo = "YLW0010";
				break;
				//TRIPLE PIX
				case 'TPX0001':
					$codigo = "TPX0010";
				break;
				//ROCKET
				case 'RCK0001':
					$codigo = "RCK0033";
				break;
				//ECS
				case 'ECS0001':
					$codigo = "ECS0010";
				break;
				//CRYSTAL
				case 'CRY0001':
					$codigo = "CRY0010";
				break;
				//SPB/x OBE
				case 'SOE0001':
					$codigo = "SOE0012";
				break;
				//FULL STR WEB & PIX
				case 'FSP0001':
					$codigo = "STR0000";
				break;
				//SPI/x Sistema de Pagamentos Instantâneos
				case 'SPI0001':
					$codigo = "SPI0023";
				break;
				//CornerPIX Anti Fraude
				case 'ATF0001':
					$codigo = "ATF0013";
				break;							
				default:
					$codigo = false;
				break;
			}

			$get_implantacao = json_decode($this->modelo->getLpByCodigo(null,$codigo));
			$implantacao_padrao = funcValor($get_implantacao[0]->valor_real,'C',2);
			if($implantacao != $implantacao_padrao){
				$implantacao_fora_padrao = 1;
			}else{
				$implantacao_fora_padrao = null;
			}	
			return $implantacao_fora_padrao;
		}

		function enviarEmailAprovada($id_propostas, $aprovacao){
			$records = json_decode($this->modelo->getPropostas($id_propostas));
			$bcc = array(
				0 => 'caio.freitas@cmsw.com',
			);

			if($aprovacao == "aprovado_comercial"){
				//AQUI QUE VAI O E-MAIL DO ORLI
				$to = array(
					'0' => EMAIL_PROPOSTA,
				);
			}else{
				$to = array(
					'0' => $records[0]->email_usuario
				);
			}

			$this->setObjectEmail();
			$data_criacao = implode('/', array_reverse(explode('-', $records[0]->data_criacao)));
			if($aprovacao == "aprovado_comercial"){
				$mensagem .= "Proposta fora do padrão ".$records[0]->id." aprovada pelo Comercial.";
				$mensagem .= "<br> Link da proposta: ".URL_SISTEMA."propostas/texto/editar/".$records[0]->id;
				$mensagem .=
				"<br></br> <b>Dados da proposta:</b> <br>
				ID da proposta: " . $records[0]->id. 
				'<br> Cliente: ' . $records[0]->cliente . 
				'<br> Produto: ' . $records[0]->nome_produto .
				'<br> Owner da proposta: '.$records[0]->nome . 
				'<br> Data de criação: ' . $data_criacao . 
				'<br> E-mail de contato: ' . $records[0]->email;
				
			}else{
				$mensagem .= "Proposta ".$records[0]->id." aprovada!";
				$mensagem .= "<br> Link da proposta: ".URL_SISTEMA."propostas/texto/editar/".$records[0]->id;
				$mensagem .=
				"<br></br> <b>Dados da proposta:</b> <br>
				ID da proposta: " . $records[0]->id. 
				'<br> Cliente: ' . $records[0]->cliente . 
				'<br> Produto: ' . $records[0]->nome_produto .
				'<br> Owner da proposta: '.$records[0]->nome . 
				'<br> Data de criação: ' . $data_criacao . 
				'<br> E-mail de contato: ' . $records[0]->email;
			}
			$assunto = "PROPOSTA APROVADA - ".$records[0]->cliente." / ".$records[0]->nome_produto." / ".$records[0]->nome_usuario;
			$send = $this->obj_email->sendMail($to, $assunto, $mensagem, null, null, null, $bcc, null, null);
			$resultado = json_decode($send);
			if($send){
				return $resultado->codigo;
			}else{
				return $resultado->codigo;
			}
		}

		//DESCONTINUADO
		function enviarProposta($records, $enviar_proposta){
			// $cnpj_cpf = $records[0]->cnpj_cpf;
			// $id_proposta = $records[0]->id;
			// $path = PATH_PROPOSTA.$cnpj_cpf.DS."proposta_comercial_$id_proposta.pdf";
			// $to[]  =  $enviar_proposta['to'];
			// $this->setObjectEmail();
			// $mensagem_email = explode(PHP_EOL, $enviar_proposta['texto']);
			// $key_mensagem = 0;
			// foreach ($mensagem_email as $key => $value) {
			// 	if(empty($value)){
			// 		unset($mensagem_email[$key]);
			// 	}else{
			// 		$key_mensagem++;
			// 		$mensagem_email_key[$key_mensagem] = $value;
			// 	}
			// }
			
			// $mensagem = $mensagem_email_key[1]."<br></br>".$mensagem_email_key[2]."<br></br>".$mensagem_email_key[3]."<br>".$mensagem_email_key[4];
			// $mensagem =  $enviar_proposta['texto'];

			// $send = $this->obj_email->sendMail($to, 'PROPOSTA COMERCIAL', $mensagem, 
			// null, null, null, null, $path);
			
			// try{

			// 	if($send){

			// 		$retorno['codigo']   = 0;
			// 		$retorno['input']    = $enviar_proposta.$path;
			// 		$retorno['output']   = $this->modelo->info;
			// 		$retorno['mensagem'] = "Sucesso ao enviar proposta";
			// 		throw new Exception (json_encode($retorno), 1);	

			// 	}else{

			// 		$retorno['codigo']   = 1;
			// 		$retorno['input']    = $enviar_proposta.$path;
			// 		$retorno['output']   =$this->modelo->info;
			// 		$retorno['mensagem'] = "Erro ao enviar proposta";
			// 		throw new Exception (json_encode($retorno), 1);	
			// 	}
			
			// }catch(Exception $e){
			// 	return $e->getMessage();
			// }

			
		}
		
		function alterarStatus($post = array(), $parametros = array()){
			try {
				$id_proposta = $this->controller->parametros[1];
				//PROPOSTA FORA DO PADRÃO TIPO 2, ABAIXO DA LP, IMPLANTAÇÃO OU PACOTE PADRÃO 
				$proposta_fora_padrao = json_decode($this->modelo->getPropostasTexto($id_proposta, true, null, null, 2));		
				$records = json_decode( $this->modelo->getPropostasTexto($id_proposta));
				
				if(!isset($records) || empty($records)){
					$retorno['codigo']   = 1;
					$retorno['input']    = $post;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Erro ao obter proposta';
					throw new Exception(json_encode($retorno), 1);
				}else{
					if($records[0]->propostas_finalizada != "sim"){
						$retorno['codigo']   = 1;						
						$retorno['input']    = $this->parametros;
						$retorno['output']   = null;
						$retorno['mensagem'] = "Necessário finalizar a proposta";
						throw new Exception (json_encode($retorno), 1);	
					}	
				}	
				
				if(!isset($post["status"]) || empty($post["status"])){			
					$retorno['codigo']   = 1;						
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Erro na ação do status";
					throw new Exception (json_encode($retorno), 1);	
				}

				$user_fluxo_aprovacao = json_decode($this->modelo->fluxoOrdemAprovacao($this->id_usuario_sessao, 'proposta')); 
				if(!isset($user_fluxo_aprovacao) || empty($user_fluxo_aprovacao)){
					$retorno['codigo']   = 1;						
					$retorno['input']    = $this->controller->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Usuário sem fluxo de aprovação cadastrado COD:818";
					throw new Exception (json_encode($retorno), 1);	
				}else{				
					$user_status_aprovacao = json_decode($this->modelo->fluxoStatusAprovacao('proposta', null, $user_fluxo_aprovacao[0]->id));
				}		
				
				$get_status = json_decode($this->obj_aprovacao->statusProposta($records,$post["status"],$user_fluxo_aprovacao));						
				if($get_status->codigo == 1){
					$retorno['codigo']   = 1;						
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = $get_status->mensagem;
					throw new Exception (json_encode($retorno), 1);	
				}else{
					$status['status'] = $get_status->output;
				}		
										
				$this->modelo->setTable('propostas');
				$save_status = $this->modelo->save($status, $id_proposta);
				if($save_status){
					if($status['status'] == "fechada"){
						//apagar
						// $return_email = $this->enviarEmailAprovada($records[0]->id, "aprovado");
						$parametros["id"] 	   		  = $records[0]->id;
						$parametros["cliente"] 		  = $records[0]->cliente;		
						$parametros["user_comercial"] = $records[0]->email_usuario;	
						//apagar

						// $this->notificacao->alertaTeams('proposta_aprovado',$parametros);
					}else if($status['status'] == "nda_aprovado"){
						$parametros["id"] 	   		  = $records[0]->id;
						$parametros["cliente"] 		  = $records[0]->cliente;		
						$parametros["user_comercial"] = $records[0]->email_usuario;					
						//apagar
						// $this->notificacao->alertaTeams('nda_aprovado',$parametros);
					}

					$retorno['codigo']   = 0;
					$retorno['input']    = $post;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Sucesso em alterar status';
					throw new Exception(json_encode($retorno), 1);
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $post;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Erro ao alterar status 1';
					throw new Exception(json_encode($retorno), 1);
				}
							
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}
		
		function alterarStatusProposta($parametros = array()){
			try {
				$this->parametros = $parametros;
				$id_user = $_SESSION['cmswerp']['userdata']->id;
				$user_fluxo_aprovacao = json_decode($this->modelo->fluxoOrdemAprovacao($this->id_usuario_sessao, 'proposta'));
				if(!isset($user_fluxo_aprovacao) || empty($user_fluxo_aprovacao)){
					$retorno['codigo']   = 1;						
					$retorno['input']    = $this->controller->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Usuário sem fluxo de aprovação cadastrado COD:879";
					throw new Exception (json_encode($retorno), 1);	
				}else{				
					$user_status_aprovacao = json_decode($this->modelo->fluxoStatusAprovacao('proposta', null, $user_fluxo_aprovacao[0]->id));
				}		

				if($this->parametros[2] == null || empty($this->parametros[2])){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Selecione uma proposta";
					throw new Exception(json_encode($retorno), 1);
				}else{
					$this->modelo->setTable('propostas');
					$id_propostas = explode(",", $this->parametros[2]);		
					foreach ($id_propostas as $key => $value) {
						$proposta_fora_padrao = json_decode($this->modelo->getPropostasTexto($value, true, null, null, 2));
						$records    = json_decode($this->modelo->getPropostasTexto($value));
						$get_status = json_decode($this->obj_aprovacao->statusProposta( $records, $this->parametros[0], $user_fluxo_aprovacao ) );						
						if($get_status->codigo == 1){
							$retorno['codigo']   = 1;						
							$retorno['input']    = $this->parametros;
							$retorno['output']   = null;
							$retorno['mensagem'] = $get_status->mensagem;
							throw new Exception (json_encode($retorno), 1);	
						}else{
							$status['status'] = $get_status->output;
						}

						$save_status = $this->modelo->save($status, $value);
						if($save_status){
							if($status['status'] == "fechada"){
								$parametros["id"] 		= $records[0]->id;
								$parametros["cliente"]  = $records[0]->cliente;
								$parametros["user_comercial"] = $records[0]->email_usuario;	
								$return_email = $this->enviarEmailAprovada($records[0]->id, "aprovado");
								$this->notificacao->alertaTeams('proposta_aprovado',$parametros);
							}else if($status['status'] == "nda_aprovado"){
								$parametros["id"] 	   = $records[0]->id;
								$parametros["cliente"] = $records[0]->cliente;		
								$parametros["user_comercial"] = $records[0]->email_usuario;						
								$this->notificacao->alertaTeams('nda_aprovado',$parametros);
							}
							$retorno['codigo']   = 0;
							$retorno['input']    = $post;
							$retorno['output']   = null;
							$retorno['mensagem'] = 'Sucesso em alterar status';
							throw new Exception(json_encode($retorno), 1);
						}else{
							$retorno['codigo']   = 1;
							$retorno['input']    = $post;
							$retorno['output']   = null;
							$retorno['mensagem'] = 'Erro ao alterar status 1';
							throw new Exception(json_encode($retorno), 1);
						}
					}			
				}				
			}catch(Exception $e){
				return $e->getMessage();
			}
		}

		function deletar($parametros){
			$this->parametros = $parametros;
			$this->modelo->setTable('lp_propostas');
			$deleted['deleted'] = 1;
			$lp = json_decode($this->modelo->getLpId($this->parametros[1]));
			//OBSERVAÇÃO IMPORTANTE!! ESSE $this->parametros[1] usado como segundo parametro de save() vem do AJAX e não da URL
			$save_deleted = $this->modelo->save($deleted, $this->parametros[1]);
			try{
				if($save_deleted){
					$retorno['codigo'] = 0;
					$retorno['input'] = $lp[0];
					$retorno['output'] = null;
					$retorno['mensagem'] = "Sucesso ao deletar lp_propostas id = " . $this->parametros[1];
				}else{
					$retorno['codigo'] = 1;
					$retorno['input'] = $lp[0];
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro ao inserir no banco";
				}
				throw new Exception (json_encode($retorno), 1);
			}catch(Exception $e){
				return $e->getMessage();
			}
		}

		function lpDefault($parametros = array()){
			$this->parametros = $parametros;
			$this->ultima_propostas = json_decode($this->modelo->getPropostasID($this->parametros[3]));
			$this->modelo->setTable('lp_propostas');
			if( $this->parametros[0] == "id_propostas" ){
				$this->ultima_propostas[0]->id = $this->parametros[3];
			}

			$lp = json_decode( $this->modelo->getLpPropostasDefault ( $this->ultima_propostas[0]->id, $this->parametros[1], $this->parametros[2] ));
			$deleted['deleted'] = 1;
			$reset['deleted'] = 0;
			foreach($lp as $key => $value){
				$save = $this->modelo->save($deleted, $value->id);
			}
			
			$lp_deleted = json_decode($this->modelo->getLpPropostasDefaultDeletada($this->ultima_propostas[0]->id, $this->parametros[1], $this->parametros[2]));
			foreach($lp_deleted as $key => $value){
				$save2 = $this->modelo->save($reset, $value->id);
			}

			if(!empty($lp)){
				$retorno_lp = $lp[0];
			}else{
				$retorno_lp = $lp_deleted[0];
			}
				
			try{
				if($save){
					$retorno['codigo'] = 0;
					$retorno['input'] = $retorno_lp;
					$retorno['output'] = $save;
					$retorno['mensagem'] = "Sucesso";
				}else if($save2){
					$retorno['codigo'] = 0;
					$retorno['input'] = $retorno_lp;
					$retorno['output'] = $save;
					$retorno['mensagem'] = "Sucesso";
				}else{
					$retorno['codigo'] = 1;
					$retorno['input'] = $retorno_lp;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro default, faixa padrão";
				}
				throw new Exception (json_encode($retorno), 1);
			}catch(Exception $e){
				return $e->getMessage();
			}
		}

		function saveFaixa($post = array(), $parametros){
			$this->parametros = $parametros;
			$this->modelo->setTable('lp_propostas');
			$post['qtd_de'] = removeCaracteres($post['qtd_de'], true);
			$post['qtd_ate'] =   removeCaracteres($post['qtd_ate'], true);
			$post['valor_real'] = removeCaracteres($post['valor_real'], 'moeda3');
			$post['padrao'] = 1;
			$post['editavel'] = 1;
			$propostas = json_decode($this->modelo->getPropostasID( $this->parametros[3] ));
			$lp_propostas = json_decode( $this->modelo->getPropostasProdutoModulo( $propostas[0]->id, $this->parametros[1], $this->parametros[2] ));
			try{
				if( !$post['qtd_de'] || empty($post['qtd_de']) ){
					$retorno['codigo'] = 1;
					$retorno['input'] = $post;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Quantidade de: não inserido";	
					throw new Exception (json_encode($retorno),1);
				}

				if( !$post['qtd_ate'] || empty($post['qtd_ate']) ){
					$retorno['codigo'] = 1;
					$retorno['input'] = $post;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Quantidade ate: não inserido";	
					throw new Exception (json_encode($retorno),1);
				}

				if( !$post['valor_real'] || empty($post['valor_real']) ){
					$retorno['codigo'] = 1;
					$retorno['input'] = $post;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Valor não inserido";	
					throw new Exception (json_encode($retorno),1);
				}

				foreach($lp_propostas as $key => $value){
					if($value->editavel == 1 ){
						if ( 
							( $post['qtd_de'] <= $value->qtd_de || $post['qtd_de'] >= $value->qtd_ate || $post['qtd_ate'] >= $value->qtd_ate ) &&
							( $post['qtd_de'] <= $value->qtd_ate && $post['qtd_ate'] >= $value->qtd_ate ) || 
							( $post['qtd_de'] <= $value->qtd_de && $post['qtd_ate'] >= $value->qtd_de ) 
												
						) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $post;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Rompendo faixa de transações de: '$value->qtd_de' ate: '$value->qtd_ate'";	
							throw new Exception (json_encode($retorno),1);
						} 
						if( $post['qtd_de'] >= $post['qtd_ate']){
							$retorno['codigo'] = 1;
							$retorno['input'] = $post;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Faixa DE: " . $post['qtd_de'] . " maior ou igual a faixa de ATE: " . $post['qtd_ate'];	
							throw new Exception (json_encode($retorno),1);
						}
					}else if( $post['qtd_de'] >= $value->qtd_de || $post['qtd_ate'] >= $value->qtd_de ){
							
							$retorno['codigo'] = 1;
							$retorno['input'] = $post;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Ultrapassou a faixa não editável de preço";	
							throw new Exception (json_encode($retorno),1);
					}
				
				}
				
				if($this->parametros[0] == "id_propostas"){
					$post["id_propostas"] = $this->parametros[3];
					$save_new_faixa = $this->modelo->save($post);
				}else{
					$save_new_faixa = $this->modelo->save($post);
				}

				if($save_new_faixa){
					$retorno['codigo'] = 0;
					$retorno['input'] = $lp_propostas[0];
					$retorno['output'] = null;
					$retorno['mensagem'] = "Sucesso ao inserir uma nova faixa de preço";
					throw new Exception (json_encode($retorno),1);
				}else{
					$retorno['codigo'] = 1;
					$retorno['input'] = $post;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro ao inserir uma nova faixa de preço";	
					throw new Exception (json_encode($retorno),1);
				}
			}catch(Exception $e){
				return $e->getMessage();
			}
		}

		function atualizarFaixa($post = array(), $parametros){
			$this->parametros = $parametros;
			$this->modelo->setTable('lp_propostas');
			$deleted['deleted'] = 1;
			$id = $post['id'];
			unset($post['id']);
			$post['valor_real'] = str_replace(".", "", $post['valor_real']);
			$lp = json_decode($this->modelo->getLpId($id));
			foreach($lp as $value){
				$post2 = $value;
			}

			$post2 = get_object_vars($post2);
			unset($post2["texto_proposta"]);unset($post2["alterado_por"]);unset($post2["alterado_em"]);	unset($post2["deleted"]);unset($post2["id"]);
			$post2['valor_real'] = removeCaracteres($post['valor_real'], 'moeda3');
			$post2['padrao'] = 1;
			try{
				if( !$post['valor_real'] || empty($post['valor_real']) ){
					$retorno['codigo'] = 1;
					$retorno['input'] = $lp[0];
					$retorno['output'] = null;
					$retorno['mensagem'] = "* Valor não inserido";	
					throw new Exception (json_encode($retorno),1);
				}

				if($this->parametros[0] == "id_propostas"){
					$post["id_propostas"] = $this->parametros[3];
				}
			
				$deleted_faixa = $this->modelo->save($deleted, $id);
				$atualizar_faixa = $this->modelo->save($post2);

				if($deleted_faixa && $atualizar_faixa){
					$retorno['codigo'] = 0;
					$retorno['input'] = $lp[0];
					$retorno['output'] = null;
					$retorno['mensagem'] = "Sucesso ao inserir uma nova faixa de preço";
					throw new Exception (json_encode($retorno),1);
				}else{
					$retorno['codigo'] = 1;
					$retorno['input'] = $lp[0];
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro ao inserir uma nova faixa de preço";	
					throw new Exception (json_encode($retorno),1);
				}
			}catch(Exception $e){
				return $e->getMessage();
			}
		}

		function save($post = array(), $parametros = array()){
			try{
				$this->parametros = $parametros;
				$id_user = $_SESSION['cmswerp']['userdata']->id;	
				$post['criado_por'] = $id_user;	
				$post['data_criacao'] = $this->data_hora_atual->format('Y-m-d');

				if(empty($this->parametros[1])){			
					if(!$post['id_produto']){
						$retorno['codigo']   = 1;
						$retorno['input']    = $post;
						$retorno['output']   = $this->modelo->info;
						$retorno['mensagem'] = 'Informe o produto';
						throw new Exception (json_encode($retorno), 1);
					}
				}

				if($post['id_produto'] == 2000000){
					if(!$post['modulo_produto']){
						$retorno['codigo']   = 1;
						$retorno['input']    = $post;
						$retorno['output']   = $this->modelo->info;
						$retorno['mensagem'] = 'Informe o modulo do produto FULL';
						throw new Exception (json_encode($retorno), 1);
					}else{
						$post['id_produto'] = $post['modulo_produto'];
						unset($post['modulo_produto']);
					}
				}else{
					unset($post['modulo_produto']);
				}
							
				if($this->parametros[0] != "id_propostas"){
					if(!$post['id_owner']){
						$retorno['codigo']   = 1;
						$retorno['input']    = $post;
						$retorno['output']   = null;
						$retorno['mensagem'] = 'Informe o OWNER da proposta';
						throw new Exception (json_encode($retorno), 1);
					}
				}

				if(($post['cnpj_cpf']) && !empty($post['cnpj_cpf'])){
					$post['cnpj_cpf'] = removeCaracteres($post['cnpj_cpf'], "char", null);
					if(is_numeric($post['cnpj_cpf'])){					
						if(strlen($post['cnpj_cpf']) < 10){
							$retorno['codigo']   = 1;
							$retorno['input']    = $post;
							$retorno['output']   = null;
							$retorno['mensagem'] = 'CNPJ/CPF invalido';
							throw new Exception (json_encode($retorno), 1);
						}				
					}else{						
						$retorno['codigo']   = 1;
						$retorno['input']    = $post;
						$retorno['output']   = null;
						$retorno['mensagem'] = 'CNPJ/CPF deve conter apenas números';
						throw new Exception (json_encode($retorno), 1);
					}						
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $post;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Informe o CNPJ/CPF';
					throw new Exception (json_encode($retorno), 1);
				}
				if(!$post['cliente']){
					$retorno['codigo']   = 1;
					$retorno['input']    = $post;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Informe o nome fantasia';
					throw new Exception (json_encode($retorno), 1);
				}
				if($post['email']){
					if(filter_var($post['email'], FILTER_VALIDATE_EMAIL) == false){					
						$retorno['codigo']   = 1;
						$retorno['input']    = $post;
						$retorno['output']   = $this->modelo->info;
						$retorno['mensagem'] = 'E-mail invalido';
						throw new Exception(json_encode($retorno), 1);
					}
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $post;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Informe o e-mail';
					throw new Exception (json_encode($retorno), 1);
				}
				if($post['telefone']){				
					$post['telefone'] = removeCaracteres($post['telefone'],'char', null); 
					$post['telefone'] = removeCaracteres($post['telefone'], true, null);
					if(strlen($post['telefone']) > 13 && strlen($post['telefone']) < 10 ){
						$retorno['codigo']   = 1;
						$retorno['input']    = $post;
						$retorno['output']   = $this->modelo->info;
						$retorno['mensagem'] = 'Telefone invalido';
						throw new Exception (json_encode($retorno), 1);
					}
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $post;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Informe o telefone';
					throw new Exception (json_encode($retorno), 1);
				}
				if($post['cep'] ){
					$post['cep'] = removeCaracteres($post['cep'], 'char', null);
					if(strlen($post['cep']) != 8 ){
						$retorno['codigo']   = 1;
						$retorno['input']    = $post;
						$retorno['output']   = $this->modelo->info;
						$retorno['mensagem'] = 'CEP invalido';
						throw new Exception (json_encode($retorno), 1);
					}
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $post;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Informe o CEP';
					throw new Exception (json_encode($retorno), 1);
				}
				if(!$post['endereco']){
					$retorno['codigo']   = 1;
					$retorno['input']    = $post;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Informe o endereço';
					throw new Exception (json_encode($retorno), 1);
				}

				if(!$post['numero']){
					$retorno['codigo']   = 1;
					$retorno['input']    = $post;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Informe o numero';
					throw new Exception (json_encode($retorno), 1);
				}
			
				if(!$post['bairro']){
					$retorno['codigo']   = 1;
					$retorno['input']    = $post;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Informe  bairro';
					throw new Exception (json_encode($retorno), 1);
				}
				if(!$post['estado']){
					$retorno['codigo']   = 1;
					$retorno['input']    = $post;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Informe o estado';
					throw new Exception (json_encode($retorno), 1);
				}
				if(!$post['cidade']){
					$retorno['codigo']   = 1;
					$retorno['input']    = $post;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Informe a cidade';
					throw new Exception (json_encode($retorno), 1);
				}
							
				// FATURAMENTO
				if(!isset($post['valor_implantacao']) || empty($post['valor_implantacao'])){				
					$retorno['codigo']   = 1;
					$retorno['input']    = $post;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Informe o valor da implantação';
					throw new Exception (json_encode($retorno), 1);
				}
										
				if(!isset($post['numero_parcelas']) || empty($post['numero_parcelas'])){
					$retorno['codigo']   = 1;
					$retorno['input']    = $post;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Informe a quantidade de parcelas';
					throw new Exception (json_encode($retorno), 1);
				} 					
					
				$post_faturamento = array(
					'valor_implantacao' => removeCaracteres($post['valor_implantacao'], 'moeda2'), 					
					'id_propostas' 		=> null,
					'id_owner' 			=> $_POST['id_owner'],
					'id_produto' 		=> $post['id_produto'],
					'numero_parcelas' 	=> $post['numero_parcelas'],				
				);

				unset($post['valor_implantacao']);	
				unset($post['numero_parcelas']);				
				$is_save = $this->modelo->save($post, $this->parametros[1]);
				if( !$is_save ){
					$retorno['codigo']   = 1;
					$retorno['input']    = $post;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Erro ao gravar na tabela propostas';
					throw new Exception (json_encode($retorno), 1);
				}else{
					$post_faturamento['id_propostas'] = $is_save;	
				}

				if($this->parametros[1]){
					unset($post['data_criacao']);
					unset($post['criado_por']);
				}										
							
				$this->modelo->setTable('propostas_faturamento');		
				//verificando se é um insert ou um update
				if(!empty($this->parametros[1])){
					//UPDATE
					unset($post_faturamento['id_propostas']);				
					$this->id_faturamento = json_decode($this->modelo->getIdPropostasFaturamento($this->parametros[1]));
					$is_save2 = $this->modelo->save($post_faturamento, $this->id_faturamento[0]->id);
				}else{
					// INSERINDO NA TABELA proposta_faturamento 
					$is_save2 = $this->modelo->save($post_faturamento);
				}						
			
				if(!$is_save2){
					$retorno['codigo']   = 1;
					$retorno['input']    = $post_faturamento;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Erro ao gravar proposta na tabela propostas_faturamento';
					throw new Exception (json_encode($retorno), 1);
				}else{
					$retorno['codigo'] = 0;
					$retorno['input'] = $post;
					$retorno['output'] = $is_save;
					$retorno['mensagem'] = 'Sucesso';				
					throw new Exception (json_encode($retorno), 1);
				}
			}catch(Exception $e){
				return $e->getMessage();						
			}		
		}

		function criarTexto($parametro_proposta = null){
			$records = json_decode( $this->modelo->getPropostasNaoFinalizada( $parametro_proposta ));
			
			$data = implode('/', array_reverse(explode('-', $records[0]->data_pagamento))); 
			$data2 = implode('/', array_reverse(explode('-', $records[0]->data_segundo_pagamento))); 
			$data3 = implode('/', array_reverse(explode('-', $records[0]->data_terceiro_pagamento)));
		
			$lp_propostas2 = json_decode( $this->modelo->getPropostasProdutoModulo($parametro_proposta, $records[0]->id_produto, null, true) );			
			$modulos_ativos = json_decode($this->produtos_model->getAllCodigoModulosAtivos($records[0]->id_produto));		
			$pacote = json_decode($this->modelo->getPacotePropostas($parametro_proposta));
			$texto_modulo = json_decode($this->modelo->getPropostasTextoOk($parametro_proposta));

			if($records[0]->nome_produto == "ROCKET"){                                                
				$texto = include "includes/texto_rocket.php";		
			}else if($records[0]->nome_produto == "SPI/x Sistema de Pagamentos Instantâneos"){
				$texto = include "includes/texto_spix.php";
			}else if($records[0]->nome_produto == "Crystal AMC"){
				$texto = include "includes/texto_crystal.php";
			}else if($records[0]->nome_produto == "CornerPIX Anti Fraude"){
				$texto = include "includes/texto_corner_pix_antifraude.php";			
			}else if($records[0]->nome_produto == "FULL STR WEB & PIX"){
				$texto = include "includes/texto_full_str_web.php"; 
			}else if($records[0]->nome_produto == "SPB/x"){			
				$texto = include "includes/texto_SPBx.php"; 			
			}

			return $texto;	
		}
	}