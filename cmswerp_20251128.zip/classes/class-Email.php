<?php
/**
 * Created by PhpStorm.
 * User: julio
 * Date: 22/07/15
 * Time: 00:40
 */

require_once(EMAIL_API.'class.smtp.php');
require_once(EMAIL_API.'class.phpmailer.php');

class Email extends PHPMailer{

    protected $mail;
    protected $msg;
    public    $error;
    protected $debug = false;
    protected $ishtml = true;
    protected $sendmethod = SMTP_SEND;    
    protected $charset = SMTP_CHARSET;    
    protected $smtpsecure = 'tls';
    protected $host = SMTP_SERVER;        
    protected $username = SMTP_USER;     
    protected $password = SMTP_PASS;     
    protected $from = SMTP_EMAIL_FROM;    
    protected $fromName = SMTP_FROM_NAME; 
    protected $port = SMTP_PORT;          
    protected $smtpauth = SMTP_AUTH;
    

    function __construct( $dados =  null ){
        if($dados){
            $this->debug      = $dados['debug'];
            $this->ishtml     = $dados['ishtml'];
            $this->sendmethod = $dados['sendmethod'];
            $this->charset    = $dados['charset'];
            $this->smtpsecure = $dados['smtpsecure'];
            $this->host       = $dados['host'];
            $this->port       = $dados['port'];
            $this->smtpauth   = $dados['smtpauth'];
            $this->username   = $dados['username'];
            $this->password   = $dados['password'];
            
        }
        $this->setConfig();
    }

    function setConfig(){

        $this->mail = new PHPMailer();

        //mode debug
        $this->mail->SMTPDebug = $this->debug;

        $this->mail->IsSMTP();
        $this->mail->isHTML($this->ishtml); //Linha comentada para funcionar com o Gmail

        // Define o método de envio
        $this->mail->Mailer     = $this->sendmethod;

        // Define que a codificação do conteúdo da mensagem será utf-8
        $this->mail->CharSet    = $this->charset;

        // Define que os emails enviadas utilizarão SMTP Seguro tls ou ssl
        $this->mail->SMTPSecure = $this->smtpsecure;
        //TIPO DE AUTENTICACAO, EXEMPLO SSL
        //$mail->SMTPSecure = TIPO_AUT_EMAIL;

        //Configuração de HOST do SMTP
        $this->mail->Host = 		$this->host;

        //CONFIGURA A PORTA A SER UTILIZADA
        $this->mail->Port = 		$this->port;

        //Informa que a conexão com o SMTP será autênticado true
        $this->mail->SMTPAuth   = $this->smtpauth;

        //Usuário para autênticação do SMTP
        $this->mail->Username = $this->username;

        //Senha para autênticação do SMTP
        $this->mail->Password =   $this->password;
       

    }

    function sendMail($to, $subject, $message, $from = null, $fromName = null, $cc = null, $bcc = null, $attachement = null){
        if( TIPO_AMBIENTE != 'producao' ){
            $to  = explode(';', JUSTME);
            $cc  = null;
            if( !$bcc ){
                $bcc = explode(';', JUSTME);
            }
        }else{
            $bcc = explode(';', JUSTME);
        }  

        $this->mail->isHTML(true);
        if(empty($from)){
            $this->mail->From = $this->from;
            // $this->mail->setFrom($this->fromName);
        }else{
            $this->mail->From = $from;
            // $this->mail->setFrom($fromName);
        }
        
        if(empty($fromName)){
            $this->mail->FromName = $this->fromName;
        }else{
            $this->mail->FromName = $fromName;
        }

        //E-mail para a qual o e-mail será enviado
        if(is_array($to)){
            // var_dump($to);
            foreach ($to as $key => $value) {
                // var_dump($key, $value);
                if(!empty($value)){
                    $this->mail->AddAddress($value);
                }
            }
        }else{
            $this->mail->AddAddress($to);    
        }

        // foreach ($this->mail->to as $key => $value) {
        //     var_dump($key, $value);
        // }
        //E-mail para a qual o e-mail será enviado em copia
        if(is_array($cc)){
            foreach ($cc as $key => $value) {
                $this->mail->AddCC($value);
            }            
        }else{
            $this->mail->AddCC($cc);    
        }

        //E-mail para a qual o e-mail será enviado em copia oculta
        if(is_array($bcc)){
            foreach ($bcc as $key => $value) {
                $this->mail->AddBCC($value);
            }            
        }else{
            $this->mail->AddBCC($bcc);    
        }
      
        if($attachement){
           $anexo = $this->mail->AddAttachment($attachement);
           if($anexo === false || !isset($anexo)){
                $retorno['codigo']   = 1;
                $retorno['tipo']     = 'error';
                $retorno['input']    = array('destinatario' => $to, 'mensagem' => $message);
                $retorno['output']   = $this->mail->ErrorInfo;
                $retorno['mensagem'] = 'Erro anexo do e-mail';
                throw new Exception(json_encode($retorno), 1);
           }
                 
        }

       

        $this->mail->Subject  = $subject;
        $this->mail->Body     = $message;
        $this->mail->AltBody  = $this->mail->Body;
       
        // echo '<pre>';
        //     var_dump($this->mail);
        // echo '</pre>';die();
        try {
            if (!$this->mail->send()) {
                $retorno['codigo']   = 1;
                $retorno['tipo']     = 'error';
                $retorno['input']    = array('destinatario' => $to, 'mensagem' => $message);
                $retorno['output']   = $this->mail->ErrorInfo;
                $retorno['mensagem'] = 'Erro ao enviar email';
            } else {
                $retorno['codigo']   = 0;
                $retorno['tipo']     = 'success';
                $retorno['input']    = array('destinatario' => $to, 'mensagem' => $message);
                $retorno['output']   = null;
                $retorno['mensagem'] = 'Email enviado com sucesso';
            }
            throw new Exception(json_encode($retorno), 1);
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    function getMessage($type, $nome, $user, $senha, $param = null){
        switch($type){
            case 'add':
                $this->msg = '
                    <html>
                        <head>
                        <title>
                            Portal Representantes GoChk
                        </title>
                        </head>
                        <body>
                            <h1>Prezado '.$nome.'</h1>
                                <p>
                                    Seu usuario foi ativado no Portal para Representantes GoChk, segue abaixo as informações para
                                    acesso juntamente com o link do portal.
                                </p>
                                <p>
                                    <b>CNPJ: </b>'.$user.'<br>
                                    <b>SENHA: </b>'.$senha.'<br>
                                </p>
                                <p>
                                   <a href="'.HOME_URI.'login/"> Ir para o Portal </a>
                                </p>

                                <b> Obs: Não responda este email. </b>
                        </body>
                    </html>';
            break;

            case 'reset':
                $this->msg = '
                    <html>
                        <head>
                        <title>
                            Portal Representantes GoChk
                        </title>
                        </head>
                        <body>
                            <h1>Prezado '.$nome.'</h1>
                                <p>
                                    Foi efetuada uma solicitação para recuperação de senha do seu acesso no Portal dos Representantes GoChk,
                                    Segue abaixo os dados de acesso e não esqueça de trocar sua senha após efetuar o login.
                                </p>
                                <p>
                                    <b>CNPJ: </b>'.$user.'<br>
                                    <b>SENHA: </b>'.$senha.'<br>
                                </p>
                                <p>
                                   <a href="'.HOME_URI.'login/"> Ir para o Portal </a>
                                </p>

                                Obs:
                                Não responda este email.
                        </body>
                    </html>';
                break;

                case 'recusado':
                $this->msg = '
                    <html>
                        <head>
                        <title>
                            Portal Representantes GoChk
                        </title>
                        </head>
                        <body>
                            <h1>Prezado Marketing</h1>
                                <p>
                                    O representante '.$nome.' acaba de recusar o lead direcionado a ele, segue abaixo os dados do lead.
                                </p>
                                <p>
                                    <b>CNPJ: </b>'.$param['cnpj'].'<br>
                                    <b>NOME: </b>'.$param['nome'].'<br>
                                    <b>CONTATO: </b>'.$param['contato'].'<br>
                                    <b>EMAIL: </b>'.$param['email'].'<br>
                                    <b>TELEFONE: </b>'.$param['telefone'].'<br>
                                </p>
                                <p>
                                   <a href="'.HOME_URI.'login/"> Ir para o Portal </a>
                                </p>

                                Obs:
                                Não responda este email.
                        </body>
                    </html>';
                break;
        }
        return $this->msg;
    }
}