<?php
  	set_time_limit(7200);
	require_once('class-CalculosData.php');
	require_once 'class-Email.php';
	class Faturamento extends Main{
		protected $log;
		protected $obj_integracao;
		protected $obj_arquivo;
		protected $obj_movimento;
		protected $obj_contrato;
		protected $obj_produto;
		protected $obj_imposto;
		protected $obj_faturamento;
		protected $fatura_modelo;
		protected $obj_indice;
		protected $obj_conta_bancaria;
		protected $obj_nf;
		protected $meios_recebimento;
		protected $contrato;
		protected $data_hora_atual;
		protected $hoje;
		protected $obj_email;
		protected $date;
		protected $consolidado;
		protected $notificacoes;
		protected $integracao;
		function __construct($controller, $do_login = true){
			parent::__construct($controller);
			$this->data_hora_atual = getDataAtual();
			$this->hoje 		   = getDataAtual();
			$this->notificacoes    = new Notificacoes($this->controller);
			//Objeto com acesso a base de dados de cadastros;		
			$this->obj_arquivo  = new Arquivos($this->controller);
			//Objeto com acesso a base de dados de cadastros;		
			$this->obj_contrato = $this->controller->load_model('contratos/contratos', true);
			//Objeto com acesso a base de dados de notas fiscais;
			$this->obj_nf = $this->controller->load_model('notas-fiscais/notas-fiscais', true);
			//Objeto com acesso a base de dados de impostos;
			$this->obj_imposto = $this->controller->load_model('impostos/impostos', true);
			//Objeto com acesso a base de dados de produtos;
			$this->obj_produto = $this->controller->load_model('cadastros/produtos', true);
			//Objeto com acesso a base de dados de faturamento;
			$this->obj_faturamento = $this->controller->load_model('faturamento/faturamento', true);
			$this->fatura_modelo = $this->controller->load_model('faturas/faturas', true);
			//Objeto com acesso a base de dados de indices;
			$this->obj_indice = $this->controller->load_model('indices/indices', true);
			//get meios de recebimento
			$this->obj_conta_bancaria = new ContaBancaria($controller);
			//objeto com acesso a base de dados de movimento diario;
			$db_movimento['db_name']  = DB_NAME_MOVIMENTO;
			$controller_movimento 	  = new MainController(null, 'faturamento', false);
			$this->obj_movimento      = $controller_movimento->load_model('movimento/movimento', true);
			$this->obj_movimento->setDb(new Db($db_movimento));
		}

		// verificar funcoes abaixo se ainda são utilizadas
		function getDataHoraAtual(){
			return $this->data_hora_atual;
		}

		//metodos usado no consolidado cliente da producao
		function calcVies($codigo_modulo, $codigo_cliente, $date = null)
		{
			if ($date) {
				$this->setDate($date);
				$now = $this->date->format('Y-m-d');
				$dia1_mes_atual = $this->date->format('Y-m') . '-01';
			} else {
				$this->setDate($this->hoje->format('Y-m-d'));
				$now = $this->hoje->format('Y-m-d');
				$dia1_mes_atual = $this->hoje->format('Y-m') . '-01';
			}

			$this->date->sub(new DateInterval("P31D"));
			$dia_anterior =  $this->date->format('Y-m-d');
			$dia1_mes_anterior = $this->date->format('Y-m') . '-01';
			$vies_ant     = json_decode($this->getTarifacaoPorPeriodo($dia1_mes_anterior, $dia_anterior, $codigo_modulo, $codigo_cliente));
			$vies_atual = json_decode($this->getTarifacaoPorPeriodo($dia1_mes_atual, $now, $codigo_modulo, $codigo_cliente));

			if (!$vies_ant) {
				$vies_ant = 0;
			} else {
				$vies_ant = $vies_ant[0]->total_transacoes;
			}

			if (!$vies_atual) {
				$vies_atual = 0;
			} else {
				$vies_atual = $vies_atual[0]->total_transacoes;
			}

			if ($vies_ant > $vies_atual) {
				//vies negativo
				$vies_resume = (- (abs(1 - ($vies_atual / $vies_ant))));
				//echo ' Valor negativo: '.$vies_resume.'<br>';
			} else {
				//vies positivo;
				if(isset($vies_atual) && $vies_atual > 0){
					$vies_resume = (abs(1 - ($vies_ant / $vies_atual)));
				}else{
					$vies_resume = (abs(1 - ($vies_ant / 1)));
				}
			}
			return $vies_resume;
		}

		function getTarifacaoPorPeriodo($dt_ini, $dt_fim, $modulo = null, $codigo_cliente = null)
		{
			return $this->obj_movimento->getMovByDateIntervalPorModulo($dt_ini, $dt_fim, $modulo, $codigo_cliente);
		}

		function calcDataFaturamento($ultimo_fechamento, $dias_faturar)
		{
			$this->setDate($ultimo_fechamento);
			$this->date->add(new DateInterval("P" . $dias_faturar . "D"));
			if ($this->date->format('l') == 'Saturday') {
				$this->date->add(new DateInterval("P2D"));
			} elseif ($this->date->format('l') == 'Sunday') {
				$this->date->add(new DateInterval("P1D"));
			}
			return $this->date->format('Y-m-d');
		}

		function getNextFechamento($ultimo_fechamento)
		{ // verificar a remoção desse metodo
			$this->setDate($ultimo_fechamento);
			$this->date->add(new DateInterval("P1M"));
			$this->date->sub(new DateInterval("P1D"));
			return $this->date->format('Y-m-d');
		}

		function nextFechamento($dt1, $dia_corte)
		{
			$dt2 = new DateTime($dt1->format('Y-m-' . $dia_corte));
			$dt2->sub(new DateInterval('P1D'));
			if ($dt1->format('Ymd') >= $dt2->format('Ymd')) {
				$dt2->add(new DateInterval('P1M'));
			}
			return $dt2;
		}

		function getDataCorte($dia_corte, $ano_mes = null){
			if ($ano_mes) {
				$data_corte = $ano_mes . '-' . $dia_corte;
				$this->setDate($data_corte);
			} else {
				$ano_mes_corte = $this->hoje->format('Y-m');
				$data_corte = $ano_mes_corte . '-' . $dia_corte;
				$this->setDate($data_corte);
			}
			//$this->date->add(new DateInterval( "P1D"));
			$this->date->sub(new DateInterval("P1D"));
			return $this->date->format('Y-m-d');
		}

		function getLastFechamento($dia_corte, $ano_mes = null){
			$data_corte = $this->getDataCorte($dia_corte, $ano_mes);
			if ($ano_mes) {
				$this->setDate($data_corte);
				if (strtotime($this->date->format('Y-m-d')) >= strtotime($data_corte)) {
					return $data_corte;
				} else {
					$this->setDate($this->hoje->format('Y-m') . '-' . $dia_corte);
					$this->date->sub(new DateInterval("P1M"));
					$this->date->add(new DateInterval("P1D"));
					return $this->date->format('Y-m-d');
				}
			} else {
				if (strtotime($this->hoje->format('Y-m-d')) >= strtotime($data_corte)) {
					return $data_corte;
				} else {
					$this->date->sub(new DateInterval("P1M"));
					$this->date->add(new DateInterval("P1D"));
					return $this->date->format('Y-m-') . $dia_corte;
				}
			}
		}

		function getContratosAtivos($id_contrato = null){
			return $this->obj_contrato->customGetRecordsAtivos($id_contrato); //
			//return $this->obj_contrato->customGetRecordsAtivos( array('COB0001') );
		}

		function getContratosPorEmpresa($cnpj_cm = null, $id_empresa = null, $include_adm = null){
			return $this->obj_contrato->getContratosPorEmpresa($cnpj_cm, $id_empresa, $include_adm);
		}

		function setDate($date = null){
			if ($date) {
				$this->date = new DateTime($date, new DateTimeZone('America/Sao_Paulo'));
			} else {
				$this->date = new DateTime('now', new DateTimeZone('America/Sao_Paulo'));
			}
		}

		function getComercial($id_contrato){
			$return = json_decode($this->obj_contrato->getComercial($id_contrato));
			if ($return) {
				$return = $return[0]->nome;
				return $return;
			} else {
				return false;
			}
		}

		function getMovDiarioCosolidadoCliente($ano = null, $mes = null){
			$clientes = null;
			$consolidado = null;
			$dados_faturamento = $this->getAnaliticoPorPeriodo($ano, $mes, 'relatorio');
			$x = 0;
			if ($dados_faturamento) {
				foreach ($dados_faturamento as $key => $value) {
					if ($value['codigo_cliente']) {
						$codigo_cliente = $value['codigo_cliente'];
						$codigo_produto = $value['codigo_produto'];
						if (!isset($clientes[$codigo_cliente][$codigo_produto])) {
							$clientes[$codigo_cliente][$codigo_produto] = $value;
						} else {
							$clientes[$codigo_cliente][$codigo_produto]['vies'] += $value['vies'];
							$clientes[$codigo_cliente][$codigo_produto]['qtd_transacoes'] += $value['qtd_transacoes'];
							$clientes[$codigo_cliente][$codigo_produto]['total_faturamento'] += $value['total_faturamento'];
							$clientes[$codigo_cliente][$codigo_produto]['previsao_faturamento'] += $value['previsao_faturamento'];
							$clientes[$codigo_cliente][$codigo_produto]['fatura_aberta'] = $value['fatura_aberta'];
						}
					}
				}

				foreach ($clientes as $key => $value) {
					foreach ($value as $chave => $valor) {
						$consolidado[] = $valor;
					}
				}
				if ($consolidado) {
					return $consolidado;
				} else {
					return false;
				}
			} else {
				echo 'Sem dados para faturamento';
			}
		}

		function getAnaliticoPorPeriodo($ano = null, $mes = null, $tipo = 'faturamento', $id_contrato = null){
			$dias_uteis = new DiasUteis();
			$contratos = json_decode($this->getContratosAtivos($id_contrato));
			$x = 0;
			if ($contratos) {
				$ano 		  = 2018;
				$mes 		  = 01;
				$ano_mes 	  = null;
				$primeiro_dia = null;
				$now 		  = null;
				$ultimo_dia	  = null;
				$ano_atual    = null;
				$chave 		  = null;
				if ($ano && $mes) {
					if ($tipo == 'faturamento') {
						$ano_mes = $ano . '-' . $mes;
						$this->setDate($ano_mes . '-02');
						$ultimo_dia = $this->date->format('Y-m-d');
						$this->date->sub(new DateInterval("P28D"));
						$primeiro_dia = $this->date->format('Y-m-03');
						$now = $ultimo_dia;
						$start = $primeiro_dia;
						$end =  $ultimo_dia;
					} elseif ($tipo == 'producao') {
						$ano_mes = $ano . '-' . $mes;
						$this->setDate($ano_mes . '-01');
						$primeiro_dia = $this->date->format('Y-m-d');
						$ultimo_dia = $ano_mes . '-' . cal_days_in_month(CAL_GREGORIAN, $mes, $ano);
						$now = $ultimo_dia;
						$start = $primeiro_dia;
						$end =  $ultimo_dia;
					}
				} else {
					if ($tipo == 'faturamento') {
						$ano_atual = $this->hoje->format('Y');
						$mes_atual = $this->hoje->format('m');
						$this->setDate($this->hoje->format('y-m-d'));
						$ultimo_dia = $this->date->format('Y-m-02');
						$this->date->sub(new DateInterval("P28D"));
						$primeiro_dia = $this->date->format('Y-m-03');
						if ($this->hoje->format('d') == $ultimo_dia) {
							$now = $ano_mes . '-' . $ultimo_dia;
						} else {
							$now = $ano_mes . '-' . $this->hoje->format('d');
						}
						$start = $primeiro_dia;
						$end =  $ultimo_dia;
					} elseif ($tipo == 'producao') {
						$ano_atual = $this->hoje->format('Y');
						$mes_atual = $this->hoje->format('m');
						$ano_mes = $ano_atual . '-' . $mes_atual;
						$primeiro_dia = $this->hoje->format('Y-m-01');
						$ultimo_dia = $this->hoje->format('Y-m-' . cal_days_in_month(CAL_GREGORIAN, $mes_atual, $ano_atual));
						if ($this->hoje->format('d') == $ultimo_dia) {
							$now = $ano_mes . '-' . $ultimo_dia;
						} else {
							$now = $ano_mes . '-' . $this->hoje->format('d');
						}
						$start = $primeiro_dia;
						$end =  $ultimo_dia;
					}
				}

				foreach ($contratos as $key => $value) {
					if (isset($value->data_corte_faturamento) && !empty($value->data_corte_faturamento)) {
						$data_corte = sprintf("%02s", $value->data_corte_faturamento);
					} else {
						$data_corte = '02';
					}
					if (isset($value->numero_dias_apos_corte) && !empty($value->numero_dias_apos_corte)) {
						$dias_faturar = $value->numero_dias_apos_corte;
					} else {
						$dias_faturar = '10';
					}
					if ($tipo == 'relatorio') {
						if ($ano && $mes) {
							$mes = sprintf("%02s", $mes);
							$periodo = new DateTime($ano . $mes . $data_corte);
						} else {
							$periodo = new DateTime($this->hoje->format('Y-m-' . $data_corte), new DateTimeZone('America/Sao_Paulo'));
						}
						$start = $periodo;
						$start = $periodo->format('Y-m-d');
						$end   = $periodo;
						$end->add(new DateInterval("P1M"));
						$end->sub(new DateInterval("P1D"));
						$end   = $end->format('Y-m-d');
					}

					$comercial = $this->getComercial($value->id_contrato);
					$ultimo_fechamento = $this->getLastFechamento($data_corte, $ano_mes);
					$proximo_fechamento = $this->getNextFechamento($ultimo_fechamento);
					$proximo_faturamento = $this->calcDataFaturamento($proximo_fechamento, $dias_faturar);
					$data_faturamento = $this->calcDataFaturamento($ultimo_fechamento, $dias_faturar);
					$dias_uteis_ate_agora = $dias_uteis->dias_uteis($primeiro_dia, $now);
					$dias_uteis_ate_fechamento = $dias_uteis->dias_uteis($now, $ultimo_dia);
					$faturamento_resume = json_decode($this->getTarifacaoPorPeriodo($start, $end, $value->codigo_modulo, $value->codigo_cliente));
					$pacote = json_decode($this->obj_contrato->getPacotesByContrato($value->id_contrato, $value->id_modulo));
					$faturas = json_decode($this->obj_nf->getNotasPorStatusOuVencimento('receber', null, $value->id_contrato, $value->codigo_produto));
					if (!empty($faturas)) {
						$fatura_aberta = 1;
					} else {
						$fatura_aberta = 0;
					}

					if (!empty($faturamento_resume[0])) {
						if ($value->codigo_produto == 'COB0001') {
							$consolidado[$x]['data_consolidado'] = $ultimo_dia;
							$consolidado[$x]['id_contrato'] = $value->id_contrato;
							$consolidado[$x]['codigo_cliente'] = $value->codigo_cliente;
							$consolidado[$x]['razao_social'] = $value->razao_social;
							$consolidado[$x]['nome_fantasia'] = (!empty($value->nome_fantasia)) ? $value->nome_fantasia : $value->razao_social;
							$consolidado[$x]['empresa_vendedora'] = $value->empresa_vendedora;
							$consolidado[$x]['comercial'] = $comercial;
							$consolidado[$x]['id_produto'] = $value->id_produto;
							$consolidado[$x]['codigo_produto'] = $value->codigo_produto;
							$consolidado[$x]['nome_produto'] = $value->nome_produto;
							$consolidado[$x]['codigo_modulo'] = $value->codigo_modulo;
							$consolidado[$x]['id_modulo'] = $value->id_modulo;
							$consolidado[$x]['nome_modulo'] = $value->nome_modulo;
							$consolidado[$x]['dias_faturamento'] = $dias_faturar;
							$consolidado[$x]['data_corte_faturamento'] = $data_corte;
							$consolidado[$x]['data_faturamento'] = $proximo_faturamento;
							$consolidado[$x]['periodo_producao_de'] = $start;
							$consolidado[$x]['periodo_producao_ate'] = $end;
							$consolidado[$x]['periodo_faturamento_de'] = $start;
							$consolidado[$x]['periodo_faturamento_ate'] = $end;
							$consolidado[$x]['fatura_aberta'] = $fatura_aberta;
							$consolidado[$x]['vies'] = $this->calcVies($value->codigo_modulo, $value->codigo_cliente, $now);

							foreach ($faturamento_resume as $chave => $valor) {
								if ($valor->total_valor) {
									$lista_preco = $this->obj_contrato->getCustomListaPreco($value->id_contrato, $value->id_modulo);
									if ($lista_preco) {
										$valor_calculado = (float) (($valor->total_valor / 100) * $lista_preco[0]['percentual']);
									} else {
										$valor_calculado = -1;
									}
								} else {
									$valor_calculado = 0;
								}

								if ($valor_calculado) {
									$valor_ate_o_momento = (float) $valor_calculado;
									$media_atual = ($valor_ate_o_momento / $dias_uteis_ate_agora);
									$media_prevista = ($media_atual * $dias_uteis_ate_fechamento);
									$previsao_faturamento = (($valor_ate_o_momento + $media_prevista));
								} else {
									$valor_ate_o_momento = 0;
									$media_atual = 0;
									$media_prevista = 0;
									$previsao_faturamento = ($valor_ate_o_momento  + $media_prevista);
								}
								$consolidado[$x]['previsao_faturamento'] = $previsao_faturamento;
								$consolidado[$x]['qtd_transacoes'] = $valor->total_transacoes;
								$consolidado[$x]['valor_total'] = $valor->total_valor;
								$consolidado[$x]['total_faturamento'] = $valor_ate_o_momento;
								/*echo ' data de corte '.$dia_corte.' periodo de faturamento de: '.$data_inicio_faturamento.' até: '.$data_fim_faturamento.' a fatura dia: '.$this->calcDataFaturamento($dia_corte, $dias_faturar).' -  dias para faturamento: '.$dias_faturar.'<br>';*/
							}	//fim do else cob0001
						} elseif ($value->codigo_produto == 'RCK0001') {
							$consolidado[$x]['data_consolidado'] = $ultimo_dia;
							$consolidado[$x]['id_contrato'] = $value->id_contrato;
							$consolidado[$x]['codigo_cliente'] = $value->codigo_cliente;
							$consolidado[$x]['razao_social'] = $value->razao_social;
							$consolidado[$x]['nome_fantasia'] = (!empty($value->nome_fantasia)) ? $value->nome_fantasia : $value->razao_social;
							$consolidado[$x]['empresa_vendedora'] = $value->empresa_vendedora;
							$consolidado[$x]['id_produto'] = $value->id_produto;
							$consolidado[$x]['codigo_produto'] = $value->codigo_produto;
							$consolidado[$x]['nome_produto'] = $value->nome_produto;
							$consolidado[$x]['id_modulo'] = $value->id_modulo;
							$consolidado[$x]['codigo_modulo'] = $value->codigo_modulo;
							$consolidado[$x]['nome_modulo'] = $value->nome_modulo;
							$consolidado[$x]['comercial'] = $comercial;
							$consolidado[$x]['dias_faturamento'] = $dias_faturar;
							$consolidado[$x]['data_corte_faturamento'] = $data_corte;
							$consolidado[$x]['data_faturamento'] = $proximo_faturamento;
							$consolidado[$x]['periodo_producao_de'] = $start;
							$consolidado[$x]['periodo_producao_ate'] = $end;
							$consolidado[$x]['periodo_faturamento_de'] = $start;
							$consolidado[$x]['periodo_faturamento_ate'] = $end;
							$consolidado[$x]['fatura_aberta'] = $fatura_aberta;
							$consolidado[$x]['vies'] = $this->calcVies($value->codigo_modulo, $value->codigo_cliente, $now);
							if(isset($faturamento_resume[0]->total_horas)){
								$consolidado[$x]['total_horas'] = $faturamento_resume[0]->total_horas;
							}else{
								$consolidado[$x]['total_horas'] = 0;
							}
							$consolidado[$x]['qtd_transacoes'] = $faturamento_resume[0]->total_transacoes;
							if ($pacote && !empty($pacote[0]->preco_pkt)) {
								$pacote_quantidade = $pacote[0]->qdt_garantido;
								$pacote_valor = $pacote[0]->preco_pkt;
							} else {
								$pacote_quantidade = null;
								$pacote_valor = null;
							}

							if ($pacote_quantidade >= $faturamento_resume[0]->total_transacoes) {
								$total_faturamento = $pacote_valor;
								$previsao_faturamento = $pacote_valor;
								$consolidado[$x]['previsao_faturamento'] = $previsao_faturamento;
								$consolidado[$x]['valor_total'] = $total_faturamento;
								$consolidado[$x]['total_faturamento'] = $total_faturamento;
							} else {
								if ($faturamento_resume[0]->codigo_modulo == 'RCK0033' || $faturamento_resume[0]->codigo_modulo == 'RCK0034') {
									$consolidado[$x]['valor_total'] = $faturamento_resume[0]->total_valor;
									$consolidado[$x]['total_faturamento'] = $faturamento_resume[0]->total_valor;
									$consolidado[$x]['previsao_faturamento'] = $faturamento_resume[0]->total_valor;
								} else {
									$where = $faturamento_resume[0]->total_transacoes . " >=  qtd_de and " . $faturamento_resume[0]->total_transacoes . " <= qtd_ate ";
									$lista_preco = $this->obj_contrato->getCustomListaPreco($value->id_contrato, $value->id_modulo, $where);
									if ($lista_preco) {
										$total_faturamento = ($faturamento_resume[0]->total_transacoes * $lista_preco[0]['valor_real']);
										$consolidado[$x]['valor_total'] = $total_faturamento;
										$consolidado[$x]['total_faturamento'] = $total_faturamento;
										if(isset($dias_uteis_ate_agora) && $dias_uteis_ate_agora > 0){
											$media_atual = ($total_faturamento / $dias_uteis_ate_agora);
										}else{
											$media_atual = 0;
										}
										$media_prevista = ($media_atual * $dias_uteis_ate_fechamento);
										$previsao_faturamento = (($total_faturamento + $media_prevista));
										$consolidado[$x]['previsao_faturamento'] = $previsao_faturamento;
									} else {
										$consolidado[$x]['valor_total'] = 0;
										$consolidado[$x]['total_faturamento'] = 0;
										$consolidado[$x]['previsao_faturamento'] = -1;
									}
								}
							}
							//fim do else rck0001
						} elseif ($value->codigo_produto == 'ADM0001') {
							$consolidado[$x]['data_consolidado'] = $ultimo_dia;
							$consolidado[$x]['id_contrato'] = $value->id_contrato;
							$consolidado[$x]['codigo_cliente'] = $value->codigo_cliente;
							$consolidado[$x]['razao_social'] = $value->razao_social;
							$consolidado[$x]['nome_fantasia'] = (!empty($value->nome_fantasia)) ? $value->nome_fantasia : $value->razao_social;
							$consolidado[$x]['empresa_vendedora'] = $value->empresa_vendedora;
							$consolidado[$x]['id_produto'] = $value->id_produto;
							$consolidado[$x]['codigo_produto'] = $value->codigo_produto;
							$consolidado[$x]['nome_produto'] = $value->nome_produto;
							$consolidado[$x]['id_modulo'] = $value->id_modulo;
							$consolidado[$x]['codigo_modulo'] = $value->codigo_modulo;
							$consolidado[$x]['nome_modulo'] = $value->nome_modulo;
							$consolidado[$x]['comercial'] = $comercial;
							$consolidado[$x]['dias_faturamento'] = $dias_faturar;
							$consolidado[$x]['data_corte_faturamento'] = $data_corte;
							$consolidado[$x]['data_faturamento'] = $proximo_faturamento;
							$consolidado[$x]['periodo_producao_de'] = $start;
							$consolidado[$x]['periodo_producao_ate'] = $end;
							$consolidado[$x]['periodo_faturamento_de'] = $start;
							$consolidado[$x]['periodo_faturamento_ate'] = $end;
							$consolidado[$x]['fatura_aberta'] = $fatura_aberta;
							$consolidado[$x]['vies'] = $this->calcVies($value->codigo_modulo, $value->codigo_cliente, $now);
							$consolidado[$x]['qtd_transacoes'] = $faturamento_resume[0]->total_transacoes;
							$consolidado[$x]['total_horas'] = $faturamento_resume[0]->total_horas;
							$consolidado[$x]['valor_total'] = $faturamento_resume[0]->total_valor;
							$consolidado[$x]['total_faturamento'] = $faturamento_resume[0]->total_valor;
							$media_atual = ($faturamento_resume[0]->total_valor / $dias_uteis_ate_agora);
							$media_prevista = ($media_atual * $dias_uteis_ate_fechamento);
							$previsao_faturamento = (($faturamento_resume[0]->total_valor + $media_prevista));
							$consolidado[$x]['previsao_faturamento'] = $previsao_faturamento;
							//fim do else amd0001
						} elseif ($value->codigo_produto == 'GCK0001') {
							$consolidado[$x]['data_consolidado'] = $ultimo_dia;
							$consolidado[$x]['id_contrato'] = $value->id_contrato;
							$consolidado[$x]['codigo_cliente'] = $value->codigo_cliente;
							$consolidado[$x]['razao_social'] = $value->razao_social;
							$consolidado[$x]['nome_fantasia'] = (!empty($value->nome_fantasia)) ? $value->nome_fantasia : $value->razao_social;
							$consolidado[$x]['empresa_vendedora'] = $value->empresa_vendedora;
							$consolidado[$x]['id_produto'] = $value->id_produto;
							$consolidado[$x]['codigo_produto'] = $value->codigo_produto;
							$consolidado[$x]['nome_produto'] = $value->nome_produto;
							$consolidado[$x]['id_modulo'] = $value->id_modulo;
							$consolidado[$x]['codigo_modulo'] = $value->codigo_modulo;
							$consolidado[$x]['nome_modulo'] = $value->nome_modulo;
							$consolidado[$x]['comercial'] = $comercial;
							$consolidado[$x]['dias_faturamento'] = $dias_faturar;
							$consolidado[$x]['data_corte_faturamento'] = $data_corte;
							$consolidado[$x]['data_faturamento'] = $proximo_faturamento;
							$consolidado[$x]['periodo_producao_de'] = $start;
							$consolidado[$x]['periodo_producao_ate'] = $end;
							$consolidado[$x]['periodo_faturamento_de'] = $start;
							$consolidado[$x]['periodo_faturamento_ate'] = $end;
							$consolidado[$x]['fatura_aberta'] = $fatura_aberta;
							$consolidado[$x]['vies'] = $this->calcVies($value->codigo_modulo, $value->codigo_cliente, $now);
							$consolidado[$x]['qtd_transacoes'] = $faturamento_resume[0]->total_transacoes;
							$consolidado[$x]['total_horas'] = $faturamento_resume[0]->total_horas;

							if ($faturamento_resume[0]->codigo_modulo != 'GCK0018' && $faturamento_resume[0]->codigo_modulo != 'GCK0099') {
								$consolidado[$x]['previsao_faturamento'] += ($faturamento_resume[0]->total_valor / 1.1333);
							} elseif ($faturamento_resume[0]->codigo_modulo == 'GCK0099') {
								$consolidado[$x]['valor_total'] += ($faturamento_resume[0]->total_valor / 1.1333);
								$consolidado[$x]['total_faturamento'] += ($faturamento_resume[0]->total_valor / 1.1333);
							}
							//fim do else GCK0001
						} elseif ($value->codigo_produto == 'SPB0001') {
							$consolidado[$x]['data_consolidado'] = $ultimo_dia;
							$consolidado[$x]['id_contrato'] = $value->id_contrato;
							$consolidado[$x]['codigo_cliente'] = $value->codigo_cliente;
							$consolidado[$x]['razao_social'] = $value->razao_social;
							$consolidado[$x]['nome_fantasia'] = (!empty($value->nome_fantasia)) ? $value->nome_fantasia : $value->razao_social;
							$consolidado[$x]['empresa_vendedora'] = $value->empresa_vendedora;
							$consolidado[$x]['id_produto'] = $value->id_produto;
							$consolidado[$x]['codigo_produto'] = $value->codigo_produto;
							$consolidado[$x]['nome_produto'] = $value->nome_produto;
							$consolidado[$x]['codigo_modulo'] = $value->codigo_modulo;
							$consolidado[$x]['id_modulo'] = $value->id_modulo;
							$consolidado[$x]['nome_modulo'] = $value->nome_modulo;
							$consolidado[$x]['comercial'] = $comercial;
							$consolidado[$x]['dias_faturamento'] = $dias_faturar;
							$consolidado[$x]['data_corte_faturamento'] = $data_corte;
							$consolidado[$x]['data_faturamento'] = $proximo_faturamento;
							$consolidado[$x]['periodo_producao_de'] = $start;
							$consolidado[$x]['periodo_producao_ate'] = $end;
							$consolidado[$x]['periodo_faturamento_de'] = $start;
							$consolidado[$x]['periodo_faturamento_ate'] = $end;
							$consolidado[$x]['fatura_aberta'] = $fatura_aberta;
							$consolidado[$x]['vies'] = $this->calcVies($value->codigo_modulo, $value->codigo_cliente, $now);
							$consolidado[$x]['qtd_transacoes'] = $faturamento_resume[0]->total_transacoes;
							$consolidado[$x]['total_horas'] = (isset($faturamento_resume[0]->total_horas))?$faturamento_resume[0]->total_horas:0;
							if ($pacote && !empty($pacote[0]->preco_pkt)) {
								$pacote_quantidade = $pacote[0]->qdt_garantido;
								$pacote_valor = $pacote[0]->preco_pkt;
							} else {
								$pacote_quantidade = null;
								$pacote_valor = null;
							}

							if ($pacote_quantidade >= $faturamento_resume[0]->total_transacoes) {
								$total_faturamento = $pacote_valor;
								$previsao_faturamento = $pacote_valor;
								$consolidado[$x]['previsao_faturamento'] = $previsao_faturamento;
								$consolidado[$x]['valor_total'] = $total_faturamento;
								$consolidado[$x]['total_faturamento'] = $total_faturamento;
							} else {
								if ($faturamento_resume[0]->codigo_modulo == 'SPB0012' || $faturamento_resume[0]->codigo_modulo == 'SPB0013') {
									$consolidado[$x]['valor_total'] = $faturamento_resume[0]->total_valor;
									$consolidado[$x]['total_faturamento'] = $faturamento_resume[0]->total_valor;
									$consolidado[$x]['previsao_faturamento'] = $faturamento_resume[0]->total_valor;
								} elseif ($faturamento_resume[0]->codigo_modulo == 'SPB0011') {

									$quantidade_excedente = ($faturamento_resume[0]->total_transacoes - $pacote_quantidade);
									$where = $faturamento_resume[0]->total_transacoes . " >=  qtd_de and " . $quantidade_excedente . " <= qtd_ate ";
									$lista_preco = $this->obj_contrato->getCustomListaPreco($value->id_contrato, $value->id_modulo, $where);
									if ($lista_preco) {
										$total_faturamento = (($quantidade_excedente * $lista_preco[0]['valor_real']) + $pacote_valor);
										$consolidado[$x]['valor_total'] = $total_faturamento;
										$consolidado[$x]['total_faturamento'] = $total_faturamento;
										if(isset($dias_uteis_ate_agora) && $dias_uteis_ate_agora > 0){
											$media_atual = ($total_faturamento / $dias_uteis_ate_agora);			
										}else{
											$media_atual = ($total_faturamento / 1);
										}
										$media_prevista = ($media_atual * $dias_uteis_ate_fechamento);
										$previsao_faturamento = (($total_faturamento + $media_prevista));
										$consolidado[$x]['previsao_faturamento'] = $previsao_faturamento;
									} else {
										$consolidado[$x]['valor_total'] = 0;
										$consolidado[$x]['total_faturamento'] = 0;
										$consolidado[$x]['previsao_faturamento'] = -1;
									}
								} else {
									$where = $faturamento_resume[0]->total_transacoes . " >=  qtd_de and " . $faturamento_resume[0]->total_transacoes . " <= qtd_ate ";
									$lista_preco = $this->obj_contrato->getCustomListaPreco($value->id_contrato, $value->id_modulo, $where);
									if ($lista_preco) {
										$total_faturamento = ($faturamento_resume[0]->total_transacoes * $lista_preco[0]['valor_real']);
										$consolidado[$x]['valor_total'] = $total_faturamento;
										$consolidado[$x]['total_faturamento'] = $total_faturamento;
										$media_atual = ($total_faturamento / $dias_uteis_ate_agora);
										$media_prevista = ($media_atual * $dias_uteis_ate_fechamento);
										$previsao_faturamento = (($total_faturamento + $media_prevista));
										$consolidado[$x]['previsao_faturamento'] = $previsao_faturamento;
									} else {
										$consolidado[$x]['valor_total'] = 0;
										$consolidado[$x]['total_faturamento'] = 0;
										$consolidado[$x]['previsao_faturamento'] = -1;
									}
								}
							}
							// fim do else spb0001
						}
					} else {
						if ($pacote) {
							$total_faturamento = $pacote[0]->preco_pkt;
							$previsao_faturamento = $pacote[0]->preco_pkt;
							$consolidado[$x]['data_consolidado'] = $ultimo_dia;
							$consolidado[$x]['id_contrato'] = $value->id_contrato;
							$consolidado[$x]['codigo_cliente'] = $value->codigo_cliente;
							$consolidado[$x]['razao_social'] = $value->razao_social;
							$consolidado[$x]['nome_fantasia'] = (!empty($value->nome_fantasia)) ? $value->nome_fantasia : $value->razao_social;
							$consolidado[$x]['empresa_vendedora'] = $value->empresa_vendedora;
							$consolidado[$x]['comercial'] = $comercial;
							$consolidado[$x]['id_produto'] = $value->id_produto;
							$consolidado[$x]['codigo_produto'] = $value->codigo_produto;
							$consolidado[$x]['nome_produto'] = $value->nome_produto;
							$consolidado[$x]['codigo_modulo'] = $value->codigo_modulo;
							$consolidado[$x]['id_modulo'] = $value->id_modulo;
							$consolidado[$x]['nome_modulo'] = $value->nome_modulo;
							$consolidado[$x]['comercial'] = $comercial;
							$consolidado[$x]['dias_faturamento'] = $dias_faturar;
							$consolidado[$x]['data_corte_faturamento'] = $data_corte;
							$consolidado[$x]['data_faturamento'] = $proximo_faturamento;
							$consolidado[$x]['periodo_producao_de'] = $start;
							$consolidado[$x]['periodo_producao_ate'] = $end;
							$consolidado[$x]['periodo_faturamento_de'] = $start;
							$consolidado[$x]['periodo_faturamento_ate'] = $end;
							$consolidado[$x]['fatura_aberta'] = $fatura_aberta;
							$consolidado[$x]['vies'] = $this->calcVies($value->codigo_modulo, $value->codigo_cliente, $now);
							$consolidado[$x]['previsao_faturamento'] = $previsao_faturamento;
							$consolidado[$x]['valor_total'] = $total_faturamento;
							$consolidado[$x]['total_faturamento'] = $total_faturamento;
							$consolidado[$x]['qtd_transacoes'] = 0;
							$consolidado[$x]['total_horas'] = 0;
						}
					}
					$x++;
				}
				return $consolidado;
			} else {
				// retorna false caso não haja contratos ativos
				return false;
			}
		}

		// verificar funcoes acima se ainda são utilizadas
		function consultaPacotes($id_contrato, $codigo_modulo = null, $extras = null){
			$return = null;
			$pacotes = json_decode($this->obj_contrato->getPacotesPorContrato($id_contrato, $codigo_modulo));
			if ($pacotes) {
				foreach ($pacotes as $key => $value) {
					$percentual_desconto = 0;
					$valor_desconto = 0;
					$param[$key]['id_empresa_vendedora'] = $value->id_empresa;
					$param[$key]['id_contrato']          = $id_contrato;
					$param[$key]['id_produto']           = $value->id_produto;
					$param[$key]['codigo_produto']       = $value->codigo_produto;
					$param[$key]['nome_produto']         = $value->nome_produto;
					$param[$key]['id_modulo']            = $value->id_modulo;
					$param[$key]['codigo_modulo']        = $value->codigo_modulo;
					$param[$key]['nome_modulo']          = $value->nome_modulo;
					$param[$key]['data_faturamento']     = $this->data_hora_atual->format('Y-m-d');
					$param[$key]['tipo_cobranca']        = $value->tipo_cobranca;
					$param[$key]['transacoes']           = $value->qdt_garantido;
					$param[$key]['valor_liquido']        = funcValor($value->preco_pkt, 'A');
					$param[$key]['valor_total']          = funcValor($value->preco_pkt, 'A');
					$param[$key]['percentual_desconto']  = funcValor($percentual_desconto, 'A');
					$param[$key]['valor_desconto']  	 = funcValor($valor_desconto, 'A');
					$param[$key]['flag']                 = $value->flag;
					$param[$key]['pct_excedido']         = 0;
					$param[$key]['deleted']              = 0;
					$param[$key]['qtd_horas']            = 0; // campo serÃ¡ apagado da base
					//verificar a exclusão
					//$param[$key]['data_vencimento']      = $this->data_hora_atual->format('Y-m-d');
					$param[$key]['ano_mes_referencia']   = $this->data_hora_atual->format('Y-m');;
					$param[$key]['tipo']   		         = 'automatico';
				}
				$return = $param;
			}
			return json_encode($return);
		}

		function calcFaturamento($dados, $tipo_tarifacao = 'degrau')
		{
			$contador         = 0;
			$total_transacoes = null;
			$valor            = null;
			$valor_soma		  = null;
			$return           = null;
			$processar		  = true;
			$lista_preco 	  = json_decode($this->obj_contrato->getListaPrecoCliente($dados->id_contrato, $dados->id_produto, $dados->id_modulo, $dados->transacoes, $tipo_tarifacao));
			$pacote      	  = json_decode($this->consultaPacotes($dados->id_contrato, $dados->codigo_modulo));
			if (isset($dados->valor) && $dados->valor > 0) {
				$return['valor'] = funcValor($dados->valor, 'A');
				$return['transacoes'] = $dados->transacoes;
				$return['pacote']     = 1;
				return json_encode($return);
			} else {
				if (!$pacote && !$lista_preco) {
					$this->setErroMsg('Erro na geração de nota fiscal, modulo ' . $dados->nome_modulo . ' sem pacote, ou sem lista, ou com divergencia na quantidade');
					$processar 		  = false;
				} elseif (!$lista_preco && $pacote) {
					if ($dados->transacoes > $pacote[0]->transacoes) {
						$this->setErroMsg('Erro na geração de nota fiscal, modulo ' . $dados->nome_modulo . ' sem pacote, ou sem lista, ou com divergencia na quantidade');
						$processar 		  = false;
					}
				}
		
				if ($processar) {
					if ($dados->tipo_cobranca == 'VOLUMETRIA') {
						$total_transacoes 			     = $dados->transacoes;
						$return['desconto_quantidade']   = 0;
						if ($pacote) {
							$pacote_qtde  = $pacote[0]->transacoes;
							$pacote_valor = $pacote[0]->valor_liquido;
							if (isset($pacote[0]->flag) && !empty($pacote[0]->flag)) {
								$pacote_flag = $pacote[0]->flag;
							} else {
								$pacote_flag  = 'SD';
							}
						}
		
						if ($pacote_qtde >= $total_transacoes) {
							$return['valor']  = funcValor($pacote_valor, 'A');
							$return['pacote'] = 0;
						} else {
							$valor_soma += $pacote_valor;
							if ($tipo_tarifacao == 'degrau') {
								if (is_array($lista_preco)) {
									$total_transacoes -= $pacote_qtde;
									$totalizador      = $pacote_qtde;
									$intervalo_faixa  = 0;
									foreach ($lista_preco as $key => $value) {
										$valor_faixa = $value->valor_real;
										if (count($lista_preco) > 1) {
											$intervalo_faixa = ($value->qtd_ate - $value->qtd_de);
											if ($value->qtd_de >= $pacote_qtde) {
												$valor_faixa = $value->valor_real;
												$lista[] 	 = $contador;
												$contador 	 += $intervalo_faixa;
												if ($contador <= $total_transacoes) {
													$totalizador += $intervalo_faixa;
													$valor_soma  += ($intervalo_faixa * $valor_faixa);
												} else {
													$dif_transacao 	= ($total_transacoes - end($lista));
													$totalizador   	+= $dif_transacao;
													$valor_soma 	+= ($dif_transacao * $valor_faixa);
													break;
												}
											}
										} else {
											$intervalo_faixa = $total_transacoes;
											$totalizador 	 += $intervalo_faixa;
											$valor_soma  	 += ($intervalo_faixa * $valor_faixa);
										}
									}
								} elseif ($dados->codigo_modulo == 'RCK0035' && $dados->valor > 0) {
									$valor_soma = $dados->valor;
								} elseif ($dados->flag == 'manual' && $dados->valor > 0) {
									$valor_soma = $dados->valor;
								}
							} else {
								switch ($pacote_flag) {
									case 'CD':
										$total_transacoes -= $pacote_qtde;
										$return['desconto_quantidade'] = $pacote_qtde;
										break;
								}
								if ($lista_preco) {
									$valor_soma = ($lista_preco[0]->valor_real * $total_transacoes);
								} elseif ($dados->codigo_modulo == 'RCK0035' && $dados->valor > 0) {
									$valor_soma = $dados->valor;
								} else {
									$lista_preco = json_decode($this->obj_contrato->getListaPrecoCliente($dados->id_contrato, $dados->id_produto, $dados->id_modulo));
									if ($lista_preco) {
										$primeira_faixa = $lista_preco[0]->valor_real;
										$valor_soma     += ($primeira_faixa * $total_transacoes);
									} else {
										echo 'erro inconsistencia entre a lista de preço e pacote para: ';
										echo 'contrato ID ' . $dados->id_contrato . ' / ' . $dados->nome_produto  . ' - ' . $dados->nome_modulo . '<pre>';
										exit;
									}
								}
							}
							$return['valor'] = funcValor($valor_soma, 'A');
							$return['pacote'] = 1;
						}
					} elseif ($dados->tipo_cobranca == 'FAIXA-FIXA') {
						$pacote = json_decode($this->consultaPacotes($dados->id_contrato, $dados->codigo_modulo));
						if ($pacote && $pacote[0]->flag == 'CD') {
							$total_transacoes = ($dados->transacoes - $pacote[0]->transacoes);
							$return['desconto_quantidade'] = (float)$pacote[0]->transacoes;
						} else {
							$return['desconto_quantidade'] = 0;
							$total_transacoes = $dados->transacoes;
						}
		
						if ($pacote && $pacote[0]->transacoes >= $dados->transacoes) {
							$return['valor']  = funcValor($pacote[0]->valor_liquido, 'A');
							$return['pacote'] = 0;
						} else {
							$lista_preco = json_decode($this->obj_contrato->getListaPrecoCliente($dados->id_contrato, $dados->id_produto, $dados->id_modulo, $dados->transacoes, $tipo_tarifacao));
							if ($lista_preco) {
								$return['valor']  = funcValor($lista_preco[0]->valor_real, 'A');
								$return['pacote'] = 0;
							}
						}
					} elseif ($dados->tipo_cobranca == 'COBRANCA-ELETRONICA') {
						$lista_preco = json_decode($this->obj_contrato->getListaPrecoCliente($dados->id_contrato, $dados->id_produto, $dados->id_modulo, $dados->transacoes, $tipo_tarifacao));
						if ($lista_preco) {
							$valor_percentual = (($dados->valor / 100) * $lista_preco[0]->percentual);
							$return['valor']  = funcValor($valor_percentual, 'A');
							$return['pacote'] = 0;
						}
					} elseif ($dados->tipo_cobranca  == 'INCREMENTAL-VOLUMETRIA') {
						$valor            	= null;
						$pacote           	= json_decode($this->consultaPacotes($dados->id_contrato, $dados->codigo_modulo));
						$total_transacoes   = $dados->transacoes;
						if ($pacote && $pacote[0]->transacoes >= $dados->transacoes) {
							$valor = funcValor($pacote[0]->valor_liquido, 'A');
							$return['pacote'] = 0;
						} else {
							$lista_preco = json_decode($this->obj_contrato->getListaPrecoCliente($dados->id_contrato, $dados->id_produto, $dados->id_modulo, null, $tipo_tarifacao, $dados->tipo_cobranca));
							if ($lista_preco) {
								if ($pacote) {
									$valor = funcValor($pacote[0]->valor_liquido, 'A');
								}
								
								if (count($lista_preco) > 0) {
									$soma_conf = $pacote[0]->transacoes;
									$total_transacoes = $dados->transacoes;
									foreach ($lista_preco as $key => $value) {
										if ($pacote[0]->transacoes < $value->qtd_de &&  $dados->transacoes >= $value->qtd_de || ($dados->transacoes >= $value->qtd_de && $dados->transacoes <= $value->qtd_ate)) {
											if ($dados->transacoes <= $value->qtd_ate) {
												$transacoes_faixa = ($dados->transacoes - $value->qtd_de);
												$soma_conf += $transacoes_faixa;
												if ($soma_conf < $dados->transacoes) {
													$transacoes_faixa += ($dados->transacoes - $soma_conf);
												}
											} else {
												$transacoes_faixa = ($value->qtd_ate - $value->qtd_de);
												$soma_conf += $transacoes_faixa;
											}

											switch ($value->modalidade) {
												case 'FAIXA':
													$valor += $value->valor_real;
													break;
												default:
													$valor += ($value->valor_real * $transacoes_faixa);
													break;
											}
										}
									}
								}
							}
							$return['pacote'] = 1;
						}
						$return['valor']  = funcValor($valor, 'A');
					} elseif ($dados->tipo_cobranca  == 'FIXO-INCREMENTAL') {
						$pacote = json_decode($this->consultaPacotes($dados->id_contrato, $dados->codigo_modulo));
						if ($pacote && $pacote[0]->transacoes >= $dados->transacoes) {
							$return['valor'] = funcValor($pacote[0]->valor_liquido, 'A');
							$return['pacote'] = 0;
						} else {
							if ($pacote) {
								$return['valor']  = funcValor($pacote[0]->valor_liquido, 'A');
							}
							$lista_preco = json_decode($this->obj_contrato->getListaPrecoCliente($dados->id_contrato, $dados->id_produto, $dados->id_modulo, $dados->transacoes, $tipo_tarifacao, $dados->tipo_cobranca));
							if ($lista_preco) {
								if ($lista_preco[0]->qtd_de > 0) {
									$num_faixas  = floor(($dados->transacoes / $lista_preco[0]->qtd_de));
									$valor_total = ($num_faixas * $lista_preco[0]->valor_real);
								}
								$return['valor']  += funcValor($valor_total, 'A');
								$return['pacote'] = 1;
							}
						}
					} elseif ($dados->tipo_cobranca  == 'VALOR-FIXO') {
						if (isset($dados->valor_liquido)) {
							$return['valor'] = funcValor($dados->valor_liquido, 'A');
						} else {
							$return['valor'] = funcValor($dados->valor, 'A');
						}
						$return['transacoes'] = $dados->transacoes;
						$return['pacote']     = 1;
					}
					return json_encode($return);
				} else {
					if (isset($dados->valor) && $dados->valor > 0) {
						$return['valor'] = funcValor($dados->valor, 'A');
						$return['transacoes'] = $dados->transacoes;
						$return['pacote']     = 1;
						return json_encode($return);
					} else {
						return false;
					}
				}
			}
		}

		function checkFaturamento($dt_ini, $dt_fim, $contrato, $extras = null)
		{
			try {
				$retorno = null;
				if (!$dt_ini) {
					$retorno['code']    == 1;
					$retorno['type']    == 'danger';
					$retorno['message'] == 'Periodo inicial não informado ou incorreto';
					$retorno['dados']   == $dt_ini;
					throw new Exception(json_encode($retorno), 1);
				}

				if (!$dt_fim) {
					$retorno['code']    == 1;
					$retorno['type']    == 'danger';
					$retorno['message'] == 'Periodo final não informado ou incorreto';
					$retorno['dados']   == $dt_fim;
					throw new Exception(json_encode($retorno), 1);
				}

				if (!$contrato) {
					$retorno['code']    == 1;
					$retorno['type']    == 'danger';
					$retorno['message'] == 'Dados do contrato não informado';
					$retorno['dados']   == $dt_ini;
					throw new Exception(json_encode($retorno), 1);
				}

				$faturamento = $this->getMovRelPorContrato($dt_ini->format('Y-m-d'), $dt_fim->format('Y-m-d'), $contrato->id_contrato);
				$pacotes     = json_decode($this->consultaPacotes($contrato->id_contrato));
				if ($pacotes) {
					foreach ($pacotes as $key => $value) {
						if ($value->valor_liquido > 0) {
							if ($faturamento) {
								foreach ($faturamento as $k1 => $v1) {
									if ($v1->codigo_modulo == $value->codigo_modulo) {
										unset($pacotes[$key]);
									}
								}
							}
						}
					}

					foreach ($pacotes as $key => $value) {
						$faturamento[] = $value;
					}
				}

				if ($faturamento) {
					foreach ($faturamento as $k1 => $v1) {
						if (!$extras) {
							$v1->tipo_desconto  = 'percentual';
							$v1->valor_desconto = 0;
						}
						
						if (isset($v1->valor_liquido) && !isset($v1->valor)) {
							$v1->valor = $v1->valor_liquido;
						}
						
						$dados_calculo = json_decode($this->calcFaturamento($v1, $contrato->tipo_tarifacao));
						if ($dados_calculo) {
							if (isset($dados_calculo->desconto_quantidade)) {
								$v1->desconto_quantidade  = $dados_calculo->desconto_quantidade;
							} else {
								$v1->desconto_quantidade  = 0;
							}

							$v1->valor_liquido = funcValor($dados_calculo->valor, 'A');
							$v1->over_pct 	   = $dados_calculo->pacote;
							$v1->codigo_erro   = 0;
							$v1->tipo_erro     = 'success';
							$v1->mensagem_erro = 'Calculo efetuado com sucesso';
						} else {
							$this->setErroMsg('Erro ao calcular faturamento para o cliente: ' . $contrato->razao_social . ' para o produto ' . $v1->nome_produto . ' e modulo ' . $v1->nome_modulo);
							$v1->codigo_erro   = 1;
							$v1->tipo_erro     = 'danger';
							$v1->mensagem_erro = 'Erro ao calcular tarifação para o modulo ' . $v1->codigo_modulo . ' nome ' . $v1->nome_modulo;
						}
					}
					return json_encode($faturamento);
				} else {
					$pacotes = json_decode($this->consultaPacotes($contrato->id_contrato));
					if ($pacotes) {
						foreach ($pacotes as $key => $value) {
							$value->periodo_de    = $dt_ini->format('Y-m-d');
							$value->periodo_ate   = $dt_fim->format('Y-m-d');
							$value->over_pct 	  = 0;
							$value->codigo_erro   = 0;
							$value->tipo_erro     = 'success';
							$value->mensagem_erro = 'Calculo efetuado com sucesso';
						}
					}
					return json_encode($pacotes);
				}
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function getDetalheFaturamento($id_contrato, $dt_ini = null, $dt_fim = null, $dt_vencimento = null, $extras = null, $impostos = 'add')
		{
			$diff 		 = null;
			$return      = null;
			$comretencao = false;
			//captura dados do contrato
			$contrato    = json_decode($this->obj_contrato->contratosAtivos($id_contrato, true, true));
			//verifica se o contrato existe e está ativo
			if ($contrato) {
				$multa_juros = json_decode($this->obj_nf->getMovAuxiliar('pendente', 'nota fiscal', null, null, null, $id_contrato));
				$lancamentos = json_decode($this->obj_nf->getMovAuxiliar('pendente', 'lancamento', 'taxa_inatividade', null, null, $id_contrato));
				if (!empty($contrato[0]->data_primeiro_faturamento) && $contrato[0]->data_primeiro_faturamento != '0000-00-00') {
					$data_primeiro_faturamento = new DateTime($contrato[0]->data_primeiro_faturamento);
				} else {
					$data_primeiro_faturamento = clone ($this->data_hora_atual);
				}

				//configura a data de corte do contrato, caso não haja a data padrao é dia 01
				if (!empty($contrato[0]->data_corte_faturamento)) {
					$dia_corte = sprintf("%02s", $contrato[0]->data_corte_faturamento);
				} else {
					$dia_corte = '01';
				}

				//verifica se o contrato tem data de venciemtno fixo para a nota, caso não tenha conta a quantidade de dias a parti da nota
				if ($dt_vencimento) {
					$dt_vencimento = new DateTime($dt_vencimento, new DateTimeZone('America/Sao_Paulo'));
				} else {
					if (empty($contrato[0]->vencimento_todo_dia)) {
						$dt_vencimento = new DateTime($this->data_hora_atual->format('Y-m-d'), new DateTimeZone('America/Sao_Paulo'));
						if (!empty($contrato[0]->numero_dias_apos_corte)) {
							$dt_vencimento->add(new dateInterval('P' . $contrato[0]->numero_dias_apos_corte . 'D'));
						} else {
							$dt_vencimento->add(new dateInterval('P15D'));
						}
						// para remover o D+1 no calculo da data de vencimento
						// $dt_vencimento->sub(new dateInterval('P1D'));
					} else {
						if ($contrato[0]->vencimento_todo_dia > $this->data_hora_atual->format('d')) {
							$dt_vencimento = new DateTime($this->data_hora_atual->format('Y-m-') . $contrato[0]->vencimento_todo_dia, new DateTimeZone('America/Sao_Paulo'));
							$diff_dias = $this->data_hora_atual->diff($dt_vencimento);

							if ($diff_dias->days < 4) {
								$dt_vencimento->add(new DateInterval('P1M'));
							}
						} else {
							$dt_vencimento = new DateTime($this->data_hora_atual->format('Y-m-') . $contrato[0]->vencimento_todo_dia, new DateTimeZone('America/Sao_Paulo'));
							$dt_vencimento->add(new dateInterval('P1M'));
						}
					}
				}

				//busca a ultima nota fiscal emitida para esse cliente, e configura a data inicial como a fim do periodo do ultimo faturamento
				$primeira_nota = json_decode($this->obj_nf->getFirstNota($id_contrato, null, null, null, false));
				$ultima_nota   = json_decode($this->obj_nf->getLastNota($id_contrato, null, null, null, false));
				if ($dt_ini && $dt_fim) { //caso o periodo de faturamento seja informado
					$dt_ini = new DateTime($dt_ini);
					$dt_fim = new DateTime($dt_fim);
				} elseif ($ultima_nota) { //configurando dados a partir da ultima nota fiscal emitida
					$mes_atual = $this->data_hora_atual->format('Y-m');
					if (!empty($ultima_nota[0]->periodo_ate) && $ultima_nota[0]->periodo_ate != '0000-00-00') {
						$dt_ini    = new DateTime($ultima_nota[0]->periodo_ate);
						$dt_fim    = clone ($dt_ini);
						$dt_ini->add(new DateInterval('P1D'));
						$dt_fim->add(new DateInterval('P1M'));
						if ($dt_ini->format('Ymd') == $dt_fim->format('Ymd')) {
							$dt_fim->add(new DateInterval('P1M'));
							$dt_fim->sub(new DateInterval('P1D'));
						} elseif ($dt_fim->format('Ymd') >= $this->data_hora_atual->format('Ymd')) {
							$dt_fim = clone $this->data_hora_atual;
						}
					} else {
						if ($data_primeiro_faturamento) {
							$dt_ini = new DateTime($contrato[0]->data_assinatura);
						} elseif (!empty($contrato[0]->data_assinatura) && $contrato[0]->data_assinatura != '0000-00-00') {
							$dt_ini = new DateTime($contrato[0]->data_assinatura);
						} else {
							$dt_ini = new DateTime($this->data_hora_atual->format('Ym') . $dia_corte);
						}
						$dt_fim = new DateTime($this->data_hora_atual->format('Ym' . $dia_corte));
						$dt_fim->sub(new DateInterval('P1D'));
					}
				} else { //caso não haja faturamento anterior e a data não seja informada, usase a data corrente.
					if ($data_primeiro_faturamento) {
						$dt_ini = new DateTime($contrato[0]->data_assinatura);
					} elseif (!empty($contrato[0]->data_assinatura) && $contrato[0]->data_assinatura != '0000-00-00') {
						$dt_ini = new DateTime($contrato[0]->data_assinatura);
					} else {
						$dt_ini = new DateTime($this->data_hora_atual->format('Ym') . $dia_corte);
					}
					$dt_fim = new DateTime($this->data_hora_atual->format('Ym' . $dia_corte));
					$dt_fim->sub(new DateInterval('P1D'));
				}
				//verificar se o ano é bissexto
				if (isset($dt_ini) && !$dt_ini->format('L') && $dt_ini->format('m-d') == '02-29') {
					$dt_ini->add(new DateInterval('P1D'));
				}

				if (isset($dt_ini) && !$dt_fim->format('L') && $dt_fim->format('m-d') == '02-29') {
					$dt_fim->add(new DateInterval('P1D'));
				}

				if ($primeira_nota) {
					$return['primeiro_faturamento'] = $primeira_nota[0]->data_emissao;
				}

				if (isset($_REQUEST['data_emissao']) && !empty($_REQUEST['data_emissao'])) {
					$return['data_emissao'] = convertDate($_REQUEST['data_emissao']);
					$return['hora_emissao'] = '00:00:00';
				} else {
					$return['data_emissao'] = $this->data_hora_atual->format('Y-m-d');
					$return['hora_emissao'] = $this->data_hora_atual->format('H:i:s');
				}

				if ($dt_ini && $dt_fim) {
					$return['ano_mes_referencia'] = $this->data_hora_atual->format('Y-m');
					$return['data_vencimento']    = $dt_vencimento->format('Y-m-d');
					$return['data_faturamento']   = $this->data_hora_atual->format('Y-m-d');
					$return['periodo_de'] 		  = $dt_ini->format('Y-m-d');
					$return['periodo_ate'] 		  = $dt_fim->format('Y-m-d');
					$return['contrato'] 		  = $contrato[0];
					if(isset($contrato[0]->id_conta) && !empty($contrato[0]->id_conta)){
						$return['contas_recebimento'] = json_decode($this->obj_conta_bancaria->getContaByIdConta($contrato[0]->id_conta));
					}else{
						$return['contas_recebimento'] = json_decode($this->obj_conta_bancaria->getContaByEmpresa($contrato[0]->id_empresa));
					}
						
					$return['ultimo_faturamento'] = $ultima_nota[0];
					if ($this->data_hora_atual->format('Ymd') >= $data_primeiro_faturamento->format('Ymd')) {
						//caso haja prorrata deve se calcular o valor do faturamento antes de qualquer coisa;
						$dias_restantes = $dt_ini->diff($dt_fim);
						// calcula o faturamento em caso de prorrata
						if (isset($extras['prorrata']) && $extras['prorrata'] == 1) { // para casos de cobrança de prorrata
							$descicao_nota = null;
							$diff      	   = null;
							$diff 	       = $dt_ini->diff($dt_fim);
							$dt1           = new DateTime($dt_ini->format('Y-m-d'));
							if ($diff->m > 0) { // para casos com mais de um mes de prazo
								for ($x = 0; $x <= $diff->m; $x++) {
									if ($x == 0) {
										$dtp = $this->nextFechamento($dt1, $contrato[0]->data_corte_faturamento);
										$dias_restantes  = $dt1->diff($dtp);
										$faturamento     = json_decode($this->checkFaturamento($dt1, $dtp, $contrato[0], $extras));
										if ($faturamento) {
											foreach ($faturamento as $key => $value) {
												if ($value->valor_liquido > 0) {
													if ($dias_restantes->m == 0 && $dias_restantes->d > 0) {
														if ($value->tipo_cobranca != 'VOLUMETRIA' || empty($value->over_pct)) {
															$value->valor_liquido = (($value->valor_liquido / 30) * $dias_restantes->d);
															$return['receita']['detalhe']['faturamento'][] = $value;
														}
													}
												}
											}
										}
									} elseif ($x == $diff->m) {
										$dt1 = new DateTime($dtp->format('Y-m-d'));
										$dt1->add(new DateInterval('P1D'));
										$dtp = $dt_fim;
										$dias_restantes = $dt1->diff($dtp);
										if ($dias_restantes->m >= 1 && $dias_restantes->d > 0) {
											$dtp2 = clone $dtp;
											$dtp2->sub(new DateInterval('P' . ($dias_restantes->d + 1) . 'D'));
											$faturamento1 = json_decode($this->checkFaturamento($dt1, $dtp2, $contrato[0], $extras));
											$dt1 = clone $dtp2;
											$dt1->add(new DateInterval('P1D'));
											$faturamento2 = json_decode($this->checkFaturamento($dt1, $dtp, $contrato[0], $extras));
											foreach ($faturamento1 as $key => $value) {
												$return['receita']['detalhe']['faturamento'][] = $value;
											}

											foreach ($faturamento2 as $key => $value) {
												$value->valor_liquido = (($value->valor_liquido / 30) * $dias_restantes->d);
												$return['receita']['detalhe']['faturamento'][] = $value;
											}
										} elseif ($dias_restantes->m >= 1 && $dias_restantes->d == 0) {
											$dtp->sub(new DateInterval('P1D'));
											$faturamento = json_decode($this->checkFaturamento($dt1, $dtp, $contrato[0], $extras));
											foreach ($faturamento as $key => $value) {
												$return['receita']['detalhe']['faturamento'][] = $value;
											}
										} elseif ($dias_restantes->d <= 30) {
											$faturamento = json_decode($this->checkFaturamento($dt1, $dtp, $contrato[0], $extras));
											foreach ($faturamento as $key => $value) {
												$value->valor_liquido = (($value->valor_liquido / 30) * $dias_restantes->d);
												$return['receita']['detalhe']['faturamento'][] = $value;
											}
										}
									} else {
										$dt1 = new DateTime($dtp->format('Y-m-d'));
										$dt1->add(new DateInterval('P1D'));
										$dtp->add(new DateInterval('P1M'));
										$dias_restantes = $dt1->diff($dtp);
										$dias_restantes = $dt1->diff($dtp);
										$faturamento = json_decode($this->checkFaturamento($dt1, $dtp, $contrato[0], $extras));
										if ($faturamento) {
											foreach ($faturamento as $key => $value) {
												$return['receita']['detalhe']['faturamento'][] = $value;
											}
										}
									}
								}
							} else {
								$faturamento     = json_decode($this->checkFaturamento($dt1, $dt_fim, $contrato[0], $extras));
								if ($faturamento) {
									foreach ($faturamento as $key => $value) {
										if ($diff->d <= 29) {
											$value->valor_liquido = (($value->valor_liquido / 30) * $dias_restantes->d);
										}
										$return['receita']['detalhe']['faturamento'][] = $value;
									}
								}
							}
						} else { //calcula o faturamento em caso não prorrata
							$faturamento = json_decode($this->checkFaturamento($dt_ini, $dt_fim, $contrato[0], $extras));
								$return['receita']['detalhe']['faturamento'] = $faturamento;
						}

						if ($contrato[0]->cnpj_cm == '14289105000117') {
							if ($contrato[0]->cnpj == '74014747000135') {
								$contrato[0]->codigo_servico = '010701217';
								$comretencao = true;
							} elseif ($contrato[0]->codigo_produto == 'GCK0001') {
								$contrato[0]->codigo_servico = '100503216';
								$comretencao = true;
							} elseif ($contrato[0]->codigo_produto == 'ECS0001') {
								$contrato[0]->codigo_servico = '010301211';
							} else {
								$contrato[0]->codigo_servico = '010602217';
								$comretencao = true;
							}
						} else {
							if ($contrato[0]->codigo_produto == 'GCK0001') {
								$contrato[0]->codigo_servico = '100503216';
							} elseif ($contrato[0]->codigo_produto == 'ADM0001') {
								$contrato[0]->codigo_servico = '010501219';
							} elseif ($contrato[0]->codigo_produto == 'ECS0001') {
								$contrato[0]->codigo_servico = '010301211';
							} else {
								$contrato[0]->codigo_servico = '010501219';
							}
						}

						if ($lancamentos) {
							foreach ($lancamentos as $key => $value) {
								$value->valor_liquido = $value->valor_calculado;
								$return['receita']['detalhe']['lancamento'][] = $value;
							}

							if (!empty($return['receita']['detalhe']['lancamento'])) {
								foreach ($return['receita']['detalhe']['lancamento'] as $key => $value) {
									if ($value->valor_liquido > 0) {
										if ($contrato[0]->preco_com_imposto == 1 || $impostos == 'sub') {
											$value->impostos      = json_decode($this->calcImposto($contrato[0], $value, $comretencao, 'sub'));
											$value->valor_total   = funcValor($value->valor_liquido, 'A');
											$value->valor_liquido = funcValor(($value->valor_liquido - $value->impostos->totalizadores->semretencao->total), 'A');
										} else {
											$value->impostos    = json_decode($this->calcImposto($contrato[0], $value, $comretencao));
											$value->valor_total = funcValor(($value->valor_liquido + $value->impostos->totalizadores->semretencao->total), 'A');
										}

										if ($extras) {
											if ($value->valor_liquido > 0 && $extras['valor_desconto'] > 0) {
												if ($extras['tipo_desconto'] == 'percentual') {
													$value->tipo_desconto       = $extras['tipo_desconto'];
													$value->aliquota_desconto   = $extras['valor_desconto'];
													$value->valor_desconto      = (($value->valor_total / 100) * $extras['valor_desconto']);
												}
											} else {
												$value->tipo_desconto       = null;
												$value->aliquota_desconto   = 0;
												$value->valor_desconto      = 0;
											}
										}

										if (isset($value->impostos->totalizadores->comretencao)) {
											$return['receita']['resumo']['total_imposto_retido'] += funcValor($value->impostos->totalizadores->comretencao->total, 'A');
										} else {
											$return['receita']['resumo']['total_imposto_retido'] += 0;
										}

										if (isset($value->valor_desconto)) {
											$return['receita']['resumo']['total_desconto']    += funcValor($value->valor_desconto, 'A');
										} else {
											$return['receita']['resumo']['total_desconto']    += 0;
										}

										$return['receita']['impostos'][]                  =  $value->impostos;
										$return['receita']['resumo']['total_liquido']     += funcValor($value->valor_liquido, 'A');
										$return['receita']['resumo']['total_imposto']     += funcValor($value->impostos->totalizadores->semretencao->total, 'A');
										$return['receita']['resumo']['total_imposto_f1']  += funcValor($value->impostos->totalizadores->naoincidente->Federal1, 'A');
										$return['receita']['resumo']['total_imposto_m1']  += funcValor($value->impostos->totalizadores->naoincidente->Municipal1, 'A');
									} else {
										$return['receita']['impostos'][]                     =  null;
										$return['receita']['resumo']['total_desconto']       += 0;
										$return['receita']['resumo']['total_liquido']        += 0;
										$return['receita']['resumo']['total_imposto']        += 0;
										$return['receita']['resumo']['total_imposto_retido'] += 0;
										$return['receita']['resumo']['total_imposto_f1']     += 0;
										$return['receita']['resumo']['total_imposto_m1']     += 0;
									}
								}
							} else {
								$return['receita']['detalhe']['lancamento'] = null;
							}
						}

						//calcula imposto sobre o faturamento
						if (!empty($return['receita']['detalhe']['faturamento'])) {
							foreach ($return['receita']['detalhe']['faturamento'] as $key => $value) {
								if ($value->tipo_erro != 'danger') {
									if ($value->valor_liquido > 0) {
										if ($contrato[0]->preco_com_imposto == 1 || $impostos == 'sub') {
											$value->impostos      = json_decode($this->calcImposto($contrato[0], $value, $comretencao, 'sub'));
											$value->valor_total   = funcValor($value->valor_liquido, 'A');
											$value->valor_liquido = funcValor(($value->valor_liquido - $value->impostos->totalizadores->semretencao->total), 'A');
										} else {
											$value->impostos    = json_decode($this->calcImposto($contrato[0], $value, $comretencao));
											$value->valor_total = funcValor(($value->valor_liquido + $value->impostos->totalizadores->semretencao->total), 'A');
										}

										if ($extras) {
											$this->controller->arrayDinamico($extras, 'valor_desconto');
											if ($value->valor_liquido > 0 && $extras['valor_desconto'] > 0) {
												if ($extras['tipo_desconto'] == 'percentual') {
													$value->tipo_desconto     = $extras['tipo_desconto'];
													$value->aliquota_desconto = $extras['valor_desconto'];
													$value->valor_desconto    = (($value->valor_total / 100) * $extras['valor_desconto']);
												}
											} else {
												$value->tipo_desconto     = null;
												$value->aliquota_desconto = 0;
												$value->valor_desconto    = 0;
											}
										}

										$this->controller->arrayDinamico($return['receita']['resumo'], 'total_desconto');
										$this->controller->arrayDinamico($return['receita']['resumo'], 'total_liquido');
										$this->controller->arrayDinamico($return['receita']['resumo'], 'total_imposto');
										$this->controller->arrayDinamico($return['receita']['resumo'], 'total_imposto_f1');
										$this->controller->arrayDinamico($return['receita']['resumo'], 'total_imposto_m1');
										$this->controller->arrayDinamico($return['receita']['resumo'], 'total_imposto_retido');
										if (isset($value->impostos->totalizadores->comretencao)) {
											$return['receita']['resumo']['total_imposto_retido'] += funcValor($value->impostos->totalizadores->comretencao->total, 'A');
										} else {
											$return['receita']['resumo']['total_imposto_retido'] += 0;
										}

										if (isset($value->valor_desconto)) {
											$return['receita']['resumo']['total_desconto']    += funcValor($value->valor_desconto, 'A');
										} else {
											$return['receita']['resumo']['total_desconto'] += 0;
										}

										$return['receita']['impostos'][]                  =  $value->impostos;
										$return['receita']['resumo']['total_liquido']     += funcValor($value->valor_liquido, 'A');
										$return['receita']['resumo']['total_imposto']     += funcValor($value->impostos->totalizadores->semretencao->total, 'A');
										$return['receita']['resumo']['total_imposto_f1']  += funcValor($value->impostos->totalizadores->naoincidente->Federal1, 'A');
										$return['receita']['resumo']['total_imposto_m1']  += funcValor($value->impostos->totalizadores->naoincidente->Municipal1, 'A');
									} else {
										$return['receita']['impostos'][]                     =  null;
										$return['receita']['resumo']['total_desconto']       += 0;
										$return['receita']['resumo']['total_liquido']        += 0;
										$return['receita']['resumo']['total_imposto']        += 0;
										$return['receita']['resumo']['total_imposto_retido'] += 0;
										$return['receita']['resumo']['total_imposto_f1']     += 0;
										$return['receita']['resumo']['total_imposto_m1']     += 0;
									}
								} else {
									// implementar aviso de erro no detalhe e na geração da nota
									// echo $value->mensagem_erro;
								}
							}
						} else {
							$return['receita']['detalhe']['faturamento'] = null;
						}

						if ($extras['cobrar_multa'] == 1) {
							if ($multa_juros) {
								foreach ($multa_juros as $key => $value) {
									$value->valor_liquido         = funcValor($value->valor_calculado, 'A');
									if ($extras['tipo_desconto']   == 'percentual' && $extras['valor_desconto'] > 0) {
										$value->tipo_desconto     = $extras['tipo_desconto'];
										$value->aliquota_desconto = $extras['valor_desconto'];
										$value->valor_desconto    = funcValor((($value->valor_calculado / 100) * $extras['valor_desconto']), 'A');
										$value->valor_total       = funcValor($value->valor_calculado, 'A');
									} else {
										$value->tipo_desconto     = $extras['tipo_desconto'];
										$value->aliquota_desconto = 0;
										$value->valor_desconto    = 0;
										$value->valor_total       = funcValor($value->valor_calculado, 'A');
									}

									if ($value->tipo_mov_aux == 'multa') {
										$return['receita']['detalhe']['multa'][] = $value;
									} elseif ($value->tipo_mov_aux == 'juros') {
										$return['receita']['detalhe']['juros'][] = $value;
									} else {
										$return['receita']['detalhe']['desconhecido'][] = $value;
									}

									$return['receita']['resumo']['total_liquido']  += funcValor($value->valor_liquido, 'A');
									$return['receita']['resumo']['total_desconto'] += funcValor($value->valor_desconto, 'A');
									if (isset($value->impostos->totalizadores->comretencao)) {
										$return['receita']['resumo']['total_imposto_retido'] += funcValor($value->impostos->totalizadores->comretencao->total, 'A');
									} else {
										$return['receita']['resumo']['total_imposto_retido'] += 0;
									}

									if (isset($value->impostos->totalizadores->semretencao)) {
										$return['receita']['impostos'][]                = $value->impostos;
										$return['receita']['resumo']['total_imposto']  += funcValor($value->impostos->totalizadores->semretencao->total, 'A');
									} else {
										$return['receita']['resumo']['total_imposto']  += 0;
									}

									if (isset($value->impostos->totalizadores->naoincidente)) {
										$return['receita']['resumo']['total_imposto_f1']  += funcValor($value->impostos->totalizadores->naoincidente->Federal1, 'A');
										$return['receita']['resumo']['total_imposto_m1']  += funcValor($value->impostos->totalizadores->naoincidente->Municipal1, 'A');
									} else {
										$return['receita']['resumo']['total_imposto_f1']  += 0;
										$return['receita']['resumo']['total_imposto_m1']  += 0;
									}
								}
							}
						} else {
							$return['receita']['detalhe']['multa'][] = null;
							$return['receita']['detalhe']['juros'][] = null;
							if ($multa_juros) {
								foreach ($multa_juros as $key => $value) {
									$p1['status'] = 'isento';
									$this->obj_nf->updateMovAux($value->id_mov_aux, $p1);
								}
							}
						}

						if ($extras['cobrar_reajuste'] == 1) {
							$reajuste = json_decode($this->obj_nf->getMovAuxiliar('pendente', 'reajuste', null, null, null, $id_contrato));
							if ($reajuste) {
								foreach ($reajuste as $key => $value) {
									if ($value->valor_calculado > 0) {
										if ($extras) {
											$value->valor_liquido         = funcValor($value->valor_calculado, 'A');
											$value->impostos              = json_decode($this->calcImposto($contrato[0], $value, $comretencao));

											if (isset($value->impostos->totalizadores->semretencao->total)) {
												$imposto_incidente = $value->impostos->totalizadores->semretencao->total;
											} else {
												$imposto_incidente = 0;
											}

											if ($extras['tipo_desconto']   == 'percentual' && $extras['valor_desconto'] > 0) {
												$value->tipo_desconto     = $extras['tipo_desconto'];
												$value->aliquota_desconto = $extras['valor_desconto'];
												$value->valor_total       = funcValor(($value->valor_liquido + $imposto_incidente), 'A');
												$value->valor_desconto    = funcValor((($value->valor_total / 100) * $extras['valor_desconto']), 'A');
												$value->valor_total      -= funcValor($value->valor_desconto, 'A');
											} else {
												$value->tipo_desconto     = $extras['tipo_desconto'];
												$value->aliquota_desconto = 0;
												$value->valor_desconto    = 0;
												$value->valor_liquido     = funcValor($value->valor_calculado, 'A');
												$value->valor_total		  = funcValor(($value->valor_liquido + $imposto_incidente), 'A');
											}

											if (isset($value->impostos->totalizadores->comretencao)) {
												$return['receita']['resumo']['total_imposto_retido'] += funcValor($value->impostos->totalizadores->comretencao->total, 'A');
											} else {
												$return['receita']['resumo']['total_imposto_retido'] = 0;
											}

											$return['receita']['impostos'][]                 = $value->impostos;
											$return['receita']['resumo']['total_liquido']    += funcValor($value->valor_liquido, 'A');
											$return['receita']['resumo']['total_imposto']    += funcValor($value->impostos->totalizadores->semretencao->total, 'A');
											$return['receita']['resumo']['total_imposto_f1'] += funcValor($value->impostos->totalizadores->naoincidente->Federal1, 'A');
											$return['receita']['resumo']['total_imposto_m1'] += funcValor($value->impostos->totalizadores->naoincidente->Municipal1, 'A');
											$return['receita']['resumo']['total_desconto']   += funcValor($value->valor_desconto, 'A');
											$return['receita']['detalhe']['reajuste'][]      = $value;
										} else {
											$value->tipo_desconto       = null;
											$value->aliquota_desconto   = 0;
											$value->valor_desconto      = 0;
										}
									}
								}
							}
						} else {
							$return['receita']['detalhe']['reajuste'] = null;
						}

						$this->controller->arrayDinamico($extras, 'tipo_desconto');
						if ($extras['tipo_desconto'] == 'valor' && $extras['valor_desconto'] > 0) {
							$return['receita']['resumo']['tipo_desconto']  = 'valor';
							$return['receita']['resumo']['total_desconto'] = $extras['valor_desconto'];
						} elseif ($extras['tipo_desconto'] == 'percentual' && $extras['valor_desconto'] > 0) {
							$return['receita']['resumo']['tipo_desconto']  = 'percentual';
						}
						$return['faturar']   = true;
					} else { //fim da comparação de data ini com data do primeiro faturamento
						$return['faturar']   = false;
						$return['msg_aviso'] = "Esse cliente só pode ser faturado a partir de: " . $data_primeiro_faturamento->format('d/m/Y');
					}
				} else {
					//incluir aviso slack
					$return['faturar']   = false;
					$return['msg_aviso'] = "Erro no periodo informado para o cliente " . $contrato[0]->razao_social . " a nota não pode ser gerada";
					$this->controller->log->writeLog($return['msg_aviso']);
				}
				return json_encode($return);
			} else {
				return false;
			}
		}

		function calcImposto($contrato, $dados, $comretencao = false, $flag = 'add')
		{
			$valor_base   = null;
			$return       = false;
			$soma_imposto = null;

			if (!is_object($contrato)) {
				$contrato = (object)$contrato;
			}

			$impostos = json_decode($this->obj_imposto->getImpostoByEmpresa($contrato->id_empresa));
			if (isset($contrato) && !is_object($contrato)) {
				$contrato = (object)$contrato;
			}

			if (isset($dados) && !is_object($dados)) {
				$dados = (object)$dados;
			}

			if (isset($dados->valor_desconto)) {
				$valor_base = funcValor(($dados->valor_liquido - $dados->valor_desconto), 'A');
			} else {
				$valor_base = funcValor($dados->valor_liquido, 'A');
			}

			// empresas com preco sem imposto é adicionado
			if ($flag == 'add') {
				$return['totalizadores']['valor_base']  = $valor_base;
			} else { // empresas com preço ja com imposto, faz o calculo reverso para descobrir a quantia tributada
				$obj_imposto    = json_decode($this->obj_imposto->getImpostoSumarizado($contrato->id_empresa, 'sem retencao'));
				$total_aliquota = (($obj_imposto[0]->total_aliquota / 100) + 1);
				$valor_base     = ($dados->valor_liquido / $total_aliquota);
				$return['totalizadores']['valor_base'] = $valor_base;
			}

			foreach ($impostos as $key => $value) {
				$incidente = removeCaracteres($value->imposto_incidente, true);
				if ($incidente == 'semretencao' || $incidente == 'naoincidente') {
					$nome_imposto  = removeCaracteres($value->nome_imposto, true);
					$valor_imposto = (($valor_base / 100) * $value->aliquota);
					$this->controller->arrayDinamico($return['totalizadores'], $incidente, 'metodo');
					$this->controller->arrayDinamico($return['totalizadores'], $incidente, 'valor_base');
					$this->controller->arrayDinamico($return['totalizadores'], $incidente, 'total');
					$this->controller->arrayDinamico($return['totalizadores'], $incidente, $nome_imposto);
					$return['totalizadores'][$incidente]['metodo']      =  $flag;
					$return['totalizadores'][$incidente]['valor_base']  =  $valor_base;
					$return['totalizadores'][$incidente]['total']       += funcValor($valor_imposto, 'A');
					$return['totalizadores'][$incidente][$nome_imposto] =  funcValor($valor_imposto, 'A');
				}
			}

			if ($comretencao) {
				$valor_base    += $return['totalizadores'][$incidente]['total'];
				foreach ($impostos as $key => $value) {
					$incidente = removeCaracteres($value->imposto_incidente, true);
					if ($incidente == 'comretencao') {
						$nome_imposto  = removeCaracteres($value->nome_imposto, true);
						$valor_imposto = (($valor_base / 100) * $value->aliquota);
						$return['totalizadores'][$incidente]['metodo']      = $flag;
						$return['totalizadores'][$incidente]['valor_base']  = $valor_base;
						$return['totalizadores'][$incidente]['total']       += funcValor($valor_imposto, 'A');
						$return['totalizadores'][$incidente][$nome_imposto] = funcValor($valor_imposto, 'A');
					}
				}
			}
			return json_encode($return);
		}

		function gerarnf($dados)
		{
			$taxa_inatividade 	  = false;
			$destinatario         = null;
			$descricao_pagamento  = null;
			$total_transacoes     = null;
			$informe_desconto     = null;
			$descricao_inicial	  = null;
			$descricao_final	  = null;
			$descricao_servico	  = null;
			$descricao_multa	  = null;
			$descricao_reajuste	  = null;
			$descricao_juros	  =	null;
			$param['periodo_de']  = $dados->periodo_de;
			$param['periodo_ate'] = $dados->periodo_ate;
			$ultima_fatura        = json_decode($this->obj_nf->getLastNota(null, null, null, $dados->contrato->cnpj_cm, false));
			$indice 	 		  = json_decode($this->obj_indice->ultimoIndice(str_pad($dados->contrato->mes_reajuste, 1, 0, STR_PAD_LEFT), $dados->contrato->indice_reajuste));

			if(isset($dados->contas_recebimento) && $dados->contas_recebimento){
				$dados_banco = $dados->contas_recebimento;
			}else if(isset($dados->contrato->id_conta) && $dados->contrato->id_conta != null){
				$dados_banco 	  = json_decode($this->obj_conta_bancaria->getContaByIdConta($dados->contrato->id_conta));
			}else{
				$dados_banco 	  = json_decode($this->obj_conta_bancaria->getContaByEmpresa($dados->contrato->id_empresa));
			}

			if ($dados->receita->resumo->total_desconto > 0) {
				$descricao_desconto = 'Total de descontos contabilizados nesta NF ' . ' R$ ' . number_format($dados->receita->resumo->total_desconto, '2', ',', '.') . '|';
			} else {
				$descricao_desconto = null;
			}

			if ($dados_banco) {
				if ($dados->contrato->codigo_produto == 'GCK0001') {
					$descricao_pagamento .= "| Nota Liquidada ";
					$inst_pag = 'Liquidada';
				} else {
					$inst_pag = substr(strtoupper($dados->contrato->meio_pagamento), 0, 14);
					$descricao_pagamento .= "Pagamento via " . strtoupper($dados->contrato->meio_pagamento) . " Banco " . $dados_banco[0]->nome_reduzido . " Agencia " . $dados_banco[0]->numero_agencia . " C/C " . $dados_banco[0]->numero_conta . "-" . $dados_banco[0]->digito_conta;
					$descricao_pagamento .= " vencimento em " . convertDate($dados->data_vencimento);
				}
			} else {
				$descricao_pagamento .= " vencimento em " . convertDate($dados->data_vencimento);
			}

			if (!empty($indice[0]->ano) && !empty($indice[0]->mes)) {
				$ultimo_indice = $indice[0]->ano . '-' . $indice[0]->mes;
			} else {
				$ultimo_indice = null;
			}

			if (!empty($ultima_fatura)) {
				$ultimo_numero_nota   = ($ultima_fatura[0]->numero + 1);
				$ultimo_numero_fatura = ($ultima_fatura[0]->numero_fatura + 1);
			} else {
				$ultimo_numero_nota   = 1;
				$ultimo_numero_fatura = 1;
			}

			if ($dados->contrato->codigo_produto == 'ECS0001') {
				$param['codigo_servico'] = '010301211';
				$descricao_inicial .= '|Processamento de dados';
			} elseif ($dados->contrato->codigo_produto == 'ADM0001') {
				$param['codigo_servico'] = '010501219';
			} elseif ($dados->contrato->codigo_produto == 'GCK0001') {
				$param['codigo_servico'] = '100503216';
				$descricao_inicial .= '|Intermediacao de negocio';
			} elseif ($dados->contrato->cnpj_cm == '14289105000117') {
				if ($dados->contrato->cnpj == '74014747000135') {
					$descricao_inicial .= '|Suporte tecnico em informatica';
					$param['codigo_servico'] = '010701217';
				} else {
					$param['codigo_servico'] = '010602217';
					$descricao_inicial .= '|Consultoria em informatica';
				}
			} else {
				$param['codigo_servico'] = '010501219';
				$descricao_inicial .= '|Licenca de uso';
			}

			if ($dados->contrato->codigo_produto != 'ADM0001') {
				if (isset($dados->periodo_de) && !empty($dados->periodo_de) && isset($dados->periodo_ate) && !empty($dados->periodo_ate)) {
					$descricao_inicial .= '|Periodo de corte de ' . convertDate($dados->periodo_de) . ' ate ' . convertDate($dados->periodo_ate);
				}
			}

			if ($dados->receita->detalhe) {
				if ($dados->contrato->codigo_produto == 'COB0001') {
					$valor_total = (($dados->receita->resumo->total_liquido + $dados->receita->resumo->total_imposto) - $dados->receita->resumo->total_desconto);
					$descricao_servico = '|Cobranca Eletronica Especializada' . ' R$ ' . number_format($valor_total, '2', ',', '.');
				} else {
					foreach ($dados->receita->detalhe->faturamento as $key => $value) {
						if ($value->valor_liquido > 0) {
							$valor_total = null;
							$valor_total = ($value->valor_total - $value->valor_desconto);
							if ($value->codigo_modulo == 'GCK0050') {
								$descricao_servico .= '|' . $value->nome_modulo . ' valor a ser pago R$ ' . number_format($valor_total, '2', ',', '.');
								$gck_liquidada = false;
							} else {
								if ($value->over_pct == 1) {
									if ($value->desconto_quantidade > 0) {
										$total_transacoes = ($value->transacoes - $value->desconto_quantidade);
										$informe_desconto = "|Incluso desconto do valor de " . $value->desconto_quantidade . " transações referente ao pacote do modulo " . $value->nome_modulo;
									} else {
										$total_transacoes = ($value->transacoes);
									}
									$descricao_servico .= '|' . $value->nome_modulo . ' R$ ' . number_format($valor_total, '2', ',', '.') . ' referente a ' . number_format($total_transacoes, '0', ',', '.') . ' transações';
								} else {
									$descricao_servico .= '|' . $value->nome_modulo . ' valor minimo R$ ' . number_format($valor_total, '2', ',', '.');
								}
							}
						} //fim verifica se tem valor a ser inputado na nota
					}
				}

				if (isset($dados->receita->detalhe->lancamento)) {
					foreach ($dados->receita->detalhe->lancamento as $key => $value) {
						$valor_total = null;
						$valor_total = ($value->valor_total - $value->valor_desconto);
						$descricao_lancamento .= '|' . $value->descricao . ' R$ ' . number_format($valor_total, '2', ',', '.');
					}
				}

				if (isset($dados->receita->detalhe->reajuste)) {
					foreach ($dados->receita->detalhe->reajuste as $key => $value) {
						$valor_total = null;
						$valor_total = ($value->valor_total - $value->valor_desconto);
						$descricao_reajuste .= '|' . $value->descricao . ' R$ ' . number_format($valor_total, '2', ',', '.');
					}
				} else {
					$descricao_reajuste .= null;
				}

				if (isset($dados->receita->detalhe->multa)) {
					foreach ($dados->receita->detalhe->multa as $key => $value) {
						if (!empty($value)) {
							$valor_total = null;
							$valor_total = ($value->valor_total - $value->valor_desconto);
							$descricao_multa .= '|R$ ' . number_format($valor_total, '2', ',', '.') . ' ' . $value->descricao;
						}
					}
				} else {
					$descricao_multa .= null;
				}

				if (isset($dados->receita->detalhe->juros)) {
					foreach ($dados->receita->detalhe->juros as $key => $value) {
						if (!empty($value)) {
							$valor_total = null;
							$valor_total = ($value->valor_total - $value->valor_desconto);
							$descricao_juros .= '|R$ ' . number_format($valor_total, '2', ',', '.') . ' ' . $value->descricao;
						}
					}
				} else {
					$descricao_juros .= null;
				}
			}

			$codigo_acesso = generateRandomString(8);
			$descricao_final .= "|Valor aproximado dos tributos conf. Lei 12.741/2012 Federal R$ " . number_format($dados->receita->resumo->total_imposto_f1, '2', ',', '.') . " Municipal R$ " . number_format($dados->receita->resumo->total_imposto_m1, '2', ',', '.') . "|" . $descricao_pagamento;
			$descricao_nfe  = $descricao_inicial;
			$descricao_nfe .= "|" . $dados->contrato->nome_produto;

			if ($dados->contrato->obs_nf) {
				$descricao_nfe .= removeHtml(trim($dados->contrato->obs_nf), '|') . '|';
			}

			$descricao_nfe .= "|Para detalhamento acesse " . URL_NF_CMSW . " e informe o CNPJ e o codigo abaixo";
			$descricao_nfe .= "|codigo de acesso: $codigo_acesso";
			$descricao_nfe .=  $descricao_final;
			if (isset($dados->tipo) && $dados->tipo == "I") {
				$descricao_inicial .= " / (IMP)";
				if (isset($dados->numero_parcelas)) {
					if ($dados->numero_parcelas == 1) {
						$descricao_inicial .= " / PAGAMENTO ÚNICO";
					} else {
						if (isset($dados->parcelas)) {
							$descricao_inicial .= " / PARCELA " . $dados->parcelas . "/" . $dados->numero_parcelas;
						}
					}
				}
			}

			$param['valor_fatura']                  = ((($dados->receita->resumo->total_liquido + $dados->receita->resumo->total_imposto) - $dados->receita->resumo->total_desconto) - $dados->receita->resumo->total_imposto_retido);
			$param['valor_total']					= (($dados->receita->resumo->total_liquido + $dados->receita->resumo->total_imposto) - $dados->receita->resumo->total_desconto);
			$param['valor_liquido']					= $dados->receita->resumo->total_liquido;
			$param['valor_impostos']				= $dados->receita->resumo->total_imposto;
			$param['valor_impostos_retidos']		= $dados->receita->resumo->total_imposto_retido;
			$param['valor_desconto']		        = $dados->receita->resumo->total_desconto;
			$param['numero']						= str_pad($ultimo_numero_nota, 6, 0, STR_PAD_LEFT);
			$param['numero_fatura']					= str_pad($ultimo_numero_fatura, 6, 0, STR_PAD_LEFT);
			$param['serie']							= null;
			if (isset($dados->tipo) && !empty($dados->tipo)) {
				$param['tipo']                      = $dados->tipo;
			} else {
				$param['tipo']						= 'A';
			}

			$param['data_emissao']					= $dados->data_emissao;
			$param['hora_emissao']					= $dados->hora_emissao;
			$param['data_vencimento']				= $dados->data_vencimento;
			$param['data_faturamento']				= $dados->data_faturamento;
			$param['prestador_servico']				= $dados->contrato->razao_social_cm;
			$param['cnpj_cpf_prestador']			= $dados->contrato->cnpj_cm;
			$param['inscricao_estadual_prestador']	= $dados->contrato->inscricao_estadual_cm;
			$param['inscricao_municipal_prestador']	= $dados->contrato->inscricao_municipal_cm;
			$param['endereco_prestador']			= $dados->contrato->endereco_cm;
			$param['numero_prestador']				= $dados->contrato->numero_cm;
			$param['complemento_prestador']			= $dados->contrato->complemento_cm;
			$param['cep_prestador']					= $dados->contrato->cep_cm;
			$param['bairro_prestador']				= $dados->contrato->bairro_cm;
			$param['municipio_prestador']			= $dados->contrato->cidade_cm;
			$param['uf_prestador']					= $dados->contrato->estado_cm;
			$param['id_contrato']					= $dados->contrato->id_contrato;
			$param['cliente']						= $dados->contrato->razao_social;
			$param['codigo_produto']				= $dados->contrato->codigo_produto;
			$param['cnpj_cpf_cliente']				= str_pad($dados->contrato->cnpj, 14, 0, STR_PAD_LEFT);
			$param['codigo_cliente']				= $dados->contrato->codigo_cliente;
			$param['inscricao_estadual_cliente']	= $dados->contrato->inscricao_estadual;
			$param['endereco_cliente']				= $dados->contrato->endereco;
			$param['numero_cliente']				= $dados->contrato->numero;
			$param['complemento_cliente']			= $dados->contrato->complemento;
			$param['cep_cliente']					= $dados->contrato->cep;
			$param['bairro_cliente']				= $dados->contrato->bairro;
			$param['municipio_cliente']				= $dados->contrato->cidade;
			$param['uf_cliente']					= $dados->contrato->estado;
			$param['email_nf']						= str_replace(';', '|', $dados->contrato->email_nf);
			$param['data_faturamento'] 				= $dados->data_faturamento;
			$param['quantidade']					= $total_transacoes; //campo deverá deletado da base de dados
			$param['total_horas']					= null; //campo deverá deletado da base de dados
			$param['dados_produto']					= null;
			$param['dados_modulos']					= null;
			$param['impostos'] 						= json_encode($dados->receita->impostos);
			$param['faturamento_relacionado'] 		= json_encode($dados->receita->detalhe);
			$param['status']						= 'receber';
			$param['ano_mes_referencia']			= $this->data_hora_atual->format('Y-m');
			$param['codigo_acesso']					= $codigo_acesso; //$this->data_hora_atual->format('YmdHis').rand(100, 999); //md5(uniqid(rand(), true));
			$param['deleted'] 						= 0;
			$param['descricao_nota']				= substr($descricao_nfe, 0, 999);
			$param['informacoes_relevantes']		= null;
			$param['descricao_servico']				= $descricao_inicial . $descricao_servico . $descricao_lancamento . $descricao_multa . $descricao_juros . $descricao_reajuste . $descricao_desconto . $descricao_final;
			$param['observacoes']					= null;
			$param['ultimo_reajuste']				= $ultimo_indice;
			$param['operacao']                      = 'automatico';
			$param['instrucao_pagamento_nome']      = substr(trim($dados->contrato->meio_pagamento), 0, 14);

			if (isset($dados->status_envio)) {
				$param['status_envio'] 				= $dados->status_envio;
			}

			if (isset($dados->parcelas)) {
				$param["parcelas"]					= $dados->parcelas;
			}

			if ($dados->contrato->obs_nf) {
				$param['descricao_servico']         .= "|" . removeHtml(trim($dados->contrato->obs_nf), '|');
			}

			if (isset($dados->receita->detalhe->lancamento) && !empty($dados->receita->detalhe->lancamento)) {
				foreach ($dados->receita->detalhe->lancamento as $key => $value) {
					if ($value->tipo_mov_aux == 'taxa_inatividade') {
						$taxa_inatividade = true;
					}
				}
			}

			if (
				(!isset($dados->tipo) || empty($dados->tipo)) &&
				(!isset($dados->receita->detalhe->faturamento) || empty($dados->receita->detalhe->faturamento)) &&
				$taxa_inatividade
			) {
				$param['tipo'] = 'N';
			}
			
			$is_save = $this->obj_nf->save($param);
			if ($is_save) {
				$contatos 		= explode(';', $dados->contrato->email_nf);
				$destinatario 	= null;
				$bcc          	= explode(';', SYSTEM_NOTIFY_TO);
				if (TIPO_AMBIENTE == 'producao') {
					$destinatario = explode(';', $dados->contrato->email_nf);
				} else {
					$destinatario = explode(';', SYSTEM_NOTIFY_TO);
				}

				$mensagem = "
						<p>Prezado(a) <b>" . $dados->contrato->razao_social . "</b></p>
						<p>A sua Nota Fiscal está em processo de emissão eletrônica.</p>
						<p>Caso não receba o e-mail contendo a Nota Fiscal Eletrônica até o final do dia de hoje, favor nos contatar pelo e-mail administracao@cmsw.com. Não é necessária nenhuma manifestação caso tenha ocorrido tudo corretamente.</p>
						<p>Obrigado<br> Diretoria Financeira e Administrativa; </p>
					";

				// o objeto email deve ser gerado sempre que mandar uma mensagem para não acumular notas fiscais;
				$this->obj_email = null;
				$this->obj_email = new Email();
				//$this->obj_email->sendMail($destinatario, 'C&M Software – Pré-Aviso de emissão de Nota Fiscal',$mensagem, null, null, null, $bcc);

				if (!empty($dados->receita->detalhe->multa)) {
					foreach ($dados->receita->detalhe->multa as $key => $value) {
						if (!empty($value)) {
							$p1['id_nf']  = $is_save;
							$p1['status'] = 'faturado';
							$this->obj_nf->updateMovAux($value->id_mov_aux, $p1);
						}
					}
				}

				if (!empty($dados->receita->detalhe->juros)) {
					foreach ($dados->receita->detalhe->juros as $key => $value) {
						if (!empty($value)) {
							$p2['id_nf']  		  = $is_save;
							$p2['status'] = 'faturado';
							$this->obj_nf->updateMovAux($value->id_mov_aux, $p2);
						}
					}
				}

				if (!empty($dados->receita->detalhe->reajuste)) {
					foreach ($dados->receita->detalhe->reajuste as $key => $value) {
						$p3['id_nf']  = $is_save;
						$p3['status'] = 'faturado';
						$this->obj_nf->updateMovAux($value->id_mov_aux, $p3);
					}
				}

				if (!empty($dados->receita->detalhe->lancamento)) {
					foreach ($dados->receita->detalhe->lancamento as $key => $value) {
						$p4['id_nf']  	   	 = $is_save;
						$p4['status'] 	   	 = 'faturado';
						$p4['vencimento_em'] = $dados->data_vencimento;
						$is_update = $this->obj_nf->updateMovAux($value->id_mov_aux, $p4);
					}
				}
				return $is_save;
			} else {
				return false;
			}
		}

		function gerarRps($notas, $flag = false)
		{
			if (!is_array($notas)) {
				$notas = json_decode($notas);
			}

			if (!empty($notas)) {
				foreach ($notas as $key => $value) {
					$obj_nota = json_decode($this->obj_nf->getNota($value->id_nf));
					if ($obj_nota) {
						$id_nf = $obj_nota[0]->id;
						$im_cm = $obj_nota[0]->inscricao_municipal_prestador;
						$cnpj_cliente = $obj_nota[0]->cnpj_cpf_cliente;
						$this->controller->arrayDinamico($rps, $im_cm, 'cnpj_cm');
						$this->controller->arrayDinamico($rps, $im_cm, 'total_valores');
						$this->controller->arrayDinamico($rps, $im_cm, 'total_impostos');
						$this->controller->arrayDinamico($rps, $im_cm, 'total_retido');

						$rps[$im_cm]['cnpj_cm'] 		= $obj_nota[0]->cnpj_cpf_prestador;
						$rps[$im_cm]['nfs'][]          	= $id_nf;

						$rps[$im_cm]['total_valores']  += $obj_nota[0]->valor_total;
						$rps[$im_cm]['total_impostos'] += $obj_nota[0]->valor_impostos;
						$rps[$im_cm]['total_retido']   += $obj_nota[0]->valor_impostos_retidos;

						if (empty($rps[$im_cm]['numero_remessa'])) {
							$rps[$im_cm]['header']         = $this->getHeaderRps($obj_nota[0]);
							$rps[$im_cm]['numero_remessa'] = substr($rps[$im_cm]['header'], 14, 11);
						}

						$rps[$im_cm]['body'][$id_nf] = $this->getBodyRps($obj_nota[0], $rps[$im_cm]['numero_remessa']);
						$impostos_retidos[$id_nf]    = $this->getImpostoRps($obj_nota[0]);
						if ($impostos_retidos[$id_nf]) {
							$array_imposto[$id_nf] = explode(';', $impostos_retidos[$id_nf]);
							foreach ($array_imposto[$id_nf] as $k1 => $v1) {
								if (!empty($v1)) {
									$rps[$im_cm]['impostos'][$id_nf][] = $v1;
								}
							}
						}
					} else {
						//implementar ação caso a nota não exista;
					}
				}

				if ($rps) {
					foreach ($rps as $key => $value) {
						$rps[$key]['footer'] = $this->getFooterRps($value);
					}

					if ($flag) {
						return $this->writeRps($rps, true);
					} else {
						$this->writeRps($rps, true);
						header('Location: /faturamento/listarrps/');
					}
				}
			}
		}

		function getHeaderRps($dados)
		{
			$dados_remessa = json_decode($this->fatura_modelo->getLastRemessa($dados->cnpj_cpf_prestador, $this->data_hora_atual->format('Y-m-d')));
			if (!empty($dados_remessa[0]->numero_remessa)) {
				$numero_remessa = ($dados_remessa[0]->numero_remessa + 1);
			} else {
				$numero_remessa = $this->data_hora_atual->format('Ymd') . '001';
			}
			$return  = 1;
			$return .= $dados->inscricao_municipal_prestador;
			$return .= 'PMB002';
			$return .= $numero_remessa;
			return $return;
		}

		function getBodyRps($dados, $numero_remessa)
		{
			$body = null;
			if ($dados) {
				$vr_fatura_gck = null;
				foreach ($dados as $key => $value) {
					$dados->{$key} = removeCaracteres($value, 'char_especiais');
					$what = array('ª', 'º');
					$by   = array('', '');
					$dados->{$key} = str_replace($what, $by, $value);
					$dados->{$key} = trim($value);
					$dados->{$key} = rtrim($value);
					$dados->{$key} = ltrim($value);
				}

				$dt_emissao = new DateTime($dados->data_emissao);
				$dados_rps  = json_decode($this->fatura_modelo->getLastRps($dados->cnpj_cpf_prestador, $this->data_hora_atual->format('Y')));
				if ($dados_rps) {
					$numero_rps  = ($dados_rps[0]->numero_rps + 1);
				} else {
					$numero_rps = 1;
				}

				if ($dados->codigo_produto == 'GCK0001') {
					$valor_fatura = $dados->valor_fatura;
					$faturamento_relacionado = json_decode($dados->faturamento_relacionado);
					if ($faturamento_relacionado) {
						foreach ($faturamento_relacionado as $key => $value) {
							if ($value->codigo_modulo == 'GCK0050') {
								$vr_fatura_gck = (float)funcValor(($value->valor_total - $value->valor_desconto), 'A');
								$vr_fatura_gck = (float)funcValor(($vr_fatura_gck - $dados->valor_impostos_retidos), 'A');
							}
						}
					}
					if (!empty($vr_fatura_gck)) {
						$valor_fatura = $vr_fatura_gck;
					} else {
						$valor_fatura = (($dados->total + $dados->valor_impostos) - $dados->valor_impostos_retidos);
					}
				} else {
					$valor_fatura = ($dados->valor_total - $dados->valor_impostos_retidos);
				}

				$param['id_nf']          = $dados->id;
				$param['data_remessa']   = $this->data_hora_atual->format('Y-m-d H:i:s');
				$param['numero_rps']     = sprintf("%010s", $numero_rps);
				$param['cnpj_prestador'] = $dados->cnpj_cpf_prestador;
				$param['numero_remessa'] = $numero_remessa;
				$param['criado_em']      = $this->data_hora_atual->format('Y-m-d H:i:s');
				$param['status']         = 'criado';

				$is_save = $this->fatura_modelo->save($param);

				$body .= '2';
				$body .= sprintf("%-5s",  'RPS');
				$body .= sprintf("%-4s",  null);
				$body .= sprintf("%-5s",  null);
				$body .= sprintf("%010s",  $numero_rps);
				// a data e hora do rps deve ser a data do dia que ele foi gerado e não a data de emissão da nota.
				// $body .= $dt_emissao->format('Ymd');
				// $body .= removeCaracteres($dados->hora_emissao, 'char');
				$body .= $this->data_hora_atual->format('Ymd');
				$body .= $this->data_hora_atual->format('His');
				$body .= 'E';
				$body .= sprintf("%-2s",  null); //parametros para cancelamento de nota, não usar apenas preencher com espaços
				$body .= sprintf("%-7s",  null); //parametros para cancelamento de nota, não usar apenas preencher com espaços
				$body .= sprintf("%-5s",  null); //parametros para cancelamento de nota, não usar apenas preencher com espaços
				$body .= sprintf("%-8s",  null); //parametros para cancelamento de nota, não usar apenas preencher com espaços
				$body .= sprintf("%-180s",  null); //parametros para cancelamento de nota, não usar apenas preencher com espaços
				$body .= sprintf("%-9s",  $dados->codigo_servico);
				$body .= '1';
				$body .= '2';
				$body .= sprintf("%-75s",  $dados->endereco_prestador);
				$body .= sprintf("%-9s",   $dados->numero_prestador);
				$body .= sprintf("%-30s",  $dados->complemento_prestador);
				$body .= sprintf("%-40s",  $dados->bairro_prestador);
				$body .= sprintf("%-40s",  $dados->municipio_prestador);
				$body .= sprintf("%-2s",   $dados->uf_prestador);
				$body .= sprintf("%-8s",   removeCaracteres($dados->cep_prestador, 'char'));
				$body .= sprintf("%06s",   substr('1', 0, 6));
				$body .= sprintf("%015s",  removeCaracteres(substr($dados->valor_total, 0, 15), 'moeda2'));
				$body .= sprintf("%-5s", 	 null);
				$body .= sprintf("%015s",  removeCaracteres($dados->valor_impostos_retidos, 'moeda2'));
				$body .= 2;
				$body .= '001';
				$body .= 2;
				$body .= 2;
				$body .= str_pad($dados->cnpj_cpf_cliente, 14, 0, STR_PAD_LEFT);
				$body .= sprintf("%-60s",  substr(removeCaracteres($dados->cliente, 'char_especiais'), 0, 60));
				$body .= sprintf("%-75s",  substr(removeCaracteres($dados->endereco_cliente, 'char_especiais'), 0, 76));
				$body .= sprintf("%-9s",   substr(removeCaracteres($dados->numero_cliente, 'char_especiais'), 0, 9));
				$body .= sprintf("%-30s",  substr(utf8_decode(removeCaracteres($dados->complemento_cliente, 'char_especiais')), 0, 30));
				$body .= sprintf("%-40s",  substr(removeCaracteres($dados->bairro_cliente, 'char_especiais'), 0, 40));
				$body .= sprintf("%-40s",  substr(removeCaracteres($dados->municipio_cliente, 'char_especiais'), 0, 40));
				$body .= sprintf("%-2s",   substr($dados->uf_cliente, 0, 2));
				$body .= sprintf("%-8s",   substr(removeCaracteres($dados->cep_cliente, 'char'), 0, 8));
				$body .= sprintf("%-152s", substr(trim($dados->email_nf), 0, 152));
				$body .= sprintf("%6s",    substr($dados->numero_fatura, 0, 6));
				$body .= sprintf("%015s",  substr(removeCaracteres(funcValor($valor_fatura, 'A'), 'moeda2'), 0, 15));
				$body .= sprintf("%-15s",  substr($dados->instrucao_pagamento_nome, 0, 15));
				$body .= sprintf("%-999s", substr(removeCaracteres($dados->descricao_nota, 'char_especiais'), 0, 1000));
				return $body;
			}
		}

		function getImpostoRps($dados)
		{
			$imp = null;
			if ($dados->impostos) {
				$id_nf = $dados->id;
				//$cnpj = $dados->cnpj_cpf_cliente;
				$impostos = json_decode($dados->impostos);
				foreach ($impostos as $key => $value) {
					if (is_object($value)  or is_array($value)) {
						foreach ($value as $k1 => $v1) {
							if (isset($v1->comretencao)) {
								if ($dados->codigo_produto == 'GCK0001') {
									if (isset($v1->comretencao->IRPF)) {
										$soma[$id_nf]['IRPF']           += $v1->comretencao->IRPF;
										$soma[$id_nf]['TOTAL_RETENCAO'] += $v1->comretencao->IRPF;
									}
								} else {
									$soma[$id_nf]['TOTAL_RETENCAO'] += ($v1->comretencao->IRPF + $v1->comretencao->{'PISPASEP'} + $v1->comretencao->COFINS + $v1->comretencao->CSLL);
									$soma[$id_nf]['IRPF']           += $v1->comretencao->IRPF;
									$soma[$id_nf]['PISPASEP']       += $v1->comretencao->{'PISPASEP'};
									$soma[$id_nf]['COFINS']         += $v1->comretencao->COFINS;
									$soma[$id_nf]['CSLL']           += $v1->comretencao->CSLL;
								}
							}
						}
					}
				}

				if (isset($soma) && !empty($soma)) {
					foreach ($soma as $key => $value) {
						foreach ($value as $k1 => $v1) {
							if ($v1 > 0) {
								if ($k1 == 'IRPF') {
									$imp .= '3';
									$imp .= '01';
									$imp .= sprintf("%015s",  number_format($v1, '2', '', ''), 0, 15);
									$imp .= ';';
								} elseif ($k1 == 'PISPASEP') {
									$imp .= '3';
									$imp .= '02';
									$imp .= sprintf("%015s",  number_format($v1, '2', '', ''), 0, 15);
									$imp .= ';';
								} elseif ($k1 == 'COFINS') {
									$imp .= '3';
									$imp .= '03';
									$imp .= sprintf("%015s",  number_format($v1, '2', '', ''), 0, 15);
									$imp .= ';';
								} elseif ($k1 == 'CSLL') {
									$imp .= '3';
									$imp .= '04';
									$imp .= sprintf("%015s",  number_format($v1, '2', '', ''), 0, 15);
									$imp .= ';';
								}
							}
						}
					}
				}
			}
			return $imp;
		}

		function getFooterRps($dados){
			$return = null;
			if ($dados) {
				if (isset($dados['cnpj_cliente'])) {
					$cnpj_cliente = $dados['cnpj_cliente'];
				} else {
					$cnpj_cliente = null;
				}

				if (isset($dados['body'])) {
					$row_number   = count($dados['body']);
				} else {
					$row_number   = null;
				}

				if (isset($dados['impostos'])) {
					foreach ($dados['impostos'] as $key => $value) {
						$row_number += count($value);
					}
				}
				$return .= 9;
				$return .= sprintf("%07s", ($row_number + 2), 0, 15);
				$return .= sprintf("%015s",  removeCaracteres(funcValor($dados['total_valores'], 'A'), 'moeda2'), 0, 15);
				$return .= sprintf("%015s",  removeCaracteres(funcValor($dados['total_retido'], 'A'), 'moeda2'), 0, 15);
			}
			return $return;
		}

		function writeRps($dados, $flag = false){
			if ($dados && is_array($dados)) {
				$cnpj =  null;
				$path = ensure_create_subdirs(UP_ABSPATH, "/notas-fiscais/");
				foreach ($dados as $key => $value) {
					$numero_remessa = $value['numero_remessa'];
					$cnpj = $value['cnpj_cm'];
					$filename = "rps_" . $cnpj . '_' . $numero_remessa . '.txt';
					$fp = fopen($path['path'].DS. $filename, "w");
					if (isset($value['header'])) {
						fwrite($fp, $value['header']);
						fwrite($fp, "\r\n");
					}

					if (isset($value['body'])) {
						foreach ($value['body'] as $kb1 => $vb1) {
							fwrite($fp, $vb1); # code...
							fwrite($fp, "\r\n");
							if (isset($value['impostos'])) {
								foreach ($value['impostos'] as $ki1 => $vi1) {
									if ($ki1 == $kb1) {
										foreach ($vi1 as $ki2 => $vi2) {
											fwrite($fp, $vi2);
											fwrite($fp, "\r\n");
										}
									}
								}
							}
						}
					}

					fwrite($fp, $value['footer']);
					fclose($fp);
					if (file_exists($path['path'] . $filename)) {
						$wrfiles[$key]['name']   = $filename;
						$wrfiles[$key]['status'] = 'success';
					} else {
						$wrfiles[$key]['name']   = $filename;
						$wrfiles[$key]['status'] = 'error';
					}
				}

				if ($flag) {
					return json_encode($wrfiles);
				}
			}
		}

		function cobrarReajuste(array $ma)
		{
			$indices = json_decode($this->obj_indice->getIndicesPorAnoMes($ma['ano'], $ma['mes'], $ma['indice']));
			if ($indices) {
				$dt_indice_ini  = new DateTime($ma['ano'] . '-' . $ma['mes'] . '-01');
				$dt_indice_ini->add(new dateInterval('P2M'));
				foreach ($indices as $key => $value) {
					$contratos = json_decode($this->obj_indice->getContratosByIndice($value->indice, $value->mes));
					if ($contratos) {
						foreach ($contratos as $k1 => $v1) {
							$obj_dt_assinatura = new DateTime($v1->data_assinatura);
							$diff = $obj_dt_assinatura->diff($dt_indice_ini);
							if ($diff->y > 0) {
								$dt_indice_fim = new DateTime($indices[0]->criado_em);
								$dt_indice_fim->sub(new DateInterval('P1D'));
								$notas = json_decode($this->obj_nf->getNotaByEmissao($dt_indice_ini->format('Y-m-d'), $dt_indice_fim->format('Y-m-d'), $v1->id));
								if ($notas) {
									foreach ($notas as $k2 => $v2) {
										if ($v2->codigo_produto != 'COB0001' && $v2->codigo_produto != 'ADM0001') {
											$chk_mov_aux = json_decode($this->obj_nf->getMovAuxiliar(null, 'reajuste', 'diferenca', null, $v2->id));
											if (!$chk_mov_aux) {
												$valor_diferenca = (($v2->valor_total / 100) * $value->percentual);
												$pmov['id_contrato'] 	= $v2->id_contrato;
												$pmov['codigo_cliente'] = $v2->codigo_cliente;
												$pmov['codigo_produto'] = 'ADM0001';
												$pmov['codigo_modulo']  = 'ADM0011';
												$pmov['qtd_transacoes'] = 1;
												$pmov['valor']   = $valor_diferenca;
												$pmov['data_tarifacao'] = $this->data_hora_atual->format('Y-m-d');
												$pmov['data_operacao']  = $this->data_hora_atual->format('Y-m-d');
												$pmov['status_trans']   = 'ativo';
												$pmov['tarifavel'] 	    = 0;
												$pmov['nsu'] 			= '0000000000';
												$pmov['tipo_tarifacao'] = 'auto';

												$id_mov_diario = $this->obj_movimento->insertMov($pmov);
												if ($id_mov_diario) {
													$prel['id_mov_diario']   = $id_mov_diario;
													$prel['id_contrato']     = $v1->id;
													$prel['codigo_produto']  = 'ADM0001';
													$prel['codigo_modulo']   = 'ADM0010';
													$prel['id_produto']      = 20;
													$prel['id_modulo']       = 89;
													$prel['data_tarifacao']  = $this->data_hora_atual->format('Y-m-d');
													$prel['id_nf']           = null;
													$prel['id_nf_origem']    = $v2->id;
													$prel['origem']          = 'reajuste';
													$prel['tipo']            = 'diferenca';
													$prel['descricao']       = 'Cobranca de reajuste ref. NF venc. em ' . convertDate($v2->data_vencimento);
													$prel['valor_base']      = $v2->valor_total;
													$prel['valor_calculado'] = $valor_diferenca;
													$prel['vencimento_em']   = $v2->data_vencimento;
													$prel['qtd_transacoes']  = 1;
													$prel['status']          = 'pendente';
													$is_save = $this->obj_nf->insertMovAux($prel);
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		function getMovRelPorContrato($dt_ini, $dt_fim, $id_contrato = null, $codigo_produto = null, $codigo_modulo = null)
		{
			$dados = json_decode($this->obj_movimento->getMovRelPorContrato($dt_ini, $dt_fim, $id_contrato, $codigo_produto, $codigo_modulo));
			return $dados;
		}

		function calcMultaJuros($id_contrato, $dt_vencimento, $dt_pagamento, $valor_base, $fds = true, $tolerancia = 0)
		{
			try {
				if (!is_object($dt_vencimento)) {
					$retorno['codigo']   = 1;
					$retorno['tipo']     = 'danger';
					$retorno['mensagem'] = 'Data de vencimento parece ser invalida';
					$retorno['dados']    = $dt_vencimento;
					throw new Exception(json_encode($retorno), 1);
				}

				if (!is_object($dt_pagamento)) {
					$retorno['codigo']   = 1;
					$retorno['tipo']     = 'danger';
					$retorno['mensagem'] = 'Data de recebimento parece ser invalida';
					$retorno['dados']    = $dt_vencimento;
					throw new Exception(json_encode($retorno), 1);
				}

				$contrato =  json_decode($this->obj_contrato->contratosAtivos($id_contrato, false, true));

				if ($contrato) {
					if ($dt_pagamento > $dt_vencimento) {
						$diff = $dt_vencimento->diff($dt_pagamento);

						$weekend = ($dt_vencimento->format('w') % 6) == 0;

						if ($tolerancia >= $diff->days) {
							$retorno['codigo']   = 1;
							$retorno['tipo']     = 'warning';
							$retorno['mensagem'] = 'Não cobrar multa e juros';
							$retorno['dados']    = null;
							throw new Exception(json_encode($retorno), 1);
						}

						if ($weekend && $fds == true) {
							//quando vencimento cai no domingo e pago na segunda
							if ($dt_vencimento->format('w') == 0 && $diff->days == 1) {
								$retorno['codigo']   = 1;
								$retorno['tipo']     = 'warning';
								$retorno['mensagem'] = 'Não cobrar multa e juros';
								$retorno['dados']    = null;
								throw new Exception(json_encode($retorno), 1);
							}

							//quando vencimento cai no sabado e pago na segunda
							if ($dt_vencimento->format('w') == 6 && $diff->days == 2) {
								$retorno['codigo']   = 1;
								$retorno['tipo']     = 'warning';
								$retorno['mensagem'] = 'Não cobrar multa e juros';
								$retorno['dados']    = null;
								throw new Exception(json_encode($retorno), 1);
							}
						}

						$vr_multa = (($valor_base / 100) * $contrato[0]->multa);
						$vr_juros = (($valor_base / 100) * $contrato[0]->juros);
						$vr_juros = (($vr_juros / 30) * $diff->days);

						$dados['valor_base']       = $valor_base;
						$dados['dias_atraso']      = $diff->days;
						$dados['percentual_multa'] = $contrato[0]->multa;
						$dados['percentual_juros'] = $contrato[0]->juros;
						$dados['valor_multa']      = funcValor($vr_multa, 'A');
						$dados['valor_juros']      = funcValor($vr_juros, 'A');
						$dados['subtotal']         = funcValor($vr_juros + $vr_multa, 'A');
						$dados['valor_total']      = funcValor($valor_base + $vr_juros + $vr_multa, 'A');

						$retorno['codigo']   = 0;
						$retorno['tipo']     = 'success';
						$retorno['mensagem'] = 'Calculo efetuado com sucesso';
						$retorno['dados']    = $dados;
						throw new Exception(json_encode($retorno), 1);
					} else {
						$retorno['codigo']   = 1;
						$retorno['tipo']     = 'warning';
						$retorno['mensagem'] = 'Não cobrar multa e juros';
						$retorno['dados']    = null;
						throw new Exception(json_encode($retorno), 1);
					}
				} else {
					$retorno['codigo']   = 2;
					$retorno['tipo']     = 'danger';
					$retorno['mensagem'] = 'Contrato vinculado a nota fiscal inexistente!';
					$retorno['dados']    = $dt_vencimento;
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function insertMovAux($action, $parametros)
		{
			try {
				if (!isset($parametros) || empty($parametros) || count($parametros) < 1) {
					$retorno['codigo'] = 1;
					$retorno['input']  = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = 'Informe os lancamentos a serem isentados';
					throw new Exception(json_encode($retorno), 1);
				}

				switch ($action) {
					case 'isentar':
						foreach ($parametros as $key => $value) {
						}
						break;
					case 'lancar':
						foreach ($parametros as $key => $value) {
							$dados_nota  = json_decode($this->obj_nf->getNota($value));
							if ($dados_nota) {
								$data_vencimento = getDataAtual($dados_nota[0]->data_vencimento);
								$data_pagamento  = getDataAtual($dados_nota[0]->recebido_em);
								$multa_juros     = json_decode($this->calcMultaJuros($dados_nota[0]->id_contrato, $data_vencimento, $data_pagamento, $dados_nota[0]->valor_liquido));
								if ($multa_juros->codigo == 0) {
									$padm['id_contrato'] 	 = $dados_nota[0]->id_contrato;
									$padm['codigo_cliente']	 = $dados_nota[0]->codigo_cliente;
									$padm['codigo_produto']	 = $dados_nota[0]->codigo_produto;
									$padm['codigo_modulo']	 = 'ADM0011';
									$padm['valor'] 	 		 = ($multa_juros->dados->valor_multa + $multa_juros->dados->valor_juros);
									$padm['qtd_transacoes']  = 1;
									$padm['centro_custo']  	 = 'nao_informado';
									$padm['data_tarifacao']  = $this->data_hora_atual->format('Y-m-d');
									$padm['data_operacao']   = $this->data_hora_atual->format('Y-m-d');
									$padm['tarifavel'] 		 = 0;
									$padm['flag']  			 = 'automatico';
									$id_mov_diario = $this->obj_movimento->insertMov($padm);
									if ($id_mov_diario) {
										$descricao_multa = "Multa referente a NF com vencimento em " . $data_vencimento->format('d/m/Y') . " paga em " . $data_pagamento->format('d/m/Y');
										$descricao_juros = "Juros referente a NF com vencimento em " . $data_vencimento->format('d/m/Y') . " paga em " . $data_pagamento->format('d/m/Y');

										$pm['id_mov_diario']  = $id_mov_diario;
										$pm['id_contrato']    = $dados_nota[0]->id_contrato;
										$pm['id_produto']     = null;
										$pm['codigo_produto'] = $dados_nota[0]->codigo_produto;
										$pm['id_modulo'] 	  = 20;
										$pm['codigo_modulo']  = 'ADM0011';
										$pm['id_nf_origem']   = $dados_nota[0]->id;
										$pm['origem']         = 'nota fiscal';
										$pm['tipo']           = 'multa';
										$pm['valor_base']     = $dados_nota[0]->valor_liquido;
										$pm['valor_calculado'] = $multa_juros->dados->valor_multa;
										$pm['data_tarifacao'] = $this->data_hora_atual->format('Y-m-d');
										$pm['vencimento_em']  = $data_vencimento->format('Y-m-d');
										$pm['recebido_em']    = $data_pagamento->format('Y-m-d');
										$pm['descricao']      = $descricao_multa;
										$pm['status']         = 'pendente';

										$pj['id_mov_diario']  = $id_mov_diario;
										$pj['id_contrato']    = $dados_nota[0]->id_contrato;
										$pj['id_produto']     = null;
										$pj['codigo_produto'] = $dados_nota[0]->codigo_produto;
										$pj['id_modulo'] 	  = 20;
										$pj['codigo_modulo']  = 'ADM0011';
										$pj['id_nf_origem']   = $dados_nota[0]->id;
										$pj['origem']         = 'nota fiscal';
										$pj['tipo']           = 'juros';
										$pj['valor_base']     = $dados_nota[0]->valor_liquido;
										$pj['valor_calculado'] = $multa_juros->dados->valor_juros;
										$pj['data_tarifacao'] = $this->data_hora_atual->format('Y-m-d');
										$pj['vencimento_em']  = $data_vencimento->format('Y-m-d');
										$pj['recebido_em']    = $data_pagamento->format('Y-m-d');
										$pj['descricao']      = $descricao_juros;
										$pj['status']         = 'pendente';

										$is_save_pm  = $this->obj_nf->insertMovAux($pm);
										$is_save_pj  = $this->obj_nf->insertMovAux($pj);
										if (!$is_save_pm) {
											$retorno['codigo']   = 1;
											$retorno['input']    = $parametros;
											$retorno['output']   = null;
											$retorno['mensagem'] = 'Erro ao salvar lançamento de multa';
											throw new Exception(json_encode($retorno), 1);
										}
										if (!$is_save_pj) {
											$retorno['codigo']   = 1;
											$retorno['input']    = $parametros;
											$retorno['output']   = null;
											$retorno['mensagem'] = 'Erro ao salvar lançamento de juros';
											throw new Exception(json_encode($retorno), 1);
										}
									} else {
										$retorno['codigo']   = 1;
										$retorno['input']    = $parametros;
										$retorno['output']   = $this->obj_movimento;
										$retorno['mensagem'] = 'Erro ao inserir na tabela de transaçõe';
										throw new Exception(json_encode($retorno), 1);
									}
								} else {
									$retorno['codigo']   = 1;
									$retorno['input']    = $value;
									$retorno['output'] 	 = $multa_juros;
									$retorno['mensagem'] = $multa_juros->mensagem;
									throw new Exception(json_encode($retorno), 1);
								}
							} else {
								$retorno['codigo'] = 1;
								$retorno['input']  = $value;
								$retorno['output'] = null;
								$retorno['mensagem'] = 'Nota fiscal não encontrada';
								throw new Exception(json_encode($retorno), 1);
							}
						}
						$retorno['codigo']   = 0;
						$retorno['input']    = $parametros;
						$retorno['output']   = null;
						$retorno['mensagem'] = 'Lançamento efetuado com sucesso';
						throw new Exception(json_encode($retorno), 1);
						break;
					default:
						$retorno['codigo'] = 1;
						$retorno['input']  = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = 'Ação desconhecida';
						throw new Exception(json_encode($retorno), 1);
						break;
				}
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function gerarNfManual($param)
		{
			try {
				global $VAR_SYSTEM;
				$codigo_servico       = null;
				$descricao_lancamento = null;
				$descricao_nota       = null;

				if (isset($param['cliente']) && !empty($param['cliente'])) {
					$cliente = json_decode($this->obj_contrato->clientesPorCodigo($param['cliente'], $param['produto'][0]['codigo'], true, true, $param['id_contrato']));
					$nf['cliente']['id_contrato']                 = $cliente[0]->id;
					$nf['cliente']['cnpj_cpf_cliente']            = $cliente[0]->cnpj;
					$nf['cliente']['cliente']                     = $cliente[0]->razao_social;
					$nf['cliente']['codigo_cliente']              = $cliente[0]->codigo_cliente;
					$nf['cliente']['nome_fantasia_cliente']       = $cliente[0]->nome_fantasia;
					$nf['cliente']['inscricao_estadual_cliente']  = $cliente[0]->inscricao_estadual;
					$nf['cliente']['inscricao_municipal_cliente'] = $cliente[0]->inscricao_municipal;
					$nf['cliente']['endereco_cliente']            = $cliente[0]->endereco;
					$nf['cliente']['numero_cliente']              = $cliente[0]->numero;
					$nf['cliente']['complemento_cliente']         = $cliente[0]->complemento;
					$nf['cliente']['bairro_cliente']              = $cliente[0]->bairro;
					$nf['cliente']['cep_cliente']                 = $cliente[0]->cep;
					$nf['cliente']['municipio_cliente']           = $cliente[0]->cidade;
					$nf['cliente']['uf_cliente']                  = $cliente[0]->estado;
					$nf['cliente']['email_nf']                    = $cliente[0]->email_nf;
				} else {
					throw new Exception("Cliente não informado!", 1);
				}

				if (isset($param['empresa_cm']) && is_numeric($param['empresa_cm'])) {
					$empresa_cm = json_decode($this->obj_contrato->getEmpresasCM($param['empresa_cm']));
					$nf['cliente']['id_empresa']                    = $empresa_cm[0]->id;
					$nf['cliente']['cnpj_prestador']                = $empresa_cm[0]->cnpj;
					$nf['cliente']['razao_social_prestador']        = $empresa_cm[0]->razao_social;
					$nf['cliente']['nome_fantasia_prestador']       = $empresa_cm[0]->nome_fantasia;
					$nf['cliente']['inscricao_estadual_prestador']  = $empresa_cm[0]->inscricao_estadual;
					$nf['cliente']['inscricao_municipal_prestador'] = $empresa_cm[0]->inscricao_municipal;
					$nf['cliente']['endereco_prestador']            = $empresa_cm[0]->endereco;
					$nf['cliente']['numero_prestador']              = $empresa_cm[0]->numero;
					$nf['cliente']['complemento_prestador']         = $empresa_cm[0]->complemento;
					$nf['cliente']['bairro_prestador']              = $empresa_cm[0]->bairro;
					$nf['cliente']['cep_prestador']                 = $empresa_cm[0]->cep;
					$nf['cliente']['municipio_prestador']           = $empresa_cm[0]->cidade;
					$nf['cliente']['uf_prestador']                  = $empresa_cm[0]->estado;
				} else {
					throw new Exception("Empresa C&M não informada!", 1);
				}

				if (isset($param['data_vencimento']) && !empty($param['data_vencimento']) && DateValidation($param['data_vencimento'])) {
					$nf['data_vencimento'] = convertDate($param['data_vencimento']);
					$obj_dt_vencimento =  new DateTime($nf['data_vencimento']);
					if ($obj_dt_vencimento <= $this->data_hora_atual) {
						throw new Exception("Data de vencimento incorreta!", 1);
					}
				}

				if (isset($param_nf['conta_bancaria']) && !empty($param_nf['conta_bancaria'])) {
					$dados_banco = $param_nf['conta_bancaria'];
				}

				if (isset($param['meio_pagamento']) && !empty($param['meio_pagamento'])) {
					$nf['meio_pagamento'] = $param['meio_pagamento'];
				} else {
					throw new Exception("informe o meio de pagamento!", 1);
				}

				if (isset($param['produto']) && is_array($param['produto'])) {

					$produto   = null;
					$vr_lanc   = null;
					$tp_lanc   = null;
					$desc_1    = null;

					$nf['cliente']['codigo_produto'] = $cliente[0]->codigo_produto;
					$produto['id_produto']     		 = $param['produto'][0]['id'];
					$produto['codigo_produto'] 		 = $param['produto'][0]['codigo'];
					$produto['nome_produto']   		 = $param['produto'][0]['nome'];

					if ($nf['cliente']['cnpj_prestador'] == '14289105000117') {
						if ($nf['cliente']['cnpj_cpf_cliente'] == '74014747000135') {
							$descricao_inicial = 'Suporte tecnico em informatica ' . "\n";
							$codigo_servico    = '010701217';
							$comretencao       = true;
						} elseif ($param['produto'][0]['codigo'] == 'GCK0001') {
							$descricao_inicial = 'Intermediacao de negocio' . "\n";
							$codigo_servico    = '100503216';
							$comretencao       = true;
						} elseif ($param['produto'][0]['codigo'] == 'ECS0001') {
							$descricao_inicial = 'Processamento de dados' . "\n";
							$codigo_servico    = '010301211';
						} else {
							$descricao_inicial = 'Consultoria em informatica' . "\n";
							$codigo_servico    = '010602217';
							$comretencao       = true;
						}
					} else {
						if ($param['produto'][0]['codigo'] == 'GCK0001') {
							$descricao_inicial = 'Intermediacao de negocio' . "\n";
							$codigo_servico    = '100503216';
						} elseif ($param['produto'][0]['codigo'] == 'ADM0001') {
							$descricao_inicial = 'Licenca de uso' . "\n";
							$codigo_servico    = '010501219';
						} elseif ($param['produto'][0]['codigo'] == 'ECS0001') {
							$descricao_inicial = 'Hospedagem' . "\n";
							$codigo_servico    = '010301211';
						} else {
							$descricao_inicial = 'Licenca de uso' . "\n";
							$codigo_servico    = '010501219';
						}
					}

					$nf['codigo_servico']    = $codigo_servico;
					$nf['descricao_servico'] = $VAR_SYSTEM['CODIGO_SERVICO'][$empresa_cm[0]->cnpj][$codigo_servico];

					foreach ($param['modulo'] as $key => $value) {
						$impostos = null;
						$vr_lanc  = removeCaracteres($param['valor'][$key], 'moeda2');

						$quant    = $param['quantidade'][$key];
						$tp_lanc  = $param['tipo_lancamento'][$key];

						$nf['modulo'][$key]                    = $value;
						$nf['modulo'][$key]['codigo_produto']  = $produto['codigo_produto'];
						$nf['modulo'][$key]['nome_modulo']     = $value['nome'];
						$nf['modulo'][$key]['tipo_lancamento'] = $tp_lanc;
						$nf['modulo'][$key]['qtd_transacoes']  = $quant;
						$nf['modulo'][$key]['valor_liquido']   = $vr_lanc;
						$nf['modulo'][$key]['valor_desconto']  = 0;


						if ($value["nome"] === "implantacao") {
							$comretencao = true;
						}

						$nf['impostos'][$key] = json_decode($this->calcImposto($nf['cliente'], $nf['modulo'][$key], $comretencao));
						$impostos = $nf['impostos'][$key];
						$nf['modulo'][$key]['impostos']    = $impostos->totalizadores;
						$nf['modulo'][$key]['valor_total'] = ($impostos->totalizadores->semretencao->total + $vr_lanc);
						$nf['valor_liquido']     	       += $vr_lanc;

						if (isset($impostos->totalizadores->comretencao->total)) {
							$nf['valor_fatura'] += (($impostos->totalizadores->semretencao->total + $vr_lanc) - $impostos->totalizadores->comretencao->total);
						} else {
							$nf['valor_fatura'] += (($impostos->totalizadores->semretencao->total + $vr_lanc));
						}
						$nf['valor_impostos']   	       += $impostos->totalizadores->semretencao->total;
						$nf['valor_total']   	           += ($impostos->totalizadores->semretencao->total + $vr_lanc);
						if (isset($impostos->totalizadores->comretencao->total)) {
							$nf['valor_impostos_retidos'] += $impostos->totalizadores->comretencao->total;
						} else {
							$nf['valor_impostos_retidos'] += 0;
						}

						$nf['valor_impostos_municipal']    += $impostos->totalizadores->naoincidente->Municipal1;
						$nf['valor_impostos_federal']      += $impostos->totalizadores->naoincidente->Federal1;
					}
					$nf['faturamento_relacionado'] = $nf['modulo'];
				} else {
					throw new Exception("Nenhum produto lançado!", 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
			return convertToObject($nf);
		}

		function inserirLancamento($dados)
		{
			try {
				$dados_md['id_contrato'] 	 = $dados->contrato->id;
				$dados_md['codigo_cliente']	 = $dados->contrato->codigo_cliente;
				$dados_md['codigo_produto']	 = $dados->contrato->codigo_produto;
				$dados_md['codigo_modulo']	 = $dados->contrato->codigo_modulo;
				$dados_md['valor']	 	     = $dados->contrato->valor;
				$dados_md['qtd_transacoes']  = 1;
				$dados_md['centro_custo']  	 = 'nao_informado';
				$dados_md['data_tarifacao']  = $this->data_atual->format('Y-m-d');
				$dados_md['data_operacao']   = $this->data_atual->format('Y-m-d');
				$dados_md['tarifavel'] 		 = 0;
				$dados_md['flag']  			 = 'automatico';
				$id_mov_diario 				 = $this->obj_movimento->insertMov($dados_md);
				if ($id_mov_diario) {
					$dados_mva['id_mov_diario']   = $id_mov_diario;
					$dados_mva['id_contrato']     = $dados->contrato->id;
					$dados_mva['codigo_modulo']	  = $dados->contrato->codigo_modulo;
					$dados_mva['codigo_produto']  = $dados->contrato->codigo_produto;
					$dados_mva['id_modulo'] 	  = $dados->contrato->id_modulo;
					$dados_mva['id_produto']      = $dados->contrato->id_produto;
					$dados_mva['id_nf']  		  = null;
					$dados_mva['id_nf_origem']    = null;
					$dados_mva['origem']          = 'lancamento';
					$dados_mva['tipo']            = 'taxa_inatividade';
					$dados_mva['descricao']       = "Taxa de inatividade conforme estipulado em contrato";
					$dados_mva['qtd_transacoes']  = 1;
					$dados_mva['qtd_horas']       = 0;
					$dados_mva['valor_base']      = $dados->contrato->valor;
					$dados_mva['valor_calculado'] = $dados->contrato->valor;
					$dados_mva['data_tarifacao']  = $this->data_atual->format('Y-m-d');
					$dados_mva['vencimento_em']   = null;
					$dados_mva['recebido_em']     = null;
					$dados_mva['status']          = 'pendente';
					$is_save = $this->obj_nf->insertMovAux($dados_mva);
					if ($is_save) {
						$retorno['codigo']   = 0;
						$retorno['output'] 	 = $is_save;
						$retorno['mensagem'] = 'Sucesso';
						throw new Exception(json_encode($retorno), 1);
					} else {
						$retorno['codigo']   = 1;
						$retorno['mensagem'] = 'Erro ao salvar no movimento auxiliar';
						throw new Exception(json_encode($retorno), 1);
					}
				} else {
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Erro ao salvar no movimento diario( tarifações )';
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function sendRpsNfe($cnpj_prestador, $numero_remessa, $path_arquivo, $parametros = null)
		{
			try {
				$this->loadIntegracao($cnpj_prestador);
				echo '<pre>';
					var_dump($cnpj_prestador);
				echo '</pre>';
				exit;
				if (isset($parametros['action']) && $parametros['action'] == 'enviar') {
					$parametros['validar'] = false;
				} else {
					$parametros['validar'] = true;
				}
				$path_full = UP_ABSPATH . 'notas-fiscais' . DS . $path_arquivo;
				if (file_exists($path_full)) {
					$parametros['base64_arquivo'] = base64_encode(file_get_contents($path_full));
					$parametros['cnpj'] 		  = $cnpj_prestador;
					$parametros['remessa'] 		  = $numero_remessa;
					$parametros['nome_arquivo']   = $path_arquivo;
					$remessas = json_decode($this->fatura_modelo->getGrupoRemessasByPrestador($cnpj_prestador, $numero_remessa));
					if ($remessas) {
						$parametros['inscricao_municipal'] = $remessas[0]->inscricao_municipal_prestador;
						if ($this->integracao) {
							$api_exec = json_decode($this->integracao->Exec('arquivo', 'enviar', $parametros));
							if (isset($parametros['action']) && $parametros['action'] == 'enviar') {
								$param_envio['tipo_envio'] = 'criar';
							} else {
								$param_envio['tipo_envio'] = 'validar';
							}
							$param_envio['alterado_por']	= (isset($_SESSION['cmswerp']['userdata']->id)) ? $_SESSION['cmswerp']['userdata']->id : null;
							$param_envio['alterado_em']		= $this->controller->data_hora_atual->format('Y-m-d H:i:s');
							$param_envio['deleted']			= 0;
							$param_envio['id_origem'] 	 	= $numero_remessa;
							$param_envio['empresa_origem']  = $cnpj_prestador;
							$param_envio['origem'] 		 	= 'RPS';
							$param_envio['tipo'] 		 	= 'remessa';
							$param_envio['modalidade'] 	 	= 'notas-fiscais';
							$param_envio['nome'] 		 	= $path_arquivo;
							$param_envio['path'] 			= UP_ABSPATH . 'notas-fiscais' . DS;
							$param_envio['data_envio'] 		= $this->controller->data_hora_atual->format('Y-m-d H:i:s');
							$param_envio['data_retorno']	= $this->controller->data_hora_atual->format('Y-m-d H:i:s');

							$i1 = $cnpj_prestador;
							$i2 = $numero_remessa;
							$i3 = $numero_remessa;
							if (isset($api_exec->codigo) && $api_exec->codigo == 0) {
								$param_envio['status_envio'] 	= 'ok';
								$param_envio['info_envio'] 	 	= $api_exec->output;
								$param_envio['mensagem'] 	 	= $api_exec->mensagem;
								$status_remessa[$i1][$i2][$i3] 	= 'processando';
							} else {
								$param_envio['status_envio'] = 'erro';
								$param_envio['info_envio'] 	 = $api_exec->output;
								$param_envio['mensagem'] 	 = $api_exec->mensagem;
								$status_remessa[$i1][$i2][$i3]  = 'erro';
							}
							$updateDb = $this->updateRemessaDb($cnpj_prestador, $numero_remessa, $status_remessa);
							$this->obj_arquivo->saveDb($param_envio);

							if (!$this->obj_arquivo->modelo->db->error) {
								if (isset($api_exec->codigo) && $api_exec->codigo == 0) {
									$retorno['codigo'] 	   = 0;
									$retorno['mensagem'][] = $api_exec->mensagem;
								} else {
									$retorno['codigo'] 	   			 = 1;
									$retorno['mensagem'][] 			 = $api_exec->mensagem;
									$parametros['tipo_destinatario'] = 'user';
									$parametros['email_to'] 		 = DEFAULT_ALERTA;
									$parametros['mensagem'] 		 = 'Erro ao enviar as notas fiscais para a prefeitura';
									return $this->notificacoes->enviar('teams', $parametros);
								}
							} else {
								$retorno['codigo'] 	 = 1;
								$retorno['mensagem'][] = 'Erro ao salvar na base de dados ' . $this->obj_arquivo->modelo->db->error;
							}
							throw new Exception(json_encode($retorno), 1);
						} else {
							$retorno['codigo'] 	 = 1;
							$retorno['mensagem'] = 'Nenhuma integracao encontrada';
							throw new Exception(json_encode($retorno), 1);
						}
					} else {
						$retorno['codigo'] 	 = 1;
						$retorno['mensagem'] = 'A remessa de numero ' . $numero_remessa . ' para a empresa ' . $cnpj_prestador . ' não foi encontrada';
						throw new Exception(json_encode($retorno), 1);
					}
				} else {
					$retorno['codigo'] 	 = 1;
					$retorno['mensagem'] = 'O arquivo ' . $path_arquivo . ' não foi encontrado';
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function updateStatusNfe($cnpj_prestador, $numero_remessa){
			try {
				$this->loadIntegracao($cnpj_prestador);
				if (!is_numeric($cnpj_prestador) || !is_numeric($numero_remessa)) {
					$retorno['codigo'] = 1;
					$retorno['mensagem'] = 'Informe o CNPJ e numero de remessa corretamente';
					throw new Exception(json_encode($retorno), 1);
				}

				$envios = json_decode($this->obj_arquivo->modelo->getLastEnvioArquivoByCnpj($cnpj_prestador, $numero_remessa));
				if ($envios) {
					foreach ($envios as $key => $value) {
						$parametros['inscricao_municipal'] 	= $value->inscricao_municipal;
						$parametros['cnpj'] 		  		= $cnpj_prestador;
						$parametros['ProtocoloRemessa'] 	= $value->info_envio;
						$api_exec 							= json_decode($this->integracao->Exec('arquivo', 'status', $parametros));
						$i1 = $value->empresa_origem;
						$i2 = $value->id_origem;
						$i3 = $value->id;

						if (isset($api_exec->codigo) && $api_exec->codigo == 0) {
							$param_retorno['info_retorno'] 	 = $api_exec->output;
							$param_retorno['mensagem'] 	 	 = $api_exec->mensagem;
							switch ($api_exec->output) {
								case '-2':
								case '-1':
									$status_remessa[$i1][$i2][$i3]   = 'processando';
									$param_retorno['status_retorno'] = 'processando';
									break;
								case '0':
									$status_remessa[$i1][$i2][$i3]   = 'validado';
									$param_retorno['status_retorno'] = 'ok';
									break;
								case '1':
									$status_remessa[$i1][$i2][$i3]   = 'importado';
									$param_retorno['status_retorno'] = 'ok';
									break;
								default:
									$status_remessa[$i1][$i2][$i3]   = 'erro';
									$param_retorno['status_retorno'] = 'erro';
									break;
							}
						} else {
							$status_remessa[$i1][$i2][$i3]   = 'erro';
							$param_retorno['status_retorno'] = 'erro';
							$param_retorno['info_retorno']   = $api_exec->output;
							$param_retorno['mensagem'] 	     = $api_exec->mensagem;
						}

						$is_update = $this->obj_arquivo->saveDb($param_retorno, $value->id);
						if (!$this->obj_arquivo->modelo->db->error) {
							$retorno['codigo'] = 0;
							$retorno[$cnpj_prestador][$numero_remessa] = $api_exec->output;
						} else {
							$retorno['codigo'] 	   = 1;
							$retorno['mensagem'][] = 'Erro ao salvar na base de dados ' . $this->obj_arquivo->modelo->db->error;
							throw new Exception(json_encode($retorno), 1);
						}
					}
					$updateDb = json_decode($this->updateRemessaDb($value->empresa_origem, $value->id_origem, $status_remessa));
					throw new Exception(json_encode($updateDb));
				} else {
					$retorno['codigo'] = 1;
					$retorno['mensagem'] = 'Remessa numero ' . $numero_remessa . ' não encontrada para o CNPJ ' . $cnpj_prestador;
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function checkRetornoRps($cnpj_prestador, $numero_remessa)
		{
			try {
				$this->loadIntegracao($cnpj_prestador);
				if (!is_numeric($cnpj_prestador) || !is_numeric($numero_remessa)) {
					$retorno['codigo'] = 1;
					$retorno['mensagem'] = 'Informe o CNPJ e numero de remessa corretamente';
					throw new Exception(json_encode($retorno), 1);
				}
				$envios = json_decode($this->obj_arquivo->modelo->getLastEnvioArquivoByCnpj($cnpj_prestador, $numero_remessa));
				if ($envios) {
					foreach ($envios as $key => $value) {
						$parametros['inscricao_municipal'] 	= $value->inscricao_municipal;
						$parametros['cnpj'] 		  		= $cnpj_prestador;
						$parametros['ProtocoloRemessa'] 	= $value->info_envio;
						$api_exec 							= json_decode($this->integracao->Exec('arquivo', 'status', $parametros));
						if (isset($api_exec->info->SituacaoArq)) {
							if (isset($api_exec->info->NomeArqRetorno)) {
								$parametros['NomeArqRetorno'] = (string) $api_exec->info->NomeArqRetorno->{0};
							} else {
								$parametros['NomeArqRetorno'] = null;
							}

							switch ($api_exec->info->SituacaoArq) {
								case '0':
									$param_envio['mensagem'] = 'Arquivo validado';
									$obj_arquivo = $this->controller->load_model('arquivos/arquivos', true);
									$obj_arquivo->setTable('envios_arquivos');
									$is_save 	 			 = $obj_arquivo->save($param_envio, $value->id);
									if (!$is_save) {
										$retorno['codigo'] = 1;
										$retorno['mensagem'] = 'Erro ao atualizar envio';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case '1':
									$dados_retorno = json_decode($this->integracao->Exec('arquivo', 'download', $parametros));
									if (isset($dados_retorno->codigo) && $dados_retorno->codigo == 0) {
										if (isset($dados_retorno->info->{0}) && !empty($dados_retorno->info->{0})) {
											if (!file_exists(TMP_FILES . 'remessa_nf' . DS . $parametros['NomeArqRetorno'])) {
												$fp = fopen(TMP_FILES . 'remessa_nf' . DS . $parametros['NomeArqRetorno'], 'w');
												if (fwrite($fp, base64_decode($dados_retorno->info->{0}))) {
													fclose($fp);
													$input = fopen(TMP_FILES . 'remessa_nf' . DS . $parametros['NomeArqRetorno'], "r");
													while (!feof($input)) {
														$linha  = fgets($input);
														$tipo   = substr($linha, 0, 1);
														if ($linha && $tipo == 2) {
															$numero_nota = substr($linha, 6, 6);
															$numero_rps  = substr($linha, 55, 9);
															if (
																!empty($numero_nota) &&
																is_numeric($numero_nota) &&
																!empty($numero_rps) &&
																is_numeric($numero_rps)
															) {

																$nf_info = json_decode($this->fatura_modelo->getNfByRps($parametros['cnpj'], $numero_remessa, str_pad($numero_rps, 10, 0, STR_PAD_LEFT)));
																if ($nf_info) {
																	$obj_arquivo = $this->controller->load_model('arquivos/arquivos', true);
																	$obj_arquivo->setTable('envios_arquivos');
																	$param_nota['numero_prefeitura'] = $numero_nota;
																	$param_envio['mensagem'] 		 = 'Arquivo importado';
																	$is_save_nf    = $this->obj_nf->save($param_nota, $nf_info[0]->id_nf);
																	$is_save_envio = $obj_arquivo->save($param_envio, $value->id);
																	if (!$is_save_nf) {
																		$retorno['codigo'] = 1;
																		$retorno['mensagem'] = 'Erro ao atualizar nota fiscal';
																		throw new Exception(json_encode($retorno), 1);
																	}

																	if (!$is_save_envio) {
																		$retorno['codigo'] = 1;
																		$retorno['mensagem'] = 'Erro ao atualizar envio';
																		throw new Exception(json_encode($retorno), 1);
																	}
																} else {
																	$retorno['codigo'] = 1;
																	$retorno['mensagem'] = 'RPS não encontrado';
																	throw new Exception(json_encode($retorno), 1);
																}
															} else {
																$retorno['codigo'] = 1;
																$retorno['mensagem'] = 'Erro ao encontrar numero rps/numero nota no arquivo';
																throw new Exception(json_encode($retorno), 1);
															}
														}
													}
													fclose($input);
												} else {
													$retorno['codigo'] = 1;
													$retorno['mensagem'] = 'Erro ao criar o arquivo de retorno COD: 2969';
													throw new Exception(json_encode($retorno), 1);
												}
											}
										} else {
											$retorno['codigo'] = 1;
											$retorno['mensagem'] = 'Erro ao receber o arquivo de retorno';
											throw new Exception(json_encode($retorno), 1);
										}
									} else {
										$retorno['codigo'] 	 = 1;
										$retorno['output'] 	 = $dados_retorno;
										$retorno['mensagem'] = 'Erro no retorno do download COD: 2970';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								case '2':
									$dados_retorno = json_decode($this->integracao->Exec('arquivo', 'donwload', $parametros));
									if (isset($dados_retorno->codigo) && $dados_retorno->codigo == 0) {
										if (isset($dados_retorno->info->{0}) && !empty($dados_retorno->info->{0})) {
											if (!file_exists(TMP_FILES . 'remessa_nf' . DS . $parametros['NomeArqRetorno'])) {
												$fp = fopen(TMP_FILES . 'remessa_nf' . DS . $parametros['NomeArqRetorno'], 'w');
												if (fwrite($fp, base64_decode($dados_retorno->info->{0}))) {
													fclose($fp);
													$input = fopen(TMP_FILES . 'remessa_nf' . DS . $parametros['NomeArqRetorno'], "r");
													while (!feof($input)) {
														$linha = fgets($input);
														if ($linha) {
															$ocorrencia = strrpos($linha, ';');
															if ($ocorrencia) {
																$ocorrencia -= 5;
																$erro 		= (int) substr($linha, $ocorrencia, 5);
																if (!empty($erro) && is_numeric($erro)) {
																	require_once(ABSPATH . DS . 'arquivos' . DS . 'nfe_barueri' . DS . 'lista_erros.php');
																	if (isset($nf_erros['RPS'][$erro])) {
																		$arr_arquivo = explode('.', $api_exec->info->NomeArqRetorno->{0});
																		$cod_envio	 = $arr_arquivo[0];
																		$msg_erro 	 = $erro . ' - ' . $nf_erros['RPS'][$erro];
																		if ($cod_envio) {
																			$param_envio['mensagem'] = $msg_erro;
																			$obj_arquivo = $this->controller->load_model('arquivos/arquivos', true);
																			$obj_arquivo->setTable('envios_arquivos');
																			$is_save 	 = $obj_arquivo->save($param_envio, $cod_envio, 'info_envio');
																			if (!$is_save) {
																				$retorno['codigo'] = 1;
																				$retorno['mensagem'] = 'Erro ao atualizar envio';
																				throw new Exception(json_encode($retorno), 1);
																			}
																		}
																	}
																}
															}
														}
													}
													fclose($input);
												} else {
													$retorno['codigo'] = 1;
													$retorno['mensagem'] = 'Erro ao criar o arquivo de retorno COD: 3024';
													throw new Exception(json_encode($retorno), 1);
												}
											}
										} else {
											$retorno['codigo'] = 1;
											$retorno['mensagem'] = 'Erro ao receber o arquivo de retorno importacao';
											throw new Exception(json_encode($retorno), 1);
										}
									} else {
										$retorno['codigo'] = 1;
										$retorno['mensagem'] = 'Erro ao receber o arquivo de retorno de erro';
										throw new Exception(json_encode($retorno), 1);
									}
									break;
								default:
									$retorno['codigo'] = 1;
									$retorno['mensagem'] = 'Situacao do arquivo desconhecida';
									throw new Exception(json_encode($retorno), 1);
									break;
							}
						} else {
							$retorno['codigo'] 	 = 1;
							$retorno['output'] 	 = $api_exec;
							$retorno['mensagem'] = 'Erro no retorno do status COD: 3028';
							throw new Exception(json_encode($retorno), 1);
						}
					}
				} else {
					$retorno['codigo'] 	 = 1;
					$retorno['mensagem'] = 'Nenhum envio encontrado';
					throw new Exception(json_encode($retorno), 1);
				}

				$retorno['codigo'] 	 = 0;
				$retorno['mensagem'] = 'Sucesso';
				throw new Exception(json_encode($retorno), 1);
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function updateRemessaDb($cnpj, $numero_remessa, $parametros)
		{
			try {
				if ($parametros) {
					foreach ($parametros as $key => $value) {
						foreach ($value as $k1 => $v1) {
							if (array_search("importado", $v1)) {
								$remessa['status'] = 'importado';
							} elseif (array_search("validado", $v1)) {
								$remessa['status'] = 'validado';
							} elseif (array_search("processando", $v1)) {
								$remessa['status'] = 'processando';
							} else {
								$remessa['status'] = 'erro';
							}
							$where_fields = array('cnpj_prestador', 'numero_remessa');
							$where_values = array($key, $k1);
							$is_save = $this->fatura_modelo->customSave($remessa, $where_fields, $where_values);
							if (!$is_save) {
								$retorno['codigo'] = 1;
								$retorno['mensagem'] = 'erro ao atualizar remessas';
								throw new Exception(json_encode($retorno), 1);
							}
						}
					}
					$retorno['codigo'] = 0;
					$retorno['mensagem'] = 'sucesso';
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['codigo'] = 1;
					$retorno['mensagem'] = 'Informe os parametros de status';
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function loadIntegracao($cnpj_prestador)
		{
			switch ($cnpj_prestador) {
				case '07003180000104':
					$this->integracao = new Integracoes($this->controller, 'NFE0001');
					break;
				case '03215009000108':
					$this->integracao = new Integracoes($this->controller, 'NFE0002');
					break;
				case '14289105000117':
					$this->integracao = new Integracoes($this->controller, 'NFE0003');
					break;
				case '43561343000138':
					$this->integracao = new Integracoes($this->controller, 'NFE0004');
					break;
			}
		}

		function getInfoEnvios($empresa_origem, $id_origem)
		{
			try {
				if (!is_numeric($empresa_origem) || !is_numeric($id_origem)) {
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Empresa ou remessa invalida';
					throw new Exception(json_encode($retorno), 1);
				}
				$registros = json_decode($this->modelo->infoEnvios($empresa_origem, $id_origem));
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}
		
		function getErroMsg()
		{
			return $this->msg_erro;
		}
			
		function getErro()
		{
			return $this->erro;
		}
		
		function setErroMsg($msg)
		{
			$this->erro[0] 	   = true;
			$this->msg_erro[]  = $msg;
			$parametros['tipo_destinatario'] = 'user';
			$parametros['email_to'] 		 = DEFAULT_ALERTA;
			$parametros['mensagem'] 		 = $msg;
			$this->notificacoes->enviar('teams', $parametros);
		}
	}