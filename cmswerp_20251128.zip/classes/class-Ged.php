<?php
	/**
	* Julio
	* Classe para log de eventos no sistema
	*/
	class Ged extends Main{
		protected $modelo;
		function __construct( $controller, $param = null, $load_modulos = false ){
			parent::__construct( $controller );
			$this->modelo = $this->controller->load_model('ged/ged', true);
			if( $load_modulos ){
				$this->obj_upload    = new Upload($controller);
				$this->obj_contrato  = $controller->load_model('contratos/contratos', true);
				$this->obj_produtos  = $controller->load_model('cadastros/produtos', true);
			}
		}

		function getDocumentoByOrigemId( $origem, $id ){
			return $documentos = json_decode( $this->modelo->getDocumentoByOrigemId( $origem, $id ) );
		}

		public function createDoc($doc, $produto, $param, $make_upload = true){
			try{
				require_once ABSPATH.'/libs/mpdf/vendor/autoload.php';
				$content        = null;
				$file_name      = null;
				$nome_amigavel  = null;
				$multipart  	= microtime(true);
				$header 		= 'Content-Type: multipart/form-data; boundary='.$multipart;
				$form_filed     = 'arquivo';
				$cnpj_cliente   = removeCaracteres($param['cnpj_cliente'], true, null);
				$codigo_cliente = substr($cnpj_cliente, '0', '8');
				$dados_produto  = json_decode($this->obj_produtos->getProduto(null, $produto));
				if(isset($param['cnpj_prestador'])){
					$dados_prestador = json_decode($this->obj_contrato->getEmpresasCM(null, $param['cnpj_prestador']));
				}else{
					$dados_prestador = json_decode($this->obj_contrato->getEmpresasCM(null, CNPJ_CM_DEFAULT));
				}

				if(!$dados_prestador){
					$retorno['codigo']   = 2;
					$retorno['tipo']     = 'erro';
					$retorno['mensagem'] = 'Empresa CM nao encontrada';
					$retorno['dados']    = $dados_prestador;
					throw new Exception(json_encode($retorno), 1);
				}

				if(!$dados_produto){
					$retorno['codigo']   = 2;
					$retorno['tipo']     = 'erro';
					$retorno['mensagem'] = 'Produto nao encontrado';
					$retorno['dados']    = $produto;
					throw new Exception(json_encode($retorno), 1);
				}

				switch ($produto) {
					case 'RLT0001':
						switch ($doc) {
							case 'contrato':
								$nome_amigavel  = 'Contrato RocketMax'; 
								$file_name      = 'contrato_rocketmax_'.str_replace(" ","_", trim(strtolower($param['razao_social_cliente']))).'_'.$this->data_atual->format('Ymd').'.pdf';
								$tipo_documento = 'contrato';
								$tipo_contrato  = 'licenciamento';
								$observacoes	= null;
								$url_parametros = http_build_query($param);
								// echo 'http://'.$_SERVER['SERVER_NAME'].'/ged/gerarcontrato/RTL0001/prepago/?'.$url_parametros;
								$conteudo_html  = file_get_contents('http://'.$_SERVER['SERVER_NAME'].'/ged/gerarcontrato/RTL0001/prepago/?'.$url_parametros);
								break;
							case 'termo_recisao':
								$nome_amigavel  = 'termo de recisao RocketMax';
								$file_name      = $doc.'_'.$cnpj_cliente.'_'.$produto.'_'.$this->data_atual->format('Ymd').'.pdf';
								$tipo_documento = 'termo';
								$tipo_contrato  = 'recisao';
								$observacoes	= 'Termo de recisão contrato rocket max';
								$url_parametros = http_build_query($param);
								$conteudo_html  = file_get_contents('http://'.$_SERVER['SERVER_NAME'].'/ged/gerarcontrato/RTL0001/termo_recisao/?'.$url_parametros);
								// Para contratos Rocket max não é necessario atribuir nome de arquivo no $content pois esta definido como padrao
								// Para demais contratos informar o nome do arquivo conforme o exemplo abaixo
							break;
							default:
								$retorno['codigo']   = 2;
								$retorno['tipo']     = 'erro';
								$retorno['mensagem'] = 'Tipo de documento desconhecido';
								$retorno['dados']    = $doc;
							break;
						}

						if($conteudo_html){
							$mpdf = new \Mpdf\Mpdf();
							$mpdf->simpleTables = true;
							$mpdf->SetDisplayMode('fullpage');
							$mpdf->img_dpi = 96;
							$mpdf->SetTitle('CONTRATO ROCKET MAX');
							$mpdf->use_kwt = true; 
							$mpdf->allow_charset_conversion = true;
							$mpdf->WriteHTML($conteudo_html);
							$mpdf->Output(UP_ABSPATH.DS."temp".DS.$file_name);
							
							if(file_exists(UP_ABSPATH.DS."temp".DS.$file_name)){
								if($make_upload){
									$file_contents = file_get_contents(UP_ABSPATH.DS."temp".DS.$file_name);
									$content =  "--".$multipart."\r\n".
									"Content-Disposition: form-data; name=\"".$form_filed."\"; filename=\"".basename($file_name)."\"\r\n".
												"Content-Type: application/zip\r\n\r\n".
												$file_contents."\r\n";
									// signal end of request (note the trailing "--")
									
									$content .= "--".$multipart."--\r\n";
									$content .= "--".$multipart."\r\n"."Content-Disposition: form-data; name=\"codigo_cliente\"\r\n\r\n".$codigo_cliente."\r\n";
									$content .= "--".$multipart."--\r\n";
		
									$content .= "--".$multipart."--\r\n";
									$content .= "--".$multipart."\r\n"."Content-Disposition: form-data; name=\"nome_fantasia\"\r\n\r\n".$param['razao_social_cliente']."\r\n";
									$content .= "--".$multipart."--\r\n";
		
									$content .= "--".$multipart."--\r\n";
									$content .= "--".$multipart."\r\n"."Content-Disposition: form-data; name=\"id_produto\"\r\n\r\n".$dados_produto[0]->id."\r\n";
									$content .= "--".$multipart."--\r\n";
		
									$content .= "--".$multipart."--\r\n";
									$content .= "--".$multipart."\r\n"."Content-Disposition: form-data; name=\"codigo_produto\"\r\n\r\n".$dados_produto[0]->codigo."\r\n";
									$content .= "--".$multipart."--\r\n";
		
									$content .= "--".$multipart."--\r\n";
									$content .= "--".$multipart."\r\n"."Content-Disposition: form-data; name=\"path_root\"\r\n\r\n".UP_GED."\r\n";
									$content .= "--".$multipart."--\r\n";
		
									$content .= "--".$multipart."--\r\n";
									$content .= "--".$multipart."\r\n"."Content-Disposition: form-data; name=\"data_criacao\"\r\n\r\n".$this->data_atual->format('Y-m-d')."\r\n";
									$content .= "--".$multipart."--\r\n";
		
									$content .= "--".$multipart."--\r\n";
									$content .= "--".$multipart."\r\n"."Content-Disposition: form-data; name=\"tipo_documento\"\r\n\r\n".$tipo_documento."\r\n";
									$content .= "--".$multipart."--\r\n";
		
									$content .= "--".$multipart."--\r\n";
									$content .= "--".$multipart."\r\n"."Content-Disposition: form-data; name=\"classificacao\"\r\n\r\n".$tipo_contrato."\r\n";
									$content .= "--".$multipart."--\r\n";
		
									$content .= "--".$multipart."--\r\n";
									$content .= "--".$multipart."\r\n"."Content-Disposition: form-data; name=\"observacoes\"\r\n\r\n".$observacoes."\r\n";
									$content .= "--".$multipart."--\r\n";
		
									$content .= "--".$multipart."--\r\n";
									$content .= "--".$multipart."\r\n"."Content-Disposition: form-data; name=\"nome_arquivo\"\r\n\r\n".$file_name."\r\n";
									$content .= "--".$multipart."--\r\n";
		
									$content .= "--".$multipart."--\r\n";
									$content .= "--".$multipart."\r\n"."Content-Disposition: form-data; name=\"nome_amigavel\"\r\n\r\n".$nome_amigavel."\r\n";
									$content .= "--".$multipart."--\r\n";
		
									$context = stream_context_create(array(
										'http' => array(
											'method' => 'POST',
											'header' => $header,
											'content' => $content,
										)
									));
									$url_upload = 'http://'.$_SERVER['SERVER_NAME'].'/ged/savefile/id/'.$codigo_cliente.'/0';
									$result     = file_get_contents($url_upload, false, $context);
									$this->obj_log->writeLog($result, 'debug', null, 'd4sign');
									$result = json_decode($result);
									if($result){
										if(0 == $result->codigo){
											$retorno['codigo']   = 0;
											$retorno['tipo']     = 'success';
											$retorno['mensagem'] = 'Arquivo salvo com sucesso';
											$retorno['dados']    = $result->dados;
										}else{
											$retorno['codigo']   = 2;
											$retorno['tipo']     = 'danger';
											$retorno['mensagem'] = 'Erro no upload do arquivo CD 1';
											$retorno['dados']    = $result;
										}
									}else{
										$retorno['codigo']   = 2;
										$retorno['tipo']     = 'danger';
										$retorno['mensagem'] = 'Erro no upload do arquivo CD 2';
										$retorno['dados']    = $url_upload.json_encode($content);
									}
								}else{
									$retorno['codigo']   = 0;
									$retorno['tipo']     = 'success';
									$retorno['mensagem'] = 'Arquivo temporario gerado com sucesso';
									$retorno['dados']    = UP_ABSPATH.DS."temp".DS.$file_name;
								}
							}else{
								$retorno['codigo']   = 2;
								$retorno['tipo']     = 'erro';
								$retorno['mensagem'] = 'Erro ao gerar o pdf do contrato';
								$retorno['dados']    = $param;
							}
						}else{
							$retorno['codigo']   = 2;
							$retorno['tipo']     = 'erro';
							$retorno['mensagem'] = 'Erro ao gerar template de arquivo';
							$retorno['dados']    = $conteudo_html;
						}
					break;
					default:
						$retorno['codigo']   = 2;
						$retorno['tipo']     = 'erro';
						$retorno['mensagem'] = 'Produto nao informado';
						$retorno['dados']    = $doc;
					break;
				}
				throw new Exception(json_encode($retorno), 1);
			}catch(Exception $e){
				return $e->getMessage();
			}
		}
		
		function saveDoc($param){
			try {
				$file_name = null;
				if(!isset($param['codigo_cliente']) || !is_numeric($param['codigo_cliente'])){
					$retorno['codigo']   = 2;
					$retorno['tipo']     = "erro";
					$retorno['mensagem'] = 'Codigo cliente invalido';
					$retorno['dados']    = $param;
					throw new Exception(json_encode($retorno), 1);
				}else{
					$cliente = json_decode($this->obj_contrato->clientesAtivos($param['codigo_cliente'], false));
				}

				if(!$cliente){
					$retorno['codigo']   = 2;
					$retorno['tipo']     = "erro";
					$retorno['mensagem'] = 'Cliente nao encontrado';
					$retorno['dados']    = $param;
					throw new Exception(json_encode($retorno), 1);
				}

				if(!isset($param['post_file']) || empty($param['post_file'])){
					$retorno['codigo']   = 2;
					$retorno['tipo']     = "erro";
					$retorno['mensagem'] = 'Arquivo vazio';
					$retorno['dados']    = $param;
					throw new Exception(json_encode($retorno), 1);
				}else{
					$ext = pathinfo($param['post_file']['name'], PATHINFO_EXTENSION);
				}

				if(!isset($cliente[0]->nome_fantasia) || empty($cliente[0]->nome_fantasia)){
					$param['nome_fantasia'] = strtolower($cliente[0]->razao_social);
				}else{
					$param['nome_fantasia'] = strtolower($cliente[0]->nome_fantasia);
				}
				
				if(!isset($param['path_root']) || empty($param['path_root'])){
					$param['path_root'] = UP_GED.DS.str_replace(" ","_", trim(strtolower($param['nome_fantasia']))).DS;
				}

				$upload = json_decode($this->obj_upload->loadFile($param['post_file'], array('pasta'=>$param['path_root'])));
				if($upload){
					if(0 == $upload->codigo){
						$param['path_file'] = $param['post_file']['name'];
						unset($param['nome_arquivo']);
						unset($param['post_file']);
						$id_ged = $this->modelo->save($param);
						if($id_ged){
							$param['id_ged']     = $id_ged;
							$retorno['codigo']   = 0;
							$retorno['tipo']     = "success";
							$retorno['mensagem'] = 'Upload efetuado com sucesso';
							$retorno['dados']    = $param;
						}else{
							$retorno['codigo']   = 2;
							$retorno['tipo']     = "danger";
							$retorno['mensagem'] = 'Erro ao gravar registro de documento';
							$retorno['dados']    = $param;
						}	
					}else{
						$retorno = $upload;
					}
				}else{
					$retorno['codigo']   = 2;
					$retorno['tipo']     = "danger";
					$retorno['mensagem'] = 'Erro desconhecido ao efetuar upload';
					$retorno['dados']    = $upload;
				}
				throw new Exception(json_encode($retorno), 1);
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}
	}