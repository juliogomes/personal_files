<?php
class GrupoSistema extends Main
{
    protected $grupo_model;
    function __construct($controller)
    {
        $this->grupo_model = $controller->load_model('gruposistema/gruposistema', true);
    }

    function getAgrupamento($parametros)
    {
        $grupos = json_decode($this->grupo_model->getAgrupamento($parametros));
        if ($grupos) {
            $agrupamentos = null;
            foreach ($grupos as $key => $value) {
                $i1 = $value->id_origem;
                $i2 = $value->id_elemento;
                $agrupamentos[$i1][$i2] = $value;
            }
            return $agrupamentos;
        } else {
            return false;
        }
    }

    function getAgrupamentoOrigem($parametros)
    {
        $grupos = json_decode($this->grupo_model->getAgrupamentoOrigem($parametros));
        if ($grupos) {
            $agrupamentos = null;
            foreach ($grupos as $key => $value) {
                $i1 = $value->id_origem;
                $i2 = $value->origem_elemento;
                $agrupamentos[$i1][$i2] = $value;
            }
            return $agrupamentos;
        } else {
            return false;
        }
    }
}
