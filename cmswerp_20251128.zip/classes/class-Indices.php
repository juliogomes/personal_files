<?php
	/**
	* Julio
	* Classe para log de eventos no sistema
	*/
    class Indices Extends Main{
        public
            $nf_model,
            $controller, 
            $indice_model,
            $lp_model,
            $pacote_model,
            $contratos_model,
            $cobranca_model,
            $ano,
            $mes,
            $indice,
            $valor;
        
        function __construct( $controller, $parametros = null ){
            parent::__construct( $controller );
            $this->indice_model    = $this->controller->modelo;
            $this->lp_model        = $this->controller->load_model('lista-precos/lista-precos', true);
            $this->pacote_model    = $this->controller->load_model('pacotes/pacotes', true);
            $this->contratos_model = $this->controller->load_model('contratos/contratos', true);
            $this->cobranca_model  = $this->controller->load_model('cobranca/cobranca', true);
            $this->nf_model        = $this->controller->load_model('notas-fiscais/notas-fiscais', true);
            $this->obj_movimento   = $this->controller->load_model('movimento/movimento', true);
            $db_movimento['db_name'] = DB_NAME_MOVIMENTO;
            $this->obj_movimento->setDb(new Db($db_movimento));
        }

        function setIndice($param){
            $this->ano    = $param['ano'];
            $this->mes    = $param['mes'];
            $this->indice = $param['indice'];
            $this->valor  = $param['valor'];
        }

        function calcReajusteLp($contratos, $reajuste){
            try{
                if(!$reajuste){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $contratos;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Dados de reajuste não informado';
                    throw new Exception(json_encode($retorno), 1); 
                }

                if(!$reajuste){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $reajuste;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Dados de reajuste não informado';
                    throw new Exception(json_encode($retorno), 1); 
                }
                
                $lista_precos = json_decode($this->getListasToReajuste($contratos));
                if($lista_precos->output){
                    $percentual = removeCaracteres($reajuste['percentual'], 'moeda2');
                    foreach ($lista_precos->output as $key => $value){
                        foreach ($value->modulos as $k1 => $v1){
                            foreach ($v1->lista as $k2 => $v2){
                                $v2->valor_atual      = $v2->valor_real;
                                $v2->percentual       = $percentual;
                                $v2->valor_reajuste   = (($v2->valor_real / 100) * $percentual) ;
                                $v2->valor_atualizado = ($v2->valor_atual + $v2->valor_reajuste) ;
                            }
                        }
                    }

                    $retorno['codigo']   = 0;
                    $retorno['input']    = $contratos;
                    $retorno['output']   = $lista_precos->output;
                    $retorno['mensagem'] = 'Sucesso';
                    throw new Exception(json_encode($retorno), 1); 
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $contratos;
                    $retorno['output']   = $lista_precos->output;
                    $retorno['mensagem'] = 'Nenhum lista de preço encontrada';
                    throw new Exception(json_encode($retorno), 1); 
                }
            }catch (Exception $e){
                return $e->getMessage();
            }  
        }

        function calcReajustePct($contratos, $reajuste){
            try{
                if(!$reajuste){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $contratos;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Dados de reajuste não informado';
                    throw new Exception(json_encode($retorno), 1); 
                }

                if(!$reajuste){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $reajuste;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Dados de reajuste não informado';
                    throw new Exception(json_encode($retorno), 1); 
                }
                
                $pacotes = json_decode($this->getPacotesToReajuste($contratos));
                
                if($pacotes->output){
                    $percentual = removeCaracteres($reajuste['percentual'], 'moeda2');
                    foreach ($pacotes->output as $key => $value){
                        foreach ($value->modulos as $k1 => $v1){
                            foreach ($v1->lista as $k2 => $v2){
                                $v2->valor_atual      = $v2->preco_pkt;
                                $v2->percentual       = $percentual;
                                $v2->valor_reajuste   = (($v2->preco_pkt / 100) * $percentual) ;
                                $v2->valor_atualizado = ($v2->valor_atual + $v2->valor_reajuste) ;
                            }
                        }
                    }
                    $retorno['codigo']   = 0;
                    $retorno['input']    = $contratos;
                    $retorno['output']   = $pacotes->output;
                    $retorno['mensagem'] = 'Sucesso';
                    throw new Exception(json_encode($retorno), 1); 
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $contratos;
                    $retorno['output']   = $lista_precos->output;
                    $retorno['mensagem'] = 'Nenhum lista de preço encontrada';
                    throw new Exception(json_encode($retorno), 1); 
                }
            }catch (Exception $e){
                return $e->getMessage();
            } 
        }

        function getListasToReajuste($contratos){
            try{
                $lps = json_decode($this->lp_model->getLpByCustomer($contratos));
                if($lps){
                    $lista_contrato = null;
                    foreach ($lps as $key => $value){
                        if($value->data_reajuste){
                            $data_assinatura = getDataAtual($value->data_reajuste);
                        }elseif($value->data_assinatura){
                            $data_assinatura = getDataAtual($value->data_assinatura);
                        }else{
                            $data_assinatura = getDataAtual();
                        }
                        
                        $diff = $data_assinatura->diff($this->controller->data_hora_atual);
                        $i1   = $value->id_contrato;
                        $i2   = $value->id_modulo;

                        if($diff->y > 0){
                            $lista_contrato[$i1]['reajustavel']  = 1;
                        }else{
                            $lista_contrato[$i1]['reajustavel']  = 0;
                        }

                        $lista_contrato[$i1]['id_contrato']      = $value->id_contrato;
                        $lista_contrato[$i1]['duracao_contrato'] = $diff->y;
                        $lista_contrato[$i1]['id_produto']       = $value->id_produto;
                        $lista_contrato[$i1]['nome_produto']     = $value->nome_produto;
                        $lista_contrato[$i1]['data_assinatura']  = $value->data_assinatura;
                        $lista_contrato[$i1]['data_reajuste']    = $value->data_reajuste;
                        $lista_contrato[$i1]['status_contrato']  = $value->status_contrato;
                        $lista_contrato[$i1]['cliente']          = $value->razao_social;
                        $lista_contrato[$i1]['produto']          = $value->nome_produto;
                        $lista_contrato[$i1]['modulos'][$i2]['nome']    = $value->nome_modulo;
                        $lista_contrato[$i1]['modulos'][$i2]['lista'][] = $value;
                    }
                    
                    $retorno['codigo']   = 0;
                    $retorno['input']    = $contratos;
                    $retorno['output']   = $lista_contrato;
                    $retorno['mensagem'] = 'Sucesso';
                    throw new Exception(json_encode($retorno), 1);

                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $contratos;
                    $retorno['output']   = $lps;
                    $retorno['mensagem'] = 'Nenhum lista de preço encontrada';
                    throw new Exception(json_encode($retorno), 1); 
                }
            }catch (Exception $e){
                return $e->getMessage();
            }  
        }

        function getPacotesToReajuste($contratos){
            try{
                $pacotes = json_decode($this->lp_model->getPacotesByContratos($contratos));
                if($pacotes){
                    foreach ($pacotes as $key => $value){
                        if($value->data_reajuste){
                            $data_assinatura = getDataAtual($value->data_reajuste);
                        }elseif($value->data_assinatura){
                            $data_assinatura = getDataAtual($value->data_assinatura);
                        }else{
                            $data_assinatura = getDataAtual();
                        }
                        $diff = $data_assinatura->diff($this->controller->data_hora_atual);
                        $i1 = $value->id_contrato;
                        $i2 = $value->id_modulos_tarifaveis;
                        if($diff->y > 0){
                            $lista_contrato[$i1]['reajustavel']  = 1;
                        }else{
                            $lista_contrato[$i1]['reajustavel']  = 0;
                        }
                        $lista_contrato[$i1]['id_contrato']      = $value->id_contrato;
                        $lista_contrato[$i1]['duracao_contrato'] = $diff->y;
                        $lista_contrato[$i1]['nome_produto']     = $value->nome_produto;
                        $lista_contrato[$i1]['data_assinatura']  = $value->data_assinatura;
                        $lista_contrato[$i1]['data_reajuste']    = $value->data_reajuste;
                        $lista_contrato[$i1]['status_contrato']  = $value->status_contrato;
                        $lista_contrato[$i1]['id_produto']     = $value->id_produto;
                        $lista_contrato[$i1]['cliente']        = $value->razao_social;
                        $lista_contrato[$i1]['produto']        = $value->nome_produto;
                        $lista_contrato[$i1]['modulos'][$i2]['nome']    = $value->nome_modulo;
                        $lista_contrato[$i1]['modulos'][$i2]['lista'][] = $value;
                    }
                    $retorno['codigo']   = 0;
                    $retorno['input']    = $contratos;
                    $retorno['output']   = $lista_contrato;
                    $retorno['mensagem'] = 'Sucesso';
                    throw new Exception(json_encode($retorno), 1); 
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $contratos;
                    $retorno['output']   = $pacotes;
                    $retorno['mensagem'] = 'Nenhum lista de preço encontrada';
                    throw new Exception(json_encode($retorno), 1); 
                }
            }catch (Exception $e){
                return $e->getMessage();
            }  
        }

        function getContatosToReajuste($param){
            try{
                $contratos_list = json_decode($this->contratos_model->getJustContratos(null, $param['indice'], $param['mes']));
                if(!$contratos_list){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = $contratos_list;
                    $retorno['mensagem'] = 'Nenhum contrato para ser reajustado';
                    throw new Exception(json_encode($retorno), 1);
                }
                
                // $chk_existe = json_decode($this->indice_model->getIndicesPorAnoMes($param['ano'], $param['mes'], $param['indice']));
                // if($chk_existe){
                //     $retorno['codigo']   = 1;
                // 	$retorno['input']    = $param;
                // 	$retorno['output']   = $contratos;
                // 	$retorno['mensagem'] = 'Indice já cadastrado!!';
                // 	throw new Exception(json_encode($retorno), 1);
                // }
                
                $data_apuracao = getDataAtual($param['ano'].'-'.$param['mes'].'-01');
                $data_apuracao->modify('last day of this month');
                
                foreach($contratos_list as $key => $value){
                    $dt_reajuste = getDataAtual($value->data_reajuste);
                    $diff        = $dt_reajuste->diff($data_apuracao);
                    
                    $i = $value->id_contrato;
                    
                    $contratos[$i]['id_contrato']     = $value->id_contrato;
                    $contratos[$i]['razao_social']    = $value->razao_social;
                    $contratos[$i]['indice']          = $value->indice_reajuste;
                    $contratos[$i]['produto']         = $value->nome_produto;
                    $contratos[$i]['codigo_produto']  = $value->codigo_produto;
                    $contratos[$i]['data_assinatura'] = $value->data_assinatura;
                    $contratos[$i]['data_reajuste']   = $value->data_reajuste;
                    $contratos[$i]['data_corte_faturamento']   = $value->data_corte_faturamento;
                    $contratos[$i]['indice_reajuste']   = $value->indice_reajuste;
                    if($diff->y > 0){
                        $contratos[$i]['reajustavel'] = 1;
                    }else{
                        $contratos[$i]['reajustavel'] = 0;
                    }
                }

                $retorno['codigo']   = 0;
                $retorno['input']    = $param;
                $retorno['output']   = $contratos;
                $retorno['mensagem'] = 'Sucesso';
                throw new Exception(json_encode($retorno), 1);
            }catch (Exception $e){
                return $e->getMessage();
            }  
        }

        function executarReajustelP($param){
            try{
                if(!isset($param['id_indice']) || count($param['id_indice']) < 1){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Indice não informado CL';
                    throw new Exception(json_encode($retorno), 1);
                }			
                
                if(!isset($param['contratos']) || count($param['contratos']) < 1){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Nenhum contrato informado para reajustar';
                    throw new Exception(json_encode($retorno), 1);
                }

                $chk_reajuste = json_decode($this->controller->modelo->getRecords($param['id_indice']));
            
                if(!$chk_reajuste){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'indice não encontrado CL';
                    throw new Exception(json_encode($retorno), 1); 
                }

                if($chk_reajuste[0]->lp_processado == 0){
                    // marcar reajuste como processado para lista de preços
                    $dados_reajuste['lp_processado'] = 1;     
                    $save_reajuste = json_decode($this->controller->modelo->save($dados_reajuste, $chk_reajuste[0]->id));
                    if($save_reajuste){
                        $dados_reajuste['indice']     = $chk_reajuste[0]->indice;
                        $dados_reajuste['ano']        = $chk_reajuste[0]->ano;
                        $dados_reajuste['mes']        = $chk_reajuste[0]->mes;
                        $dados_reajuste['percentual'] = number_format($chk_reajuste[0]->percentual,'4',',','.');
                        $lps = json_decode($this->calcReajusteLp($param['contratos'], $dados_reajuste));
                        if($lps->codigo == 0){
                            foreach ($lps->output as $key => $value) {
                                $lp_historico['id_contrato'] = $value->id_contrato;
                                $lp_historico['id_produto']  = $value->id_produto;
                                foreach ($value->modulos as $k1 => $v1) {
                                    $lp_historico['id_modulo'] = $k1;
                                    foreach ($v1->lista as $k2 => $v2) {
                                        $lp_historico['id_lp']            = $v2->id;
                                        $lp_historico['tipo_lista']       = 'cliente';
                                        $lp_historico['id_modulo']        = $k1;
                                        $lp_historico['tipo_cobranca']    = $v2->tipo_cobranca;
                                        $lp_historico['qtd_de']           = $v2->qtd_de;
                                        $lp_historico['qtd_ate']          = $v2->qtd_ate;
                                        $lp_historico['idade_de']         = $v2->idade_de;
                                        $lp_historico['idade_ate']        = $v2->idade_ate;
                                        $lp_historico['valor_real']       = $v2->valor_real;
                                        $lp_historico['valor_relativo']   = $v2->valor_relativo;
                                        $lp_historico['valor_reajuste']   = $v2->valor_reajuste;
                                        $lp_historico['valor_antigo']     = $v2->valor_atual;
                                        $lp_historico['valor_atualizado'] = $v2->valor_atualizado;
                                        $lp_historico['qtd_licencas']     = $v2->qtd_licencas;
                                        $lp_historico['ano_reajuste']     = $dados_reajuste['ano'];
                                        $lp_historico['mes_reajuste']     = $dados_reajuste['mes'];
                                        $lp_historico['percentual']       = $v2->percentual;
                                        $lp_historico['indice']           = $dados_reajuste['indice'];
                                        $lp_historico['tipo_atualizacao'] = 'reajuste';
                                        $save_historico = $this->saveLpHistorico($lp_historico);
                                        if($save_historico){
                                            $v2->status_historico = 'ok';
                                            $lp_cliente['valor_real']   = $v2->valor_atualizado;
                                            $lp_cliente['ano_reajuste'] = $dados_reajuste['ano'];
                                            $lp_cliente['mes_reajuste'] = $dados_reajuste['mes'];
                                            $save_lp = json_decode($this->saveLpCliente($lp_cliente, $v2->id));
                                            if($save_lp->codigo == 0){
                                                $v2->status_lp = 'ok';
                                            }else{
                                                $v2->status_lp = 'erro';
                                            }
                                        }else{
                                            $v2->status_historico = 'erro';
                                        }
                                    }
                                }
                            }
                            $retorno['codigo']   = 0;
                            $retorno['input']    = $param;
                            $retorno['output']   = $lps->output;
                            $retorno['mensagem'] = 'Sucesso';
                            throw new Exception(json_encode($retorno), 1);
                        }else{
                            $retorno['codigo']   = 1;
                            $retorno['input']    = $param;
                            $retorno['output']   = $lps->output;
                            $retorno['mensagem'] = 'Nenuma lista encontrada';
                            throw new Exception(json_encode($retorno), 1);
                        }
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $param;
                        $retorno['output']   = $chk_reajuste;
                        $retorno['mensagem'] = 'Erro ao marcar indice como processado - CL';
                        throw new Exception(json_encode($retorno), 1);
                    }
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = $chk_reajuste;
                    $retorno['mensagem'] = 'Indice já processado CL';
                    throw new Exception(json_encode($retorno), 1);
                }
            } catch (Exception $e) {
                return $e->getMessage();
            }
        }

        function executarReajustePct($param){
            try{
                if(!isset($param['id_indice']) || count($param['id_indice']) < 1){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Indice não informado CL';
                    throw new Exception(json_encode($retorno), 1);
                }			
                
                if(!isset($param['contratos']) || count($param['contratos']) < 1){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Nenhum contrato informado para reajustar';
                    throw new Exception(json_encode($retorno), 1);
                }

                $chk_reajuste = json_decode($this->controller->modelo->getRecords($param['id_indice']));
            
                if(!$chk_reajuste){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'indice não encontrado CL';
                    throw new Exception(json_encode($retorno), 1); 
                }

                if($chk_reajuste[0]->pct_processado == 0){
                    // marcar reajuste como processado para lista de preços
                    $dados_reajuste['pct_processado'] = 1;     
                    $save_reajuste = json_decode($this->controller->modelo->save($dados_reajuste, $chk_reajuste[0]->id));
                    if($save_reajuste){
                        $dados_reajuste['indice']     = $chk_reajuste[0]->indice;
                        $dados_reajuste['ano']        = $chk_reajuste[0]->ano;
                        $dados_reajuste['mes']        = $chk_reajuste[0]->mes;
                        $dados_reajuste['percentual'] = number_format($chk_reajuste[0]->percentual,'4',',','.');
                        $pacotes = json_decode($this->calcReajustePct($param['contratos'], $dados_reajuste));
                        if($pacotes->codigo == 0){
                            foreach ($pacotes->output as $key => $value) {
                                $pct_historico['id_contrato'] = $value->id_contrato;
                                foreach ($value->modulos as $k1 => $v1) {
                                    $pct_historico['id_modulos_tarifaveis'] = $k1;
                                    foreach ($v1->lista as $k2 => $v2){
                                        $pct_historico['id_pacote']        = $v2->id;
                                        $pct_historico['tipo_pacote']      = 'cliente';
                                        $pct_historico['qdt_atual']        = $v2->qdt_garantido;
                                        $pct_historico['qdt_atualizada']   = $v2->qdt_garantido;
                                        $pct_historico['preco_atual']      = $v2->preco_pkt;
                                        $pct_historico['preco_atualizado'] = $v2->valor_atualizado;
                                        $pct_historico['percentual']       = $v2->percentual;
                                        $pct_historico['ano_reajuste']     = $chk_reajuste[0]->ano;
                                        $pct_historico['mes_reajuste']     = $chk_reajuste[0]->mes;
                                        $pct_historico['flag']             = $v2->flag;
                                        $pct_historico['tipo_atualizacao'] = 'reajuste';
                                        $save_historico = json_decode($this->savePctHistorico($pct_historico));
                                        if($save_historico->codigo == 0){
                                            $v2->status_historico = 'ok';
                                            $pct_cliente['preco_pkt']       = $v2->valor_atualizado;
                                            $pct_cliente['ultimo_reajuste'] = $chk_reajuste[0]->ano;
                                            $save_pct = json_decode($this->savePctCliente($pct_cliente, $v2->id));
                                            if($save_pct->codigo == 0){
                                                $v2->status_pct = 'ok';
                                            }else{
                                                $v2->status_pct = 'erro';
                                            }
                                        }else{
                                            $v2->status_historico = 'erro';
                                        }
                                    }
                                }
                            }
                            $retorno['codigo']   = 0;
                            $retorno['input']    = $param;
                            $retorno['output']   = $pacotes->output;
                            $retorno['mensagem'] = 'Sucesso';
                            throw new Exception(json_encode($retorno), 1);
                        }else{
                            $retorno['codigo']   = 1;
                            $retorno['input']    = $param;
                            $retorno['output']   = $pacotes->output;
                            $retorno['mensagem'] = 'Nenuma lista encontrada';
                            throw new Exception(json_encode($retorno), 1);
                        }
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $param;
                        $retorno['output']   = $chk_reajuste;
                        $retorno['mensagem'] = 'Erro ao marcar indice como processado - CL';
                        throw new Exception(json_encode($retorno), 1);
                    }
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = $chk_reajuste;
                    $retorno['mensagem'] = 'Indice já processado CL';
                    throw new Exception(json_encode($retorno), 1);
                }
            } catch (Exception $e) {
                return $e->getMessage();
            }
        }

        function checkNotasEmitidas($param){
            try {
                if(!isset($param['indice']) || count($param['indice']) < 1){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Indice reajuste não informados';
                    throw new Exception(json_encode($retorno), 1);
                }

                if(!isset($param['ano']) || count($param['ano']) < 1){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Ano reajuste não informados';
                    throw new Exception(json_encode($retorno), 1);
                }

                if(!isset($param['mes']) || count($param['mes']) < 1){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Mes reajuste não informados';
                    throw new Exception(json_encode($retorno), 1);
                }

                if(!isset($param['percentual']) || count($param['percentual']) < 1){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Percentual reajuste não informados';
                    throw new Exception(json_encode($retorno), 1);
                }
                $contratos = json_decode($this->getContatosToReajuste($param));
                $notas = null;
                if($contratos->codigo == 0){
                    foreach ($contratos->output as $key => $value){
                        $data_reajuste = getDataAtual($value->data_reajuste);
                        $diff = $data_reajuste->diff($this->controller->data_hora_atual);
                        if($diff->y > 0){
                            $mes_reajuste_cliente = $data_reajuste->format('m');
                            if($param['ano'] < $this->controller->data_hora_atual->format('Y')){
                                $data_de = clone $this->controller->data_hora_atual;
                                $data_de->modify('-1 year');
                                $de = $data_de->format('Y').'-'.$data_reajuste->format('m-d');
                            }else{
                                $de = $this->controller->data_hora_atual->format('Y').'-'.$data_reajuste->format('m-d');
                            }
                            $ate  = $this->controller->data_hora_atual->format('Y-m-d');
                            $nfs  = json_decode($this->nf_model->getNotasComMD($de, $ate, $value->id_contrato));
                            if($nfs){
                                foreach ($nfs as $k1 => $v1){
                                    $valor_calculado            = (($v1->valor_liquido / 100) * $param['percentual']);
                                    $v1->data_corte_faturamento = $value->data_corte_faturamento;
                                    $v1->data_assinatura        = $value->data_assinatura;
                                    $v1->data_reajuste          = $value->data_reajuste;
                                    $v1->indice_reajuste        = $value->indice_reajuste;
                                    $v1->valor_calculado        = $valor_calculado;
                                    $v1->id_nf_origem           = $v1->id_nf_origem; 
                                    $v1->descricao              = "Cobranca de reajuste Integral ref. NF fatura nr. $v1->numero_fatura venc. em ".convertDate($v1->data_vencimento);
                                    $notas[$v1->id] = $v1;
                                }
                            }
                        }
                    }
                
                    if($notas){
                        $retorno['codigo']   = 0;
                        $retorno['input']    = $_POST;
                        $retorno['output']   = $notas;
                        $retorno['mensagem'] = 'Sucesso';
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $_POST;
                        $retorno['output']   = $notas;
                        $retorno['mensagem'] = 'Notas fiscais para lançamento não encontrada';
                    }
                    throw new Exception(json_encode($retorno), 1);
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $_POST;
                    $retorno['output']   = $contratos;
                    $retorno['mensagem'] = $contratos->mensagem;
                    throw new Exception(json_encode($retorno), 1);
                }
            }catch (Exception $e) {
                return $e->getMessage();
            }
        }

        function saveLpHistorico($param, $id = null){
            try {
                if($param){
                    $this->lp_model->setTable('lp_historico');
                    $is_save = $this->lp_model->save($param);
                    $this->lp_model->setTable('lp_clientes');
                    if($is_save){
                        $retorno['codigo']   = 0;
                        $retorno['input']    = $param;
                        $retorno['output']   = null;
                        $retorno['mensagem'] = 'Sucesso';
                        throw new Exception(json_encode($retorno), 1);     
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $param;
                        $retorno['output']   = null;
                        $retorno['mensagem'] = 'Erro ao gravar informações da faixa no historico';
                        throw new Exception(json_encode($retorno), 1); 
                    }
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Faixa não informada no historico';
                    throw new Exception(json_encode($retorno), 1); 
                }
            } catch (Exception $e) {
                return $e->getMessage();
            }
        }

        function savePctHistorico($param, $id = null){
            try {
                if($param){
                    $this->lp_model->setTable('pacote_historico');
                    $is_save = $this->lp_model->save($param);
                    $this->lp_model->setTable('lp_clientes');
                    if($is_save){
                        $retorno['codigo']   = 0;
                        $retorno['input']    = $param;
                        $retorno['output']   = null;
                        $retorno['mensagem'] = 'Sucesso';
                        throw new Exception(json_encode($retorno), 1);     
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $param;
                        $retorno['output']   = null;
                        $retorno['mensagem'] = 'Erro ao gravar informações do historico';
                        throw new Exception(json_encode($retorno), 1); 
                    }
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'pacote não informado no historico';
                    throw new Exception(json_encode($retorno), 1); 
                }
            } catch (Exception $e) {
                return $e->getMessage();
            }
        }

        function saveLpCliente($param, $id = null){
            try {
                if($param){
                    $is_save = $this->lp_model->save($param, $id);
                    if($is_save){
                        $retorno['codigo']   = 0;
                        $retorno['input']    = $param;
                        $retorno['output']   = $is_save;
                        $retorno['mensagem'] = 'Sucesso';
                        throw new Exception(json_encode($retorno), 1);     
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $param;
                        $retorno['output']   = $is_save;
                        $retorno['mensagem'] = 'Erro ao gravar informações da faixa';
                        throw new Exception(json_encode($retorno), 1); 
                    }
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Faixa não informada';
                    throw new Exception(json_encode($retorno), 1); 
                }
            } catch (Exception $e) {
                return $e->getMessage();
            }
        }
        
        function savePctCliente($param, $id = null){
            try {
                if($param){
                    $this->lp_model->setTable('pacote_contratado');
                    $is_save = $this->lp_model->save($param, $id);
                    $this->lp_model->setTable('lp_clientes');
                    if($is_save){
                        $retorno['codigo']   = 0;
                        $retorno['input']    = $param;
                        $retorno['output']   = $is_save;
                        $retorno['mensagem'] = 'Sucesso';
                        throw new Exception(json_encode($retorno), 1);     
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $param;
                        $retorno['output']   = $is_save;
                        $retorno['mensagem'] = 'Erro ao gravar informações do pacote';
                        throw new Exception(json_encode($retorno), 1); 
                    }
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Pacote não informado';
                    throw new Exception(json_encode($retorno), 1); 
                }
            } catch (Exception $e) {
                return $e->getMessage();
            }
        }

        function saveReajuste($param){
            try {
                $chk_existe = json_decode($this->indice_model->getIndicesPorAnoMes($param['ano'], $param['mes'], $param['indice']));
                if($chk_existe){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = $chk_existe;
                    $retorno['mensagem'] = 'Indice já cadastrado';
                }else{
                    
                    $param['criado_em']  = $this->controller->data_hora_atual->format('Y-m-d');
                    $param['percentual'] = removeCaracteres($param['percentual'], 'moeda2');
                    
                    $is_save = $this->controller->modelo->save($param);

                    if($is_save){
                        $retorno['codigo']   = 0;
                        $retorno['input']    = $param;
                        $retorno['output']   = $is_save;
                        $retorno['mensagem'] = 'Indice cadastrado com sucesso';
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $param;
                        $retorno['output']   = $is_save;
                        $retorno['mensagem'] = 'Indice já cadastrado';
                    }
                }
                throw new Exception(json_encode($retorno), 1);
            }catch (Exception $e){
                return $e->getMessage();
            }
        }

        function saveMovAux($numeros_nf, $dados_indice){
            try{
                if(!isset($numeros_nf) || count($numeros_nf) < 1){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Nenhuma nota fisca informada';
                    throw new Exception(json_encode($retorno), 1);
                }
                
                if(!isset($dados_indice) || count($dados_indice) < 1){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $param;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Indice reajuste não informados';
                    throw new Exception(json_encode($retorno), 1);
                }

                foreach ($numeros_nf as $key => $value) {
                    $dados_nota = json_decode($this->nf_model->getNota($value));
                    if($dados_nota){
                        $percentual               = $dados_indice[0]->percentual;
                        $valor_calculado          = (($dados_nota[0]->valor_liquido / 100) * $percentual);
                        $pmtr['codigo_cliente']  = $dados_nota[0]->codigo_cliente;
                        $pmtr['login']           = 'nao_informado';
                        $pmtr['valor']           = $valor_calculado;
                        $pmtr['data_operacao']   = $this->controller->data_hora_atual->format('Y-m-d');
                        $pmtr['tarifavel']       = 0;
                        $pmtr['id_contrato']     = $dados_nota[0]->id_contrato;
                        $pmtr['codigo_produto']  = 'ADM0001';
                        $pmtr['codigo_modulo']   = 'ADM0010';
                        $pmtr['qtd_transacoes']  = 1;
                        $pmtr['data_tarifacao']  = $this->controller->data_hora_atual->format('Y-m-d');
                        $save_mov = $this->obj_movimento->save($pmtr);
                        if($save_mov){
                            $pmaux['id_contrato']     = $dados_nota[0]->id_contrato;
                            $pmaux['id_mov_diario']   = $save_mov;
                            $pmaux['codigo_produto']  = 'ADM0001';
                            $pmaux['codigo_modulo']   = 'ADM0010';
                            $pmaux['id_produto']      = '20';
                            $pmaux['id_modulo']       = '89';
                            $pmaux['id_nf_origem']    = $dados_nota[0]->id;
                            $pmaux['origem']          = 'reajuste';
                            $pmaux['tipo']            = 'diferenca';
                            $pmaux['descricao']       = "Cobranca de reajuste Integral ref. NF fatura nr. ".$dados_nota[0]->numero_fatura." emitida. em ".convertDate($dados_nota[0]->data_emissao);
                            $pmaux['qtd_transacoes']  = 1;
                            $pmaux['valor_base']      = $dados_nota[0]->valor_liquido;
                            $pmaux['valor_calculado'] = $valor_calculado;
                            $pmaux['data_tarifacao']  = $this->controller->data_hora_atual->format('Y-m-d');
                            $pmaux['vencimento_em']   = $dados_nota[0]->data_vencimento;
                            $pmaux['status']          = 'pendente';
                            $save_mov_aux = $this->nf_model->insertMovAux($pmaux);
                            if(!$save_mov_aux){
                                $retorno['codigo']   = 1;
                                $retorno['input']    = $pmaux;
                                $retorno['output']   = $save_mov_aux;
                                $retorno['mensagem'] = 'Erro ao salvar lancamento na mov diario aux';
                                throw new Exception(json_encode($retorno), 1); 
                            }
                        }else{
                            $retorno['codigo']   = 1;
                            $retorno['input']    = $pmtr;
                            $retorno['output']   = $this->obj_movimento;
                            $retorno['mensagem'] = 'Erro ao salvar lancamento na tabela tarifacoes';
                            throw new Exception(json_encode($retorno), 1);
                        }  
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $value;
                        $retorno['output']   = $dados_nota;
                        $retorno['mensagem'] = 'Nota informada não encontrada';
                        throw new Exception(json_encode($retorno), 1);
                    }
                }
                $retorno['codigo']   = 0;
                $retorno['input']    = $numeros_nf;
                $retorno['output']   = $save_mov_aux;
                $retorno['mensagem'] = 'Sucesso';
                throw new Exception(json_encode($retorno), 1);
            }catch (Exception $e) {
                return $e->getMessage();
            }
        }

        function listarContratosReversao( $id_reajuste, $contratos = null ){
            $array_lp = null;
            if( isset( $id_reajuste ) && is_numeric( $id_reajuste ) ){
				$dados_pacote = json_decode( $this->controller->modelo->getContratosReajustePacoteByIndice( $id_reajuste, $contratos ) );
				if( $dados_pacote ){
                    foreach ( $dados_pacote as $key => $value ){
                        $i1 = $value->id_contrato;
                        $array_lp[$i1]['id_indice']     = $value->id_indice;
                        $array_lp[$i1]['indice']        = $value->indice;
                        $array_lp[$i1]['ano_reajuste'] = $value->ano_reajuste;
                        $array_lp[$i1]['mes_reajuste'] = $value->mes_reajuste;
                        $array_lp[$i1]['id_contrato']   = $value->id_contrato;
                        $array_lp[$i1]['cliente']       = $value->razao_social;
                        $array_lp[$i1]['produto']       = $value->nome_produto;
                        $array_lp[$i1]['percentual']    = $value->percentual;
                        $array_lp[$i1]['status']        = $value->status;
                    }
				}

                $dados_lista = json_decode( $this->controller->modelo->getContratosReajusteListaByIndice( $id_reajuste, $contratos ) );
				if( $dados_lista ){
                    foreach ( $dados_lista as $key => $value ){
                        $i1 = $value->id_contrato;
                        $array_lp[$i1]['id_indice']     = $value->id_indice;
                        $array_lp[$i1]['indice']        = $value->indice;
                        $array_lp[$i1]['ano_reajuste'] = $value->ano_reajuste;
                        $array_lp[$i1]['mes_reajuste'] = $value->mes_reajuste;
                        $array_lp[$i1]['id_contrato']   = $value->id_contrato;
                        $array_lp[$i1]['cliente']       = $value->razao_social;
                        $array_lp[$i1]['produto']       = $value->nome_produto;
                        $array_lp[$i1]['percentual']    = $value->percentual;
                        $array_lp[$i1]['status']        = $value->status;
                    }
				}
			}
            return $array_lp;
        }

        function checarReversao( $id_reajuste, $contratos = null ){
            if( isset( $id_reajuste ) && is_numeric( $id_reajuste ) ){
                $lista_contratos = $this->listarContratosReversao( $id_reajuste, $contratos );
                if( $lista_contratos ){
                    foreach( $lista_contratos as $key => $value){
                        $ids_contratos[] = $value['id_contrato'];
                    }
                    $pacotes = json_decode( $this->lp_model->getPacoteHistoricoByAnoMes( $ano_reajuste, $mes_reajuste, $indice, $ids_contratos ) );
                    
                    if( $pacotes ){
                        foreach ( $pacotes as $key => $value ){
                            if( $value->id_pacote && $value->id_contrato ){
                                $data_alteracao = getDateTime( $value->alterado_em );
                                $p1 = $value->id_contrato;
                                $p2 = $value->id_pacote;
                                $p3 = $data_alteracao->format('YmdHi');
                                $array_lp[$p1]['razao_social']                  = $value->razao_social;
                                $array_lp[$p1]['produto']                       = $value->produto;
                                $array_lp[$p1]['pacote'][$p2]['modulo']         = $value->modulo;
                                $array_lp[$p1]['pacote'][$p2]['tipo']           = 'pacote';
                                $array_lp[$p1]['pacote'][$p2]['codigo_modulo']  = $value->codigo_modulo;
                                $array_lp[$p1]['pacote'][$p2]['historico'][$p3] = $value;
                                if( $value->tipo_atualizacao == 'reversao' ){
                                    $array_lp[$p1]['pacote'][$p2]['revertido'] = true;
                                }
                                ksort( $array_lp[$p1]['pacote'][$p2]['historico'] );
                                $array_lp[$p1]['pacote'][$p2]['recente'] = end( $array_lp[$p1]['pacote'][$p2]['historico'] );
                            }
                        }
                    }

                    $lista_preco  = json_decode( $this->lp_model->getLpHistoricoByAnoMes( $ano_reajuste, $mes_reajuste, $indice, $ids_contratos ) );
                    if( $lista_preco ){
                        foreach ( $lista_preco as $key => $value ){
                            $data_alteracao = getDateTime( $value->alterado_em );
                            $i1 = $value->id_contrato;
                            $i2 = $value->id_lp;
                            $i3 = $data_alteracao->format('YmdHi');
                            $array_lp[$i1]['razao_social']                 = $value->razao_social;
                            $array_lp[$i1]['produto']                      = $value->nome_produto;
                            $array_lp[$i1]['lista'][$i2]['modulo']         = $value->nome_modulo;
                            $array_lp[$i1]['lista'][$i2]['tipo']           = 'lista';
                            $array_lp[$i1]['lista'][$i2]['codigo_modulo']  = $value->codigo_modulo;
                            $array_lp[$i1]['lista'][$i2]['historico'][$i3] = $value;
                            if( $value->tipo_atualizacao == 'reversao' ){
                                $array_lp[$i1]['lista'][$i2]['revertido'] = true;
                            }
                            ksort( $array_lp[$i1]['lista'][$i2]['historico'] );
                            $array_lp[$i1]['lista'][$i2]['recente'] = end( $array_lp[$i1]['lista'][$i2]['historico'] );
                        }
                    }
                }
				
                if( isset( $array_lp ) && !empty( $array_lp ) ){
                    ksort( $array_lp );
                }
			}
            return $array_lp;
        }

        function ReverterLista( $ids ){
            try {
                if( $ids ){
                    $lps = null;
                    foreach ($ids as $key => $value) {
                        if( !empty( $value ) && is_numeric( $value ) ){
                            $lps[] = $value;
                        }
                    }
                    
                    if( $lps ){
                        $historico = json_decode( $this->lp_model->getLpHistoricoClienteById( $lps ) );
                        if( $historico ){
                            $count_lista = 0;
                            foreach ( $historico as $key => $value ) {
                                $revert['id_contrato']    = $value->id_contrato;
                                $revert['tipo_cobranca']  = $value->tipo_cobranca;
                                $revert['modalidade']     = null;
                                $revert['qtd_de']         = $value->qtd_de;
                                $revert['qtd_ate']        = $value->qtd_ate;
                                $revert['idade_de']       = $value->idade_de;
                                $revert['idade_ate']      = $value->idade_ate;
                                $revert['valor_real']     = $value->valor_antigo;
                                $revert['valor_de']       = $value->valor_de;
                                $revert['valor_ate']      = $value->valor_ate;
                                $revert['valor_relativo'] = $value->valor_relativo;
                                $revert['percentual']     = $value->percentual;
                                $revert['valor_total']    = $value->valor_total;
                                $revert['qtd_licencas']   = $value->qtd_licencas;
                                $revert['id_modulo']      = $value->id_modulo;
                                $revert['id_produto']     = $value->id_produto;
                                $revert['status']         = 'ativo';
                                $revert['ano_reajuste']   = $value->ano_reajuste;
                                $revert['mes_reajuste']   = $value->mes_reajuste;
                                $revert['alterado_em']    = $this->data_atual->format('Y-m-d H:i:s');
                                $revert['alterado_por']   = $_SESSION['cmswerp']['userdata']->id;
                                $revert['deleted']        = 0;
                                $this->lp_model->setTable('lp_clientes');
                                $is_update                = $this->lp_model->save( $revert, $value->id_lp );
                                if( $is_update ){
                                    $count_lista++;
                                    $lp_historico = null;
                                    $lp_historico['tipo_lista']       = $value->tipo_lista;
                                    $lp_historico['id_lp']            = $value->id_lp;
                                    $lp_historico['id_contrato']      = $value->id_contrato;
                                    $lp_historico['indice']           = $value->indice;
                                    $lp_historico['id_produto']       = $value->id_produto;
                                    $lp_historico['id_modulo']        = $value->id_modulo;
                                    $lp_historico['tipo_cobranca']    = $value->tipo_cobranca;
                                    $lp_historico['qtd_de']           = $value->qtd_de;
                                    $lp_historico['qtd_ate']          = $value->qtd_ate;
                                    $lp_historico['valor_real']       = $value->valor_antigo;
                                    $lp_historico['idade_de']         = $value->idade_de;
                                    $lp_historico['idade_ate']        = $value->idade_ate;
                                    $lp_historico['valor_relativo']   = $value->valor_relativo;
                                    $lp_historico['percentual']       = $value->percentual;
                                    $lp_historico['valor_antigo']     = $value->valor_atualizado;
                                    $lp_historico['valor_reajuste']   = $value->valor_reajuste;
                                    $lp_historico['valor_atualizado'] = $value->valor_antigo;
                                    $lp_historico['qtd_licencas']     = $value->qtd_licencas;
                                    $lp_historico['ano_reajuste']     = $value->ano_reajuste;
                                    $lp_historico['mes_reajuste']     = $value->mes_reajuste;
                                    $lp_historico['tipo_atualizacao'] = 'reversao';
                                    $lp_historico['deleted']          = 0;
                                    $lp_historico['alterado_em']      = $this->data_atual->format('Y-m-d H:i:s');
                                    $lp_historico['alterado_por']     = $_SESSION['cmswerp']['userdata']->id;
                                    $this->lp_model->setTable('lp_historico');
                                    $save_historico = $this->lp_model->save( $lp_historico );
                                    if( !$save_historico ){
                                        $retorno['codigo'] 	 = 1;
                                        $retorno['mensagem'] = 'Erro ao atualizar a o historico da lista ID: '.$value->id_lp;
                                        throw new Exception( json_encode( $retorno ), 1);
                                    }
                                }else{
                                    $retorno['codigo'] 	 = 1;
                                    $retorno['mensagem'] = 'Erro ao atualizar a lista ID: '.$value->id_lp;
                                    throw new Exception( json_encode( $retorno ), 1);
                                }
                            }
                            $retorno['codigo'] 	 = 0;
                            $retorno['mensagem'] = $count_lista.' listas alterados';
                            throw new Exception( json_encode( $retorno ), 1);
                        }else{
                            $retorno['codigo'] 	 = 1;
                            $retorno['mensagem'] = 'Nenhum historico encontrado';
                            throw new Exception( json_encode( $retorno ), 1);
                        }
                    }
                }else{
                    $retorno['codigo'] 	 = 1;
					$retorno['mensagem'] = 'Selecione a os itens a serem revertidos';
					throw new Exception( json_encode( $retorno ), 1); 
                }
            } catch ( Exception $e ) {
                return $e->getMessage();
            }
        }

        function ReverterPacote( $ids ){
            try {
                if( $ids ){
                    $pacotes = null;
                    foreach ($ids as $key => $value) {
                        if( !empty( $value ) && is_numeric( $value ) ){
                            $pacotes[] = $value;
                        }
                    }
				    
                    if( $pacotes ){
                        $historico = json_decode( $this->lp_model->getPacoteHistoricoClienteById( $pacotes ) );
                        if( $historico ){
                            $count_pacote = 0;
                            foreach ( $historico as $key => $value ) {
                                $count_pacote++;
                                $revert['id_contrato']           = $value->id_contrato;
                                $revert['id_modulos_tarifaveis'] = $value->id_modulos_tarifaveis;
                                $revert['qdt_garantido']         = $value->qdt_atual;
                                $revert['valor_garantido']       = $value->valor_garantido;
                                $revert['preco_pkt']             = $value->preco_atual;
                                $revert['percentual']            = $value->percentual ;
                                $revert['frenquencia']           = $value->frenquencia;
                                $revert['ultimo_reajuste']       = $value->ano_reajuste;
                                $revert['status']                = 'ativo';
                                $revert['flag']                  = $value->flag;
                                $revert['deleted']               = 0;
                                $revert['alterado_em']    = $this->data_atual->format('Y-m-d H:i:s');
                                $revert['alterado_por']   = $_SESSION['cmswerp']['userdata']->id;
                                $this->pacote_model->setTable('pacote_contratado');
                                $is_update                      = $this->pacote_model->save( $revert, $value->id_pacote );
                                if( $is_update ){
                                    $count_pacote++;
                                    $pacote_historico = null;
                                    $pacote_historico['tipo_pacote']            = $value->tipo_pacote;
                                    $pacote_historico['id_pacote']              = $value->id_pacote;
                                    $pacote_historico['id_contrato']            = $value->id_contrato;
                                    $pacote_historico['id_modulos_tarifaveis']  = $value->id_modulos_tarifaveis;
                                    $pacote_historico['qdt_atual']              = $value->qdt_atualizada;
                                    $pacote_historico['qdt_atualizada']         = $value->qdt_atual;
                                    $pacote_historico['preco_atual']            = $value->preco_atualizado;
                                    $pacote_historico['preco_atualizado']       = $value->preco_atual;
                                    $pacote_historico['percentual']             = $value->percentual;
                                    $pacote_historico['ano_reajuste']           = $value->ano_reajuste;
                                    $pacote_historico['mes_reajuste']           = $value->mes_reajuste;
                                    $pacote_historico['flag']                   = $value->flag;
                                    $pacote_historico['tipo_atualizacao']       = 'reversao';
                                    $pacote_historico['deleted']                = 0;
                                    $pacote_historico['alterado_em']            = $this->data_atual->format('Y-m-d H:i:s');
                                    $pacote_historico['alterado_por']           = $_SESSION['cmswerp']['userdata']->id;
                                    $this->pacote_model->setTable('pacote_historico');
                                    $save_historico = $this->pacote_model->save( $pacote_historico );
                                    if( !$save_historico ){
                                        $retorno['codigo'] 	 = 1;
                                        $retorno['mensagem'] = 'Erro ao atualizar a o historico da pacote ID: '.$value->id_lp;
                                        throw new Exception( json_encode( $retorno ), 1);
                                    }
                                }else{
                                    $retorno['codigo'] 	 = 1;
                                    $retorno['mensagem'] = 'Erro ao atualizar a pacote ID: '.$value->id_lp;
                                    throw new Exception( json_encode( $retorno ), 1);
                                }
                            }
                            $retorno['codigo'] 	 = 0;
                            $retorno['mensagem'] = $count_pacote.' pacotes alterados';
                            throw new Exception( json_encode( $retorno ), 1);
                        }else{
                            $retorno['codigo'] 	 = 1;
                            $retorno['mensagem'] = 'Nenhum historico encontrado';
                            throw new Exception( json_encode( $retorno ), 1);
                        }
                    }
                }else{
                    $retorno['codigo'] 	 = 1;
					$retorno['mensagem'] = 'Selecione a os itens a serem revertidos';
					throw new Exception( json_encode( $retorno ), 1); 
                }
            } catch ( Exception $e ) {
                return $e->getMessage();
            }
        }

        function checkHistoricoPacoteContratoIndice(){
            $dados_pacote = json_decode( $this->controller->modelo->getHistoricoPacoteContratoIndice() );
            if( $dados_pacote ){
                $this->controller->modelo->setTable('pacote_historico');
                foreach ( $dados_pacote as $key => $value ) {
                    $param['indice']        = $value->indice_reajuste;
                    $param['alterado_por']  = $value->alterado_por;
                    $param['alterado_em']   = $value->alterado_em;
                    $is_save = $this->controller->modelo->save( $param, $value->id_historico );
                    if( !$is_save ){
                        echo '<pre>';
                            var_dump( $this->controller->modelo );
                        echo '</pre>';
                        exit;
                    }
                }
                $this->controller->modelo->setTable('indices_reajuste');
            }
        }

        function checkRelacionamentoPacoteHistorico(){
            $dados_pacote = json_decode( $this->controller->modelo->getHistoricoPacoteEIndice() );
            if( $dados_pacote ){
                $this->controller->modelo->setTable('pacote_historico');
                foreach ( $dados_pacote as $key => $value ) {
                    $param['id_indice']     = $value->id_indice;
                    $param['indice']        = $value->indice;
                    $param['flag']          = $value->flag;
                    $param['alterado_por']  = $value->alterado_por;
                    $param['alterado_em']   = $value->alterado_em;
                    $is_save = $this->controller->modelo->save( $param, $value->id_historico );
                    if( !$is_save ){
                        echo '<pre>';
                            var_dump( $this->controller->modelo );
                        echo '</pre>';
                        exit;
                    }
                }
                $this->controller->modelo->setTable('indices_reajuste');
            }
        }

        function checkHistoricoELp(){
            $dados_pacote = json_decode( $this->controller->modelo->getHistoricoELp() );
            if( $dados_pacote ){
                $this->controller->modelo->setTable('lp_historico');
                foreach ( $dados_pacote as $key => $value ) {
                    $param['id_contrato']  = $value->id_contrato;
                    $param['indice']       = $value->indice_reajuste;
                    $param['alterado_por'] = $value->alterado_por;
                    $param['alterado_em']  = $value->alterado_em;
                    $is_save = $this->controller->modelo->save( $param, $value->id_historico );
                    if( !$is_save ){
                        echo '<pre>';
                            var_dump( $this->controller->modelo );
                        echo '</pre>';
                        exit;
                    }
                }
                $this->controller->modelo->setTable('indices_reajuste');
            }
        }

        function checkRelacionamentoListaHistorico(){
            $dados_lista = json_decode( $this->controller->modelo->getHistoricoELista() );
            if( $dados_lista ){
                $this->controller->modelo->setTable('lp_historico');
                foreach ( $dados_lista as $key => $value ) {
                    $param['id_contrato']  = $value->id_contrato;
                    $param['id_produto']   = $value->id_produto;
                    $param['id_modulo']    = $value->id_modulo;
                    $param['id_indice']    = $value->id_indice;
                    $param['indice']       = $value->indice;
                    $param['alterado_por'] = $value->alterado_por;
                    $param['alterado_em']  = $value->alterado_em;
                    $is_save               = $this->controller->modelo->save( $param, $value->id_historico );
                    if( !$is_save ){
                        echo '<pre>';
                            var_dump( $this->controller->modelo );
                        echo '</pre>';
                        exit;
                    }
                }
                $this->controller->modelo->setTable('indices_reajuste');
            }
        }

        function checkRelacionamentosHistoricos(){
            $this->checkHistoricoPacoteContratoIndice();
            $this->checkRelacionamentoPacoteHistorico();
            $this->checkHistoricoELp();
            $this->checkRelacionamentoListaHistorico();
        }
    }