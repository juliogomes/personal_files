<?php

/**
 * Caio Freitas
 * 09/09/2022
 * Classe para instrução de faturamento
 */
class InstrucaoFaturamento extends Main
{
    private
        $id_user_sesssao,
        $table,
        $minuta,
        // $notificacao,
        // $data_hora_atual,
        $aprovacao;
    protected
        $parametros,
        $id_user,
        $model_comissao,
        $usuario_model;

    function __construct($controller, $parametros)
    {
        parent::__construct($controller);
        if (isset($_SESSION['cmswerp']['userdata']->id)) {
            $this->id_user_sesssao = $_SESSION['cmswerp']['userdata']->id;
            $this->id_user         = $_SESSION['cmswerp']['userdata']->id;
        }
        $this->parametros      = $parametros;
        // $this->minuta          = new Minuta( $this->controller );       
        $this->minuta          = new MinutaV2($this->controller);
        $this->notificacao     = new Notificacoes($this);
        $this->data_hora_atual = getDataAtual();
        $this->model_comissao  = $this->controller->load_model('comissao/comissao', true);
        $this->usuario_model   = $this->controller->load_model('usuarios/usuarios', true);
        $this->controller->modelo = $this->controller->load_model('propostas/propostas', true);
    }

    function save($etapa = null, $insert = null)
    {
        try {
            if (isset($this->parametros[1]) && !empty($this->parametros[1])) {
                $id_contrato        = $this->parametros[1];
                $minuta_proposta    = json_decode($this->controller->modelo->getContratoProposta($id_contrato));
                $id_proposta        =  $minuta_proposta[0]->id_proposta;
            } else {
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro parâmetros id_contrato";
                throw new Exception(json_encode($retorno), 1);
            }

            switch ($etapa) {
                case 'contrato':
                    $this->table           = "if_contrato";
                    $proxima_etapa         = 2;
                    $retorno_func          = $this->verificaContrato();
                    $insert['id_proposta'] = $retorno_func['id_proposta'];
                    $id_contrato           =  $retorno_func['id_contrato'];
                    break;
                case 'endereco':
                    $this->table = "if_endereco";
                    $proxima_etapa = 3;
                    $endereco = json_decode($this->controller->modelo->getIfEndereco($id_contrato));
                    if (!isset($endereco) || empty($endereco)) {
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $this->parametros;
                        $retorno['output']   = null;
                        $retorno['mensagem'] = "Adicione ao menos um endereço";
                        throw new Exception(json_encode($retorno), 1);
                    } else {
                        $retorno['codigo']   = 0;
                        $retorno['etapa']    = $proxima_etapa;
                        $retorno['input']    = $endereco;
                        $retorno['output']   = $id_contrato;
                        $retorno['mensagem'] = "Sucesso";
                        throw new Exception(json_encode($retorno), 1);
                    }
                    break;
                case 'contato':
                    $this->table = "if_contato";
                    $proxima_etapa = 4;
                    $retorno_func = $this->verificaContatos($id_contrato);
                    if (isset($retorno_func) && $retorno_func['codigo'] == 0) {
                        $retorno['codigo']   = 0;
                        $retorno['etapa']    = $proxima_etapa;
                        $retorno['input']    = $retorno_func['input'];
                        $retorno['output']   = $id_contrato;
                        $retorno['mensagem'] = $retorno_func['mensagem'];
                        throw new Exception(json_encode($retorno), 1);
                    } else {
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $retorno_func['input'];
                        $retorno['output']   = $id_contrato;
                        $retorno['mensagem'] = $retorno_func['mensagem'];
                        throw new Exception(json_encode($retorno), 1);
                    }
                    break;
                case 'faturamento':
                    $user_fluxo_aprovacao = json_decode($this->controller->modelo->fluxoOrdemAprovacao($this->id_user, 'minuta'));
                    $this->table           = "if_faturamento";
                    $proxima_etapa         = 5;
                    $insert['id_contrato'] = $id_contrato;
                    $faturamento = json_decode($this->controller->modelo->getInstrucaofaturamento($id_contrato));
                    if (isset($faturamento) && !empty($faturamento)) {
                        $id_objeto = $faturamento[0]->id;
                    }
                    break;
                case 'minuta':
                    $this->table   = "minuta_contrato";
                    $proxima_etapa = 6;
                    $contrato        = json_decode($this->controller->modelo->getContratoProposta($id_contrato));
                    $minuta        = json_decode($this->controller->modelo->getTextoMinuta($id_contrato));
                    $id_proposta   =  $minuta_proposta[0]->id_proposta;
                    if (isset($insert['minuta']) && !empty($insert['minuta'])) {
                        $contador_tag = $this->minuta->checkTag($contrato[0]->codigo);
                        if ($contador_tag != false) {
                            $minuta_contrato = $insert['minuta'];
                            unset($insert['minuta']);
                            $verifica_tag = json_decode($this->minuta->verificaTag($contrato[0]->codigo, $minuta_contrato, $contador_tag));
                            if (isset($verifica_tag->codigo) && $verifica_tag->codigo == 1) {
                                $retorno['codigo']   = 1;
                                $retorno['input']    = $verifica_tag->input;
                                $retorno['output']   = $verifica_tag->output;
                                $retorno['mensagem'] = $verifica_tag->mensagem;
                                throw new Exception(json_encode($retorno), 1);
                            }
                        } else {
                            $minuta_contrato = $insert['minuta'];
                            unset($insert['minuta']);
                        }

                        if (isset($minuta[0]->id) && !empty($minuta[0]->id)) {
                            $id_minuta = $minuta[0]->id;
                        } else {
                            $id_minuta = null;
                        }

                        $insert['id_contrato']  = $id_contrato;
                        $insert['pagina']       = 1;
                        $insert['texto']        = $minuta_contrato;
                        $insert['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
                        $insert['alterado_em']  = $this->data_atual->format('Y-m-d H:i:s');
                        $insert['deleted']      = 0;
                        $this->controller->modelo->setTable($this->table);
                        $save_modelo_contrato = $this->controller->modelo->save($insert, $id_minuta);
                        echo '<pre>';
                        var_dump($insert);
                        echo '</pre>';
                        exit;
                        if ($save_modelo_contrato) {
                            $retorno_func = $this->insertGedMinuta($id_contrato, $minuta_proposta[0]->codigo);
                            if (isset($retorno_func) && $retorno_func['codigo'] == 0) {
                                $retorno['codigo']   = 0;
                                $retorno['etapa']    = $proxima_etapa;
                                $retorno['input']    = $insert;
                                $retorno['output']   = $id_contrato;
                                $retorno['mensagem'] = "Sucesso";
                                throw new Exception(json_encode($retorno), 1);
                            } else {
                                $retorno['codigo']   = 1;
                                $retorno['input']    = $retorno_func['input'];
                                $retorno['output']   = $retorno_func['output'];
                                $retorno['mensagem'] = $retorno_func['mensagem'];
                                throw new Exception(json_encode($retorno), 1);
                            }
                        } else {
                            $retorno['codigo']   = 1;
                            $retorno['input']    = $this->parametros;
                            $retorno['output']   = $this->controller->modelo->info;
                            $retorno['mensagem'] = "Erro ao inserir minuta";
                            throw new Exception(json_encode($retorno), 1);
                        }
                    } else {
                        $retorno['codigo']   = 1;
                        $retorno['input']    = null;
                        $retorno['output']   = $this->controller->modelo->info;
                        $retorno['mensagem'] = "Erro POST minuta";
                        throw new Exception(json_encode($retorno), 1);
                    }
                    break;
                case 'preview':
                    $insert['finalizado'] = '1';
                    $if_contrato = json_decode($this->controller->modelo->getIfContrato($id_contrato));
                    if (!isset($if_contrato) || empty($if_contrato)) {
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $this->parametros;
                        $retorno['output']   = $id_contrato;
                        $retorno['mensagem'] = "Erro em obter informações de contrato";
                        throw new Exception(json_encode($retorno), 1);
                    } else {
                        $etapa          = 'preview';
                        $this->table    = "if_contrato";
                        $proxima_etapa  = 'x';
                    }
                    break;
                default:
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $this->parametros;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Etapa do faturamento inexistente";
                    throw new Exception(json_encode($retorno), 1);
                    break;
            }

            if ($etapa == 'contrato' || $etapa == 'faturamento'  || $etapa == 'preview') {
                if (isset($insert) && !empty($insert)) {
                    $this->controller->modelo->setTable($this->table);
                    if (isset($faturamento) && !empty($faturamento) && $etapa == "faturamento") {
                        $save = $this->controller->modelo->save($insert, $faturamento[0]->id);
                    } else {
                        if ($etapa == 'contrato' || $etapa == 'preview') {
                            $save = $this->controller->modelo->save($insert, $id_contrato);
                            $id_contrato = $save;
                        } else {
                            $save = $this->controller->modelo->save($insert);
                        }
                    }

                    if ($save) {
                        if ($etapa == 'faturamento' && strtoupper($user_fluxo_aprovacao[0]->nome_perfil) != "JURIDICO") {
                            //apagar                                                  
                            $retorno_func = $this->insertGedMinuta($id_contrato, $minuta_proposta[0]->codigo);
                            if (isset($retorno_func) && $retorno_func['codigo'] == 0) {
                                $retorno['codigo']   = 0;
                                $retorno['etapa']    = $proxima_etapa;
                                $retorno['input']    = $insert;
                                $retorno['output']  = $id_contrato;
                                $retorno['mensagem'] = "Sucesso";
                                throw new Exception(json_encode($retorno), 1);
                            } else {
                                $retorno['codigo']   = 1;
                                $retorno['input']    = $retorno_func['input'];
                                $retorno['output']   = $retorno_func['output'];
                                $retorno['mensagem'] = $retorno_func['mensagem'];
                                throw new Exception(json_encode($retorno), 1);
                            }
                        } else {
                            $retorno['codigo']   = 0;
                            $retorno['etapa']    = $proxima_etapa;
                            $retorno['input']    = $insert;
                            if ($proxima_etapa == "x") {
                                //ENVIAR NOTIFICAÇÃO                      
                                $parametros['id'] = $id_proposta;
                                $this->notificacao->alertaTeams('minuta_preenchida', $parametros);
                                $retorno['output']   = $id_proposta;
                                $retorno['input']    = $minuta_proposta;
                            } else {
                                $retorno['output'] = $id_contrato;
                            }
                            $retorno['mensagem'] = "Sucesso";
                            throw new Exception(json_encode($retorno), 1);
                        }
                    } else {
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $this->parametros;
                        $retorno['output']   = $this->controller->modelo->info;
                        $retorno['mensagem'] = "Erro ao inserir no banco de dados";
                        throw new Exception(json_encode($retorno), 1);
                    }
                } else {
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $this->parametros;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Insert vazio";
                    throw new Exception(json_encode($retorno), 1);
                }
            }
        } catch (Exception $e) {
            return $retorno;
        }
    }

    function verificaContrato()
    {
        if (isset($this->parametros[1]) && !empty($this->parametros[1])) {
            if ($this->parametros[1] == "id_proposta") {
                $id_proposta = $this->parametros[2];
                $contrato =  json_decode($this->controller->modelo->getIfContrato(null, $id_proposta));
                if (isset($contrato) && !empty($contrato)) {
                    $id_contrato = $contrato[0]->id;
                }
            } else {
                $id_contrato = $this->parametros[1];
                $contrato =  json_decode($this->controller->modelo->getIfContrato($id_contrato));
                $id_proposta = $contrato[0]->id_proposta;
            }
        }
        $retorno['id_contrato'] = $id_contrato;
        $retorno['id_proposta'] = $id_proposta;
        return $retorno;
    }

    function verificaContatos($id_objeto)
    {
        try {
            $contatos = json_decode($this->controller->modelo->getContato(null, $id_objeto));
            if (!isset($contatos) || empty($contatos)) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Adicione ao menos 3 contatos: RESPONSÁVEL LEGAL, TESTEMUNHA E FINANCEIRO";
                throw new Exception(json_encode($retorno), 1);
            } else {
                if (is_array($contatos)) {
                    foreach ($contatos as $key => $value) {
                        if (strtoupper($value->tipo_contato) == "RESPONSAVEL_LEGAL") {
                            $responsavel_legal = true;
                        }
                        if (strtoupper($value->tipo_contato) == "TESTEMUNHA") {
                            $testemunha = true;
                        }
                        if (strtoupper($value->tipo_contato) == "FINANCEIRO") {
                            $financeiro = true;
                        }
                    }
                }

                if (!isset($responsavel_legal) || $responsavel_legal != true) {
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $this->parametros;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Necessário adicionar ao menos um REPRESENTANTE LEGAL";
                    throw new Exception(json_encode($retorno), 1);
                }
                if (!isset($testemunha) || $testemunha != true) {
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $this->parametros;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Necessário adicionar uma TESTEMUNHA";
                    throw new Exception(json_encode($retorno), 1);
                }
                if (!isset($financeiro) || $financeiro != true) {
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $this->parametros;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Necessário adicionar um contato FINANCEIRO";
                    throw new Exception(json_encode($retorno), 1);
                }

                $retorno['codigo']   = 0;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $contatos;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            return $retorno;
        }
    }

    //By: Caio Freitas - 17/08/2022
    function insertGedMinuta($id_objeto, $codigo)
    {
        try {
            $contato_cm = json_decode($this->controller->modelo->getContatoSign("sign_cm", null, null, true));
            if (!isset($contato_cm) || empty($contato_cm)) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $this->controller->modelo->info;
                $retorno['mensagem'] = "Necessario o cadastro de contato ATIVO de RESPONSÁVEL LEGAL e TESTEMUNHA da C&M Software, acesse o menu configurações e cadastre";
                throw new Exception(json_encode($retorno), 1);
            } else {
                foreach ($contato_cm as $key => $value) {
                    if (strtoupper($value->tipo_contato) == "JURIDICO") {
                        $juridico[] = $value;
                    }
                    if (strtoupper($value->tipo_contato) == "TESTEMUNHA") {
                        $testemunha[] = $value;
                    }
                    if (strtoupper($value->tipo_contato) == "RESPONSAVEL_LEGAL") {
                        $responsavel_legal[] = $value;
                    }
                }
                if (!isset($responsavel_legal) || empty($responsavel_legal)) {
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $this->parametros;
                    $retorno['output']   = $this->controller->modelo->info;
                    $retorno['mensagem'] = "Necessario ter (UM) contato de REPRESENTANTE LEGAL da C&M Software cadastrado ATIVO, acesse o menu configurações e cadastre";
                    throw new Exception(json_encode($retorno), 1);
                }
                if (!isset($juridico) || empty($juridico)) {
                    if (!isset($testemunha) || empty($testemunha)) {
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $this->parametros;
                        $retorno['output']   = $this->controller->modelo->info;
                        $retorno['mensagem'] = "Necessario ter (UMA) TESTEMUNHA OU CONTATO JURIDICO da C&M Software cadastrado ATIVO, acesse o menu configurações e cadastre";
                        throw new Exception(json_encode($retorno), 1);
                    }
                }
            }

            $contrato = json_decode($this->controller->modelo->getContratoProposta($id_objeto));
            $ged       = json_decode($this->controller->modelo->gedDocumentoAnexo2($id_objeto, 'minuta'));

            if (isset($ged) && !empty($ged)) {
                $nome_hash = $ged[0]->nome_hash;
            } else {
                $data_hash = date('YmdHms');
                $nome_hash = "minuta_" . $id_objeto . "_" . $data_hash . ".pdf";
            }

            $insert_ged_documento = [
                'nome_documento' => 'minuta_' . $id_objeto . '.pdf',
                'data_documento' => $this->data_hora_atual->format('Y-m-d'),
                'doc_origem'     => 'minuta',
                'id_origem'      => $id_objeto,
                'produto'        => $contrato[0]->id_produto,
                'tipo'              => 'minuta',
                'subtipo'          => 'minuta',
                'owner'          => $contrato[0]->id_owner,
                'data_criacao'      => $this->data_hora_atual->format('H:i:s Y-m-d'),
            ];

            $this->controller->modelo->setTable('ged_documento');
            $save_ged_documento = $this->controller->modelo->save($insert_ged_documento, $ged[0]->id_ged_documento);
            if (!$save_ged_documento) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $this->controller->modelo->info;
                $retorno['mensagem'] = "Erro ged";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $ged_documento = json_decode($this->controller->modelo->gedDocumento2('minuta', $id_objeto));
                if (!isset($ged_documento)) {
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $this->parametros;
                    $retorno['output']   = $this->controller->modelo->info;
                    $retorno['mensagem'] = "Erro ged documento";
                    throw new Exception(json_encode($retorno), 1);
                }

                if (isset($ged) && !empty($ged)) {
                    $hash_arquivo = $ged[0]->nome_hash;
                } else {
                    $path_documento = PATH_MINUTA . $contrato[0]->cnpj . DS . $nome_hash;
                    $hash_arquivo = hash_file('md5', $path_documento);
                }
            }

            $insert_ged_anexo = [
                'id_documento'  => $ged_documento[0]->id,
                'nome_amigavel' => $ged_documento[0]->nome_documento,
                'path_root'     => PATH_MINUTA,
                'path_objeto'   => $contrato[0]->cnpj . DS,
                'nome_hash'     => $nome_hash,
                'hash_arquivo'  => $hash_arquivo,
                'data_criacao'  => $this->data_hora_atual->format('Y-m-d H:i:s'),
            ];

            $this->controller->modelo->setTable('ged_anexo');
            $save_ged_anexo = $this->controller->modelo->save($insert_ged_anexo, $ged[0]->id_ged_anexo);
            if (!$save_ged_anexo) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $this->controller->modelo->info;;
                $retorno['mensagem'] = "Erro save ged documento";
                throw new Exception(json_encode($retorno), 1);
            } else {

                if (!$ged) {
                    $ged[0] = (object)$insert_ged_anexo;
                };

                //apagar
                $obj_pdf = json_decode($this->minuta->gerarPDF($ged, $contrato[0]));
                // $r = $this->minuta->gerarPDF_default($contrato[0]->codigo,$id_objeto, $contrato[0]->id_proposta);

                return;
                if (isset($obj_pdf) && $obj_pdf->codigo == 0) {
                    if ($codigo == "RCK0001") {
                        $pdf_customizacao = $this->insertGedCustomizacao($id_objeto);
                        if ($pdf_customizacao['codigo'] != 0) {
                            $retorno['etapa']     = 'x';
                            $retorno['codigo']   = 1;
                            $retorno['input']    = $pdf_customizacao['input'];
                            $retorno['output']   = $pdf_customizacao['output'];
                            $retorno['mensagem'] = "Erro ao gerar contrato de customização";
                            throw new Exception(json_encode($retorno), 1);
                        } else {
                            $retorno['codigo']   = 0;
                            $retorno['etapa']    = 6;
                            $retorno['input']    = $ged;
                            $retorno['output']   = $id_objeto;
                            $retorno['mensagem'] = "Sucesso";
                            throw new Exception(json_encode($retorno), 1);
                        }
                    } else {
                        $retorno['codigo']   = 0;
                        $retorno['etapa']    = 6;
                        $retorno['input']    = $ged;
                        $retorno['output']   = $id_objeto;
                        $retorno['mensagem'] = "Sucesso";
                        throw new Exception(json_encode($retorno), 1);
                    }
                } else {
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $this->parametros;
                    $retorno['output']   = $this->controller->modelo->info;
                    $retorno['mensagem'] = $obj_pdf->mensagem ? $obj_pdf->mensagem : "Erro ao gerar PDF COD: 484";
                    throw new Exception(json_encode($retorno), 1);
                }
            }
        } catch (Exception $e) {
            return $retorno;
        }
    }

    function insertGedCustomizacao($id_objeto)
    {
        try {
            $ged       = json_decode($this->controller->modelo->gedDocumentoAnexo2($id_objeto, 'customizacao'));
            $contrato = json_decode($this->controller->modelo->getContratoProposta($id_objeto));
            if (isset($contrato) && $contrato[0]->codigo != "RCK0001") {
                $retorno['codigo']   = 0;
                $retorno['etapa']    = 6;
                $retorno['input']    = $ged;
                $retorno['output']   = $id_objeto;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception(json_encode($retorno), 1);
            }

            if (isset($ged) && !empty($ged)) {
                $nome_hash = $ged[0]->nome_hash;
            } else {
                $data_hash = date('YmdHms');
                $nome_hash = "customizacao_" . $id_objeto . "_" . $data_hash . ".pdf";
            }

            $insert_ged_documento = [
                'nome_documento' => 'customizacao_' . $id_objeto . '.pdf',
                'data_documento' => $this->data_hora_atual->format('Y-m-d'),
                'doc_origem'     => 'customizacao',
                'id_origem'      => $id_objeto,
                'produto'        => $contrato[0]->id_produto,
                'tipo'              => 'customizacao',
                'subtipo'          => 'customizacao',
                'owner'          => $contrato[0]->id_owner,
                'data_criacao'      => $this->data_hora_atual->format('H:i:s Y-m-d'),
            ];

            $this->controller->modelo->setTable('ged_documento');
            $save_ged_documento = $this->controller->modelo->save($insert_ged_documento, $ged[0]->id_ged_documento);
            if (!$save_ged_documento) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $this->controller->modelo->info;
                $retorno['mensagem'] = "Erro ged";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $ged_documento = json_decode($this->controller->modelo->gedDocumento2('customizacao', $id_objeto));
                if (!isset($ged_documento)) {
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $this->parametros;
                    $retorno['output']   = $this->controller->modelo->info;
                    $retorno['mensagem'] = "Erro ged documento";
                    throw new Exception(json_encode($retorno), 1);
                }
                if (isset($ged) && !empty($ged)) {
                    $hash_arquivo = $ged[0]->nome_hash;
                } else {
                    $path_documento = PATH_MINUTA . $contrato[0]->cnpj . DS . $nome_hash;
                    $hash_arquivo = hash_file('md5', $path_documento);
                }
            }

            $insert_ged_anexo = [
                'id_documento'  => $ged_documento[0]->id,
                'nome_amigavel' => $ged_documento[0]->nome_documento,
                'path_root'     => PATH_MINUTA,
                'path_objeto'   => $contrato[0]->cnpj . DS,
                'nome_hash'     => $nome_hash,
                'hash_arquivo'  => $hash_arquivo,
                'data_criacao'  => $this->data_hora_atual->format('Y-m-d'),
            ];

            $this->controller->modelo->setTable('ged_anexo');
            $save_ged_anexo = $this->controller->modelo->save($insert_ged_anexo, $ged[0]->id_ged_anexo);
            if (!$save_ged_anexo) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $this->controller->modelo->info;;
                $retorno['mensagem'] = "Erro save ged documento";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $obj_pdf = json_decode($this->minuta->gerarPDF("ADM0001", $id_objeto, $contrato[0]->id_proposta));
                if (isset($obj_pdf) && $obj_pdf->codigo == 0) {
                    $retorno['codigo']   = 0;
                    $retorno['etapa']    = 6;
                    $retorno['input']    = $ged;
                    $retorno['output']   = $contrato[0]->id_proposta;
                    $retorno['mensagem'] = "Sucesso";
                    throw new Exception(json_encode($retorno), 1);
                } else {
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $this->parametros;
                    $retorno['output']   = $this->controller->modelo->info;
                    $retorno['mensagem'] = "Erro ao gerar PDF COD:575";
                    throw new Exception(json_encode($retorno), 1);
                }
            }
        } catch (Exception $e) {
            return $retorno;
        }
    }

    function addContato($id_contrato, $insert)
    {
        $limites = [
            'responsavel_legal' => 3,
            'financeiro' => 2,
            'juridico' => 1,
            'contato_responsavel' => 1,
            'tecnico' => 1,
            'testemunha' => 1,
        ];
        
        try {
            $contatos = json_decode($this->controller->modelo->getContato(null, $id_contrato, $insert['tipo_contato'], "minuta"));
            if (isset($contatos) && count($contatos) >= $limites[$insert['tipo_contato']]) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $_POST;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Permitido apenas " . $limites[$insert['tipo_contato']] . ' ' . str_replace("_", " ", $insert['tipo_contato']);
                throw new Exception(json_encode($retorno), 1);
            }

            $this->controller->modelo->setTable('if_contato');
            $save_contato = $this->controller->modelo->save($insert);
            if ($save_contato) {
                $retorno['codigo']   = 0;
                $retorno['input']    = $save_contato;
                $retorno['output']   = $insert;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo']   = 1;
                $retorno['input']    = $insert;
                $retorno['output']   = $this->controller->modelo->info;
                $retorno['mensagem'] = "Erro ao salvar informação";
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            return $retorno;
        }
    }

    function detalheContato()
    {
        try {
            if (!isset($this->parametros[0]) || empty($this->parametros[0])) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro ao parâmetros";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $id_contato = $this->parametros[0];
            }

            $contato = json_decode($this->controller->modelo->getContato($id_contato, null, null, "minuta"));
            if ($contato[0]->tipo_contato == "responsavel_legal" || $contato[0]->tipo_contato == "nota_fiscal" || $contato[0]->tipo_contato == "testemunha_2") {
                $contato[0]->tipo_contato = str_replace("_", " ", $contato[0]->tipo_contato);
            }

            if ($contato) {
                $retorno['codigo']   = 0;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $contato;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo']   = 1;
                $retorno['input']    = $contato;
                $retorno['output']   = $this->controller->modelo->info;
                $retorno['mensagem'] = "Erro ao obter detalhe de contato";
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            return $retorno;
        }
    }

    function excluirContato()
    {
        try {
            if (!isset($this->parametros[0]) || empty($this->parametros[0])) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro ao parâmetros";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $id_contato = $this->parametros[0];
                $deleted['deleted'] = '1';
            }
            $this->controller->modelo->setTable('if_contato');
            $update = $this->controller->modelo->save($deleted, $id_contato);
            if ($update) {
                $retorno['codigo']   = 0;
                $retorno['input']    = $update;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Sucesso em excluir contato";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo']   = 1;
                $retorno['input']    = $save;
                $retorno['output']   = $this->controller->modelo->info;
                $retorno['mensagem'] = "Erro ao excluir";
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            return $retorno;
        }
    }

    function addEndereco($insert)
    {
        try {
            $this->controller->modelo->setTable('if_endereco');
            $save_endereco = $this->controller->modelo->save($insert);
            if ($save_endereco) {
                $retorno['codigo']   = 0;
                $retorno['input']    = $save_endereco;
                $retorno['output']   = $insert;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo']   = 1;
                $retorno['input']    = $insert;
                $retorno['output']   = $this->controller->modelo->info;
                $retorno['mensagem'] = "Erro ao salvar informação";
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            return $retorno;
        }
    }

    function detalheEndereco()
    {
        try {
            if (!isset($this->parametros[0]) || empty($this->parametros[0])) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro ao parâmetros";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $id_endereco = $this->parametros[0];
            }

            $endereco = json_decode($this->controller->modelo->getIfEndereco(null, $id_endereco));
            if ($endereco) {
                $retorno['codigo']   = 0;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $endereco;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo']   = 1;
                $retorno['input']    = $endereco;
                $retorno['output']   = $this->modelo->info;
                $retorno['mensagem'] = "Erro ao obter detalhe de endereço";
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            return $retorno;
        }
    }

    function excluirEndereco()
    {
        try {
            if (!isset($this->parametros[0]) || empty($this->parametros[0])) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro ao parâmetros";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $id_endereco = $this->parametros[0];
                $deleted['deleted'] = '1';
            }
            if (!isset($this->parametros[1]) || empty($this->parametros[1])) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro ao parâmetros";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $id_contrato = $this->parametros[1];
            }
            $this->controller->modelo->setTable('if_endereco');
            $update = $this->controller->modelo->save($deleted, $id_endereco);
            if ($update) {
                $retorno['codigo']   = 0;
                $retorno['input']    = $update;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Sucesso em excluir endereço";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo']   = 1;
                $retorno['input']    = $save;
                $retorno['output']   = $this->modelo->info;
                $retorno['mensagem'] = "Erro ao excluir";
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            return $retorno;
        }
    }

    function addComissao($insert)
    {
        try {
            $get_perfil = json_decode($this->model_comissao->getComissaoUsuario(null, $insert['id_usuario']));
            if (!isset($get_perfil) || empty($get_perfil)) {
                $get_user = json_decode($this->controller->modelo->getUsuarios($insert['id_usuario']));
                $retorno['codigo']   = 1;
                $retorno['input']    = $insert;
                $retorno['output']   = $this->controller->modelo->info;
                $retorno['mensagem'] = "Usuário " . $get_user[0]->nome . " sem perfil de comissão, cadastre no menu comissão";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $insert['id_comissao_usuario'] = $get_perfil[0]->id_comissao;
                $insert['data_criacao']        = $this->data_hora_atual->format('Y-m-d');
            }
            $get_user_comissao = json_decode($this->model_comissao->getFullComissao($insert['id_objeto'], $insert['id_usuario']));
            if (isset($get_user_comissao) && !empty($get_user_comissao)) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $insert;
                $retorno['output']   = $get_user_comissao;
                $retorno['mensagem'] = "Usuário comercial " . $get_user_comissao[0]->nome_usuario . " já adicionado neste contrato como " . strtoupper($get_user_comissao[0]->perfil);
                throw new Exception(json_encode($retorno), 1);
            }


            $this->controller->modelo->setTable('comissoes_validade');
            $save = $this->controller->modelo->save($insert);
            if ($save) {
                $get_comissao = json_decode($this->model_comissao->getFullComissao($insert['id_objeto']));
                if (isset($get_comissao) && !empty($get_comissao)) {
                    $html = $this->gerarHtmlComissao($get_comissao);
                    $retorno['codigo']   = 0;
                    $retorno['input']    = $get_comissao;
                    $retorno['output']   = $html;
                    $retorno['mensagem'] = "Sucesso";
                    throw new Exception(json_encode($retorno), 1);
                } else {
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $save;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Erro em obter get user comercial";
                    throw new Exception(json_encode($retorno), 1);
                }
            } else {
                $retorno['codigo']   = 1;
                $retorno['input']    = $insert;
                $retorno['output']   = $this->controller->modelo->info;
                $retorno['mensagem'] = "Erro ao salvar informação";
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            return $retorno;
        }
    }

    function gerarHtmlComissao($get_user_comissao)
    {
        $html = "";
        if (isset($get_user_comissao) && is_array($get_user_comissao)) {
            foreach ($get_user_comissao as $key => $value) {
                $html .= "<tr id='tr_" . $value->id . "'>";
                $html .= "<td class='text-center' style='font-size:10px;vertical-align:middle;'>" . strtoupper($value->perfil) . "</td>";
                $html .= "<td class='text-center' style='font-size:10px;vertical-align:middle;'>" . strtoupper($value->nome_perfil) . "</td>";
                $html .= "<td class='text-center' style='font-size:10px;vertical-align:middle;'>" . strtoupper($value->nome_usuario) . "</td>";
                $html .= "<td class='text-center' style='font-size:10px;vertical-align:middle;'>";
                if ($value->meses_validade == '1') {
                    $html .= $value->meses_validade . " MÊS";
                } else {
                    $html .= $value->meses_validade . " MESES";
                }
                $html .= "</td>";
                $html .= "<td class='text-center' style='font-size:10px;vertical-align:middle;'>";
                $html .= "<button type='button' class='btn btn-danger btn-xs delete_comissao' value='" . $value->id . "'><i class='fa fa-trash'></i> <b>EXCLUIR</b></button>";
                $html .= "</td>";
                $html .= "</tr>";
            }
        }
        return $html;
    }

    function getUserComissao($id_contrato)
    {
        try {
            $get_user_comissao = json_decode($this->model_comissao->getComissoesByObjeto($id_contrato));
            if (isset($get_user_comissao) && !empty($get_user_comissao)) {
                $retorno['codigo']   = 0;
                $retorno['input']    = $id_contrato;
                $retorno['output']   = $get_user_comissao;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo']   = 2;
                $retorno['input']    = $id_contrato;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Esse contrato ainda não tem comissão cadastrada";
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            return $retorno;
        }
    }

    function getUsersComercial($id_owner, $empresa = null, $dados_proposta)
    {
        try {
            $perfil_comercial = json_decode($this->model_comissao->getPerfilComissaoUsuario());
            if (isset($perfil_comercial) && !empty($perfil_comercial)) {
                foreach ($perfil_comercial as $key => $value) {
                    $percentual = str_replace("%", "", $value->percentual);
                    if ($percentual > 0) {
                        if (strtoupper($value->nome_perfil) == "SDR" || strtoupper($value->nome_perfil) == "MRR") {
                            $retorno['sdr'][]         = $value;
                        } else if (strtoupper($value->nome_perfil) == "CLOSER") {
                            if ($value->id_usuario == $id_owner) {
                                $retorno['owner'][]   = $value;
                            }
                        } else {
                            $perfil = str_replace(" ", "_", $value->nome_perfil);
                            switch ($dados_proposta[0]->codigo) {
                                case 'CRY0003':
                                case 'YLW0001':
                                    if ($value->email == 'marcio.lourenco@cmsw.com') {
                                        $perfil = str_replace(" ", "_", $value->nome_perfil);
                                        $retorno[strtolower($perfil)][] = $value;
                                    }
                                    break;
                                default:
                                    if ($value->email == 'kamal.zogheib@cmsw.com') {
                                        $perfil = str_replace(" ", "_", $value->nome_perfil);
                                        $retorno[strtolower($perfil)][] = $value;
                                    }
                                    break;
                            }
                        }

                        switch ($dados_proposta[0]->codigo) {
                            case 'CRY0003':
                            case 'YLW0001':
                                switch ($value->email) {
                                    case 'thiago.ferreira@cmsw.com':
                                        $perfil = str_replace(" ", "_", $value->nome_perfil);
                                        $retorno[strtolower($perfil)][] = $value;
                                        break;
                                }
                                break;
                        }
                    }
                }
            }
            throw new Exception(json_encode($retorno), 1);
        } catch (Exception $e) {
            return $retorno;
        }
    }

    function deletarUserComissao($id)
    {
        try {
            $insert['deleted'] = 1;
            $get_user_comissao = json_decode($this->model_comissao->getFullComissao(null, null, $id));
            $get_comissao      = json_decode($this->model_comissao->getFullComissao($get_user_comissao[0]->id_objeto));

            $this->controller->modelo->setTable("comissoes_validade");
            $save = $this->controller->modelo->save($insert, $id);
            if ($save) {
                $retorno['count'] = count($get_comissao);
                $retorno['codigo']   = 0;
                $retorno['input']    = $get_user_comissao[0]->perfil;
                $retorno['output']   = $id;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo']   = 1;
                $retorno['input']    = $insert;
                $retorno['output']   = $this->controller->modelo->info;
                $retorno['mensagem'] = "Erro em deletar comissão";
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            return $retorno;
        }
    }

    function removeHtmlComissao($id_objeto)
    {
        try {
            $get_user_comissao = json_decode($this->model_comissao->getFullComissao($id_objeto));
            if (isset($get_user_comissao) && !empty($get_user_comissao)) {
                $retorno['codigo']   = 0;
                $retorno['input']    = $id_objeto;
                $retorno['output']   = $get_user_comissao;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo']   = 1;
                $retorno['input']    = $id_objeto;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Sem comercial cadastrado";
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            return $retorno;
        }
    }
}
