<?php
    /**
    * Julio
    * Classe para log de eventos no sistema
    */
    require_once(ABSPATH .DS.'models'.DS.'integracoes'.DS.'integracoes-model.php');
    class Integracoes extends Main{
        protected
            $id,
            $data_hoje,
            $obj_api,
            $codigo,
            $url,
            $port,
            $user,
            $password,
            $device_id,
            $token,
            $tipo_request,
            $channel,
            $manager,
            $usar_cert,
            $cert_path,
            $cert_key,
            $security_key,
            $path_root,
            $obj_mq,
            $model;
        public
            $nome,
            $response_http_code;

        function __construct( $controller, $codigo = null ){
            parent::__construct( $controller );
            $this->data_hoje = getDataAtual();
            $this->model     = new IntegracoesModel();
            if( $codigo ){
                $this->loadDados( $codigo );
            }
        }
    
        function getId(){
            if($this->device_id){
                return $this->id;    
            }
        }
    
        function getDeviceId(){
            if($this->device_id){
                return $this->device_id;    
            }else{
                return 'fila_desconhecida';
            }
        }
    
        function getPathRoot(){
            return $this->path_root;    
        }
    
        function getUrl(){
            return $this->url;
        }
    
        function getToken(){
            return $this->token;
        }
    
        function loadDados($codigo){
            try{
                if( $codigo ){
                    $dados_api = json_decode($this->getIntegracaoByCodigo($codigo));
                    if( $dados_api ){
                        $this->id           = $dados_api[0]->id;
                        $this->nome         = $dados_api[0]->nome;
                        $this->codigo       = $dados_api[0]->codigo;
                        $this->url          = $dados_api[0]->url;
                        $this->port         = $dados_api[0]->port;
                        $this->user         = $dados_api[0]->user;
                        $this->password     = $dados_api[0]->password;
                        $this->device_id    = $dados_api[0]->device_id;
                        $this->security_key = $dados_api[0]->security_key;
                        $this->token        = $dados_api[0]->token;
                        $this->tipo_request = $dados_api[0]->tipo_request;
                        $this->channel      = $dados_api[0]->channel;
                        $this->manager      = $dados_api[0]->manager;
                        $this->usar_cert    = $dados_api[0]->usar_cert;
                        $this->cert_path    = $dados_api[0]->cert_path;
                        $this->cert_key     = $dados_api[0]->cert_key;
                        $this->path_root    = $dados_api[0]->path_root;
                        $this->loadApi();
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $codigo;
                        $retorno['output']   = $dados_api;
                        $retorno['mensagem'] = 'Api não encontrada com o codigo '.$codigo;
                        throw new Exception(json_encode($retorno), 1);    
                    }
                }else{
                    $retorno['codigo'] = 1;
                    $retorno['input']  = $codigo;
                    $retorno['output'] = null;
                    $retorno['mensagem'] = 'Informe o codigo da api';
                    throw new Exception(json_encode($retorno), 1);
                }
            }catch(Exception $e){
                return $e->getMessage();
            }
        }
    
        function getIntegracaoByTokenCallBack($token){
            return $this->model->getIntegracaoByTokenCallBack($token);
        }
    
        function getIntegracaoByToken($token){
            return $this->model->getIntegracaoByToken($token);
        }
    
        function getIntegracaoByCodigo($codigo){
            return $this->model->getIntegracaoByCodigo($codigo);
        }
    
        function loadApi(){
            $param['codigo']       = $this->codigo;
            $param['url']          = $this->url;
            $param['port']         = $this->port;
            $param['user']         = $this->user;
            $param['password']     = $this->password;
            $param['token']        = $this->token;
            $param['security_key'] = $this->security_key;
            $param['dev_id']       = $this->device_id;
            $param['usar_cert']    = $this->usar_cert;
            $param['channel']      = $this->channel;
            $param['manager']      = $this->manager;
            $param['cert_path']    = $this->cert_path;
            $param['cert_key']     = $this->cert_key;
            $param['path_root']    = $this->path_root;
            switch ($this->codigo) {
                case 'TKPIX001':
                case 'TKPIX002':
                case 'TLPIX001':
                case 'TLPIX002':
                case 'TKCHE001':
                case 'MIP001':
                    $param = array(
                        'host'    => $this->url,
                        'port'    => $this->port,
                        'channel' => $this->channel,
                        'manager' => $this->manager,
                        'queue'   => $this->device_id,
                        'loop'    => '1',
                    );
                    $this->obj_mq = new MqPlugin($param);
                break;
                default:          
                    $this->obj_api = new Api(null, $param);
                break;
            }
            
        }
    
        function getMQMsgId(){
            return $this->obj_mq->getMsgId();
        }
    
        function Exec( $objeto, $metodo, $parametros = null ){
            switch ( $this->codigo ) {
                case 'TLPIX001':
                case 'TLPIX002':
                case 'TKPIX001':
                case 'TKPIX002':
                case 'TKCHE001':
                case 'MIP001':
                    if( !$this->obj_mq->conexao ){
                        $is_connect = $this->obj_mq->connect();
                        if( !$is_connect ){
                            $param_msg['destino']   = 'grupo';
                            $param_msg['webhook'][] = URL_WEBHOOK_SLACK_TESTEINTEGRACAO;
                            $param_msg['mensagem']  = null;
                            $param_msg['mensagem'] .= "ERRO \n";
                            $param_msg['mensagem'] .= "Erro ao conectar no MQ em ".$this->url."\n";
                            $param_msg['mensagem'] .= "Porta: ".$this->port."\n";
                            $param_msg['mensagem'] .= "Fila: ".$this->device_id."\n";
                            if(isset($this->obj_mq->text_reason) && !empty($this->obj_mq->text_reason)){
                                $param_msg['mensagem'] .= "retorno: ".$this->obj_mq->text_reason."\n";
                            }else{
                                $param_msg['mensagem'] .= "retorno: Erro desconhecido \n";
                            }
                            $send = $this->notificacoes->enviarMensagem( $param_msg );
                            return false;
                        }
                    }

                    switch ( $metodo ) {
                        case 'input':
                            if( $this->obj_mq->colocarNaFila( $parametros['msg'] ) ){
                                $return = true;
                            }else{
                                $return = false;
                            }
                        break;
                        case 'read':
                            if( $this->obj_mq->pegarNaFila() ){
                                $return = $this->obj_mq->PegarMensagem();
                            }else{
                                $return = false;
                            }
                        break;
                    }
                    
                    if( $this->obj_mq->conexao ){
                        $this->obj_mq->closeMq();
                        $this->obj_mq->disconect();
                    }
                    return $return;
                break;
                default:
                    $return = $this->obj_api->Exec( $this->codigo, $objeto, $metodo, $parametros );
                    $this->response_http_code = $this->obj_api->response_http_code;
                    return $return;
                break;
            }
        }
    
        function saveExec($param){
            switch ($this->codigo) {
                case 'CAR001':
                    $dados_bd['id_integracao']        = $this->id;
                    $dados_bd['data_execucao']        = $this->data_hoje->format('Y-m-d H:i:s');
                    $dados_bd['data_transacao']       = (isset($param['data_transacao']))?$param['data_transacao']:null;
                    $dados_bd['tipo_transacao']       = (isset($param['tipo_transacao']))?$param['tipo_transacao']:null;
                    $dados_bd['modalidade_transacao'] = (isset($param['modalidade_transacao']))?$param['modalidade_transacao']:null;
                    $dados_bd['tipo_dados_origem']    = (isset($param['tipo_dados_origem']))?$param['tipo_dados_origem']:null;
                    $dados_bd['valor_dados_origem']   = (isset($param['valor_dados_origem']))?$param['valor_dados_origem']:null;
                    $dados_bd['tipo_dados_destino']   = (isset($param['tipo_dados_destino']))?$param['tipo_dados_destino']:null;
                    $dados_bd['valor_dados_destino']  = (isset($param['valor_dados_destino']))?$param['valor_dados_destino']:null;
                    $dados_bd['token_transacao']      = (isset($param['token_transacao']))?$param['token_transacao']:null;
                    $dados_bd['origem_transacao']     = (isset($param['origem_transacao']))?$param['origem_transacao']:null;
                    $dados_bd['id_origem']            = (isset($param['id_origem']))?$param['id_origem']:null;
                    $dados_bd['valor']                = (isset($param['valor']))?$param['valor']:null;
                    $dados_bd['balance']              = (isset($param['balance']))?$param['balance']:null;
                    $dados_bd['codigo_seguranca']     = (isset($param['codigo_seguranca']))?$param['codigo_seguranca']:null;
                    $dados_bd['status']               = (isset($param['status']))?$param['status']:null;
                break;
            }
            return $this->model->saveTransacao($dados_bd);
        }
    }