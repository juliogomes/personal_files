<?php
	/**
	* Julio
	* Classe para log de eventos no sistema
	*/
class Jobs{
	protected $obj_mensagem;
	protected $obj_nf;

	function __construct($param = null){
		//$this->date_atual = new DateTime('now', new DateTimeZone( 'America/Sao_Paulo'));
		// //Objeto com acesso a base de dados de cadastros;
		$controller = new MainController(null, 'tarifador');
		$this->obj_mensagem = $controller->load_model('mensagens/mensagens', true);
		$this->obj_nf = $controller->load_model('notas-fiscais/notas-fiscais', true);
		// $this->obj_contrato = $controller->load_model('contratos/contratos', true);
		// //Objeto com acesso a base de dados de impostos;
		// $controller = new MainController(null, 'tarifador');
		// $this->obj_imposto = $controller->load_model('impostos/impostos', true);
		// //Objeto com acesso a base de dados de produtos;
		// $controller = new MainController(null, 'tarifador');
		// $this->obj_produto = $controller->load_model('cadastros/produtos', true);
		// //Objeto com acesso a base de dados de faturamento;
		// $controller = new MainController(null, 'tarifador');
		// $this->obj_faturamento = $controller->load_model('faturamento/faturamento', true);
		// //Objeto com acesso a base de dados de indices;
		// $controller = new MainController(null, 'tarifador');
		// $this->obj_indice = $controller->load_model('cadastros/indices-reajuste', true);
		// //objeto com acesso a base de dados de movimento diario;
		// $controller = new MainController(null, 'tarifador');
		// $controller->Db = new Db(DB_NAME_MOVIMENTO);// Configurando o banco de dados movimento
		// $this->obj_movimento = $controller->load_model('movimento/movimento', true);
	}

	function getMsgNotaVencida(){
		return $this->obj_mensagem->getMsgNotaVencida();
	}

	function getNotasVencidas(){
		return $this->obj_nf->getNotasVencidas();
	}

	function saveSentMessage($param){
		return $this->obj_mensagem->saveSentMessage($param);
	}

	function getLastSentMessage($id_nota){
		return $this->obj_mensagem->getLastSentMessage($id_nota);
	}
}
