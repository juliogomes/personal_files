<?php
class Ldap
{
	public  $logged_in;
	public  $userdata;
	private $host 	 = LDAP_SERVER;
	private $port  	 = LDAP_PORT;
	private $dominio = LDAP_DOMINIO;
	private $filtro; //filtro é obrigatorio porem será informado em cada chamada de funçao exemplo de filtro (&(objectCategory=person)(samaccountname=$user)) ou "(objectClass=user)"
	private $basedn  = BASE_DN;
	private $atrib   = ATRIBUTOS_LDAP;
	//private $atrib	 = array("dn","cn","uid", "samaccountname", "name", "mail", "mailNickname","displayName","title", "department","company", "userPrincipalName", "desciption", "OU", "homeDrive","userAccountControl", "mobile" );
	private $user	 = null;
	private $pass	 = null;
	public  $error;
	public  $conexao;
	public  $retorno;
	public  $login_error;

	function __construct($autoconect = null){
		if($autoconect){
			$this->getConnection();
		}
		//phpinfo();
		ldap_set_option($this->conexao, LDAP_OPT_PROTOCOL_VERSION , 3); // versão 3 do ldap 
		ldap_set_option($this->conexao, LDAP_OPT_REFERRALS, 0);
		ldap_set_option($this->conexao, LDAP_OPT_SIZELIMIT, -1);
	}

	function getConnection($host = null, $port = null){
		try{
			if($host){
				$this->host = $host;
			}

			if($port){
				$this->port = $port;
			}

			$ldapcon = ldap_connect($this->host, $this->port) ;
			if($ldapcon){
				$this->conexao = $ldapcon;
				return $this->conexao;
			}else{
				$error['status']['codigo']   = ldap_errno($this->conexao);
				$error['status']['string']   = ldap_err2str(ldap_errno($this->conexao));
				$error['status']['mensagem'] = 'Não foi possivel conectar ao servidor ldap';
				throw new Exception(json_encode($error));
			}
		}catch(Exception $e){
			$this->error = $e;
			$this->conexao = false;
		}
	}

	function bindLdap($user, $pass){
		try{
			$arr_user = explode('@', $user);
			$user = $arr_user[0].'@cmnet';
			if(ldap_bind($this->conexao, $user, $pass)){
				return true;
			}else{
				$error['status']['codigo']   = ldap_errno($this->conexao);
				$error['status']['string']   = ldap_err2str(ldap_errno($this->conexao));
				$error['status']['mensagem'] = 'Login invalido ou senha incorreta';
				throw new Exception(json_encode($error));
			}
		}catch(Exception $e){
			$this->error = $e->getMessage();
			return false;
		}
	}

	function login($usuario, $senha){
		$this->getConnection();
		if($this->conexao){
			try{
				$bind = $this->bindLdap($usuario.$this->dominio, $senha);
				if (!ldap_errno($this->conexao)){
					return true;
				}else{
					throw new Exception('Dados de acesso incorretos ou conta bloqueada para usuario '.$usuario.' - '. ldap_err2str (ldap_errno($this->conexao)));
				}
			}catch(Exception $e){
				$this->error = $e->getMessage();
				return false;
			}
		}
	}

	function search($filtro = null, $atrib = null, $basedn = null, $conexao = null ){
		try{
			if($filtro){
				$this->filtro = $filtro;
			}

			if($atrib){
				$this->atrib = $atrib;
			}

			if($basedn){
				$this->basedn = $basedn;
			}

			if($conexao){
				$this->conexao = $conexao;
			}
			
			if($this->bindLdap($this->user, $this->pass)){
				$search = ldap_search($this->conexao, $this->basedn, $this->filtro, $this->atrib);
				if($search){
					// $entry = ldap_first_entry($this->conexao, $search);
					// $hoursbinary=ldap_get_values_len($this->conexao,$entry,"logonhours"); 
					// $hourshex=bin2hex($hoursbinary[0])."<br>";
					// echo '<pre>';
					// 	var_dump($hourshex);
					// echo '</pre>';
					$this->dados = json_encode(ldap_get_entries($this->conexao, $search));
					return $this->dados;
				}else{
					$error['status']['codigo']   = ldap_errno($this->conexao);
					$error['status']['string']   = ldap_err2str(ldap_errno($this->conexao));
					$error['status']['mensagem'] = 'Erro ao pesquisar diretorio ldap';
					throw new Exception(json_encode($error));
				}
			}else{
				$error['status']['codigo']   = ldap_errno($this->conexao);
				$error['status']['string']   = ldap_err2str(ldap_errno($this->conexao));
				$error['status']['mensagem'] = 'Login invalido ou senha incorreta';
				throw new Exception(json_encode($error));
			}

		}catch(Exception $e){
			$this->error = $e->getMessage();
			return false;
		}
	}

	function getUser($user, $pass){
		try{
			$arr_user = explode('@', $user);
			$user = $arr_user[0];
			$filtro = "(&(objectClass=user)(objectCategory=person)(|(mail=*)(telephonenumber=*))(!(userAccountControl:1.2.840.113556.1.4.803:=2))(samaccountname=$user))";
			//$filtro = "(&(objectClass=user)(objectCategory=person)(samaccountname=$user))";
			if(!$this->conexao){
				if(!$this->getConnection()){
					throw new Exception('conexao');
				}
			}
			if(!$this->bindLdap($user, $pass)){
				throw new Exception($this->error);
			}
			if($this->search($filtro)){
				return $this->dados;
			}else{
				return false;
			}
		}catch(Exception $e){
			$this->error = $e->getMessage();
			return false;
		}
	}
}