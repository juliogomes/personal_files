<?php
	/**
	* Julio	
	* Classe para log de eventos no sistema
	*/

class Log extends Main{
	protected 
		$tipo,
		$origem,
		$folder,
		$file,
		$info,
		$obj_notify, 
		$now, 
		$model_log;
	
	function __construct($controller = null){
		parent::__construct($controller);
	}

	function setLogModel(){
		$this->model_log = $this->controller->load_model('logs/logs', true);
	}

	function setTipo($tipo, $origem = null){
		$this->origem = ($origem)?$origem:'erro';
		/*
			1 - apenas file
			2 - apenas base de dados
			3 -  base de dados e file
		*/
		$this->tipo = $tipo;
		return $this;
	}

	function setFolder(){

	}

	function setFile($folder){
		if($folder){
			$this->folder = $folder;
		}else{
			switch ($this->tipo) {
				case 'sistema':
					$this->folder = 'sistema';	
				break;
				case 'sistema':
					$this->folder =
					 'sistema';	
				break;
				case 'sistema':
					$this->folder = 'sistema';	
				break;
				case 'sistema':
					$this->folder = 'sistema';	
				break;
				default: // padrao é erro
					$this->folder = 'sistema';
				break;
			}
		}
	}

	function record($newvalue, $oldval, $extras){
		switch ($tipo) {
			case 'value':
				# code...
			break;
			default: // padrao texto
				# code...
			break;
		}
	}

	function logInDb($tipo, $modulo, $id_modulo, $action, $oldvalue, $newvalue = null, $file_too = false){
		
		if('action' == $tipo){
			$param['id_modulo'] = $id_modulo;
			$param['modulo']    = $modulo;
			$param['action']    = $action;
			$param['oldvalue']  = json_encode($oldvalue);
			$param['newvalue']  = json_encode($newvalue);
		}else{
			$param['id_modulo'] = $id_modulo;
			$param['modulo']    = $modulo;
			$param['action']    = $action;
			$param['dados']     = json_encode($oldvalue);
			$param['erro']      = json_encode($newvalue);
			$this->model_log->setTable('log_errors');
		}
		
		if($file_too){
			if($tipo == 'action'){
				$tipo_text = 'debug';
			}else{
				$tipo_text = 'erro';
			}

			$this->writeLog(json_encode($param), $tipo_text, $tipo_text, 'log_action', false);
		}

		// return $this->model_log->save($param);
	}

	function writeLog($msg, $tipo = null, $modulo = null, $file_name = null, $send_aviso = false){
	
		if(!$tipo || 'error' == $tipo){
			$tipo = 'erro';
		}
		
		$mensagem = $this->controller->data_hora_atual->format('Y-m-d H:i:s').'-'.$tipo.'-'.$msg;
		
		if($file_name){
			$log = fopen($file_name."_".$this->controller->data_hora_atual->format('Ymd').".txt", "a+",0);
		}else{
			$log = fopen("log_diario_".$this->controller->data_hora_atual->format('Ymd').".txt", "a+",0);	
		}

		fwrite($log, $mensagem.PHP_EOL);
		fclose($log);
		
		if($send_aviso){
		    $this->setNotificacion();
			$parametros['tipo_destinatario'] = 'webhook';
			if('producao' == TIPO_AMBIENTE){
				$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/12ad07a8afcc45b1a3d600758059232e/c8c7ff53-e294-4a3a-bcad-c9f04857e469';
			}else{
				$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9f2e2cc655bf4e76bfdb0531dd3a83d7/c328c206-070a-4beb-bbed-da82e018abec';
			}
			$parametros['mensagem'] = $msg;
			$this->notificacoes->enviar('teams', $parametros);
			if(is_array($send_info)){
				foreach ($send_info as $key => $value) {
					if(0 != $value->codigo){
						$this->writeLog(json_encode($value), 'erro', 'erro', null);
					}
				}
			}
		}
	}

	function setLog($param){
		if($param){
			$this->log['mensagem']    = $param['mensagem'];
			$this->log['nome_modulo'] = $param['nome_modulo'];
		}
		return $this;
	}

	function saveLog(){
		var_dump($this->log);
	}
}

