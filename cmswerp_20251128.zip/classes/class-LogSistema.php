<?php
	/**
	* Julio	
	* Classe para log de eventos no sistema
	*/
    require_once(ABSPATH.DS.'models'.DS.'logs'.DS.'logs-model.php' );
    class LogSistema extends Main{
        protected
            $usuario,
            $password,
            $ip_remoto,
            $info,
            $data_acesso,
            $status;

        function __construct(){
            $args  = func_get_args();
            parent::__construct( $args['0'] );
            $this->modelo = new LogsModel();
        }

        function get_client_ip() {
            $ipaddress = '';
            if (isset($_SERVER['HTTP_CLIENT_IP']))
                $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
            else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
                $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
            else if(isset($_SERVER['HTTP_X_FORWARDED']))
                $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
            else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
                $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
            else if(isset($_SERVER['HTTP_FORWARDED']))
                $ipaddress = $_SERVER['HTTP_FORWARDED'];
            else if(isset($_SERVER['REMOTE_ADDR']))
                $ipaddress = $_SERVER['REMOTE_ADDR'];
            else
                $ipaddress = 'UNKNOWN';
            return $ipaddress;
        }

        function saveLoginAction(){
            $args = func_get_args();
            $this->modelo->setTable('log_acessos');
            $info[] = $_SERVER['HTTP_USER_AGENT'];
            $info[] = $_SERVER['HTTP_ORIGIN'];
            $info[] = $_SERVER['HTTP_REFERER'];
            $info[] = $_SERVER['HTTP_COOKIE'];
            $info[] = $_SERVER['HTTP_USER_AGENT'];
            $info[] = $_SERVER['SERVER_SIGNATURE'];
            $info[] = $_SERVER['SERVER_NAME'];
            $info[] = $_SERVER['REMOTE_ADDR'];
            $info[] = $_SERVER['SERVER_ADDR'];
            $info[] = $_SERVER['QUERY_STRING'];
            $info[] = $_SERVER['REQUEST_URI'];
            $info[] = $_SERVER['SCRIPT_NAME'];
            $info[] = $_SERVER['REDIRECT_QUERY_STRING'];
            $info[] = $_SERVER['REMOTE_PORT'];
            $info[] = $_SERVER['SCRIPT_FILENAME'];

            $log_param['usuario']      = $args[0];
			$log_param['password']     = $args[1];
            $log_param['status']       = $args[2];
            $log_param['erro_msg']     = $args[3];
            $log_param['modulo_origem'] = (isset($args[4]) && !empty($args[4])) ? $args[4] : 'login';
            $log_param['ip_remoto']    = self::get_client_ip();
            $log_param['info']         = json_encode($info);
            $log_param['data_acesso']  = $this->data_atual->format('Y-m-d H:i:s');
            $log_param['alterado_em']  = $this->data_atual->format('Y-m-d H:i:s');
            $log_param['alterado_por'] = ( isset($_SESSION['cmswerp']['userdata']->id) )?$_SESSION['cmswerp']['userdata']->id:null;
            $log_param['deleted']      = 0;
            $this->modelo->save( $log_param );
        }
    }