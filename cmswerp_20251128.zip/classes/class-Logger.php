<?php
    class Logger{
        public static $arquivo = ABSPATH.DS."logs".DS."cron";
        public static function log($mensagem){
            error_log(
                date("[Y-m-d H:i:s] ") . $mensagem . "\n",
                3,
                self::$arquivo."_".date("Y-m-d").".log"
            );
        }
    }
