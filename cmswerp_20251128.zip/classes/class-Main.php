<?php
    class Main{
        protected $notificacoes;
        protected $controller;
        protected $modelo;
        public $data_atual;
        public $erro     = array();
        public $msg_erro = array();
        function __construct( $controller = null ){
            $this->data_atual = getDataAtual();
            $this->controller = $controller;
        }

        function setModel($modulo){
            if($modulo){
                $modulo = $this->controller->setModulo($modulo);
            }
        }

        function setNotificacion(){
            $this->notificacoes = new Notificacoes( $this->controller );
        }
    }