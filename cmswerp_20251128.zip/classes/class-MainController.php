<?php
	class MainController extends UserLogin{
		/**
		 * $title
		 *
		 * Título das páginas
		 *
		 * @access public
		 */
		public $title;
		/**
		 * $nivel_acesso
		 *
		 * Nivel de acesso
		 *
		 * @access public
		 */
		protected $nivel_acesso;
		/**
		 * $error
		 *
		 * Erro de execução
		 *
		 * @access public
		 */
		public $error;
		/**
		 * $login_required
		 *
		 * Se a página precisa de login
		 *
		 * @access public
		 */
		public $login_required = true;
		/**
		 * $acao
		 *
		 * @access public
		 */
		public $acao;
		/**
		 * $parametros
		 *
		 * @access public
		 */
		public $parametros = array();
		/**
		 * $cl_log
		 *
		 * @access public
		 */
		public $cl_log;
		/**
		 * Construtor da classe
		 *
		 * Configura as propriedades e métodos da classe.
		 *
		 * @since 0.1
		 * @access public
		 */
		protected
			$nome_view,
			$nome_modulo,
			$config_model,
			$app_nologin,
			$config_list,
			$globals;
		public
			$modelo,
			$data_hora_atual;
		public function __construct($parametros = array(), $nome_modulo = null, $do_login = true)
		{
			$this->login_required = ($do_login) ? true : false;
			// instanciando a classe de log;
			$this->cl_log = new Log($this);
			//iniciando sessãoc caso não esteja iniciada
			if (!isset($_SESSION)) session_start();
			//instanciando hora padrão do sistema
			$this->data_hora_atual = getDataAtual();
			// carregando variaveis globais do sistema
			global	$VAR_SYSTEM;
			$this->globals = $VAR_SYSTEM;
			// parametros
			$this->parametros = $parametros;
			// carregando modelo padrão
			$this->load_model();
			parent::__construct();
			if ($this->login_required) {
				$this->autentica();
			}
			$this->config_model = $this->load_model('configuracoes/configuracoes', true);
			if($this->config_model){
				// carregando configurações do sistema
				$this->config_list = json_decode($this->config_model->getConfiguracoes());
			}else{
				echo 'Erro ao carregar configurações';
				exit;	
			}
		} // __construct

		function getNivelAcesso()
		{
			return $this->cl_permissoes->getNivelAcesso();
		}

		function autentica()
		{
			if (!isset($this->globals['NOLOGIN_EXEC'][$_SERVER['REQUEST_URI']])) {
				$this->check_userlogin();
			}
		}

		// setar nome do modulo
		function setModulo($modulo)
		{
			$this->nome_modulo = $modulo;
		}

		function getModulo()
		{
			return $this->nome_modulo;
		}

		function setView($view)
		{
			$this->nome_view = $view;
		}

		function viewPage($view)
		{
			require_once ABSPATH . "/views/$this->nome_view/$view ";
		}

		function __call($name, $arguments)
		{
			$start = microtime(true);
			try {
				$method_call = substr($name, 3);
				if ($this->login_required && $this->nome_modulo != 'login' && !isset($this->globals['NOLOGIN_EXEC'][$_SERVER['REQUEST_URI']])) {
					if (!isset($_SESSION['cmswerp']['userdata']->permissoes) || empty($_SESSION['cmswerp']['userdata']->permissoes)) {
						$retorno['status']      = 'error';
						$retorno['codigo']      = 2;
						$retorno['input']       = $this->nome_modulo;
						$retorno['output']      = null;
						$retorno['mensagem']    = 'Permissões não encontradas COD: 131';
						throw new Exception(json_encode($retorno));
					}
					$chk_permissao = json_decode($this->cl_permissoes->setPermissoes($_SESSION['cmswerp']['userdata']->permissoes)->checkPermissoes($this->nome_modulo, 'modulo'));
					$this->cl_permissoes->verificarPermissao();
					if ($chk_permissao->codigo == 0) {
						$this->nivel_acesso = $this->cl_permissoes->getNivelAcesso();
					} else {
						$retorno['status']      = 'error';
						$retorno['codigo']      = 2;
						$retorno['input']       = $this->nome_modulo;
						$retorno['output']      = $chk_permissao;
						$retorno['mensagem']    = $chk_permissao->mensagem;
						throw new Exception(json_encode($retorno));
					}
				}

				/*if (!isset($this->userdata->acesso_externo) || $this->userdata->acesso_externo != 1) {
					$output     = [];
					$returnVar  = null;
					exec('blocktarifa', $output, $returnVar);
					$arquivo = 'block_tarifa.txt';
					$range = explode('.', $_SERVER['REMOTE_ADDR']);
					if ($range[0] != '172' && $range[0] != '127') {
						preg_match('#https?://([^/]+)#', URL_SISTEMA, $matches);
						if (URL_SISTEMA != $matches[0] . '/') {
							echo 'Acesso bloqueado, contate o suporte para mais informações COD: ' . $range[0];
							exit;
						}
					} else {
						if (file_exists($arquivo)) {
							$linhas = file($arquivo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
							if ($linhas !== false) {
								foreach ($linhas as $linha) {
									$ip = htmlspecialchars(trim($linha));
									$range  = explode('.', $_SERVER['REMOTE_ADDR']);
									if ($_SERVER['REMOTE_ADDR'] == $ip || $range[0] != '172' || $range[0] != '127') {
										echo 'Acesso bloqueado, contate o suporte para mais informações COD: 157';
										exit;
									}
								}
							} else {
								echo "Erro ao ler o arquivo!";
							}
						}
					}
				}*/

				if (method_exists($this, $method_call)) { // method_exists
					$this->{$method_call}($arguments);
				} else {
					$this->index($arguments);
				}
				
				$elapsed = microtime(true) - $start;
				if (APP_MONITORING) {
					$userId		= (isset($_SESSION['cmswerp']['userdata']->id)) ? $_SESSION['cmswerp']['userdata']->id : null;
					$userNome	= (isset($_SESSION['cmswerp']['userdata']->nome)) ? $_SESSION['cmswerp']['userdata']->nome : null;
					$file_name  = ABSPATH . '/logs/debug/app.txt';
					$fp 	    = fopen($file_name, 'a+');
					$metodo     = get_class($this) . ' - ' . $method_call;
					fwrite($fp, "[Data: " . $this->data_hora_atual->format('Y-m-d H:i:s') . " User: $userId - $userNome] [SQL] {$metodo} tempo: " . number_format($elapsed, 4) . "s" . "\n");
					fclose($fp);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
				exit;
			}
		}

		/**
		 * Load model
		 *
		 * Carrega os modelos presentes na pasta /models/.
		 *
		 * @since 0.1
		 * @access public
		 */
		public function load_model($model_name = false, $return = false, $include_this = true){
			if ($model_name) {
				$model_name = $model_name . '-model';
			} else {
				if (isset($this->nome_modulo)) {
					$model_name = $this->nome_modulo . '/' . $this->nome_modulo . '-model';
				}
			}
			// Um arquivo deverá ser enviado
			if (! $model_name) return;
			// Garante que o nome do modelo tenha letras minúsculas
			$model_name =  strtolower($model_name);
			// Inclui o arquivo
			$model_path = ABSPATH . '/models/' . $model_name . '.php';
			// Verifica se o arquivo existe
			if (file_exists($model_path)) {
				// Inclui o arquivo
				require_once $model_path;
				// Remove os caminhos do arquivo (se tiver algum)
				$model_name = explode('/', $model_name);
				// Pega só o nome final do caminho
				$model_name = end($model_name);
				// Remove caracteres inválidos do nome do arquivo
				$model_name = preg_replace('/[^a-zA-Z0-9]/is', '', $model_name);
				// Verifica se a classe existe
				if (class_exists($model_name)) {
					if ($return) {
						// Retorna um objeto da classe
						return new $model_name($this);
					} else {
						// Retorna um objeto da classe
						$this->modelo =  new $model_name($this);
					}
				}
				// The end :)
				return;
			} // load_model
		} // load_model

		function loginRequired($param)
		{
			$this->login_required = $param;
		}

		function getModel()
		{
			return $this->modelo;
		}

		function loadFields($tipo, $nome, $subtipo = null)
		{
			require_once('fields_inc.php');
			global $FIELDS;
			$tipo = strtoupper($tipo);
			$nome = strtoupper($nome);
			if ($subtipo) {
				$subtipo = strtoupper($subtipo);
				return $FIELDS['TIPO_CAMPO'][$tipo][$nome][$subtipo]['OPTIONS'];
			} else {
				return $FIELDS['TIPO_CAMPO'][$tipo][$nome]['OPTIONS'];
			}
		}

		function getFields($tipo, $nome, $subtipo = null, $selected = null)
		{
			$options = $this->loadFields($tipo, $nome, $subtipo);
			if ($options) {
				foreach ($options as $key => $value) {
					if ($key == $selected) {
						echo " <option value='$key' selected >$value</option>";
					} else {
						echo " <option value='$key'>$value</option>";
					}
				}
			}
		}

		function arrayDinamico(&$array, $i, $key = null, $default = 0)
		{
			// Se o índice não existe ou não for array, inicializa como array
			if (!isset($array[$i]) || !is_array($array[$i])) {
				$array[$i] = array();
			}

			if ($key !== null) {
				if (!isset($array[$i][$key])) {
					$array[$i][$key] = $default;
				}
			} else {
				// Se não houver key, define o valor direto
				if (empty($array[$i])) {
					$array[$i] = $default;
				}
			}
		}

		function retorno($tipo, $mensagem, $dados = null)
		{
			switch ($tipo) {
				case 'ok':
				case 'sucesso':
					$retorno['status'] = 'ok';
					$retorno['codigo'] = 0;
					break;
				case 'alerta':
					$retorno['status'] = 'alerta';
					$retorno['codigo'] = 2;
					break;
				default:
					$retorno['status'] = 'erro';
					$retorno['codigo'] = 1;
					break;
			}
			$retorno['mensagem'] = $mensagem;
			$retorno['dados'] 	 = $dados;
			echo json_encode($retorno);
			exit;
		}
	} // class MainController