<?php
class MainModel{
	/**
	 * $form_confirma
	 *
	 * Mensagem de confirmação para apagar dados de formulários
	 *
	 * @access public
	 */
	public $form_confirma;
	/**
	 * $db
	 *
	 * O objeto da nossa conexão PDO
	 *
	 * @access public
	 */
	public $db;
	/**
	 * $error
	 *
	 * Erro na execução do modelo
	 *
	 * @access public
	 */
	public $info;
		/**
	 * $controller
	 *
	 * O controller que gerou esse modelo
	 *
	 * @access public
	 */
	public $controller;
	/**
	 * Inverte datas
	 *
	 * Obtém a data e inverte seu valor.
	 * De: d-m-Y H:i:s para Y-m-d H:i:s ou vice-versa.
	 *
	 * @since 0.1
	 * @access public
	 * @param string $data A data
	 */
	//define a tabela para o modelo carregado no load model
	protected $table;
	function __construct($controller = null, $parametros = null){
		if($parametros){
			$this->setDb( null, $parametros );
		}else{
			$this->setDb();
		}
		$this->controller = $controller;
		// $this->db = $db;
		// Configura o controlador
		// Configura os parâmetros
		// Configura os dados do usuário
	}

	function setDb($db = null, $parametros = null){
		if($db){
			$this->db = $db;
		}else{			
			if(isset($parametros) && !empty($parametros)){						
				$this->db = new Db($parametros);
			}else{
				$this->db = new Db();
			}			
		}
	}

	public function inverte_data( $data = null ) {
		// Configura uma variável para receber a nova data
		$nova_data = null;
		// Se a data for enviada
		if ( $data ) {
			// Explode a data por -, /, : ou espaço
			$data = preg_split('/\-|\/|\s|:/', $data);
			// Remove os espaços do começo e do fim dos valores
			$data = array_map( 'trim', $data );
			// Cria a data invertida
			$nova_data .= chk_array( $data, 2 ) . '-';
			$nova_data .= chk_array( $data, 1 ) . '-';
			$nova_data .= chk_array( $data, 0 );
			// Configura a hora
			if ( chk_array( $data, 3 ) ) {
				$nova_data .= ' ' . chk_array( $data, 3 );
			}
			// Configura os minutos
			if ( chk_array( $data, 4 ) ) {
				$nova_data .= ':' . chk_array( $data, 4 );
			}
			// Configura os segundos
			if ( chk_array( $data, 5 ) ) {
				$nova_data .= ':' . chk_array( $data, 5 );
			}
		}
		// Retorna a nova data
		return $nova_data;
	} // inverte_data

	function setTable($table){
		$this->table = $table;
	}
	
	function getTable(){
		return $this->table;
	}

	function getById($id){
		$id = (int) $id;
		if(is_numeric($id) && !empty($id)){
			$query = "
				select * from ".$this->table." tf where tf.id = $id
			";
			$exec = $this->db->query($query);
			if($exec){
				// Retorna
				$return = $exec->fetch(PDO::FETCH_ASSOC);
				return json_encode($return);
			}else{
				return false;
			}
		}else{
			return false;
		}
	}
	//exemplos
	// public function __set($name, $value)
    // {
    //     echo "Setting '$name' to '$value'\n";
    //     $this->data[$name] = $value;
    // }

    // public function __get($name)
    // {
    //     echo "Getting '$name'\n";
    //     if (array_key_exists($name, $this->data)) {
    //         return $this->data[$name];
    //     }

    //     $trace = debug_backtrace();
    //     trigger_error(
    //         'Undefined property via __get(): ' . $name .
    //         ' in ' . $trace[0]['file'] .
    //         ' on line ' . $trace[0]['line'],
    //         E_USER_NOTICE);
    //     return null;
    // }
    // implementar posteriormente
	// function __set($atr, $value){
	// 	$this->$atr = $value;
	// }
	// function __get($atr){
	// 	return $this->$atr;
	// }

	function getModulosByProdutos($id_produto, $orderby = null){
		$query = " select * from ".$this->table." where id_produto = ".$id_produto;
		if($orderby){
			$query .= ' order by '.$orderby;
		};
		$exec = $this->db->query($query);
		if($exec){
			$return = $exec->fetchAll();
			return json_encode($return);
		}else{
			return false;
		}
	}

	function save( $param, $id = null, $field = 'id' ){
		try{
			if( is_object( $param ) ){
				$param = get_object_vars( $param );
			}

			if( !$this->table ){
				$retorno['codigo']   = 1;
                $retorno['tipo']     = 'error';
				$retorno['input']    = $param;
				$retorno['output']   = null;
				$retorno['mensagem'] = 'Tabela não definida';
				throw new Exception(json_encode($retorno), 1);
			}

			if( isset( $this->controller->login_required ) && $this->controller->login_required ){
				if(!isset($this->controller->globals['NOLOGIN_EXEC'][$_SERVER['REQUEST_URI']]) && (!$this->controller || !$this->controller->cl_permissoes->getNivelAcesso()) ){
					$retorno['codigo']   = 1;
					$retorno['tipo']     = 'error';
					$retorno['input']    = $param;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Nivel e permissões não definida';
					throw new Exception(json_encode($retorno), 1);
				}
              
				if(!isset($this->controller->globals['NOLOGIN_EXEC'][$_SERVER['REQUEST_URI']]) && $this->controller->cl_permissoes->getNivelAcesso() < 2){
					$retorno['codigo']   = 1;
					$retorno['tipo']     = 'error';
					$retorno['input']    = $param;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Você não possui nivel de acesso para essa ação';
					throw new Exception(json_encode($retorno), 1);
				}
			}else{
				// echo '<pre>';
				// 	var_dump($this->controller->globals);
				// echo '</pre>';
			}

			if( $id ){
				if( $field == 'id' ){
					if(!is_numeric($id) || empty($id)){
						$retorno['codigo']   = 1;
						$retorno['tipo']     = 'error';
						$retorno['input']    = $id;
						$retorno['output']   = null;
						$retorno['mensagem'] = 'ID do registro invalido 1';
						throw new Exception(json_encode($retorno), 1);	
					}
				}else{
					if(empty($id)){
						$retorno['codigo']   = 1;
						$retorno['tipo']     = 'error';
						$retorno['input']    = $id;
						$retorno['output']   = null;
						$retorno['mensagem'] = 'ID do registro invalido 2';
						throw new Exception(json_encode($retorno), 1);	
					}
				}
				$where_field       = $field;
				$where_field_value = $id;
				$this->db->update($this->table, $where_field, $where_field_value, $param);
			}else{
				$this->db->insert( $this->table, $param );
			}

			if( !$this->db->error ){
				if( !$id && $this->db->last_id ){
					$id = $this->db->last_id;
				}
				
				if( $id ){
					$retorno['codigo']   = 0;
					$retorno['tipo']     = 'sucesso';
					$retorno['input']    = $param;
					$retorno['output']   = $id;
					$retorno['mensagem'] = 'Sucesso ao salvar registro na tabela '.$this->table;
					throw new Exception(json_encode($retorno), 1);
				}else{
					$retorno['codigo']   = 1;
					$retorno['tipo']     = 'error';
					$retorno['input']    = $param;
					$retorno['query']    = $this->db->last_query;
					$retorno['output']   = $this->db->error;
					$retorno['mensagem'] = 'Erro desconhecido ao salvar registro na tabela '.$this->table;
					throw new Exception(json_encode($retorno), 1);
				}
			}else{
				$retorno['codigo']   = 1;
				$retorno['tipo']     = 'error';
				$retorno['input']    = $param;
				$retorno['query']    = $this->db->last_query;
				$retorno['output']   = $this->db->error;
				$retorno['mensagem'] = 'Erro ao salvar registro na tabela '.$this->table;
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			$this->info = json_decode($e->getMessage());
			if(isset($this->info->codigo) && $this->info->codigo == 0){
				return $id;
			}else{
				return false;
			}
		}
	}

	// function deleteRecords($table, $id, $param = null)
	// {
	// 	if($id){
	// 		return $this->db->delete($table, 'id', $id);
	// 	}else{
	// 		return false;
	// 	}
	// }

} // MainModel