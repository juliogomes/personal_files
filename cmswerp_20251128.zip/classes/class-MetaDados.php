<?php
	class MetaDados extends Main{
		protected $metadados_model;
		protected $error;
		function __construct( $controller ){
			parent::__construct( $controller );
			$this->metadados_model = $this->controller->load_model( 'metadados/metadados', true );
		}

		function getMetaDados( $meta_origem, $id_origem, $meta_tipo = null ){
			return $this->metadados_model->getMetaDados( $meta_origem, $id_origem, $meta_tipo );
		}

		function getMetaDadosByCampo( $meta_origem, $id_origem, $meta_campo = null ){
			return $this->metadados_model->getMetaDadosByCampo( $meta_origem, $id_origem, $meta_campo );
		}

		function getMetaInfo( $meta_origem, $id_origem, $meta_campo = null ){
			$dados = json_decode( $this->getMetaDados( $meta_origem, $id_origem, $meta_campo ) );
			if( $dados ){
				$meta_info = null;
				foreach ( $dados as $key => $value ) {
					$json_info = json_decode( $value->meta_info );
					if( $json_info ){
						foreach ( $json_info as $k1 => $v1 ) {
							$meta_info[] = $v1;
						}
					}
				}
				return $meta_info;
			}else{
				return false;
			}
		}

		function save( $dados, $id = null ){
			$is_save = $this->metadados_model->save( $dados, $id );
			if( $is_save ){
				return true;
			}else{
				$this->error = $this->metadados_model->db->error;
				return false;
			}
		}
	}