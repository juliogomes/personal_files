<?php

/**
 * Caio Freitas
 * 28/07/2022
 * Classe para gerar texto de minuta de contrato
 */
class Minuta
{
    private
        $controller,
        $data_extenso,
        $model_modelo,
        $dicionario,
        $model_produto;
    function __construct($controller)
    {
        $this->controller = $controller;
        $this->model_modelo = $this->controller->load_model('modelo/modelo', true);
        $this->model_produto = $this->controller->load_model('produtos/produtos', true);
        require ABSPATH . "/config_extras.php";
        $this->dicionario = $VAR_SYSTEM;
        setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
        $this->data_extenso = strftime('%d de %B de %Y', strtotime('today'));
    }

    function gerarMinuta($produto)
    {
        try {
            $texto = $this->gerarTexto($produto);
            if (isset($texto) && !empty($texto)) {
                $retorno['codigo']   = 0;
                $retorno['input']    = $produto;
                $retorno['output']   =  $texto;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo']   = 1;
                $retorno['input']    = $produto;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Produto indefinido COD: 37";
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    function gerarPDF($ged, $produto, $id_contrato, $id_proposta)
    {
        $api = new Api();

        try {
            $pathModelosContrato = UP_GED . DS . 'modelos_contrato';
            if (!is_dir($pathModelosContrato)) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $produto;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Pasta de modelos de contrato não encontrada";
                throw new Exception(json_encode($retorno), 1);
            }
            $pathProduto = $pathModelosContrato . DS . $produto;

            if (!is_dir($pathProduto)) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $produto;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Pasta do produdo em modelos de contrato não encontrada";
                throw new Exception(json_encode($retorno), 1);
            }

            $pathArquivoModelo =  $pathProduto . DS . 'modelo_contrato.docx';
            if (!file_exists($pathArquivoModelo)) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $produto;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Arquivo modelo de contrato não encontrado";
                throw new Exception(json_encode($retorno), 1);
            }

            $tempNameFile = 'documento_' . uniqid() . '.docx';

            $tempFile = sys_get_temp_dir() . DS . $tempNameFile;

            if (!copy($pathArquivoModelo, $tempFile)) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $produto;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro ao copiar modelo de contrato";
                throw new Exception(json_encode($retorno), 1);
            }

            $urlApi = 'http://api.tarifador:81/apicreatehtml.php?function=gerarPDF';

            $post = [
                // 'file' => new CURLFile($tempFile, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', basename($tempFile)),
                // 'nameFile' => $tempNameFile,
                // 'arquivo_base64' => base64_encode(file_get_contents($tempFile)),
                'pathFile' => $tempFile,
                'data' => [
                    'text' => [
                        'NOME_CLIENTE' => 'Luciano Silva',
                        'ENDERECO_CLIENTE' => 'Rua 1'
                    ],
                    'tables' => [
                        'preco_unico' => [
                            ['Produto' => 'Teclado', 'Qtd' => 2, 'Preço' => 'R$ 80,00'],
                            ['Produto' => 'Mouse',   'Qtd' => 1, 'Preço' => 'R$ 50,00'],
                            ['Produto' => 'Monitor', 'Qtd' => 1, 'Preço' => 'R$ 850,00'],
                        ]
                    ]

                ]
            ];

            $paramsRequest =  [
                CURLOPT_URL => $urlApi,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json'
                ],
                CURLOPT_POSTFIELDS => json_encode($post)
            ];

            $result = json_decode($api->CurlExec(null, $paramsRequest));
            if (!$result->status) {
                $retorno['codigo']   = 1;
                $retorno['input']    = null;
                $retorno['output']   = null;
                $retorno['mensagem'] = $result->mensagem;
                throw new Exception(json_encode($retorno), 1);
            }

            if (is_dir(PATH_MINUTA)) {
                mkdir(PATH_MINUTA);
            }

            $pathFinalPDF = PATH_MINUTA . $ged[0]->path_objeto . $ged[0]->nome_hash;
            if (!is_dir(PATH_MINUTA . $ged[0]->path_objeto)) {
                mkdir(PATH_MINUTA . $ged[0]->path_objeto);
            }

            if (copy($result->pdfPath, $pathFinalPDF)) {
                unlink($tempFile);
                unlink($result->pdfPath);
            }

            $retorno['codigo']   = 1;
            $retorno['input']    = $produto;
            $retorno['output']   = null;
            $retorno['mensagem'] = json_encode($result);
            throw new Exception(json_encode($retorno), 1);
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    private function obtemValoresTags($id_contrato, $cod_produto)
    {
        setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
        if (isset($id_contrato) && !empty($id_contrato)) {
            $contrato = json_decode($this->controller->modelo->getIfContrato($id_contrato));
            $endereco = json_decode($this->controller->modelo->getIfEndereco($id_contrato));
            $dados_minuta["CLIENTE"]["CLIENTE"]   = $contrato[0]->razao_social;
            $dados_minuta["CLIENTE"]["CNPJ"]      = formatarString("cnpj", $contrato[0]->cnpj);
            $dados_minuta["ENDERECO"]["ENDERECO"] = $endereco[0]->endereco . ", nº " . $endereco[0]->numero;
            $dados_minuta["ENDERECO"]["BAIRRO"]   = $endereco[0]->bairro;
            $dados_minuta["ENDERECO"]["CEP"]      = formatarString("cep", $endereco[0]->cep);
            $dados_minuta["ENDERECO"]["CIDADE"]   = $endereco[0]->cidade;
            $dados_minuta["ENDERECO"]["UF"]       = $endereco[0]->estado;

            $contatos = json_decode($this->controller->modelo->getIfContato($id_contrato, 'minuta'));
            if (isset($contatos) && !empty($contatos)) {
                $contador_representante = 0;
                foreach ($contatos as $key => $value) {
                    if (strtoupper($value->tipo_contato) == "RESPONSAVEL_LEGAL") {
                        if ($contador_representante == 0) {
                            $dados_minuta["REPRESENTANTE"]["NOME"]      = $value->nome;
                            $dados_minuta["REPRESENTANTE"]["CARGO"]     = $value->cargo_setor;
                            $dados_minuta["REPRESENTANTE"]["CPF"]       = formatarString("cpf", $value->cpf);
                            $dados_minuta["REPRESENTANTE"]["TELEFONE"]  = formatarString("telefone", $value->telefone);
                            $dados_minuta["REPRESENTANTE"]["EMAIL"]     = $value->email;
                        } else {
                            $dados_minuta["REPRESENTANTE_2"]["NOME"]      = "<b>" . $value->nome . "</b>";
                            $dados_minuta["REPRESENTANTE_2"]["CARGO"]     = $value->cargo_setor;
                            $dados_minuta["REPRESENTANTE_2"]["CPF"]       = formatarString("cpf", $value->cpf);
                            $dados_minuta["REPRESENTANTE_2"]["TELEFONE"]  = formatarString("telefone", $value->telefone);
                            $dados_minuta["REPRESENTANTE_2"]["EMAIL"]     = $value->email;
                        }
                        $contador_representante++;
                    }

                    if (strtoupper($value->tipo_contato) == "TESTEMUNHA") {
                        $dados_minuta["TESTEMUNHA"]["NOME"]         = $value->nome;
                        $dados_minuta["TESTEMUNHA"]["CPF"]          = formatarString("cpf", $value->cpf);
                        $dados_minuta["TESTEMUNHA"]["EMAIL"]        = $value->email;
                        $dados_minuta["TESTEMUNHA"]["TIPO_CONTATO"] = strtoupper($value->tipo_contato);
                        $dados_minuta["TESTEMUNHA"]["TELEFONE"]     = formatarString("telefone", $value->telefone);
                    }

                    if (strtoupper($value->tipo_contato) == "TESTEMUNHA_2") {
                        $dados_minuta["TESTEMUNHA_2"]["NOME"]         = $value->nome;
                        $dados_minuta["TESTEMUNHA_2"]["CPF"]          = formatarString("cpf", $value->cpf);
                        $dados_minuta["TESTEMUNHA_2"]["EMAIL"]        = $value->email;
                        $dados_minuta["TESTEMUNHA_2"]["TIPO_CONTATO"] = "TESTEMUNHA";
                        $dados_minuta["TESTEMUNHA_2"]["TELEFONE"]     = formatarString("telefone", $value->telefone);
                    }

                    if (!isset($dados_minuta["CONTATO_FINANCEIRO"])) {
                        if (strtoupper($value->tipo_contato) == "FINANCEIRO") {
                            $dados_minuta["CONTATO_FINANCEIRO"]["TIPO_CONTATO"] = strtoupper($value->tipo_contato);
                            $dados_minuta["CONTATO_FINANCEIRO"]["NOME"]         = $value->nome;
                            $dados_minuta["CONTATO_FINANCEIRO"]["EMAIL"]        = $value->email;
                            $dados_minuta["CONTATO_FINANCEIRO"]["TELEFONE"]     = formatarString("telefone", $value->telefone);
                        }
                    } else {
                        if (strtoupper($value->tipo_contato) == "FINANCEIRO") {
                            $dados_minuta["CONTATO_FINANCEIRO"]["CONTATO_FINANCEIRO_2"] = "• FINANCEIRO: " . $value->nome . " - e-mail: " . $value->email . " - telefone: " . formatarString("telefone", $value->telefone);
                        }
                    }

                    if (strtoupper($value->tipo_contato) == "CONTATO_RESPONSAVEL") {
                        $contato_responsavel['status'] = true;
                        $contato_responsavel['dados'][] = $value;
                    }
                }

                if (!isset($dados_minuta["CONTATO_FINANCEIRO"]["CONTATO_FINANCEIRO_2"])) {
                    $dados_minuta["CONTATO_FINANCEIRO"]["CONTATO_FINANCEIRO_2"] = "";
                }

                if (isset($contato_responsavel) && $contato_responsavel['status'] == true) {
                    $dados_minuta["CONTATO_RESPONSAVEL"]["NOME"]     = $contato_responsavel["dados"][0]->nome;
                    $dados_minuta["CONTATO_RESPONSAVEL"]["EMAIL"]    = $contato_responsavel["dados"][0]->email;
                    $dados_minuta["CONTATO_RESPONSAVEL"]["TELEFONE"] = formatarString("telefone", $contato_responsavel["dados"][0]->telefone);
                } else {
                    $dados_minuta["CONTATO_RESPONSAVEL"]["NOME"]     = $dados_minuta["REPRESENTANTE"]["NOME"];
                    $dados_minuta["CONTATO_RESPONSAVEL"]["EMAIL"]    = $dados_minuta["REPRESENTANTE"]["EMAIL"];
                    $dados_minuta["CONTATO_RESPONSAVEL"]["TELEFONE"] = $dados_minuta["REPRESENTANTE"]["TELEFONE"];
                }
            } else {
                return false;
            }

            $contato_cm = json_decode($this->controller->modelo->getContatoSign("sign_cm", null, null, true));
            if (isset($contato_cm) && !empty($contato_cm)) {
                foreach ($contato_cm as $key => $value) {
                    if (strtoupper($value->tipo_contato) == "JURIDICO") {
                        $juridico[] = $value;
                    }
                    if (strtoupper($value->tipo_contato) == "TESTEMUNHA") {
                        $testemunha[] = $value;
                    }
                }
                if (isset($juridico) && !empty($juridico)) {
                    $dados_minuta['TESTEMUNHA_CM']["NOME"]  = $juridico[0]->nome;
                    $dados_minuta['TESTEMUNHA_CM']["CPF"]   = formatarString("cpf", $juridico[0]->cpf);
                    $dados_minuta['TESTEMUNHA_CM']["EMAIL"] = $juridico[0]->email;
                } else {
                    if (isset($testemunha) && !empty($testemunha)) {
                        $dados_minuta['TESTEMUNHA_CM']["NOME"]  = $testemunha[0]->nome;
                        $dados_minuta['TESTEMUNHA_CM']["CPF"]   = formatarString("cpf", $testemunha[0]->cpf);
                        $dados_minuta['TESTEMUNHA_CM']["EMAIL"] = $testemunha[0]->email;
                    }
                }
            }
        } else {
            return false;
        }
        $faturamento = json_decode($this->controller->modelo->getInstrucaoFaturamento($id_contrato));
        if (isset($faturamento) && !empty($faturamento)) {
            $dados_minuta["FATURAMENTO"]["IMPLANTACAO"]         = funcValor($faturamento[0]->implantacao,  'C', 2);
            $dados_minuta["FATURAMENTO"]["IMPLANTACAO_EXTENSO"] = "( " . Extenso::converte(funcValor($faturamento[0]->implantacao, 'C', 2), true, false) . " )";

            if (isset($faturamento[0]->hospedagem) && !empty($faturamento[0]->hospedagem)) {
                $dados_minuta["FATURAMENTO"]["PACOTE"] = funcValor($faturamento[0]->hospedagem, 'C', 2);
                $dados_minuta["FATURAMENTO"]["PACOTE_EXTENSO"] = "( " . Extenso::converte(funcValor($faturamento[0]->hospedagem, 'C', 2), true, false) . " )";
            } else {
                $pacote_propostas = json_decode($this->controller->modelo->getPacotePropostas($contrato[0]->id_proposta));
                if (isset($pacote_propostas) && !empty($pacote_propostas)) {
                    $dados_minuta["FATURAMENTO"]["PACOTE"] = funcValor($pacote_propostas[0]->preco_pkt, 'C', 2);
                    $dados_minuta["FATURAMENTO"]["PACOTE_EXTENSO"] = "( " . Extenso::converte(funcValor($pacote_propostas[0]->preco_pkt, 'C', 2), true, false) . " )";
                }
            }

            $dados_minuta["FATURAMENTO"]["CORTE_FATURAMENTO"] = $faturamento[0]->faturamento_todo_dia;
            $dados_minuta["FATURAMENTO"]["CORTE_FATURAMENTO_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->faturamento_todo_dia, false, false) . " )";
            if ($faturamento[0]->tipo_data_faturamento == "dias_apos_faturamento" && !empty($faturamento[0]->dias_apos_faturamento)) {
                $dados_minuta["FATURAMENTO"]["PRAZO_PAGAMENTO"] = "de " . $faturamento[0]->dias_apos_faturamento;
                $dados_minuta["FATURAMENTO"]["PRAZO_PAGAMENTO_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->dias_apos_faturamento, false, false) . " ) dias";
            } else {
                $dados_minuta["FATURAMENTO"]["PRAZO_PAGAMENTO"] = "todo dia " . $faturamento[0]->vencimento_todo_dia;
                $dados_minuta["FATURAMENTO"]["PRAZO_PAGAMENTO_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->vencimento_todo_dia, false, false) . " ) de cada mês";
            }

            if ($faturamento[0]->parcelas == "1") {
                $dados_minuta["FATURAMENTO"]["IMPLANTACAO_TEXTO"] = "que será pago em até 10 (dez) dias após a assinatura do presente contrato";
            } else if ($faturamento[0]->parcelas == "2") {
                $parcela_implatacao =  funcValor($faturamento[0]->implantacao / 2, 'C', 2);
                $dados_minuta["FATURAMENTO"]["IMPLANTACAO_TEXTO"] = "que serão pagos em 2 (duas) parcelas iguais e consecutivas de R$ " . $parcela_implatacao . " ( " . Extenso::converte($parcela_implatacao, true, false) . " ) sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela.";
            } else if ($faturamento[0]->parcelas == "3") {
                $parcela_implatacao =  funcValor($faturamento[0]->implantacao / 3, 'C', 2);
                $dados_minuta["FATURAMENTO"]["IMPLANTACAO_TEXTO"] = "que serão pagos em 3 (três) parcelas iguais e consecutivas de R$ " . $parcela_implatacao . " ( " . Extenso::converte($parcela_implatacao, true, false) . " ) sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela e a terceira parcela com vencimento em 30 (trinta) dias após o vencimento da segunda parcela.";
            } else {
                $parcela_implatacao =  funcValor($faturamento[0]->implantacao / $faturamento[0]->parcelas, 'C', 2);
                $dados_minuta["FATURAMENTO"]["IMPLANTACAO_TEXTO"] = "que serão pagos em " . $faturamento[0]->parcelas . " (" . Extenso::converte($faturamento[0]->parcelas, false, false) . ") parcelas iguais e consecutivas de R$ " . $parcela_implatacao . " ( " . Extenso::converte($parcela_implatacao, true, false) . " ) sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela e a terceira parcela com vencimento em 30 (trinta) dias após o vencimento da segunda parcela.";
            }

            $dados_minuta["FATURAMENTO"]["PRIMEIRO_FATURAMENTO"] = "<b> 29 (vinte e nove) </b>";
            if (empty($faturamento[0]->duracao_contrato)) {
                $dados_minuta["FATURAMENTO"]["VIGENCIA_CONTRATO"] = "INDETERMINADO";
                $dados_minuta["FATURAMENTO"]["VIGENCIA_CONTRATO_EXTENSO"] = "";
            } else {
                $dados_minuta["FATURAMENTO"]["VIGENCIA_CONTRATO"] = strtoupper(str_replace("meses", "", $faturamento[0]->duracao_contrato));
                $dados_minuta["FATURAMENTO"]["VIGENCIA_CONTRATO_EXTENSO"] = "(" . Extenso::converte(str_replace("meses", "", $faturamento[0]->duracao_contrato), false, false) . ") meses";
            }

            $dados_minuta["FATURAMENTO"]["INDICE_REAJUSTE"] = strtoupper($faturamento[0]->reajuste);
            $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS"] = $faturamento[0]->percentual_juros . "%";
            $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"] = "(" . Extenso::converte($faturamento[0]->percentual_juros, false, false) . " porcento)";
            $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA"] = $faturamento[0]->percentual_multa . "%";
            $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"] = "(" . Extenso::converte($faturamento[0]->percentual_multa, false, false) . " porcento)";

            if ($cod_produto != "ADM0001") {
                $empresa = json_decode($this->controller->modelo->empresaVendedora(null, true));
            } else {
                $empresa = json_decode($this->controller->modelo->empresaVendedora(null, true));
            }

            if (isset($empresa) && !empty($empresa)) {
                foreach ($empresa as $key => $value) {
                    $dados_minuta["FATURAMENTO"]["CM"]      = $value->razao_social;
                    $dados_minuta["FATURAMENTO"]["CM_CNPJ"] = formatarString("cnpj", $value->cnpj);
                }
            }
        }

         switch ($cod_produto) {
                case 'RCK0001':
                    $pacote_engine = json_decode($this->controller->modelo->getPacotePropostas($contrato[0]->id_proposta, 13, 8));
                    if (isset($pacote_engine) && !empty($pacote_engine)) {
                        $dados_minuta["FATURAMENTO"]["TRANSACOES_ENGINE"] = funcValor($pacote_engine[0]->quantidade_garantido, 'C', 0);
                        $dados_minuta["FATURAMENTO"]["TRANSACOES_ENGINE_EXTENSO"] = "( " . Extenso::converte($pacote_engine[0]->quantidade_garantido, false, true) . " )";
                    }
                    break;
                case 'FSP0001':
                    $modulos_proposta = json_decode($this->controller->modelo->getPropostasModuloByIdProposta($contrato[0]->id_proposta));
                    if (isset($modulos_proposta) && is_array($modulos_proposta)) {
                        foreach ($modulos_proposta as $key => $value) {
                            if ($value->cod_modulo == "ASSTR001" && $value->deleted == 0) {
                                $modulo["assessoria_str"] = true;
                            }
                            if ($value->cod_modulo == "ASPIX001" && $value->deleted == 0) {
                                $modulo["assessoria_pix"] = true;
                            }
                        }

                        if (isset($modulo["assessoria_str"]) && $modulo["assessoria_str"] == true) {
                            $cod_modulo = "STR0003";
                            $assessoria_bacen = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "FSP0001", $cod_modulo));
                            if (isset($assessoria_bacen) && !empty($assessoria_bacen)) {
                                $assessoria_str = funcValor($assessoria_bacen[0]->valor_real, 'C', 2);
                                if ($faturamento[0]->parcelas == "1") {
                                    $dados_minuta["FATURAMENTO"]["ASSESSORIA_BACEN"] .= "• O valor da Assessoria BACEN para emissão do ISPB é de <b> R$ " . $assessoria_str . " (" . Extenso::converte($assessoria_str, false, false) . ")</b>, que será pago em até 10 (dez) dias após a assinatura do presente contrato.";
                                } else if ($faturamento[0]->parcelas == "2") {
                                    $dados_minuta["FATURAMENTO"]["ASSESSORIA_BACEN"] .= "• O valor da Assessoria BACEN para emissão do ISPB é de <b> R$ " . $assessoria_str . " (" . Extenso::converte($assessoria_str, false, false) . ")</b>, que serão pagos em 2 (duas) parcelas iguais e consecutivas
                                        sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela.";
                                } else {
                                    $dados_minuta["FATURAMENTO"]["ASSESSORIA_BACEN"] .= "• O valor da Assessoria BACEN para emissão do ISPB é de <b> R$ " . $assessoria_str . " (" . Extenso::converte($assessoria_str, false, false) . ")</b>, que serão pagos em 3 (duas) parcelas iguais e consecutivas
                                        sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela e a terceira parcela
                                        com vencimento em 30 (trinta) dias após o vencimento da segunda parcela.";
                                }
                            }
                        }
                        if (!isset($dados_minuta["FATURAMENTO"]["ASSESSORIA_BACEN"])) {
                            $dados_minuta["FATURAMENTO"]["ASSESSORIA_BACEN"] = "";
                        }

                        if (isset($modulo["assessoria_pix"]) && $modulo["assessoria_pix"] == true) {
                            $cod_modulo = "STR0002";
                            $assessoria_pix = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "FSP0001", $cod_modulo));
                            if (isset($assessoria_pix) && !empty($assessoria_pix)) {
                                $implantacao_pix = funcValor($assessoria_pix[0]->valor_real, 'C', 2);
                                if ($faturamento[0]->parcelas == "1") {
                                    $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"] .= "• O valor da Assessoria PIX é de <b> R$ " . $implantacao_pix . " (" . Extenso::converte($implantacao_pix, false, false) . ")</b>, que será pago em até 10 (dez) dias após a assinatura do presente contrato.";
                                } else if ($faturamento[0]->parcelas == "2") {
                                    $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"] .= "• O valor da Assessoria PIX é de <b> R$ " . $implantacao_pix . " (" . Extenso::converte($implantacao_pix, false, false) . ")</b>, que serão pagos em 2 (duas) parcelas iguais e consecutivas
                                        sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela.";
                                } else {
                                    $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"] .= "• O valor da Assessoria PIX é de <b> R$ " . $implantacao_pix . " (" . Extenso::converte($implantacao_pix, false, false) . ")</b>, que serão pagos em 3 (duas) parcelas iguais e consecutivas
                                        sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela e a terceira parcela
                                        com vencimento em 30 (trinta) dias após o vencimento da segunda parcela.";
                                }
                            }
                        }
                        if (!isset($dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"])) {
                            $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"] = "";
                        }
                    }

                    $hora_homem = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "FSP0001", "PIX0019"));
                    if (isset($hora_homem) && !empty($hora_homem)) {
                        $dados_minuta["FATURAMENTO"]["HORA_HOMEM"] = funcValor($hora_homem[0]->valor_real, 'C', 2);
                    }

                    $pacote_full = json_decode($this->controller->modelo->getPacotePropostas($contrato[0]->id_proposta, 2000000, 2000000, null, "ASC"));
                    $lp['full_str_web'] = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "FSP0001", "STR0001"));
                    if (isset($pacote_full)) {
                        $contador_pacote = 1;
                        $dados_minuta["VALORES"]["PACOTE_FULL"] =
                            "<table class='table_lp'>
                                    <tr class='tr_table'>
                                        <th id='titulo' class='th_table'>Pacote</th>
                                        <th class='th_table'>Mensagens</th>
                                        <th class='th_table'>Mensalidade</th>
                                        <th class='th_table'>Excedente</th>
                                    </tr>";
                        foreach ($pacote_full as $key => $value) {
                            $dados_minuta["VALORES"]["PACOTE_FULL"] .=
                                "<tr>
                                        <td class='td_table'><b>  PACOTE $contador_pacote </b></td>
                                        <td class='td_table'><b>" . funcValor($value->quantidade_garantido, 'C', 0) . "</b></td>
                                        <td class='td_table'> R$ " . funcValor($value->preco_pkt, 'C', 2) . "</td>
                                        <td class='td_table'> R$ " . funcValor($value->valor_excedente, 'C', 6) . "</td>
                                    </tr>";
                            $contador_pacote++;
                        }
                        $dados_minuta["VALORES"]["PACOTE_FULL"] .= "</table>";
                    } else {
                        $pacote_opcional = json_decode($this->controller->modelo->getPacoteOpcional("FSP0001"));
                        if (isset($pacote_opcional)) {
                            $dados_minuta["VALORES"]["PACOTE_FULL"] = "
                                <table class='table_lp'>
                                    <tr class='tr_table'>
                                        <th id='titulo' class='th_table'>Pacote</th>
                                        <th class='th_table'>Mensagens</th>
                                        <th class='th_table'>Mensalidade</th>
                                        <th class='th_table'>Excedente</th>
                                    </tr>";
                            foreach ($pacote_opcional as $key => $value) {
                                $dados_minuta["VALORES"]["PACOTE_FULL"] .= "
                                            <tr>
                                                <td id='titulo' class='td_table'><b>" . strtoupper($value->modulo) . "</b></td>
                                                <td class='td_table'><b>" . funcValor($value->quantidade_garantido, 'C', 0) . "</b></td>
                                                <td class='td_table'>" . funcValor($value->preco_pkt, 'C', 2) . "</td>
                                                <td class='td_table'>" . funcValor($value->excedente, 'C', 6) . "</td>
                                            </tr>    
                                        ";
                            }
                            $dados_minuta["VALORES"]["PACOTE_FULL"] .= "
                                </table>";
                        } else {
                            $dados_minuta["VALORES"]["PACOTE_FULL"] = "
                                <table class='table_lp'>
                                    <tr class='tr_table'>
                                        <th id='titulo' class='th_table'>Pacote</th>
                                        <th class='th_table'>Mensagens</th>
                                        <th class='th_table'>Mensalidade</th>
                                        <th class='th_table'>Excedente</th>
                                    </tr>
                                    <tr>
                                        <td id='titulo' class='td_table'><b>PACOTE 1</b></td>
                                        <td class='td_table'><b>" . $this->dicionario['PACOTE_FULL']['PACOTE_1']['MENSAGENS'] . "</b></td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_1']['MENSALIDADE'] . "</td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_1']['EXCEDENTE'] . "</td>
                                    </tr>
                                    <tr>
                                        <td id='titulo' class='td_table'><b>PACOTE 2</b></td>
                                        <td class='td_table'><b>" . $this->dicionario['PACOTE_FULL']['PACOTE_2']['MENSAGENS'] . "</b></td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_2']['MENSALIDADE'] . "</td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_2']['EXCEDENTE'] . "</td>
                                    </tr>
                                    <tr>
                                        <td id='titulo' class='td_table'><b>PACOTE 3</b></td>
                                        <td class='td_table'><b>" . $this->dicionario['PACOTE_FULL']['PACOTE_3']['MENSAGENS'] . "</b></td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_3']['MENSALIDADE'] . "</td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_3']['EXCEDENTE'] . "</td>
                                    </tr>
                                    <tr>
                                        <td id='titulo' class='td_table'><b>PACOTE 4</b></td>
                                        <td class='td_table'><b>" . $this->dicionario['PACOTE_FULL']['PACOTE_4']['MENSAGENS'] . "</b></td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_4']['MENSALIDADE'] . "</td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_4']['EXCEDENTE'] . "</td>
                                    </tr>
                                    <tr>
                                        <td id='titulo' class='td_table'><b>PACOTE 5</b></td>
                                        <td class='td_table'><b>" . $this->dicionario['PACOTE_FULL']['PACOTE_5']['MENSAGENS'] . "</b></td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_5']['MENSALIDADE'] . "</td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_5']['EXCEDENTE'] . "</td>
                                    </tr>
                                </table>
                                ";
                        }
                    }

                    $valores_base_lp['debito']  = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "FSP0001", "PIX0016"));
                    $valores_base_lp['credito'] = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "FSP0001", "PIX0012"));
                    if (isset($valores_base_lp['debito']) && isset($valores_base_lp['credito'])) {
                        $dados_minuta["VALORES"]["VALORES_BASE_TARIFACAO"] = "                        
                            <table class='table_lp'>                           
                                <tr>
                                    <td class='td_color'>Crédito do CLIENTE:</td>
                                    <td class='td_table'><b> R$ " . funcValor($valores_base_lp['credito'][0]->valor_real, 'C', 6) . "</b></td>
                                    <td class='td_color'>Debito do CLIENTE:</td>
                                    <td class='td_table'><b> R$ " . funcValor($valores_base_lp['debito'][0]->valor_real, 'C', 6) . "</b></td>
                                </tr>
                            </table>
                            ";
                    }
                    break;
                case "SPI0001":
                    $modulo_proposta    = json_decode($this->controller->modelo->getPropostasModuloByIdProposta($contrato[0]->id_proposta, "ASPIX001", 0));
                    if (isset($modulo_proposta) && !empty($modulo_proposta)) {
                        $assessoria_pix = json_decode($this->controller->modelo->getLpByCodigo("SPI0001", "SPI0024"));
                        if (isset($assessoria_pix) && !empty($assessoria_pix)) {
                            $implantacao_assessoria = funcValor($assessoria_pix[0]->valor_real, 'C', 2);
                        } else {
                            $implantacao_assessoria = $this->dicionario["TEXTO_SLIDE"]["ASSESSORIA"]["ASSESSORIA_PIX"];
                        }
                        if (isset($implantacao_assessoria) && !empty($implantacao_assessoria)) {
                            if ($faturamento[0]->parcelas == "1") {
                                $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"] .= "O valor da assessoria pix é de <b> R$ " . $implantacao_assessoria . " (" . Extenso::converte($implantacao_assessoria, false, false) . ") </b>, que será pago em até 10 (dez) dias após a assinatura do presente contrato.";
                            } else if ($faturamento[0]->parcelas == "2") {
                                $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"] .= "O valor da assessoria pix é de <b> R$ " . $implantacao_assessoria . " (" . Extenso::converte($implantacao_assessoria, false, false) . ") </b>, que serão pagos em 2 (duas) parcelas iguais e consecutivas
                                    sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela.";
                            } else {
                                $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"] .= "O valor da assessoria pix é de <b> R$ " . $implantacao_assessoria . " (" . Extenso::converte($implantacao_assessoria, false, false) . ") </b>, que serão pagos em 3 (duas) parcelas iguais e consecutivas
                                    sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela e a terceira parcela
                                    com vencimento em 30 (trinta) dias após o vencimento da segunda parcela.";
                            }
                        }
                    }
                    if (!isset($dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"])) {
                        $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"] = "";
                    }

                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS"]         = $faturamento[0]->percentual_juros . "%";
                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA"]         = $faturamento[0]->percentual_multa . "%";
                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->percentual_juros, false, false) . " por cento)";
                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->percentual_multa, false, false) . " por cento)";
                    $valores_base_lp['debito']  = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "SPI0001", "SPI0010"));
                    $valores_base_lp['credito'] = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "SPI0001", "SPI0016"));
                    if (isset($valores_base_lp['debito']) && isset($valores_base_lp['credito'])) {
                        $dados_minuta["VALORES"]["VALORES_BASE_TARIFACAO"] = "                 
                                <ul> Valor Integral da transação a Crédito do <b>CLIENTE</b> = " . funcValor($valores_base_lp['credito'][0]->valor_real, 'C', 6) . " </ul>
                                <ul> Valor Integral da transação a Débito do <b>CLIENTE</b> = " . funcValor($valores_base_lp['debito'][0]->valor_real, 'C', 6) . " </ul>                          
                            ";
                    }
                    break;
                case 'YLW0001':
                    // $dados_minuta["FATURAMENTO"]["DURACAO_CONTRATO"]         = str_replace("meses","",$faturamento[0]->duracao_contrato);
                    // $dados_minuta["FATURAMENTO"]["DURACAO_CONTRATO_EXTENSO"] = "(".Extenso::converte($dados_minuta["FATURAMENTO"]["DURACAO_CONTRATO"],false,false).") meses";       
                    $valores_lp = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "YLW0001"));
                    if (isset($valores_lp) && is_array($valores_lp)) {
                        foreach ($valores_lp as $key => $value) {
                            switch ($value->cod_modulo) {
                                case 'YLW0018':
                                    $dados_minuta["VALORES"]['ATIVACAO']         = funcValor($value->valor_real, 'C', 2);
                                    $dados_minuta["VALORES"]['ATIVACAO_EXTENSO'] = "(" . Extenso::converte($dados_minuta["VALORES"]['ATIVACAO'], true, false) . ")";
                                    break;
                                case 'YLW0013':
                                    $dados_minuta["VALORES"]['MANUTENCAO']         = funcValor($value->valor_real, 'C', 2);
                                    $dados_minuta["VALORES"]['MANUTENCAO_EXTENSO'] = "(" . Extenso::converte($dados_minuta["VALORES"]['MANUTENCAO'], true, false) . ")";
                                    break;
                                case 'YLW0012':
                                    $lp_royalty[] = $value;
                                    break;
                                case 'YLW0017':
                                    $dados_minuta["VALORES"]["BAIXA_PAGAMENTO"]           = funcValor($value->valor_real, 'C', 2);
                                    $dados_minuta["VALORES"]["BAIXA_PAGAMENTO_EXTENSO"]   = "(" . Extenso::converte($dados_minuta["VALORES"]["BAIXA_PAGAMENTO"], true, false) . ")";
                                    break;
                                case 'YLW0016':
                                    $dados_minuta["VALORES"]["CORNER_PIX"]         = funcValor($value->valor_real, 'C', 2);
                                    $dados_minuta["VALORES"]["CORNER_PIX_EXTENSO"] = "(" . Extenso::converte($dados_minuta["VALORES"]["CORNER_PIX"], true, false) . ")";
                                    break;
                                case 'YLW0015':
                                    $dados_minuta["VALORES"]["MARKETING_COOPERADO"] = funcValor($value->valor_real, 'C', 2);
                                    $dados_minuta["VALORES"]["MARKETING_COOPERADO_EXTENSO"] = "(" . Extenso::converte($dados_minuta["VALORES"]["MARKETING_COOPERADO"], false, false) . ")";
                                    break;
                                case 'YLW0014':
                                    $dados_minuta["VALORES"]["PORTAL_EMISSOR"] = funcValor($value->valor_real, 'C', 2);
                                    $dados_minuta["VALORES"]["PORTAL_EMISSOR_EXTENSO"] = "(" . Extenso::converte($dados_minuta["VALORES"]["PORTAL_EMISSOR"], false, false) . ")";
                                    break;
                                case 'YLW0011':
                                    $dados_minuta["VALORES"]["API_YELLOW"] = funcValor($value->valor_real, 'C', 2);
                                    $dados_minuta["VALORES"]["API_YELLOW_EXTENSO"] = "(" . Extenso::converte($dados_minuta["VALORES"]["API_YELLOW"], true, false) . ")";
                                    break;
                                default:
                                    # code...
                                    break;
                            }
                        }
                    }

                    if (isset($lp_royalty) && is_array($lp_royalty)) {
                        foreach ($lp_royalty as $key => $value) {
                            if ($value->qtd_de == 1) {
                                $dados_minuta["VALORES"]["ROYALTY_SILVER"]           = funcValor($value->percentual, 'C', 2) . "%";
                                $dados_minuta["VALORES"]["ROYALTY_SILVER_TRANSACAO"] = funcValor($value->qtd_ate, 'C', 0);
                            }
                        }
                    }
                    if (isset($dados_minuta["VALORES"]['ATIVACAO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['ATIVACAO'], $dados_minuta["VALORES"]['ATIVACAO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['ATIVACAO_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['ATIVACAO_EXTENSO'], $dados_minuta["VALORES"]['ATIVACAO_EXTENSO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['MANUTENCAO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['MANUTENCAO_CONTA'], $dados_minuta["VALORES"]['MANUTENCAO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['MANUTENCAO_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['MANUTENCAO_CONTA_EXTENSO'], $dados_minuta["VALORES"]['MANUTENCAO_EXTENSO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['ROYALTY_SILVER'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['PORCENTAGEM_SILVER'], $dados_minuta["VALORES"]['ROYALTY_SILVER'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['ROYALTY_SILVER_TRANSACAO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['TRANSACAO_SILVER'], $dados_minuta["VALORES"]['ROYALTY_SILVER_TRANSACAO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['BAIXA_PAGAMENTO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['BAIXA_PAGAMENTO'], $dados_minuta["VALORES"]['BAIXA_PAGAMENTO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['BAIXA_PAGAMENTO_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['BAIXA_PAGAMENTO_EXTENSO'], $dados_minuta["VALORES"]['BAIXA_PAGAMENTO_EXTENSO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['CORNER_PIX'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['CORNER_PIX'], $dados_minuta["VALORES"]['CORNER_PIX'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['CORNER_PIX_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['CORNER_PIX_EXTENSO'], $dados_minuta["VALORES"]['CORNER_PIX_EXTENSO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['MARKETING_COOPERADO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['MARKETING_COOPERADO'], $dados_minuta["VALORES"]['MARKETING_COOPERADO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['MARKETING_COOPERADO_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['MARKETING_COOPERADO_EXTENSO'], $dados_minuta["VALORES"]['MARKETING_COOPERADO_EXTENSO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['PORTAL_EMISSOR'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['PORTAL_EMISSOR'], $dados_minuta["VALORES"]['PORTAL_EMISSOR'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['PORTAL_EMISSOR_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['PORTAL_EMISSOR_EXTENSO'], $dados_minuta["VALORES"]['PORTAL_EMISSOR_EXTENSO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['API_YELLOW'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['API_YELLOW'], $dados_minuta["VALORES"]['API_YELLOW'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['API_YELLOW_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['API_YELLOW_EXTENSO'], $dados_minuta["VALORES"]['API_YELLOW_EXTENSO'], $texto);
                    }


                    // if(isset($dados_minuta["FATURAMENTO"]["DURACAO_CONTRATO"])){
                    //     $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["DURACAO_CONTRATO"],$dados_minuta["FATURAMENTO"]["DURACAO_CONTRATO"],$texto);
                    // }
                    // if(isset($dados_minuta["FATURAMENTO"]["DURACAO_CONTRATO_EXTENSO"])){
                    //     $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["DURACAO_CONTRATO_EXTENSO"],$dados_minuta["FATURAMENTO"]["DURACAO_CONTRATO_EXTENSO"],$texto);
                    // }

                    break;
                case 'CRY0001':
                    $lp_crystal = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "CRY0001"));
                    if (isset($lp_crystal) && is_array($lp_crystal)) {
                        foreach ($lp_crystal as $key => $value) {
                            if ($value->cod_modulo == "CRY0011") {
                                $dados_minuta["VALORES"]['OPEN_BANKING']         = funcValor($value->valor_real, 'C', 2);
                                $dados_minuta["VALORES"]['OPEN_BANKING_EXTENSO'] = "(" . Extenso::converte($dados_minuta["VALORES"]['OPEN_BANKING'], true, false) . ")";
                                $dados_minuta["VALORES"]['OPEN_BANKING']         = "R$ " . $dados_minuta["VALORES"]['OPEN_BANKING'];
                            } else if ($value->cod_modulo == "CRY0012") {
                                $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA']         = funcValor($value->valor_real, 'C', 2);
                                $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA_EXTENSO'] = "(" . Extenso::converte($dados_minuta["VALORES"]['TRANSACAO_EXECUTADA'], true, false) . ")";
                                $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA']         = "R$ " . $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA'];
                            }
                        }
                    }

                    if (isset($dados_minuta["VALORES"]['TRANSACAO_EXECUTADA'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CRYSTAL"]['TRANSACAO_EXECUTADA'], $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['TRANSACAO_EXECUTADA_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CRYSTAL"]['TRANSACAO_EXECUTADA_EXTENSO'], $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA_EXTENSO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['OPEN_BANKING'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CRYSTAL"]['OPEN_BANKING'], $dados_minuta["VALORES"]['OPEN_BANKING'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['OPEN_BANKING_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CRYSTAL"]['OPEN_BANKING_EXTENSO'], $dados_minuta["VALORES"]['OPEN_BANKING_EXTENSO'], $texto);
                    }
                    break;
                case 'SOE0001':
                    $modulo_proposta    = json_decode($this->controller->modelo->getPropostasModuloByIdProposta($contrato[0]->id_proposta, "ASSTR001", 0));
                    if (isset($modulo_proposta) && !empty($modulo_proposta)) {
                        $assessoria_str = json_decode($this->controller->modelo->getLpByCodigo("SOE0001", "ASSTR001"));
                        if (isset($assessoria_str) && !empty($assessoria_str)) {
                            $implantacao_assessoria = funcValor($assessoria_str[0]->valor_real, 'C', 2);
                        } else {
                            $implantacao_assessoria = $this->dicionario["TEXTO_SLIDE"]["ASSESSORIA"]["ASSESSORIA_STR"];
                        }
                        if (isset($implantacao_assessoria) && !empty($implantacao_assessoria)) {
                            if ($faturamento[0]->parcelas == "1") {
                                $dados_minuta["FATURAMENTO"]["ASSESSORIA_STR"] .= "• O valor da Assessoria BACEN para emissão do ISPB é de <b>  " . $implantacao_assessoria . " (" . Extenso::converte($implantacao_assessoria, false, false) . ")</b>, que será pago em até 10 (dez) dias após a assinatura do presente contrato.";
                            } else if ($faturamento[0]->parcelas == "2") {
                                $dados_minuta["FATURAMENTO"]["ASSESSORIA_STR"] .= "• O valor da Assessoria BACEN para emissão do ISPB é de <b> " . $implantacao_assessoria . " (" . Extenso::converte($implantacao_assessoria, false, false) . ")</b>, que serão pagos em 2 (duas) parcelas iguais e consecutivas
                                    sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela.";
                            } else {
                                $dados_minuta["FATURAMENTO"]["ASSESSORIA_STR"] .= "• O valor da Assessoria BACEN para emissão do ISPB é de <b>  " . $implantacao_assessoria . " (" . Extenso::converte($implantacao_assessoria, false, false) . ")</b>, que serão pagos em 3 (duas) parcelas iguais e consecutivas
                                    sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela e a terceira parcela
                                    com vencimento em 30 (trinta) dias após o vencimento da segunda parcela.";
                            }
                        }
                    } else {
                        $dados_minuta["FATURAMENTO"]["ASSESSORIA_STR"] = "";
                    }

                    $lp_spbx = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "SOE0001"));
                    if (isset($lp_spbx) && is_array($lp_spbx)) {
                        foreach ($lp_spbx as $key => $value) {
                            if ($value->cod_modulo == "SOE0015") {
                                $dados_minuta["VALORES"]["TRATAMENTO_INCONSISTENCIA"] = funcValor($value->valor_real, "C", 3);
                            }
                            if ($value->cod_modulo == "SOE0013") {
                                $dados_minuta["VALORES"]["BAIXA_COMPE"]     = funcValor($value->valor_real, "C", 3);
                            }
                            if ($value->cod_modulo == "SOE0016") {
                                $dados_minuta["VALORES"]["WEBSERVICE"]      = funcValor($value->valor_real, "C", 3);
                            }
                            if ($value->cod_modulo == "SOE0017") {
                                $dados_minuta["VALORES"]["LOTE_ARQUIVO"]    = funcValor($value->valor_real, "C", 3);
                            }
                            if ($value->cod_modulo == "SOE0023") {
                                $dados_minuta["VALORES"]["DEBITO_CLIENTE"]  = funcValor($value->valor_real, "C", 6);
                            }
                            if ($value->cod_modulo == "SOE0018") {
                                $dados_minuta["VALORES"]["CREDITO_CLIENTE"] = funcValor($value->valor_real, "C", 6);
                            }
                            if ($value->cod_modulo == "SOE0033") {
                                $dados_minuta["VALORES"]["HORA_HOMEM"]      = funcValor($value->valor_real, "C", 6);
                            }
                            if ($value->cod_modulo == "PIX0019") {
                                $dados_minuta["VALORES"]["HORA_HOMEM"]      = funcValor($value->valor_real, "C", 6);
                            }
                            if ($value->cod_modulo == "SOE0010") {
                                $lp['spbx'][] = $value;
                            }
                        }
                    }
                    if (isset($lp['spbx']) && !empty($lp['spbx'])) {
                        sort($lp['spbx']);
                        $table_lp = $this->gerarTableHtml($cod_produto, $lp['spbx']);
                    }

                    $pacote = json_decode($this->controller->modelo->getPacotePropostas($contrato[0]->id_proposta, 22, 103));
                    if (isset($pacote) && !empty($pacote)) {
                        if (isset($pacote) && !empty($pacote)) {
                            $dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB"]         = funcValor($pacote[0]->quantidade_garantido, 'C', 0);
                            $dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB_EXTENSO"] = "( " . Extenso::converte($pacote[0]->quantidade_garantido, false, false) . " )";
                            $dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB"]              = "R$ " . funcValor($pacote[0]->preco_pkt, 'C', 2);
                            $dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB_EXTENSO"]      = "( " . Extenso::converte(funcValor($pacote[0]->preco_pkt, 'C', 2), true, false) . " )";
                        }
                    } else {
                        $pacote_default = json_decode($this->controller->modelo->getPacoteDefault(22, 103));
                        if (isset($pacote_default) && !empty($pacote_default)) {
                            $dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB"]         = funcValor($pacote_default[0]->qdt_garantido, 'C', 0);
                            $dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB_EXTENSO"] = "( " . Extenso::converte($pacote_default[0]->qdt_garantido, false, false) . " )";
                            $dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB"]              = "R$ " . funcValor($pacote_default[0]->preco_pkt, 'C', 2);
                            $dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB_EXTENSO"]      = "( " . Extenso::converte(funcValor($pacote_default[0]->preco_pkt, 'C', 2), true, false) . " )";
                        } else {
                            $dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB"]         = "6.000";
                            $dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB_EXTENSO"] = "( seis mil )";
                            $dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB"]              = "R$ 20.000,00";
                            $dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB_EXTENSO"]      = "( vinte mil reais )";
                        }
                    }

                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS"]         = $faturamento[0]->percentual_juros . "%";
                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA"]         = $faturamento[0]->percentual_multa . "%";
                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->percentual_juros, false, false) . " por cento)";
                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->percentual_multa, false, false) . " por cento)";

                    if (isset($dados_minuta["VALORES"]["TRATAMENTO_INCONSISTENCIA"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['TRATAMENTO_INCONSISTENCIA'], $dados_minuta["VALORES"]["TRATAMENTO_INCONSISTENCIA"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["BAIXA_COMPE"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['BAIXA_COMPE'], $dados_minuta["VALORES"]["BAIXA_COMPE"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["WEBSERVICE"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['WEBSERVICE'], $dados_minuta["VALORES"]["WEBSERVICE"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["LOTE_ARQUIVO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['LOTE_ARQUIVO'], $dados_minuta["VALORES"]["LOTE_ARQUIVO"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["DEBITO_CLIENTE"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['DEBITO_CLIENTE'], $dados_minuta["VALORES"]["DEBITO_CLIENTE"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["CREDITO_CLIENTE"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['CREDITO_CLIENTE'], $dados_minuta["VALORES"]["CREDITO_CLIENTE"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["HORA_HOMEM"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['HORA_HOMEM'], $dados_minuta["VALORES"]["HORA_HOMEM"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['TRANSACOES_PACOTE_SPB'], $dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['TRANSACOES_PACOTE_SPB_EXTENSO'], $dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB_EXTENSO"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['VALOR_PACOTE_SPB'], $dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['VALOR_PACOTE_SPB_EXTENSO'], $dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB_EXTENSO"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['PERCENTUAL_JUROS'], $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['PERCENTUAL_MULTA'], $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['PERCENTUAL_JUROS_EXTENSO'], $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['PERCENTUAL_MULTA_EXTENSO'], $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"], $texto);
                    }
                    if (isset($table_lp) && !empty($table_lp)) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['TABLE'], $table_lp, $texto);
                    }
                    break;
                case 'ATF0001':
                    $lp_corner = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "ATF0001"));
                    if (isset($lp_corner) && is_array($lp_corner)) {
                        foreach ($lp_corner as $key => $value) {
                            if ($value->cod_modulo == "ATF0010") {
                                $dados_minuta["VALORES"]["VALOR_APROVADO"] = funcValor($value->valor_real, "C", 2);
                                $dados_minuta["VALORES"]["VALOR_APROVADO_EXTENSO"] = "( " . Extenso::converte(funcValor($value->valor_real, "C", 2), true, true) . " )";
                                $dados_minuta["VALORES"]["TRANSACAO_APROVADO"] = "10 (dez)";
                            }
                            if ($value->cod_modulo == "ATF0011") {
                                $dados_minuta["VALORES"]["VALOR_REPROVADO"] = funcValor($value->valor_real, "C", 2);
                                $dados_minuta["VALORES"]["VALOR_REPROVADO_EXTENSO"] = "( " . Extenso::converte(funcValor($value->valor_real, "C", 2), true, true) . " )";
                            }
                            if ($value->cod_modulo == "ATF0012") {
                                $dados_minuta["VALORES"]["VALOR_DETALHADO"] = funcValor($value->valor_real, "C", 2);
                                $dados_minuta["VALORES"]["VALOR_DETALHADO_EXTENSO"] = "( " . Extenso::converte(funcValor($value->valor_real, "C", 2), true, true) . " )";
                            }
                        }
                    }

                    $pacote = json_decode($this->controller->modelo->getPacotePropostas($contrato[0]->id_proposta, 3000000, 3000004));
                    if (isset($pacote) && !empty($pacote)) {
                        $dados_minuta["VALORES"]["PACOTE"] = funcValor($pacote[0]->preco_pkt, "C", 2);
                        $dados_minuta["VALORES"]["PACOTE_EXTENSO"] = "( " . Extenso::converte(funcValor($pacote[0]->preco_pkt, "C", 2), true, true) . " )";
                    }
                    if (isset($dados_minuta["VALORES"]["VALOR_APROVADO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]['VALOR_APROVADO'], $dados_minuta["VALORES"]["VALOR_APROVADO"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["VALOR_APROVADO_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]['VALOR_APROVADO_EXTENSO'], $dados_minuta["VALORES"]["VALOR_APROVADO_EXTENSO"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["TRANSACAO_APROVADO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]['TRANSACAO_APROVADO'], $dados_minuta["VALORES"]["TRANSACAO_APROVADO"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["VALOR_REPROVADO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]['VALOR_REPROVADO'], $dados_minuta["VALORES"]["VALOR_REPROVADO"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["VALOR_REPROVADO_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]['VALOR_REPROVADO_EXTENSO'], $dados_minuta["VALORES"]["VALOR_REPROVADO_EXTENSO"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["VALOR_DETALHADO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]['VALOR_DETALHADO'], $dados_minuta["VALORES"]["VALOR_DETALHADO"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["VALOR_DETALHADO_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]['VALOR_DETALHADO_EXTENSO'], $dados_minuta["VALORES"]["VALOR_DETALHADO_EXTENSO"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["PACOTE"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]["PACOTE"], $dados_minuta["VALORES"]["PACOTE"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["PACOTE_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]["PACOTE_EXTENSO"], $dados_minuta["VALORES"]["PACOTE_EXTENSO"], $texto);
                    }
                    break;
                case 'TPX0001':
                    $lp_triplo_pix = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "TPX0001"));
                    if (isset($lp_triplo_pix) && is_array($lp_triplo_pix)) {
                        foreach ($lp_triplo_pix as $key => $value) {
                            if ($value->cod_modulo == "TPX0011") {
                                $dados_minuta["VALORES"]["LP_TRIPLO_PIX"] = "R$ " . funcValor($value->valor_real, "C", 2);
                                $dados_minuta["VALORES"]["LP_TRIPLO_PIX_EXTENSO"] = "( " . Extenso::converte(funcValor($value->valor_real, "C", 2), true, true) . " )";
                            }
                        }
                    }
                    if (isset($dados_minuta["VALORES"]["LP_TRIPLO_PIX"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["TRIPLO_PIX"]['TRIPLO_PIX'], $dados_minuta["VALORES"]["LP_TRIPLO_PIX"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["LP_TRIPLO_PIX_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["TRIPLO_PIX"]['TRIPLO_PIX_EXTENSO'], $dados_minuta["VALORES"]["LP_TRIPLO_PIX_EXTENSO"], $texto);
                    }
                    break;
                case 'ECS0001':
                    $pacote_ecs = json_decode($this->controller->modelo->getPacotePropostas($contrato[0]->id_proposta, 21, 94));
                    if (isset($pacote_ecs) && !empty($pacote_ecs)) {
                        $dados_minuta["VALORES"]["PACOTE_ECS"] = "R$ " . funcValor($pacote_ecs[0]->preco_pkt, "C", 2);
                        $dados_minuta["VALORES"]["PACOTE_ECS_EXTENSO"] = "( " . Extenso::converte(funcValor($pacote_ecs[0]->preco_pkt, 'C', 2), true, false) . " )";
                    } else {
                        $lp_ecs = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "ECS0001"));
                        foreach ($lp_ecs as $key => $value) {
                            if ($value->cod_modulo == "ECS0011") {
                                $dados_minuta["VALORES"]["PACOTE_ECS"] = "R$ " . funcValor($value->valor_real, "C", 2);
                                $dados_minuta["VALORES"]["PACOTE_ECS_EXTENSO"] = "( " . Extenso::converte(funcValor($value->valor_real, "C", 2), true, true) . " )";
                            }
                        }
                    }

                    if (isset($dados_minuta["VALORES"]["PACOTE_ECS"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["ECS"]['PACOTE'], $dados_minuta["VALORES"]["PACOTE_ECS"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["PACOTE_ECS_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["ECS"]['PACOTE_EXTENSO'], $dados_minuta["VALORES"]["PACOTE_ECS_EXTENSO"], $texto);
                    }

                    break;
                case 'ADM0001':
                    $hora_homem = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "RCK0001", "RCK0052"));
                    if (isset($hora_homem) && !empty($hora_homem)) {
                        $dados_minuta["FATURAMENTO"]["HORA_HOMEM"] = funcValor($hora_homem[0]->valor_real, 'C', 2);
                        $dados_minuta["FATURAMENTO"]["HORA_HOMEM_EXTENSO"] = "( " . Extenso::converte($dados_minuta["FATURAMENTO"]["HORA_HOMEM"], true, true) . " )";
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["HORA_HOMEM"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]['HORA_HOMEM'], $dados_minuta["FATURAMENTO"]["HORA_HOMEM"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["HORA_HOMEM_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]['HORA_HOMEM_EXTENSO'], $dados_minuta["FATURAMENTO"]["HORA_HOMEM_EXTENSO"], $texto);
                    }
                    break;
                default:
                    //default                   
                    break;
            }


    }

    function gerarPDF_default($produto, $id_contrato, $id_proposta, $texto)
    {
        if (! $texto) {
            return false;
        }

        try {

            // $texto = json_decode($this->controller->modelo->getTextoMinuta($id_contrato));
            // if (!isset($texto)) {
            //     $texto = json_decode($this->model_modelo->getModelo($produto));
            //     if (!isset($texto)) {
            //         $texto = $this->gerarTexto($produto);
            //         if (isset($texto) && is_array($texto)) {
            //             foreach ($texto as $key => $value) {
            //                 $lp[$key]->texto = $value;
            //             }
            //             $texto = $lp;
            //         }
            //     }
            // }

            if ($produto == "ADM0001") {
                $ged = json_decode($this->controller->modelo->gedDocumentoAnexo2($id_contrato, 'customizacao'));
            } else {
                $ged = json_decode($this->controller->modelo->gedDocumentoAnexo2($id_contrato, 'minuta'));
            }

            $path         = $ged[0]->path_objeto;
            $nome_arquivo = $ged[0]->nome_hash;
            $path_full    = PATH_MINUTA . DS . $path . $nome_arquivo;
            if (!is_dir(PATH_MINUTA)) {
                mkdir(PATH_MINUTA);
            }

            if (!is_dir(PATH_MINUTA . DS . $path)) {
                mkdir(PATH_MINUTA . DS . $path);
            }

            $lp     = json_decode($this->controller->modelo->getLpPropostaByCodigo($produto, null, $id_proposta));
            $pacote = json_decode($this->controller->modelo->getPacotePropostas($id_proposta));
            switch ($produto) {
                case 'RCK0001':
                    $pdf = $this->pdfRocket($texto, $path_full, $id_contrato, $lp, $pacote);
                    break;
                case 'FSP0001':
                    $pdf = $this->pdfFull($texto, $path_full, $id_contrato, $lp, $pacote);
                    break;
                case 'SPI0001':
                    $pdf = $this->pdfSPIx($texto, $path_full, $id_contrato, $lp, $pacote);
                    break;
                case 'YLW0001':
                    $pdf = $this->pdfYellow($texto, $path_full, $id_contrato, $lp, $pacote);
                    break;
                case 'CRY0001':
                    $pdf = $this->pdfCrystalAMC($texto, $path_full, $id_contrato, $lp, $pacote);
                    break;
                case 'CRY0002':
                    $pdf = $this->pdfCrystalCertificate($texto, $path_full, $id_contrato, $lp, $pacote);
                    break;
                case 'CRY0003':
                    $pdf = $this->pdfCrystalBMC($texto, $path_full, $id_contrato, $lp, $pacote);
                    break;
                case 'CPA0001':
                    $pdf = $this->pdfPixAutomatico($texto, $path_full, $id_contrato, $lp, $pacote);
                    break;
                case 'SOE0001':
                    $pdf = $this->pdfSpbObe($texto, $path_full, $id_contrato, $lp, $pacote);
                    break;
                case 'ATF0001':
                    $pdf = $this->pdfCornerPix($texto, $path_full, $id_contrato, $lp, $pacote);
                    break;
                case 'TPX0001':
                    $pdf = $this->pdfTriploPix($texto, $path_full, $id_contrato, $lp, $pacote);
                    break;
                case 'ECS0001':
                    $pdf = $this->pdfECS($texto, $path_full, $id_contrato, $lp, $pacote);
                    break;
                case 'ADM0001':
                    $texto = json_decode($this->model_modelo->getModelo("ADM0001"));
                    $lp = json_decode($this->controller->modelo->getLpPropostaByCodigo('RCK0001', null, $id_proposta));
                    $pdf = $this->pdfCustomizacao($texto, $path_full, $id_contrato, $lp);
                    break;
                default:
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $produto;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Produto indefinido COD: 124";
                    throw new Exception(json_encode($retorno), 1);
                    break;
            }

            if (isset($pdf) && !empty($pdf)) {
                $file = is_file($path_full);
                if ($file == true) {
                    clearstatcache();
                }

                $retorno['codigo']   = 0;
                $retorno['input']    = $produto;
                $retorno['output']   = $pdf;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo']   = 1;
                $retorno['input']    = $produto;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro ao gerar PDF COD:144";
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    private function gerarTexto($produto)
    {
        $get_modelo = json_decode($this->model_modelo->getModelo($produto));
        switch ($produto) {
            case 'RCK0001':
                if (isset($get_modelo) && is_array($get_modelo)) {
                    foreach ($get_modelo as $key => $value) {
                        $texto[] = $value->texto;
                    }
                } else {
                    include "includes/texto_rocket.php";
                }
                break;
            case 'YLW0001':
                if (isset($get_modelo) && is_array($get_modelo)) {
                    foreach ($get_modelo as $key => $value) {
                        $texto[] = $value->texto;
                    }
                } else {
                    $lp_table = json_decode($this->model_produto->getLpByDefaultProduto(null, "YLW0001", "YLW0012"));
                    include "includes/texto_yellow.php";
                }
                break;
            case 'TPX0001':
                if (isset($get_modelo) && is_array($get_modelo)) {
                    foreach ($get_modelo as $key => $value) {
                        $texto[] = $value->texto;
                    }
                } else {
                    $lp_table = json_decode($this->model_produto->getLpByDefaultProduto(null, "YLW0001", "YLW0012"));
                    include "includes/texto_triplo_pix.php";
                }
                break;
            case 'CPA0001':
                if (isset($get_modelo) && is_array($get_modelo)) {
                    foreach ($get_modelo as $key => $value) {
                        $texto[] = $value->texto;
                    }
                } else {
                    include "includes/texto_pix_automatico.php";
                }
                break;
            case 'CRY0001':
                if (isset($get_modelo) && is_array($get_modelo)) {
                    foreach ($get_modelo as $key => $value) {
                        $texto[] = $value->texto;
                    }
                } else {
                    include "includes/texto_crystal.php";
                }
                break;
            case 'CRY0002':
                // if(isset($get_modelo) && is_array($get_modelo)){
                //     foreach ($get_modelo as $key => $value) {				
                //         $texto[] = $value->texto;					
                //     }
                // }else{
                //     include "includes/texto_crystal.php"; 
                // }
                break;
            case 'CRY0003':
                if (isset($get_modelo) && is_array($get_modelo)) {
                    foreach ($get_modelo as $key => $value) {
                        $texto[] = $value->texto;
                    }
                } else {
                    include "includes/texto_cry0003.php";
                }
                break;
            case 'ATF0001':
                if (isset($get_modelo) && is_array($get_modelo)) {
                    foreach ($get_modelo as $key => $value) {
                        $texto[] = $value->texto;
                    }
                } else {
                    include "includes/texto_corner_pix_antifraude.php";
                }
                break;
            case 'FSP0001':
                if (isset($get_modelo) && is_array($get_modelo)) {
                    foreach ($get_modelo as $key => $value) {
                        $texto[] = $value->texto;
                    }
                } else {
                    include "includes/texto_full.php";
                }
                break;
            case 'SPI0001':
                if (isset($get_modelo) && is_array($get_modelo)) {
                    foreach ($get_modelo as $key => $value) {
                        $texto[] = $value->texto;
                    }
                } else {
                    include "includes/texto_SPIx.php";
                }
                break;
            case 'SOE0001':
                if (isset($get_modelo) && is_array($get_modelo)) {
                    foreach ($get_modelo as $key => $value) {
                        $texto[] = $value->texto;
                    }
                } else {
                    include "includes/texto_SPBx.php";
                }
                break;
            case 'ECS0001':
                if (isset($get_modelo) && is_array($get_modelo)) {
                    foreach ($get_modelo as $key => $value) {
                        $texto[] = $value->texto;
                    }
                } else {
                    include "includes/ecs.php";
                }
                break;
            // case 'SPB0001':
            // break;
            case 'ADM0001':
                if (isset($get_modelo) && is_array($get_modelo)) {
                    foreach ($get_modelo as $key => $value) {
                        $texto[] = $value->texto;
                    }
                } else {
                    include "includes/texto_customizacao.php";
                }
                break;
                // default:
                // break;
        }
        return $texto;
    }

    private function pdfRocket($texto, $path_full, $id_contrato, $lp, $pacote = null)
    {
        require_once "libs/mpdf/vendor/autoload.php";
        set_time_limit(300);
        unlink($path_full);

        $style_documento = file_get_contents('assets/css/css_pdf.css');
        $style_table = file_get_contents('assets/css/css_pdf_table.css');

        $mpdf = new \Mpdf\Mpdf();
        $mpdf->SetHeader();

        $pacote_default =  json_decode($this->model_modelo->getPacoteDefault("RCK0001"));
        if (isset($pacote_default) && !empty($pacote_default)) {
            foreach ($pacote_default as $key => $value) {
                $pacote_modulo[$value->codigo_modulo] = $value;
            }
        }

        $contador = 0;
        foreach ($texto as $key => $value) {
            if ($contador == 0) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "RCK0001");
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br><br>" . $value->texto);
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img> <p style="font-size:10px">Barueri, ' . $this->data_extenso . '</p></div>', null, true);
            } elseif ($contador == 1) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "RCK0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br></br>" . $value->texto);
            } else {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "RCK0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br>" . $value->texto);
            }
            $contador++;
        }

        $mpdf->keep_table_proportions = true;

        $tabela_modulos = $this->organizaListaPreco("RCK0001", "engine", $lp, $pacote);
        if (isset($tabela_modulos) && !empty($tabela_modulos)) {
            $html = $this->gerarTableHtml("RCK0001", $tabela_modulos, "engine", "50%");
            $mpdf->AddPage();
            $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
            $mpdf->WriteHTML($style_table, \Mpdf\HTMLParserMode::HEADER_CSS);
            $mpdf->WriteHTML("<br></br><br></br><br>" . $this->dicionario["TEXTO_ROCKET"]["ENGINE"]["TABELA"]);
            $mpdf->WriteHTML("<br></br><br>" . "<b><u>" . $this->dicionario["TEXTO_ROCKET"]["ENGINE"]["TITULO"] . "</b></u>");
            $mpdf->WriteHTML("<br></br>" . $this->dicionario["TEXTO_ROCKET"]["ENGINE"]["TEXTO"] . "<br></br>");
            $mpdf->WriteHTML("<br></br><br></br>" . $html);
        }

        $tabela_modulos = $this->organizaListaPreco("RCK0001", "rocket", $lp);
        if (isset($tabela_modulos) && !empty($tabela_modulos)) {
            $html = $this->gerarTableHtml("RCK0001", $tabela_modulos, null, "60%");
            $mpdf->AddPage();
            $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
            $mpdf->WriteHTML($style_table, \Mpdf\HTMLParserMode::HEADER_CSS);
            $mpdf->WriteHTML("<br></br><br>" . "<b><u>" . $this->dicionario["TEXTO_ROCKET"]["MODULOS"]["TITULO"] . "</b></u>");
            $mpdf->WriteHTML("<br></br>" . $this->dicionario["TEXTO_ROCKET"]["MODULOS"]["TEXTO"] . "<br></br>");
            $mpdf->WriteHTML("<br></br><br></br>" . $html);
        }

        $tabela_modulos = $this->organizaListaPreco("RCK0001", "validacao_cadastral", $lp);
        if (isset($tabela_modulos) && !empty($tabela_modulos)) {
            $html = $this->gerarTableHtml("RCK0001", $tabela_modulos, null, "60%");
            $mpdf->AddPage();
            $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
            $mpdf->WriteHTML("<br></br><br>" . "<b><u>" . $this->dicionario["TEXTO_ROCKET"]["VALIDACAO_CADASTRAL"]["TITULO"] . "</b></u>");
            $mpdf->WriteHTML("<br></br>" . $this->dicionario["TEXTO_ROCKET"]["VALIDACAO_CADASTRAL"]["TEXTO"] . "<br></br>");
            $mpdf->WriteHTML($html);
        }

        $tabela_modulos = $this->organizaListaPreco("RCK0001", "suite_liquidacao", $lp);
        if (isset($tabela_modulos) && !empty($tabela_modulos)) {
            $html = $this->gerarTableHtml("RCK0001", $tabela_modulos, null, "60%");
            $mpdf->AddPage();
            $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
            $mpdf->WriteHTML("<br></br><br>" . "<b><u>" . $this->dicionario["TEXTO_ROCKET"]["SUITE_LIQUIDACAO"]["TITULO"] . "</b></u>");
            $mpdf->WriteHTML("<br></br>" . $this->dicionario["TEXTO_ROCKET"]["SUITE_LIQUIDACAO"]["TEXTO"] . "<br></br>");
            $mpdf->WriteHTML($html);
        }

        $tabela_modulos = $this->organizaListaPreco("RCK0001", "open_banking", $lp);
        if (isset($tabela_modulos) && !empty($tabela_modulos)) {
            $html = $this->gerarTableHtml("RCK0001", $tabela_modulos, null, "60%");
            $mpdf->AddPage();
            $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
            $mpdf->WriteHTML("<br></br><br>" . "<b><u>" . $this->dicionario["TEXTO_ROCKET"]["OPEN_BANKING"]["TITULO"] . "</b></u>");
            $mpdf->WriteHTML($html);
        }

        $tabela_modulos = $this->organizaListaPreco("RCK0001", "serpro", $lp);

        if (isset($tabela_modulos) && !empty($tabela_modulos)) {

            $texto_serpro = str_replace("**--VALOR_SERPRO--**", funcValor($pacote_modulo['RCK0036']->preco_pkt, "C", 2), $this->dicionario["TEXTO_ROCKET"]["SERPRO"]["TEXTO"]);
            $texto_serpro = str_replace("**--TRANSACOES_SERPRO--**", funcValor($pacote_modulo['RCK0036']->qdt_garantido, "C", 0), $texto_serpro);

            $html = $this->gerarTableHtml("RCK0001", $tabela_modulos, "serpro", "20%", $pacote_modulo);
            $mpdf->AddPage();
            $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
            $mpdf->WriteHTML($style_table, \Mpdf\HTMLParserMode::HEADER_CSS);
            $mpdf->WriteHTML("<br></br><br>" . "<b><u>" . $this->dicionario["TEXTO_ROCKET"]["SERPRO"]["TITULO"] . "</b></u>");
            $mpdf->WriteHTML("<br></br>" . $texto_serpro . "<br></br>");
            $mpdf->WriteHTML("<br></br>" . $this->dicionario["TEXTO_ROCKET"]["SERPRO"]["INDICE"] . "<br></br>");
            $mpdf->WriteHTML($this->dicionario["TEXTO_ROCKET"]["SERPRO"]["TEXTO_2"] . "<br></br>");
            $mpdf->WriteHTML($html);
        }

        $tabela_modulos = $this->organizaListaPreco("RCK0001", "carta", $lp);
        if (isset($tabela_modulos) && !empty($tabela_modulos)) {
            $texto_carta = str_replace("**--TRANSACOES_CARTA--**", funcValor($pacote_modulo['RCK0023']->qdt_garantido, "C", 0), $this->dicionario["TEXTO_ROCKET"]["CARTA"]["TEXTO"]);
            $html = $this->gerarTableHtml("RCK0001", $tabela_modulos, "carta", "20%", $pacote_modulo);
            $mpdf->WriteHTML($style_table, \Mpdf\HTMLParserMode::HEADER_CSS);
            $mpdf->WriteHTML("<br></br><br><br></br><br><br></br><br><br></br><br><br><br>");
            $mpdf->WriteHTML("<br></br><br><br></br><br>" . "<b><u>" . $this->dicionario["TEXTO_ROCKET"]["CARTA"]["TITULO"] . "</b></u>");
            $mpdf->WriteHTML("<br></br>" . $texto_carta . "<br></br>");
            $mpdf->WriteHTML($html);
        }

        $tabela_modulos = $this->organizaListaPreco("RCK0001", "face_id", $lp);
        if (isset($tabela_modulos) && !empty($tabela_modulos)) {
            $html = $this->gerarTableHtml("RCK0001", $tabela_modulos, "face_id", "40%");
            $mpdf->AddPage();
            $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
            $mpdf->WriteHTML("<br></br><br><br></br>" . "<b><u>" . $this->dicionario["TEXTO_ROCKET"]["FACE_ID"]["TITULO"] . "</b></u>");
            $mpdf->WriteHTML($html);
        }

        $tabela_modulos = $this->organizaListaPreco("RCK0001", "token_pix", $lp);
        if (isset($tabela_modulos) && !empty($tabela_modulos)) {
            $html = $this->gerarTableHtml("RCK0001", $tabela_modulos, "token_pix", "40%");

            $mpdf->WriteHTML("<br></br><br><br></br><br><br></br><br><br></br><br>");
            $mpdf->WriteHTML("<br></br><b><u>" . $this->dicionario["TEXTO_ROCKET"]["TOKEN_PIX"]["TITULO"] . "</b></u>");
            $mpdf->WriteHTML($html);
        }
        $mpdf->Output($path_full, 'F');
        return true;
    }

    private function pdfFull($texto, $path_full, $id_contrato, $lp)
    {
        require_once "libs/mpdf/vendor/autoload.php";
        set_time_limit(300);
        unlink($path_full);

        $style_documento = file_get_contents('assets/css/css_pdf.css');
        $style_full = file_get_contents('assets/css/css_pdf_full.css');

        $mpdf = new \Mpdf\Mpdf();
        $mpdf->SetHeader();
        $contador = 0;
        foreach ($texto as $key => $value) {
            if ($contador == 0) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "FSP0001");
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br><br>" . $value->texto);
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img> <p style="font-size:10px">Barueri, ' . $this->data_extenso . '</p></div>', null, true);
            } elseif ($contador == 1) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "FSP0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML($style_full, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br></br>" . $value->texto);
            } else {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "FSP0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_full, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br>" . $value->texto);
            }
            $contador++;
        }

        $mpdf->Output($path_full, 'F');

        return true;
    }

    private function pdfSPIx($texto, $path_full, $id_contrato, $lp)
    {
        require_once "libs/mpdf/vendor/autoload.php";
        set_time_limit(300);
        unlink($path_full);

        $style_documento = file_get_contents('assets/css/css_pdf.css');
        $style_full = file_get_contents('assets/css/css_pdf_full.css');

        $mpdf = new \Mpdf\Mpdf();
        $mpdf->SetHeader();
        $contador = 0;
        foreach ($texto as $key => $value) {
            if ($contador == 0) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "SPI0001");
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br><br>" . $value->texto);
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img> <p style="font-size:10px">Barueri, ' . $this->data_extenso . '</p></div>', null, true);
            } elseif ($contador == 1) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "SPI0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML($style_full, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br></br>" . $value->texto);
            } else {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "SPI0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_full, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br>" . $value->texto);
            }
            $contador++;
        }

        $mpdf->Output($path_full, 'F');

        return true;
    }

    private function pdfYellow($texto, $path_full, $id_contrato, $lp)
    {
        require_once "libs/mpdf/vendor/autoload.php";
        set_time_limit(300);
        unlink($path_full);
        $style_documento = file_get_contents('assets/css/css_pdf.css');
        $style_table = file_get_contents('assets/css/css_pdf_yellow.css');
        $mpdf = new \Mpdf\Mpdf();
        $mpdf->SetHeader();
        $contador = 0;
        foreach ($texto as $key => $value) {
            if ($contador == 0) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "YLW0001");
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br><br>" . $value->texto);
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img> <p style="font-size:10px">Barueri, ' . $this->data_extenso . '</p></div>', null, true);
            } elseif ($contador == 1) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "YLW0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br></br>" . $value->texto);
            } else {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "YLW0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                if ($contador > 2) {
                    $mpdf->WriteHTML($style_table, \Mpdf\HTMLParserMode::HEADER_CSS);
                }
                $mpdf->WriteHTML("<br></br><br>" . $value->texto);
            }
            $contador++;
        }

        $mpdf->Output($path_full, 'F');
        return true;
    }

    private function pdfCrystalAMC($texto, $path_full, $id_contrato, $lp)
    {
        require_once "libs/mpdf/vendor/autoload.php";
        set_time_limit(300);
        unlink($path_full);
        $style_documento = file_get_contents('assets/css/css_pdf.css');
        $mpdf = new \Mpdf\Mpdf();
        $mpdf->SetHeader();
        $contador = 0;
        foreach ($texto as $key => $value) {
            if ($contador == 0) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "CRY0001");
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br><br>" . $value->texto);
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img> <p style="font-size:10px">Barueri, ' . $this->data_extenso . '</p></div>', null, true);
            } elseif ($contador == 1) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "CRY0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br></br>" . $value->texto);
            } else {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "CRY0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br>" . $value->texto);
            }
            $contador++;
        }
        $mpdf->Output($path_full, 'F');
        return true;
    }

    private function pdfCrystalBMC($texto, $path_full, $id_contrato, $lp, $pacote = null)
    {
        $texto[0]->texto = $this->replaceTag($id_contrato, $texto[0]->texto, "CRY0003");
        if ($pacote) {
            // implementar tabela de pacote.
        }

        if ($lp) {
            $table_lp = '
                    <table border=1 class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th class="fundo_azul"> CODIGO </th>
                                <th class="fundo_azul"> MODULO </th>
                                <th class="fundo_azul"> INFO </th>
                                <th class="fundo_azul"> VALOR </th>
                            </tr>
                        </thead>
                        <tbody>
                ';

            foreach ($lp as $key => $value) {
                $table_lp .= '<tr><td class="fundo_azul"> ' . $value->codigo_modulo . ' </td>';
                $table_lp .= '<td> ' . $value->descricao . ' </td>';
                $table_lp .= '<td> POR TRANSAÇÃO </td>';
                $table_lp .= '<td> ' . number_format($value->valor_real, '6', ',', '.') . ' </td></tr>';
            }

            $table_lp .= '
                        </tbody>
                    </table>
                ';
        }

        require_once "libs/mpdf/vendor/autoload.php";
        set_time_limit(300);
        // unlink($path_full);
        $style_table = file_get_contents('assets/css/css_table_crystal_bmc.css');
        $corpo_table = '
				<br /><br />
				<!DOCTYPE html>
				<html lang="en">
				<head>
					<meta charset="UTF-8">
					<meta name="viewport" content="width=device-width, initial-scale=1.0">
				</head>
				<body>
					' . $texto[0]->texto . '
                    ' . $table_lp . '
				</body>
				</html>
			';
        $mpdf = new \Mpdf\Mpdf([
            'debug' => true,
            'allow_output_buffering' => true
        ]);

        $mpdf->SetHeader();
        $mpdf->AddPage();
        $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/logotipo-crystal-bmc.png"></img></div>', null, true);
        $mpdf->WriteHTML($style_table, \Mpdf\HTMLParserMode::HEADER_CSS);
        $mpdf->WriteHTML($corpo_table, \Mpdf\HTMLParserMode::HTML_BODY);
        $mpdf->Output($path_full, 'F');
        return true;
    }

    private function pdfCrystalCertificate($texto, $path_full, $id_contrato, $lp)
    {
        $texto[0]->texto = $this->replaceTag($id_contrato, $texto[0]->texto, "CRY0003");
        if ($pacote) {
            // implementar tabela de pacote.
        }

        if ($lp) {
            $table_lp = '
                    <table border=1 class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th class="fundo_azul"> CODIGO </th>
                                <th class="fundo_azul"> MODULO </th>
                                <th class="fundo_azul"> INFO </th>
                                <th class="fundo_azul"> VALOR </th>
                            </tr>
                        </thead>
                        <tbody>
                ';

            foreach ($lp as $key => $value) {
                $table_lp .= '<tr><td class="fundo_azul"> ' . $value->codigo_modulo . ' </td>';
                $table_lp .= '<td> ' . $value->descricao . ' </td>';
                $table_lp .= '<td> POR TRANSAÇÃO </td>';
                $table_lp .= '<td> ' . number_format($value->valor_real, '6', ',', '.') . ' </td></tr>';
            }

            $table_lp .= '
                        </tbody>
                    </table>
                ';
        }

        require_once "libs/mpdf/vendor/autoload.php";
        set_time_limit(300);
        // unlink($path_full);
        $style_table = file_get_contents('assets/css/css_table_crystal_bmc.css');
        $corpo_table = '
				<br /><br />
				<!DOCTYPE html>
				<html lang="en">
				<head>
					<meta charset="UTF-8">
					<meta name="viewport" content="width=device-width, initial-scale=1.0">
				</head>
				<body>
					' . $texto[0]->texto . '
                    ' . $table_lp . '
				</body>
				</html>
			';

        $mpdf = new \Mpdf\Mpdf([
            'debug' => true,
            'allow_output_buffering' => true
        ]);

        $mpdf->SetHeader();
        $mpdf->AddPage();
        $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/logotipo-crystal-bmc.png"></img></div>', null, true);
        $mpdf->WriteHTML($style_table, \Mpdf\HTMLParserMode::HEADER_CSS);
        $mpdf->WriteHTML($corpo_table, \Mpdf\HTMLParserMode::HTML_BODY);
        $mpdf->Output($path_full, 'F');
        return true;
    }

    private function pdfPixAutomatico($texto, $path_full, $id_contrato)
    {
        require_once "libs/mpdf/vendor/autoload.php";
        set_time_limit(300);
        unlink($path_full);
        $style_documento = file_get_contents('assets/css/css_pdf.css');
        $mpdf = new \Mpdf\Mpdf();
        $mpdf->SetHeader();
        $contador = 0;
        foreach ($texto as $key => $value) {
            $value->texto = $this->replaceTag($id_contrato, $value->texto, "CPA0001");
            $mpdf->AddPage();
            $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
            $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
            $mpdf->WriteHTML("<br></br><br>" . $value->texto);
            $contador++;
        }
        $mpdf->Output($path_full, 'F');
        return true;
    }

    private function pdfSpbObe($texto, $path_full, $id_contrato, $lp)
    {
        require_once "libs/mpdf/vendor/autoload.php";
        set_time_limit(300);
        unlink($path_full);

        $style_documento = file_get_contents('assets/css/css_pdf.css');
        $style_full = file_get_contents('assets/css/css_pdf_full.css');

        $mpdf = new \Mpdf\Mpdf();
        $mpdf->SetHeader();
        $contador = 0;
        foreach ($texto as $key => $value) {
            if ($contador == 0) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "SOE0001");
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br><br>" . $value->texto);
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img> <p style="font-size:10px">Barueri, ' . $this->data_extenso . '</p></div>', null, true);
            } elseif ($contador == 1) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "SOE0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML($style_full, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br></br>" . $value->texto);
            } else {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "SOE0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_full, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br>" . $value->texto);
            }
            $contador++;
        }
        $mpdf->Output($path_full, 'F');
        return true;
    }

    private function pdfCornerPix($texto, $path_full, $id_contrato, $lp)
    {
        require_once "libs/mpdf/vendor/autoload.php";
        set_time_limit(300);
        unlink($path_full);

        $style_documento = file_get_contents('assets/css/css_pdf.css');
        $style_full = file_get_contents('assets/css/css_pdf_full.css');
        $mpdf = new \Mpdf\Mpdf();
        $mpdf->SetHeader();
        $contador = 0;
        foreach ($texto as $key => $value) {
            if ($contador == 0) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "ATF0001");
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br><br>" . $value->texto);
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img> <p style="font-size:10px">Barueri, ' . $this->data_extenso . '</p></div>', null, true);
            } elseif ($contador == 1) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "ATF0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML($style_full, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br></br>" . $value->texto);
            } else {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "ATF0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_full, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br>" . $value->texto);
            }
            $contador++;
        }

        $mpdf->Output($path_full, 'F');
        return true;
    }

    private function pdfTriploPix($texto, $path_full, $id_contrato, $lp)
    {
        require_once "libs/mpdf/vendor/autoload.php";
        set_time_limit(300);
        unlink($path_full);

        $style_documento = file_get_contents('assets/css/css_pdf.css');
        $style_full = file_get_contents('assets/css/css_pdf_full.css');
        $mpdf = new \Mpdf\Mpdf();
        $mpdf->SetHeader();
        $contador = 0;
        foreach ($texto as $key => $value) {
            if ($contador == 0) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "TPX0001");
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br><br>" . $value->texto);
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img> <p style="font-size:10px">Barueri, ' . $this->data_extenso . '</p></div>', null, true);
            } elseif ($contador == 1) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "TPX0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML($style_full, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br></br>" . $value->texto);
            } else {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "TPX0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_full, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br>" . $value->texto);
            }
            $contador++;
        }
        $mpdf->Output($path_full, 'F');
        return true;
    }

    private function pdfECS($texto, $path_full, $id_contrato, $lp)
    {
        require_once "libs/mpdf/vendor/autoload.php";
        set_time_limit(300);
        unlink($path_full);

        $style_documento = file_get_contents('assets/css/css_pdf.css');
        $style_full = file_get_contents('assets/css/css_pdf_full.css');
        $mpdf = new \Mpdf\Mpdf();
        $mpdf->SetHeader();
        $contador = 0;
        foreach ($texto as $key => $value) {
            if ($contador == 0) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "ECS0001");
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br><br>" . $value->texto);
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img> <p style="font-size:10px">Barueri, ' . $this->data_extenso . '</p></div>', null, true);
            } elseif ($contador == 1) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "ECS0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML($style_full, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br></br>" . $value->texto);
            } else {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "ECS0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_full, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br>" . $value->texto);
            }
            $contador++;
        }
        $mpdf->Output($path_full, 'F');
        return true;
    }

    private function pdfCustomizacao($texto, $path_full, $id_contrato)
    {
        require_once "libs/mpdf/vendor/autoload.php";
        set_time_limit(300);
        $style_documento = file_get_contents('assets/css/css_pdf.css');
        $style_full = file_get_contents('assets/css/css_pdf_full.css');
        $mpdf = new \Mpdf\Mpdf();
        $mpdf->SetHeader();
        $contador = 0;
        foreach ($texto as $key => $value) {
            if ($contador == 0) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "ADM0001");
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br><br>" . $value->texto);
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img> <p style="font-size:10px">Barueri, ' . $this->data_extenso . '</p></div>', null, true);
            } elseif ($contador == 1) {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "ADM0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML($style_full, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br></br><br></br>" . $value->texto);
            } else {
                $value->texto = $this->replaceTag($id_contrato, $value->texto, "ADM0001");
                $mpdf->AddPage();
                $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
                $mpdf->WriteHTML($style_full, \Mpdf\HTMLParserMode::HEADER_CSS);
                $mpdf->WriteHTML("<br></br><br>" . $value->texto);
            }
            $contador++;
        }
        $mpdf->Output($path_full, 'F');
        return true;
    }

    function replaceTag($id_contrato, $texto, $cod_produto)
    {
        setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
        if (isset($id_contrato) && !empty($id_contrato)) {
            $contrato = json_decode($this->controller->modelo->getIfContrato($id_contrato));
            $endereco = json_decode($this->controller->modelo->getIfEndereco($id_contrato));
            $dados_minuta["CLIENTE"]["CLIENTE"]   = $contrato[0]->razao_social;
            $dados_minuta["CLIENTE"]["CNPJ"]      = formatarString("cnpj", $contrato[0]->cnpj);
            $dados_minuta["ENDERECO"]["ENDERECO"] = $endereco[0]->endereco . ", nº " . $endereco[0]->numero;
            $dados_minuta["ENDERECO"]["BAIRRO"]   = $endereco[0]->bairro;
            $dados_minuta["ENDERECO"]["CEP"]      = formatarString("cep", $endereco[0]->cep);
            $dados_minuta["ENDERECO"]["CIDADE"]   = $endereco[0]->cidade;
            $dados_minuta["ENDERECO"]["UF"]       = $endereco[0]->estado;

            $contatos = json_decode($this->controller->modelo->getIfContato($id_contrato, 'minuta'));
            if (isset($contatos) && !empty($contatos)) {
                $contador_representante = 0;
                foreach ($contatos as $key => $value) {
                    if (strtoupper($value->tipo_contato) == "RESPONSAVEL_LEGAL") {
                        if ($contador_representante == 0) {
                            $dados_minuta["REPRESENTANTE"]["NOME"]      = $value->nome;
                            $dados_minuta["REPRESENTANTE"]["CARGO"]     = $value->cargo_setor;
                            $dados_minuta["REPRESENTANTE"]["CPF"]       = formatarString("cpf", $value->cpf);
                            $dados_minuta["REPRESENTANTE"]["TELEFONE"]  = formatarString("telefone", $value->telefone);
                            $dados_minuta["REPRESENTANTE"]["EMAIL"]     = $value->email;
                        } else {
                            $dados_minuta["REPRESENTANTE_2"]["NOME"]      = "<b>" . $value->nome . "</b>";
                            $dados_minuta["REPRESENTANTE_2"]["CARGO"]     = $value->cargo_setor;
                            $dados_minuta["REPRESENTANTE_2"]["CPF"]       = formatarString("cpf", $value->cpf);
                            $dados_minuta["REPRESENTANTE_2"]["TELEFONE"]  = formatarString("telefone", $value->telefone);
                            $dados_minuta["REPRESENTANTE_2"]["EMAIL"]     = $value->email;
                        }
                        $contador_representante++;
                    }

                    if (strtoupper($value->tipo_contato) == "TESTEMUNHA") {
                        $dados_minuta["TESTEMUNHA"]["NOME"]         = $value->nome;
                        $dados_minuta["TESTEMUNHA"]["CPF"]          = formatarString("cpf", $value->cpf);
                        $dados_minuta["TESTEMUNHA"]["EMAIL"]        = $value->email;
                        $dados_minuta["TESTEMUNHA"]["TIPO_CONTATO"] = strtoupper($value->tipo_contato);
                        $dados_minuta["TESTEMUNHA"]["TELEFONE"]     = formatarString("telefone", $value->telefone);
                    }

                    if (strtoupper($value->tipo_contato) == "TESTEMUNHA_2") {
                        $dados_minuta["TESTEMUNHA_2"]["NOME"]         = $value->nome;
                        $dados_minuta["TESTEMUNHA_2"]["CPF"]          = formatarString("cpf", $value->cpf);
                        $dados_minuta["TESTEMUNHA_2"]["EMAIL"]        = $value->email;
                        $dados_minuta["TESTEMUNHA_2"]["TIPO_CONTATO"] = "TESTEMUNHA";
                        $dados_minuta["TESTEMUNHA_2"]["TELEFONE"]     = formatarString("telefone", $value->telefone);
                    }

                    if (!isset($dados_minuta["CONTATO_FINANCEIRO"])) {
                        if (strtoupper($value->tipo_contato) == "FINANCEIRO") {
                            $dados_minuta["CONTATO_FINANCEIRO"]["TIPO_CONTATO"] = strtoupper($value->tipo_contato);
                            $dados_minuta["CONTATO_FINANCEIRO"]["NOME"]         = $value->nome;
                            $dados_minuta["CONTATO_FINANCEIRO"]["EMAIL"]        = $value->email;
                            $dados_minuta["CONTATO_FINANCEIRO"]["TELEFONE"]     = formatarString("telefone", $value->telefone);
                        }
                    } else {
                        if (strtoupper($value->tipo_contato) == "FINANCEIRO") {
                            $dados_minuta["CONTATO_FINANCEIRO"]["CONTATO_FINANCEIRO_2"] = "• FINANCEIRO: " . $value->nome . " - e-mail: " . $value->email . " - telefone: " . formatarString("telefone", $value->telefone);
                        }
                    }

                    if (strtoupper($value->tipo_contato) == "CONTATO_RESPONSAVEL") {
                        $contato_responsavel['status'] = true;
                        $contato_responsavel['dados'][] = $value;
                    }
                }

                if (!isset($dados_minuta["CONTATO_FINANCEIRO"]["CONTATO_FINANCEIRO_2"])) {
                    $dados_minuta["CONTATO_FINANCEIRO"]["CONTATO_FINANCEIRO_2"] = "";
                }

                if (isset($contato_responsavel) && $contato_responsavel['status'] == true) {
                    $dados_minuta["CONTATO_RESPONSAVEL"]["NOME"]     = $contato_responsavel["dados"][0]->nome;
                    $dados_minuta["CONTATO_RESPONSAVEL"]["EMAIL"]    = $contato_responsavel["dados"][0]->email;
                    $dados_minuta["CONTATO_RESPONSAVEL"]["TELEFONE"] = formatarString("telefone", $contato_responsavel["dados"][0]->telefone);
                } else {
                    $dados_minuta["CONTATO_RESPONSAVEL"]["NOME"]     = $dados_minuta["REPRESENTANTE"]["NOME"];
                    $dados_minuta["CONTATO_RESPONSAVEL"]["EMAIL"]    = $dados_minuta["REPRESENTANTE"]["EMAIL"];
                    $dados_minuta["CONTATO_RESPONSAVEL"]["TELEFONE"] = $dados_minuta["REPRESENTANTE"]["TELEFONE"];
                }
            }

            $contato_cm = json_decode($this->controller->modelo->getContatoSign("sign_cm", null, null, true));
            if (isset($contato_cm) && !empty($contato_cm)) {
                foreach ($contato_cm as $key => $value) {
                    if (strtoupper($value->tipo_contato) == "JURIDICO") {
                        $juridico[] = $value;
                    }
                    if (strtoupper($value->tipo_contato) == "TESTEMUNHA") {
                        $testemunha[] = $value;
                    }
                }
                if (isset($juridico) && !empty($juridico)) {
                    $dados_minuta['TESTEMUNHA_CM']["NOME"]  = $juridico[0]->nome;
                    $dados_minuta['TESTEMUNHA_CM']["CPF"]   = formatarString("cpf", $juridico[0]->cpf);
                    $dados_minuta['TESTEMUNHA_CM']["EMAIL"] = $juridico[0]->email;
                } else {
                    if (isset($testemunha) && !empty($testemunha)) {
                        $dados_minuta['TESTEMUNHA_CM']["NOME"]  = $testemunha[0]->nome;
                        $dados_minuta['TESTEMUNHA_CM']["CPF"]   = formatarString("cpf", $testemunha[0]->cpf);
                        $dados_minuta['TESTEMUNHA_CM']["EMAIL"] = $testemunha[0]->email;
                    }
                }
            }

            $faturamento = json_decode($this->controller->modelo->getInstrucaoFaturamento($id_contrato));
            if (isset($faturamento) && !empty($faturamento)) {
                $dados_minuta["FATURAMENTO"]["IMPLANTACAO"]         = funcValor($faturamento[0]->implantacao,  'C', 2);
                $dados_minuta["FATURAMENTO"]["IMPLANTACAO_EXTENSO"] = "( " . Extenso::converte(funcValor($faturamento[0]->implantacao, 'C', 2), true, false) . " )";

                if (isset($faturamento[0]->hospedagem) && !empty($faturamento[0]->hospedagem)) {
                    $dados_minuta["FATURAMENTO"]["PACOTE"] = funcValor($faturamento[0]->hospedagem, 'C', 2);
                    $dados_minuta["FATURAMENTO"]["PACOTE_EXTENSO"] = "( " . Extenso::converte(funcValor($faturamento[0]->hospedagem, 'C', 2), true, false) . " )";
                } else {
                    $pacote_propostas = json_decode($this->controller->modelo->getPacotePropostas($contrato[0]->id_proposta));
                    if (isset($pacote_propostas) && !empty($pacote_propostas)) {
                        $dados_minuta["FATURAMENTO"]["PACOTE"] = funcValor($pacote_propostas[0]->preco_pkt, 'C', 2);
                        $dados_minuta["FATURAMENTO"]["PACOTE_EXTENSO"] = "( " . Extenso::converte(funcValor($pacote_propostas[0]->preco_pkt, 'C', 2), true, false) . " )";
                    }
                }

                $dados_minuta["FATURAMENTO"]["CORTE_FATURAMENTO"] = $faturamento[0]->faturamento_todo_dia;
                $dados_minuta["FATURAMENTO"]["CORTE_FATURAMENTO_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->faturamento_todo_dia, false, false) . " )";
                if ($faturamento[0]->tipo_data_faturamento == "dias_apos_faturamento" && !empty($faturamento[0]->dias_apos_faturamento)) {
                    $dados_minuta["FATURAMENTO"]["PRAZO_PAGAMENTO"] = "de " . $faturamento[0]->dias_apos_faturamento;
                    $dados_minuta["FATURAMENTO"]["PRAZO_PAGAMENTO_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->dias_apos_faturamento, false, false) . " ) dias";
                } else {
                    $dados_minuta["FATURAMENTO"]["PRAZO_PAGAMENTO"] = "todo dia " . $faturamento[0]->vencimento_todo_dia;
                    $dados_minuta["FATURAMENTO"]["PRAZO_PAGAMENTO_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->vencimento_todo_dia, false, false) . " ) de cada mês";
                }

                if ($faturamento[0]->parcelas == "1") {
                    $dados_minuta["FATURAMENTO"]["IMPLANTACAO_TEXTO"] = "que será pago em até 10 (dez) dias após a assinatura do presente contrato";
                } else if ($faturamento[0]->parcelas == "2") {
                    $parcela_implatacao =  funcValor($faturamento[0]->implantacao / 2, 'C', 2);
                    $dados_minuta["FATURAMENTO"]["IMPLANTACAO_TEXTO"] = "que serão pagos em 2 (duas) parcelas iguais e consecutivas de R$ " . $parcela_implatacao . " ( " . Extenso::converte($parcela_implatacao, true, false) . " ) sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela.";
                } else if ($faturamento[0]->parcelas == "3") {
                    $parcela_implatacao =  funcValor($faturamento[0]->implantacao / 3, 'C', 2);
                    $dados_minuta["FATURAMENTO"]["IMPLANTACAO_TEXTO"] = "que serão pagos em 3 (três) parcelas iguais e consecutivas de R$ " . $parcela_implatacao . " ( " . Extenso::converte($parcela_implatacao, true, false) . " ) sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela e a terceira parcela com vencimento em 30 (trinta) dias após o vencimento da segunda parcela.";
                } else {
                    $parcela_implatacao =  funcValor($faturamento[0]->implantacao / $faturamento[0]->parcelas, 'C', 2);
                    $dados_minuta["FATURAMENTO"]["IMPLANTACAO_TEXTO"] = "que serão pagos em " . $faturamento[0]->parcelas . " (" . Extenso::converte($faturamento[0]->parcelas, false, false) . ") parcelas iguais e consecutivas de R$ " . $parcela_implatacao . " ( " . Extenso::converte($parcela_implatacao, true, false) . " ) sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela e a terceira parcela com vencimento em 30 (trinta) dias após o vencimento da segunda parcela.";
                }

                $dados_minuta["FATURAMENTO"]["PRIMEIRO_FATURAMENTO"] = "<b> 29 (vinte e nove) </b>";
                if (empty($faturamento[0]->duracao_contrato)) {
                    $dados_minuta["FATURAMENTO"]["VIGENCIA_CONTRATO"] = "INDETERMINADO";
                    $dados_minuta["FATURAMENTO"]["VIGENCIA_CONTRATO_EXTENSO"] = "";
                } else {
                    $dados_minuta["FATURAMENTO"]["VIGENCIA_CONTRATO"] = strtoupper(str_replace("meses", "", $faturamento[0]->duracao_contrato));
                    $dados_minuta["FATURAMENTO"]["VIGENCIA_CONTRATO_EXTENSO"] = "(" . Extenso::converte(str_replace("meses", "", $faturamento[0]->duracao_contrato), false, false) . ") meses";
                }

                $dados_minuta["FATURAMENTO"]["INDICE_REAJUSTE"] = strtoupper($faturamento[0]->reajuste);
                $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS"] = $faturamento[0]->percentual_juros . "%";
                $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"] = "(" . Extenso::converte($faturamento[0]->percentual_juros, false, false) . " porcento)";
                $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA"] = $faturamento[0]->percentual_multa . "%";
                $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"] = "(" . Extenso::converte($faturamento[0]->percentual_multa, false, false) . " porcento)";

                if ($cod_produto != "ADM0001") {
                    $empresa = json_decode($this->controller->modelo->empresaVendedora(null, true));
                } else {
                    $empresa = json_decode($this->controller->modelo->empresaVendedora(null, true));
                }

                if (isset($empresa) && !empty($empresa)) {
                    foreach ($empresa as $key => $value) {
                        $dados_minuta["FATURAMENTO"]["CM"]      = $value->razao_social;
                        $dados_minuta["FATURAMENTO"]["CM_CNPJ"] = formatarString("cnpj", $value->cnpj);
                    }
                }
            }

            switch ($cod_produto) {
                case 'RCK0001':
                    $pacote_engine = json_decode($this->controller->modelo->getPacotePropostas($contrato[0]->id_proposta, 13, 8));
                    if (isset($pacote_engine) && !empty($pacote_engine)) {
                        $dados_minuta["FATURAMENTO"]["TRANSACOES_ENGINE"] = funcValor($pacote_engine[0]->quantidade_garantido, 'C', 0);
                        $dados_minuta["FATURAMENTO"]["TRANSACOES_ENGINE_EXTENSO"] = "( " . Extenso::converte($pacote_engine[0]->quantidade_garantido, false, true) . " )";
                    }
                    break;
                case 'FSP0001':
                    $modulos_proposta = json_decode($this->controller->modelo->getPropostasModuloByIdProposta($contrato[0]->id_proposta));
                    if (isset($modulos_proposta) && is_array($modulos_proposta)) {
                        foreach ($modulos_proposta as $key => $value) {
                            if ($value->cod_modulo == "ASSTR001" && $value->deleted == 0) {
                                $modulo["assessoria_str"] = true;
                            }
                            if ($value->cod_modulo == "ASPIX001" && $value->deleted == 0) {
                                $modulo["assessoria_pix"] = true;
                            }
                        }

                        if (isset($modulo["assessoria_str"]) && $modulo["assessoria_str"] == true) {
                            $cod_modulo = "STR0003";
                            $assessoria_bacen = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "FSP0001", $cod_modulo));
                            if (isset($assessoria_bacen) && !empty($assessoria_bacen)) {
                                $assessoria_str = funcValor($assessoria_bacen[0]->valor_real, 'C', 2);
                                if ($faturamento[0]->parcelas == "1") {
                                    $dados_minuta["FATURAMENTO"]["ASSESSORIA_BACEN"] .= "• O valor da Assessoria BACEN para emissão do ISPB é de <b> R$ " . $assessoria_str . " (" . Extenso::converte($assessoria_str, false, false) . ")</b>, que será pago em até 10 (dez) dias após a assinatura do presente contrato.";
                                } else if ($faturamento[0]->parcelas == "2") {
                                    $dados_minuta["FATURAMENTO"]["ASSESSORIA_BACEN"] .= "• O valor da Assessoria BACEN para emissão do ISPB é de <b> R$ " . $assessoria_str . " (" . Extenso::converte($assessoria_str, false, false) . ")</b>, que serão pagos em 2 (duas) parcelas iguais e consecutivas
                                        sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela.";
                                } else {
                                    $dados_minuta["FATURAMENTO"]["ASSESSORIA_BACEN"] .= "• O valor da Assessoria BACEN para emissão do ISPB é de <b> R$ " . $assessoria_str . " (" . Extenso::converte($assessoria_str, false, false) . ")</b>, que serão pagos em 3 (duas) parcelas iguais e consecutivas
                                        sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela e a terceira parcela
                                        com vencimento em 30 (trinta) dias após o vencimento da segunda parcela.";
                                }
                            }
                        }
                        if (!isset($dados_minuta["FATURAMENTO"]["ASSESSORIA_BACEN"])) {
                            $dados_minuta["FATURAMENTO"]["ASSESSORIA_BACEN"] = "";
                        }

                        if (isset($modulo["assessoria_pix"]) && $modulo["assessoria_pix"] == true) {
                            $cod_modulo = "STR0002";
                            $assessoria_pix = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "FSP0001", $cod_modulo));
                            if (isset($assessoria_pix) && !empty($assessoria_pix)) {
                                $implantacao_pix = funcValor($assessoria_pix[0]->valor_real, 'C', 2);
                                if ($faturamento[0]->parcelas == "1") {
                                    $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"] .= "• O valor da Assessoria PIX é de <b> R$ " . $implantacao_pix . " (" . Extenso::converte($implantacao_pix, false, false) . ")</b>, que será pago em até 10 (dez) dias após a assinatura do presente contrato.";
                                } else if ($faturamento[0]->parcelas == "2") {
                                    $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"] .= "• O valor da Assessoria PIX é de <b> R$ " . $implantacao_pix . " (" . Extenso::converte($implantacao_pix, false, false) . ")</b>, que serão pagos em 2 (duas) parcelas iguais e consecutivas
                                        sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela.";
                                } else {
                                    $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"] .= "• O valor da Assessoria PIX é de <b> R$ " . $implantacao_pix . " (" . Extenso::converte($implantacao_pix, false, false) . ")</b>, que serão pagos em 3 (duas) parcelas iguais e consecutivas
                                        sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela e a terceira parcela
                                        com vencimento em 30 (trinta) dias após o vencimento da segunda parcela.";
                                }
                            }
                        }
                        if (!isset($dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"])) {
                            $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"] = "";
                        }
                    }

                    $hora_homem = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "FSP0001", "PIX0019"));
                    if (isset($hora_homem) && !empty($hora_homem)) {
                        $dados_minuta["FATURAMENTO"]["HORA_HOMEM"] = funcValor($hora_homem[0]->valor_real, 'C', 2);
                    }

                    $pacote_full = json_decode($this->controller->modelo->getPacotePropostas($contrato[0]->id_proposta, 2000000, 2000000, null, "ASC"));
                    $lp['full_str_web'] = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "FSP0001", "STR0001"));
                    if (isset($pacote_full)) {
                        $contador_pacote = 1;
                        $dados_minuta["VALORES"]["PACOTE_FULL"] =
                            "<table class='table_lp'>
                                    <tr class='tr_table'>
                                        <th id='titulo' class='th_table'>Pacote</th>
                                        <th class='th_table'>Mensagens</th>
                                        <th class='th_table'>Mensalidade</th>
                                        <th class='th_table'>Excedente</th>
                                    </tr>";
                        foreach ($pacote_full as $key => $value) {
                            $dados_minuta["VALORES"]["PACOTE_FULL"] .=
                                "<tr>
                                        <td class='td_table'><b>  PACOTE $contador_pacote </b></td>
                                        <td class='td_table'><b>" . funcValor($value->quantidade_garantido, 'C', 0) . "</b></td>
                                        <td class='td_table'> R$ " . funcValor($value->preco_pkt, 'C', 2) . "</td>
                                        <td class='td_table'> R$ " . funcValor($value->valor_excedente, 'C', 6) . "</td>
                                    </tr>";
                            $contador_pacote++;
                        }
                        $dados_minuta["VALORES"]["PACOTE_FULL"] .= "</table>";
                    } else {
                        $pacote_opcional = json_decode($this->controller->modelo->getPacoteOpcional("FSP0001"));
                        if (isset($pacote_opcional)) {
                            $dados_minuta["VALORES"]["PACOTE_FULL"] = "
                                <table class='table_lp'>
                                    <tr class='tr_table'>
                                        <th id='titulo' class='th_table'>Pacote</th>
                                        <th class='th_table'>Mensagens</th>
                                        <th class='th_table'>Mensalidade</th>
                                        <th class='th_table'>Excedente</th>
                                    </tr>";
                            foreach ($pacote_opcional as $key => $value) {
                                $dados_minuta["VALORES"]["PACOTE_FULL"] .= "
                                            <tr>
                                                <td id='titulo' class='td_table'><b>" . strtoupper($value->modulo) . "</b></td>
                                                <td class='td_table'><b>" . funcValor($value->quantidade_garantido, 'C', 0) . "</b></td>
                                                <td class='td_table'>" . funcValor($value->preco_pkt, 'C', 2) . "</td>
                                                <td class='td_table'>" . funcValor($value->excedente, 'C', 6) . "</td>
                                            </tr>    
                                        ";
                            }
                            $dados_minuta["VALORES"]["PACOTE_FULL"] .= "
                                </table>";
                        } else {
                            $dados_minuta["VALORES"]["PACOTE_FULL"] = "
                                <table class='table_lp'>
                                    <tr class='tr_table'>
                                        <th id='titulo' class='th_table'>Pacote</th>
                                        <th class='th_table'>Mensagens</th>
                                        <th class='th_table'>Mensalidade</th>
                                        <th class='th_table'>Excedente</th>
                                    </tr>
                                    <tr>
                                        <td id='titulo' class='td_table'><b>PACOTE 1</b></td>
                                        <td class='td_table'><b>" . $this->dicionario['PACOTE_FULL']['PACOTE_1']['MENSAGENS'] . "</b></td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_1']['MENSALIDADE'] . "</td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_1']['EXCEDENTE'] . "</td>
                                    </tr>
                                    <tr>
                                        <td id='titulo' class='td_table'><b>PACOTE 2</b></td>
                                        <td class='td_table'><b>" . $this->dicionario['PACOTE_FULL']['PACOTE_2']['MENSAGENS'] . "</b></td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_2']['MENSALIDADE'] . "</td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_2']['EXCEDENTE'] . "</td>
                                    </tr>
                                    <tr>
                                        <td id='titulo' class='td_table'><b>PACOTE 3</b></td>
                                        <td class='td_table'><b>" . $this->dicionario['PACOTE_FULL']['PACOTE_3']['MENSAGENS'] . "</b></td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_3']['MENSALIDADE'] . "</td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_3']['EXCEDENTE'] . "</td>
                                    </tr>
                                    <tr>
                                        <td id='titulo' class='td_table'><b>PACOTE 4</b></td>
                                        <td class='td_table'><b>" . $this->dicionario['PACOTE_FULL']['PACOTE_4']['MENSAGENS'] . "</b></td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_4']['MENSALIDADE'] . "</td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_4']['EXCEDENTE'] . "</td>
                                    </tr>
                                    <tr>
                                        <td id='titulo' class='td_table'><b>PACOTE 5</b></td>
                                        <td class='td_table'><b>" . $this->dicionario['PACOTE_FULL']['PACOTE_5']['MENSAGENS'] . "</b></td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_5']['MENSALIDADE'] . "</td>
                                        <td class='td_table'>" . $this->dicionario['PACOTE_FULL']['PACOTE_5']['EXCEDENTE'] . "</td>
                                    </tr>
                                </table>
                                ";
                        }
                    }

                    $valores_base_lp['debito']  = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "FSP0001", "PIX0016"));
                    $valores_base_lp['credito'] = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "FSP0001", "PIX0012"));
                    if (isset($valores_base_lp['debito']) && isset($valores_base_lp['credito'])) {
                        $dados_minuta["VALORES"]["VALORES_BASE_TARIFACAO"] = "                        
                            <table class='table_lp'>                           
                                <tr>
                                    <td class='td_color'>Crédito do CLIENTE:</td>
                                    <td class='td_table'><b> R$ " . funcValor($valores_base_lp['credito'][0]->valor_real, 'C', 6) . "</b></td>
                                    <td class='td_color'>Debito do CLIENTE:</td>
                                    <td class='td_table'><b> R$ " . funcValor($valores_base_lp['debito'][0]->valor_real, 'C', 6) . "</b></td>
                                </tr>
                            </table>
                            ";
                    }
                    break;
                case "SPI0001":
                    $modulo_proposta    = json_decode($this->controller->modelo->getPropostasModuloByIdProposta($contrato[0]->id_proposta, "ASPIX001", 0));
                    if (isset($modulo_proposta) && !empty($modulo_proposta)) {
                        $assessoria_pix = json_decode($this->controller->modelo->getLpByCodigo("SPI0001", "SPI0024"));
                        if (isset($assessoria_pix) && !empty($assessoria_pix)) {
                            $implantacao_assessoria = funcValor($assessoria_pix[0]->valor_real, 'C', 2);
                        } else {
                            $implantacao_assessoria = $this->dicionario["TEXTO_SLIDE"]["ASSESSORIA"]["ASSESSORIA_PIX"];
                        }
                        if (isset($implantacao_assessoria) && !empty($implantacao_assessoria)) {
                            if ($faturamento[0]->parcelas == "1") {
                                $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"] .= "O valor da assessoria pix é de <b> R$ " . $implantacao_assessoria . " (" . Extenso::converte($implantacao_assessoria, false, false) . ") </b>, que será pago em até 10 (dez) dias após a assinatura do presente contrato.";
                            } else if ($faturamento[0]->parcelas == "2") {
                                $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"] .= "O valor da assessoria pix é de <b> R$ " . $implantacao_assessoria . " (" . Extenso::converte($implantacao_assessoria, false, false) . ") </b>, que serão pagos em 2 (duas) parcelas iguais e consecutivas
                                    sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela.";
                            } else {
                                $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"] .= "O valor da assessoria pix é de <b> R$ " . $implantacao_assessoria . " (" . Extenso::converte($implantacao_assessoria, false, false) . ") </b>, que serão pagos em 3 (duas) parcelas iguais e consecutivas
                                    sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela e a terceira parcela
                                    com vencimento em 30 (trinta) dias após o vencimento da segunda parcela.";
                            }
                        }
                    }
                    if (!isset($dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"])) {
                        $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"] = "";
                    }

                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS"]         = $faturamento[0]->percentual_juros . "%";
                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA"]         = $faturamento[0]->percentual_multa . "%";
                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->percentual_juros, false, false) . " por cento)";
                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->percentual_multa, false, false) . " por cento)";
                    $valores_base_lp['debito']  = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "SPI0001", "SPI0010"));
                    $valores_base_lp['credito'] = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "SPI0001", "SPI0016"));
                    if (isset($valores_base_lp['debito']) && isset($valores_base_lp['credito'])) {
                        $dados_minuta["VALORES"]["VALORES_BASE_TARIFACAO"] = "                 
                                <ul> Valor Integral da transação a Crédito do <b>CLIENTE</b> = " . funcValor($valores_base_lp['credito'][0]->valor_real, 'C', 6) . " </ul>
                                <ul> Valor Integral da transação a Débito do <b>CLIENTE</b> = " . funcValor($valores_base_lp['debito'][0]->valor_real, 'C', 6) . " </ul>                          
                            ";
                    }
                    break;
                case 'YLW0001':
                    // $dados_minuta["FATURAMENTO"]["DURACAO_CONTRATO"]         = str_replace("meses","",$faturamento[0]->duracao_contrato);
                    // $dados_minuta["FATURAMENTO"]["DURACAO_CONTRATO_EXTENSO"] = "(".Extenso::converte($dados_minuta["FATURAMENTO"]["DURACAO_CONTRATO"],false,false).") meses";       
                    $valores_lp = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "YLW0001"));
                    if (isset($valores_lp) && is_array($valores_lp)) {
                        foreach ($valores_lp as $key => $value) {
                            switch ($value->cod_modulo) {
                                case 'YLW0018':
                                    $dados_minuta["VALORES"]['ATIVACAO']         = funcValor($value->valor_real, 'C', 2);
                                    $dados_minuta["VALORES"]['ATIVACAO_EXTENSO'] = "(" . Extenso::converte($dados_minuta["VALORES"]['ATIVACAO'], true, false) . ")";
                                    break;
                                case 'YLW0013':
                                    $dados_minuta["VALORES"]['MANUTENCAO']         = funcValor($value->valor_real, 'C', 2);
                                    $dados_minuta["VALORES"]['MANUTENCAO_EXTENSO'] = "(" . Extenso::converte($dados_minuta["VALORES"]['MANUTENCAO'], true, false) . ")";
                                    break;
                                case 'YLW0012':
                                    $lp_royalty[] = $value;
                                    break;
                                case 'YLW0017':
                                    $dados_minuta["VALORES"]["BAIXA_PAGAMENTO"]           = funcValor($value->valor_real, 'C', 2);
                                    $dados_minuta["VALORES"]["BAIXA_PAGAMENTO_EXTENSO"]   = "(" . Extenso::converte($dados_minuta["VALORES"]["BAIXA_PAGAMENTO"], true, false) . ")";
                                    break;
                                case 'YLW0016':
                                    $dados_minuta["VALORES"]["CORNER_PIX"]         = funcValor($value->valor_real, 'C', 2);
                                    $dados_minuta["VALORES"]["CORNER_PIX_EXTENSO"] = "(" . Extenso::converte($dados_minuta["VALORES"]["CORNER_PIX"], true, false) . ")";
                                    break;
                                case 'YLW0015':
                                    $dados_minuta["VALORES"]["MARKETING_COOPERADO"] = funcValor($value->valor_real, 'C', 2);
                                    $dados_minuta["VALORES"]["MARKETING_COOPERADO_EXTENSO"] = "(" . Extenso::converte($dados_minuta["VALORES"]["MARKETING_COOPERADO"], false, false) . ")";
                                    break;
                                case 'YLW0014':
                                    $dados_minuta["VALORES"]["PORTAL_EMISSOR"] = funcValor($value->valor_real, 'C', 2);
                                    $dados_minuta["VALORES"]["PORTAL_EMISSOR_EXTENSO"] = "(" . Extenso::converte($dados_minuta["VALORES"]["PORTAL_EMISSOR"], false, false) . ")";
                                    break;
                                case 'YLW0011':
                                    $dados_minuta["VALORES"]["API_YELLOW"] = funcValor($value->valor_real, 'C', 2);
                                    $dados_minuta["VALORES"]["API_YELLOW_EXTENSO"] = "(" . Extenso::converte($dados_minuta["VALORES"]["API_YELLOW"], true, false) . ")";
                                    break;
                                default:
                                    # code...
                                    break;
                            }
                        }
                    }

                    if (isset($lp_royalty) && is_array($lp_royalty)) {
                        foreach ($lp_royalty as $key => $value) {
                            if ($value->qtd_de == 1) {
                                $dados_minuta["VALORES"]["ROYALTY_SILVER"]           = funcValor($value->percentual, 'C', 2) . "%";
                                $dados_minuta["VALORES"]["ROYALTY_SILVER_TRANSACAO"] = funcValor($value->qtd_ate, 'C', 0);
                            }
                        }
                    }
                    if (isset($dados_minuta["VALORES"]['ATIVACAO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['ATIVACAO'], $dados_minuta["VALORES"]['ATIVACAO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['ATIVACAO_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['ATIVACAO_EXTENSO'], $dados_minuta["VALORES"]['ATIVACAO_EXTENSO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['MANUTENCAO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['MANUTENCAO_CONTA'], $dados_minuta["VALORES"]['MANUTENCAO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['MANUTENCAO_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['MANUTENCAO_CONTA_EXTENSO'], $dados_minuta["VALORES"]['MANUTENCAO_EXTENSO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['ROYALTY_SILVER'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['PORCENTAGEM_SILVER'], $dados_minuta["VALORES"]['ROYALTY_SILVER'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['ROYALTY_SILVER_TRANSACAO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['TRANSACAO_SILVER'], $dados_minuta["VALORES"]['ROYALTY_SILVER_TRANSACAO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['BAIXA_PAGAMENTO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['BAIXA_PAGAMENTO'], $dados_minuta["VALORES"]['BAIXA_PAGAMENTO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['BAIXA_PAGAMENTO_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['BAIXA_PAGAMENTO_EXTENSO'], $dados_minuta["VALORES"]['BAIXA_PAGAMENTO_EXTENSO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['CORNER_PIX'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['CORNER_PIX'], $dados_minuta["VALORES"]['CORNER_PIX'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['CORNER_PIX_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['CORNER_PIX_EXTENSO'], $dados_minuta["VALORES"]['CORNER_PIX_EXTENSO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['MARKETING_COOPERADO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['MARKETING_COOPERADO'], $dados_minuta["VALORES"]['MARKETING_COOPERADO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['MARKETING_COOPERADO_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['MARKETING_COOPERADO_EXTENSO'], $dados_minuta["VALORES"]['MARKETING_COOPERADO_EXTENSO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['PORTAL_EMISSOR'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['PORTAL_EMISSOR'], $dados_minuta["VALORES"]['PORTAL_EMISSOR'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['PORTAL_EMISSOR_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['PORTAL_EMISSOR_EXTENSO'], $dados_minuta["VALORES"]['PORTAL_EMISSOR_EXTENSO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['API_YELLOW'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['API_YELLOW'], $dados_minuta["VALORES"]['API_YELLOW'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['API_YELLOW_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]['API_YELLOW_EXTENSO'], $dados_minuta["VALORES"]['API_YELLOW_EXTENSO'], $texto);
                    }


                    // if(isset($dados_minuta["FATURAMENTO"]["DURACAO_CONTRATO"])){
                    //     $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["DURACAO_CONTRATO"],$dados_minuta["FATURAMENTO"]["DURACAO_CONTRATO"],$texto);
                    // }
                    // if(isset($dados_minuta["FATURAMENTO"]["DURACAO_CONTRATO_EXTENSO"])){
                    //     $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["DURACAO_CONTRATO_EXTENSO"],$dados_minuta["FATURAMENTO"]["DURACAO_CONTRATO_EXTENSO"],$texto);
                    // }

                    break;
                case 'CRY0001':
                    $lp_crystal = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "CRY0001"));
                    if (isset($lp_crystal) && is_array($lp_crystal)) {
                        foreach ($lp_crystal as $key => $value) {
                            if ($value->cod_modulo == "CRY0011") {
                                $dados_minuta["VALORES"]['OPEN_BANKING']         = funcValor($value->valor_real, 'C', 2);
                                $dados_minuta["VALORES"]['OPEN_BANKING_EXTENSO'] = "(" . Extenso::converte($dados_minuta["VALORES"]['OPEN_BANKING'], true, false) . ")";
                                $dados_minuta["VALORES"]['OPEN_BANKING']         = "R$ " . $dados_minuta["VALORES"]['OPEN_BANKING'];
                            } else if ($value->cod_modulo == "CRY0012") {
                                $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA']         = funcValor($value->valor_real, 'C', 2);
                                $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA_EXTENSO'] = "(" . Extenso::converte($dados_minuta["VALORES"]['TRANSACAO_EXECUTADA'], true, false) . ")";
                                $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA']         = "R$ " . $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA'];
                            }
                        }
                    }

                    if (isset($dados_minuta["VALORES"]['TRANSACAO_EXECUTADA'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CRYSTAL"]['TRANSACAO_EXECUTADA'], $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['TRANSACAO_EXECUTADA_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CRYSTAL"]['TRANSACAO_EXECUTADA_EXTENSO'], $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA_EXTENSO'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['OPEN_BANKING'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CRYSTAL"]['OPEN_BANKING'], $dados_minuta["VALORES"]['OPEN_BANKING'], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]['OPEN_BANKING_EXTENSO'])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CRYSTAL"]['OPEN_BANKING_EXTENSO'], $dados_minuta["VALORES"]['OPEN_BANKING_EXTENSO'], $texto);
                    }
                    break;
                case 'SOE0001':
                    $modulo_proposta    = json_decode($this->controller->modelo->getPropostasModuloByIdProposta($contrato[0]->id_proposta, "ASSTR001", 0));
                    if (isset($modulo_proposta) && !empty($modulo_proposta)) {
                        $assessoria_str = json_decode($this->controller->modelo->getLpByCodigo("SOE0001", "ASSTR001"));
                        if (isset($assessoria_str) && !empty($assessoria_str)) {
                            $implantacao_assessoria = funcValor($assessoria_str[0]->valor_real, 'C', 2);
                        } else {
                            $implantacao_assessoria = $this->dicionario["TEXTO_SLIDE"]["ASSESSORIA"]["ASSESSORIA_STR"];
                        }
                        if (isset($implantacao_assessoria) && !empty($implantacao_assessoria)) {
                            if ($faturamento[0]->parcelas == "1") {
                                $dados_minuta["FATURAMENTO"]["ASSESSORIA_STR"] .= "• O valor da Assessoria BACEN para emissão do ISPB é de <b>  " . $implantacao_assessoria . " (" . Extenso::converte($implantacao_assessoria, false, false) . ")</b>, que será pago em até 10 (dez) dias após a assinatura do presente contrato.";
                            } else if ($faturamento[0]->parcelas == "2") {
                                $dados_minuta["FATURAMENTO"]["ASSESSORIA_STR"] .= "• O valor da Assessoria BACEN para emissão do ISPB é de <b> " . $implantacao_assessoria . " (" . Extenso::converte($implantacao_assessoria, false, false) . ")</b>, que serão pagos em 2 (duas) parcelas iguais e consecutivas
                                    sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela.";
                            } else {
                                $dados_minuta["FATURAMENTO"]["ASSESSORIA_STR"] .= "• O valor da Assessoria BACEN para emissão do ISPB é de <b>  " . $implantacao_assessoria . " (" . Extenso::converte($implantacao_assessoria, false, false) . ")</b>, que serão pagos em 3 (duas) parcelas iguais e consecutivas
                                    sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela e a terceira parcela
                                    com vencimento em 30 (trinta) dias após o vencimento da segunda parcela.";
                            }
                        }
                    } else {
                        $dados_minuta["FATURAMENTO"]["ASSESSORIA_STR"] = "";
                    }

                    $lp_spbx = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "SOE0001"));
                    if (isset($lp_spbx) && is_array($lp_spbx)) {
                        foreach ($lp_spbx as $key => $value) {
                            if ($value->cod_modulo == "SOE0015") {
                                $dados_minuta["VALORES"]["TRATAMENTO_INCONSISTENCIA"] = funcValor($value->valor_real, "C", 3);
                            }
                            if ($value->cod_modulo == "SOE0013") {
                                $dados_minuta["VALORES"]["BAIXA_COMPE"]     = funcValor($value->valor_real, "C", 3);
                            }
                            if ($value->cod_modulo == "SOE0016") {
                                $dados_minuta["VALORES"]["WEBSERVICE"]      = funcValor($value->valor_real, "C", 3);
                            }
                            if ($value->cod_modulo == "SOE0017") {
                                $dados_minuta["VALORES"]["LOTE_ARQUIVO"]    = funcValor($value->valor_real, "C", 3);
                            }
                            if ($value->cod_modulo == "SOE0023") {
                                $dados_minuta["VALORES"]["DEBITO_CLIENTE"]  = funcValor($value->valor_real, "C", 6);
                            }
                            if ($value->cod_modulo == "SOE0018") {
                                $dados_minuta["VALORES"]["CREDITO_CLIENTE"] = funcValor($value->valor_real, "C", 6);
                            }
                            if ($value->cod_modulo == "SOE0033") {
                                $dados_minuta["VALORES"]["HORA_HOMEM"]      = funcValor($value->valor_real, "C", 6);
                            }
                            if ($value->cod_modulo == "PIX0019") {
                                $dados_minuta["VALORES"]["HORA_HOMEM"]      = funcValor($value->valor_real, "C", 6);
                            }
                            if ($value->cod_modulo == "SOE0010") {
                                $lp['spbx'][] = $value;
                            }
                        }
                    }
                    if (isset($lp['spbx']) && !empty($lp['spbx'])) {
                        sort($lp['spbx']);
                        $table_lp = $this->gerarTableHtml($cod_produto, $lp['spbx']);
                    }

                    $pacote = json_decode($this->controller->modelo->getPacotePropostas($contrato[0]->id_proposta, 22, 103));
                    if (isset($pacote) && !empty($pacote)) {
                        if (isset($pacote) && !empty($pacote)) {
                            $dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB"]         = funcValor($pacote[0]->quantidade_garantido, 'C', 0);
                            $dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB_EXTENSO"] = "( " . Extenso::converte($pacote[0]->quantidade_garantido, false, false) . " )";
                            $dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB"]              = "R$ " . funcValor($pacote[0]->preco_pkt, 'C', 2);
                            $dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB_EXTENSO"]      = "( " . Extenso::converte(funcValor($pacote[0]->preco_pkt, 'C', 2), true, false) . " )";
                        }
                    } else {
                        $pacote_default = json_decode($this->controller->modelo->getPacoteDefault(22, 103));
                        if (isset($pacote_default) && !empty($pacote_default)) {
                            $dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB"]         = funcValor($pacote_default[0]->qdt_garantido, 'C', 0);
                            $dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB_EXTENSO"] = "( " . Extenso::converte($pacote_default[0]->qdt_garantido, false, false) . " )";
                            $dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB"]              = "R$ " . funcValor($pacote_default[0]->preco_pkt, 'C', 2);
                            $dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB_EXTENSO"]      = "( " . Extenso::converte(funcValor($pacote_default[0]->preco_pkt, 'C', 2), true, false) . " )";
                        } else {
                            $dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB"]         = "6.000";
                            $dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB_EXTENSO"] = "( seis mil )";
                            $dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB"]              = "R$ 20.000,00";
                            $dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB_EXTENSO"]      = "( vinte mil reais )";
                        }
                    }

                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS"]         = $faturamento[0]->percentual_juros . "%";
                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA"]         = $faturamento[0]->percentual_multa . "%";
                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->percentual_juros, false, false) . " por cento)";
                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->percentual_multa, false, false) . " por cento)";

                    if (isset($dados_minuta["VALORES"]["TRATAMENTO_INCONSISTENCIA"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['TRATAMENTO_INCONSISTENCIA'], $dados_minuta["VALORES"]["TRATAMENTO_INCONSISTENCIA"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["BAIXA_COMPE"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['BAIXA_COMPE'], $dados_minuta["VALORES"]["BAIXA_COMPE"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["WEBSERVICE"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['WEBSERVICE'], $dados_minuta["VALORES"]["WEBSERVICE"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["LOTE_ARQUIVO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['LOTE_ARQUIVO'], $dados_minuta["VALORES"]["LOTE_ARQUIVO"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["DEBITO_CLIENTE"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['DEBITO_CLIENTE'], $dados_minuta["VALORES"]["DEBITO_CLIENTE"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["CREDITO_CLIENTE"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['CREDITO_CLIENTE'], $dados_minuta["VALORES"]["CREDITO_CLIENTE"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["HORA_HOMEM"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['HORA_HOMEM'], $dados_minuta["VALORES"]["HORA_HOMEM"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['TRANSACOES_PACOTE_SPB'], $dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['TRANSACOES_PACOTE_SPB_EXTENSO'], $dados_minuta["FATURAMENTO"]["TRANSACOES_PACOTE_SPB_EXTENSO"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['VALOR_PACOTE_SPB'], $dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['VALOR_PACOTE_SPB_EXTENSO'], $dados_minuta["FATURAMENTO"]["VALOR_PACOTE_SPB_EXTENSO"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['PERCENTUAL_JUROS'], $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['PERCENTUAL_MULTA'], $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['PERCENTUAL_JUROS_EXTENSO'], $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['PERCENTUAL_MULTA_EXTENSO'], $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"], $texto);
                    }
                    if (isset($table_lp) && !empty($table_lp)) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]['TABLE'], $table_lp, $texto);
                    }
                    break;
                case 'ATF0001':
                    $lp_corner = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "ATF0001"));
                    if (isset($lp_corner) && is_array($lp_corner)) {
                        foreach ($lp_corner as $key => $value) {
                            if ($value->cod_modulo == "ATF0010") {
                                $dados_minuta["VALORES"]["VALOR_APROVADO"] = funcValor($value->valor_real, "C", 2);
                                $dados_minuta["VALORES"]["VALOR_APROVADO_EXTENSO"] = "( " . Extenso::converte(funcValor($value->valor_real, "C", 2), true, true) . " )";
                                $dados_minuta["VALORES"]["TRANSACAO_APROVADO"] = "10 (dez)";
                            }
                            if ($value->cod_modulo == "ATF0011") {
                                $dados_minuta["VALORES"]["VALOR_REPROVADO"] = funcValor($value->valor_real, "C", 2);
                                $dados_minuta["VALORES"]["VALOR_REPROVADO_EXTENSO"] = "( " . Extenso::converte(funcValor($value->valor_real, "C", 2), true, true) . " )";
                            }
                            if ($value->cod_modulo == "ATF0012") {
                                $dados_minuta["VALORES"]["VALOR_DETALHADO"] = funcValor($value->valor_real, "C", 2);
                                $dados_minuta["VALORES"]["VALOR_DETALHADO_EXTENSO"] = "( " . Extenso::converte(funcValor($value->valor_real, "C", 2), true, true) . " )";
                            }
                        }
                    }

                    $pacote = json_decode($this->controller->modelo->getPacotePropostas($contrato[0]->id_proposta, 3000000, 3000004));
                    if (isset($pacote) && !empty($pacote)) {
                        $dados_minuta["VALORES"]["PACOTE"] = funcValor($pacote[0]->preco_pkt, "C", 2);
                        $dados_minuta["VALORES"]["PACOTE_EXTENSO"] = "( " . Extenso::converte(funcValor($pacote[0]->preco_pkt, "C", 2), true, true) . " )";
                    }
                    if (isset($dados_minuta["VALORES"]["VALOR_APROVADO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]['VALOR_APROVADO'], $dados_minuta["VALORES"]["VALOR_APROVADO"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["VALOR_APROVADO_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]['VALOR_APROVADO_EXTENSO'], $dados_minuta["VALORES"]["VALOR_APROVADO_EXTENSO"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["TRANSACAO_APROVADO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]['TRANSACAO_APROVADO'], $dados_minuta["VALORES"]["TRANSACAO_APROVADO"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["VALOR_REPROVADO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]['VALOR_REPROVADO'], $dados_minuta["VALORES"]["VALOR_REPROVADO"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["VALOR_REPROVADO_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]['VALOR_REPROVADO_EXTENSO'], $dados_minuta["VALORES"]["VALOR_REPROVADO_EXTENSO"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["VALOR_DETALHADO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]['VALOR_DETALHADO'], $dados_minuta["VALORES"]["VALOR_DETALHADO"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["VALOR_DETALHADO_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]['VALOR_DETALHADO_EXTENSO'], $dados_minuta["VALORES"]["VALOR_DETALHADO_EXTENSO"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["PACOTE"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]["PACOTE"], $dados_minuta["VALORES"]["PACOTE"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["PACOTE_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]["PACOTE_EXTENSO"], $dados_minuta["VALORES"]["PACOTE_EXTENSO"], $texto);
                    }
                    break;
                case 'TPX0001':
                    $lp_triplo_pix = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "TPX0001"));
                    if (isset($lp_triplo_pix) && is_array($lp_triplo_pix)) {
                        foreach ($lp_triplo_pix as $key => $value) {
                            if ($value->cod_modulo == "TPX0011") {
                                $dados_minuta["VALORES"]["LP_TRIPLO_PIX"] = "R$ " . funcValor($value->valor_real, "C", 2);
                                $dados_minuta["VALORES"]["LP_TRIPLO_PIX_EXTENSO"] = "( " . Extenso::converte(funcValor($value->valor_real, "C", 2), true, true) . " )";
                            }
                        }
                    }
                    if (isset($dados_minuta["VALORES"]["LP_TRIPLO_PIX"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["TRIPLO_PIX"]['TRIPLO_PIX'], $dados_minuta["VALORES"]["LP_TRIPLO_PIX"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["LP_TRIPLO_PIX_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["TRIPLO_PIX"]['TRIPLO_PIX_EXTENSO'], $dados_minuta["VALORES"]["LP_TRIPLO_PIX_EXTENSO"], $texto);
                    }
                    break;
                case 'ECS0001':
                    $pacote_ecs = json_decode($this->controller->modelo->getPacotePropostas($contrato[0]->id_proposta, 21, 94));
                    if (isset($pacote_ecs) && !empty($pacote_ecs)) {
                        $dados_minuta["VALORES"]["PACOTE_ECS"] = "R$ " . funcValor($pacote_ecs[0]->preco_pkt, "C", 2);
                        $dados_minuta["VALORES"]["PACOTE_ECS_EXTENSO"] = "( " . Extenso::converte(funcValor($pacote_ecs[0]->preco_pkt, 'C', 2), true, false) . " )";
                    } else {
                        $lp_ecs = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "ECS0001"));
                        foreach ($lp_ecs as $key => $value) {
                            if ($value->cod_modulo == "ECS0011") {
                                $dados_minuta["VALORES"]["PACOTE_ECS"] = "R$ " . funcValor($value->valor_real, "C", 2);
                                $dados_minuta["VALORES"]["PACOTE_ECS_EXTENSO"] = "( " . Extenso::converte(funcValor($value->valor_real, "C", 2), true, true) . " )";
                            }
                        }
                    }

                    if (isset($dados_minuta["VALORES"]["PACOTE_ECS"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["ECS"]['PACOTE'], $dados_minuta["VALORES"]["PACOTE_ECS"], $texto);
                    }
                    if (isset($dados_minuta["VALORES"]["PACOTE_ECS_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["ECS"]['PACOTE_EXTENSO'], $dados_minuta["VALORES"]["PACOTE_ECS_EXTENSO"], $texto);
                    }

                    break;
                case 'ADM0001':
                    $hora_homem = json_decode($this->controller->modelo->getLpId(null, $contrato[0]->id_proposta, "RCK0001", "RCK0052"));
                    if (isset($hora_homem) && !empty($hora_homem)) {
                        $dados_minuta["FATURAMENTO"]["HORA_HOMEM"] = funcValor($hora_homem[0]->valor_real, 'C', 2);
                        $dados_minuta["FATURAMENTO"]["HORA_HOMEM_EXTENSO"] = "( " . Extenso::converte($dados_minuta["FATURAMENTO"]["HORA_HOMEM"], true, true) . " )";
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["HORA_HOMEM"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]['HORA_HOMEM'], $dados_minuta["FATURAMENTO"]["HORA_HOMEM"], $texto);
                    }
                    if (isset($dados_minuta["FATURAMENTO"]["HORA_HOMEM_EXTENSO"])) {
                        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]['HORA_HOMEM_EXTENSO'], $dados_minuta["FATURAMENTO"]["HORA_HOMEM_EXTENSO"], $texto);
                    }
                    break;
                default:
                    //default                   
                    break;
            }
        }

        //CLIENTE
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["CLIENTE"], $dados_minuta["CLIENTE"], $texto);
        //ENDERECO
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["ENDERECO"], $dados_minuta["ENDERECO"], $texto);
        //RESPONSÁVEL LEGAL 2
        if (isset($dados_minuta["REPRESENTANTE_2"])) {
            $add_texto = "e " . $dados_minuta["REPRESENTANTE_2"]["NOME"] . ", " . $dados_minuta["REPRESENTANTE_2"]["CARGO"] . ", " . "C.P.F. n°" . $dados_minuta['REPRESENTANTE_2']["CPF"]
                . ", e-mail " . $dados_minuta["REPRESENTANTE_2"]["EMAIL"] . ", telefone " . $dados_minuta["REPRESENTANTE_2"]["TELEFONE"];
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["REPRESENTANTE"]['REPRESENTANTE_2'], $add_texto, $texto);
        } else {
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["REPRESENTANTE"]['REPRESENTANTE_2'], ",", $texto);
        }

        //RESPONSÁVEL LEGAL 
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["REPRESENTANTE"], $dados_minuta["REPRESENTANTE"], $texto);
        //CONTATOS FINANCEIRO      
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["CONTATO"]['CONTATO_FINANCEIRO'], $dados_minuta["CONTATO_FINANCEIRO"]["NOME"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["CONTATO"]['CONTATO_FINANCEIRO/EMAIL'], $dados_minuta["CONTATO_FINANCEIRO"]["EMAIL"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["CONTATO"]['CONTATO_FINANCEIRO/TELEFONE'], $dados_minuta["CONTATO_FINANCEIRO"]["TELEFONE"], $texto);

        //CONTATOS FINANCEIRO 2
        if (isset($dados_minuta["CONTATO_FINANCEIRO"]["CONTATO_FINANCEIRO_2"])) {
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["CONTATO"]['CONTATO_FINANCEIRO_2'], $dados_minuta["CONTATO_FINANCEIRO"]["CONTATO_FINANCEIRO_2"], $texto);
        }

        //CONTATO RESPONSAVEL 
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["CONTATO"]['CONTATO_RESPONSAVEL/NOME'], $dados_minuta["CONTATO_RESPONSAVEL"]["NOME"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["CONTATO"]['CONTATO_RESPONSAVEL/EMAIL'], $dados_minuta["CONTATO_RESPONSAVEL"]["EMAIL"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["CONTATO"]['CONTATO_RESPONSAVEL/TELEFONE'], $dados_minuta["CONTATO_RESPONSAVEL"]["TELEFONE"], $texto);
        //TESTEMUNHAS
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]['TESTEMUNHA'], $dados_minuta["TESTEMUNHA"]["NOME"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]['TESTEMUNHA_EMAIL'], $dados_minuta["TESTEMUNHA"]["EMAIL"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]['TESTEMUNHA_CPF'], $dados_minuta["TESTEMUNHA"]["CPF"], $texto);
        //TESTEMUNHAS CM
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]['TESTEMUNHA_CMSW'], $dados_minuta["TESTEMUNHA_CM"]["NOME"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]['TESTEMUNHA_CMSW/CPF'], $dados_minuta["TESTEMUNHA_CM"]["CPF"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]['TESTEMUNHA_CMSW/EMAIL'], $dados_minuta["TESTEMUNHA_CM"]["EMAIL"], $texto);
        //FATURAMENTO
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["IMPLANTACAO"], $dados_minuta["FATURAMENTO"]["IMPLANTACAO"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["IMPLANTACAO_EXTENSO"], $dados_minuta["FATURAMENTO"]["IMPLANTACAO_EXTENSO"], $texto);
        //EMPRESA C&M
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["C&M"]["CM_SOFTWARE"], $dados_minuta["FATURAMENTO"]["CM"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["C&M"]["CM_SOFTWARE_CNPJ"], $dados_minuta["FATURAMENTO"]["CM_CNPJ"], $texto);

        if (isset($dados_minuta["FATURAMENTO"]["PACOTE"])) {
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PACOTE"], $dados_minuta["FATURAMENTO"]["PACOTE"], $texto);
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PACOTE_EXTENSO"], $dados_minuta["FATURAMENTO"]["PACOTE_EXTENSO"], $texto);
        }

        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["CORTE_FATURAMENTO"], $dados_minuta["FATURAMENTO"]["CORTE_FATURAMENTO"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["CORTE_FATURAMENTO_EXTENSO"], $dados_minuta["FATURAMENTO"]["CORTE_FATURAMENTO_EXTENSO"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PRAZO_PAGAMENTO"], $dados_minuta["FATURAMENTO"]["PRAZO_PAGAMENTO"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PRAZO_PAGAMENTO_EXTENSO"], $dados_minuta["FATURAMENTO"]["PRAZO_PAGAMENTO_EXTENSO"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PRIMEIRO_FATURAMENTO"], $dados_minuta["FATURAMENTO"]["PRIMEIRO_FATURAMENTO"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["IMPLANTACAO_TEXTO"], $dados_minuta["FATURAMENTO"]["IMPLANTACAO_TEXTO"], $texto);
        // $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PRIMEIRO_FATURAMENTO_EXTENSO"],$dados_minuta["FATURAMENTO"]["PRIMEIRO_FATURAMENTO_EXTENSO"],$texto);        

        //PACOTE ENGINE
        if (isset($dados_minuta["FATURAMENTO"]["TRANSACOES_ENGINE"])) {
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["TRANSACOES_ENGINE"], $dados_minuta["FATURAMENTO"]["TRANSACOES_ENGINE"], $texto);
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["TRANSACOES_ENGINE_EXTENSO"], $dados_minuta["FATURAMENTO"]["TRANSACOES_ENGINE_EXTENSO"], $texto);
        }
        //ASSESSORIA STR        
        if (isset($dados_minuta["FATURAMENTO"]["ASSESSORIA_STR"])) {
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["ASSESSORIA_STR"], $dados_minuta["FATURAMENTO"]["ASSESSORIA_STR"], $texto);
        }
        //ASSESSORIA BACEN        
        if (isset($dados_minuta["FATURAMENTO"]["ASSESSORIA_BACEN"])) {
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["ASSESSORIA_BACEN"], $dados_minuta["FATURAMENTO"]["ASSESSORIA_BACEN"], $texto);
        }
        //ASSESSORIA PIX
        if (isset($dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"])) {
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["ASSESSORIA_PIX"], $dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"], $texto);
        }
        //HORA HOMEM
        if (isset($dados_minuta["FATURAMENTO"]["HORA_HOMEM"])) {
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["HORA_HOMEM"], $dados_minuta["FATURAMENTO"]["HORA_HOMEM"], $texto);
        }
        if (isset($dados_minuta["VALORES"]["PACOTE_FULL"])) {
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["FULL"]["PACOTE_FULL_STR"], $dados_minuta["VALORES"]["PACOTE_FULL"], $texto);
        }
        if (isset($dados_minuta["VALORES"]["VALORES_BASE_TARIFACAO"])) {
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["VALORES"]["FULL"]["VALORES_BASE_TARIFACAO"], $dados_minuta["VALORES"]["VALORES_BASE_TARIFACAO"], $texto);
        }
        if (isset($dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS"])) {
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_JUROS"], $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS"], $texto);
        }
        if (isset($dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"])) {
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"], $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"], $texto);
        }
        if (isset($dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA"])) {
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_MULTA"], $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA"], $texto);
        }
        if (isset($dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"])) {
            $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"], $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"], $texto);
        }

        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["VIGENCIA_CONTRATO"], $dados_minuta["FATURAMENTO"]["VIGENCIA_CONTRATO"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["VIGENCIA_CONTRATO_EXTENSO"], $dados_minuta["FATURAMENTO"]["VIGENCIA_CONTRATO_EXTENSO"], $texto);
        $texto = str_replace($this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["INDICE_REAJUSTE"], $dados_minuta["FATURAMENTO"]["INDICE_REAJUSTE"], $texto);
        return $texto;
    }


    function organizaListaPreco($cod_produto, $grupo, $lp, $pacote = null)
    {
        switch ($cod_produto) {
            case 'RCK0001':
                switch ($grupo) {
                    case 'rocket':
                        $excecao = array("RCK0011", "RCK0015", "RCK0016", "RCK0017", "RCK0018", "RCK0019", "RCK0020", "RCK0024", "RCK0025", "RCK0028", "RCK0030", "RCK0038");
                        break;
                    case 'validacao_cadastral':
                        $excecao = array('RCK0026', 'RCK0012', 'RCK0013', 'RCK0014', 'RCK0021', 'RCK0022');
                        break;
                    case 'carta':
                        $excecao = array('RCK0023');
                        break;
                    case 'suite_liquidacao':
                        $excecao = array('RCK0029', 'RCK0032', 'RCK0042', 'RCK0041', 'RCK0044', 'RCK0050', 'RCK0045', 'RCK0046', 'RCK0049');
                        break;
                    case 'open_banking':
                        $excecao = array('RCK0060', 'RCK0061', 'RCK0062', 'RCK0063', 'RCK0064', 'RCK0065', 'RCK0066', 'RCK0067');
                        break;
                    case 'serpro':
                        $excecao = array('RCK0036');
                        break;
                    case 'engine':
                        $excecao = array('RCK0010');
                        break;
                    case 'token_pix':
                        $excecao = array('RCK0069');
                        break;
                    case 'face_id':
                        $excecao = array('RCK0070');
                        break;
                    default:
                        $excecao = array("RCK0011", "RCK0015", "RCK0016", "RCK0017", "RCK0018", "RCK0019", "RCK0020", "RCK0024", "RCK0025", "RCK0028", "RCK0030", "RCK0038");
                        break;
                }

                if ($lp) {
                    $contador = 0;
                    $contador_faixa = 0;
                    foreach ($lp as $key => $value) {
                        if (in_array($value->codigo_modulo, $excecao)) {
                            $i1 = $value->codigo_modulo;
                            if ($grupo == "serpro") {
                                if ($value->qtd_de < '20001') {
                                    $tabela['header'][$i1] = strtoupper($value->descricao);
                                    ksort($tabela['header']);
                                    $tabela['faixa'][$value->qtd_de][$i1] = funcValor($value->valor_real, 'C', 6);
                                    ksort($tabela['faixa'][$value->qtd_de]);
                                } else {
                                    $i1 = $value->codigo_modulo;
                                    $tabela['faixa']["Acima de"][$i1] = funcValor($value->valor_real, 'C', 6);
                                }
                            } else if ($grupo == "carta") {
                                if ($value->qtd_de < '2501') {
                                    $tabela['header'][$i1] = strtoupper($value->descricao);
                                    ksort($tabela['header']);
                                    $tabela['faixa'][$value->qtd_de . "_" . $value->qtd_ate][$i1] = funcValor($value->valor_real, 'C', 6);
                                    ksort($tabela['faixa'][$value->qtd_de . "_" . $value->qtd_ate]);
                                } else {
                                    $i1 = $value->codigo_modulo;
                                    $tabela['faixa']["Acima de_" . $value->qtd_de][$i1] = funcValor($value->valor_real, 'C', 6);
                                }
                            } else {
                                if ($value->qtd_de < '10000001') {
                                    if ($grupo == "rocket") {
                                        $tabela['header'][$i1] = str_replace("CONSOLE", "", strtoupper($value->descricao));
                                    } else if ($grupo == "open_banking") {
                                        $tabela['header'][$i1] = str_replace("ROCKET OPEN BANKING -", "", strtoupper($value->descricao));
                                        $tabela['header'][$i1] = str_replace("çã", "ÇÃ", strtoupper($value->descricao));
                                    } else {
                                        $tabela['header'][$i1] = strtoupper($value->descricao);
                                    }
                                    ksort($tabela['header']);
                                    if (isset($pacote) && !empty($pacote)) {
                                        if ($contador_faixa == 0) {
                                            $value->qtd_de = $pacote[0]->quantidade_garantido + 1;
                                        }
                                    }
                                    $tabela['faixa'][$value->qtd_de . "_" . $value->qtd_ate][$i1] = funcValor($value->valor_real, 'C', 6);
                                    ksort($tabela['faixa'][$value->qtd_de . "_" . $value->qtd_ate]);
                                } else {
                                    $i1 = $value->codigo_modulo;
                                    $tabela['faixa']["ACIMA DE_10.000.000"][$i1] = funcValor($value->valor_real, 'C', 6);
                                }
                            }
                            $contador_faixa++;
                        }
                        $contador++;
                    }
                } else {
                    return false;
                }
                break;

            default:
                # code...
                break;
        }
        return $tabela;
    }

    function gerarTableHtml($cod_produto, $tabela, $grupo = null, $table_height = null, $pacote_modulo = null)
    {
        switch ($cod_produto) {
            case 'RCK0001':
                if (isset($tabela) && !empty($tabela)) {
                    $tabela_html = "<div class='div_table' style='height:$table_height'> <br></br>";
                    $tabela_html .= "<table class='table_lista_preco' border='' cellpadding='1' cellspacing='1'>";
                    $tabela_html .= "<thead>";
                    $tabela_html .= "<tr class='tr_header'>";
                    if ($grupo == "carta") {
                        $tabela_html .= "<th class='th_header'> <b>De</b> </th>";
                        $tabela_html .= "<th class='th_header'> <b>Até</b> </th>";
                        $tabela_html .= "<th class='th_header'> <b>Custo</b> </th>";
                        $tabela_html .= "<th class='th_header'> <b>Obs</b> </th>";
                    } else if ($grupo == "serpro") {
                        $tabela_html .= "<th class='th_header'> <b>De</b> </th>";
                        $tabela_html .= "<th class='th_header'> <b>Custo</b> </th>";
                        $tabela_html .= "<th class='th_header'> <b>Obs</b> </th>";
                    } else {
                        if ($grupo == "engine") {
                            $tabela_html .= "<th class='th_header' style='width:20%'> <b>DE</b> </th>";
                            $tabela_html .= "<th class='th_header' style='width:20%'> <b>ATÉ</b> </th>";
                            foreach ($tabela["header"] as $key => $value) {
                                $tabela_html .= "<th class='th_header' style='width:60%'><b>" . $value . "</b> <br> <b class='b_header'>(" . $key . ")</b>" . "</th>";
                            }
                        } else {
                            if ($grupo == "face_id" || $grupo == "token_pix") {
                                $tabela_html .= "<th class='th_header' style='height:70px'> <b>DE</b> </th>";
                                $tabela_html .= "<th class='th_header' style='height:70px'> <b>ATÉ</b> </th>";
                                foreach ($tabela["header"] as $key => $value) {
                                    $tabela_html .= "<th class='th_header' style='height:70px'><b>" . $value . "</b> <br> <b class='b_header'>(" . $key . ")</b>" . "</th>";
                                }
                            } else {
                                $tabela_html .= "<th class='th_header'> <b>DE</b> </th>";
                                $tabela_html .= "<th class='th_header'> <b>ATÉ</b> </th>";
                                foreach ($tabela["header"] as $key => $value) {
                                    $tabela_html .= "<th class='th_header'><b>" . $value . "</b> <br> <b class='b_header'>(" . $key . ")</b>" . "</th>";
                                }
                            }
                        }
                    }

                    $tabela_html .= "</tr>";
                    $tabela_html .= "</thead>";
                    $tabela_html .= "<tbody>";
                    $contador_faixa = 0;
                    if ($contador_faixa == 0 && $grupo == "carta") {
                        $tabela_html .= "<tr class='tr_body'>";
                        $tabela_html .= "<td class='td_faixa'>0</td>";
                        $tabela_html .= "<td class='td_faixa'>250</td>";
                        $tabela_html .= "<td class='td_valor'>" . funcValor($pacote_modulo['RCK0023']->preco_pkt, "C", 2) . "</td>";
                        $tabela_html .= "<td class='td_valor'>Fixo Mensal</td>";
                        $tabela_html .= "</tr>";
                    } else if ($contador_faixa == 0 && $grupo == "serpro") {
                        $tabela_html .= "<tr class='tr_body'>";
                        $tabela_html .= "<td class='td_faixa'>0</td>";
                        $tabela_html .= "<td class='td_valor'>" . funcValor($pacote_modulo['RCK0036']->preco_pkt, "C", 2) . "</td>";
                        $tabela_html .= "<td class='td_valor'>Fixo Mensal</td>";
                        $tabela_html .= "</tr>";
                    }

                    foreach ($tabela["faixa"] as $key_faixa => $value_faixa) {
                        $contador = 0;

                        $tabela_html .= "<tr class='tr_body'>";
                        foreach ($tabela["header"] as $key_header => $value_header) {
                            $explode_faixa = explode("_", $key_faixa);
                            if ($contador == 0 && strtoupper($explode_faixa[0]) != "ACIMA DE") {
                                if ($grupo == "face_id" || $grupo == "token_pix") {
                                    $tabela_html .= "<td class='td_faixa' style='height:50px'>" . funcValor($explode_faixa[0], 'C', 0) . "</td>";
                                } else {
                                    $tabela_html .= "<td class='td_faixa'>" . funcValor($explode_faixa[0], 'C', 0) . "</td>";
                                }
                            } else if ($contador == 0 && strtoupper($explode_faixa[0]) == "ACIMA DE") {
                                $tabela_html .= "<td class='td_faixa'>" . $explode_faixa[0] . "</td>";
                            }

                            if ($grupo == "carta") {
                                if ($contador == 0 && strtoupper($explode_faixa[0]) != "ACIMA DE") {
                                    $tabela_html .= "<td class='td_faixa'>" . funcValor($explode_faixa[1], 'C', 0) . "</td>";
                                } else if ($contador == 0 && strtoupper($explode_faixa[0]) == "ACIMA DE") {
                                    $tabela_html .= "<td class='td_faixa'>" . funcValor(($explode_faixa[1] - 1), 'C', 0) . "</td>";
                                }
                                $tabela_html .= "<td class='td_valor'>" . $value_faixa[$key_header] . "</td>";
                                $tabela_html .= "<td class='td_valor'>Unitário adicional</td>";
                            } else if ($grupo == "serpro") {
                                $tabela_html .= "<td class='td_valor'>" . $value_faixa[$key_header] . "</td>";
                                $tabela_html .= "<td class='td_valor'>Unitário adicional</td>";
                            } else if ($grupo == "face_id" || $grupo == "token_pix") {
                                $tabela_html .= "<td class='td_faixa' style='height:50px'>" . funcValor($explode_faixa[1], 'C', 0) . "</td>";
                                $tabela_html .= "<td class='td_valor' style='height:50px'>" . $value_faixa[$key_header] . "</td>";
                            } else {
                                if ($contador == 0 && strtoupper($explode_faixa[0]) != "ACIMA DE") {
                                    $tabela_html .= "<td class='td_faixa'>" . funcValor($explode_faixa[1], 'C', 0) . "</td>";
                                } else if ($contador == 0 && strtoupper($explode_faixa[0]) == "ACIMA DE") {
                                    $tabela_html .= "<td class='td_faixa'>" . $explode_faixa[1] . "</td>";
                                }
                                $tabela_html .= "<td class='td_valor'>" . $value_faixa[$key_header] . "</td>";
                            }

                            $contador++;
                        }
                        $tabela_html .= "</tr>";
                        $contador_faixa++;
                    }

                    $tabela_html .= "</tbody>";
                    $tabela_html .= "</table>";
                    $tabela_html .= "</div>";
                }
                break;
            case 'SOE0001':
                $tabela_html = "
                    <table class='table_lp'>
                        <thead>
                            <tr class='tr_table'>
                                <th class='th_table'> De </th>
                                <th class='th_table'> Até </th>
                                <th class='th_table'> Unitário </th>
                            <tr>
                        </thead>
                        <tbody>";
                foreach ($tabela as $key => $value) {
                    $tabela_html .= "
                            <tr>
                                <td class='td_table'>" . funcValor($value->qtd_de, 'C', 0) . "</td> 
                                <td class='td_table'>" . funcValor($value->qtd_ate, 'C', 0) . "</td>
                                <td class='td_table'>" . funcValor($value->valor_real, 'C', 6) . "</td>
                            </tr>";
                }
                $tabela_html .= "                       
                        </tbody>
                    </table>
                    ";
                break;
            default:
                # code...
                break;
        }

        return $tabela_html;
    }

    public function checkTag($cod_produto)
    {
        //TAG CLIENTE             
        $tag_contador['cliente'][0] = 1;
        $tag_contador['cliente'][1] = 1;
        //TAG ENDEREÇO
        $tag_contador['endereco'][] = 1;
        $tag_contador['endereco'][] = 1;
        //TAG BAIRRO
        $tag_contador['bairro'][] = 1;
        $tag_contador['bairro'][] = 1;
        //TAG CEP
        $tag_contador['cep'][]    = 1;
        $tag_contador['cep'][]    = 1;
        //TAG CIDADE
        $tag_contador['cidade'][] = 1;
        $tag_contador['cidade'][] = 1;
        //TAG UF
        $tag_contador['uf'][]     = 1;
        $tag_contador['uf'][]     = 1;
        // TAG REPRESENTANTE LEGAL
        $tag_contador['representante_legal'][0]          = 1;
        $tag_contador['representante_legal'][1]          = 1;
        $tag_contador['representante_legal_cargo'][1]    = 1;
        $tag_contador['representante_legal_cpf'][1]      = 1;
        $tag_contador['representante_legal_email'][1]    = 1;
        $tag_contador['representante_legal_telefone'][1] = 1;
        //TAG REPRESENTANTE 2
        $tag_contador['representante_legal_2'][1]        = 1;
        //TAG CNPJ
        $tag_contador['cnpj'][1] = 1;
        //TAG CONTATO FINANCEIRO                
        $tag_contador['contato_financeiro'][1]          = 1;
        $tag_contador['contato_financeiro_email'][1]    = 1;
        $tag_contador['contato_financeiro_telefone'][1] = 1;
        //TAG TESTEMUNHA
        $tag_contador['testemunha'][1]       = 1;
        $tag_contador['testemunha_cpf'][1]   = 1;
        $tag_contador['testemunha_email'][1] = 1;
        //TAG TESTEMUNHA CM SOFTWARE
        $tag_contador['testemunha_cmsw'][1]       = 1;
        $tag_contador['testemunha_cmsw_cpf'][1]   = 1;
        $tag_contador['testemunha_cmsw_email'][1] = 1;
        switch ($cod_produto) {
            case 'RCK0001':
                //TAG IMPLANTACAO
                $tag_contador['implantacao'][1]         = 1;
                $tag_contador['implantacao_extenso'][1] = 1;
                $tag_contador['implantacao'][3]         = 1;
                $tag_contador['implantacao_extenso'][3] = 1;
                //TAG PACOTE
                $tag_contador['pacote'][1]         = 1;
                $tag_contador['pacote_extenso'][1] = 1;
                $tag_contador['pacote'][3]         = 1;
                $tag_contador['pacote_extenso'][3] = 1;
                //TAG TRANSAÇÕES ENGINE
                $tag_contador['transacoes_engine'][1]         = 1;
                $tag_contador['transacoes_engine_extenso'][1] = 1;
                $tag_contador['transacoes_engine'][3]         = 1;
                $tag_contador['transacoes_engine_extenso'][3] = 1;
                //TAG FATURAMENTO
                $tag_contador['corte_faturamento'][1]         = 1;
                $tag_contador['corte_faturamento_extenso'][1] = 1;
                $tag_contador['corte_faturamento'][3]         = 1;
                $tag_contador['corte_faturamento_extenso'][3] = 1;
                //TAG PRAZO 
                $tag_contador['prazo_pagamento'][1]         = 1;
                $tag_contador['prazo_pagamento_extenso'][1] = 1;
                $tag_contador['prazo_pagamento'][3]         = 1;
                $tag_contador['prazo_pagamento_extenso'][3] = 1;
                //TAG FATURAMENTO
                $tag_contador['vigencia_contrato'][1]         = 1;
                $tag_contador['vigencia_contrato'][3]         = 1;
                $tag_contador['vigencia_contrato_extenso'][1] = 1;
                $tag_contador['indice_reajuste'][1]           = 1;
                $tag_contador['indice_reajuste'][4]           = 1;
                break;
            case 'FSP0001':
                //TAG IMPLANTACAO
                $tag_contador['implantacao'][1]         = 1;
                $tag_contador['implantacao_extenso'][1] = 1;
                // $tag_contador['assessoria_bacen'][1] = 1;
                $tag_contador['hora_homem'][1] = 1;
                //TAG FATURAMENTO
                $tag_contador['corte_faturamento'][1]         = 1;
                $tag_contador['corte_faturamento_extenso'][1] = 1;
                $tag_contador['corte_faturamento'][2]         = 1;
                $tag_contador['corte_faturamento_extenso'][2] = 1;
                //TAG PRAZO 
                $tag_contador['prazo_pagamento'][1]         = 1;
                $tag_contador['prazo_pagamento_extenso'][1] = 1;
                $tag_contador['prazo_pagamento'][2]         = 1;
                $tag_contador['prazo_pagamento_extenso'][2] = 1;
                //TAG FATURAMENTO
                $tag_contador['vigencia_contrato'][1]         = 1;
                $tag_contador['vigencia_contrato_extenso'][1] = 1;
                $tag_contador['indice_reajuste'][1]           = 1;
                $tag_contador['indice_reajuste'][2]           = 1;
                //PACOTES E VALORES BASES
                $tag_contador['pacote_full_str'][1] = 1;
                $tag_contador['valores_base'][1]    = 1;
                break;
            case 'SPI0001':
                //TAG IMPLANTACAO
                $tag_contador['implantacao'][7]         = 1;
                $tag_contador['implantacao_extenso'][7] = 1;
                // $tag_contador['implantacao_texto'][7]   = 1;                           
                //TAG FATURAMENTO
                $tag_contador['corte_faturamento'][2]         = 1;
                $tag_contador['corte_faturamento_extenso'][2] = 1;
                //TAG PRAZO 
                $tag_contador['prazo_pagamento'][2]         = 1;
                $tag_contador['prazo_pagamento_extenso'][2] = 1;

                // $tag_contador['primeiro_faturamento'][2] = 1;
                // $tag_contador['primeiro_faturamento_extenso'][2] = 1;

                //TAG FATURAMENTO
                $tag_contador['indice_reajuste'][1]          = 1;
                $tag_contador['percentual_multa'][4]         = 1;
                $tag_contador['percentual_multa_extenso'][4] = 1;
                $tag_contador['percentual_juros'][4]         = 1;
                $tag_contador['percentual_juros_extenso'][4] = 1;
                //PACOTES E VALORES BASES                
                $tag_contador['valores_base'][7] = 1;
                //TAG TESTEMUNHA
                unset($tag_contador['testemunha']);
                unset($tag_contador['testemunha_cpf']);
                unset($tag_contador['testemunha_email']);
                $tag_contador['testemunha'][2]       = 1;
                $tag_contador['testemunha_cpf'][2]   = 1;
                $tag_contador['testemunha_email'][2] = 1;
                //TAG TESTEMUNHA CM SOFTWARE
                unset($tag_contador['testemunha_cmsw']);
                unset($tag_contador['testemunha_cmsw_cpf']);
                unset($tag_contador['testemunha_cmsw_email']);
                $tag_contador['testemunha_cmsw'][2]       = 1;
                $tag_contador['testemunha_cmsw_cpf'][2]   = 1;
                $tag_contador['testemunha_cmsw_email'][2] = 1;
                break;
            case 'YLW0001':
                $tag_contador['vigencia_contrato'][1]         = 1;
                $tag_contador['vigencia_contrato_extenso'][1] = 1;
                $tag_contador['vigencia_contrato'][3]         = 1;
                $tag_contador['vigencia_contrato_extenso'][3] = 1;

                $tag_contador['indice_reajuste'][1] = 1;
                $tag_contador['indice_reajuste'][4] = 2;
                $tag_contador['indice_reajuste'][5] = 1;
                //TAG FATURAMENTO
                $tag_contador['corte_faturamento'][1]         = 1;
                $tag_contador['corte_faturamento_extenso'][1] = 1;
                $tag_contador['corte_faturamento'][4]         = 1;
                $tag_contador['corte_faturamento_extenso'][4] = 1;
                //TAG PRAZO 
                $tag_contador['prazo_pagamento'][1]         = 1;
                $tag_contador['prazo_pagamento_extenso'][1] = 1;
                $tag_contador['prazo_pagamento'][4]         = 1;
                $tag_contador['prazo_pagamento_extenso'][4] = 1;
                //IMPLANTAÇÃO
                $tag_contador['implantacao'][3]         = 1;
                $tag_contador['implantacao_extenso'][3] = 1;
                // $tag_contador['implantacao_texto'][3]   = 1;               
                //LP
                $tag_contador['ativacao'][3]                    = 1;
                $tag_contador['ativacao_extenso'][3]            = 1;
                $tag_contador['manutencao_conta'][3]            = 1;
                $tag_contador['manutencao_conta_extenso'][3]    = 1;
                $tag_contador['transacao_silver'][3]            = 1;
                $tag_contador['porcentagem_silver'][3]          = 1;
                $tag_contador['baixa_pagamento'][4]             = 1;
                $tag_contador['baixa_pagamento_extenso'][4]     = 1;
                $tag_contador['corner_pix'][4]                  = 1;
                $tag_contador['corner_pix_extenso'][4]          = 1;
                $tag_contador['portal_emissor'][4]              = 1;
                $tag_contador['portal_emissor_extenso'][4]      = 1;
                $tag_contador['api_yellow'][4]                  = 1;
                $tag_contador['api_yellow_extenso'][4]          = 1;
                $tag_contador['marketing_cooperado'][4]         = 1;
                $tag_contador['marketing_cooperado_extenso'][4] = 1;
                //CLIENTE
                $tag_contador['cliente'][2] = 1;
                break;
            case 'CRY0001':
                $tag_contador['vigencia_contrato'][1]         = 1;
                $tag_contador['vigencia_contrato_extenso'][1] = 1;

                $tag_contador['indice_reajuste'][1]     = 1;
                $tag_contador['indice_reajuste'][3]     = 1;
                $tag_contador['indice_reajuste'][4]     = 1;

                $tag_contador['implantacao'][1]         = 1;
                $tag_contador['implantacao_extenso'][1] = 1;
                $tag_contador['implantacao'][3]         = 1;
                $tag_contador['implantacao_extenso'][3] = 1;

                $tag_contador['transacao_executada'][1]         = 1;
                $tag_contador['transacao_executada_extenso'][1] = 1;
                $tag_contador['transacao_executada'][3]         = 1;
                $tag_contador['transacao_executada_extenso'][3] = 1;
                $tag_contador['open_banking'][1]                = 1;
                $tag_contador['open_banking_extenso'][1]        = 1;
                $tag_contador['open_banking'][3]                = 1;
                $tag_contador['open_banking_extenso'][3]        = 1;
                //TAG FATURAMENTO
                $tag_contador['corte_faturamento'][1]         = 1;
                $tag_contador['corte_faturamento_extenso'][1] = 1;
                $tag_contador['corte_faturamento'][3]         = 1;
                $tag_contador['corte_faturamento_extenso'][3] = 1;
                //TAG PRAZO 
                $tag_contador['prazo_pagamento'][1]         = 1;
                $tag_contador['prazo_pagamento_extenso'][1] = 1;
                $tag_contador['prazo_pagamento'][3]         = 1;
                $tag_contador['prazo_pagamento_extenso'][3] = 1;
                break;
            case 'CRY0003':
                unset($tag_contador['cnpj'][1]);
                unset($tag_contador['cliente'][1]);
                unset($tag_contador['endereco'][1]);
                unset($tag_contador['bairro'][1]);
                unset($tag_contador['cep'][1]);
                unset($tag_contador['cidade'][1]);
                unset($tag_contador['uf'][1]);
                unset($tag_contador['representante_legal'][1]);
                unset($tag_contador['REPRESENTANTE_2']);
                unset($tag_contador['representante_legal_cargo'][1]);
                unset($tag_contador['representante_legal_cpf'][1]);
                unset($tag_contador['representante_legal_email'][1]);
                unset($tag_contador['representante_legal_telefone'][1]);
                unset($tag_contador['contato_financeiro'][1]);
                unset($tag_contador['contato_financeiro_email'][1]);
                unset($tag_contador['contato_financeiro_telefone'][1]);
                unset($tag_contador['testemunha_cmsw'][1]);
                unset($tag_contador['testemunha_cmsw_cpf'][1]);
                unset($tag_contador['testemunha_cmsw_email'][1]);
                unset($tag_contador['testemunha'][1]);
                unset($tag_contador['testemunha_cpf'][1]);
                unset($tag_contador['testemunha_email'][1]);

                //TAG TESTEMUNHA CM SOFTWARE
                $tag_contador['testemunha_cmsw'][0]       = 1;
                $tag_contador['testemunha_cmsw_cpf'][0]   = 1;
                $tag_contador['testemunha_cmsw_email'][0] = 1;
                //TAG TESTEMUNHA CLIENTE
                $tag_contador['testemunha'][0]       = 1;
                $tag_contador['testemunha_cpf'][0]   = 1;
                $tag_contador['testemunha_email'][0] = 1;

                $tag_contador['vigencia_contrato'][0]           = 1;
                $tag_contador['vigencia_contrato_extenso'][0]   = 1;
                $tag_contador['indice_reajuste'][0]             = 1;
                $tag_contador['implantacao'][0]                 = 1;
                $tag_contador['implantacao_extenso'][0]         = 1;
                $tag_contador['transacao_executada'][1]         = 1;
                $tag_contador['transacao_executada_extenso'][1] = 1;
                $tag_contador['transacao_executada'][3]         = 1;
                $tag_contador['transacao_executada_extenso'][3] = 1;
                //TAG FATURAMENTO
                $tag_contador['corte_faturamento'][0]           = 1;
                $tag_contador['corte_faturamento_extenso'][0]   = 1;
                //TAG PRAZO 
                $tag_contador['prazo_pagamento'][0]             = 1;
                $tag_contador['prazo_pagamento_extenso'][0]     = 1;
                break;
            case 'SOE0001':
                //TAG FATURAMENTO
                $tag_contador['corte_faturamento'][1] = 1;
                $tag_contador['corte_faturamento_extenso'][1] = 1;
                //TAG PRAZO
                $tag_contador['prazo_pagamento'][1] = 1;
                $tag_contador['prazo_pagamento_extenso'][1] = 1;
                //TAG FATURAMENTO
                // $tag_contador['primeiro_faturamento'][1] = 1;
                // $tag_contador['primeiro_faturamento_extenso'][1] = 1;
                //PERCENTUAL
                $tag_contador['percentual_multa'][3] = 1;
                $tag_contador['percentual_multa_extenso'][3] = 1;
                $tag_contador['percentual_juros'][3] = 1;
                $tag_contador['percentual_juros_extenso'][3] = 1;
                //TAG IMPLANTACAO
                $tag_contador['implantacao'][12] = 1;
                $tag_contador['implantacao_extenso'][12] = 1;
                $tag_contador['implantacao'][14] = 1;
                $tag_contador['implantacao_extenso'][14] = 1;
                //LP
                $tag_contador['credito_cliente'][15] = 1;
                $tag_contador['debito_cliente'][15] = 1;
                $tag_contador['baixa_compe'][12] = 1;
                $tag_contador['webservice'][12] = 1;
                $tag_contador['lote_arquivo'][12] = 1;
                $tag_contador['tratamento_inconsistencia'][13] = 1;
                $tag_contador['hora_homem'][12] = 1;
                //INDICE REAJUSTE
                $tag_contador['indice_reajuste'][1] = 2;
                //VIGENCIA CONTRATO
                $tag_contador['vigencia_contrato'][1] = 1;
                $tag_contador['vigencia_contrato_extenso'][1] = 1;
                //TABLE
                $tag_contador['table'][13] = 1;
                //PACOTE
                $tag_contador['valor_pacote'][12] = 1;
                $tag_contador['valor_pacote_extenso'][12] = 1;
                $tag_contador['transacao_pacote'][12] = 1;
                $tag_contador['transacao_pacote_extenso'][12] = 1;
                break;
            case 'ATF0001':
                //INDICE REAJUSTE
                $tag_contador['indice_reajuste'][1] = 1;
                $tag_contador['indice_reajuste'][4] = 1;
                //VIGENCIA CONTRATO
                $tag_contador['vigencia_contrato'][1] = 1;
                $tag_contador['vigencia_contrato_extenso'][1] = 1;
                $tag_contador['vigencia_contrato'][3] = 1;
                $tag_contador['vigencia_contrato_extenso'][3] = 1;
                //IMPLANTAÇÃO
                $tag_contador['implantacao'][1] = 1;
                $tag_contador['implantacao_extenso'][1] = 1;
                // $tag_contador['implantacao_texto'][1] = 1;
                $tag_contador['implantacao'][3] = 1;
                $tag_contador['implantacao_extenso'][3] = 1;
                // $tag_contador['implantacao_texto'][3] = 1;
                //PACOTE
                $tag_contador['pacote'][1] = 1;
                $tag_contador['pacote_extenso'][1] = 1;
                $tag_contador['pacote'][3] = 1;
                $tag_contador['pacote_extenso'][3] = 1;
                //LP
                $tag_contador['valor_aprovado'][1] = 1;
                $tag_contador['valor_aprovado_extenso'][1] = 1;
                $tag_contador['valor_aprovado'][3] = 1;
                $tag_contador['valor_aprovado_extenso'][3] = 1;
                $tag_contador['transacao_aprovado'][1] = 1;
                $tag_contador['transacao_aprovado'][3] = 1;
                $tag_contador['valor_reprovado'][1] = 1;
                $tag_contador['valor_reprovado_extenso'][1] = 1;
                $tag_contador['valor_reprovado'][3] = 1;
                $tag_contador['valor_reprovado_extenso'][3] = 1;
                $tag_contador['valor_detalhado'][1] = 1;
                $tag_contador['valor_detalhado_extenso'][1] = 1;
                $tag_contador['valor_detalhado'][3] = 1;
                $tag_contador['valor_detalhado_extenso'][3] = 1;
                //TAG FATURAMENTO
                $tag_contador['corte_faturamento'][1] = 1;
                $tag_contador['corte_faturamento_extenso'][1] = 1;
                $tag_contador['corte_faturamento'][3] = 1;
                $tag_contador['corte_faturamento_extenso'][3] = 1;
                //TAG PRAZO
                $tag_contador['prazo_pagamento'][1] = 1;
                $tag_contador['prazo_pagamento_extenso'][1] = 1;
                $tag_contador['prazo_pagamento'][3] = 1;
                $tag_contador['prazo_pagamento_extenso'][3] = 1;
                //TAG FATURAMENTO
                // $tag_contador['primeiro_faturamento'][1] = 1;
                // $tag_contador['primeiro_faturamento_extenso'][1] = 1;
                // $tag_contador['primeiro_faturamento'][3] = 1;
                // $tag_contador['primeiro_faturamento_extenso'][3] = 1;                           
                //PERCENTUAL
                $tag_contador['percentual_multa'][4] = 1;
                $tag_contador['percentual_multa_extenso'][4] = 1;
                $tag_contador['percentual_juros'][4] = 1;
                $tag_contador['percentual_juros_extenso'][4] = 1;
                break;
            case 'TPX0001':
                //INDICE REAJUSTE
                $tag_contador['indice_reajuste'][1] = 1;
                //VIGENCIA CONTRATO
                $tag_contador['vigencia_contrato'][1] = 1;
                $tag_contador['vigencia_contrato_extenso'][1] = 1;
                //IMPLANTAÇÃO
                $tag_contador['implantacao'][1]         = 1;
                $tag_contador['implantacao_extenso'][1] = 1;
                // $tag_contador['implantacao_texto'][1]   = 1;          
                //LP
                $tag_contador['triplo_pix'][1] = 1;
                $tag_contador['triplo_pix_extenso'][1] = 1;
                //TAG FATURAMENTO
                $tag_contador['corte_faturamento'][1] = 1;
                $tag_contador['corte_faturamento_extenso'][1] = 1;
                //TAG PRAZO
                $tag_contador['prazo_pagamento'][1] = 1;
                $tag_contador['prazo_pagamento_extenso'][1] = 1;
                //TAG FATURAMENTO
                // $tag_contador['primeiro_faturamento'][1] = 1;
                // $tag_contador['primeiro_faturamento_extenso'][1] = 1;                
                //PERCENTUAL
                $tag_contador['percentual_multa'][3] = 1;
                $tag_contador['percentual_multa_extenso'][3] = 1;
                $tag_contador['percentual_juros'][3] = 1;
                $tag_contador['percentual_juros_extenso'][3] = 1;
                break;
            case 'ECS0001':
                //PERCENTUAL
                $tag_contador['percentual_multa'][4]           = 1;
                $tag_contador['percentual_multa_extenso'][4]   = 1;
                $tag_contador['percentual_juros'][4]           = 1;
                $tag_contador['percentual_juros_extenso'][4]   = 1;
                //INDICE REAJUSTE
                $tag_contador['indice_reajuste'][4]            = 1;
                $tag_contador['indice_reajuste'][4]            = 1;
                //IMPLANTAÇÃO
                $tag_contador['implantacao'][8]               = 1;
                $tag_contador['implantacao_extenso'][8]       = 1;
                // $tag_contador['implantacao_texto'][8]         = 1;
                //PACOTE
                $tag_contador['pacote'][8]                    = 1;
                $tag_contador['pacote_extenso'][8]            = 1;
                //TAG FATURAMENTO
                $tag_contador['corte_faturamento'][8]         = 1;
                $tag_contador['corte_faturamento_extenso'][8] = 1;
                //TAG PRAZO
                $tag_contador['prazo_pagamento'][8]           = 1;
                $tag_contador['prazo_pagamento_extenso'][8]   = 1;
                //TAG FATURAMENTO
                // $tag_contador['primeiro_faturamento'][8]      = 1;
                // $tag_contador['primeiro_faturamento_extenso'][8] = 1; 
                //VIGENCIA CONTRATO
                $tag_contador['vigencia_contrato'][8]         = 1;
                $tag_contador['vigencia_contrato_extenso'][8] = 1;
                break;
            case 'ADM0001':
                //PERCENTUAL
                $tag_contador['hora_homem'][1]           = 1;
                $tag_contador['hora_homem_extenso'][1]   = 1;
                $tag_contador['percentual_multa'][2]           = 1;
                $tag_contador['percentual_multa_extenso'][2]   = 1;
                $tag_contador['percentual_juros'][2]           = 1;
                $tag_contador['percentual_juros_extenso'][2]   = 1;
                //INDICE REAJUSTE
                $tag_contador['indice_reajuste'][1] = 1;

                unset($tag_contador['testemunha'][1]);
                unset($tag_contador['testemunha_cpf'][1]);
                unset($tag_contador['testemunha_email'][1]);
                //TAG TESTEMUNHA CM SOFTWARE
                unset($tag_contador['testemunha_cmsw'][1]);
                unset($tag_contador['testemunha_cmsw_cpf'][1]);
                unset($tag_contador['testemunha_cmsw_email'][1]);
                //VIGENCIA CONTRATO
                // $tag_contador['vigencia_contrato'][1] = 1;
                // $tag_contador['vigencia_contrato_extenso'][1] = 1;
                //TAG FATURAMENTO
                // $tag_contador['corte_faturamento'][1] = 1;
                // $tag_contador['corte_faturamento_extenso'][1] = 1;               
                //TAG PRAZO
                // $tag_contador['prazo_pagamento'][1] = 1;
                // $tag_contador['prazo_pagamento_extenso'][1] = 1;               
                //TAG FATURAMENTO
                // $tag_contador['primeiro_faturamento'][1] = 1;
                // $tag_contador['primeiro_faturamento_extenso'][1] = 1; 
                break;
            default:
                return false;
                break;
        }
        return $tag_contador;
    }

    function verificaTag($cod_produto, $texto_modelo, $contador_tag)
    {
        try {
            // if( isset( $texto_modelo ) && !empty( $texto_modelo ) ){
            //     $contador = 1;
            //     foreach ( $texto_modelo as $key => $value ) {
            //         if(isset($contador_tag['cm_software'][$key])){                                                                                  
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["C&M"]["CM_SOFTWARE"]);      
            //             if($cont_tag < $contador_tag['cm_software'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--CM_SOFTWARE--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG C&M SOFTWARE CNPJ
            //         if(isset($contador_tag['cm_software_cnpj'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["C&M"]["CM_SOFTWARE_CNPJ"]);                                              							
            //             if($cont_tag < $contador_tag['cm_software_cnpj'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--CM_SOFTWARE_CNPJ--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG CLIENTE
            //         if( isset( $contador_tag['cliente'][$key] ) ){
            //             $cont_tag = substr_count( $value, $this->dicionario["DICIONARIO_TAG"]["CLIENTE"]["CLIENTE"] );
            //             if( $cont_tag < $contador_tag['cliente'][$key] ){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--CLIENTE--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG CNPJ
            //         if(isset($contador_tag['cnpj'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["CLIENTE"]["CNPJ"]);
            //             if($cont_tag < $contador_tag['cnpj'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--CNPJ--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG ENDEREÇO
            //         if( isset( $contador_tag['endereco'][$key] ) ){
            //             $cont_tag = substr_count( $value, $this->dicionario["DICIONARIO_TAG"]["ENDERECO"]["ENDERECO"] );
            //             if( $cont_tag < $contador_tag['endereco'][$key] ){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--ENDERECO--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG BAIRRO
            //         if(isset($contador_tag['bairro'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["ENDERECO"]["BAIRRO"]);
            //             if($cont_tag < $contador_tag['bairro'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--BAIRRO--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG CEP
            //         if(isset($contador_tag['cep'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["ENDERECO"]["CEP"]);
            //             if($cont_tag < $contador_tag['cep'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--CEP--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG CIDADE
            //         if(isset($contador_tag['cidade'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["ENDERECO"]["CIDADE"]);
            //             if($cont_tag < $contador_tag['cidade'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--CIDADE--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG UF
            //         if(isset($contador_tag['uf'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["ENDERECO"]["UF"]);
            //             if($cont_tag < $contador_tag['uf'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--UF--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG REPRESENTANTE LEGAL
            //         if(isset($contador_tag['representante_legal'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["REPRESENTANTE"]["REPRESENTANTE_LEGAL"]);
            //             if($cont_tag < $contador_tag['representante_legal'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--REPRESENTANTE_LEGAL--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG REPRESENTANTE LEGAL 2
            //         if( isset( $contador_tag['representante_legal_2'][$key] ) ){
            //             switch ( $cod_produto ) {
            //                 case 'CRY0003':
            //                 break;
            //                 default:
            //                     $cont_tag = substr_count( $value, $this->dicionario["DICIONARIO_TAG"]["REPRESENTANTE"]["REPRESENTANTE_2"] );
            //                     if($cont_tag < $contador_tag['representante_legal_2'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--REPRESENTANTE_2--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 break;
            //             }
            //         }

            //         //TAG REPRESENTANTE LEGAL CARGO
            //         if(isset($contador_tag['representante_legal_cargo'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["REPRESENTANTE"]["REPRESENTANTE_LEGAL/CARGO"]);									
            //             if($cont_tag < $contador_tag['representante_legal_cargo'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--REPRESENTANTE_LEGAL/CARGO--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG REPRESENTANTE LEGAL CPF
            //         if(isset($contador_tag['representante_legal_cpf'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["REPRESENTANTE"]["REPRESENTANTE_LEGAL/CPF"]);									
            //             if($cont_tag < $contador_tag['representante_legal_cpf'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--REPRESENTANTE_LEGAL/CPF--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG REPRESENTANTE LEGAL TELEFONE
            //         if(isset($contador_tag['representante_legal_telefone'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["REPRESENTANTE"]["REPRESENTANTE_LEGAL/TELEFONE"]);									
            //             if($cont_tag < $contador_tag['representante_legal_telefone'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--REPRESENTANTE_LEGAL/TELEFONE--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG REPRESENTANTE LEGAL EMAIL
            //         if(isset($contador_tag['representante_legal_email'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["REPRESENTANTE"]["REPRESENTANTE_LEGAL/EMAIL"]);									
            //             if($cont_tag < $contador_tag['representante_legal_email'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--REPRESENTANTE_LEGAL/EMAIL--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG CONTATO FINANCEIRO
            //         if( isset( $contador_tag['contato_financeiro'][$key] ) ){
            //             $cont_tag = substr_count( $value, $this->dicionario["DICIONARIO_TAG"]["CONTATO"]["CONTATO_FINANCEIRO"] );									
            //             if($cont_tag < $contador_tag['contato_financeiro'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--CONTATO_FINANCEIRO--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG CONTATO FINANCEIRO EMAIL
            //         if(isset($contador_tag['contato_financeiro_email'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["CONTATO"]["CONTATO_FINANCEIRO/EMAIL"]);									
            //             if($cont_tag < $contador_tag['contato_financeiro_email'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--CONTATO_FINANCEIRO/EMAIL--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG CONTATO FINANCEIRO TELEFONE
            //         if(isset($contador_tag['contato_financeiro_telefone'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["CONTATO"]["CONTATO_FINANCEIRO/TELEFONE"]);									
            //             if($cont_tag < $contador_tag['contato_financeiro_telefone'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--CONTATO_FINANCEIRO/TELEFONE--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG FINANCEIRO 2
            //         if(isset($contador_tag['contato_financeiro_2'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["CONTATO"]["CONTATO_FINANCEIRO_2"]);                        								
            //             if($cont_tag < $contador_tag['contato_financeiro_2'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--CONTATO_FINANCEIRO_2--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG IMPLANTAÇÃO 
            //         if( isset( $contador_tag['implantacao'][$key] ) ){
            //             $cont_tag = substr_count( $value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["IMPLANTACAO"] );
            //             if( $cont_tag < $contador_tag['implantacao'][$key] ){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--IMPLANTACAO--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG IMPLANTAÇÃO EXTENSO
            //         if(isset($contador_tag['implantacao_extenso'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["IMPLANTACAO_EXTENSO"]);									
            //             if($cont_tag < $contador_tag['implantacao_extenso'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--IMPLANTACAO/EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG IMPLANTAÇÃO TEXTO
            //         if(isset($contador_tag['implantacao_texto'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["IMPLANTACAO_TEXTO"]);                                               								
            //             if($cont_tag < $contador_tag['implantacao_texto'][$key]){                          
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--IMPLANTACAO_TEXTO--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }                   

            //         //TAG CORTE FATURAMENTO
            //         if(isset($contador_tag['corte_faturamento'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["CORTE_FATURAMENTO"]);
            //             if($cont_tag < $contador_tag['corte_faturamento'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--CORTE_FATURAMENTO--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG CORTE FATURAMENTO EXTENSO
            //         if(isset($contador_tag['corte_faturamento_extenso'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["CORTE_FATURAMENTO_EXTENSO"]);									
            //             if($cont_tag < $contador_tag['corte_faturamento_extenso'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--CORTE_FATURAMENTO/EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG PRAZO PAGAMENTO
            //         if(isset($contador_tag['prazo_pagamento'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PRAZO_PAGAMENTO"]);                        								
            //             if($cont_tag < $contador_tag['prazo_pagamento'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--PRAZO_PAGAMENTO--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG PRAZO PAGAMENTO EXTENSO
            //         if(isset($contador_tag['prazo_pagamento_extenso'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PRAZO_PAGAMENTO_EXTENSO"]);
            //             if($cont_tag < $contador_tag['prazo_pagamento_extenso'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--PRAZO_PAGAMENTO/EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }  

            //         //TAG TESTEMUNHA
            //         if( isset( $contador_tag['testemunha'][$key] ) ){
            //             $cont_tag = substr_count( $value, $this->dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]["TESTEMUNHA"] );									
            //             if($cont_tag < $contador_tag['testemunha'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--TESTEMUNHA--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG TESTEMUNHA CPF
            //         if(isset($contador_tag['testemunha_cpf'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]["TESTEMUNHA_CPF"]);									
            //             if($cont_tag < $contador_tag['testemunha_cpf'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--TESTEMUNHA_CPF--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG TESTEMUNHA EMAIL
            //         if(isset($contador_tag['testemunha_email'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]["TESTEMUNHA_EMAIL"]);									
            //             if($cont_tag < $contador_tag['testemunha_email'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--TESTEMUNHA_EMAIL--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG TESTEMUNHA CMSW
            //         if(isset($contador_tag['testemunha_cmsw'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]["TESTEMUNHA_CMSW"]);									
            //             if($cont_tag < $contador_tag['testemunha_cmsw'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--TESTEMUNHA_CMSW--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG TESTEMUNHA 2 CPF
            //         if(isset($contador_tag['testemunha_cmsw_cpf'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]["TESTEMUNHA_CMSW/CPF"]);									
            //             if($cont_tag < $contador_tag['testemunha_cmsw_cpf'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--TESTEMUNHA_CMSW/CPF--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG TESTEMUNHA 2 EMAIL
            //         if(isset($contador_tag['testemunha_cmsw_email'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]["TESTEMUNHA_CMSW/EMAIL"]);									
            //             if($cont_tag < $contador_tag['testemunha_cmsw_email'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--TESTEMUNHA_CMSW/EMAIL--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //VIGENCIA CONTRATO
            //         if(isset($contador_tag['vigencia_contrato'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["VIGENCIA_CONTRATO"]);                               						
            //             if($cont_tag < $contador_tag['vigencia_contrato'][$key]){                                   
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--VIGENCIA_CONTRATO--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //VIGENCIA CONTRATO EXTENSO
            //         if(isset($contador_tag['vigencia_contrato_extenso'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["VIGENCIA_CONTRATO_EXTENSO"]);									
            //             if($cont_tag < $contador_tag['vigencia_contrato_extenso'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--VIGENCIA_CONTRATO/EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         //TAG INDICE AJUSTE
            //         if(isset($contador_tag['indice_reajuste'][$key])){
            //             $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["INDICE_REAJUSTE"]);                                                                          						
            //             if($cont_tag < $contador_tag['indice_reajuste'][$key]){
            //                 $retorno['codigo']   = 1;
            //                 $retorno['input']    = $texto;
            //                 $retorno['output']   = null;
            //                 $retorno['mensagem'] = "Tag **--INDICE_REAJUSTE--** da página ".$contador." foi apagado ou alterado";
            //                 throw new Exception (json_encode($retorno), 1);
            //             }
            //         }

            //         switch ($cod_produto) {
            //             case 'RCK0001':
            //                 //TAG PACOTE
            //                 if(isset($contador_tag['pacote'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PACOTE"]);									
            //                     if($cont_tag < $contador_tag['pacote'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PACOTE--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }
            //                 //TAG PACOTE EXTENSO
            //                 if(isset($contador_tag['pacote_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PACOTE_EXTENSO"]);									
            //                     if($cont_tag < $contador_tag['pacote_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PACOTE/EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }    
            //                 //TAG TRANSACOES ENGINE
            //                 if(isset($contador_tag['transacoes_engine'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["TRANSACOES_ENGINE"]);									
            //                     if($cont_tag < $contador_tag['transacoes_engine'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--TRANSACOES_ENGINE--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }
            //                 //TAG TRANSACOES ENGINE EXTENSO
            //                 if(isset($contador_tag['transacoes_engine_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["TRANSACOES_ENGINE_EXTENSO"]);									
            //                     if($cont_tag < $contador_tag['transacoes_engine_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--TRANSACOES_ENGINE/EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }    
            //             break;
            //             case 'FSP0001':
            //                 //TAG ASSESSORIA BACEN - DESCONTINUADO - 11/11/2022
            //                 if(isset($contador_tag['assessoria_bacen'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["ASSESSORIA_BACEN"]);                               						
            //                     if($cont_tag < $contador_tag['assessoria_bacen'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--ASSESSORIA_BACEN--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }  
            //                 //TAG HORA HOMEM
            //                 if(isset($contador_tag['hora_homem'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["HORA_HOMEM"]);                               						
            //                     if($cont_tag < $contador_tag['hora_homem'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--HORA_HOMEM--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['pacote_full_str'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["FULL"]["PACOTE_FULL_STR"]);                               						
            //                     if($cont_tag < $contador_tag['pacote_full_str'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PACOTE_FULL_STR--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['valores_base'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["FULL"]["VALORES_BASE_TARIFACAO"]);                               						
            //                     if($cont_tag < $contador_tag['valores_base'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--VALORES_BASE_TARIFACAO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //             break;
            //             case 'SPI0001':
            //                 if(isset($contador_tag['percentual_multa'][$key])){                               
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_MULTA"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_multa'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_MULTA--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }
            //                 if(isset($contador_tag['percentual_multa_extenso'][$key])){                                
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"]);                                                        						
            //                     if($cont_tag < $contador_tag['percentual_multa_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_MULTA_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }
            //                 if(isset($contador_tag['percentual_juros'][$key])){ 
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_JUROS"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_juros'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_JUROS--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }
            //                 if(isset($contador_tag['percentual_juros_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_juros_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_JUROS_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }                            
            //                 if(isset($contador_tag['valores_base'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["FULL"]["VALORES_BASE_TARIFACAO"]);                               						
            //                     if($cont_tag < $contador_tag['valores_base'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--VALORES_BASE_TARIFACAO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }                          
            //             break;
            //             case 'YLW0001':
            //                 if(isset($contador_tag['ativacao'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]["ATIVACAO"]);                               						
            //                     if($cont_tag < $contador_tag['ativacao'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--ATIVACAO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }
            //                 if(isset($contador_tag['ativacao_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]["ATIVACAO_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['ativacao_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--ATIVACAO_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }                       
            //                 if(isset($contador_tag['manutencao_conta'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]["MANUTENCAO_CONTA"]);                               						
            //                     if($cont_tag < $contador_tag['manutencao_conta'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--MANUTENCAO_CONTA--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }
            //                 if(isset($contador_tag['manutencao_conta_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]["MANUTENCAO_CONTA_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['manutencao_conta_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--MANUTENCAO_CONTA_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }  
            //                 if(isset($contador_tag['transacao_silver'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]["TRANSACAO_SILVER"]);                               						
            //                     if($cont_tag < $contador_tag['transacao_silver'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--TRANSACAO_SILVER--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }
            //                 if(isset($contador_tag['porcentagem_silver'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]["PORCENTAGEM_SILVER"]);                               						
            //                     if($cont_tag < $contador_tag['porcentagem_silver'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PORCENTAGEM_SILVER--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }               
            //                 if(isset($contador_tag['baixa_pagamento'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]["BAIXA_PAGAMENTO"]);                               						
            //                     if($cont_tag < $contador_tag['baixa_pagamento'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--BAIXA_PAGAMENTO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }  
            //                 if(isset($contador_tag['baixa_pagamento_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]["BAIXA_PAGAMENTO_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['baixa_pagamento_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--BAIXA_PAGAMENTO_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }  
            //                 if(isset($contador_tag['corner_pix'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]["CORNER_PIX"]);                               						
            //                     if($cont_tag < $contador_tag['corner_pix'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--CORNER_PIX--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['corner_pix_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]["CORNER_PIX_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['corner_pix_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--CORNER_PIX_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['portal_emissor'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]["PORTAL_EMISSOR"]);                               						
            //                     if($cont_tag < $contador_tag['portal_emissor'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PORTAL_EMISSOR--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['portal_emissor_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]["PORTAL_EMISSOR_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['portal_emissor_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PORTAL_EMISSOR_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['api_yellow'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]["API_YELLOW"]);                               						
            //                     if($cont_tag < $contador_tag['api_yellow'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--API_YELLOW--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['api_yellow_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]["API_YELLOW_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['api_yellow_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--API_YELLOW_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['marketing_cooperado'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]["MARKETING_COOPERADO"]);                               						
            //                     if($cont_tag < $contador_tag['marketing_cooperado'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--MARKETING_COOPERADO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['marketing_cooperado_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["YELLOW"]["MARKETING_COOPERADO_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['marketing_cooperado_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--MARKETING_COOPERADO_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }                               
            //             break;
            //             case 'CRY0001':
            //                 if(isset($contador_tag['transacao_executada'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["CRYSTAL"]["TRANSACAO_EXECUTADA"]);   

            //                     if($cont_tag < $contador_tag['transacao_executada'][$key]){                                    
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--TRANSACAO_EXECUTADA--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }
            //                 if(isset($contador_tag['transacao_executada_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["CRYSTAL"]["TRANSACAO_EXECUTADA_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['transacao_executada_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--TRANSACAO_EXECUTADA_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }                       
            //                 if(isset($contador_tag['open_banking'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["CRYSTAL"]["OPEN_BANKING"]);                                                        						
            //                     if($cont_tag < $contador_tag['open_banking'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--TRANSACAO_OPEN_BANKING--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }
            //                 if(isset($contador_tag['open_banking_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["CRYSTAL"]["OPEN_BANKING_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['open_banking_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--TRANSACAO_OPEN_BANKING_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }  
            //             break;
            //             case 'CRY0003':
            //                 // verificar checktag e replace tag
            //             break;
            //             case 'SOE0001':
            //                 if(isset($contador_tag['baixa_compe'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]["BAIXA_COMPE"]);                               						
            //                     if($cont_tag < $contador_tag['baixa_compe'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--BAIXA_COMPE--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['webservice'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]["WEBSERVICE"]);                               						
            //                     if($cont_tag < $contador_tag['webservice'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--WEBSERVICE--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['lote_arquivo'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]["LOTE_ARQUIVO"]);                               						
            //                     if($cont_tag < $contador_tag['lote_arquivo'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--LOTE_ARQUIVO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['tratamento_inconsistencia'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]["TRATAMENTO_INCONSISTENCIA"]);                               						
            //                     if($cont_tag < $contador_tag['tratamento_inconsistencia'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--TRATAMENTO_INCONSISTENCIA--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['credito_cliente'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]["CREDITO_CLIENTE"]);                               						
            //                     if($cont_tag < $contador_tag['credito_cliente'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--CREDITO_CLIENTE--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }
            //                 if(isset($contador_tag['debito_cliente'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]["DEBITO_CLIENTE"]);                               						
            //                     if($cont_tag < $contador_tag['debito_cliente'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--DEBITO_CLIENTE--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }  
            //                 if(isset($contador_tag['hora_homem'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]["HORA_HOMEM"]);                               						
            //                     if($cont_tag < $contador_tag['hora_homem'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--HORA_HOMEM--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }   
            //                 if(isset($contador_tag['percentual_multa'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_MULTA"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_multa'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_MULTA--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['percentual_multa_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_multa_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_MULTA/EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['percentual_juros'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_JUROS"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_juros'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_JUROS--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['percentual_juros_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_juros_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_JUROS/EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }  
            //                 if(isset($contador_tag['table'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]["TABLE"]);                               						
            //                     if($cont_tag < $contador_tag['table'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--TABLE--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['valor_pacote'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]["VALOR_PACOTE_SPB"]);                               						
            //                     if($cont_tag < $contador_tag['valor_pacote'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--VALOR_PACOTE_SPB--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['valor_pacote_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]["VALOR_PACOTE_SPB_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['valor_pacote_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--VALOR_PACOTE_SPB_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['transacao_pacote'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]["TRANSACOES_PACOTE_SPB"]);                               						
            //                     if($cont_tag < $contador_tag['transacao_pacote'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--TRANSACOES_PACOTE_SPB--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }  
            //                 if(isset($contador_tag['transacao_pacote_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["SPB/X OBE"]["TRANSACOES_PACOTE_SPB_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['transacao_pacote_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--TRANSACOES_PACOTE_SPB_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }                                                
            //             break;
            //             case 'ATF0001':
            //                 if(isset($contador_tag['pacote'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]["PACOTE"]);                                                          						
            //                     if($cont_tag < $contador_tag['pacote'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PACOTE--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }
            //                 if(isset($contador_tag['pacote_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]["PACOTE_EXTENSO"]);                                                       						
            //                     if($cont_tag < $contador_tag['pacote_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PACOTE_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['valor_aprovado'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]["VALOR_APROVADO"]);                               						
            //                     if($cont_tag < $contador_tag['valor_aprovado'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--VALOR_APROVADO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['valor_aprovado_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]["VALOR_APROVADO_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['valor_aprovado_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--VALOR_APROVADO_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }  
            //                 if(isset($contador_tag['transacao_aprovado'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]["TRANSACAO_APROVADO"]);                                                           						
            //                     if($cont_tag < $contador_tag['transacao_aprovado'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--TRANSACAO_APROVADO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }  
            //                 if(isset($contador_tag['valor_reprovado'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]["VALOR_REPROVADO"]);                               						
            //                     if($cont_tag < $contador_tag['valor_reprovado'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--VALOR_REPROVADO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }
            //                 if(isset($contador_tag['valor_reprovado_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]["VALOR_REPROVADO_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['valor_reprovado_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--VALOR_REPROVADO_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }
            //                 if(isset($contador_tag['valor_detalhado'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]["VALOR_DETALHADO"]);                               						
            //                     if($cont_tag < $contador_tag['valor_detalhado'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--VALOR_DETALHADO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }
            //                 if(isset($contador_tag['valor_detalhado_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["CORNER_PIX"]["VALOR_DETALHADO_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['valor_detalhado_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--VALOR_DETALHADO_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }
            //                 if(isset($contador_tag['percentual_multa'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_MULTA"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_multa'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_MULTA--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['percentual_multa_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_multa_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_MULTA/EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['percentual_juros'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_JUROS"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_juros'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_JUROS--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['percentual_juros_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_juros_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_JUROS/EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }                            
            //             break;
            //             case 'TPX0001':
            //                 if(isset($contador_tag['percentual_multa'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_MULTA"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_multa'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_MULTA--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['percentual_multa_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_multa_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_MULTA/EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['percentual_juros'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_JUROS"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_juros'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_JUROS--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['percentual_juros_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_juros_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_JUROS/EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }  
            //                 if(isset($contador_tag['triplo_pix'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]['TRIPLO_PIX']["TRIPLO_PIX"]);                               						
            //                     if($cont_tag < $contador_tag['triplo_pix'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--TRIPLO_PIX--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['triplo_pix_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]['TRIPLO_PIX']["TRIPLO_PIX_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['triplo_pix_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--TRIPLO_PIX_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }   
            //             break;
            //             case 'ECS0001':
            //                 if(isset($contador_tag['percentual_multa'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_MULTA"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_multa'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_MULTA--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['percentual_multa_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_multa_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_MULTA/EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['percentual_juros'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_JUROS"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_juros'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_JUROS--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['percentual_juros_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_juros_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_JUROS/EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 }  
            //                 if(isset($contador_tag['pacote'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["ECS"]["PACOTE"]);                               						
            //                     if($cont_tag < $contador_tag['pacote'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PACOTE_ECS--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['pacote_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["VALORES"]["ECS"]["PACOTE_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['pacote_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PACOTE_EXTENSO/ECS--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //             break;
            //             case 'ADM0001':
            //                 if(isset($contador_tag['percentual_multa'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_MULTA"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_multa'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_MULTA--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['percentual_multa_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_multa_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_MULTA/EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['percentual_juros'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_JUROS"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_juros'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_JUROS--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['percentual_juros_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['percentual_juros_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--PERCENTUAL_JUROS/EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['hora_homem'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["HORA_HOMEM"]);                               						
            //                     if($cont_tag < $contador_tag['hora_homem'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--HORA_HOMEM--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //                 if(isset($contador_tag['hora_homem_extenso'][$key])){
            //                     $cont_tag = substr_count($value, $this->dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["HORA_HOMEM_EXTENSO"]);                               						
            //                     if($cont_tag < $contador_tag['hora_homem_extenso'][$key]){
            //                         $retorno['codigo']   = 1;
            //                         $retorno['input']    = $texto;
            //                         $retorno['output']   = null;
            //                         $retorno['mensagem'] = "Tag **--HORA_HOMEM_EXTENSO--** da página ".$contador." foi apagado ou alterado";
            //                         throw new Exception (json_encode($retorno), 1);
            //                     }
            //                 } 
            //             break;
            //             default:
            //                 // $retorno['codigo']   = 1;
            //                 // $retorno['input']    = $_POST;
            //                 // $retorno['output']   = null;
            //                 // $retorno['mensagem'] = "Erro verifica tag código produto";
            //                 // throw new Exception (json_encode($retorno), 1);	
            //             break;
            //         }
            //         $contador++;                  
            //     }                                                     
            // }else{
            //     $retorno['codigo']   = 1;
            //     $retorno['input']    = $_POST;
            //     $retorno['output']   = null;
            //     $retorno['mensagem'] = "Erro texto modelo";
            //     throw new Exception (json_encode($retorno), 1);	
            // }           				
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }
}
