<?php

/**
 * Luciano Damasceno
 * 21/10/2025
 * Classe para gerar texto de minuta de contrato
 */
class MinutaV2
{
    private
        $controller,
        $data_extenso,
        $model_modelo,
        $propostas_model,
        $dicionario,
        $dados_minuta,
        $modulos_traducao,
        $modulos_adm,
        $model_produto;
    function __construct($controller)
    {
        $meses = [
            "01" => "Janeiro",
            "02" => "Fevereiro",
            "03" => "Março",
            "04" => "Abril",
            "05" => "Maio",
            "06" => "Junho",
            "07" => "Julho",
            "08" => "Agosto",
            "09" => "Setembro",
            "10" => "Outubro",
            "11" => "Novembro",
            "12" => "Dezembro",
        ];

        $this->controller = $controller;
        $this->model_modelo = $this->controller->load_model('modelo/modelo', true);
        $this->propostas_model = $this->controller->load_model('propostas/propostas', true);
        $this->model_produto = $this->controller->load_model('produtos/produtos', true);
        require ABSPATH . "/config_extras.php";
        $this->dicionario = $VAR_SYSTEM;
        setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
        $day = date("d");
        $month = $meses[date("m")];
        $year = date("Y");
        $this->data_extenso = "$day de $month de $year";

        $this->modulos_adm = [
            'ADM0010' => 'REAJUSTE_NUMERICO',
            'ADM0011' => 'MULTA_NUMERICO',
            'ADM0012' => 'JUROS_NUMERICO',
            'ADM0013' => 'INATIVIDADE_NUMERICO',
            'ADM0014' => 'MENSALIDADE_NUMERICO',
            'ADM0015' => 'IMPLANTACAO_VALOR_NUMERICO',
            'ADM0016' => 'CUSTOMIZACAO_SOFTWARE_NUMERICO',
            'ADM0017' => 'VALOR_OUTROS_LANCAMENTOS_NUMERICOS',
            'ADM0018' => 'CORNER_FULL_CERTIFICACAO_OPEN_FINANCE',
        ];

        $this->modulos_traducao = [
            "COR0010" => "TRANSACOES_DOMINIO_01",
            "COR0011" => "TRANSACOES_DOMINIO_02",
            "COR0012" => "SPB_02_TRATAMENTO_DE_INCONSISTENCIA",
            "COR0013" => "SPB_02_TRANSACOES_WEBSERVICE",
            "COR0014" => "SPB_02_TRANSACOES_WEBSERVICE_LOTE",
            "COR0015" => "SPB_02_REMESSA_BAIXA_CONVERSAO_BATCH_XML",
            "COR0016" => "SPB_02_REGISTRO_E_BAIXA_NOVACOB",
            "COR0017" => "PIX_TRANSACAO_A_CREDITO_06H00_11H59",
            "COR0018" => "PIX_TRANSACAO_A_CREDITO_12H00_15H30",
            "COR0019" => "PIX_TRANSACAO_A_CREDITO_15H31_22H00",
            "COR0020" => "PIX_TRANSACAO_A_CREDITO_22H01_05H59",
            "COR0021" => "PIX_TRANSACAO_A_DEBITO_06H00_11H59",
            "COR0022" => "PIX_TRANSACAO_A_DEBITO_12H00_15H30",
            "COR0023" => "PIX_TRANSACAO_A_DEBITO_15H31_22H00",
            "COR0024" => "PIX_TRANSACAO_A_DEBITO_22H01_05H59",
            "COR0025" => "PIX_AUTOMATICO_EVENTO_TRANSACAO_ACEITACAO_CONSENTIMENTO",
            "COR0026" => "PIX_AUTOMATICO_EVENTO_TRANSACAO_ACEITACAO_AGENDAMENTO",
            "COR0027" => "ANTIFRAUDE_TRANSACAO_RECUSADA_PAGAMENTO",
            "COR0028" => "ANTIFRAUDE_TRANSACAO_DETALHADA_PAGAMENTO",
            "COR0029" => "ANTIFRAUDE_TRANSACAO_APROVADA_PAGAMENTO",
            "COR0030" => "OPEN_FINANCE_RESPONSE_API_OPEN_BANKING",
            "COR0031" => "OPEN_FINANCE_REQUEST_API_OPEN_BANKING",
            "COR0032" => "BH_GERACAO_FATURA_PDF_COM_DADOS_VARIAVEIS",
            "COR0033" => "BH_GERACAO_BOLETO_PDF_COM_DADOS_VARIAVEIS",
            "COR0034" => "BH_ENVIO_DE_SMS",
            "COR0035" => "BH_ENVIO_DE_EMAIL",
            "COR0036" => "BH_BAIXA_QR_CODE",
            "COR0037" => "PIX_SINACOR",
            "COR0038" => "TRIPLE_PIX_CONSOLIDACAO",
            "COR0039" => "GERACAO_ARQUIVOS_ROC_605",
            "COR0040" => "ITP_MODE_POR_CONSULTA_DICT",
            "COR0041" => "PACOTE_COMPROMISSADO_PIX",
            "COR0042" => "ASSESSORIA_BACEN",
            "SER0001" => "SERPRO_PIX",
            "IMP0011" => "CERTIFICACAO OPEN FINANCE"
        ];
    }

    // Preview da minuta
    function gerarMinuta($produto)
    {
        try {
            //apagar
            // $pathModelosContrato = 'C:\Users\LucianoEricDamasceno\Desktop\modelos_contrato';

            // obtem doc pelo produto

            // clona doc

            // $texto = $this->gerarTexto( $produto );
            if (isset($texto) && !empty($texto)) {
                $retorno['codigo']   = 0;
                $retorno['input']    = $produto;
                $retorno['output']   =  $texto;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo']   = 1;
                $retorno['input']    = $produto;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Produto indefinido COD: 37";
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }
    function gerarPDF($ged, $contrato)
    {

        $produto = $contrato->codigo_produto;
        $api = new Api();

        try {
            if (!is_dir(PATH_MINUTA)) {
                mkdir(PATH_MINUTA);
            }

            if (!is_dir(PATH_MINUTA . $ged[0]->path_objeto)) {
                mkdir(PATH_MINUTA . $ged[0]->path_objeto);
            }

            $pathModelosContrato = UP_GED . DS . 'modelos_contrato';
            if (!is_dir($pathModelosContrato)) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $produto;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Pasta de modelos de contrato não encontrada";
                throw new Exception(json_encode($retorno), 1);
            }
            $pathProduto = $pathModelosContrato . DS . $produto;

            if (!is_dir($pathProduto)) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $produto;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Pasta do produdo em modelos de contrato não encontrada";
                throw new Exception(json_encode($retorno), 1);
            }

            $pathArquivoModelo =  $pathProduto . DS . 'modelo_contrato.docx';
            if (!file_exists($pathArquivoModelo)) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $produto;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Arquivo modelo de contrato não encontrado";
                throw new Exception(json_encode($retorno), 1);
            }

            $TemplateTempFile = sys_get_temp_dir() . DS . str_replace('pdf', 'docx', $ged[0]->nome_hash);

            if (!copy($pathArquivoModelo, $TemplateTempFile)) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $produto;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro ao copiar modelo de contrato";
                throw new Exception(json_encode($retorno), 1);
            }

            $valoresTags = $this->obtemValoresTags($contrato);
            if (!$valoresTags || empty($valoresTags)) {
                $retorno['codigo']   = 1;
                $retorno['input']    = $produto;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro ao obter valores de tags";
                throw new Exception(json_encode($retorno), 1);
            }

            // $urlApi = 'http://tarifadorphp8:81/Apiproposta/gerenatepdf';
            $urlApi = 'http://tarifa.cmsw.com:8888/Apiproposta/generatepdf';

            $post = [
                'templateTempFile' => $TemplateTempFile,
                'finalPath' => PATH_MINUTA . $ged[0]->path_objeto,
                'data' => [
                    'text' => $valoresTags['text'],
                    'tables' => $valoresTags['tabelas'],
                ]
            ];

            $paramsRequest =  [
                CURLOPT_URL => $urlApi,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Authorization: Bearer +t786x#HpgQ@Mh5f5y30j2ev648wQD5rsc7nPF1N+pg='
                ],
                CURLOPT_POSTFIELDS => json_encode($post)
            ];
            $pathFinalPDF = PATH_MINUTA . $ged[0]->path_objeto . $ged[0]->nome_hash;

            $result = json_decode($api->CurlExec(null, $paramsRequest));
            if (!$result->status && !file_exists($pathFinalPDF)) {
                $retorno['codigo']   = 1;
                $retorno['input']    = null;
                $retorno['output']   = null;
                $retorno['mensagem'] = $result->mensagem;
                throw new Exception(json_encode($retorno), 1);
            }

            $retorno['codigo']   = 1;
            $retorno['input']    = $produto;
            $retorno['output']   = null;
            $retorno['mensagem'] = json_encode($result);
            throw new Exception(json_encode($retorno), 1);
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    private function obtemValoresTags($contrato)
    {

        $limites = [
            'responsavel_legal' => 3,
            'financeiro' => 2,
            'juridico' => 1,
            'contato_responsavel' => 1,
            'tecnico' => 1,
            'testemunha' => 1,
        ];

        $id_if_contrato = $contrato->id;
        $cod_produto = $contrato->codigo_produto;
        setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
        $dados_minuta['DATA_GERACAO_DOCUMENTO'] = $this->data_extenso;
        if (isset($id_if_contrato) && !empty($id_if_contrato)) {

            $endereco = json_decode($this->controller->modelo->getIfEndereco($id_if_contrato));
            $dados_minuta["CLIENTE_NOME"]   = $contrato->razao_social;
            $dados_minuta["CLIENTE_CNPJ"]      = formatarString("cnpj", $contrato->cnpj);
            $dados_minuta["CLIENTE_ENDERECO"] = $endereco[0]->endereco . ", nº " . $endereco[0]->numero;
            $dados_minuta["CLIENTE_BAIRRO"]   = $endereco[0]->bairro;
            $dados_minuta['CLIENTE_CEP']      = formatarString("cep", $endereco[0]->cep);
            $dados_minuta["CLIENTE_CIDADE"]   = $endereco[0]->cidade;
            $dados_minuta["CLIENTE_UF"]       = $endereco[0]->estado;

            $contatos = json_decode($this->controller->modelo->getIfContato($id_if_contrato, 'minuta'));
            $contatos_organizados = [];

            if (isset($contatos) && !empty($contatos)) {
                foreach ($contatos as $key => $v) {
                    $contatos_organizados[$v->tipo_contato][] = $v;
                }

                foreach ($contatos_organizados as $k => $value) {
                    $contato_name = str_replace('contato_', '', $k);
                    $contato_name = strtoupper($k == 'responsavel_legal' ? 'representante_legal' : $contato_name);
                    if ($limites[$k] == 1) {
                        $dados_minuta[$contato_name . '_NOME'] = $value[0]->nome;
                        $dados_minuta[$contato_name . '_CARGO'] = $value[0]->cargo_setor ? $value[0]->cargo_setor :  '';
                        $dados_minuta[$contato_name . '_CPF'] = $value[0]->cpf ? formatarString("cpf", $value[0]->cpf) : '';
                        $dados_minuta[$contato_name . '_TELEFONE'] = $value[0]->telefone ? formatarString("telefone",  $value[0]->telefone) : '';
                        $dados_minuta[$contato_name . '_EMAIL'] = $value[0]->email ? $value[0]->email : '';
                    } else {
                        foreach ($value as $k2 => $v) {
                            $dados_minuta[$contato_name . '_' . ($k2 + 1) . '_NOME'] = $v->nome;
                            $dados_minuta[$contato_name . '_' . ($k2 + 1) . '_CARGO'] = $v->cargo_setor ? $v->cargo_setor :  '';
                            $dados_minuta[$contato_name . '_' . ($k2 + 1) . '_CPF'] = $v->cpf ? formatarString("cpf", $v->cpf) : '';
                            $dados_minuta[$contato_name . '_' . ($k2 + 1) . '_TELEFONE'] = $v->telefone ?  formatarString("telefone",  $v->telefone) : '';
                            $dados_minuta[$contato_name . '_' . ($k2 + 1) . '_EMAIL'] = $v->email ? $v->email : '';
                        }
                    }
                }
            }

            $limitesCM = [
                'responsavel_legal' => 1,
                'testemunha' => 2,
                'financeiro' => 2,
                'juridico' => 1,
                'contato_responsavel' => 1,
                'tecnico' => 1,
            ];
            $contato_name = '';
            $contato_cm = json_decode($this->controller->modelo->getContatoSign("sign_cm", null, null, true));
            if (isset($contato_cm) && !empty($contato_cm)) {

                foreach ($contato_cm as $key => $v) {
                    $contatos_cm_organizados[$v->tipo_contato][] = $v;
                }

                foreach ($contatos_cm_organizados as $kc => $value) {
                    $contato_name = str_replace('contato_', '', $k);
                    $contato_name = 'CM_' . strtoupper($kc == 'responsavel_legal' ? 'representante_legal' : $kc);
                    if ($limitesCM[$kc] == 1) {
                        $dados_minuta[$contato_name . '_NOME'] = $value[0]->nome;
                        $dados_minuta[$contato_name . '_CARGO'] = $value[0]->cargo_setor ? $value[0]->cargo_setor :  '';
                        $dados_minuta[$contato_name . '_CPF'] = $value[0]->cpf ? formatarString("cpf", $value[0]->cpf) : '';
                        $dados_minuta[$contato_name . '_TELEFONE'] = $value[0]->telefone ? formatarString("telefone",  $value[0]->telefone) : '';
                        $dados_minuta[$contato_name . '_EMAIL'] = $value[0]->email ? $value[0]->email : '';
                    } else {
                        foreach ($value as $k3 => $v) {
                            $dados_minuta[$contato_name . '_' . ($k3 + 1) . '_NOME'] = $v->nome;
                            $dados_minuta[$contato_name . '_' . ($k3 + 1) . '_CARGO'] = $v->cargo_setor ? $v->cargo_setor :  '';
                            $dados_minuta[$contato_name . '_' . ($k3 + 1) . '_CPF'] = $v->cpf ? formatarString("cpf", $v->cpf) : '';
                            $dados_minuta[$contato_name . '_' . ($k3 + 1) . '_TELEFONE'] = $v->telefone ?  formatarString("telefone",  $v->telefone) : '';
                            $dados_minuta[$contato_name . '_' . ($k3 + 1) . '_EMAIL'] = $v->email ? $v->email : '';
                        }
                    }
                }
            }
        }

        $faturamento = json_decode($this->controller->modelo->getInstrucaoFaturamento($id_if_contrato));
        if (isset($faturamento) && !empty($faturamento)) {
            $dados_minuta["IMPLANTACAO_VALOR_NUMERICO"]  = funcValor($faturamento[0]->implantacao,  'C', 2);
            $dados_minuta["IMPLANTACAO_VALOR_EXTENSO"]   = "( " . Extenso::converte(funcValor($faturamento[0]->implantacao, 'C', 2), true, false) . " )";

            // $mensalidade  = json_decode($this->controller->modelo->getPropostasModuloByIdProposta($contrato[0]->id_proposta, "FSP0001", "PIX0016"));
            $modulo_mensalidade = json_decode($this->propostas_model->getLpPropostasId($id_if_contrato, 'ADM0014'));
            if (!$modulo_mensalidade) {
                $modulo_mensalidade = json_decode($this->propostas_model->getLpByCodigo($cod_produto, 'ADM0014'));
                if ($modulo_mensalidade) {
                    $mensalidade =  $modulo_mensalidade[0]->valor_real;
                }
            }
            if ($modulo_mensalidade) {
                $mensalidade =  $modulo_mensalidade[0]->valor_real;
            }
            if (!$modulo_mensalidade) {
                $modulo_mensalidade = json_decode($this->propostas_model->newPacoteDefault($cod_produto, 'ADM0014'));
                if ($modulo_mensalidade) {
                    $mensalidade =  $modulo_mensalidade[0]->preco_pkt;
                }
            }

            if ($mensalidade) {
                $dados_minuta['MENSALIDADE_NUMERICO'] = funcValor($mensalidade, 'C', 2);
                $dados_minuta['MENSALIDADE_EXTENSO'] =  "( " . Extenso::converte(funcValor($mensalidade, 'C', 2), true, false) . " )";
            };


            $modulo_customizacao_software = json_decode($this->propostas_model->getLpPropostasId($id_if_contrato, 'ADM0016'));
            if (isset($modulo_customizacao_software)) {
                $dados_minuta['CUSTOMIZACAO_SOFTWARE_NUMERICO'] = $modulo_customizacao_software[0]->valor_real;
                $dados_minuta['CUSTOMIZACAO_SOFTWARE_EXTENSO'] =  "( " . Extenso::converte(funcValor($modulo_customizacao_software[0]->valor_real, 'C', 2), true, false) . " )";
            } else {
                $dados_minuta['CUSTOMIZACAO_SOFTWARE_NUMERICO'] = '';
                $dados_minuta['CUSTOMIZACAO_SOFTWARE_EXTENSO'] = '';
            }


            $dados_minuta["DATA_CORTE_NUMERICO"] = $faturamento[0]->faturamento_todo_dia;
            $dados_minuta["DATA_CORTE_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->faturamento_todo_dia, false, false) . " )";
            if ($faturamento[0]->tipo_data_faturamento == "dias_apos_faturamento" && !empty($faturamento[0]->dias_apos_faturamento)) {
                $dados_minuta["PRAZO_PAGAMENTO_NUMERICO"] = "de " . $faturamento[0]->dias_apos_faturamento;
                $dados_minuta["PRAZO_PAGAMENTO_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->dias_apos_faturamento, false, false) . " ) dias";
            } else {
                $dados_minuta["PRAZO_PAGAMENTO_NUMERICO"] = "todo dia " . $faturamento[0]->vencimento_todo_dia;
                $dados_minuta["PRAZO_PAGAMENTO_EXTENSO"] = "( " . Extenso::converte($faturamento[0]->vencimento_todo_dia, false, false) . " ) de cada mês";
            }

            if ($faturamento[0]->parcelas == "1") {
                $dados_minuta["IMPLANTACAO_TEXTO"] = "que será pago em até 10 (dez) dias após a assinatura do presente contrato";
            } else if ($faturamento[0]->parcelas == "2") {
                $parcela_implatacao =  funcValor($faturamento[0]->implantacao / 2, 'C', 2);
                $dados_minuta["IMPLANTACAO_TEXTO"] = "que serão pagos em 2 (duas) parcelas iguais e consecutivas de R$ " . $parcela_implatacao . " ( " . Extenso::converte($parcela_implatacao, true, false) . " ) sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela.";
            } else if ($faturamento[0]->parcelas == "3") {
                $parcela_implatacao =  funcValor($faturamento[0]->implantacao / 3, 'C', 2);
                $dados_minuta["IMPLANTACAO_TEXTO"] = "que serão pagos em 3 (três) parcelas iguais e consecutivas de R$ " . $parcela_implatacao . " ( " . Extenso::converte($parcela_implatacao, true, false) . " ) sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela e a terceira parcela com vencimento em 30 (trinta) dias após o vencimento da segunda parcela.";
            } else {
                $parcela_implatacao =  funcValor($faturamento[0]->implantacao / $faturamento[0]->parcelas, 'C', 2);
                $dados_minuta["IMPLANTACAO_TEXTO"] = "que serão pagos em " . $faturamento[0]->parcelas . " (" . Extenso::converte($faturamento[0]->parcelas, false, false) . ") parcelas iguais e consecutivas de R$ " . $parcela_implatacao . " ( " . Extenso::converte($parcela_implatacao, true, false) . " ) sendo a primeira parcela com vencimento até 10 (dez) dias após a assinatura do presente contrato, a segunda parcela com vencimento em 30 (trinta) dias após o vencimento da primeira parcela e a terceira parcela com vencimento em 30 (trinta) dias após o vencimento da segunda parcela.";
            }

            $dados_minuta["PRIMEIRO_FATURAMENTO"] = " 29 (vinte e nove) ";
            if (empty($faturamento[0]->duracao_contrato)) {
                $dados_minuta["VIGENCIA_CONTRATO_NUMERICO"] = "INDETERMINADO";
                $dados_minuta["VIGENCIA_CONTRATO_EXTENSO"] = "";
            } else {
                $dados_minuta["VIGENCIA_CONTRATO_NUMERICO"] = strtoupper(str_replace("meses", "", $faturamento[0]->duracao_contrato));
                $dados_minuta["VIGENCIA_CONTRATO_EXTENSO"] = "(" . Extenso::converte(str_replace("meses", "", $faturamento[0]->duracao_contrato), false, false) . ") meses";
            }

            $dados_minuta["INDICE_REAJUSTE"] = strtoupper($faturamento[0]->reajuste);
            $dados_minuta["PERCENTUAL_JUROS_NUMERICO"] = $faturamento[0]->percentual_juros . "%";
            $dados_minuta["PERCENTUAL_JUROS_EXTENSO"] = "(" . Extenso::converte($faturamento[0]->percentual_juros, false, false) . " porcento)";
            $dados_minuta["PERCENTUAL_MULTA_NUMERICO"] = $faturamento[0]->percentual_multa . "%";
            $dados_minuta["PERCENTUAL_MULTA_EXTENSO"] = "(" . Extenso::converte($faturamento[0]->percentual_multa, false, false) . " porcento)";

            $empresa = json_decode($this->controller->modelo->empresaVendedora(null, true));

            if (isset($empresa) && !empty($empresa)) {
                foreach ($empresa as $key => $value) {
                    $dados_minuta["CM_NOME_EMRRESA"]      = $value->razao_social;
                    $dados_minuta["CM_CNPJ"] = formatarString("cnpj", $value->cnpj);
                }
            } else {
                $dados_minuta["CM_NOME_EMRRESA"] = '';
                $dados_minuta['CM_CNPJ'] = '';
            }
        }

        switch ($cod_produto) {
            case 'COR0001':
                $tabelas = $this->pdfCornerFull($contrato)['tabelas'];
                $valoresUnicos = $this->pdfCornerFull($contrato)['valoresUnicos'];
                break;

            default:
                // ...
                break;
        };

        return [
            'text' => array_merge($dados_minuta, $valoresUnicos),
            'tabelas' => $tabelas
        ];
    }

    private function pdfCornerFull($contrato)
    {
        $lista_preco_proposta =  json_decode($this->propostas_model->getLpPropostasId($contrato->id_proposta));
        // $modulos_proposta = json_decode($this->propostas_model->getPropostasModuloByIdProposta($contrato->id_proposta));
        $faixas_pre_organizadas = [];

        $faixas = [];
        $precos_unicos = [];
        $tabelas = [];

        foreach ($lista_preco_proposta as $key => $value) {
            $faixas_pre_organizadas[$value->codigo_modulo][] = $value;
        };

        foreach ($faixas_pre_organizadas as $key => $value) {
            if (count($value) == 1) {
                // $precos_unicos[$key] = $value[0];

                $precos_unicos[$this->modulos_traducao[$key] . '_NUMERICO'] = $value[0]->valor_real;
                $precos_unicos[$this->modulos_traducao[$key] . '_EXTENSO'] = "( " . Extenso::converte(funcValor($value[0]->valor_real, 'C', 2), true, false) . " )";

                $value[0]->qtd_de = '-';
                $value[0]->qtd_ate = '-';
                $faixas[$key] = $value;
            } else {
                foreach ($value as $key2 => $value2) {
                    $faixas[$key][$value2->qtd_de] = $value2;
                }
            }
        }

        if ($faixas) {
            foreach ($faixas as $key => $value) {
                $index = 0;
                asort($value);
                foreach ($value as $k => $v) {
                    if (count($value) == 1) {
                    }
                    $index++;
                    $de = count($value) > 1 ?  ($index == count($value) ? 'Acima de ' : funcValor($v->qtd_de, 'C', 0)) : '-';
                    $ate = count($value) > 1 ? funcValor($v->qtd_ate, 'C', 0) : '-';

                    $row = [
                        [
                            'de' => $de,
                            'ate' => $ate,
                            'valor' => funcValor($v->valor_real, 'C', 6)
                        ],
                    ];
                    $tabelas["TABELA_" . $this->modulos_traducao[$key]][] = $row[0];
                }
            }
        }

        foreach ($this->modulos_traducao as $key => $value) {
            if (!in_array($tabelas["TABELA_" . $value], $tabelas)) {
                $row = [
                    'de' => '-',
                    'ate' => '-',
                    'valor' => '-'
                ];
                $tabelas["TABELA_" . $value] = $row;
            }
        }

        ksort($tabelas);
        ksort($precos_unicos);
        return [
            "tabelas" => $tabelas,
            'valoresUnicos' => $precos_unicos
        ];
    }
}
