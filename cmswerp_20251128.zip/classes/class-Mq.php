<?php
	/**
	* Julio
	* Classe para log de eventos no sistema
	*/

	class Mq{
		Private
			$msg,
			$host,
			$channel,
			$queue_manager,
			$mqcno,
			$con,
			$obj,
			$gmo,
			$md,
			$mdg,
			$tx,
			$rx,
			$pmo,
			$obj_msg;

		public
			$error,
			$loop;


		function __construct($param = null){
			$this->setMq($param);
			// if(DEBUG_TARIFADOR)	{
			// 	$this->log->writeLog(' Objeto Mq criado '.json_encode($this), 'debug', 'tarifacao');
			// }
		}

		function setMq( $param ){
			$this->host = HOST_MQ.'('.PORT_MQ.')';
			$this->channel = CHANEL_MQ;
			$this->queue_manager = QUEUE_MQ;
			$this->gmo = array('Options' => MQSERIES_MQGMO_FAIL_IF_QUIESCING | MQSERIES_MQGMO_WAIT, 'WaitInterval' => LOOP_MQ);
			if(!$param){
				$this->rx = RX_MQ;
				$this->tx = TX_MQ;
			}else{
				$this->rx  = $param['rx'];
				$this->tx  = $param['tx'];
			}
		}

		function connect(){
			$this->setMqCno();
			mqseries_connx( $this->queue_manager, $this->mqcno, $conn, $comp_code, $reason );
			if ( $comp_code !== MQSERIES_MQCC_OK ){
				$this->setError( $comp_code, $reason,  mqseries_strerror( $reason ) );
			}else{
				$this->con = $conn;
			}
		}

		function setMqCno(){
			$this->mqcno = array
			(
				'Version' => MQSERIES_MQCNO_VERSION_2,
				'Options' => MQSERIES_MQCNO_STANDARD_BINDING,
				'MQCD' => array('ChannelName' => $this->channel,
				'ConnectionName' => $this->host,
				'TransportType' => MQSERIES_MQXPT_TCP)
			);
		}

		function openQueue( $queue ){
			$this->mqods = array( 'ObjectName' => $queue );
			if( $this->con ){
				mqseries_open(
					$this->con,
					$this->mqods,
					MQSERIES_MQOO_INPUT_AS_Q_DEF | MQSERIES_MQOO_FAIL_IF_QUIESCING | MQSERIES_MQOO_OUTPUT,
					$obj,
					$comp_code,
					$reason
				);

				if ($comp_code !== MQSERIES_MQCC_OK){
					$this->setError($comp_code, $reason,  mqseries_strerror($reason));
				}else{
					$this->obj = $obj;
				}
			}else{
				return false;
			}		
		}

		function getMsg(){
			return $this->msg;
		}

		function getObjMsg(){
			return $this->obj_msg;
		}

		function setObjMsq($msg_json = null){
			// a mensagem na variavel msg deve sempre corresponder ao objeto mq varialve obj_msg
			if($msg_json){
				$this->msg = $msg_json;	
			}
			
			$this->obj_msg = json_decode($this->msg);
			if( isset( $this->obj_msg->comando ) && $this->obj_msg->ispb == 'tarifacao' ){
				if(
					!isset($this->obj_msg->ispb)    ||
					!isset($this->obj_msg->modulo)  ||
					empty($this->obj_msg->ispb)     ||
					empty($this->obj_msg->modulo)
				){
					$file_name = ABSPATH.'/logs/msg_error_tarifacao_produto_'.$data_temp->format('Ymd').".txt";
					$fp = fopen($file_name, 'a+');
					fwrite($fp, $this->msg."\n");
					fclose($fp);
				}
			}elseif( !isset( $this->obj_msg->comando ) ){
				$file_name = ABSPATH.'/logs/msg_error_tarifacao_comando_'.$data_temp->format('Ymd').".txt";
				$fp = fopen($file_name, 'a+');
				fwrite($fp, $this->msg."\n");
				fclose($fp);
			}
			
			if(isset($this->obj_msg->ispb) && $this->obj_msg->ispb == 27406222 && isset($this->obj_msg->modulo) && $this->obj_msg->modulo == 'SPB0011'){
				$this->obj_msg->modulo = 'SPB0010';
				$this->msg = json_encode($this->obj_msg);
			}elseif(isset($this->obj_msg->ispb) && $this->obj_msg->ispb == 11165756 && isset($this->obj_msg->modulo) && $this->obj_msg->modulo == 'SPB0010'){
				$this->obj_msg->produto = 'FSP0001';
				$this->obj_msg->modulo  = 'STR0001';
				$this->msg = json_encode($this->obj_msg);
			}
			return $this;
		}

		function setMsg($msg = null){
			if(!$msg){
				$this->mdg = array();
				// parametro 1024 é referente ao buffer da mensagem a ser capturada
				if($this->con){
					mqseries_get($this->con, $this->obj, $this->mdg, $this->gmo, 2048, $msg, $data_length, $comp_code, $reason);
					if ($comp_code !== MQSERIES_MQCC_OK)	{
						$this->setError($comp_code, $reason,  mqseries_strerror($reason));
					}else{
						$msg_temp 		   = json_decode($msg, true);
    					$msg_temp['MsgId'] = bin2hex(mqseries_bytes_val($this->mdg['MsgId']));
    					$msg 			   = json_encode($msg_temp, JSON_UNESCAPED_UNICODE);
    					$this->msg = $msg;
    					$this->data_length = $data_length;
					}
				}else{
					return false;
				}
			}else{
				$this->msg = $msg;
			}
		}

		function insertQueue($msg, $correlation_id){
			$this->msg = $msg;
			$this->md = array(
				'Version' => MQSERIES_MQMD_VERSION_1,
				'Expiry' => MQSERIES_MQEI_UNLIMITED,
				'Report' => MQSERIES_MQRO_NONE,
				'MsgType' => MQSERIES_MQMT_DATAGRAM,
				'Format' => MQSERIES_MQFMT_STRING,
				'Priority' => 1,
				'Persistence' => MQSERIES_MQPER_PERSISTENT,
				'ReplyToQ' => 'RCVQ',
				'CorrelId' => $correlation_id
			);

			$this->pmo = array('Options' => MQSERIES_MQPMO_NEW_MSG_ID|MQSERIES_MQPMO_SYNCPOINT);
			// put the message 'Ping' on the queueu.
			mqseries_put($this->con, $this->obj, $this->md, $this->pmo, $this->msg, $comp_code, $reason);
			if ($comp_code !== MQSERIES_MQCC_OK){
				$this->setError($comp_code, $reason,  mqseries_strerror($reason));
				return false;
			}else{
				return true;
			}
		}

		function spendQueue(){
			$this->connect();
			$this->openQueue( $this->tx );
			$this->setMsg();
			$this->closeMq();
			$this->disconect();
		}

		function putQueue($msg, $correlation_id){
			$this->connect();
			$this->openQueue($this->rx);
			$this->insertQueue($msg, $correlation_id);
			$this->closeMq();
			$this->disconect();
		}

		function closeMq($obj = null, $conn = null){
			if($obj){
				$this->obj = $obj;
			}
			if($this->con){
				mqseries_close($this->con, $this->obj, MQSERIES_MQCO_NONE, $comp_code, $reason);
				if ($comp_code !== MQSERIES_MQCC_OK){
					$this->setError($comp_code, $reason,  mqseries_strerror($reason));
				}
			}elseif($conn){
				$this->con = $conn;
			}else{
				return false;
			}		
		}

		function disconect($conn = null){
			if($conn){
				$this->con = $conn;
			}
			if($this->con){
				// disconnect from the queue manager.
				mqseries_disc($this->con, $comp_code, $reason);
				if ($comp_code !== MQSERIES_MQCC_OK){
					$this->setError($comp_code, $reason,  mqseries_strerror($reason));
				}else{
					$this->con = $conn;
				}
			}else{
				return false;
			}		
		}

		function setError($comp_code, $cod_reason, $text_reason){
			//se $cod_reason = 2080 // buffer menor que a mensagem a ser capturada
			// texto para codigo 2080 é  "Truncated message returned (processing not completed)."
			$this->comp_code = $comp_code;
			$this->cod_reason = $cod_reason;
			$this->text_reason  = $text_reason;
			$this->error = "Connx CompCode: ".$comp_code." Reason: ".$cod_reason." Text: ".$text_reason." Mensagem: ".$this->msg."<br>\n";
			// $this->log->writeLog($this->error, 'debug', 'tarifacao');
		}
		
		function __destruct(){
			// if(DEBUG_TARIFADOR){
			// 	$this->log->writeLog(' Objeto Mq destruido '.json_encode($this), 'debug', 'tarifacao');
			// }
		}
		
		function consultaFila()
    	{
    		$this->connect();
    		$this->openQueue($this->tx);
    		echo '<pre>';
    		var_dump($this->con, $this->tx, $this->obj);
    		echo '</pre>';
    		// Consulta a quantidade de mensagens na fila
            $selectors = [MQSERIES_MQIA_CURRENT_Q_DEPTH]; // Seletores que definem atributos a consultar
    		$selectorCount = count($selectors); // Número de seletores
    		$intAttrs = []; // Array para armazenar os atributos inteiros
    		$intAttrCount = 1; // Esperamos 1 atributo inteiro
    		$charAttrs = ""; // String para armazenar atributos de texto (não usamos neste exemplo)
    		$charAttrLength = 0; // Nenhum atributo de texto esperado
    		$compCode = 0;  // Código de conclusão
    		$reason = 0;    // Código de razão
            mqseries_inq(
                $this->con,
                $this->obj,
                $selectorCount,
                $selectors,
                $intAttrCount,
                $intAttrs,
                $charAttrLength,
                $charAttrs,
                $compCode,
                $reason
            );
        
            if ($compCode === MQSERIES_MQCC_OK) {
                echo "Quantidade de mensagens na fila '$queueName': " . $attrs[MQSERIES_MQIA_CURRENT_Q_DEPTH] . "\n";
            } else {
                echo "Erro ao consultar a fila. Código: $compCode, Razão: $reason\n";
            }
    		
    	}
	}

