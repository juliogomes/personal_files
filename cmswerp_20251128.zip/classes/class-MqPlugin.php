<?php
	/**
	* Julio
	* Classe para log de eventos no sistema
	*/

class MqPlugin extends Main{
	private
		$msgId,
		$msg,
		$host,
		$channel,
		$queue_manager,
        $queue,
		$mqcno,
		$mqods,
		$mdg,
		$gmo;
	public
		$conexao,
		$error,
		$loop;

	function __construct($param = null){
		$this->setMq($param);
		parent::__construct(null);
	}

	function setMq($param){
		$this->host          = $param['host'].'('.$param['port'].')';
		$this->channel       = $param['channel'];
		$this->queue_manager = $param['manager'];
        $this->queue         = $param['queue'];
        $this->loop          = $param['loop'];
	}

	function connect(){
		$this->gmo = array(
			'Options' => MQSERIES_MQGMO_FAIL_IF_QUIESCING | MQSERIES_MQGMO_WAIT, 
			'WaitInterval' => $this->loop
		);

        $this->mqcno = array(
			'Version' => MQSERIES_MQCNO_VERSION_2,
			'Options' => MQSERIES_MQCNO_STANDARD_BINDING,
			'MQCD' => array('ChannelName' => $this->channel,
			'ConnectionName' => $this->host,
			'TransportType' => MQSERIES_MQXPT_TCP)
		);
		mqseries_connx($this->queue_manager, $this->mqcno, $conn, $comp_code, $reason);
		if ($comp_code !== MQSERIES_MQCC_OK){
			$this->setError($comp_code, $reason, mqseries_strerror($reason));
			return false;
		}else{
			$this->conexao = $conn;
			return true;
		}
	}

	function openQueue(){
		$this->mqods = array('ObjectName' => $this->queue);
		if($this->conexao){
			mqseries_open($this->conexao,$this->mqods,MQSERIES_MQOO_INPUT_AS_Q_DEF | MQSERIES_MQOO_FAIL_IF_QUIESCING | MQSERIES_MQOO_OUTPUT,$obj,$comp_code,$reason);
			if ($comp_code !== MQSERIES_MQCC_OK){
				$this->setError($comp_code, $reason,  mqseries_strerror($reason));
				return false;
			}else{
				$this->obj = $obj;
				return true;
			}
		}else{
			return false;
		}		
	}

    function PegarMensagem(){
        // echo 'PEGANDO NA FILA <br>';
        return $this->msg;
    }

	function colocarNaFila($msg){
		if($msg){
			if($this->openQueue()){
				$this->md = array(
					'Version' => MQSERIES_MQMD_VERSION_1,
					'Expiry' => MQSERIES_MQEI_UNLIMITED,
					'Report' => MQSERIES_MQRO_NONE,
					'MsgType' => MQSERIES_MQMT_DATAGRAM,
					'Format' => MQSERIES_MQFMT_STRING,
					'Priority' => 1,
					'Persistence' => MQSERIES_MQPER_PERSISTENT,
					'ReplyToQ' => 'RCVQ',
					// 'CorrelId' => $correlation_id
				);
				$this->pmo = array('Options' => MQSERIES_MQPMO_NEW_MSG_ID|MQSERIES_MQPMO_SYNCPOINT);
				mqseries_put($this->conexao, $this->obj, $this->md, $this->pmo, $msg, $comp_code, $reason);
				if ($comp_code === MQSERIES_MQCC_OK){
					return true;
				}else{
					$this->setError($comp_code, $reason,  mqseries_strerror($reason));
					return false;
				}
			}else{
				return false;
			}
		}else{

		}
	}

	function getMsgId(){
		return $this->msgId;
	}

	function pegarNaFila(){
		if($this->openQueue()){
			$this->mdg = array();
			// parametro 1024 é referente ao buffer da mensagem a ser capturada
			if($this->conexao){
				mqseries_get($this->conexao, $this->obj, $this->mdg, $this->gmo, 16384, $msg, $data_length, $comp_code, $reason);
				// mqseries_inq($this->conexao, $this->obj, 1, array(MQSERIES_MQCA_Q_MGR_NAME), 0, $int_attr, 48, $char_attr, $comp_code, $reason);
				if ($comp_code === MQSERIES_MQCC_OK)	{
					$this->msgId = bin2hex(mqseries_bytes_val($this->mdg['MsgId']));
					if(strlen($this->msgId) > 48){
					    $this->msgId = substr($this->msgId, 0, 48);
					}
					$this->msg 	        = $msg;
					$this->data_length  = $data_length;
					$file_name          = ABSPATH.'/logs/'.strtolower($this->queue).'_'.$this->data_atual->format('Ymd').'.log';
                    $fp                 = fopen($file_name, 'a+');
                    fwrite($fp, $msg."\n");
                    fclose($fp);
                	return true;
				}else{
					$this->setError($comp_code, $reason,  mqseries_strerror($reason));
					return false;
				}
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	function closeMq(){
		if($this->conexao && isset($this->obj)){
		    mqseries_close($this->conexao, $this->obj, MQSERIES_MQCO_NONE, $comp_code, $reason);
    		if ($comp_code !== MQSERIES_MQCC_OK){
    			$this->setError($comp_code, $reason,  mqseries_strerror($reason));
    		}else{
    			return true;
    		}    
		}
	}

	function disconect(){
		//disconnect from the queue manager.
		mqseries_disc($this->conexao, $comp_code, $reason);
		if ($comp_code !== MQSERIES_MQCC_OK){
			$this->setError($comp_code, $reason,  mqseries_strerror($reason));
		}else{
			return true;
		}
	}

	function setError($comp_code, $cod_reason, $text_reason){
		//se $cod_reason = 2080 // buffer menor que a mensagem a ser capturada
		// texto para codigo 2080 é  "Truncated message returned (processing not completed)."
		$this->comp_code   = $comp_code;
		$this->cod_reason  = $cod_reason;
		$this->text_reason = $text_reason;
		$this->error = "Connx CompCode: ".$comp_code." Reason: ".$cod_reason." Text: ".$text_reason." Mensagem: ".$this->msg."<br>\n";
	}
}