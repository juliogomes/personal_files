<?php
class NewMain
{
    protected $registry;
    protected $model;
    public $data_atual;
    public $erro     = array();
    public $msg_erro = array();
    function __construct($registry = null)
    {
        $this->data_atual = getDataAtual();
        if ($registry instanceof Registry) {
            $this->registry = $registry;
        } else {
            $this->registry = new Registry();
        }
    }
}
