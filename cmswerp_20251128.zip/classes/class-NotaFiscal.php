<?php
	/**
	* Julio
	* Classe para log de eventos no sistema
	*/
class NotaFiscal extends Main{
	protected $controller;
	function __construct($controller, $param = null){
		$this->controller = $controller;
		//Objeto com acesso a base de dados de cadastros;
		$this->obj_contrato = $this->controller->load_model('contratos/contratos', true);
		//Objeto com acesso a base de dados de impostos;
		$this->obj_imposto = $this->controller->load_model('impostos/impostos', true);
		//Objeto com acesso a base de dados de produtos;
		$this->obj_produto = $this->controller->load_model('cadastros/produtos', true);
		//Objeto com acesso a base de dados de faturamento;
		$this->obj_faturamento = $this->controller->load_model('faturamento/faturamento', true);
		//Objeto com acesso a base de dados de indices;
		$this->obj_indice = $this->controller->load_model('cadastros/indices-reajuste', true);
		//objeto com acesso a base de dados de movimento diario;
	}
}
