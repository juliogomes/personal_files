<?php

    class Notificacoes extends Main{
        protected 
            $obj_api,
            $parametros,
            $integracao,
            $obj_email, 
            $user_model;      
        
        function __construct($controller = null, $param = null){
            parent::__construct($controller);
            $this->obj_api    = new Api($this->controller, $param);
            $this->obj_email  = new Email();
            $this->user_model = new UsuariosModel();
        }
        
        function enviar( $tipo, $parametros ){
            try {
                if(!$tipo){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $parametros;
                    $retorno['output'] 	 = null;
                    $retorno['mensagem'] = 'Tipo de mensagem não informado';
                }

                if(!$parametros){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $parametros;
                    $retorno['output'] 	 = null;
                    $retorno['mensagem'] = 'Parametros obrigatorios não informados';
                }

                switch ($tipo) {
                    case 'teams':
                        $this->integracao = new Integracoes($this->controller, 'TEAM001');
                        $obj_token        = json_decode($this->integracao->Exec( 'token', 'getTokenUser' ) );
                        if(!isset($parametros['mensagem']) || empty($parametros['mensagem'])){
                            if(!$parametros){
                                $retorno['codigo']   = 1;
                                $retorno['input']    = $parametros;
                                $retorno['output'] 	 = null;
                                $retorno['mensagem'] = 'Mensagem não pode ser vazia';
                            }
                        }
                        
                        if(isset( $obj_token->output->access_token ) ){
                            $parametros['token'] = $obj_token->output->access_token;
                        }else{
                            if(!$parametros){
                                $retorno['codigo']   = 1;
                                $retorno['input']    = $parametros;
                                $retorno['output'] 	 = $obj_token;
                                $retorno['mensagem'] = $obj_token->mensagem;
                            }
                        }

                        switch ($parametros['tipo_destinatario']) {
                            case 'canal':
                                if(!isset($parametros['id_grupo']) || empty($parametros['id_grupo'])){
                                    $retorno['codigo']   = 1;
                                    $retorno['input']    = $parametros;
                                    $retorno['output'] 	 = null;
                                    $retorno['mensagem'] = 'ID do grupo não informado';
                                }

                                if(!isset($parametros['id_canal']) || empty($parametros['id_canal'])){
                                    $retorno['codigo']   = 1;
                                    $retorno['input']    = $parametros;
                                    $retorno['output'] 	 = null;
                                    $retorno['mensagem'] = 'ID do canal não informado';
                                }
                                return json_decode($this->integracao->Exec('chat', 'sendMessageChannel', $parametros));
                            break;
                            case 'webhook':
                                return json_decode($this->integracao->Exec('chat', 'sendMessageWebHook', $parametros));                           
                            break;
                            case 'user':
                                $parametros['members'][0] = "julio.gomes@cmsw.com";
                                if(!isset($parametros['email_to']) || empty($parametros['email_to'])){
                                    $retorno['codigo']   = 1;
                                    $retorno['input']    = $parametros;
                                    $retorno['output'] 	 = null;
                                    $retorno['mensagem'] = 'Email do destinatario não informado';
                                    throw new Exception (json_encode($retorno), 1);
                                }
                                
                                $parametros['members'][1] = $parametros['email_to'];
                                $create = json_decode( $this->integracao->Exec( 'chat', 'createOne', $parametros ) );
                                if( $create->codigo == 0 ){
                                    $parametros['chat_id'] = $create->output->id;
                                    return json_decode( $this->integracao->Exec( 'chat', 'sendMessageChat', $parametros ) );
                                }else{
                                    return $create;
                                }
                            break;
                            default:
                                $retorno['codigo']   = 1;
                                $retorno['input']    = $parametros;
                                $retorno['output'] 	 = null;
                                $retorno['mensagem'] = 'Tipo de destinatario não informado';
                            break;
                        }
                    break;
                    case 'email':
                        if( isset( $parametros['para'] ) && !empty( $parametros['para'] ) ){
                            $para = $parametros['para'];
                        }else{
                            $retorno['codigo']   = 1;
                            $retorno['mensagem'] = 'Informe o destinatario';
                        }

                        $assunto        = ( isset( $parametros['assunto'] ) )?$parametros['assunto']:'Você recebeu uma mensagem';
                        $mensagem       = ( isset( $parametros['mensagem'] ) )?$parametros['mensagem']:'Você recebeu uma mensagem';
                        $remetente      = ( isset( $parametros['remetente'] ) )?$parametros['remetente']:null;
                        $remetente_nome = ( isset( $parametros['remetente_nome'] ) )?$parametros['remetente_nome']:null;
                        $copia_para     = ( isset( $parametros['copia_para'] ) )?$parametros['copia_para']:null;
                        $copia_oculta   = ( isset( $parametros['copia_oculta'] ) )?$parametros['copia_oculta']:null;
                        $anexo          = ( isset( $parametros['anexo'] ) )?$parametros['anexo']:null;
                        return $this->obj_email->sendMail( 
                            $para, 
                            $assunto, 
                            $mensagem,
                            $remetente,
                            $remetente_nome,
                            $copia_para,
                            $copia_oculta,
                            $anexo
                       );
                    break;
                    default:
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $parametros;
                        $retorno['output'] 	 = null;
                        $retorno['mensagem'] = 'Tipo de envio não informado';
                    break;
                }
            } catch (Exception $e) {
                return $e->getMessage();
            }
        }
        
        function sendProposta($param, $records, $nome_hash){
            
            $cnpj_cpf = $records[0]->cnpj_cpf;
            $id_proposta = $records[0]->id;
            $replay_to['email'] = $records[0]->email_usuario;
            $replay_to['user'] = $records[0]->nome;
            $path = UP_GED.DS.'propostas'.DS.$cnpj_cpf.DS.'proposta_finalizada'.DS.$nome_hash;
            $to =  $param['to'];
            $this->obj_email  = new Email();
            $mensagem = $param['texto'];
            $send = $this->obj_email->sendMail($to, 'PROPOSTA COMERCIAL', $mensagem, 
            null, null, null, null, $path, $replay_to);
            $retorno_json = json_decode($send);
            try{
                if($retorno_json->codigo == 0){
                    $retorno['codigo']   = $retorno_json->codigo;
                    $retorno['input']    = $retorno_json->input;
                    $retorno['output']   = $retorno_json->output;
                    $retorno['mensagem'] = "Sucesso ao enviar proposta";
                    throw new Exception (json_encode($retorno), 1);	
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $retorno_json->input;
                    $retorno['output']   = $retorno_json->output;
                    $retorno['mensagem'] = $retorno_json->mensagem;
                    throw new Exception (json_encode($retorno), 1);	
                }
            }catch(Exception $e){
                return $e->getMessage();
            }
        }

        function sendNotificacao($tipo, $param = null, $records = null, $nome_hash = null){
            switch ($tipo) {
                case 'alertas':
                    return $this->sendAlertas($param);
                break;
                case 'status_despesas':
                    return $this->StatusDespesas($param);
                break;
                case 'proposta':
                    return $this->sendProposta($param, $records, $nome_hash);
                break;
                default:
                break;
            }
        }

        function alertaTeams($tipo, $parametros = null){
            try{
                if(TIPO_AMBIENTE == 'producao'){
                    $url = 'https://tarifa.cmsw.com/';
                }else if(TIPO_AMBIENTE == 'homolog'){
                    $url = 'https://tarifa-h.cmsw.com/';
                }else{
                    $url = 'http://projetos4.local/';
                }
                $mensagem["tipo_destinatario"] = 'user';            
                        
                switch ($tipo) {
                    case 'assinatura':
                        $objeto = "minuta";                                                     
                        $mensagem["mensagem"] = "Contrato assinado por: ".$parametros["nome_ass"].". Tipo de contato: ".strtoupper(str_replace("_"," ",$parametros["tipo_contato"])).". Link para verificar assinaturas: ".$url."propostas/statusFaturamento/".$parametros["id"];				
                    break;
                    case 'contrato_finalizado':
                        $objeto = "minuta";                  
                        $mensagem["mensagem"]	= "Parabéns comercial, contrato: ".$parametros["cliente"]." assinado por todos os assinantes. Link para verificar assinaturas: ".$url."propostas/statusFaturamento/".$parametros["id"];                   	
                    break;
                    case 'contrato_ganho':
                        $objeto = "contrato";                  
                        $mensagem["mensagem"] = "NOVO CONTRATO GERADO E FATURADO! - LINK: ".$url."contratos/detalhe/id/".$parametros["id"];
                    break; 
                    case 'aprovado_comercial': 
                        $objeto = "proposta";                    
                        $mensagem["mensagem"] = "MINUTA APROVADA PELO DIRETOR COMERCIAL - LINK: ".$url."propostas/statusFaturamento/".$parametros["id"];
                    break;
                    case 'aprovado_juridico': 
                        $objeto = "proposta";                    
                        $mensagem["mensagem"] = "MINUTA APROVADA PELO JURIDICO - LINK: ".$url."propostas/statusFaturamento/".$parametros["id"];
                    break;
                    case 'minuta_preenchida':
                        $objeto = "minuta";                     
                        $mensagem["mensagem"] = "MINUTA PREENCHIDA - LINK: ".$url."propostas/statusFaturamento/".$parametros["id"];
                    break;
                    case 'proposta_aprovado':
                        $objeto = "proposta";                    
                        $mensagem["mensagem"] = "PROPOSTA APROVADA - ".$parametros["cliente"]." - LINK: ".$url."propostas/texto/editar/id/".$parametros["id"];                 
                    break;
                    case 'nda_aprovado':
                        $objeto = "proposta";                   
                        $mensagem["mensagem"] = "NDA APROVADO - ID: ".$parametros["id"]." - CLIENTE: ".$parametros["cliente"];
                    break;
                    case 'proposta_criada':
                        $objeto = "proposta";
                        if(isset($parametros['codigo_produto']) && $parametros['codigo_produto'] == "YLW0001"){                      
                            $mensagem["mensagem"] = "NOVA PROPOSTA YELLOW - LINK: ".$url."propostas/texto/editar/id/".$parametros["id"]; 
                        }else{                        
                            $mensagem["mensagem"] = "NOVA PROPOSTA - LINK: ".$url."propostas/texto/editar/id/".$parametros["id"]; 
                        }                    
                    break;
                    case 'erro_contrato':
                        $user                 = array("julio.gomes@cmsw.com");
                        if(isset($parametros["mensagem"])){
                            $mensagem["mensagem"] = $parametros["mensagem"];
                        }else{
                            $mensagem["mensagem"] = "ERRO CONTRATO - ID:".$parametros["id"]." - CLIENTE: ".$parametros["cliente"];
                        }
                    break;
                    case 'alerta_comissao_progressiva':
                        $user                 = array("julio.gomes@cmsw.com");
                        $mensagem["mensagem"] = "ALERTA DE DISPARO COMISSÃO PROGRESSIVA - ".$this->data_atual->format('d/m/Y H:i:s');
                    break;
                    case 'erro_comissao_progressiva':
                        $user                 = array("julio.gomes@cmsw.com");
                        if(isset($parametros['mensagem'])){
                            $mensagem["mensagem"] = $parametros['mensagem'];
                        }else{
                            $mensagem["mensagem"] = "ERRO DE COMISSÃO PROGRESSIVA - ".$this->data_atual->format('d/m/Y H:i:s');
                        }
                    break;
                    case 'sucesso_rotina':
                        $user                 = array("julio.gomes@cmsw.com");                   
                        $mensagem["mensagem"] = "SUCESSO ROTINA - ".$this->data_atual->format('d/m/Y H:i:s');                   
                    break;
                    case 'webhhok':
                        //OBTER USUARIOS JURIDICO / DIRETOR COMERCIAL / ASSINANTES / OWNER DO CONTRATO
                        $objeto = "minuta";                    
                    break;
                    case 'ponto_marcacao':
                        // $user = array("julio.gomes@cmsw.com","selma.oliveira@cmsw.com","julio.gomes@cmsw.com","dulcineia.mata@cmsw.com","isabelle.santana@cmsw.com", "aleni.santos@cmsw.com");  
                        $user = array("julio.gomes@cmsw.com");
                        array_push($user, $parametros['user']);
                        $mensagem["mensagem"] = $parametros["mensagem"];
                    break;
                    case 'rotina_alerta':
                        $user = array("julio.gomes@cmsw.com");                    
                        $mensagem["mensagem"] = $parametros["mensagem"];
                    break;
                    default:
                        $user                 = array("julio.gomes@cmsw.com");
                        $mensagem["mensagem"] = "TESTE DE ALERTA TEAMS ".$this->data_atual->format('d/m/Y H:i:s').'COD: 257';
                    break;
                } 

                if(isset($objeto) && !empty($objeto)){
                    $get_user = json_decode($this->user_model->getAlertas(null,$objeto));
                    if(isset($get_user) && !empty($get_user)){
                        foreach ($get_user as $key => $value) {
                        $user[] = $value->email;
                        }
                    }
                }
                if(isset($parametros["user_comercial"]) && !empty($parametros["user_comercial"])){
                    array_push($user,$parametros['user_comercial']);
                }
            
                // if(TIPO_AMBIENTE != "producao" || !isset($user)){
                //     $user = array("julio.gomes@cmsw.com");
                // }     
                // $user = array("julio.gomes@cmsw.com");
                if(isset($user) && !empty($user)){
                    foreach ($user as $key => $value) {
                        $mensagem["email_to"] = $value;
                        $this->enviar('teams',$mensagem);	
                    }
                }else{
                    $user = array("julio.gomes@cmsw.com");
                    $mensagem["mensagem"] .= " user não definido!";
                    foreach ($user as $key => $value) {
                        $mensagem["email_to"] = $value;
                        $this->enviar('teams',$mensagem);
                    }
                }
            
            }catch(Exception $e){
                return $e->getMessage();
            }
        }

        function enviarEmail($tipo, $parametros){
            if(TIPO_AMBIENTE == 'producao'){              
                $url = 'https://tarifa.cmsw.com/';
            }else if(TIPO_AMBIENTE == 'homolog'){
                $url = 'https://tarifa-h.cmsw.com/';
            }else{
                $url = 'http://projetos4.local/';
            }
            $bcc = array(
                0 => 'julio.gomes@cmsw.com',
            );	

            switch ($tipo) {
                case 'contrato_ganho':
                    $to       =  array("julio.gomes@cmsw.com","beatriz.silva@cmsw.com","selma.oliveira@cmsw.com","dulcineia.mata@cmsw.com","aleni.santos@cmsw.com","julio.gomes@cmsw.com","patrick.nascimento@cmsw.com");
                    $mensagem =  "NOVO CONTRATO GERADO E FATURADO!";
                    $mensagem .= "<br> CLIENTE: ".$parametros["cliente"];
                    $mensagem .= "<br> LINK: ".$url."contratos/detalhe/id/".$parametros["id"];
                break;
                
                default:
                    $mensagem = "TESTE MENSAGEM";
                break;
            }

            if(TIPO_AMBIENTE != "producao"){
                $to  =  [			
                    "0" => "julio.gomes@cmsw.com",
                ];	
            }		
                    
            $send = $this->obj_email->sendMail($to, 'CONTRATO FATURADO', $mensagem);
            return json_decode($send);				
        }

        function alertaWebhook($tipo, $dados, $codigo = null, $parametros = null){
            try{           
                switch ($tipo) {
                    case 'alerta':
                        // $parametros['tipo_destinatario'] = "canal";
                        // $parametros['id_grupo']          = "6481764e-f982-42db-b9b4-04235da91ec8&tenantId=07c74f1b-9c61-4995-807a-c7942b88271b";
                        // $parametros['id_canal']          = "140a62c3.cmsw.com@amer.teams.ms";
                        $parametros['tipo_destinatario'] = 'webhook';
                        $parametros['webhook']           = "https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/a7b31b8f453e41bfb6744ec6963de16d/c8c7ff53-e294-4a3a-bcad-c9f04857e469";
                        switch ($codigo) {
                            case '1':
                                $parametros['mensagem'] = "Documento finalizado<br>Cliente: ".$dados['cliente']."<br>".$this->data_atual->format('d/m/Y H:i:s');
                                break;
                            case '2':
                                $parametros['mensagem'] = "E-mail não encontrado: ".$dados['email']."<br> Cliente: ".$dados['cliente']."<br>".$this->data_atual->format('d/m/Y H:i:s');;
                                break;
                            case '3':
                                $parametros['mensagem'] = "Documento cancelado"."<br>".$dados['cliente']."<br>".$this->data_atual->format('d/m/Y H:i:s');;
                                break;
                            case '4':
                                $parametros['mensagem'] = "Documento assinado por: ".$dados['email']."<br>".$dados['cliente']."<br>".$this->data_atual->format('d/m/Y H:i:s');;
                                break;                        
                            default:
                                $parametros['mensagem'] = "Código indefinido"."<br>".$this->data_atual->format('d/m/Y H:i:s');;
                                break;
                        }                    				
                    break;       
                    case 'alerta_ponto':
                        $parametros['tipo_destinatario'] = 'webhook';
                        $parametros['webhook']           = "https://cmsw1.webhook.office.com/webhookb2/06b48f3c-0684-46b4-ad04-63494a706bc7@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/22923bd1726f4a93bd97e45a28d53268/dee1a75d-d63b-487b-9957-4470177c2fc1";  
                        $parametros['mensagem']          = $dados['mensagem'];                    
                    break;
                    default:
                        $user                 = array("julio.gomes@cmsw.com");
                        $mensagem["mensagem"] = "TESTE DE ALERTA TEAMS WEBHOOK ".$this->data_atual->format('d/m/Y H:i:s').'COD: 369';
                    break;
                }
                        
                if(isset($parametros) && !empty($parametros)){
                    $retorno_func = $this->enviar('teams',$parametros);	                
                }else{
                    $user = array("julio.gomes@cmsw.com");
                    $mensagem["mensagem"] .= "Parametros do alerta WebHook não definido!";
                    foreach ($user as $key => $value) {
                        $mensagem["email_to"] = $value;
                        $retorno_func = $this->enviar('teams',$mensagem);
                    }
                }                    
            
                if(isset($retorno_func) && $retorno_func->codigo == 0){
                    $retorno['codigo']   = 0;				
                    $retorno['mensagem'] = "Sucesso";
                    throw new Exception (json_encode($retorno), 1);	
                }else{
                    $retorno['codigo']   = 1;				
                    $retorno['mensagem'] = "Erro";
                    throw new Exception (json_encode($retorno), 1);	
                }
            }catch(Exception $e){
                return $e->getMessage();
            }
        }
        
        function sendAlertas( $param ){
            try{
                $param_slack = null;
                if( is_array( $param ) ){
                    $dados_envio = convertToObject($param);
                }
            
                foreach ( $dados_envio as $key => $value ) {
                    $is_send = false;
                    if('email' == $key){                    
                        $this->obj_email  = new Email();
                        if( isset( $value->destinatario ) && !empty( $value->destinatario ) ){
                            if( is_string( $value->destinatario ) ){
                                $to = explode(';', $value->destinatario);
                            }else{
                                $to = $value->destinatario;
                            }
                        }else{
                            $to = null;
                        } 

                        if( isset( $value->em_copia ) && !empty( $value->em_copia ) ){
                            $cc = explode(';', $value->em_copia);
                        }else{
                            $cc = null;
                        } 

                        if( isset( $value->copia_oculta ) && !empty( $value->copia_oculta ) ){
                            $bcc = explode(';', $value->copia_oculta);
                        }else{
                            $bcc = null;
                        } 

                        if( isset( $value->assunto ) && !empty( $value->assunto ) ){
                            $subject = $value->assunto;
                        }else{
                            $subject  = 'Alerta tarifador leia a mensagem!!!';
                        } 

                        if( isset( $value->mensagem ) && !empty( $value->mensagem ) ){
                            $mensagem = $value->mensagem;
                        }else{
                            $mensagem = 'Alerta tarifador leia a mensagem!!!';
                        } 

                        if( isset( $value->email_remetente ) ){
                            if( !empty( $value->email_remetente ) && is_array( $value->email_remetente ) ){
                                $from = explode(';', $value->email_remetente);
                            }elseif( !empty( $value->email_remetente ) && is_string( $value->email_remetente ) ){
                                $from = $value->email_remetente;
                            }
                        }else{
                            $from = null;
                        }

                        if( isset( $value->nome_remetente ) ){
                            if( !empty( $value->nome_remetente ) && is_array( $value->nome_remetente ) ){
                                $from_name = explode(';', $value->nome_remetente);
                            }elseif( !empty( $value->nome_remetente ) && is_string( $value->nome_remetente ) ){
                                $from_name = $value->nome_remetente;
                            }
                        }else{
                            $from_name = null;
                        } 

                        if( isset( $value->anexo ) && !empty( $value->anexo ) ){
                            $attachment = $value->anexo;
                        }else{
                            $attachment = null;
                        } 
    
                        $is_send = json_decode( $this->obj_email->sendMail( $to, $subject, $mensagem, $from, $from_name, $cc, $bcc, $attachment ) );
                        $this->obj_email = null;
                        if($is_send->codigo == 0){
                            $retorno[$key]['codigo']   = 0;
                            $retorno[$key]['tipo']     = 'success';
                            $retorno[$key]['input']    = $is_send->input;
                            $retorno[$key]['output']   = $is_send->output;
                            $retorno[$key]['mensagem'] = 'Email enviado com sucesso';
                        }else{
                            $retorno[$key]['codigo']   = 1;
                            $retorno[$key]['tipo']     = 'error';
                            $retorno[$key]['input']    = $is_send->input;
                            $retorno[$key]['output']   = $is_send->output;
                            $retorno[$key]['mensagem'] = 'Erro ao enviar email';
                        }
                    }
                }
                throw new Exception(json_encode($retorno), 1);   
            } catch (Exception $e) {
                return $e->getMessage();
            }
        }
    }