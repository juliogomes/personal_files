<?php
// Irá substituir a classe notificações
class Notificador extends Main
{
    protected $obj_class;
    protected $canal = 'teams';
    private static $logPath = LOG_DIR . 'notificacoes.log';
    function __construct($controller = null, $param = null)
    {
        parent::__construct($controller);
    }

    public static function enviar($tipo, $titulo, $mensagem, $parametros, $canais = [], $agendarPara = null)
    {
        if ($agendarPara) {
            self::agendarEnvio($titulo, $mensagem, $parametros, $canais, $agendarPara);
            return;
        }

        if (!empty($canais['email'])) {
            self::enviarEmail($tipo, $titulo, $mensagem, $parametros);
        }

        if (!empty($canais['whatsapp'])) {
            self::enviarWhatsapp($tipo, $titulo, $mensagem, $parametros);
        }

        if (!empty($canais['teams'])) {
            self::enviarTeams($tipo, $titulo, $mensagem, $parametros);
        }

        if (!empty($canais['sistema'])) {
            self::enviarInterno($tipo, $titulo, $mensagem, $parametros);
        }
    }

    private static function enviarEmail($tipo, $titulo, $mensagem, $parametros)
    {
        $subject = $titulo;
        self::log("📧 Enviando e-mail");
        self::log("━━━━━━━━━━━━━━━━━━━━━━");
        self::log("📨 Para: " . (isset($parametros['to']) ? $parametros['to'] : $parametros['email']));
        self::log("📝 Assunto: " . $titulo);
        self::log("💬 Mensagem: ");
        $msg_texto = "📢 <strong>Ocorrência gerada:</strong><br>";
        $msg_texto .= "👤 <strong>Colaborador:</strong> {$mensagem['colaborador']}<br>";
        $msg_texto .= "📝 <strong>Justificativa:</strong> {$mensagem['justificativa']}<br>";
        $msg_texto .= "🆔 <strong>ID da Ocorrência:</strong> {$mensagem['id_ocorrencia']}<br>";
        $msg_texto .= "🔐 <strong>Token de Regularização:</strong> {$mensagem['token']}";
        // Log com aspas e mantendo formatação
        self::log("\"" . $msg_texto . "\"");
        self::log("━━━━━━━━━━━━━━━━━━━━━━");
        $email    = new Email();
        $template = self::carregarTemplate('email', $tipo, $titulo, $mensagem);
        $from        = isset($parametros['from'])        ? $parametros['from']        : null;
        $from_name   = isset($parametros['from_name'])   ? $parametros['from_name']   : null;
        $to          = isset($parametros['to'])          ? $parametros['to']          : (isset($parametros['email']) ? $parametros['email'] : null);
        $cc          = isset($parametros['cc'])          ? $parametros['cc']          : null;
        $bcc         = isset($parametros['bcc'])         ? $parametros['bcc']         : null;
        $attachement = isset($parametros['attachement']) ? $parametros['attachement'] : null;
        $is_send = $email->sendMail($to, $subject, $template, $from, $from_name, $cc, $bcc, $attachement);
        if ($is_send) {
            return true;
        } else {
            return false;
        }
    }

    private static function enviarTeams($tipo, $titulo, $mensagem, $parametros)
    {
        $mensagem_json = json_encode($mensagem);
        $conteudo = "[Teams] {$titulo}: {$mensagem_json}";
        self::log($conteudo);
        $controller = null; // ou defina o controller necessário, se tiver um contexto
        $instancia = new self($controller);
        $instancia->integracao = new Integracoes($controller, 'TEAM001');
        $obj_token = json_decode($instancia->integracao->Exec('token', 'getTokenUser'));
        if (isset($obj_token->output->access_token)) {
            $param['token'] = $obj_token->output->access_token;
        } else {
            echo $obj_token->mensagem;
            exit;
        }

        $param['token']      = $obj_token->output->access_token;
        $param['members'][1] = $parametros['to'];
        $create = json_decode($instancia->integracao->Exec('chat', 'createOne', $param));
        if ($create->codigo == 0) {
            $param['chat_id'] = $create->output->id;
            // Conteúdo do Adaptive Card
            // $adaptiveCardContent = [
            //     '$schema' => 'http://adaptivecards.io/schemas/adaptive-card.json',
            //     'type' => 'AdaptiveCard',
            //     'version' => '1.3',
            //     'body' => [
            //         [
            //             'type' => 'TextBlock',
            //             'text' => '📢 ' . $titulo,
            //             'size' => 'Large',
            //             'weight' => 'Bolder',
            //             'wrap' => true
            //         ],
            //         [
            //             'type' => 'TextBlock',
            //             'text' => 'COLABORADOR: ' . $mensagem['colaborador'],
            //             'wrap' => true
            //         ],
            //         [
            //             'type' => 'TextBlock',
            //             'text' => 'JUSTIFICATIVA: ' . $mensagem['justificativa'],
            //             'wrap' => true
            //         ],
            //         [
            //             'type' => 'TextBlock',
            //             'text' => 'ID OCORRENCIA: ' . $mensagem['id_ocorrencia'],
            //             'wrap' => true
            //         ],
            //         [
            //             'type' => 'TextBlock',
            //             'text' => 'TOKEN: ' . $mensagem['token'],
            //             'wrap' => true
            //         ]
            //     ]
            // ];
            $adaptiveCard = self::carregarTemplate('teams', $tipo, $titulo, $mensagem);
            $param['mensagem'] = [
                'body' => [
                    'contentType' => 'html',
                    'content' => "<attachment id=\"1\"></attachment>"
                ],
                'attachments' => [
                    [
                        'id' => '1',
                        'contentType' => 'application/vnd.microsoft.card.adaptive',
                        'contentUrl' => null,
                        'content' => json_encode($adaptiveCard)
                    ]
                ]
            ];
        } else {
            echo 'Erro ao criar chat: ' . $create->mensagem;
            exit;
        }
        $param['isHMTL'] = true;
        $send_teams = json_decode($instancia->integracao->Exec('chat', 'sendMessageChat', $param));
    }

    private static function enviarWhatsapp($titulo, $mensagem, $usuario)
    {
        $conteudo = "[WhatsApp] Para: {$usuario['telefone']} - {$titulo}: {$mensagem}";
        self::log($conteudo);
    }

    private static function enviarInterno($titulo, $mensagem, $usuario)
    {
        $conteudo = "[🖥️ Sistema] Usuário {$usuario['nome']} - {$titulo}: {$mensagem}";
        self::log($conteudo);
    }

    private static function agendarEnvio($titulo, $mensagem, $usuario, $canais, $data)
    {
        // implementar disparador contido em disparar_agendados.php
        $registro = [
            'titulo' => $titulo,
            'mensagem' => $mensagem,
            'usuario' => $usuario,
            'canais' => $canais,
            'agendar_para' => $data
        ];
        $json = json_encode($registro);
        file_put_contents('agendados.json', $json . PHP_EOL, FILE_APPEND);
        self::log("[Agendado] {$titulo} para {$data}");
    }

    private static function log($mensagem)
    {
        $registro = "[" . date('Y-m-d H:i:s') . "] $mensagem\n";
        // echo $registro; // Pode ser removido em produção
        file_put_contents(self::$logPath, $registro, FILE_APPEND);
    }

    public static function carregarTemplate($canal, $tipo, $titulo, $mensagem)
    {
        $arquivo = ABSPATH . "/template/notificador/mensagens/{$canal}/{$tipo}.php";
        if (!file_exists($arquivo)) return false;
        extract(['titulo' => $titulo, 'mensagem' => $mensagem]);
        return include $arquivo;
    }
}
