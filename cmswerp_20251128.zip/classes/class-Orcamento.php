<?php
	/**
	* Julio
	* Classe para controle de orcamento
	*/
class Orcamento{
    protected $controller, $data_hora_atual, $obj_orcamento, $obj_despesas, $id_grupo_default, $id_conta_default;
    function __construct($controller, $parametros = null){
		$this->controller       = $controller;
		$this->data_hora_atual  = $this->controller->data_hora_atual;
        $this->obj_orcamento    = $this->controller->load_model('orcamento/orcamento', true);
        $this->obj_despesas     = $this->controller->load_model('despesas/despesas', true);
        $this->id_grupo_default = json_decode($this->obj_orcamento->getDefault('grupo'));
		$this->id_conta_default = json_decode($this->obj_orcamento->getDefault('conta'));
    }
    
	function getLancamentos($ano_ini, $mes_ini, $mes_fim){
		return $this->obj_orcamento->getLancamentos($ano_ini, $mes_ini, $mes_fim);
	}

    function transferirSaldo($input_origem, $input_destino){
        try {

            //valores de retorno padrão caso não ocorra erros
            $retorno['status']   = 'sucesso';
            $retorno['codigo']   = 0;
            $retorno['mensagem'] = 'Transferencia efetuada com sucesso';

            $param['origem']['ano']      = $input_origem['ano'];
            $param['origem']['tipo']     = $input_origem['tipo'];
            $param['origem']['id_cc']    = $input_origem['id_centro_custo'];
            $param['origem']['operacao'] = 'd';

            if('centro_custo' == $input_origem['origem']){
                $param['origem']['id_grupo'] = $this->id_grupo_default[0]->id;
                $param['origem']['id_conta'] = $this->id_conta_default[0]->id;
            }elseif('grupo' == $input_origem['origem']){
                $param['origem']['id_grupo'] = $input_origem['id_grupo'];
                $param['origem']['id_conta'] = $this->id_conta_default[0]->id;
            }else{
                $param['origem']['id_grupo'] = $input_origem['id_grupo'];
                $param['origem']['id_conta'] = $input_origem['id_conta'];
            }
            
            if(isset($input_origem['meses']) && count($input_origem['meses']) > 0){
                $meses_origem = $input_origem['meses'];
            }else{
                $meses_origem = returnNumeroMes();
			}
			
            $valor_transferencia = removeCaracteres($input_origem['valor'], 'moeda');
            $mod_origem          = restoDivisao($valor_transferencia, count($meses_origem));

            if($mod_origem > 0){
                $valor_transferencia -= $mod_origem;
            }
			
            $valor_mensal_origem = ($valor_transferencia / count($meses_origem));
			
            foreach ($meses_origem as $key => $value) {
                $param['origem']['meses'][$value]['mes'] = $value;
                if($mod_origem > 0){
                    $param['origem']['meses'][$value]['valor_total'] = '-'.($valor_mensal_origem + $mod_origem);
                }else{
                    $param['origem']['meses'][$value]['valor_total'] = '-'.$valor_mensal_origem;
                }
                $mod_origem = 0;
            }
			
            if(isset($param['origem']) && count($param['origem']) > 0){
                if(isset($param['origem']['meses']) && count($param['origem']['meses']) > 0){
                    foreach ($param['origem']['meses'] as $k1 => $v1) {
                        $psave_origem['ano']      = $param['origem']['ano'];
                        $psave_origem['tipo']     = $param['origem']['tipo'];
                        $psave_origem['id_cc']    = $param['origem']['id_cc'];
                        $psave_origem['id_grupo'] = $param['origem']['id_grupo'];
                        $psave_origem['id_conta'] = $param['origem']['id_conta'];
                        $psave_origem['operacao'] = $param['origem']['operacao'];
                        $psave_origem['mes']      = $v1['mes'];
                        $psave_origem['valor']    = $v1['valor_total'];
                        $is_save = $this->obj_orcamento->save($psave_origem);
                        if(!$is_save){
                            $retorno['codigo']      = 1;
                            $retorno['status']      = 'erro';
                            $retorno['tipo']        = 'danger';
                            $retorno['input'][$k1]  = $input_origem;
                            $retorno['output'][$k1] = $param;
                            $retorno['mensagem']    = 'Erro ao debitar saldo';
                        }
                    }
                }else{
                    $retorno['codigo']    = 1;
                    $retorno['status']    = 'erro';
                    $retorno['tipo']      = 'danger';
                    $retorno['input'][0]  = $input_origem;
                    $retorno['output'][0] = $param;
                    $retorno['mensagem']  = 'Meses não informado';
                }
            }else{
                $retorno['codigo']    = 1;
                $retorno['status']    = 'erro';
                $retorno['tipo']      = 'danger';
                $retorno['input'][0]  = $input_origem;
                $retorno['output'][0] = $param;
                $retorno['mensagem']  = 'Erro nos dados de origem';
            }
            
            $param['destino']['ano']      = $input_destino['ano'];
            $param['destino']['tipo']     = $input_destino['tipo'];
            $param['destino']['id_cc']    = $input_destino['id_centro_custo'];
            $param['destino']['operacao'] = 'c';
            
            if('centro_custo' == $input_destino['destino']){
                $param['destino']['id_grupo'] = $this->id_grupo_default[0]->id;
                $param['destino']['id_conta'] = $this->id_conta_default[0]->id;
            }elseif('grupo' == $input_destino['destino']){
                $param['destino']['id_grupo'] = $input_destino['id_grupo'];
                $param['destino']['id_conta'] = $this->id_conta_default[0]->id;
            }else{
                $param['destino']['id_grupo'] = $input_destino['id_grupo'];
                $param['destino']['id_conta'] = $input_destino['id_conta'];
            }
            
            if(isset($input_destino['meses']) && count($input_destino['meses']) > 0){
                $meses_destino = $input_destino['meses'];
            }else{
                $meses_destino = returnNumeroMes();
            }

            $valor_transferencia = removeCaracteres($input_destino['valor'], 'moeda');
            
			$mod_destino = restoDivisao($valor_transferencia, count($meses_destino));
            
            if($mod_destino > 0){
                $valor_transferencia -= $mod_destino;
            }

            $valor_mensal_destino = ($valor_transferencia / count($meses_destino));
            foreach ($meses_destino as $key => $value) {
                $param['destino']['meses'][$value]['mes'] = $value;
                if($mod_destino > 0){
                    $param['destino']['meses'][$value]['valor_total'] = ($valor_mensal_destino + $mod_destino);
                }else{
                    $param['destino']['meses'][$value]['valor_total'] = $valor_mensal_destino;
                }
                $mod_destino = 0;
            }
			
			if(isset($param['destino']) && count($param['destino']) > 0){
                if(isset($param['destino']['meses']) && count($param['destino']['meses']) > 0){
                    foreach ($param['destino']['meses'] as $k1 => $v1) {
                        $psave_destino['ano']      = $param['destino']['ano'];
                        $psave_destino['tipo']     = $param['destino']['tipo'];
                        $psave_destino['id_cc']    = $param['destino']['id_cc'];
                        $psave_destino['id_grupo'] = $param['destino']['id_grupo'];
                        $psave_destino['id_conta'] = $param['destino']['id_conta'];
                        $psave_destino['operacao'] = $param['destino']['operacao'];
                        $psave_destino['mes']      = $v1['mes'];
						$psave_destino['valor']    = $v1['valor_total'];
						
                        $is_save = $this->obj_orcamento->save($psave_destino);
						
						if(!$is_save){
							
							$retorno['codigo']      = 1;
                            $retorno['status']      = 'erro';
                            $retorno['tipo']        = 'danger';
                            $retorno['input'][$k1]  = $input_destino;
                            $retorno['output'][$k1] = $param;
							$retorno['mensagem']    = 'Erro ao creditar saldo';
                        }
                    }
                }else{
                    $retorno['codigo']    = 1;
                    $retorno['status']    = 'erro';
                    $retorno['tipo']      = 'danger';
                    $retorno['input'][0]  = $input_destino;
                    $retorno['output'][0] = $param;
                    $retorno['mensagem']  = 'Meses não informado'; 
                }
            }else{
                $retorno['codigo']    = 1;
                $retorno['status']    = 'erro';
                $retorno['tipo']      = 'danger';
                $retorno['input'][0]  = $input_destino;
                $retorno['output'][0] = $param;
                $retorno['mensagem']  = 'Erro nos dados de destino';
            }
            throw new Exception(json_encode($retorno), 1);
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

	function getSaldo($param){
		
		$retorno = null;

		if($param['meses']){
			$filtro['meses'] = $param['meses'];
		}else{
			for ($i=1; $i <= 12 ; $i++) { 
				$filtro['meses'][$i] = $i;
			}
		}
		
		$filtro['origem']     	   = $param['origem'];
		$filtro['destino']     	   = $param['destino'];
		$filtro['ano']     		   = $param['ano'];
		$filtro['agrupar_por']     = $param['agrupar_por'];
		$filtro['valor']           = $param['valor'];
		$filtro['id_grupo']        = $param['id_grupo'];
		$filtro['id_conta']        = $param['id_conta'];
		$filtro['id_subconta']     = $param['id_subconta'];
		$filtro['id_centro_custo'] = $param['id_centro_custo'];
		$filtro['periodo']         = $param['periodo'];

		foreach ($filtro['meses']  as $key => $value) {
			$filtro['dt_base'] = new DateTime($filtro['ano'].'-'.$value.'-01');
			if($filtro['periodo'] == 'mensal'){
				$retorno[$key]['nome']  = nomeMes($key);
				$retorno[$key]['dados'] = $this->calculaSaldo($filtro);
			}elseif($filtro['periodo'] == 'trimestral'){
				if($value <= 3){
					$retorno[1]['nome']  = '1º Trimestre';
					$retorno[1]['dados'] = $this->calculaSaldo($filtro);
				}elseif($value > 4 && $value <= 6){
					$retorno[2]['nome']  = '2º Trimestre';
					$retorno[2]['dados'] = $this->calculaSaldo($filtro);
				}elseif($value > 6 && $value <= 9){
					$retorno[3]['nome']  = '3º Trimestre';
					$retorno[3]['dados'] = $this->calculaSaldo($filtro);
				}elseif($value > 9 && $value <= 12){
					$retorno[4]['nome']  = '4º Trimestre';
					$retorno[4]['dados'] = $this->calculaSaldo($filtro);
				}
			}elseif($filtro['periodo'] == 'semestral'){
				if($value <= 6){
					$retorno[1]['nome']  = '1º Semestre';
					$retorno[1]['dados'] = $this->calculaSaldo($filtro);
				}elseif($value > 6 && $value <= 12){
					$retorno[2]['nome']  = '2º Semestre';
					$retorno[2]['dados'] = $this->calculaSaldo($filtro);
				}
			}elseif($filtro['periodo'] == 'anual'){
				if($value <= 6){
					$retorno[1]['nome']  = 'Ano '.$filtro['ano'];
					$retorno[1]['dados'] = $this->calculaSaldo($filtro);
				}
			}
		}
		return $retorno;
	}

    function calculaSaldo($param){
		
		$mes = null;
		$ano = $param['dt_base']->format('Y');
		
		$a = false;
		$b = false;
		$c = false;
		$d = false;
		
		if($param['periodo'] == 'mensal'){
			$mes = $param['dt_base']->format('m');
			$dt_ini = clone $param['dt_base'];
			$dt_ini->modify('first day of this month');
			$dt_fim  = clone $param['dt_base'];
			$dt_fim->modify('last day of this month');

			$retorno['mes']    = $mes;
			$retorno['dt_ini'] = $dt_ini;
			$retorno['dt_fim'] = $dt_fim;
			
		}elseif($param['periodo'] == 'trimestral'){
			if($param['dt_base']->format('m') <= 3 ){
				$mes     = array('ini' => 1, 'fim' => 3);
				$dt_ini  = new DateTime($param['dt_base']->format('Y-01-01'));
				$dt_fim  = new DateTime($param['dt_base']->format('Y-03-31'));
			}elseif($param['dt_base']->format('m') > 3 && $param['dt_base']->format('m') <= 6){
				$mes     = array('ini' => 4, 'fim' => 6);
				$dt_ini  = new DateTime($param['dt_base']->format('Y-04-01'));
				$dt_fim  = new DateTime($param['dt_base']->format('Y-06-30'));
			}elseif($param['dt_base']->format('m') > 6 && $param['dt_base']->format('m') <= 9){
				$mes     = array('ini' => 7, 'fim' => 9);
				$dt_ini  = new DateTime($param['dt_base']->format('Y-07-01'));
				$dt_fim  = new DateTime($param['dt_base']->format('Y-09-30'));
			}elseif($param['dt_base']->format('m') > 9 && $param['dt_base']->format('m') <= 12){
				$mes     = array('ini' => 10, 'fim' => 12);
				$dt_ini  = new DateTime($param['dt_base']->format('Y-10-01'));
				$dt_fim  = new DateTime($param['dt_base']->format('Y-12-31'));
			}
		}elseif($param['periodo'] == 'semestral'){
			if($param['dt_base']->format('m') <= 6 ){
				$mes     = array('ini' => 1, 'fim' => 6);
				$dt_ini  = new DateTime($param['dt_base']->format('Y-01-01'));
				$dt_fim  = new DateTime($param['dt_base']->format('Y-06-30'));
			}elseif($param['dt_base']->format('m') > 6 && $param['dt_base']->format('m') <= 12){
				$mes     = array('ini' => 7, 'fim' => 12);
				$dt_ini  = new DateTime($param['dt_base']->format('Y-07-01'));
				$dt_fim  = new DateTime($param['dt_base']->format('Y-12-31'));
			}
		}elseif($param['periodo'] == 'anual'){
			$dt_ini = new DateTime($param['dt_base']->format('Y-01-01'));
			$dt_fim = new DateTime($param['dt_base']->format('Y-12-31'));
		}

		$retorno['input']['dt_base']      = $param['dt_base'];
		$retorno['input']['tipo']         = $param['tipo'];
		$retorno['input']['dt_ini']       = $dt_ini;
		$retorno['input']['dt_fim']       = $dt_fim;
		$retorno['input']['valor']        = number_format($param['valor'], '2', ',','.');

		if($param['agrupar_por'] == 'centro_custo'){
			$a = true;
		}elseif($param['agrupar_por'] == 'grupo'){
			$a = true;
			$b = true;
		}elseif($param['agrupar_por'] == 'conta'){
			$a = true;
			$b = true;
			$c = true;
		}elseif($param['agrupar_por'] == 'subconta'){
			$a = true;
			$b = true;
			$c = true;
			$d = true;
		}
		
		$param['filtro'][0]['view'] = $param['tipo'];
		$param['ano']    = $ano;
		$param['mes']    = $mes;
		$param['dt_ini'] = $dt_ini;
		$param['dt_fim'] = $dt_fim;
		$param['agrupar'][]= 'status';

		if($a && !empty($param['id_centro_custo'])){
			
			$param['agrupar'][]         = 'centro_custo';
			$param['filtro'][0]['nome'] = 'centro_custo';
			$param['filtro'][0]['id']   = $param['id_centro_custo'];
			
			$orc_centro_custo     = json_decode($this->obj_orcamento->getOrcamentoByParametro($param, false));
			$debitos_centro_custo = json_decode($this->obj_despesas->getDespesasParametro($param, $param['tipo'], false));
			
			if($orc_centro_custo){
				$retorno['centro_custo']['orcamento']    = $orc_centro_custo;
			}else{
				$retorno['centro_custo']['orcamento'][0]['centro_custo'] = $param['nome_centro_custo'];
				$retorno['centro_custo']['orcamento'][0]['valor'] = 0;
			}

			$retorno['centro_custo']['saldo']['total']  = $orc_centro_custo[0]->valor;

			if($debitos_centro_custo){
				foreach ($debitos_centro_custo as $key => $value) {
					if('pago' == $value->status){
						$retorno['centro_custo']['debitos']['pago'] = $value;
						$retorno['centro_custo']['saldo']['total']  -= ($value->valor);
					}elseif('aberto' == $value->status && 'aprovado' == $value->status_autorizacao){
						$retorno['centro_custo']['debitos']['aprovado'] = $value;
						$retorno['centro_custo']['saldo']['total']  -= ($value->valor);
					}elseif('aberto' == $value->status && 'pendente' == $value->status_autorizacao){
						$retorno['centro_custo']['debitos']['pendente'] = $value;
					}
				}
			}else{
				$retorno['centro_custo']['debitos']['pago']['valor']     = 0;
				$retorno['centro_custo']['debitos']['aprovado']['valor'] = 0;
				$retorno['centro_custo']['debitos']['pendente']['valor'] = 0;
				$retorno['centro_custo']['saldo']['total']               = 0;
			}
		}

		if($b && !empty($param['id_grupo'])){

			$param['agrupar'][]           = 'grupo';
			$param['filtro'][1]['nome']   = 'grupo';
			$param['filtro'][1]['id']     = $param['id_grupo'];
			
			$orc_grupo     = json_decode($this->obj_orcamento->getOrcamentoByParametro($param, false));
			$debitos_grupo = json_decode($this->obj_despesas->getDespesasParametro($param, $param['tipo'], false));

			if($orc_grupo){
				$retorno['grupo']['orcamento']    = $orc_grupo;
			}else{
				$retorno['grupo']['orcamento'][0]['grupo'] = $param['nome_grupo'];
				$retorno['grupo']['orcamento'][0]['valor'] = 0;
			}
			
			$retorno['grupo']['saldo']['total']  = $orc_grupo[0]->valor;

			if($debitos_grupo){
				foreach ($debitos_grupo as $key => $value) {
					if('pago' == $value->status){
						$retorno['grupo']['debitos']['pago'] = $value;
						$retorno['grupo']['saldo']['total']  -= ($value->valor);
					}elseif('aberto' == $value->status && 'aprovado' == $value->status_autorizacao){
						$retorno['grupo']['debitos']['aprovado'] = $value;
						$retorno['grupo']['saldo']['total']  -= ($value->valor);
					}elseif('aberto' == $value->status && 'pendente' == $value->status_autorizacao){
						$retorno['grupo']['debitos']['pendente'] = $value;
					}
				}
			}else{
				$retorno['grupo']['debitos']['pago'] = 0;
				$retorno['grupo']['debitos']['aprovado'] = 0;
				$retorno['grupo']['debitos']['pendente'] = 0;
			}
		}

		if($c && !empty($param['id_conta'])){
			$param['agrupar'][]         = 'conta';
			$param['filtro'][2]['nome'] = 'conta';
			$param['filtro'][2]['id']   = $param['id_conta'];
			
			$orc_conta   = json_decode($this->obj_orcamento->getOrcamentoByParametro($param, false));
			$debitos_conta = json_decode($this->obj_despesas->getDespesasParametro($param, $param['tipo'], false));
			
			if($orc_conta){
				$retorno['conta']['orcamento']    = $orc_conta;
			}else{
				$retorno['conta']['orcamento'][0]['conta'] = $param['nome_conta'];
				$retorno['conta']['orcamento'][0]['valor'] = 0;
			}
			
			$retorno['conta']['saldo']['total']  = $orc_conta[0]->valor;
			
			if($debitos_conta){
				foreach ($debitos_conta as $key => $value) {
					if('pago' == $value->status){
						$retorno['conta']['debitos']['pago'] = $value;
						$retorno['conta']['saldo']['total']  -= ($value->valor);
					}elseif('aberto' == $value->status && 'aprovado' == $value->status_autorizacao){
						$retorno['conta']['debitos']['aprovado'] = $value;
						$retorno['conta']['saldo']['total']  -= ($value->valor);
					}elseif('aberto' == $value->status && 'pendente' == $value->status_autorizacao){
						$retorno['conta']['debitos']['pendente'] = $value;
					}
				}
			}else{
				$retorno['conta']['debitos']['pago'] = 0;
				$retorno['conta']['debitos']['aprovado'] = 0;
				$retorno['conta']['debitos']['pendente'] = 0;
			}
		}
		
		if($d && !empty($param['id_subconta'])){
			
			$param['agrupar'][]         = 'subconta';
			$param['filtro'][3]['nome'] = 'subconta';
			$param['filtro'][3]['id']   = $param['id_subconta'];
			
			$orc_subconta     = json_decode($this->obj_orcamento->getOrcamentoByParametro($param, false));
			$debitos_subconta = json_decode($this->obj_despesas->getDespesasParametro($param, $param['tipo'], false));

			if($orc_subconta){
				$retorno['subconta']['orcamento']    = $orc_subconta;
			}else{
				$retorno['subconta']['orcamento'][0]['subconta'] = $param['nome_subconta'];
				$retorno['subconta']['orcamento'][0]['valor'] = 0;
			}

			$retorno['subconta']['saldo']['total']  = $orc_conta[0]->valor;

			if($debitos_subconta){
				foreach ($debitos_subconta as $key => $value) {
					if('pago' == $value->status){
						$retorno['subconta']['debitos']['pago'] = $value;
						$retorno['subconta']['saldo']['total']  -= ($value->valor);
					}elseif('aberto' == $value->status && 'aprovado' == $value->status_autorizacao){
						$retorno['subconta']['debitos']['aprovado'] = $value;
						$retorno['subconta']['saldo']['total']  -= ($value->valor);
					}elseif('aberto' == $value->status && 'pendente' == $value->status_autorizacao){
						$retorno['subconta']['debitos']['pendente'] = $value;
					}
				}
			}else{
				$retorno['subconta']['debitos']['pago'] = 0;
				$retorno['subconta']['debitos']['aprovado'] = 0;
				$retorno['subconta']['debitos']['pendente'] = 0;
			}
		}

		$mo = $param['origem'];
		$saldo_final = ($retorno[$mo]['saldo']['total'] - $param['valor']);
		$retorno['saldo_final'] = $saldo_final;
		
		if($saldo_final > 0){
			$retorno['auth_transf'] = true;
		}else{
			$retorno['auth_transf'] = false;
		}
		
		return $retorno;
	}

	//funcao nova
	function getDadosOrcamento($param){
		try {
			$config_orcamento = json_decode($this->controller->config[0]->controle_orcamento);
			if($config_orcamento->nome_controle == 'Orcamento'){
				$ano = 2021;
				$organizar_por    = 'centro_custo';
				$periodo_controle = $config_orcamento->periodo_controle;
				$nivel_controle   = $config_orcamento->nivel_controle;
				$dt_ini           = new DateTime('2021-01-01');
				$dt_fim           = new DateTime('2021-12-31');
				
				if(isset($_POST['tipo']) && is_numeric($_POST['tipo'])){
					$tipo = $_POST['tipo'];
				}else{
					$tipo = null;
				}
				
				if(isset($_POST['centro_custo']) && is_numeric($_POST['centro_custo'])){
					$centro_custo = $_POST['centro_custo'];
				}else{
					$centro_custo = null;
				}
	
				if(isset($_POST['grupo']) && is_numeric($_POST['grupo'])){
					$grupo = $_POST['grupo'];
					$agrupar_por = 'grupo';
				}else{
					$grupo = null;
				}
	
				if(isset($_POST['conta']) && is_numeric($_POST['conta'])){
					$conta = $_POST['conta'];
					$agrupar_por = 'conta';
				}else{
					$conta = null;
				}
	
				if(isset($_POST['sub_conta']) && is_numeric($_POST['sub_conta'])){
					$sub_conta = $_POST['sub_conta'];
					$agrupar_por = 'subconta';
				}else{
					$sub_conta = null;
				}
				
				$orc_lancamentos = json_decode($this->obj_orcamento->getLancamentos($dt_ini->format('Y'), $dt_ini->format('m'), $dt_fim->format('m'), $tipo, $centro_custo, $grupo, $conta, $sub_conta));
				$despesas        = json_decode($this->obj_despesas->getDespesaByOrcamento($dt_ini->format('Y-m-d'), $dt_fim->format('Y-m-d'), $tipo, $centro_custo, $grupo, $conta, $sub_conta));
				
				if($orc_lancamentos){
					foreach ($orc_lancamentos as $key => $value){
						$data_vencimento = new DateTime($value->data_vencimento);
						$i1 = $value->centro_custo;
						$i2 = $value->grupo;
						$i3 = $value->conta;
						$i4 = $value->subconta;
						$i5 = $value->operacao;
						$i6 = nomeMes($value->mes);
						
						$lancamentos['orcamento']['totais']['geral'] += $value->valor;
						switch ($value->operacao) {
							case 'c':
								$lancamentos['orcamento']['totais']['credito'] += $value->valor;
							break;
							case 'd':
								$lancamentos['orcamento']['totais']['debito'] += $value->valor;
							break;
							default:
								$lancamentos['orcamento']['totais']['debito'] += $value->valor;
							break;				
						}
	
						switch ($organizar_por) {
							default: // default centro de custo
								//total anual
								$lancamentos['orcamento']['detalhes'][$i1]['anual']['total'] += $value->valor;
								//total mensal
								$lancamentos['orcamento']['detalhes'][$i1]['mensal'][$i6]     += $value->valor;
								//semestral
								if($i6 <= 6){
									$lancamentos['orcamento']['detalhes'][$i1]['semestral'][1] += $value->valor;
								}else{
									$lancamentos['orcamento']['detalhes'][$i1]['semestral'][2] += $value->valor;
								}
	
								if($i6 <= 3){
									$lancamentos['orcamento']['detalhes'][$i1]['trimestral'][1] += $value->valor;
								}elseif($i6 > 3 && $i6 <= 6 ){
									$lancamentos['orcamento']['detalhes'][$i1]['trimestral'][2] += $value->valor;
								}elseif($i6 > 6 && $i6 <= 9){
									$lancamentos['orcamento']['detalhes'][$i1]['trimestral'][3] += $value->valor;
								}elseif($i6 > 9){
									$lancamentos['orcamento']['detalhes'][$i1]['trimestral'][4] += $value->valor;
								}
							break;
							case 'grupo':
								//total anual
								$lancamentos['orcamento']['detalhes'][$i1][$i2]['anual']['total'] += $value->valor;
								//total mensal
								$lancamentos['orcamento']['detalhes'][$i1][$i2]['mensal'][$i6]     += $value->valor;
								//semestral
								if($i6 <= 6){
									$lancamentos['orcamento']['detalhes'][$i1][$i2]['semestral'][1] += $value->valor;
								}else{
									$lancamentos['orcamento']['detalhes'][$i1][$i2]['semestral'][2] += $value->valor;
								}
	
								if($i6 <= 3){
									$lancamentos['orcamento']['detalhes'][$i1][$i2]['trimestral'][1] += $value->valor;
								}elseif($i6 > 3 && $i6 <= 6 ){
									$lancamentos['orcamento']['detalhes'][$i1][$i2]['trimestral'][2] += $value->valor;
								}elseif($i6 > 6 && $i6 <= 9){
									$lancamentos['orcamento']['detalhes'][$i1][$i2]['trimestral'][3] += $value->valor;
								}elseif($i6 > 9){
									$lancamentos['orcamento']['detalhes'][$i1][$i2]['trimestral'][4] += $value->valor;
								}
							break;
							case 'conta':
								//total anual
								$lancamentos['orcamento']['detalhes'][$i1][$i2][$i3]['anual']['total'] += $value->valor;
								//total mensal
								$lancamentos['orcamento']['detalhes'][$i1][$i2][$i3]['mensal'][$i6]     += $value->valor;
								//semestral
								if($i6 <= 6){
									$lancamentos['orcamento']['detalhes'][$i1][$i2][$i3]['semestral'][1] += $value->valor;
								}else{
									$lancamentos['orcamento']['detalhes'][$i1][$i2][$i3]['semestral'][2] += $value->valor;
								}
	
								if($i6 <= 3){
									$lancamentos['orcamento']['detalhes'][$i1][$i2][$i3]['trimestral'][1] += $value->valor;
								}elseif($i6 > 3 && $i6 <= 6 ){
									$lancamentos['orcamento']['detalhes'][$i1][$i2][$i3]['trimestral'][2] += $value->valor;
								}elseif($i6 > 6 && $i6 <= 9){
									$lancamentos['orcamento']['detalhes'][$i1][$i2][$i3]['trimestral'][3] += $value->valor;
								}elseif($i6 > 9){
									$lancamentos['orcamento']['detalhes'][$i1][$i2][$i3]['trimestral'][4] += $value->valor;
								}
							break;
							case 'subconta':
								//total anual
								$lancamentos['orcamento']['detalhes'][$i1][$i2][$i3][$i4]['anual']['total'] += $value->valor;
								//total mensal
								$lancamentos['orcamento']['detalhes'][$i1][$i2][$i3][$i4]['mensal'][$i6]     += $value->valor;
								//semestral
								if($i6 <= 6){
									$lancamentos['orcamento']['detalhes'][$i1][$i2][$i3][$i4]['semestral'][1] += $value->valor;
								}else{
									$lancamentos['orcamento']['detalhes'][$i1][$i2][$i3][$i4]['semestral'][2] += $value->valor;
								}
	
								if($i6 <= 3){
									$lancamentos['orcamento']['detalhes'][$i1][$i2][$i3][$i4]['trimestral'][1] += $value->valor;
								}elseif($i6 > 3 && $i6 <= 6 ){
									$lancamentos['orcamento']['detalhes'][$i1][$i2][$i3][$i4]['trimestral'][2] += $value->valor;
								}elseif($i6 > 6 && $i6 <= 9){
									$lancamentos['orcamento']['detalhes'][$i1][$i2][$i3][$i4]['trimestral'][3] += $value->valor;
								}elseif($i6 > 9){
									$lancamentos['orcamento']['detalhes'][$i1][$i2][$i3][$i4]['trimestral'][4] += $value->valor;
								}
							break;
						}
					}
				}
				
				if($despesas){
					foreach ($despesas as $key => $value){
						$data_vencimento = new DateTime($value->data_vencimento);
						$i1 = $value->centro_custo;
						$i2 = $value->grupo;
						$i3 = $value->conta;
						$i4 = $value->subconta;
						$i5 = $value->status_autorizacao;
						$i6 = nomeMes($data_vencimento->format('m'));
						
						$lancamentos['despesas']['totais']['geral'] += $value->valor;
						switch ($value->status_autorizacao) {
							case 'aprovado':
								$lancamentos['despesas']['totais']['aprovado'] += $value->valor;
							break;
							case 'pendente':
								$lancamentos['despesas']['totais']['pendente'] += $value->valor;
							break;
							default:
								$lancamentos['despesas']['totais']['pendente'] += $value->valor;
							break;				
						}

						switch ($organizar_por) {
							default: // default centro de custo
								//total anual
								$lancamentos['despesas']['detalhes'][$i1]['anual']['total'] += $value->valor;
								//total mensal
								$lancamentos['despesas']['detalhes'][$i1]['mensal'][$i6]     += $value->valor;
								//semestral
								if($i6 <= 6){
									$lancamentos['despesas']['detalhes'][$i1]['semestral'][1] += $value->valor;
								}else{
									$lancamentos['despesas']['detalhes'][$i1]['semestral'][2] += $value->valor;
								}

								if($i6 <= 3){
									$lancamentos['despesas']['detalhes'][$i1]['trimestral'][1] += $value->valor;
								}elseif($i6 > 3 && $i6 <= 6 ){
									$lancamentos['despesas']['detalhes'][$i1]['trimestral'][2] += $value->valor;
								}elseif($i6 > 6 && $i6 <= 9){
									$lancamentos['despesas']['detalhes'][$i1]['trimestral'][3] += $value->valor;
								}elseif($i6 > 9){
									$lancamentos['despesas']['detalhes'][$i1]['trimestral'][4] += $value->valor;
								}
							break;
							case 'grupo':
								//total anual
								$lancamentos['despesas']['detalhes'][$i1][$i2]['anual']['total'] += $value->valor;
								//total mensal
								$lancamentos['despesas']['detalhes'][$i1][$i2]['mensal'][$i6]     += $value->valor;
								//semestral
								if($i6 <= 6){
									$lancamentos['despesas']['detalhes'][$i1][$i2]['semestral'][1] += $value->valor;
								}else{
									$lancamentos['despesas']['detalhes'][$i1][$i2]['semestral'][2] += $value->valor;
								}

								if($i6 <= 3){
									$lancamentos['despesas']['detalhes'][$i1][$i2]['trimestral'][1] += $value->valor;
								}elseif($i6 > 3 && $i6 <= 6 ){
									$lancamentos['despesas']['detalhes'][$i1][$i2]['trimestral'][2] += $value->valor;
								}elseif($i6 > 6 && $i6 <= 9){
									$lancamentos['despesas']['detalhes'][$i1][$i2]['trimestral'][3] += $value->valor;
								}elseif($i6 > 9){
									$lancamentos['despesas']['detalhes'][$i1][$i2]['trimestral'][4] += $value->valor;
								}
							break;
							case 'conta':
								//total anual
								$lancamentos['despesas']['detalhes'][$i1][$i2][$i3]['anual']['total'] += $value->valor;
								//total mensal
								$lancamentos['despesas']['detalhes'][$i1][$i2][$i3]['mensal'][$i6]     += $value->valor;
								//semestral
								if($i6 <= 6){
									$lancamentos['despesas']['detalhes'][$i1][$i2][$i3]['semestral'][1] += $value->valor;
								}else{
									$lancamentos['despesas']['detalhes'][$i1][$i2][$i3]['semestral'][2] += $value->valor;
								}

								if($i6 <= 3){
									$lancamentos['despesas']['detalhes'][$i1][$i2][$i3]['trimestral'][1] += $value->valor;
								}elseif($i6 > 3 && $i6 <= 6 ){
									$lancamentos['despesas']['detalhes'][$i1][$i2][$i3]['trimestral'][2] += $value->valor;
								}elseif($i6 > 6 && $i6 <= 9){
									$lancamentos['despesas']['detalhes'][$i1][$i2][$i3]['trimestral'][3] += $value->valor;
								}elseif($i6 > 9){
									$lancamentos['despesas']['detalhes'][$i1][$i2][$i3]['trimestral'][4] += $value->valor;
								}
							break;
							case 'subconta':
								//total anual
								$lancamentos['despesas']['detalhes'][$i1][$i2][$i3][$i4]['anual']['total'] += $value->valor;
								//total mensal
								$lancamentos['despesas']['detalhes'][$i1][$i2][$i3][$i4]['mensal'][$i6]     += $value->valor;
								//semestral
								if($i6 <= 6){
									$lancamentos['despesas']['detalhes'][$i1][$i2][$i3][$i4]['semestral'][1] += $value->valor;
								}else{
									$lancamentos['despesas']['detalhes'][$i1][$i2][$i3][$i4]['semestral'][2] += $value->valor;
								}

								if($i6 <= 3){
									$lancamentos['despesas']['detalhes'][$i1][$i2][$i3][$i4]['trimestral'][1] += $value->valor;
								}elseif($i6 > 3 && $i6 <= 6 ){
									$lancamentos['despesas']['detalhes'][$i1][$i2][$i3][$i4]['trimestral'][2] += $value->valor;
								}elseif($i6 > 6 && $i6 <= 9){
									$lancamentos['despesas']['detalhes'][$i1][$i2][$i3][$i4]['trimestral'][3] += $value->valor;
								}elseif($i6 > 9){
									$lancamentos['despesas']['detalhes'][$i1][$i2][$i3][$i4]['trimestral'][4] += $value->valor;
								}
							break;
						}
					}
				}
			}
			$retorno['codigo']   = 0;
			$retorno['input']    = $param;
			$retorno['output']   = $lancamentos;
			$retorno['mensagem'] = 'Sucesso';

			throw new Exception(json_encode($retorno), 1);
			
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}
}
