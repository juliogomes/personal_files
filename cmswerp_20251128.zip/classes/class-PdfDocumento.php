<?php
	class PdfDocumento extends Documento{
		function __construct ($controller){
			parent::__construct($controller);		
		}	

		// DESCONTINUADO 
		function manipularXML(){
			// não se deve usar caminho dessa forma, colocar dentro de uma constante
			$file_pptx = 'C:\Users\caio.freitas\Desktop\tarifador-propostas' . "/slidexml-view.xml";
			$xml = simplexml_load_file($file_pptx);
			$xml2 = simplexml_load_file('C:\Users\caio.freitas\Desktop\tarifador-propostas' . "/testexml.xml");
			$zip = new ZipArchive;
			$zip->open($file_pptx);
		}

		function mergerPDF( $id_proposta, $records, $cnpj_cpf, $modulo_array = array() ){
			include 'config_extras.php';
			include  ABSPATH.DS.'libs'.DS.'pdfmergermaster'.DS.'src'.DS.'PDFMerger'.DS.'PDFMerger.php';
			require_once (ABSPATH.DS.'libs'.DS.'FPDI-master'.DS.'src'.DS.'autoload.php');
			require_once (ABSPATH.DS.'libs'.DS.'FPDF-master'.DS.'fpdf.php');
			$pdf = new \Clegginabox\PDFMerger\PDFMerger;
			if( $records[0]->codigo === "FSP0001"){
				$path = PATH_SLIDE_FULL;
				if( $modulo_array['assessoria_pix'] && $modulo_array['assessoria_str'] && !$modulo_array['boleto'] && !$modulo_array['pix_sinacor'] ){
					$add_slide = "full_assessoria.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 0];
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 0];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 1];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 1];
				}elseif( $modulo_array['assessoria_pix'] && !$modulo_array['assessoria_str'] && !$modulo_array['boleto'] && !$modulo_array['pix_sinacor']  ){
					$add_slide = "full_assessoria_pix.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 1];
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 0];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 1];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 1];
				}elseif( $modulo_array['assessoria_str'] && !$modulo_array['assessoria_pix'] && !$modulo_array['boleto'] && !$modulo_array['pix_sinacor'] ){
					$add_slide = "full_assessoria_str.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 0];
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 1];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 1];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 1];
				}elseif( $modulo_array['boleto'] && $modulo_array['assessoria_pix'] && $modulo_array['assessoria_str'] && !$modulo_array['pix_sinacor']  ){
					$add_slide = "full_boleto_assessoria.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 0];
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 0];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 0];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 1];
				}elseif( $modulo_array['boleto'] && $modulo_array['assessoria_pix'] && !$modulo_array['assessoria_str'] && !$modulo_array['pix_sinacor']  ){
					$add_slide = "full_boleto_assessoria_pix.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 1];
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 0];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 0];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 1];
				}elseif( $modulo_array['boleto'] && !$modulo_array['assessoria_pix'] && $modulo_array['assessoria_str'] && !$modulo_array['pix_sinacor'] ){
					$add_slide = "full_boleto_assessoria_str.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 0];
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 1];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 0];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 1];
				}elseif( $modulo_array['boleto'] && !$modulo_array['assessoria_pix'] && !$modulo_array['assessoria_str'] && !$modulo_array['pix_sinacor']  ){
					$add_slide = "full_boleto_sem_assessoria.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 1];
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 1];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 0];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 1];
				}elseif( !$modulo_array['boleto'] && !$modulo_array['assessoria_pix'] && !$modulo_array['assessoria_str'] && !$modulo_array['pix_sinacor'] ){
					$add_slide = "full_sem_assessoria.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 1];
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 1];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 1];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 1];
				}elseif( !$modulo_array['boleto'] && !$modulo_array['assessoria_pix'] && !$modulo_array['assessoria_str'] && $modulo_array['pix_sinacor']  ){
					$add_slide = "full_sinacor.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 1];
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 1];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 1];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 0];
				}elseif( !$modulo_array['boleto'] && $modulo_array['assessoria_pix'] && $modulo_array['assessoria_str'] && $modulo_array['pix_sinacor']  ){
					$add_slide = "full_sinacor_assessoria.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 0];
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 0];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 1];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 0];
				}elseif( !$modulo_array['boleto'] && $modulo_array['assessoria_pix'] && !$modulo_array['assessoria_str'] && $modulo_array['pix_sinacor']  ){
					$add_slide = "full_sinacor_assessoria_pix.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 1];
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 0];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 1];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 0];
				}elseif( !$modulo_array['boleto'] && !$modulo_array['assessoria_pix'] && $modulo_array['assessoria_str'] && $modulo_array['pix_sinacor']  ){
					$add_slide = "full_sinacor_assessoria_str.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 0];
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 1];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 1];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 0];
				}elseif( $modulo_array['boleto'] && !$modulo_array['assessoria_pix'] && !$modulo_array['assessoria_str'] && $modulo_array['pix_sinacor']  ){
					$add_slide = "full_sinacor_boleto.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 1];
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 1];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 0];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 0];
				}elseif( $modulo_array['boleto'] && $modulo_array['assessoria_pix'] && $modulo_array['assessoria_str'] && $modulo_array['pix_sinacor']  ){
					$add_slide = "full_sinacor_boleto_assessoria.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 0];
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 0];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 0];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 0];
				}elseif( $modulo_array['boleto'] && !$modulo_array['assessoria_pix'] && $modulo_array['assessoria_str'] && $modulo_array['pix_sinacor']  ){
					$add_slide = "full_sinacor_boleto_assessoria_str.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 0];
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 1];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 0];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 0];
				}elseif( $modulo_array['boleto'] && $modulo_array['assessoria_pix'] && !$modulo_array['assessoria_str'] && $modulo_array['pix_sinacor']  ){
					$add_slide = "full_sinacor_boleto_assessoria_pix.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 1];
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 0];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 0];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'FSP0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 0];
				}
			}elseif($records[0]->codigo === "SOE0001"){
				$path = PATH_SLIDE_OBE;
				if( $modulo_array['pix_sinacor'] && $modulo_array['assessoria_str'] && !$modulo_array['boleto'] ){
					$add_slide = "obe-sinacor-str.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 0];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 1];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 0];
				}elseif( $modulo_array['pix_sinacor'] && !$modulo_array['assessoria_str'] && !$modulo_array['boleto']  ){
					$add_slide = "obe-sinacor.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 1];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 1];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 0];
				}elseif( $modulo_array['assessoria_str'] && !$modulo_array['pix_sinacor'] && !$modulo_array['boleto'] ){
					$add_slide = "obe-str.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 0];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 1];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 1];
				}elseif( $modulo_array['boleto'] && $modulo_array['pix_sinacor'] && $modulo_array['assessoria_str']  ){
					$add_slide = "obe-sinacor-boleto-str.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 0];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 0];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 0];
				}elseif( $modulo_array['boleto'] && $modulo_array['pix_sinacor'] && !$modulo_array['assessoria_str']  ){
					$add_slide = "obe-sinacor-boleto.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 1];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 0];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 0];
				}elseif( $modulo_array['boleto'] && !$modulo_array['pix_sinacor'] && $modulo_array['assessoria_str'] ){
					$add_slide = "obe-boleto-str.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 0];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 0];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 1];
				}elseif( $modulo_array['boleto'] && !$modulo_array['pix_sinacor'] && !$modulo_array['assessoria_str']  ){
					$add_slide = "obe-boleto.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 1];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 0];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 1];
				}else{
					$add_slide = "obe.pdf";
					$insert['assessoria_str'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'ASSTR001', 'deleted' => 1];
					$insert['boleto'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'BOHIB001', 'deleted' => 1];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SOE0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 1];
				}
			}elseif($records[0]->codigo === "SPI0001"){
				$path = PATH_SLIDE_SPI_X;
				if( $modulo_array['pix_sinacor'] && !$modulo_array['assessoria_pix'] ){
					$add_slide = "spi-x-sinacor.pdf";
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SPI0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 1];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SPI0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 0];
				}elseif( $modulo_array['pix_sinacor'] && $modulo_array['assessoria_pix'] ){
					$add_slide = "spi-x-sinacor-pix.pdf";
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SPI0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 0];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SPI0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 0];
				}elseif( !$modulo_array['pix_sinacor'] && $modulo_array['assessoria_pix'] ){
					$add_slide = "spi-x-pix.pdf";
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SPI0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 0];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SPI0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 1];
				}else{
					$add_slide = "spi-x.pdf";
					$insert['assessoria_pix'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SPI0001', 'cod_modulo' => 'ASPIX001', 'deleted' => 1];
					$insert['pix_sinacor'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'SPI0001', 'cod_modulo' => 'PIXSI001', 'deleted' => 1];
				}
			}elseif($records[0]->codigo === "ATF0001"){
				$path = PATH_SLIDE_ANTIFRAUDE;
				$add_slide = "antifraude.pdf";
			}elseif($records[0]->codigo === "ECS0001"){
				$path = PATH_SLIDE_ECS;
				$add_slide = "exclusive_collocation_service.pdf";
			}elseif($records[0]->codigo === "CRY0001"){
				$path = PATH_SLIDE_CRYSTAL;
				$add_slide = "crystal.pdf";
			}elseif($records[0]->codigo === "CRY0002"){
				$path = PATH_SLIDE_CRYSTAL;
				$add_slide = "crystal2.pdf";
			}elseif($records[0]->codigo === "CRY0003"){
				$path = PATH_SLIDE_CRYSTAL_BMC;
				$add_slide = "crystal_bmc_apresentacao.pdf";
			}elseif($records[0]->codigo === "CPA0001"){
				$path 	   = PATH_CORNER_INVOICE;
				// $add_slide = "corner_invoice_apresentacao.pdf";
				$add_slide = "corner_invoice_full.pdf";
			}elseif($records[0]->codigo === "RCK0001"){
				$path = PATH_SLIDE_ROCKET;		
				if($modulo_array["engine_workflow"] && !$modulo_array["cvc_onboarding"]){
					$add_slide = "introducao_rocket_engine.pdf";
					$add_slide_corpo = "rocket_engine.pdf";
					$insert['engine_workflow'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'RCK0001', 'cod_modulo' => 'RCKEW001', 'deleted' => 0];
					$insert['cvc_onboarding'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'RCK0001', 'cod_modulo' => 'RCKCO001', 'deleted' => 1];
				}elseif(!$modulo_array["engine_workflow"] && $modulo_array["cvc_onboarding"]){
					$add_slide = "introducao_rocket_cvc_onboarding.pdf";
					$add_slide_corpo = "rocket_cvc_onboarding.pdf";
					$insert['engine_workflow'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'RCK0001', 'cod_modulo' => 'RCKEW001', 'deleted' => 1];
					$insert['cvc_onboarding'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'RCK0001', 'cod_modulo' => 'RCKCO001', 'deleted' => 0];
				}elseif($modulo_array["engine_workflow"] && $modulo_array["cvc_onboarding"]){
					$add_slide = "introducao_rocket_engine.pdf";
					$add_slide_corpo = "rocket_engine.pdf";
					$add_modulo = "modulo_rocket_cvc_onboarding.pdf";
					$insert['engine_workflow'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'RCK0001', 'cod_modulo' => 'RCKEW001', 'deleted' => 0];
					$insert['cvc_onboarding'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'RCK0001', 'cod_modulo' => 'RCKCO001', 'deleted' => 0];
				}else{
					$add_slide = "introducao_rocket_engine.pdf";
					$add_slide_corpo = "rocket_engine.pdf";
					$insert['engine_workflow'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'RCK0001', 'cod_modulo' => 'RCKEW001', 'deleted' => 1];
					$insert['cvc_onboarding'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'RCK0001', 'cod_modulo' => 'RCKCO001', 'deleted' => 1];
				}
				
				if($modulo_array["clc"]){
					$insert['clc'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'RCK0001', 'cod_modulo' => 'RCKCLC01', 'deleted' => 0];
				}else{
					$insert['clc'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'RCK0001', 'cod_modulo' => 'RCKCLC01', 'deleted' => 1];
				}
				
				if($modulo_array["open_banking"]){
					$add_slide = "introducao_rocket_open_banking.pdf";
					$add_slide_corpo = "rocket_open_banking.pdf";
					if($modulo_array['cvc_onboarding']){
						$add_modulo = "modulo_rocket_cvc_onboarding.pdf";
					}
					$insert['open_banking'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'RCK0001', 'cod_modulo' => 'RCKOB001', 'deleted' => 0];
				}else{
					$insert['open_banking'] = [ 'id_propostas' => $id_proposta, 'cod_produto' => 'RCK0001', 'cod_modulo' => 'RCKOB001', 'deleted' => 1];
				}
			}elseif($records[0]->codigo === "TPX0001"){
				$path = PATH_SLIDE_TRIPLOPIX;
				$add_slide = "triplo_pix.pdf";
			}elseif($records[0]->codigo === "YLW0001"){
				$path = PATH_SLIDE_YELLOW;
				$add_slide = "yellow.pdf";
				// $add_slide_condicao = "yellow_condicao_comercial_valores_fixo.pdf";
			}

			if( !$add_slide || empty( $add_slide ) ){
				$retorno['codigo']   = 1;
				$retorno['input']    = $insert;
				$retorno['output']   = $this->modelo->info;
				$retorno['mensagem'] = 'Erro ao encontra PDF';
				throw new Exception (json_encode($retorno), 1);
			}
					
			$this->modelo->setTable('propostas_modulo');
			$modulos_proposta =	json_decode($this->modelo->getPropostasModuloByIdProposta($id_proposta));
			if( isset( $insert ) ){
				if( $modulos_proposta ){
					foreach ($modulos_proposta as $key => $value) {
						if($value->cod_modulo == "ASSTR001"){
							$save = $this->modelo->save($insert['assessoria_str'], $value->id );
						}

						if($value->cod_modulo == "ASPIX001"){
							$save = $this->modelo->save($insert['assessoria_pix'], $value->id );
						}

						if($value->cod_modulo == "BOHIB001"){
							$save = $this->modelo->save($insert['boleto'], $value->id );
						}

						if($value->cod_modulo == "PIXSI001"){
							$save = $this->modelo->save($insert['pix_sinacor'], $value->id);
						}

						if($value->cod_modulo == "RCKEW001"){
							$save = $this->modelo->save($insert['engine_workflow'], $value->id);
						}

						if($value->cod_modulo == "RCKCO001"){
							$save = $this->modelo->save($insert['cvc_onboarding'], $value->id);
						}

						if($value->cod_modulo == "RCKCLC01"){
							$save = $this->modelo->save($insert['clc'], $value->id);
						}

						if($value->cod_modulo == "RCKOB001"){
							$save = $this->modelo->save($insert['open_banking'], $value->id);
						}
					}
				}else{
					foreach ($insert as $key => $value) {
						$save = $this->modelo->save($value);
					}
				}
			}

			try{
				if($save || !isset($insert) ){
					$data_hash = date('YmdHms');
					$this->hoje = date('Y-m-d H:m:s');
					if( !is_dir(PATH_PROPOSTA.$cnpj_cpf) ){
						$mkdir = mkdir(PATH_PROPOSTA.$cnpj_cpf);
					}

					if( !is_dir(PATH_PROPOSTA.$cnpj_cpf.DS."proposta_finalizada") ){
						$mkdir = mkdir(PATH_PROPOSTA.$cnpj_cpf.DS."proposta_finalizada");
					} 

					$ged = json_decode( $this->modelo->gedDocumentoAnexo($id_proposta) );
					if($ged){
						$proposta_comercial = $ged[0]->nome_hash; 
					}else{
						$proposta_comercial = "proposta_comercial_$id_proposta"."_".$data_hash.".pdf";
					}
					
					switch ( $records[0]->codigo ) {
						case 'CRY0001':
						case 'CRY0002':
							$pdf->addPDF($path.$add_slide, 'all')
							->addPDF( PATH_PROPOSTA.$cnpj_cpf.DS.'pdf'.DS."slide_$id_proposta.pdf", 'all' )
							->addPDF($path.'crystal_obrigado.pdf', 'all')
							->merge('file', PATH_PROPOSTA.$cnpj_cpf.DS."proposta_finalizada".DS.$proposta_comercial);
						break;
						case 'CRY0003':
							$pdf->addPDF($path.$add_slide, 'all')
							->addPDF(PATH_PROPOSTA.$cnpj_cpf.DS.'pdf'.DS."slide_$id_proposta.pdf", 'all')
							->addPDF($path.'crystal_bmc_encerramento.pdf', 'all')
							->merge('file', PATH_PROPOSTA.$cnpj_cpf.DS."proposta_finalizada".DS.$proposta_comercial);
						break;
						case 'CPA0001':
							$pdf->addPDF( $path.$add_slide, 'all' )
							//->addPDF( PATH_PROPOSTA.$cnpj_cpf.DS.'pdf'.DS."slide_$id_proposta.pdf", 'all' )
							// ->addPDF( $path.'corner_invoice_precos.pdf', 'all' )
							// ->addPDF( $path.'corner_invoice_encerramento.pdf', 'all' )
							->merge( 'file', PATH_PROPOSTA.$cnpj_cpf.DS."proposta_finalizada".DS.$proposta_comercial );
						break;
						case 'FSP0001':
							$pdf->addPDF(PATH_PROPOSTA.$cnpj_cpf.DS.'pdf'.DS."slide_introducao_$id_proposta.pdf", 'all')
							->addPDF(PATH_SLIDE_FULL_SEM_PAGINA."full.pdf", 'all');
							if( $modulo_array['pix_sinacor'] ){
								$pdf->addPDF(PATH_SLIDE_FULL_SEM_PAGINA."full_sinacor.pdf", 'all');
							}

							if( $modulo_array['boleto'] ){
								$pdf->addPDF(PATH_SLIDE_FULL_SEM_PAGINA."full_boleto.pdf", 'all');
							}

							if( $modulo_array['assessoria_pix'] && !$modulo_array['assessoria_str'] ){
								$pdf->addPDF(PATH_SLIDE_FULL_SEM_PAGINA."full_assessoria_pix.pdf", 'all');
							}

							if( !$modulo_array['assessoria_pix'] && $modulo_array['assessoria_str'] ){
								$pdf->addPDF(PATH_SLIDE_FULL_SEM_PAGINA."full_assessoria_str.pdf", 'all');
							}

							if( $modulo_array['assessoria_pix'] && $modulo_array['assessoria_str'] ){
								$pdf->addPDF(PATH_SLIDE_FULL_SEM_PAGINA."full_assessoria.pdf", 'all');
							}

							if( $modulo_array['ecs'] ){
								$pdf->addPDF(PATH_SLIDE_FULL_SEM_PAGINA."full_ecs.pdf", 'all');
							}
							$pdf->addPDF(PATH_PROPOSTA.$cnpj_cpf.DS.'pdf'.DS."slide_$id_proposta.pdf", 'all')
							->merge('file', PATH_PROPOSTA.$cnpj_cpf.DS."proposta_finalizada".DS.$proposta_comercial );
						break;
						case 'RCK0001':
							$pdf->addPDF($path.$add_slide, 'all');
							// if(isset($add_owner)){
							// 	$pdf->addPDF(PATH_SLIDE_ROCKET_USUARIO.$add_owner, 'all');
							// }
							$pdf->addPDF($path.$add_slide_corpo, 'all');
							if(isset($add_modulo)){
								$pdf->addPDF($path.$add_modulo, 'all');
							}
							$pdf->addPDF($path.'condicao_comercial.pdf', 'all');
							$pdf->addPDF(PATH_PROPOSTA.$cnpj_cpf.DS.'pdf'.DS."slide_$id_proposta.pdf", 'all');
							$pdf->addPDF($path.'obrigado.pdf', 'all')
							->merge('file', PATH_PROPOSTA.$cnpj_cpf.DS."proposta_finalizada".DS.$proposta_comercial);
						break;
						case 'YLW0001':
							$pdf->addPDF($path.$add_slide, 'all')		
							->addPDF($path.'yellow_apenas_condicao_comercial.pdf', 'all')				
							->addPDF(PATH_PROPOSTA.$cnpj_cpf.DS.'pdf'.DS."slide_$id_proposta.pdf", 'all')
							->addPDF($path.'yellow_end.pdf', 'all')
							->merge('file', PATH_PROPOSTA.$cnpj_cpf.DS."proposta_finalizada".DS.$proposta_comercial);
						break;
						default:
							$pdf->addPDF(PATH_PROPOSTA.$cnpj_cpf.DS.'pdf'.DS."slide_introducao_$id_proposta.pdf", 'all')
							->addPDF($path.$add_slide, 'all')
							->addPDF(PATH_PROPOSTA.$cnpj_cpf.DS.'pdf'.DS."slide_$id_proposta.pdf", 'all')
							->merge('file', PATH_PROPOSTA.$cnpj_cpf.DS."proposta_finalizada".DS.$proposta_comercial);
						break;
					}
		
					if( isset( $pdf ) ){
						if($records[0]->propostas_finalizada == "nao"){
							$insert_ged_documento = [ 
								'nome_documento' => 'proposta_comercial_'.$id_proposta.'.pdf',
								'data_documento' => $records[0]->data_criacao,
								'doc_origem' => 'proposta',
								'id_origem' => $records[0]->id, 
								'produto' => $records[0]->id_produto,
								'tipo' => 'proposta',
								'subtipo' => 'proposta',
								'owner' => $records[0]->id_owner,
								'data_criacao' => $this->hoje,
							];

							$this->modelo->setTable('ged_documento');
							if(!$ged){
								$save_ged_documento = $this->modelo->save($insert_ged_documento);
							}else{
								$save_ged_documento = $this->modelo->save($insert_ged_documento, $ged[0]->id_ged_documento);
							}

							if($save_ged_documento){
								$ged_documento = json_decode($this->modelo->gedDocumento($id_proposta));
								$path_documento = PATH_PROPOSTA.$cnpj_cpf.DS."proposta_finalizada".DS.$proposta_comercial;
								$hash_arquivo = hash_file('md5', $path_documento);							
								if(!$ged){
									$insert_ged_anexo = [
										'id_documento' => $ged_documento[0]->id,
										'nome_amigavel' => $ged_documento[0]->nome_documento,
										'path_root' => PATH_PROPOSTA,
										'path_objeto' => $cnpj_cpf.DS.'proposta_finalizada'.DS,
										'nome_hash' => 'proposta_comercial_'.$id_proposta.'_'.$data_hash.".pdf",
										'hash_arquivo' => $hash_arquivo,
										'data_criacao' => $this->hoje,
									];
								}else{
									$insert_ged_anexo = [
										'id_documento' => $ged_documento[0]->id,
										'nome_amigavel' => $ged_documento[0]->nome_documento,
										'path_root' => PATH_PROPOSTA,
										'path_objeto' => DS.$cnpj_cpf.DS.'proposta_finalizada'.DS,
										'nome_hash' => $ged[0]->nome_hash,
										'hash_arquivo' => $hash_arquivo,
										'data_criacao' => $this->hoje,
									];
								}
			
								$this->modelo->setTable('ged_anexo');

								if(!$ged){
									$save_ged_anexo = $this->modelo->save($insert_ged_anexo);
								}else{
									$save_ged_anexo = $this->modelo->save($insert_ged_anexo, $ged[0]->id_ged_anexo);
								}

								if(!$save_ged_anexo){
									$retorno['codigo']   = 1;
									$retorno['input'] = $insert_ged_anexo;
									$retorno['output'] = $save_ged_anexo;
									$retorno['mensagem'] = 'Erro ao salvar no ged_anexo';
									throw new Exception (json_encode($retorno));
								}
							}else{
								$retorno['codigo']   = 1;
								$retorno['input'] = $insert_ged_documento;
								$retorno['output'] = $save_ged_documento;
								$retorno['mensagem'] = 'Erro ao salvar no ged_documento';
								throw new Exception (json_encode($retorno));
							}
						}
				
						$lp_fora_padrao = json_decode( $this->modelo->getLpForaPadrao($id_proposta) );
						$lp_padrao_excluida = json_decode( $this->modelo->getLpPadraoExcluida($id_proposta) );					
						$pacote_fora_padrao = json_decode( $this->modelo->getPacotePropostasEditada($id_proposta) );
						if(isset($pacote_fora_padrao)){
							//FORMATANDO PARA COMPARAÇÃO
							$pacote_fora_padrao[0]->preco_pkt = funcValor($pacote_fora_padrao[0]->preco_pkt, 'C', 0);
							$pacote_fora_padrao[0]->qdt_garantido = funcValor($pacote_fora_padrao[0]->qdt_garantido, 'C', 0);
						}else{
							if(isset($modulo_array["clc"]) && $records[0]->codigo == "RCK0001"){
								$pacote_fora_padrao = json_decode($this->modelo->getPacotePropostas($id_proposta));
							}
						}	
									
						if(isset($pacote_fora_padrao)){
							if($records[0]->codigo == "RCK0001"){
								if(isset($modulo_array["clc"])){
									$pacote_default = json_decode($this->modelo->getPacoteDefault($records[0]->id_produto,83));
									//FORMATANDO PARA COMPARAÇÃO
									$pacote_default[0]->qdt_garantido = funcValor($pacote_default[0]->qdt_garantido, 'C', 0);
									$pacote_default[0]->preco_pkt = funcValor($pacote_default[0]->preco_pkt, 'C', 0);												
									if($pacote_fora_padrao[0]->preco_pkt > $pacote_default[0]->preco_pkt || $pacote_fora_padrao[0]->quantidade_garantido <= $pacote_default[0]->qdt_garantido){
										$fora_padrao = 1;
									}elseif($pacote_fora_padrao[0]->preco_pkt < $pacote_default[0]->preco_pkt || $pacote_fora_padrao[0]->quantidade_garantido < $pacote_default[0]->qdt_garantido){
										$fora_padrao = 2;
									}elseif($pacote_fora_padrao[0]->preco_pkt == $pacote_default[0]->preco_pkt &&  $pacote_fora_padrao[0]->quantidade_garantido == $pacote_default[0]->qdt_garantido){
										$fora_padrao = null;
										$pacote_fora_padrao = null;
									}
								}else{
									$pacote_default = json_decode($this->modelo->getPacoteDefault($records[0]->id_produto,8));
									//FORMATANDO PARA COMPARAÇÃO
									$pacote_default[0]->qdt_garantido = funcValor($pacote_default[0]->qdt_garantido, 'C', 0);
									$pacote_default[0]->preco_pkt = funcValor($pacote_default[0]->preco_pkt, 'C', 0);
									if($pacote_fora_padrao[0]->preco_pkt > $pacote_default[0]->preco_pkt && $pacote_fora_padrao[0]->quantidade_garantido <= $pacote_default[0]->qdt_garantido){
										$fora_padrao = 1;
									}elseif($pacote_fora_padrao[0]->preco_pkt < $pacote_default[0]->preco_pkt || $pacote_fora_padrao[0]->quantidade_garantido < $pacote_default[0]->qdt_garantido){
										$fora_padrao = 2;	
									}elseif($pacote_fora_padrao[0]->preco_pkt == $pacote_default[0]->preco_pkt &&  $pacote_fora_padrao[0]->quantidade_garantido == $pacote_default[0]->qdt_garantido){
										$fora_padrao = null;
										$pacote_fora_padrao = null;
									}
								}							
							}elseif($records[0]->codigo == "SOE0001"){
								$pacote_default[0]->descricao = $VAR_SYSTEM['TEXTO_SLIDE']['SPB/X OBE']['DESCRICAO'];
								$pacote_default[0]->qdt_garantido = $VAR_SYSTEM['TEXTO_SLIDE']['SPB/X OBE']['QUANTIDADE_GARANTIDA'];
								$pacote_default[0]->preco_pkt = $VAR_SYSTEM['TEXTO_SLIDE']['SPB/X OBE']['FATURAMENTO_MINIMO'];
								//FORMATANDO PARA COMPARAÇÃO
								$pacote_default[0]->qdt_garantido = funcValor($pacote_default[0]->qdt_garantido, 'C', 0);
								$pacote_default[0]->preco_pkt = funcValor($pacote_default[0]->preco_pkt, 'C', 0);							
								
								if($pacote_fora_padrao[0]->preco_pkt > $pacote_default[0]->preco_pkt && $pacote_fora_padrao[0]->quantidade_garantido <= $pacote_default[0]->qdt_garantido){
									$fora_padrao = 1;
								}elseif($pacote_fora_padrao[0]->preco_pkt < $pacote_default[0]->preco_pkt || $pacote_fora_padrao[0]->quantidade_garantido < $pacote_default[0]->qdt_garantido){
									$fora_padrao = 2;	
								}elseif($pacote_fora_padrao[0]->preco_pkt == $pacote_default[0]->preco_pkt &&  $pacote_fora_padrao[0]->quantidade_garantido == $pacote_default[0]->qdt_garantido){
									$fora_padrao = null;
									$pacote_fora_padrao = null;
								}
							}elseif($records[0]->codigo == "ECS0001"){
								$pacote_default = json_decode($this->modelo->getLpByCodigo(null,"ECS0011"));
								$pacote_default[0]->qdt_garantido = funcValor($pacote_default[0]->qdt_garantido, 'C', 0);
								$pacote_default[0]->preco_pkt = funcValor($pacote_default[0]->preco_pkt, 'C', 0);

								if($pacote_fora_padrao[0]->preco_pkt > $pacote_default[0]->preco_pkt && $pacote_fora_padrao[0]->quantidade_garantido <= $pacote_default[0]->qdt_garantido){
									$fora_padrao = 1;
								}elseif($pacote_fora_padrao[0]->preco_pkt < $pacote_default[0]->preco_pkt || $pacote_fora_padrao[0]->quantidade_garantido < $pacote_default[0]->qdt_garantido){
									$fora_padrao = 2;	
								}elseif($pacote_fora_padrao[0]->preco_pkt == $pacote_default[0]->preco_pkt &&  $pacote_fora_padrao[0]->quantidade_garantido == $pacote_default[0]->qdt_garantido){
									$fora_padrao = null;
									$pacote_fora_padrao = null;
								}
								
							}					
						}
						
						$implantacao = funcValor($records[0]->valor_implantacao, 'C', 0);
						if( $records[0]->codigo == "SPI0001"){
							$codigo = "SPI0023";
							$get_implantacao = json_decode($this->modelo->getLpByCodigo(null,$codigo));
							$implantacao_padrao = funcValor($get_implantacao[0]->valor_real,'C',0);	
																	
							if($implantacao > $implantacao_padrao){
								$implantacao_fora_padrao = 1;
							}elseif($implantacao < $implantacao_padrao){							
								$implantacao_fora_padrao = 2;
							}elseif($implantacao == $implantacao_padrao){
								$implantacao_fora_padrao = null;
							}
						//AQUI COMPARO IMPLANTAÇÃO 
						}elseif($records[0]->codigo == "FSP0001"){
							$codigo = "STR0000";
							$get_implantacao = json_decode($this->modelo->getLpByCodigo(null,$codigo));
							$implantacao_padrao = funcValor($get_implantacao[0]->valor_real,'C',0);	
													
							if($implantacao > $implantacao_padrao){
								$implantacao_fora_padrao = 1;
							}elseif($implantacao < $implantacao_padrao){
								$implantacao_fora_padrao = 2;
							}elseif($implantacao == $implantacao_padrao){
								$implantacao_fora_padrao = null;
							}
						}elseif($records[0]->codigo == "ATF0001"){
							$codigo = "ATF0013";
							$get_implantacao = json_decode($this->modelo->getLpByCodigo(null,$codigo));
							$implantacao_padrao = funcValor($get_implantacao[0]->valor_real,'C',0);

													
							if($implantacao > $implantacao_padrao){
								$implantacao_fora_padrao = 1;
							}elseif($implantacao < $implantacao_padrao){
								$implantacao_fora_padrao = 2;
							}elseif($implantacao == $implantacao_padrao){
								$implantacao_fora_padrao = null;
							}					
						}elseif($records[0]->codigo == "SOE0001"){
							$codigo = "SOE0012";
							$get_implantacao = json_decode($this->modelo->getLpByCodigo(null,$codigo));
							$implantacao_padrao = funcValor($get_implantacao[0]->valor_real,'C',0);						
													
							if($implantacao > $implantacao_padrao){
								$implantacao_fora_padrao = 1;
							}elseif($implantacao < $implantacao_padrao){
								$implantacao_fora_padrao = 2;
							}elseif($implantacao == $implantacao_padrao){
								$implantacao_fora_padrao = null;
							}
						}elseif($records[0]->codigo == "CRY0001"){
							$codigo = "CRY0010";
							$get_implantacao = json_decode($this->modelo->getLpByCodigo(null,$codigo));
							$implantacao_padrao = funcValor($get_implantacao[0]->valor_real,'C',0);					
							if($implantacao > $implantacao_padrao){
								$implantacao_fora_padrao = 1;
							}elseif($implantacao < $implantacao_padrao){
								$implantacao_fora_padrao = 2;
							}elseif($implantacao == $implantacao_padrao){
								$implantacao_fora_padrao = null;
							}						
						}elseif($records[0]->codigo == "ECS0001"){
							$codigo = "ECS0010";
							$get_implantacao = json_decode($this->modelo->getLpByCodigo(null,$codigo));
							$implantacao_padrao = funcValor($get_implantacao[0]->valor_real,'C',0);													
						
							if($implantacao > $implantacao_padrao){
								$implantacao_fora_padrao = 1;
							}elseif($implantacao < $implantacao_padrao){
								$implantacao_fora_padrao = 2;
							}elseif($implantacao == $implantacao_padrao){
								$implantacao_fora_padrao = null;
							}
						}else if($records[0]->codigo == "RCK0001"){
							if(isset($modulo_array["clc"])){
								$codigo = "RCK0068";
								$get_implantacao = json_decode($this->modelo->getLpByCodigo(null,$codigo));
								$implantacao_padrao = funcValor($get_implantacao[0]->valor_real,'C',0);
																						
								if($implantacao > $implantacao_padrao){
									$implantacao_fora_padrao = 1;
								}elseif($implantacao < $implantacao_padrao){
									$implantacao_fora_padrao = 2;
								}elseif($implantacao == $implantacao_padrao){
									$implantacao_fora_padrao = null;
								}
							}else{
								$codigo = "RCK0033";
								$get_implantacao = json_decode($this->modelo->getLpByCodigo(null,$codigo));
								$implantacao_padrao = funcValor($get_implantacao[0]->valor_real,'C',0);				
																						
								if($implantacao > $implantacao_padrao){
									$implantacao_fora_padrao = 1;
								}elseif($implantacao < $implantacao_padrao){
									$implantacao_fora_padrao = 2;
								}elseif($implantacao == $implantacao_padrao){
									$implantacao_fora_padrao = null;
								}							
							}
						}else if($records[0]->codigo == "TPX0001"){
							$codigo = "TPX0010";
							$get_implantacao = json_decode($this->modelo->getLpByCodigo(null,$codigo));
							$implantacao_padrao = funcValor($get_implantacao[0]->valor_real,'C',0);					
													
							if($implantacao > $implantacao_padrao){
								$implantacao_fora_padrao = 1;
							}elseif($implantacao < $implantacao_padrao){
								$implantacao_fora_padrao = 2;
							}elseif($implantacao == $implantacao_padrao){
								$implantacao_fora_padrao = null;
							}					
						}else if($records[0]->codigo == "YLW0001"){
							$codigo = "YLW0010";
							$get_implantacao = json_decode($this->modelo->getLpByCodigo(null,$codigo));
							$implantacao_padrao = funcValor($get_implantacao[0]->valor_real,'C',0);					
													
							if($implantacao > $implantacao_padrao){
								$implantacao_fora_padrao = 1;
							}elseif($implantacao < $implantacao_padrao){
								$implantacao_fora_padrao = 2;
							}elseif($implantacao == $implantacao_padrao){
								$implantacao_fora_padrao = null;
							}					
						}else{
							$implantacao_fora_padrao = null;
						}
					
						$this->modelo->setTable('propostas');
						if($lp_fora_padrao || $pacote_fora_padrao || $implantacao_fora_padrao || $lp_padrao_excluida){						
							if($records[0]->proposta_fora_padrao == 0 && $records[0]->propostas_finalizada == "sim"){							
								$parametros[0] = "id_propostas";
								$parametros[1] = $records[0]->id; 
								$parametros[2] = "mergepdf";
								$this->enviarEmail($parametros);
							}

							if($implantacao_fora_padrao == 2 || $fora_padrao == 2){
								$insert_proposta['proposta_fora_padrao'] = 2;
							}elseif($implantacao_fora_padrao == 1 || $fora_padrao == 1){
								$insert_proposta['proposta_fora_padrao'] = 1;
							}
							$this->modelo->save($insert_proposta, $id_proposta);
						}else{
							$insert_proposta['proposta_fora_padrao'] = 0;
							$this->modelo->save($insert_proposta, $id_proposta);
						}

						$retorno['codigo']   = 0;
						$retorno['mensagem'] = 'Sucesso';
						$retorno['input'] = $records[0]->id_produto;
						$retorno['output'] = $id_proposta;
						throw new Exception (json_encode($retorno));
					}														
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $insert;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Erro ao gravar modulos';
					throw new Exception (json_encode($retorno), 1);
				}
			}catch(Exception $e){
				echo $e->getMessage();
			}
		}
	}