<?php

/**
 * Julio
 * Classe para log de eventos no sistema
 */
class Permissoes extends Main
{
    private
        $permissoes,
        $permissoes_extras,
        $config_model,
        $perfil_model;
    public
        // variaveis para metodos temporarios que irão ser replicados a todos os metodos
        $erro_permissao,
        $is_master,
        $nivel_acesso,
        $alcada_acesso,
        $permissao_acesso;

    function __construct($controller, $param = null)
    {
        parent::__construct($controller);
        $this->config_model = $this->controller->load_model('configuracoes/configuracoes', true);
        $this->perfil_model = $this->controller->load_model('perfis/perfis', true);
        $this->setPermissoesExtras();
    }

    function getPermissoes()
    {
        return $this->permissoes;
    }

    function getPermissoesExtras()
    {
        return $this->permissoes_extras;
    }

    function setPermissoes($json_permissoes)
    {
        if ($json_permissoes) {
            $this->permissoes = json_decode($json_permissoes);
        }
        return $this;
    }

    function setPermissoesExtras()
    {
        $this->permissoes_extras = json_decode($this->config_model->getConfiguracoes());
    }

    function checkPermissoes($modulo, $tipo_permissao = 'modulo', $nivel_acesso = null)
    {
        try {
            if ($_SESSION['cmswerp']['userdata']->master) {
                $this->nivel_acesso  = 4;
                $retorno['codigo']   = 0;
                $retorno['input']    = $modulo;
                $retorno['output']   = 'master';
                $retorno['mensagem'] = "Sucesso";
                throw new Exception(json_encode($retorno), 1);
            }

            if ($this->permissoes) {
                if (!$modulo) {
                    $modulo = $this->controller->getModulo();
                }

                if (!$nivel_acesso) {
                    $nivel_acesso = '1'; // 1 - view, 2 - edit, 3 - edita e aprova;
                }

                switch ($tipo_permissao) {
                    case 'metodo':
                        $retorno = null;
                        foreach ($this->permissoes->modulos as $key => $value) {
                            foreach ($value as $k1 => $v1) {
                                if (strtolower($v1->link) == strtolower($modulo)) {
                                    $retorno['codigo']   = 0;
                                    $retorno['input']    = $modulo;
                                    $retorno['output']   = $v1;
                                    $retorno['mensagem'] = "Sucesso";
                                    throw new Exception(json_encode($retorno), 1);
                                }
                            }
                        }
                        throw new Exception(json_encode($retorno), 1);
                        break;
                    default: // modulo por padrão
                        if (!isset($this->permissoes->modulos)) {
                            $retorno['codigo']   = 102;
                            $retorno['input']    = $modulo;
                            $retorno['output']   = $modulo;
                            $retorno['mensagem'] = "Permições para modulos não definida";
                            throw new Exception(json_encode($retorno), 1);
                        }

                        $pmodulo = null;
                        foreach ($this->permissoes->modulos as $key => $value) {
                            foreach ($value as $k1 => $v1) {
                                if ($v1->controller == $modulo) {
                                    $pmodulo = $v1;
                                    $this->nivel_acesso = $v1->permissoes;
                                }
                            }
                        }

                        if ($this->nivel_acesso >= $nivel_acesso) {
                            $retorno['codigo']   = 0;
                            $retorno['input']    = $modulo;
                            $retorno['output']   = $pmodulo;
                            $retorno['mensagem'] = "Sucesso";
                            throw new Exception(json_encode($retorno), 1);
                        } else {
                            $retorno['codigo']   = 104;
                            $retorno['input']    = $modulo;
                            $retorno['output']   = $pmodulo;
                            $retorno['mensagem'] = "Tipo de permissão inválida ";
                            throw new Exception(json_encode($retorno), 1);
                        }
                        break;
                }
            } else {
                $retorno['codigo']   = 101;
                $retorno['input']    = null;
                $retorno['output']   = null;
                $retorno['mensagem'] = 'Permissões não encontradas COD: 120';
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            $chk = json_decode($e->getMessage());
            if ($chk->codigo != 0) {
                echo json_encode($chk);
                exit;
            } else {
                return $e->getMessage();
            }
        }
    }

    function checkPermissoesExtras($modulo, $id_usuario, $force = false)
    {
        switch ($modulo) {
            case 'despesas':
                if (isset($this->permissoes_extras[0])) {
                    $controle_orcamento = json_decode($this->permissoes_extras[0]->controle_orcamento);
                    if (isset($controle_orcamento->aprovadores)) {
                        foreach ($controle_orcamento->aprovadores as $key => $value) {
                            if ($value == $id_usuario) {
                                return true;
                            }
                        }
                    } else {
                        return false;
                    }
                }
                break;
        }
        return false;
    }

    function checkPermissaoByUsuario($id_usuario, $modulo, $metodo = null)
    {
        $perfil = json_decode($this->perfil_model->getPerfilByUserId($id_usuario));
        if (isset($perfil[0]->permissoes)) {
            $permissoes = json_decode($perfil[0]->permissoes);
            if ($permissoes) {
                foreach ($this->permissoes->modulos as $key => $value) {
                    foreach ($value as $k1 => $v1) {
                        if ($v1->controller == $modulo && $v1->link == $metodo) {
                            return $v1->permissoes;
                        }
                    }
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
        return false;
    }

    function getNivelAcesso()
    {
        return $this->nivel_acesso;
    }

    // variaveis para metodos temporarios que irão ser replicados a todos os metodos
    function verificarPermissao($modulo = null)
    {
        if (!$modulo) {
            $modulo = $this->controller->getModulo();
        }

        $check = json_decode($this->checkPermissoes($modulo));
        if ($check->codigo == 0) {
            if (isset($check->output) && $check->output == 'master') {
                $this->is_master = true;
                $this->alcada_acesso    = 4;
                $this->permissao_acesso = 4;
                return true;
            } else {
                $this->is_master = false;
                if ($check->output->controller == $modulo) {
                    $this->alcada_acesso    = $check->output->alcadas;
                    $this->permissao_acesso = $check->output->permissoes;
                    return true;
                } else {
                    $this->stopExec();
                }
            }
        } else {
            $this->stopExec();
        }
    }

    function stopExec()
    {
        echo 'Sem permissão de acesso COD: 204';
        exit;
    }
}
