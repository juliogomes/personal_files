<?php
class Registry
{
    protected $services = [];

    public function set($name, $service)
    {
        $this->services[$name] = $service;
    }

    public function get($name)
    {
        if (!isset($this->services[$name])) {
            throw new Exception("Serviço '$name' não encontrado no registry.");
        }
        return $this->services[$name];
    }
}
