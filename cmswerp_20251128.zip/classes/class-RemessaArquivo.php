<?php

    class RemessaArquivo extends ClienteContaBancaria{
    	const QUEBRA_LINHA = "\r\n";
    	protected $codigo_remessa, $obj_boleto, $seq_remessa, $qtd_registros, $tipo_arquivo, $ext_arquivo, $path_arquivo, $modalidade, $nome_arquivo , $string, $linhas_arquivo, $qtde_lotes;
    	function __construct($controller, $cliente = null){
    		require_once 'libs/codigo_barras/boletosPHP.php';
    		$this->obj_boleto = new boletosPHP();
    		$this->path_arquivo = REMESSAS_ABSPATH;
    		if(is_array($cliente)){
    			$cliente = convertToObject($cliente);
    		}
    		parent::__construct($controller, $cliente);
    		if($cliente){
    			$this->ConfigurarRemessa($cliente);
    		}
    	}
    
    	function ConfigurarRemessa($dados){
    		$dir_default = $dados->dir_default.DS;
    		if(isset($dados->tipo_arquivo) && !empty($dados->tipo_arquivo)){
    			$this->setTipoArquivo($dados->tipo_arquivo);
    			if($this->getTipoArquivo() == 'retorno'){
    				$this->setExtArquivo('RET');
    			}else{
    				$this->setExtArquivo('REM');
    			}
    		}else{
    			$this->setTipoArquivo('remessa');
    			$this->setExtArquivo('REM');
    		}
    		
    		if(isset($dados->dir_default) && !empty($dados->dir_default)){
    			$this->setPathArquivo($dados->dir_default);
    		}
    
    		if(isset($dados->modalidade) && !empty($dados->modalidade)){	
    			$this->setModalidade($dados->modalidade);
    		}else{
    			$this->setModalidade('pagamento');
    		}
    
    		if(isset($dados->cnab) && !empty($dados->cnab)){
    			$this->setCnab($dados->cnab);
    		}else{
    			$this->setCnab(CNAB_DEFAULT);
    		}
    
    		$this->setCodigoRemessa(null); // forçar nulo no codigo da remessa, será populado após salvar os dados na base
    		$ultima_remessa = null;
    		$ultima_remessa = json_decode($this->arquivo_model->getLastRemessaByConvenio($dados->codigo_convenio, $dados->tipo_arquivo, $dados->modalidade));
    		
    		
    		if($ultima_remessa){
    			$this->setCodigoRemessa(($ultima_remessa[0]->codigo_arquivo + 1));
    		}else{
    			$this->setCodigoRemessa(1);
    		}
    
    		if($ultima_remessa && $ultima_remessa[0]->data_gravacao == $this->data_atual->format('Y-m-d')){
    			$this->setSeqRemessa( ($ultima_remessa[0]->num_seq_remessa + 1) );
    		}else{
    			$this->setSeqRemessa(1);
    		}
    		return $this;
    	}
    
    	function setMapaArquivo($mapa, $header = true){
    		// $this->linhas_arquivo++;
    		if($mapa){
    			if($header){
    				$this->mapa_arquivo['header'] = convertToObject($mapa);
    			}else{
    				$this->mapa_arquivo['trailer'] = convertToObject($mapa);
    			}
    		}
    		return $this;
    	}
    	
    	function setCnab($cnab = null){
    		$this->cnab = $cnab;
    	}
    
    	function getCnab(){
    		return $this->cnab;
    	}
    
    	function setTipoArquivo($tipo_arquivo = null){
    		$this->tipo_arquivo = $tipo_arquivo;
    	}
    
    	function getTipoArquivo(){
    		return $this->tipo_arquivo;
    	}
    
    	function setModalidade($modalidade = null){
    		$this->modalidade = $modalidade;
    	}
    
    	function getModalidade(){
    		return $this->modalidade;
    	}
    	
    	function setCodigoRemessa($codigo_remessa){
    		$this->codigo_remessa = $codigo_remessa;
    	}
    
    	function getCodigoRemessa(){
    		return $this->codigo_remessa;
    	}
    
    	function setSeqRemessa($seq_remessa){
    		$this->seq_remessa = $seq_remessa;
    	}
    
    	function getSeqRemessa(){
    		return $this->seq_remessa;
    	}
    
    	function setPathArquivo($path_arquivo = null){
    		$this->path_arquivo .= $path_arquivo.DS;
    	}
    
    	function getpathArquivo(){
    		return $this->path_arquivo;
    	}
    
    	function setExtArquivo($ext_arquivo = null){
    		if($ext_arquivo){
    			$this->ext_arquivo = $ext_arquivo;
    		}
    	}
    
    	function getExtArquivo(){
    		return $this->ext_arquivo;
    	}
    	
    	function setQtdeLotes($qtde_lotes = null){
    		if($qtde_lotes){
    			$this->qtde_lotes = $qtde_lotes;
    		}
    	}
    
    	function getQtdeLotes(){
    		return $this->qtde_lotes;
    	}
    
    	function setLinhasArquivo($linhas_arquivo = null){
    		if($linhas_arquivo){
    			$this->linhas_arquivo = $linhas_arquivo;
    		}
    	}
    
    	function getLinhasArquivo(){
    		return $this->linhas_arquivo;
    	}
    
    	function getNomeArquivo(){
    		return $this->nome_arquivo;
    	}
    
    	function setNomeArquivo($nome_arquivo = null){
    		
    		if($nome_arquivo){
    			$this->nome_arquivo = $nome_arquivo;
    		}elseif($this->getNomeArquivo()){
    			$this->nome_arquivo = $this->getNomeArquivo();
    		}else{
    			$this->nome_arquivo = 'banco_'.strtolower($this->codigo_banco).'_'.$this->data_atual->format('YmdHis').'.'.$this->getExtArquivo();
    		}
    	}
    
    	function CriarArquivo($nome_arquivo = null){
    		// $this->setLinhasArquivo(2);
    		$fp = null;
    		
    		if($nome_arquivo){
    			$this->setNomeArquivo($nome_arquivo);
    		}
    		if(!file_exists($this->path_arquivo.$this->getNomeArquivo())){
    			$this->fp = fopen($this->path_arquivo.$this->getNomeArquivo(), 'x');
    			return $this;
    		}else{
    			return false;
    		}
    	}
    
    	function popularArquivo($text = null){
    		$fp = fopen($this->getpathArquivo().$this->getNomeArquivo(), 'w');
    		fwrite($fp, $this->string);
    		fclose($fp);
    	}
    	
    	function saveBD($modulo){
    		if($modulo){
    			switch ($modulo) {
    				case 'remessa':
    					$param['codigo_arquivo']   = $this->codigo_remessa;
    					$param['num_seq_remessa']  = $this->seq_remessa;
    					$param['nome_arquivo']     = $this->getNomeArquivo();
    					$param['cnab']             = $this->cnab;
    					$param['tipo_arquivo']     = $this->getTipoArquivo();
    					$param['modalidade']       = $this->modalidade;
    					$param['tipo_inscricao']   = $this->tipo_pessoa;
    					$param['numero_inscricao'] = $this->cnpj_cpf;
    					$param['codigo_empresa']   = null;
    					$param['nome_empresa']     = $this->nome_cliente;
    					$param['codigo_banco']     = $this->codigo_banco;
    					$param['codigo_convenio']  = $this->codigo_convenio;
    					$param['agencia']          = $this->agencia;
    					$param['conta']            = $this->conta;
    					$param['conta_dv']         = $this->conta_dig;
    					$param['nome_banco']       = $this->nome_banco;
    					$param['data_gravacao']    = $this->data_atual->format('Y-m-d');
    					$param['hora_gravacao'] = $this->data_atual->format('H:i:s');
    					$save_remessa = $this->arquivo_model->save($param);
    					if($save_remessa){
    						$this->setCodigoRemessa($save_remessa);
    						return $this;
    					}else{
    						return false;
    					}
    				break;
    				case 'lote':
    					$param['codigo_arquivo'] = $this->codigo_remessa;
    					$param['codigo_lote']    = $this->codigo_lote;
    					$param['tipo_lote']      = $this->tipo_lote; 
    					$this->boleto_model->setTable('remessa_lote');
    					if($this->boleto_model->save($param)){
    						return $this;
    					}else{
    						return false;
    					}
    				break;
    				case 'detalhe':
    					$param['num_seq']        = $this->getSeqDetalhe();
    					$param['id_lote']        = $this->getCodigoLote();
    					$param['id_remessa']     = $this->getCodigoRemessa();
    					$param['id_despesa']     = $this->getNumeroDocumento();
    					$param['tipo_cobranca']  = $this->getTipoPagamento();
    					$this->boleto_model->setTable('remessa_detalhe');
    					if($this->boleto_model->save($param)){
    						return $this;
    					}else{
    						return false;
    					}
    				break;
    				default:
    					# code...
    				break;
    			}
    			return $this;
    		}else{
    			return false;
    		}
    	}
    }