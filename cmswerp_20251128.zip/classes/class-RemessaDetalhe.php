<?php
    abstract class RemessaDetalhe extends RemessaLote{
    	protected $detalhe, $numero_documento, $seq_detalhe, $mapa_detalhe, $linhas_detalhe, $codigo_camara;
    	function __construct($controller, $cliente){
    		if(is_array($cliente)){
    			$cliente = convertToObject($cliente);
    		}
    		parent::__construct($controller, $cliente);
    		$this->setBanco($cliente);
    		$this->setBanco($cliente);
    	}
    
    	function getDetalhe(){
    		return $this;
    	}
    
    	function setDetalhe($dados){
    		if(is_array($dados)){
    			$dados = convertToObject($dados);
    		}
    		$this->detalhe = $dados;
    		return $this;
    	}
    
    	function setString($string){
    		$this->string .= $string.RemessaArquivo::QUEBRA_LINHA;
    	}
    
    	function getString(){
    		return $this->string;
    	}
    
    	function setSeqDetalhe($seq_detalhe){
    		$this->seq_detalhe = $seq_detalhe;
    	}
    
    	function getSeqDetalhe(){
    		return $this->seq_detalhe;
    	}
    
    	function setCodigoCamara($codigo_camara){
    		$this->codigo_camara = $codigo_camara;
    	}
    
    	function getCodigoCamara(){
    		return $this->codigo_camara;
    	}
    
    	function setNumeroDocumento($numero_documento){
    		$this->numero_documento = $numero_documento;
    	}
    
    	function getNumeroDocumento(){
    		return $this->numero_documento;
    	}
    
    	function setLinhasDetalhe($linhas_detalhe){
    		$this->linhas_detalhe = $linhas_detalhe;
    	}
    
    	function getLinhasDetalhe(){
    		return $this->linhas_detalhe;
    	}
    
    	function buitString($modulo, $header = true){
    		switch ($modulo){
    			case 'arquivo':
    				if($header){
    					if($this->mapa_arquivo['header']){
    						// echo 'gravando linha arquivo header <br>';
    						$this->writeString($this->mapa_arquivo['header'], 'arquivo');
    					}else{
    						$this->error = true;
    					}
    				}else{
    					if($this->mapa_arquivo['trailer']){
    						// echo 'gravando linha arquivo trailer <br>';
    						$this->writeString($this->mapa_arquivo['trailer'], 'arquivo');	
    					}else{
    						$this->error = true;
    					}
    				}
    			break;
    			case 'lote':
    				if($header){
    					if($this->mapa_lote['header']){
    						// echo 'gravando linha lote header <br>';
    						$this->writeString($this->mapa_lote['header'], 'lote');
    					}else{
    						$this->error = true;
    					}
    				}else{
    					if($this->mapa_lote['trailer']){
    						// echo 'gravando linha lote trailer <br>';
    						$this->writeString($this->mapa_lote['trailer'],'lote');	
    					}else{
    						$this->error = true;
    					}
    				}
    			break;
    			case 'detalhe':
    				if($this->mapa_detalhe){
    					foreach($this->mapa_detalhe as $key => $value){
    						// echo 'gravando linha detalhe <br>';
    						$this->writeString($value, 'detalhe');
    					}
    				}else{
    					$this->error = true;
    				}
    			break;
    			default:
    				# code...
    			break;
    		}
    		return $this;
    	}
    
    	function writeString($dados, $tipo = null){
    		$linha = 0;
    		$string = null; // necessario para evitar duplicação de linha
    		foreach ($dados as $key => $value){
    			// echo 'gravando linha'.$linha++.' <br>';
    			if(isset($value->valor)){
    				$value->valor = trim($value->valor);
    			}
    			if(isset($value->tipo) && $value->tipo == 'N'){
    				if(isset($value->valor)){
    					$value->valor = removeCaracteres($value->valor, 'char');
    					$value->valor = substr($value->valor, 0, $value->tamanho);
    				}
    				if($key == 'numero_referencia'){
    					$string .= strtoupper(str_pad($value->valor, $value->tamanho, 0, STR_PAD_LEFT));
    				}else{
    					$string .= strtoupper(str_pad(funcValor($value->valor,'S',0), $value->tamanho, 0, STR_PAD_LEFT));
    				}
    			}elseif(isset($value->tipo) && $value->tipo == 'A'){
    				if(isset($value->valor)){
    					$value->valor = removeCaracteres($value->valor, 'char_especiais');
    					$value->valor = removeAcentos($value->valor, ' ');
    					$value->valor = substr($value->valor, 0, $value->tamanho);
    				}
    				// if($key == 'endereço_empresa'){
    				// 	var_dump($key, $value->valor);
    				// 	exit;
    				// }
    				$string .= strtoupper(str_pad($value->valor, $value->tamanho, ' ', STR_PAD_RIGHT));
    				// var_dump($key, $value->valor, $string);
    				// if($key == 'endereço_empresa'){
    				// 	exit;
    				// }
    				// var_dump($key, $string);
    				// if($key == 'nome_concessionaria'){
    				// 	var_dump($string);
    				// }
    			}elseif(isset($value->tipo) && $value->tipo == 'E'){
    				if(isset($value->valor)){
    					$value->valor = removeCaracteres($value->valor, 'char_especiais');
    					$value->valor = substr($value->valor, 0, $value->tamanho);
    				}
    				$string .= strtoupper(str_pad($value->valor, $value->tamanho, 0, STR_PAD_LEFT));
    			}
    	
    			if(isset($value->brancos)){
    				$string .= str_pad(' ', $value->brancos, ' ', STR_PAD_LEFT);
    			}
    			
    			if(isset($value->zeros)){
    				$string .= str_pad('0', $value->zeros, '0', STR_PAD_LEFT);
    			}
    			// if($tipo == 'lote'){
    			// 	echo'<pre>';
    			// 		var_dump($key, $string);
    			// 	echo '</pre>';
    			// 	if($key == 'endereço_empresa'){
    			// 		exit;
    			// 	}
    			// }
    		}
    		$this->setString($string);
    		$this->popularArquivo();
    		// $fp = fopen('remessa.rem', 'w');
    		// fwrite($fp, $this->string);
    		// fclose($fp);
    		// var_dump($this->getString());
    	}
    
    	function setMapaDetalhe($mapa){
    		// $this->linhas_detalhe++;
    		if($mapa){
    			$this->mapa_detalhe = convertToObject($mapa);
    		}
    		return $this;
    	}
    
    	// function processMapaCnab($cnab = null){
    	// 	if($cnab){
    	// 		$this->cnab = $cnab;
    	// 	}
    	// 	if(count($this->detalhe) > 0){
    	// 		foreach($this->detalhe as $key => $value){
    	// 			if($this->cnab == 240){
    	// 				$this->builtMapaCnab240($value, 'a');
    	// 				$this->builtMapaCnab240($value, 'b');
    	// 			}elseif($this->cnab == 400){
    	// 				$this->buitMapaCnab400($value);
    	// 			}else{
    	// 				//implementar erro cnab não encontrado
    	// 			}
    	// 		}
    	// 	}else{
    	// 		return false;
    	// 	}
    	// }
    }