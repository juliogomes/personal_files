<?php

class RemessaItau extends RemessaDetalhe{
	function __construct($controller, $cliente){
		
		if(is_array($cliente)){
			$cliente = convertToObject($cliente);
		}

		parent::__construct($controller, $cliente);
		$this->setBanco($cliente);
		$this->setConta($cliente);
		$this->setCliente($cliente);
		// echo 'PI'.$this->data_atual->format('md').$this->getSeqRemessa().'.REM';
		$this->setNomeArquivo('PI'.$this->data_atual->format('md').$this->getSeqRemessa().'.REM');
		$this->saveBD('remessa')->CriarArquivo();
	}

	function setDetalhe($dados){
		
		$detalhe = null;
		if(is_array($dados)){
			$dados = convertToObject($dados);
		}

		foreach ($dados as $key => $value) {
			$this->qtd_registros++;
			$detalhe[$key]['ie_cm']            = $value->ie_cm;
			$detalhe[$key]['id_doc']           = $value->id_doc; // id na tabela da base
			$detalhe[$key]['numero_documento'] = $value->numero_documento; // id na tabela da base
			// $detalhe[$key]['seq_detalhe']   = $value->seq_detalhe; // numero sequencial do lote, inicia-se com 1 a cada novo lote
			$detalhe[$key]['id_fornecedor']    = $value->id_fornecedor;
			$detalhe[$key]['nome_fornecedor']  = $value->nome_fornecedor;
			$detalhe[$key]['seu_numero']       = $value->seu_numero; // numero de identificação da despesa - id_despesa na tabela
			$detalhe[$key]['codigo_ispb']      = $value->codigo_ispb;
			$detalhe[$key]['tipo_inscricao']   = $value->tipo_inscricao; // 1 - CNPJ, 2 - CPF
			$detalhe[$key]['cnpj_cm']          = $value->cnpj_cm;
			$detalhe[$key]['cnpj_cpf']         = $value->cnpj_cpf;
			$detalhe[$key]['codigo_banco']     = $value->codigo_banco;
			$detalhe[$key]['nome_banco']       = $value->nome_banco;
			$detalhe[$key]['numero_agencia']   = $value->numero_agencia;
			$detalhe[$key]['digito_agencia']   = $value->digito_agencia;
			$detalhe[$key]['numero_conta']     = $value->numero_conta;
			$detalhe[$key]['digito_conta']     = $value->digito_conta;
			$detalhe[$key]['ag_conta_dig']     = $value->ag_conta_dig;
			// var_dump($value->codigo_barras, $this->obj_boleto->ipteToBarras($value->codigo_barras, true));
			// var_dump($value->codigo_barras, $this->obj_boleto->ipteToBarras($value->codigo_barras, true));
			$detalhe[$key]['codigo_barras']    = $this->obj_boleto->ipteToBarras($value->codigo_barras, true);
			$detalhe[$key]['codigo_receita']   = $value->codigo_receita;
			$detalhe[$key]['tipo_contribuinte'] = $value->tipo_contribuinte;
			// $detalhe[$key]['identificacao_contribuinte']   = $value->identificacao_contribuinte;
			$detalhe[$key]['codigo_tributo']   = $value->codigo_tributo;
			$detalhe[$key]['competencia']      = $value->competencia;
			$detalhe[$key]['numero_referencia']   = $value->numero_referencia;
			$detalhe[$key]['outros_valores']   = $value->outros_valores;
			$detalhe[$key]['atualizacao_monetaria']   = $value->atualizacao_monetaria;
			$detalhe[$key]['percentual_receita']   = $value->percentual_receita;
			$detalhe[$key]['inscricao_estadual']   = $value->inscricao_estadual;
			$detalhe[$key]['divida_ativa']   = $value->divida_ativa;
			$detalhe[$key]['numero_parcela']   = $value->numero_parcela;
			$detalhe[$key]['data_vencimento']  = $value->data_vencimento;
			$detalhe[$key]['valor']            = $value->valor;
			$detalhe[$key]['abatimento']       = $value->abatimento;
			$detalhe[$key]['desconto']         = $value->desconto;
			$detalhe[$key]['multa']            = $value->multa;
			$detalhe[$key]['mora']             = $value->mora;
			$detalhe[$key]['descricao']        = $value->descricao;
			$detalhe[$key]['tipo_despesa']     = $value->tipo_despesa;
			$detalhe[$key]['tipo_cobranca']    = $value->tipo_cobranca;
			$detalhe[$key]['meio_pagamento']   = $value->meio_pagamento;
			$detalhe[$key]['tipo_conta']       = $value->tipo_conta;
			$detalhe[$key]['endereco']     	   = $value->endereco;
			$detalhe[$key]['numero']           = $value->numero;
			$detalhe[$key]['complemento']      = $value->complemento;
			$detalhe[$key]['bairro']           = $value->bairro;
			$detalhe[$key]['cidade']           = $value->cidade;
			$detalhe[$key]['estado']           = $value->estado;
			$detalhe[$key]['cep']              = $value->cep;
			/*
				'01' = Crédito em Conta
				'02' = Pagamento de Aluguel/Condomínio
				'03' = Pagamento de Duplicata/Títulos
				'04' = Pagamento de Dividendos
				'05' = Pagamento de Mensalidade Escolar
				'06' = Pagamento de Salários
				'07' = Pagamento a Fornecedores
				'08' = Operações de Câmbios/Fundos/Bolsa de Valores
				'09' = Repasse de Arrecadação/Pagamento de Tributos
				'10' = Transferência Internacional em Real
				'11' = DOC para Poupança
				'12' = DOC para Depósito Judicial
				'13' = Outros
				‘16’ = Pagamento de bolsa auxílio
				‘17’ = Remuneração à cooperado
			*/
			
			if(
				strtolower($value->tipo_cobranca) == 'fatura' ||
				strtolower($value->tipo_cobranca) == 'nota fiscal' ||
				strtolower($value->tipo_cobranca) == 'recibo' ||
				strtolower($value->tipo_cobranca) == 'concessionaria'
			){
				if($value->meio_pagamento == 'transferencia'){
					if($value->tipo_conta == 'p'){
						$detalhe[$key]['finalidade_doc'] = '11';
					}else{
						$detalhe[$key]['finalidade_doc'] = '01';
					}
				}else{
					$detalhe[$key]['finalidade_doc'] = '07';
				}
			}else{
				$detalhe[$key]['finalidade_doc'] = '09';
			}
			//Aguardando esclarecimentos da Rhaissa para complementar
			// verificar documento auxiliar dominios_spb.xls na pasta do sistema arquivos\arquivos_auxiliares\bacen
			if(
				strtolower($value->tipo_cobranca) == 'fatura' ||
				strtolower($value->tipo_cobranca) == 'nota fiscal' ||
				strtolower($value->tipo_cobranca) == 'recibo'
			){
				if($value->meio_pagamento == 'transferencia'){
					$detalhe[$key]['finalidade_ted'] = '00010';
				}else{
					$detalhe[$key]['finalidade_ted'] = '00005';
				}
			}elseif(strtolower($value->tipo_cobranca) == 'concessionaria'){
				$detalhe[$key]['finalidade_ted'] = '00002';
			}else{
				$detalhe[$key]['finalidade_ted'] = '00001';
			}
			/*
				Código adotado para complemento da finalidade pagamento.
				Para finalidade TED deverá ser formatada com o seguinte domínio: CC – para destino com tipo de conta corrente
				PP – para destino com tipo de conta poupança
				Observação: para modalidade DOC esta informação é definida a partir do código de finalidade DOC (campo P005).
			*/
			if($value->tipo_conta == 'p'){
				$detalhe[$key]['finalidade_complemento'] = 'pp';
			}else{
				$detalhe[$key]['finalidade_complemento'] = 'cc';
			}
		}
		
		$this->detalhe = convertToObject($detalhe);
		return $this;
	}

	function BuiltFile(){
		$segmento_lote = null;
		if($this->getCodigoRemessa()){
			foreach($this->detalhe as $key => $value){
				// $this->setCodigoCamara(0);
				$codigo_barras = $value->codigo_barras; 
				if($value->tipo_despesa == 'tributo' || ($value->tipo_cobranca == 'concessionaria' && substr($codigo_barras, 0, 1) == '8')){
					$i1 = 'tributo';
					if($value->meio_pagamento == 'boleto_cc'){
						$i2 = 'tributo_cc'; // tributo com codigo de barra
					}elseif($value->tipo_cobranca == 'darf_normal'){
						$i2 = 'darf_normal';
					}elseif($value->tipo_cobranca == 'gps'){
						$i2 = 'gps';
					}elseif($value->tipo_cobranca == 'darf_simples'){
						$i2 = 'darf_simples';
					}elseif($value->tipo_cobranca == 'gare_sp'){
						$i2 = 'gare_sp';
					}elseif($value->tipo_cobranca == 'iptu'){
						$i2 = 'iptu';
					}elseif($value->tipo_cobranca == 'darj'){
						$i2 = 'darj';
					}elseif($value->tipo_cobranca == 'ipva'){
						$i2 = 'ipva';
					}elseif($value->tipo_cobranca == 'licenciamento'){
						$i2 = 'licenciamento';
					}elseif($value->tipo_cobranca == 'dpvat'){
						$i2 = 'dpvat';
					}elseif($value->tipo_cobranca == 'outros'){
						$i2 = 'outros_tributos';
					}
					$lotes[$i1][$i2][] = $value;
				}else{
					
					$i1 = 'fornecedor';
					if($value->meio_pagamento == 'boleto_cc'){
						if(($this->codigo_banco == $value->codigo_banco) || (substr($codigo_barras, 0, 3) == $this->codigo_banco) ){
							//boletos do mesmo banco com codigo de barra
							$i2 = 'bccmb';
						}else{
							//boletos de outros bancos com codigo de barra
							$i2 = 'bccob';
						}
					}elseif($value->meio_pagamento == 'boleto_sc'){
						if($this->codigo_banco == $value->codigo_banco){
							//boletos do mesmo banco sem codigo de barra
							$i2 = 'bscmb';
						}else{
							//boletos de outros bancos sem codigo de barra
							$i2 = 'bscob';
						}
					}elseif($value->meio_pagamento == 'transferencia'){
						//PARA BANCOS IGUAIS É FEITO CREDITO EM CONTA DIRETAMENTE
						if($this->codigo_banco == $value->codigo_banco && $value->tipo_conta == 'c'){
							$i2 = 'credito_conta_corrente';
							$value->finalidade_ted = '';
							$value->finalidade_complemento = '';
							$value->codigo_camara = '0';
						}elseif($this->codigo_banco == $value->codigo_banco && $value->tipo_conta == 'p'){
							$i2 = 'credito_conta_poupanca';
							$value->finalidade_ted = '';
							$value->finalidade_complemento = '';
							$value->codigo_camara = '0';
						}elseif($value->cnpj_cpf == $this->cnpj_cpf){
							//TED E DOC PARA MESMA TITULARIDADE
							$i2 = 'tedmt';
							$value->codigo_camara = '018';
						}elseif($value->cnpj_cpf != $this->cnpj_cpf){
							// echo "despesa $value->seu_numero / codigo banco cm $this->codigo_banco - codigo banco fornecedor $value->codigo_banco - tipo conta $value->tipo_conta \n";
							//TED E DOC PARA OUTRA TITULARIDADE
							$i2 = 'tedot';
							$value->codigo_camara = '018';
						}else{
							//TED E DOC PARA OUTRA TITULARIDADE
							$i2 = 'tedot';
							$value->codigo_camara = '018';
						}
					}elseif($value->meio_pagamento == 'orderm_pagamento'){
						// ORDEM DE PAGAMENTO
						$i2 = 'ordem_pagamento';
					}elseif($value->meio_pagamento == 'cheque_adm' || $value->meio_pagamento == 'cheque_comum'){
						$i2 = 'cheque';
					}
					$lotes[$i1][$i2][] = $value;
				}
			}
			/*
			Tipo de Serviço: '20' = Pagamento Fornecedor 
			Forma de Lançamento 
			'01' = Crédito em Conta Corrente - (SEGMENTOS A e B)
			'03' = DOC/TED (1) (2) - (SEGMENTOS A e B) 
			'30' = Liquidação de Títulos do Próprio Banco - (SEGMENTOS J e J-52)
			'31' = Pagamento de Títulos de Outros Bancos - (SEGMENTOS J e J-52) 
			'41' = TED – Outra Titularidade (1) - (SEGMENTOS A e B)
			'43' = TED – Mesma Titularidade (1) - (SEGMENTOS A e B)
			Títulos Banco Bradesco e de outros bancos - (SEGMENTOS G, H, Y)
			Para clientes cadastrados os nesta modalidade o banco disponibiliza 2 arquivos diários – sendo o primeiro entre às 05h00 / 09h00 e o segundo entre às 13h00 / 15h00. Os nomes dos arquivos de retorno do Multipag apresentam-se: PI + dia + mês + sequencial 00, 01, 02 – exemplo: PI070500.ret. 
			Informações do arquivo de rastreamento: “Entrada de títulos, títulos liquidados, alteração de vencimento, etc”
			Tipo de Serviço: ‘22’ = Pagamento de Contas, Tributos e Impostos

			Forma de Lançamento
			‘11’ = Pagamento de Contas e Tributos com Código de Barras - (SEGMENTOS O) 
			‘16’ = Tributo - DARF Normal - (SEGMENTOS N – N2)
			‘17’ = Tributo - GPS (Guia da Previdência Social) - (SEGMENTOS N – N1)  
			‘18’ = Tributo - DARF Simples - (SEGMENTOS N – N3)
			‘22’ = Tributo – GARE SP - (SEGMENTOS N – N4)
			Crédito em conta é utilizado apenas para contas BRADESCO – forma de lançamento ‘01’.
			DOC/TED (1) (2) é utilizado para contas de outros bancos – forma de lançamento ‘03’
			TED (1) – é utilizado para contas de outros bancos-  Outra titularidade – forma de lançamento ‘41’
			TED (1) - é utilizado para de contas de outros bancos-  Outra titularidade – forma de lançamento  ‘42’
			No manual em anexo, verifique as diferenças entre (1) e (2) para DOC/TED e TED, conforme página 86: 
			*/
			if(count($lotes) > 0){
				
				// $this->setLotes($lotes);
				$this->builtMapaArquivoCnab240(true)->buitString('arquivo', true);
				// $this->setLinhasArquivo(2);
				$contador_lote = 1;
				$this->setCodigoLote($contador_lote);
				$this->setTipoOperacao('c');
				
				foreach($lotes as $key => $value){
					// $this->setLinhasLote(2);
					$this->setTipoLote($key);
					if($key == 'fornecedor' ){
						$this->setTipoServico(20);
					}else{
						$this->setTipoServico(22);
					}
						
					foreach($value as $k1 => $v1){
						$this->setSeqDetalhe(0);
						if($k1 == 'tributo_cc'){
							$this->setFormaLancamento(11);
						}elseif($k1 == 'tedmt'){
							$this->setFormaLancamento(43);
						}elseif($k1 == 'tedot'){
							$this->setFormaLancamento(41);
						}elseif($k1 == 'bccmb' || $k1 == 'bscmb'){
							$this->setFormaLancamento(30);
						}elseif($k1 == 'bccob' || $k1 == 'bscob'){
							$this->setFormaLancamento(31);
						}elseif($k1 == 'credito_conta_corrente'){
							$this->setFormaLancamento(01);
						}elseif($k1 == 'credito_conta_poupanca'){
							$this->setFormaLancamento(05);
						}elseif($k1 == 'darf_normal'){
							$this->setFormaLancamento(16);
						}elseif($k1 == 'darf_simples'){
							$this->setFormaLancamento(18);
						}elseif($k1 == 'gare_sp'){
							$this->setFormaLancamento(22);
						}elseif($k1 == 'gps'){
							$this->setFormaLancamento(17);
						}elseif($k1 == 'iptu'){
							$this->setFormaLancamento(19);
						}elseif($k1 == 'darj'){
							$this->setFormaLancamento(21);
						}elseif($k1 == 'ipva'){
							$this->setFormaLancamento(25);
						}elseif($k1 == 'licenciamento'){
							$this->setFormaLancamento(26);
						}elseif($k1 == 'dpvat'){
							$this->setFormaLancamento(27);
						}elseif($k1 == 'outros_tributos'){
							$this->setFormaLancamento(11);
						}elseif($k1 == 'cheque'){
							$this->setFormaLancamento('02');
						}elseif($k1 == 'ordem_pagamento'){
							$this->setFormaLancamento('10');
						}
					
						if($this->saveBD('lote')){
							$valores = 0;
							// $this->setLinhasLote($this->getLinhasLote() + 2);
							//incrementa 1 no codigo do lote
							$this->setCodigoLote($contador_lote++);
							// $this->setLinhasDetalhe(count($v1));
							
							$this->setLotes($k1);
							if($k1 == 'tributo_cc'){
								$segmento_lote = 'o';
							}elseif(
								$k1 == 'outros_tributos' ||
								$k1 == 'iptu' ||
								$k1 == 'darj' ||
								$k1 == 'ipva' ||
								$k1 == 'licenciamento' ||
								$k1 == 'dpvat'         ||
								$k1 == 'darf_normal' ||
								$k1 == 'gps' ||
								$k1 == 'darf_simples' ||
								$k1 == 'gare_sp'
							){
								$segmento_lote = 'n';
							}elseif(
								$k1 == 'bccmb' ||
								$k1 == 'bscmb' ||
								$k1 == 'bccob' ||
								$k1 == 'bscob'
							){
								$segmento_lote = 'j';
							}else{
								$segmento_lote = 'a';
							}

							$this->builtMapaLoteCnab240(true, $segmento_lote)->buitString('lote', true);
							$this->setQtdeLotes($this->getQtdeLotes() + 1);//seta a quantidade de lotes no arquivo
							$this->setLinhasLote(0);
							$this->setLinhasDetalhe(0);
							foreach($v1 as $k2 => $v2){
								// var_dump($key, $k1, $k2, $v2);
								// echo 'setando linhas para 0 ';
								// $this->setLinhasArquivo(($this->getLinhasArquivo() + 1));
								// echo 'linha zerada'.$this->getLinhasDetalhe(0);
								$this->setNumeroDocumento($v2->numero_documento);
								// var_dump($v2->valor, $v2->multa, $v2->mora, $v2->atualizacao_monetaria, $v2->abatimento, $v2->desconto);
								$valores += (($v2->valor + $v2->multa + $v2->mora) - ($v2->abatimento+$v2->desconto));
								// var_dump($valores);
								$this->setValoresLote(funcValor($valores,'E'));
								if($key == 'tributo' ){
									$this->setTipoPagamento($k1);
									if($k1 == 'tributo_cc'){
										// var_dump($k1);
										$this->builtMapaDetalheCnab240($v2, 'o');//cria lote e os detalhes do lote
									}elseif(
										$k1 == 'outros_tributos' ||
										$k1 == 'iptu' ||
										$k1 == 'darj' ||
										$k1 == 'ipva' ||
										$k1 == 'licenciamento' ||
										$k1 == 'dpvat'
									){
										$this->builtMapaDetalheCnab240($v2, 'n', 'n1');
									}elseif($k1 == 'darf_normal'){
										$this->builtMapaDetalheCnab240($v2, 'n', 'n2');//cria lote e os detalhes do lote
									}elseif($k1 == 'gps'){
										$this->builtMapaDetalheCnab240($v2, 'n', 'n1');//cria lote e os detalhes do lote
									}elseif($k1 == 'darf_simples'){
										$this->builtMapaDetalheCnab240($v2, 'n', 'n3');//cria lote e os detalhes do lote
									}elseif($k1 == 'gare_sp'){
										$this->builtMapaDetalheCnab240($v2, 'n', 'n4');//cria lote e os detalhes do lote
									}
								}else{
									$this->setTipoPagamento($k1);
									//para pagamentos de conta de agua, luz ou telefone
									if($k1 == 'tributo_cc'){
										$this->builtMapaDetalheCnab240($v2, 'o');//cria lote e os detalhes do lote
									}elseif(
										$k1 == 'tedmt' || 
										$k1 == 'tedot' || 
										$k1 == 'credito_conta_corrente' || 
										$k1 == 'credito_conta_poupanca' ||
										$k1 == 'orderm_pagamento'
									){
										$this->builtMapaDetalheCnab240($v2, 'a');//cria lote e os detalhes do lote
										// $this->builtMapaDetalheCnab240($v2, 'b');//cria lote e os detalhes do lote
									}elseif(
										$k1 == 'bccmb' || 
										$k1 == 'bscmb' || 
										$k1 == 'bccob' || 
										$k1 == 'bscob'
									){
										$this->builtMapaDetalheCnab240($v2, 'j');//cria lote e os detalhes do lote
										$this->builtMapaDetalheCnab240($v2, 'j52');//cria lote e os detalhes do lote
									}
								}
							}

							$this->builtMapaLoteCnab240(false)->buitString('lote', false); // insere trailer do lote
						}else{
							$this->error = true;
						}
					}
				}
				$this->builtMapaArquivoCnab240(false)->buitString('arquivo', false);
			}//fim count lotes
		}else{
			//implementar erro
		}
		// $arquivo = $this->builtMapaArquivoCnab240(true); // true para header, false para trailer
		// $lote    = $this->builtMapaLoteCnab240(null, true);
		// $lote    = $this->builtMapaLoteCnab240(null, false); 
		// $arquivo = $this->builtMapaArquivoCnab240(null, false); // true para header, false para trailer
	}

	function builtMapaArquivoCnab240($header = true){
		// var_dump($header);
		$mapa_arquivo['header']  = null;
		$mapa_arquivo['trailer'] = null;
		$this->setLinhasArquivo(($this->getLinhasArquivo() + 1));
		if($header){
			//posicao 1-3
			$mapa_arquivo['header']['codigo_banco']['valor']   = $this->codigo_banco;
			$mapa_arquivo['header']['codigo_banco']['tamanho'] = 3; 
			$mapa_arquivo['header']['codigo_banco']['tipo']    = 'N';
			//posicao 4-7
			$mapa_arquivo['header']['codigo_lote']['valor']   = '0000';
			$mapa_arquivo['header']['codigo_lote']['tamanho'] = 4; 
			$mapa_arquivo['header']['codigo_lote']['tipo']    = 'N';
			//posicao 8-8
			$mapa_arquivo['header']['tipo_registro']['valor']   = '0';
			$mapa_arquivo['header']['tipo_registro']['tamanho'] = 1; 
			$mapa_arquivo['header']['tipo_registro']['tipo']    = 'N';
			//posicao 9-14
			$mapa_arquivo['header']['cnab9']['brancos'] = '6';
            //posicao 15-17
			$mapa_arquivo['header']['versao_layout']['valor']   = '081'; 
			$mapa_arquivo['header']['versao_layout']['tamanho'] = 3; 
			$mapa_arquivo['header']['versao_layout']['tipo']    = 'N';
            //posicao 18-18
			$mapa_arquivo['header']['tipo_inscricao']['valor']   = $this->tipo_pessoa; // 1 = CPF, 2 = CNPJ
			$mapa_arquivo['header']['tipo_inscricao']['tamanho'] = 1; 
			$mapa_arquivo['header']['tipo_inscricao']['tipo']    = 'N';
			//posicao 19-32
			$mapa_arquivo['header']['numero_inscricao']['valor']   = $this->cnpj_cpf;
			$mapa_arquivo['header']['numero_inscricao']['tamanho'] = 14; 
			$mapa_arquivo['header']['numero_inscricao']['tipo']    = 'N';
			// var_dump($this->codigo_convenio);
			// exit;
			//posicao 33-52
			$mapa_arquivo['header']['cnab33']['brancos'] = '20';
			//posicao 53-57
			$mapa_arquivo['header']['numero_agencia']['valor']   = $this->agencia;
			$mapa_arquivo['header']['numero_agencia']['tamanho'] = 5; 
            $mapa_arquivo['header']['numero_agencia']['tipo']    = 'N';
            //posicao 58-58
            $mapa_arquivo['header']['cnab58']['brancos'] = '1';
			//posicao 59-70
			$mapa_arquivo['header']['numero_conta']['valor']   = $this->conta;
			$mapa_arquivo['header']['numero_conta']['tamanho'] = 12; 
			$mapa_arquivo['header']['numero_conta']['tipo']    = 'N';
            //posicao 71-71
            $mapa_arquivo['header']['cnab71']['brancos'] = '1';
			//posicao 72-72
			$mapa_arquivo['header']['digito_agencia_conta']['valor']   = null; //padrao banco
			$mapa_arquivo['header']['digito_agencia_conta']['tamanho'] = 1; 
			$mapa_arquivo['header']['digito_agencia_conta']['tipo']    = 'N';
			//posicao 73-102
			$mapa_arquivo['header']['nome_empresa']['valor']   = $this->nome_cliente;
			$mapa_arquivo['header']['nome_empresa']['tamanho'] = 30; 
			$mapa_arquivo['header']['nome_empresa']['tipo']    = 'A';
			//posicao 103-132
			$mapa_arquivo['header']['nome_banco']['valor']   = $this->nome_banco;
			$mapa_arquivo['header']['nome_banco']['tamanho'] = 30; 
            $mapa_arquivo['header']['nome_banco']['tipo']    = 'A';
            //posicao 133-142
            $mapa_arquivo['header']['cnab133']['brancos'] = '10';
			//posicao 143-143
			$mapa_arquivo['header']['codigo_remessa']['valor']   = '1'; // 1 para remessa, 2 para retorno
			$mapa_arquivo['header']['codigo_remessa']['tamanho'] = 1; 
			$mapa_arquivo['header']['codigo_remessa']['tipo']    = 'N';
			//posicao 144-151
			$mapa_arquivo['header']['data_geracao']['valor']   = '01-05-2020';//$this->data_atual->format('dmY');
			$mapa_arquivo['header']['data_geracao']['tamanho'] = 8; 
			$mapa_arquivo['header']['data_geracao']['tipo']    = 'N';
			//posicao 152-157
			$mapa_arquivo['header']['hora_geracao']['valor']   = $this->data_atual->format('his');
			$mapa_arquivo['header']['hora_geracao']['tamanho'] = 6; 
			$mapa_arquivo['header']['hora_geracao']['tipo']    = 'N';
            //posicao 158-166
            $mapa_arquivo['header']['cnab133']['zeros'] = '9';
            //posicao 167-171
			$mapa_arquivo['header']['densidade']['valor']   = null;
			$mapa_arquivo['header']['densidade']['tamanho'] = 5; 
			$mapa_arquivo['header']['densidade']['tipo']    = 'N';
			//posicao 172-240
			$mapa_arquivo['header']['reservado_banco']['brancos'] = '69';
			$this->setMapaArquivo($mapa_arquivo['header'], true); //false para trailer, true para header
		}else{
			//posicao 1-3
			$mapa_arquivo['trailer']['codigo_banco']['valor']   = $this->codigo_banco;
			$mapa_arquivo['trailer']['codigo_banco']['tamanho'] = 3; 
			$mapa_arquivo['trailer']['codigo_banco']['tipo']    = 'N';
			//posicao 4-7
			$mapa_arquivo['trailer']['codigo_lote']['valor']   = '9999';
			$mapa_arquivo['trailer']['codigo_lote']['tamanho'] = 4; 
			$mapa_arquivo['trailer']['codigo_lote']['tipo']    = 'N';
			//posicao 8-8
			$mapa_arquivo['trailer']['tipo_registro']['valor']   = '9';
			$mapa_arquivo['trailer']['tipo_registro']['tamanho'] = 1; 
			$mapa_arquivo['trailer']['tipo_registro']['tipo']    = 'N';
			//posicao 9-17
			$mapa_arquivo['trailer']['cnab1']['brancos'] = '9';
			//posicao 18-23
			// var_dump($this->getQtdeLotes());
			// var_dump($this->getLinhasLote(), $this->getLinhasDetalhe());
			$mapa_arquivo['trailer']['quantidade_lotes']['valor']   = $this->getQtdeLotes();
			$mapa_arquivo['trailer']['quantidade_lotes']['tamanho'] = 6; 
			$mapa_arquivo['trailer']['quantidade_lotes']['tipo']    = 'N';
			//posicao 24-29
			// var_dump($this->getLinhasArquivo(), $this->getLinhasLote(), $this->getLinhasDetalhe());
			$mapa_arquivo['trailer']['quantidade_registros']['valor']   = ($this->getLinhasArquivo());
			$mapa_arquivo['trailer']['quantidade_registros']['tamanho'] = 6; 
			$mapa_arquivo['trailer']['quantidade_registros']['tipo']    = 'N';
			//posicao 30-35
			/*Quantidade de Contas para Conciliação (Lotes)
			Número indicativo de lotes de Conciliação Bancária enviados no arquivo. Somatória dos registros de tipo 1 e Tipo de Operação =
			'E'.
			Campo específico para o serviço de Conciliação Bancária.
			*/
			//implementar futuramento
			$mapa_arquivo['trailer']['quantidade_contas']['valor']   = 0; //$this->getQtdeLotes();
			$mapa_arquivo['trailer']['quantidade_contas']['tamanho'] = 6; 
			$mapa_arquivo['trailer']['quantidade_contas']['tipo']    = 'N';
			//posicao 36-240
			$mapa_arquivo['trailer']['cnab2']['brancos'] = '205';
			
			$this->setMapaArquivo($mapa_arquivo['trailer'], false); //false para trailer, true para header
		}
		return $this;
	}

	function builtMapaLoteCnab240($header = true, $segmento = null){
		$mapa_lote['header']  = null;
		$mapa_lote['trailer'] = null;
		$this->setLinhasArquivo(($this->getLinhasArquivo() + 1));
		$this->setLinhasLote(($this->getLinhasLote() + 2));
		if($header){
			//posicao 1-3
			$mapa_lote['header']['codigo_banco']['valor']   = $this->codigo_banco;
			$mapa_lote['header']['codigo_banco']['tamanho'] = 3; 
			$mapa_lote['header']['codigo_banco']['tipo']    = 'N';
			//posicao 4-7
			$mapa_lote['header']['codigo_lote']['valor']   = $this->getCodigoLote(); // numero sequencial do lote, não pode repetir dentro do arquivo
			$mapa_lote['header']['codigo_lote']['tamanho'] = 4; 
			$mapa_lote['header']['codigo_lote']['tipo']    = 'N';
			//posicao 8-8
			$mapa_lote['header']['tipo_registro']['valor']   = '1';
			$mapa_lote['header']['tipo_registro']['tamanho'] = 1; 
			$mapa_lote['header']['tipo_registro']['tipo']    = 'N';
			//posicao 9-9
			$mapa_lote['header']['tipo_operacao']['valor']   = $this->getTipoOperacao();
			$mapa_lote['header']['tipo_operacao']['tamanho'] = 1; 
			$mapa_lote['header']['tipo_operacao']['tipo']    = 'A';
			//posicao 10-11
			$mapa_lote['header']['tipo_servico']['valor']   = $this->getTipoServico();
			$mapa_lote['header']['tipo_servico']['tamanho'] = 2; 
			$mapa_lote['header']['tipo_servico']['tipo']    = 'N';
			//posicao 12-13
			$mapa_lote['header']['forma_lancamento']['valor']   = $this->getFormaLancamento();
			$mapa_lote['header']['forma_lancamento']['tamanho'] = 2; 
			$mapa_lote['header']['forma_lancamento']['tipo']    = 'N';

			//posicao 14-16
			if('o' == $segmento || 'n' == $segmento){
				$mapa_lote['header']['versao_layout']['valor']   = '030';
				$mapa_lote['header']['versao_layout']['tamanho'] = 3; 
				$mapa_lote['header']['versao_layout']['tipo']    = 'N';
			}elseif('j' == $segmento){
				$mapa_lote['header']['versao_layout']['valor']   = '030';
				$mapa_lote['header']['versao_layout']['tamanho'] = 3; 
				$mapa_lote['header']['versao_layout']['tipo']    = 'N';
			}else{
				$mapa_lote['header']['versao_layout']['valor']   = '040';
				$mapa_lote['header']['versao_layout']['tamanho'] = 3; 
				$mapa_lote['header']['versao_layout']['tipo']    = 'N';
			}
			//posicao 17-17
			$mapa_lote['header']['cnab17']['brancos'] = '1';
			//posicao 18-18
			$mapa_lote['header']['tipo_inscricao']['valor']   = $this->tipo_pessoa; // 1 = CPF, 2 = CNPJ
			$mapa_lote['header']['tipo_inscricao']['tamanho'] = 1; 
			$mapa_lote['header']['tipo_inscricao']['tipo']    = 'N';
			//posicao 19-32
			$mapa_lote['header']['numero_inscricao']['valor']   = $this->cnpj_cpf;
			$mapa_lote['header']['numero_inscricao']['tamanho'] = 14; 
			$mapa_lote['header']['numero_inscricao']['tipo']    = 'N';
            //posicao 33-36
            //Nas posições 33 a 36 (Identificação do Lançamento no Extrato do Favorecido) informar o conteúdo “ 1707” . 
			$mapa_lote['header']['id_lancamento']['valor']   = '1707';
			$mapa_lote['header']['id_lancamento']['tamanho'] = 4; 
			$mapa_lote['header']['id_lancamento']['tipo']    = 'N';
            //posicao 37-52
			$mapa_lote['header']['cnab37']['brancos'] = '16';
            //posicao 53-57
			$mapa_lote['header']['numero_agencia']['valor']   = $this->agencia;
			$mapa_lote['header']['numero_agencia']['tamanho'] = 5; 
			$mapa_lote['header']['numero_agencia']['tipo']    = 'N';
            //posicao 58-58
			$mapa_lote['header']['cnab58']['brancos'] = '1';
			//posicao 59-70
			$mapa_lote['header']['numero_conta']['valor']   = $this->conta;
			$mapa_lote['header']['numero_conta']['tamanho'] = 12; 
            $mapa_lote['header']['numero_conta']['tipo']    = 'N';
            //posicao 71-71
			$mapa_lote['header']['cnab71']['brancos'] = '1';
			//posicao 72-72
			$mapa_lote['header']['dac']['valor']   = ''; //padrao banco
			$mapa_lote['header']['dac']['tamanho'] = 1; 
			$mapa_lote['header']['dac']['tipo']    = 'N';
			//posicao 73-102
			$mapa_lote['header']['nome_empresa']['valor']   = $this->nome_cliente;
			$mapa_lote['header']['nome_empresa']['tamanho'] = 30; 
			$mapa_lote['header']['nome_empresa']['tipo']    = 'A';
            //posicao 103-132
            //verificar
			$mapa_lote['header']['finalidade_lote']['valor']   = null; //$this->finalidade_lote;
			$mapa_lote['header']['finalidade_lote']['tamanho'] = 30;
			$mapa_lote['header']['finalidade_lote']['tipo']    = 'A';
            //posicao 133-142
            //verificar
			$mapa_lote['header']['historico_cc']['valor']   = null; //$this->historico_cc;
			$mapa_lote['header']['historico_cc']['tamanho'] = 10;
            $mapa_lote['header']['historico_cc']['tipo']    = 'A';
			//posicao 143-172	
			$mapa_lote['header']['endereço_empresa']['valor']   = $this->logradouro;
			$mapa_lote['header']['endereço_empresa']['tamanho'] = 30;
			$mapa_lote['header']['endereço_empresa']['tipo']    = 'A';
			//posicao 173-177
			$mapa_lote['header']['numero']['valor']   = $this->numero;
			$mapa_lote['header']['numero']['tamanho'] = 5; 
			$mapa_lote['header']['numero']['tipo']    = 'N';
			//posicao 178-192
			$mapa_lote['header']['complemento']['valor']   = $this->complemento;
			$mapa_lote['header']['complemento']['tamanho'] = 15; 
			$mapa_lote['header']['complemento']['tipo']    = 'A';
			//posicao 193-212
			$mapa_lote['header']['cidade']['valor']   = $this->cidade;
			$mapa_lote['header']['cidade']['tamanho'] = 20; 
			$mapa_lote['header']['cidade']['tipo']    = 'A';
			//posicao 213-220
			$mapa_lote['header']['cep']['valor']   = $this->cep;
			$mapa_lote['header']['cep']['tamanho'] = 8; 
			$mapa_lote['header']['cep']['tipo']    = 'N';
			//posicao 221-222
			$mapa_lote['header']['estado']['valor']   = $this->uf;
			$mapa_lote['header']['estado']['tamanho'] = 2; 
			$mapa_lote['header']['estado']['tipo']    = 'A';
			//posicao 223-230
			$mapa_lote['header']['cnab223']['brancos'] = '8';
			//posicao 231-240
			$mapa_lote['header']['ocorrencias']['valor']   = null; // para uso do banco
			$mapa_lote['header']['ocorrencias']['tamanho'] = 10; 
			$mapa_lote['header']['ocorrencias']['tipo']    = 'A';
			
			$this->setMapaLote($mapa_lote['header'], true); //false para trailer, true para header
		}else{
			//posicao 1-3
			$mapa_lote['trailer']['codigo_banco']['valor']   = $this->codigo_banco;
			$mapa_lote['trailer']['codigo_banco']['tamanho'] = 3; 
			$mapa_lote['trailer']['codigo_banco']['tipo']    = 'N';
			//posicao 4-7
			$mapa_lote['trailer']['codigo_lote']['valor']   = $this->getCodigoLote();
			$mapa_lote['trailer']['codigo_lote']['tamanho'] = 4; 
			$mapa_lote['trailer']['codigo_lote']['tipo']    = 'N';
			//posicao 8-8
			$mapa_lote['trailer']['tipo_registro']['valor']   = '5';
			$mapa_lote['trailer']['tipo_registro']['tamanho'] = 1; 
			$mapa_lote['trailer']['tipo_registro']['tipo']    = 'N';
			//posicao 9-17
			$mapa_lote['trailer']['cnab1']['brancos'] = '9';
			//posicao 18-23
			// var_dump($this->getLinhasLote(), $this->getLinhasDetalhe());
			$mapa_lote['trailer']['quantidade_registros']['valor']   = ($this->getLinhasLote() + $this->getLinhasDetalhe());
			$mapa_lote['trailer']['quantidade_registros']['tamanho'] = 6; 
			$mapa_lote['trailer']['quantidade_registros']['tipo']    = 'N';
			//posicao 24-41
			$mapa_lote['trailer']['soma_valores']['valor']   = $this->getValoresLote();
			$mapa_lote['trailer']['soma_valores']['tamanho'] = 18; 
			$mapa_lote['trailer']['soma_valores']['tipo']    = 'N';
			//posicao 42-59
			$mapa_lote['trailer']['cnab42']['zeros'] = '18';
			//posicao 60-65
			$mapa_lote['trailer']['cnab60']['brancos'] = '171';
			//posicao 231-240
			$mapa_lote['trailer']['ocorrencias']['valor']   = ''; // para uso do banco
			$mapa_lote['trailer']['ocorrencias']['tamanho'] = 10; 
			$mapa_lote['trailer']['ocorrencias']['tipo']    = 'A';
			$this->setMapaLote($mapa_lote['trailer'], false); //false para trailer, true para header
		}//fim do else
		return $this;
	}

	function builtMapaDetalheCnab240($detalhe, $segmento = 'a', $complemento = null){

		$mapa_detalhe = null;
		// echo 'Add linhas lote antes :'.$this->getLinhasDetalhe().'<br>';
		$this->setLinhasArquivo(($this->getLinhasArquivo() + 1));
		// echo '<br> incemenrando linha detalhe: '.$this->getLinhasDetalhe().'<br>';
		$this->setLinhasDetalhe(($this->getLinhasDetalhe() + 1));
		// echo 'Add linhas lote depois :'.$this->getLinhasDetalhe().'<br>';
		// echo '<pre>';
		// 	var_dump($this->getSeqDetalhe());
		// echo '</pre>';
		$this->setSeqDetalhe( ($this->getSeqDetalhe() + 1 ));
		// if($segmento == 'o'){
		// 	echo '<pre>';
		// 		var_dump($this->getSeqDetalhe());
		// 	echo '</pre>';
		// }
	
		//$this->saveBD('detalhe');
		switch ($segmento) {
			case 'a':
				//SEGMENTO A
				//posicao 1-3
				$mapa_detalhe['a']['codigo_banco']['valor']   = $this->codigo_banco;
				$mapa_detalhe['a']['codigo_banco']['tamanho'] = 3; 
				$mapa_detalhe['a']['codigo_banco']['tipo']    = 'N';
				//posicao 4-7
				$mapa_detalhe['a']['codigo_lote']['valor']   = $this->codigo_lote;
				$mapa_detalhe['a']['codigo_lote']['tamanho'] = 4; 
				$mapa_detalhe['a']['codigo_lote']['tipo']    = 'N';
				//posicao 8-8
				$mapa_detalhe['a']['tipo_registro']['valor']   = '3';
				$mapa_detalhe['a']['tipo_registro']['tamanho'] = 1; 
				$mapa_detalhe['a']['tipo_registro']['tipo']    = 'N';
				//posicao 9-13
				$mapa_detalhe['a']['numero_seq_detalhe']['valor']   = $this->getSeqDetalhe();
				$mapa_detalhe['a']['numero_seq_detalhe']['tamanho'] = 5; 
				$mapa_detalhe['a']['numero_seq_detalhe']['tipo']    = 'N';
				//posicao 14-14
				$mapa_detalhe['a']['codigo_segmento']['valor']   = 'A'; // FIXO A
				$mapa_detalhe['a']['codigo_segmento']['tamanho'] = 1; 
				$mapa_detalhe['a']['codigo_segmento']['tipo']    = 'A';
				//posicao 15-17
                //varificar
				$mapa_detalhe['a']['tipo_movimento']['valor']   = 0;
				$mapa_detalhe['a']['tipo_movimento']['tamanho'] = 3; 
				$mapa_detalhe['a']['tipo_movimento']['tipo']    = 'N';
				//posicao 18-20
				/*
				Código da Câmara Centralizadora
				Código adotado pela FEBRABAN, para identificar qual Câmara de Centralizadora será responsável pelo processamento dos
				pagamentos.
				Preencher com o código da Câmara Centralizadora para envio do DOC. Domínio:
				'018' = TED (STR, CIP)
				'700' = DOC (COMPE)
				'888' = TED (STR/CIP) – Utilizado quando for necessário o envio de TED utilizando o código ISPB da Instituição Financeira
				Destinatária. Neste caso é obrigatório o preenchimento do campo “Código ISPB” – Campo 26.3B, do Segmento de Pagamento,
				conforme descrito na Nota P015.
                */
                //verificar
				$mapa_detalhe['a']['camara']['valor']   = $detalhe->codigo_camara;//'018';
				$mapa_detalhe['a']['camara']['tamanho'] = 3; 
				$mapa_detalhe['a']['camara']['tipo']    = 'N';
				//posicao 21-23
				$mapa_detalhe['a']['codigo_banco_favorecido']['valor']   = $detalhe->codigo_banco;
				$mapa_detalhe['a']['codigo_banco_favorecido']['tamanho'] = 3; 
				$mapa_detalhe['a']['codigo_banco_favorecido']['tipo']    = 'N';
				//posicao 24-28
				$mapa_detalhe['a']['agencia_favorecido']['valor']   = $detalhe->numero_agencia;
				$mapa_detalhe['a']['agencia_favorecido']['tamanho'] = 5; 
				$mapa_detalhe['a']['agencia_favorecido']['tipo']    = 'N';
				//posicao 29-29
				$mapa_detalhe['a']['agencia_dig_favorecido']['valor']   = $detalhe->digito_agencia;
				$mapa_detalhe['a']['agencia_dig_favorecido']['tamanho'] = 1; 
				$mapa_detalhe['a']['agencia_dig_favorecido']['tipo']    = 'A';
				//posicao 30-41
				$mapa_detalhe['a']['conta_favorecido']['valor']   = $detalhe->numero_conta;
				$mapa_detalhe['a']['conta_favorecido']['tamanho'] = 12; 
				$mapa_detalhe['a']['conta_favorecido']['tipo']    = 'N';
				//posicao 42-42
				$mapa_detalhe['a']['conta_dig_favorecido']['valor']   = $detalhe->digito_conta;
				$mapa_detalhe['a']['conta_dig_favorecido']['tamanho'] = 1; 
				$mapa_detalhe['a']['conta_dig_favorecido']['tipo']    = 'A';
				//posicao 43-43
				$mapa_detalhe['a']['ag_conta_dig_favorecido']['valor']   = null; // padrao utilizado pelo banco
				$mapa_detalhe['a']['ag_conta_dig_favorecido']['tamanho'] = 1; 
				$mapa_detalhe['a']['ag_conta_dig_favorecido']['tipo']    = 'A';
				//posicao 44-73
				$mapa_detalhe['a']['nome_favorecido']['valor']   = $detalhe->nome_fornecedor;
				$mapa_detalhe['a']['nome_favorecido']['tamanho'] = 30; 
				$mapa_detalhe['a']['nome_favorecido']['tipo']    = 'A';
				//posicao 74-93
				$mapa_detalhe['a']['seu_numero']['valor']   = $detalhe->seu_numero;
				$mapa_detalhe['a']['seu_numero']['tamanho'] = 20; 
				$mapa_detalhe['a']['seu_numero']['tipo']    = 'A';
				//posicao 94-101
				$mapa_detalhe['a']['data_pagamento']['valor']   = $detalhe->data_vencimento;
				$mapa_detalhe['a']['data_pagamento']['tamanho'] = 8; 
				$mapa_detalhe['a']['data_pagamento']['tipo']    = 'N';
				//posicao 102-104
				$mapa_detalhe['a']['moeda']['valor']   = '009';
				$mapa_detalhe['a']['moeda']['tamanho'] = 3; 
				$mapa_detalhe['a']['moeda']['tipo']    = 'A';
                //posicao 105-112
                //verificar
				$mapa_detalhe['a']['ispb']['valor']   = $detalhe->codigo_ispb; // enviar por padrão 0
				$mapa_detalhe['a']['ispb']['tamanho'] = 8;
                $mapa_detalhe['a']['ispb']['tipo']    = 'N';
                //posicao 113-119
                $mapa_detalhe['a']['cnab113']['zeros'] = '7'; // brancos
                //posicao 120-134
				$mapa_detalhe['a']['valor_pagamento']['valor']   = funcValor($detalhe->valor,'E');
				$mapa_detalhe['a']['valor_pagamento']['tamanho'] = 15; 
				$mapa_detalhe['a']['valor_pagamento']['tipo']    = 'N';
				//posicao 135-149
				$mapa_detalhe['a']['nosso_numero']['valor']   = null; // numero atribuido pelo banco
				$mapa_detalhe['a']['nosso_numero']['tamanho'] = 15; 
				$mapa_detalhe['a']['nosso_numero']['tipo']    = 'A';
                //posicao 150-154
                $mapa_detalhe['a']['cnab150']['brancos'] = '5'; // brancos
                //posicao 155-162
				$mapa_detalhe['a']['data_efetiva']['valor']   = $detalhe->data_vencimento;
				$mapa_detalhe['a']['data_efetiva']['tamanho'] = 8; 
				$mapa_detalhe['a']['data_efetiva']['tipo']    = 'N';
				//posicao 163-177
				$mapa_detalhe['a']['valor_efetivo']['valor']   = funcValor($detalhe->valor,'E');
				$mapa_detalhe['a']['valor_efetivo']['tamanho'] = 15; 
				$mapa_detalhe['a']['valor_efetivo']['tipo']    = 'N';
				//posicao 178-195
				// verificar documento auxiliar dominios_spb.xls na pasta do sistema arquivos\arquivos_auxiliares\bacen
				$mapa_detalhe['a']['informacoes2']['valor']   = ''; // Informações a serem constadas no documento de pagamento exibida para o recebedor
				$mapa_detalhe['a']['informacoes2']['tamanho'] = 18; 
                $mapa_detalhe['a']['informacoes2']['tipo']    = 'A';
                //posicao 196-197
                $mapa_detalhe['a']['cnab196']['brancos'] = '2'; // brancos
                //posicao 198-203
				//varificar
				$mapa_detalhe['a']['numero_documento']['valor']   = $detalhe->id_doc; // Informações a serem constadas no documento de pagamento exibida para o recebedor
				$mapa_detalhe['a']['numero_documento']['tamanho'] = 6; 
                $mapa_detalhe['a']['numero_documento']['tipo']    = 'N';
                //posicao 204-217
				$mapa_detalhe['a']['numero_inscricao']['valor']   = $detalhe->cnpj_cpf;
				$mapa_detalhe['a']['numero_inscricao']['tamanho'] = 14; 
                $mapa_detalhe['a']['numero_inscricao']['tipo']    = 'N';
                //posicao 218-219
				$mapa_detalhe['a']['finalidade_doc']['valor']   = $detalhe->finalidade_doc;
				$mapa_detalhe['a']['finalidade_doc']['tamanho'] = 02; 
				$mapa_detalhe['a']['finalidade_doc']['tipo']    = 'A';
				//posicao 220-224
				$mapa_detalhe['a']['finalidade_ted']['valor']   = $detalhe->finalidade_ted;
				$mapa_detalhe['a']['finalidade_ted']['tamanho'] = 5;
                $mapa_detalhe['a']['finalidade_ted']['tipo']    = 'A';
                //posicao 225-229
                $mapa_detalhe['a']['cnab225']['brancos'] = '5'; // brancos
				//posicao 230-230
				$mapa_detalhe['a']['aviso_favorecido']['valor']   = null;
				$mapa_detalhe['a']['aviso_favorecido']['tamanho'] = 1; 
				$mapa_detalhe['a']['aviso_favorecido']['tipo']    = 'A';
				//posicao 231-240
				$mapa_detalhe['a']['ocorrencia']['valor']   = ''; //Apenas para retorno do arquivo
				$mapa_detalhe['a']['ocorrencia']['tamanho'] = 10; 
				$mapa_detalhe['a']['ocorrencia']['tipo']    = 'A';
			break; // fim segmento a
			case 'b':
				//SEGMENTO B
				//posicao 1-3
				$mapa_detalhe['b']['codigo_banco']['valor']   = $this->codigo_banco;
				$mapa_detalhe['b']['codigo_banco']['tamanho'] = 3; 
				$mapa_detalhe['b']['codigo_banco']['tipo']    = 'N';
				//posicao 4-7
				$mapa_detalhe['b']['lote_servico']['valor']   = $this->codigo_lote;
				$mapa_detalhe['b']['lote_servico']['tamanho'] = 4; 
				$mapa_detalhe['b']['lote_servico']['tipo']    = 'N';
				//posicao 8-8
				$mapa_detalhe['b']['tipo_registro']['valor']   = 3;
				$mapa_detalhe['b']['tipo_registro']['tamanho'] = 1; 
				$mapa_detalhe['b']['tipo_registro']['tipo']    = 'N';
				//posicao 9-13
				$mapa_detalhe['b']['seq_detalhe']['valor']   = $this->getSeqDetalhe();
				$mapa_detalhe['b']['seq_detalhe']['tamanho'] = 5; 
				$mapa_detalhe['b']['seq_detalhe']['tipo']    = 'N';
				//posicao 14-14
				$mapa_detalhe['b']['codigo_segmento']['valor']   = 'B'; // FIXO B
				$mapa_detalhe['b']['codigo_segmento']['tamanho'] = 1; 
				$mapa_detalhe['b']['codigo_segmento']['tipo']    = 'A';
				//posicao 15-17
				$mapa_detalhe['b']['cnab']['brancos'] = 3;
				//posicao 18-18
				$mapa_detalhe['b']['tipo_inscricao']['valor']   = $detalhe->tipo_inscricao; // 2 - CNPJ, 1 - CPF
				$mapa_detalhe['b']['tipo_inscricao']['tamanho'] = 1;
				$mapa_detalhe['b']['tipo_inscricao']['tipo']    = 'N';
				//posicao 19-32
				$mapa_detalhe['b']['numero_inscricao']['valor']   = $detalhe->cnpj_cpf;
				$mapa_detalhe['b']['numero_inscricao']['tamanho'] = 14; 
				$mapa_detalhe['b']['numero_inscricao']['tipo']    = 'N';
				//posicao 33-62	
				$mapa_detalhe['b']['endereço_empresa']['valor']   = $detalhe->endereco;
				$mapa_detalhe['b']['endereço_empresa']['tamanho'] = 30; 
				$mapa_detalhe['b']['endereço_empresa']['tipo']    = 'A';
				//posicao 63-67
				$mapa_detalhe['b']['numero']['valor']   = $detalhe->numero;
				$mapa_detalhe['b']['numero']['tamanho'] = 5; 
				$mapa_detalhe['b']['numero']['tipo']    = 'N';
				//posicao 68-82
				$mapa_detalhe['b']['complemento']['valor']   = $detalhe->complemento;
				$mapa_detalhe['b']['complemento']['tamanho'] = 15; 
				$mapa_detalhe['b']['complemento']['tipo']    = 'A';
				//posicao 83-97
				$mapa_detalhe['b']['bairro']['valor']   = $detalhe->bairro;
				$mapa_detalhe['b']['bairro']['tamanho'] = 15; 
				$mapa_detalhe['b']['bairro']['tipo']    = 'A';
				//posicao 98-117
				$mapa_detalhe['b']['cidade']['valor']   = $detalhe->cidade;
				$mapa_detalhe['b']['cidade']['tamanho'] = 20; 
				$mapa_detalhe['b']['cidade']['tipo']    = 'A';
				//posicao 118-125
				$mapa_detalhe['b']['cep']['valor']   = $detalhe->cep;
				$mapa_detalhe['b']['cep']['tamanho'] = 8; 
				$mapa_detalhe['b']['cep']['tipo']    = 'N';
				//posicao 126-127
				$mapa_detalhe['b']['estado']['valor']   = $detalhe->estado;
				$mapa_detalhe['b']['estado']['tamanho'] = 2; 
				$mapa_detalhe['b']['estado']['tipo']    = 'A';
				//posicao 128-135
				$mapa_detalhe['b']['data_vencimento']['valor']   = $detalhe->data_vencimento;
				$mapa_detalhe['b']['data_vencimento']['tamanho'] = 8; 
				$mapa_detalhe['b']['data_vencimento']['tipo']    = 'N';
				//posicao 136-150
				$mapa_detalhe['b']['valor_documento']['valor']   = funcValor($detalhe->valor,'E');
				$mapa_detalhe['b']['valor_documento']['tamanho'] = 15; 
				$mapa_detalhe['b']['valor_documento']['tipo']    = 'N';
				//posicao 151-165
				$mapa_detalhe['b']['valor_abatimento']['valor']   = $detalhe->abatimento;
				$mapa_detalhe['b']['valor_abatimento']['tamanho'] = 15; 
				$mapa_detalhe['b']['valor_abatimento']['tipo']    = 'N';
				//posicao 166-180
				$mapa_detalhe['b']['valor_desconto']['valor']   = $detalhe->desconto;
				$mapa_detalhe['b']['valor_desconto']['tamanho'] = 15; 
				$mapa_detalhe['b']['valor_desconto']['tipo']    = 'N';
				//posicao 181-195
				$mapa_detalhe['b']['valor_mora']['valor']   = funcValor($detalhe->mora,'E');
				$mapa_detalhe['b']['valor_mora']['tamanho'] = 15; 
				$mapa_detalhe['b']['valor_mora']['tipo']    = 'N';
				//posicao 196-210
				$mapa_detalhe['b']['valor_multa']['valor']   = funcValor($detalhe->multa,'E');
				$mapa_detalhe['b']['valor_multa']['tamanho'] = 15; 
				$mapa_detalhe['b']['valor_multa']['tipo']    = 'N';
				//posicao 211-225
				$mapa_detalhe['b']['codigo_favorecido']['valor']   = $detalhe->id_fornecedor;
				$mapa_detalhe['b']['codigo_favorecido']['tamanho'] = 15; 
				$mapa_detalhe['b']['codigo_favorecido']['tipo']    = 'A';
				//posicao 226-226
				$mapa_detalhe['b']['aviso']['valor']   = 0;
				$mapa_detalhe['b']['aviso']['tamanho'] = 1; 
				$mapa_detalhe['b']['aviso']['tipo']    = 'N';
				//posicao 227-232
				$mapa_detalhe['b']['codigo_ug']['valor']   = 0; // Uso exclusivo para Pagamentos de Salários dos servidores, pelo SIAPE
				$mapa_detalhe['b']['codigo_ug']['tamanho'] = 6;
				$mapa_detalhe['b']['codigo_ug']['tipo']    = 'N';
				//posicao 233-240
				$mapa_detalhe['b']['codigo_ispb']['valor']   = 0; //$detalhe->codigo_ispb - só informar quando banco não tiver codigo de compensação;
				$mapa_detalhe['b']['codigo_ispb']['tamanho'] = 8;
				$mapa_detalhe['b']['codigo_ispb']['tipo']    = 'N';
			break; // fim segmento b
			case 'j':
				//SEGMENTO J
				//posicao 1-3
				$mapa_detalhe['j']['codigo_banco']['valor']   = $this->codigo_banco;
				$mapa_detalhe['j']['codigo_banco']['tamanho'] = 3; 
				$mapa_detalhe['j']['codigo_banco']['tipo']    = 'N';
				//posicao 4-7
				$mapa_detalhe['j']['lote_servico']['valor']   = $this->codigo_lote;
				$mapa_detalhe['j']['lote_servico']['tamanho'] = 4; 
				$mapa_detalhe['j']['lote_servico']['tipo']    = 'N';
				//posicao 8-8
				$mapa_detalhe['j']['tipo_registro']['valor']   = 3;
				$mapa_detalhe['j']['tipo_registro']['tamanho'] = 1; 
				$mapa_detalhe['j']['tipo_registro']['tipo']    = 'N';
				//posicao 9-13
				$mapa_detalhe['j']['seq_detalhe']['valor']   = $this->getSeqDetalhe();
				$mapa_detalhe['j']['seq_detalhe']['tamanho'] = 5; 
				$mapa_detalhe['j']['seq_detalhe']['tipo']    = 'N';
				//posicao 14-14
				$mapa_detalhe['j']['codigo_segmento']['valor']   = 'j'; // FIXO J
				$mapa_detalhe['j']['codigo_segmento']['tamanho'] = 1; 
				$mapa_detalhe['j']['codigo_segmento']['tipo']    = 'A';
				//posicao 15-17
				//verificar
				/*Código adotado pela FEBRABAN, para identificar o tipo de movimentação enviada no arquivo. Domínio:
				'0' = Indica INCLUSÃO
				‘1’ = Indica CONSULTA
				'3' = Indica ESTORNO (somente para retorno)
				'5' = Indica ALTERAÇÃO
				‘7’ = Indica LIQUIDAÇAO
				'9' = Indica EXCLUSÃO
				*/
				$mapa_detalhe['j']['tipo_movimento']['valor']   = '0';
				$mapa_detalhe['j']['tipo_movimento']['tamanho'] = 3; 
				$mapa_detalhe['j']['tipo_movimento']['tipo']    = 'N';
				//posicao 18-61
				$mapa_detalhe['j']['codigo_barras']['valor']   = $detalhe->codigo_barras;
				$mapa_detalhe['j']['codigo_barras']['tamanho'] = 44;
				$mapa_detalhe['j']['codigo_barras']['tipo']    = 'E';
				//posicao 62-91
				$mapa_detalhe['j']['nome_cedente']['valor']   = $this->nome_cliente;
				$mapa_detalhe['j']['nome_cedente']['tamanho'] = 30;
				$mapa_detalhe['j']['nome_cedente']['tipo']    = 'A';
				//posicao 92-99	
				$mapa_detalhe['j']['data_vencimento']['valor']   = $detalhe->data_vencimento;
				$mapa_detalhe['j']['data_vencimento']['tamanho'] = 8; 
				$mapa_detalhe['j']['data_vencimento']['tipo']    = 'N';
				//posicao 100-114
				$mapa_detalhe['j']['valor_titulo']['valor']   = funcValor($detalhe->valor,'E');
				$mapa_detalhe['j']['valor_titulo']['tamanho'] = 15; 
				$mapa_detalhe['j']['valor_titulo']['tipo']    = 'N';
				//posicao 115-129
				$mapa_detalhe['j']['valor_desconto']['valor']   = ($detalhe->desconto + $detalhe->abatimento);
				$mapa_detalhe['j']['valor_desconto']['tamanho'] = 15; 
				$mapa_detalhe['j']['valor_desconto']['tipo']    = 'N';
				//posicao 130-144
				// var_dump(($detalhe->mora + $detalhe->multa));
				$mapa_detalhe['j']['valor_mora']['valor']   = ($detalhe->mora + $detalhe->multa);
				$mapa_detalhe['j']['valor_mora']['tamanho'] = 15; 
				$mapa_detalhe['j']['valor_mora']['tipo']    = 'N';
				//posicao 145-152
				$mapa_detalhe['j']['data_pagamento']['valor']   = $detalhe->data_vencimento;
				$mapa_detalhe['j']['data_pagamento']['tamanho'] = 8; 
				$mapa_detalhe['j']['data_pagamento']['tipo']    = 'N';
				//posicao 153-167
				$mapa_detalhe['j']['valor_pagamento']['valor']   = funcValor($detalhe->valor,'E');
				$mapa_detalhe['j']['valor_pagamento']['tamanho'] = 15; 
				$mapa_detalhe['j']['valor_pagamento']['tipo']    = 'N';
				//posicao 168-182
				$mapa_detalhe['j']['cnab168']['zeros'] = 15;
				//posicao 183-202
				$mapa_detalhe['j']['numero_documento']['valor']   = $detalhe->id_doc;
				$mapa_detalhe['j']['numero_documento']['tamanho'] = 20; 
				$mapa_detalhe['j']['numero_documento']['tipo']    = 'A';
				//posicao 203-215
				$mapa_detalhe['j']['cnab203']['brancos'] = 13;
				//posicao 216-230
				$mapa_detalhe['j']['nosso_numero']['valor']   = null; // numero atribuido pelo banco
				$mapa_detalhe['j']['nosso_numero']['tamanho'] = 15; 
				$mapa_detalhe['j']['nosso_numero']['tipo']    = 'A';
				//posicao 231-240
				$mapa_detalhe['j']['ocorrencias']['valor']   = null;//preenchimento por parte do banco
				$mapa_detalhe['j']['ocorrencias']['tamanho'] = 10;
				$mapa_detalhe['j']['ocorrencias']['tipo']    = 'A';
			break; // fim segmento j
			case 'j52':
				//SEGMENTO J52
				//posicao 1-3
				$mapa_detalhe['j52']['codigo_banco']['valor']   = $this->codigo_banco;
				$mapa_detalhe['j52']['codigo_banco']['tamanho'] = 3; 
				$mapa_detalhe['j52']['codigo_banco']['tipo']    = 'N';
				//posicao 4-7
				$mapa_detalhe['j52']['lote_servico']['valor']   = $this->codigo_lote;
				$mapa_detalhe['j52']['lote_servico']['tamanho'] = 4; 
				$mapa_detalhe['j52']['lote_servico']['tipo']    = 'N';
				//posicao 8-8
				$mapa_detalhe['j52']['tipo_registro']['valor']   = 3;
				$mapa_detalhe['j52']['tipo_registro']['tamanho'] = 1; 
				$mapa_detalhe['j52']['tipo_registro']['tipo']    = 'N';
				//posicao 9-13
				$mapa_detalhe['j52']['seq_detalhe']['valor']   = $this->getSeqDetalhe();
				$mapa_detalhe['j52']['seq_detalhe']['tamanho'] = 5; 
				$mapa_detalhe['j52']['seq_detalhe']['tipo']    = 'N';
				//posicao 14-14
				$mapa_detalhe['j52']['codigo_segmento']['valor']   = 'j52'; // FIXO J52
				$mapa_detalhe['j52']['codigo_segmento']['tamanho'] = 1; 
				$mapa_detalhe['j52']['codigo_segmento']['tipo']    = 'A';
				//posicao 15-17
				$mapa_detalhe['j52']['codigo_movimento']['valor']   = 9; // nove por padrão 
				$mapa_detalhe['j52']['codigo_movimento']['tamanho'] = 3;
				$mapa_detalhe['j52']['codigo_movimento']['tipo']    = 'N';
				//posicao 18-19
				//verificar
				$mapa_detalhe['j52']['identificacao_registro']['valor']   = 52;
				$mapa_detalhe['j52']['identificacao_registro']['tamanho'] = 2; 
				$mapa_detalhe['j52']['identificacao_registro']['tipo']    = 'N';
				//posicao 20-20	
				//verificar
				$mapa_detalhe['j52']['tipo_inscricao_cedente']['valor']   = $this->tipo_pessoa; // 1 - CPF, 2 - CNPJ
				$mapa_detalhe['j52']['tipo_inscricao_cedente']['tamanho'] = 1; 
				$mapa_detalhe['j52']['tipo_inscricao_cedente']['tipo']    = 'N';
				//posicao 21-35
				$mapa_detalhe['j52']['inscricao_cedente']['valor']   = $this->cnpj_cpf;
				$mapa_detalhe['j52']['inscricao_cedente']['tamanho'] = 15; 
				$mapa_detalhe['j52']['inscricao_cedente']['tipo']    = 'N';
				//posicao 36-75
				$mapa_detalhe['j52']['nome_cedente']['valor']   = $this->nome_cliente;
				$mapa_detalhe['j52']['nome_cedente']['tamanho'] = 40; 
				$mapa_detalhe['j52']['nome_cedente']['tipo']    = 'A';
				//posicao 76-76
				$mapa_detalhe['j52']['tipo_inscricao_sacado']['valor']   = $detalhe->tipo_inscricao; // 1 - CPF, 2 - CNPJ
				$mapa_detalhe['j52']['tipo_inscricao_sacado']['tamanho'] = 1; 
				$mapa_detalhe['j52']['tipo_inscricao_sacado']['tipo']    = 'N';
				//posicao 77-91	
				$mapa_detalhe['j52']['inscricao_sacado']['valor']   = $detalhe->cnpj_cpf;
				$mapa_detalhe['j52']['inscricao_sacado']['tamanho'] = 15; 
				$mapa_detalhe['j52']['inscricao_sacado']['tipo']    = 'N';
				//posicao 92-131	
				$mapa_detalhe['j52']['nome_sacado']['valor']   = $detalhe->nome_fornecedor;
				$mapa_detalhe['j52']['nome_sacado']['tamanho'] = 40; 
				$mapa_detalhe['j52']['nome_sacado']['tipo']    = 'A';
				//posicao 132-132	
				$mapa_detalhe['j52']['tipo_inscricao_banco']['valor']   = $this->getTipoIncricaoBanco();
				$mapa_detalhe['j52']['tipo_inscricao_banco']['tamanho'] = 1; 
				$mapa_detalhe['j52']['tipo_inscricao_banco']['tipo']    = 'N';
				//posicao 133-147	
				$mapa_detalhe['j52']['inscricao_banco']['valor']   = $this->getCnpjBanco();
				$mapa_detalhe['j52']['inscricao_banco']['tamanho'] = 15; 
				$mapa_detalhe['j52']['inscricao_banco']['tipo']    = 'N';
				//posicao 148-187	
				$mapa_detalhe['j52']['nome_banco']['valor']   = $this->getNomeBanco();
				$mapa_detalhe['j52']['nome_banco']['tamanho'] = 40; 
				$mapa_detalhe['j52']['nome_banco']['tipo']    = 'A';
				//posicao 188-240
				$mapa_detalhe['j52']['cnab2']['brancos'] = 53;
			break; // fim segmento j52
			case 'o':
				//SEGMENTO O
				//posicao 1-3
				$mapa_detalhe['o']['codigo_banco']['valor']   = $this->codigo_banco;
				$mapa_detalhe['o']['codigo_banco']['tamanho'] = 3; 
				$mapa_detalhe['o']['codigo_banco']['tipo']    = 'N';
				//posicao 4-7
				$mapa_detalhe['o']['lote_servico']['valor']   = $this->codigo_lote;
				$mapa_detalhe['o']['lote_servico']['tamanho'] = 4; 
				$mapa_detalhe['o']['lote_servico']['tipo']    = 'N';
				//posicao 8-8
				$mapa_detalhe['o']['tipo_registro']['valor']   = 3;
				$mapa_detalhe['o']['tipo_registro']['tamanho'] = 1; 
				$mapa_detalhe['o']['tipo_registro']['tipo']    = 'N';
				//posicao 9-13
				$mapa_detalhe['o']['seq_detalhe']['valor']   = $this->getSeqDetalhe();
				$mapa_detalhe['o']['seq_detalhe']['tamanho'] = 5; 
				$mapa_detalhe['o']['seq_detalhe']['tipo']    = 'N';
				//posicao 14-14
				$mapa_detalhe['o']['codigo_segmento']['valor']   = 'o'; // FIXO O
				$mapa_detalhe['o']['codigo_segmento']['tamanho'] = 1; 
				$mapa_detalhe['o']['codigo_segmento']['tipo']    = 'A';
				//posicao 15-15
				/*Código adotado pela FEBRABAN, para identificar o tipo de movimentação enviada no arquivo. Domínio:
				'0' = Indica INCLUSÃO
				‘1’ = Indica CONSULTA
				'3' = Indica ESTORNO (somente para retorno)
				'5' = Indica ALTERAÇÃO
				‘7’ = Indica LIQUIDAÇAO
				'9' = Indica EXCLUSÃO
				*/
				$mapa_detalhe['o']['tipo_movimento']['valor']   = '0'; // padrão 0
				$mapa_detalhe['o']['tipo_movimento']['tamanho'] = 1; 
				$mapa_detalhe['o']['tipo_movimento']['tipo']    = 'N';
				//posicao 16-17
				$mapa_detalhe['o']['codigo_movimento']['valor']   = 9; //padrao 9 bloqueado necessita de autorização do master
				$mapa_detalhe['o']['codigo_movimento']['tamanho'] = 2;
				$mapa_detalhe['o']['codigo_movimento']['tipo']    = 'N';
				//posicao 18-61
				
				$mapa_detalhe['o']['codigo_barras']['valor']   = $detalhe->codigo_barras;
				$mapa_detalhe['o']['codigo_barras']['tamanho'] = 44;
				$mapa_detalhe['o']['codigo_barras']['tipo']    = 'E';
				//posicao 62-91
				$mapa_detalhe['o']['nome_concessionaria']['valor']   = $detalhe->nome_fornecedor;
				$mapa_detalhe['o']['nome_concessionaria']['tamanho'] = 30; 
				$mapa_detalhe['o']['nome_concessionaria']['tipo']    = 'A';
				//posicao 92-99	
				$mapa_detalhe['o']['data_vencimento']['valor']   = $detalhe->data_vencimento;
				$mapa_detalhe['o']['data_vencimento']['tamanho'] = 8; 
				$mapa_detalhe['o']['data_vencimento']['tipo']    = 'N';
				//posicao 100-107
				$mapa_detalhe['o']['data_pagamento']['valor']   = $detalhe->data_vencimento;
				$mapa_detalhe['o']['data_pagamento']['tamanho'] = 8; 
				$mapa_detalhe['o']['data_pagamento']['tipo']    = 'N';
				//posicao 108-122
				$mapa_detalhe['o']['valor_pagamento']['valor']   = funcValor($detalhe->valor,'E');
				$mapa_detalhe['o']['valor_pagamento']['tamanho'] = 15; 
				$mapa_detalhe['o']['valor_pagamento']['tipo']    = 'N';
				//posicao 123-142
				$mapa_detalhe['o']['numero_documento']['valor']   = $detalhe->id_doc;
				$mapa_detalhe['o']['numero_documento']['tamanho'] = 20; 
				$mapa_detalhe['o']['numero_documento']['tipo']    = 'A';
				//posicao 143-162
				$mapa_detalhe['o']['nosso_numero']['valor']   = null; // numero atribuido pelo banco
				$mapa_detalhe['o']['nosso_numero']['tamanho'] = 20; 
				$mapa_detalhe['o']['nosso_numero']['tipo']    = 'A';
				//posicao 163-230
				$mapa_detalhe['o']['cnab1']['brancos'] = 68;
				//posicao 231-240
				$mapa_detalhe['o']['ocorrencias']['valor']   = null;//preenchimento por parte do banco
				$mapa_detalhe['o']['ocorrencias']['tamanho'] = 10;
				$mapa_detalhe['o']['ocorrencias']['tipo']    = 'A';	
			break; // fim segmento O
			case 'n':
				//SEGMENTO N
				//posicao 1-3
				$mapa_detalhe['n']['codigo_banco']['valor']   = $this->codigo_banco;
				$mapa_detalhe['n']['codigo_banco']['tamanho'] = 3; 
				$mapa_detalhe['n']['codigo_banco']['tipo']    = 'N';
				//posicao 4-7
				$mapa_detalhe['n']['lote_servico']['valor']   = $this->codigo_lote;
				$mapa_detalhe['n']['lote_servico']['tamanho'] = 4; 
				$mapa_detalhe['n']['lote_servico']['tipo']    = 'N';
				//posicao 8-8
				$mapa_detalhe['n']['tipo_registro']['valor']   = 3;
				$mapa_detalhe['n']['tipo_registro']['tamanho'] = 1; 
				$mapa_detalhe['n']['tipo_registro']['tipo']    = 'N';
				//posicao 9-13
				$mapa_detalhe['n']['seq_detalhe']['valor']   = $this->getSeqDetalhe();
				$mapa_detalhe['n']['seq_detalhe']['tamanho'] = 5; 
				$mapa_detalhe['n']['seq_detalhe']['tipo']    = 'N';
				//posicao 14-14
				$mapa_detalhe['n']['codigo_segmento']['valor']   = 'n'; // FIXO N
				$mapa_detalhe['n']['codigo_segmento']['tamanho'] = 1; 
				$mapa_detalhe['n']['codigo_segmento']['tipo']    = 'A';
				//posicao 15-15
				/*Código adotado pela FEBRABAN, para identificar o tipo de movimentação enviada no arquivo. Domínio:
				'0' = Indica INCLUSÃO
				‘1’ = Indica CONSULTA
				'3' = Indica ESTORNO (somente para retorno)
				'5' = Indica ALTERAÇÃO
				‘7’ = Indica LIQUIDAÇAO
				'9' = Indica EXCLUSÃO
				*/
				$mapa_detalhe['n']['tipo_movimento']['valor']   = '0'; // padrao 0 sempre inclusão
				$mapa_detalhe['n']['tipo_movimento']['tamanho'] = 1; 
				$mapa_detalhe['n']['tipo_movimento']['tipo']    = 'N';
				//posicao 16-17
				$mapa_detalhe['n']['codigo_movimento']['valor']   = 9; // padrao 9 precisa de liberação do master
				$mapa_detalhe['n']['codigo_movimento']['tamanho'] = 2;
				$mapa_detalhe['n']['codigo_movimento']['tipo']    = 'N';
				//posicao 18-37
				$mapa_detalhe['n']['numero_documento']['valor']   = $detalhe->id_doc;
				$mapa_detalhe['n']['numero_documento']['tamanho'] = 20; 
				$mapa_detalhe['n']['numero_documento']['tipo']    = 'A';
				//posicao 38-57
				$mapa_detalhe['n']['nosso_numero']['valor']   = null; // numero atribuido pelo banco
				$mapa_detalhe['n']['nosso_numero']['tamanho'] = 20; 
				$mapa_detalhe['n']['nosso_numero']['tipo']    = 'A';
				//posicao 58-87
				$mapa_detalhe['n']['nome_contribuinte']['valor']   = $this->nome_cliente;
				$mapa_detalhe['n']['nome_contribuinte']['tamanho'] = 30; 
				$mapa_detalhe['n']['nome_contribuinte']['tipo']    = 'A';
				//posicao 88-95
				$mapa_detalhe['n']['data_pagamento']['valor']   = $detalhe->data_vencimento;
				$mapa_detalhe['n']['data_pagamento']['tamanho'] = 8; 
				$mapa_detalhe['n']['data_pagamento']['tipo']    = 'N';
				//posicao 96-110
				$mapa_detalhe['n']['valor_pagamento']['valor']   = funcValor(($detalhe->valor + $detalhe->mora + $detalhe->multa),'E');
				$mapa_detalhe['n']['valor_pagamento']['tamanho'] = 15; 
				$mapa_detalhe['n']['valor_pagamento']['tipo']    = 'N';

				if($complemento == 'n1'){
					//var_dump($detalhe->valor, $detalhe->multa, $detalhe->mora, funcValor(($detalhe->valor + $detalhe->mora + $detalhe->multa ),'E'));
					//posicao 111-116
					$mapa_detalhe['n']['codigo_receita']['valor']   = $detalhe->codigo_receita;
					$mapa_detalhe['n']['codigo_receita']['tamanho'] = 6; 
					$mapa_detalhe['n']['codigo_receita']['tipo']    = 'A';
					//posicao 117-118
					/*
					Tipo de Identificação do Contribuinte
					Considerar todos OS TIPOS de identificação possíveis
					• CNPJ = 1
					• CPF = 2
					• NIT / PIS / PASEP = 3 (este é o código existente no CNAB que identifica PIS / PASEP)
					• CEI = 4
					• NB = 6
					• Nº do Título = 7
					• DEBCAD = 8
					• REFERÊNCIA = 9
					*/
					$mapa_detalhe['n']['tipo_contribuinte']['valor']   = $detalhe->tipo_contribuinte;
					$mapa_detalhe['n']['tipo_contribuinte']['tamanho'] = 2; 
					$mapa_detalhe['n']['tipo_contribuinte']['tipo']    = 'N';
					//posicao 119-132
					$mapa_detalhe['n']['identificacao_contribuinte']['valor']   = $detalhe->cnpj_cm;
					$mapa_detalhe['n']['identificacao_contribuinte']['tamanho'] = 14; 
					$mapa_detalhe['n']['identificacao_contribuinte']['tipo']    = 'N';
					//posicao 133-134
					$mapa_detalhe['n']['codigo_tributo']['valor']   = $this->getFormaLancamento();
					$mapa_detalhe['n']['codigo_tributo']['tamanho'] = 2; 
					$mapa_detalhe['n']['codigo_tributo']['tipo']    = 'A';
					//posicao 135-140
					$mapa_detalhe['n']['competencia']['valor']   = $detalhe->competencia;
					$mapa_detalhe['n']['competencia']['tamanho'] = 6;
					$mapa_detalhe['n']['competencia']['tipo']    = 'N';
					//posicao 141-155
					// valor previsto 
					$mapa_detalhe['n']['valor_previsto']['valor']   = funcValor($detalhe->valor,'E');
					$mapa_detalhe['n']['valor_previsto']['tamanho'] = 15; 
					$mapa_detalhe['n']['valor_previsto']['tipo']    = 'N';
					//posicao 156-170
					$mapa_detalhe['n']['outros_valores']['valor']   = funcValor($detalhe->mora,'E');
					$mapa_detalhe['n']['outros_valores']['tamanho'] = 15; 
					$mapa_detalhe['n']['outros_valores']['tipo']    = 'N';
					//posicao 171-185
					$mapa_detalhe['n']['atualizacao_monetaria']['valor']   = funcValor($detalhe->multa,'E');
					$mapa_detalhe['n']['atualizacao_monetaria']['tamanho'] = 15; 
					$mapa_detalhe['n']['atualizacao_monetaria']['tipo']    = 'N';
					//posicao 186-230
					$mapa_detalhe['n']['cnab1']['brancos'] = 45;
				}elseif($complemento == 'n2'){
					//posicao 111-116
					$mapa_detalhe['n']['codigo_receita']['valor']   = $detalhe->codigo_receita;
					$mapa_detalhe['n']['codigo_receita']['tamanho'] = 6; 
					$mapa_detalhe['n']['codigo_receita']['tipo']    = 'A';
					//posicao 117-118
					/*
					Tipo de Identificação do Contribuinte
					Considerar todos OS TIPOS de identificação possíveis
					• CNPJ = 1
					• CPF = 2
					• NIT / PIS / PASEP = 3 (este é o código existente no CNAB que identifica PIS / PASEP)
					• CEI = 4
					• NB = 6
					• Nº do Título = 7
					• DEBCAD = 8
					• REFERÊNCIA = 9
					*/
					$mapa_detalhe['n']['tipo_contribuinte']['valor']   = $detalhe->tipo_contribuinte;
					$mapa_detalhe['n']['tipo_contribuinte']['tamanho'] = 2; 
					$mapa_detalhe['n']['tipo_contribuinte']['tipo']    = 'N';
					//posicao 119-132
					$mapa_detalhe['n']['identificacao_contribuinte']['valor']   = $detalhe->cnpj_cm;
					$mapa_detalhe['n']['identificacao_contribuinte']['tamanho'] = 14; 
					$mapa_detalhe['n']['identificacao_contribuinte']['tipo']    = 'N';
					//posicao 133-134
					/*Código de Identificação do Tributo
					Sugestão: Utilizar os mesmos códigos de Forma de Lançamento
					Tributos Federais
					• ‘16’ = Tributo - DARF Normal
					• ‘18’ = Tributo - DARF Simples
					• ‘17’ = Tributo - GPS (Guia da Previdência Social)
					• ‘21’ = Tributo – DARJ
					• ‘25’ = Tributo – IPVA
					• ‘26’ = Tributo – Licenciamento
					• ‘27’ = Tributo – DPVAT
					Tributos Estaduais:
					• ‘22’ = Tributo - GARE-SP ICMS
					• ‘23’ = Tributo - GARE-SP DR
					• ‘24’ = Tributo - GARE-SP ITCMD Tributos Municipais:
					*/
					// var_dump($this->getFormaLancamento());
					$mapa_detalhe['n']['codigo_tributo']['valor']   = $this->getFormaLancamento();
					$mapa_detalhe['n']['codigo_tributo']['tamanho'] = 2; 
					$mapa_detalhe['n']['codigo_tributo']['tipo']    = 'A';
					//posicao 135-142
					$mapa_detalhe['n']['periodo_apuracao']['valor']   = $detalhe->data_vencimento;
					$mapa_detalhe['n']['periodo_apuracao']['tamanho'] = 8;
					$mapa_detalhe['n']['periodo_apuracao']['tipo']    = 'N';
					//posicao 143-159
					$mapa_detalhe['n']['numero_referencia']['valor']   = $detalhe->numero_referencia;
					$mapa_detalhe['n']['numero_referencia']['tamanho'] = 17;
					$mapa_detalhe['n']['numero_referencia']['tipo']    = 'N';
					//posicao 160-174
					$mapa_detalhe['n']['valor_principal']['valor']   = funcValor($detalhe->valor,'E');
					$mapa_detalhe['n']['valor_principal']['tamanho'] = 15; 
					$mapa_detalhe['n']['valor_principal']['tipo']    = 'N';
					//posicao 175-189
					$mapa_detalhe['n']['multa']['valor']   = funcValor($detalhe->multa,'E');
					$mapa_detalhe['n']['multa']['tamanho'] = 15; 
					$mapa_detalhe['n']['multa']['tipo']    = 'N';
					//posicao 190-204
					$mapa_detalhe['n']['juros']['valor']   = funcValor($detalhe->mora,'E');
					$mapa_detalhe['n']['juros']['tamanho'] = 15; 
					$mapa_detalhe['n']['juros']['tipo']    = 'N';
					//posicao 205-212
					$mapa_detalhe['n']['data_vencimento']['valor']   = $detalhe->data_vencimento;
					$mapa_detalhe['n']['data_vencimento']['tamanho'] = 8; 
					$mapa_detalhe['n']['data_vencimento']['tipo']    = 'N';
					//posicao 213-230
					$mapa_detalhe['n']['cnab1']['brancos'] = 18;
				}elseif($complemento == 'n3'){
					//posicao 111-116
					$mapa_detalhe['n']['codigo_receita']['valor']   = $detalhe->codigo_receita;
					$mapa_detalhe['n']['codigo_receita']['tamanho'] = 6; 
					$mapa_detalhe['n']['codigo_receita']['tipo']    = 'A';
					//posicao 117-118
					//posicao 117-118
					/*
					Tipo de Identificação do Contribuinte
					Considerar todos OS TIPOS de identificação possíveis
					• CNPJ = 1
					• CPF = 2
					• NIT / PIS / PASEP = 3 (este é o código existente no CNAB que identifica PIS / PASEP)
					• CEI = 4
					• NB = 6
					• Nº do Título = 7
					• DEBCAD = 8
					• REFERÊNCIA = 9
					*/
					$mapa_detalhe['n']['tipo_contribuinte']['valor']   = $detalhe->tipo_contribuinte;
					$mapa_detalhe['n']['tipo_contribuinte']['tamanho'] = 2; 
					$mapa_detalhe['n']['tipo_contribuinte']['tipo']    = 'N';
					//posicao 119-132
					$mapa_detalhe['n']['identificacao_contribuinte']['valor']   = $detalhe->cnpj_cm;
					$mapa_detalhe['n']['identificacao_contribuinte']['tamanho'] = 14; 
					$mapa_detalhe['n']['identificacao_contribuinte']['tipo']    = 'N';
					//posicao 133-134
					$mapa_detalhe['n']['codigo_tributo']['valor']   = $this->getFormaLancamento(17);
					$mapa_detalhe['n']['codigo_tributo']['tamanho'] = 2; 
					$mapa_detalhe['n']['codigo_tributo']['tipo']    = 'A';
					//posicao 135-142
					$mapa_detalhe['n']['periodo_apuracao']['valor']   = $detalhe->competencia;
					$mapa_detalhe['n']['periodo_apuracao']['tamanho'] = 8;
					$mapa_detalhe['n']['periodo_apuracao']['tipo']    = 'N';
					//posicao 143-157
					$mapa_detalhe['n']['receita_bruta']['valor']   = funcValor($detalhe->valor,'E');
					$mapa_detalhe['n']['receita_bruta']['tamanho'] = 15;
					$mapa_detalhe['n']['receita_bruta']['tipo']    = 'N';
					//posicao 158-164
					$mapa_detalhe['n']['percentual_receita']['valor']   = $detalhe->percentual_receita;
					$mapa_detalhe['n']['percentual_receita']['tamanho'] = 15; 
					$mapa_detalhe['n']['percentual_receita']['tipo']    = 'N';
					//posicao 165-179
					$mapa_detalhe['n']['valor_principal']['valor']   = funcValor($detalhe->valor,'E');
					$mapa_detalhe['n']['valor_principal']['tamanho'] = 15; 
					$mapa_detalhe['n']['valor_principal']['tipo']    = 'N';
					//posicao 180-194
					$mapa_detalhe['n']['multa']['valor']   = funcValor($detalhe->multa,'E');
					$mapa_detalhe['n']['multa']['tamanho'] = 15; 
					$mapa_detalhe['n']['multa']['tipo']    = 'N';
					//posicao 195-209
					$mapa_detalhe['n']['juros']['valor']   = funcValor($detalhe->mora,'E');
					$mapa_detalhe['n']['juros']['tamanho'] = 15; 
					$mapa_detalhe['n']['juros']['tipo']    = 'N';
					//posicao 210-230
					$mapa_detalhe['n']['cnab1']['brancos'] = 21;
				}elseif($complemento == 'n4'){
					//posicao 111-116
					$mapa_detalhe['n']['codigo_receita']['valor']   = $detalhe->codigo_receita;
					$mapa_detalhe['n']['codigo_receita']['tamanho'] = 6; 
					$mapa_detalhe['n']['codigo_receita']['tipo']    = 'A';
					//posicao 117-118
					//posicao 117-118
					/*
					Tipo de Identificação do Contribuinte
					Considerar todos OS TIPOS de identificação possíveis
					• CNPJ = 1
					• CPF = 2
					• NIT / PIS / PASEP = 3 (este é o código existente no CNAB que identifica PIS / PASEP)
					• CEI = 4
					• NB = 6
					• Nº do Título = 7
					• DEBCAD = 8
					• REFERÊNCIA = 9
					*/
					$mapa_detalhe['n']['tipo_contribuinte']['valor']   = $detalhe->tipo_contribuinte;
					$mapa_detalhe['n']['tipo_contribuinte']['tamanho'] = 2; 
					$mapa_detalhe['n']['tipo_contribuinte']['tipo']    = 'N';
					//posicao 119-132
					$mapa_detalhe['n']['identificacao_contribuinte']['valor']   = $detalhe->cnpj_cm;
					$mapa_detalhe['n']['identificacao_contribuinte']['tamanho'] = 14; 
					$mapa_detalhe['n']['identificacao_contribuinte']['tipo']    = 'N';
					//posicao 133-134
					$mapa_detalhe['n']['codigo_tributo']['valor']   = $this->getFormaLancamento();
					$mapa_detalhe['n']['codigo_tributo']['tamanho'] = 2; 
					$mapa_detalhe['n']['codigo_tributo']['tipo']    = 'A';
					//posicao 135-142
					$mapa_detalhe['n']['data_vencimento']['valor']   = $detalhe->data_vencimento;
					$mapa_detalhe['n']['data_vencimento']['tamanho'] = 8; 
					$mapa_detalhe['n']['data_vencimento']['tipo']    = 'N';
					//posicao 143-54
					$mapa_detalhe['n']['inscricao_estadual']['valor']   = $detalhe->ie_cm;
					$mapa_detalhe['n']['inscricao_estadual']['tamanho'] = 12;
					$mapa_detalhe['n']['inscricao_estadual']['tipo']    = 'N';
					//posicao 155-167
					$mapa_detalhe['n']['divida_ativa']['valor']   = $detalhe->divida_ativa;
					$mapa_detalhe['n']['divida_ativa']['tamanho'] = 13;
					$mapa_detalhe['n']['divida_ativa']['tipo']    = 'N';
					// posicao 168-173
					$mapa_detalhe['n']['periodo_apuracao']['valor']   = $detalhe->competencia;
					$mapa_detalhe['n']['periodo_apuracao']['tamanho'] = 6;
					$mapa_detalhe['n']['periodo_apuracao']['tipo']    = 'N';
					//posicao 174-186
					$mapa_detalhe['n']['numero_parcela']['valor']   = $detalhe->numero_parcela;
					$mapa_detalhe['n']['numero_parcela']['tamanho'] = 13; 
					$mapa_detalhe['n']['numero_parcela']['tipo']    = 'N';
					//posicao 187-201
					$mapa_detalhe['n']['valor_receita']['valor']   = funcValor($detalhe->valor,'E');
					$mapa_detalhe['n']['valor_receita']['tamanho'] = 15;
					$mapa_detalhe['n']['valor_receita']['tipo']    = 'N';
					//posicao 202-215
					$mapa_detalhe['n']['juros']['valor']   = funcValor($detalhe->mora,'E');
					$mapa_detalhe['n']['juros']['tamanho'] = 14; 
					$mapa_detalhe['n']['juros']['tipo']    = 'N';
					//posicao 216-229
					$mapa_detalhe['n']['multa']['valor']   = funcValor($detalhe->multa,'E');
					$mapa_detalhe['n']['multa']['tamanho'] = 14; 
					$mapa_detalhe['n']['multa']['tipo']    = 'N';
					//posicao 230-230
					$mapa_detalhe['n']['cnab1']['brancos'] = 1;
				}
				//posicao 231-240
				$mapa_detalhe['n']['ocorrencias']['valor']   = null;//preenchimento por parte do banco
				$mapa_detalhe['n']['ocorrencias']['tamanho'] = 10;
				$mapa_detalhe['n']['ocorrencias']['tipo']    = 'A';
			break; // fim segmento N
			default:
				//padrao não implementado
			break; // fim default
		}
		$this->setMapaDetalhe($mapa_detalhe)->buitString('detalhe');
	}
}	