<?php

abstract class RemessaLote extends RemessaArquivo{
	protected $codigo_lote, $lotes, $mapa_lote, $tipo_lote, $tipo_operacao, $tipo_servico, $tipo_pagamento, $forma_lancamento, $versao_layout, $linhas_lote, $valores_lote;
	function __construct($controller, $cliente = null)
	{
		if(is_array($cliente)){
			$cliente = convertToObject($cliente);
		}
		parent::__construct($controller, $cliente);
		$this->setCodigoLote(1); // atribui 1 primeiro codigo de lote para a remessa.
		
	}

	function getCodigoLote(){
		return $this->codigo_lote;
	}

	function setCodigoLote($codigo_lote){
		$this->codigo_lote = $codigo_lote;
	}

	function getTipoLote(){
		return $this->tipo_lote;
	}

	function setTipoLote($tipo_lote){
		$this->tipo_lote = $tipo_lote;
	}

	function getVersaoLayout(){
		return $this->versao_layout;
	}

	function setVersaoLayout($versao_layout){
		$this->versao_layout = $versao_layout;
	}

	function getTipoOperacao(){
		return $this->tipo_operacao;
	}

	function setTipoOperacao($tipo_operacao){
		$this->tipo_operacao = $tipo_operacao;
	}

	function getTipoServico(){
		return $this->tipo_servico;
	}

	function setTipoServico($tipo_servico){
		$this->tipo_servico = $tipo_servico;
	}

	function getTipoPagamento(){
		return $this->tipo_pagamento;
	}

	function setTipoPagamento($tipo_pagamento){
		$this->tipo_pagamento = $tipo_pagamento;
	}

	function getLinhasLote(){
		return $this->linhas_lote;
	}

	function setLinhasLote($linhas_lote){
		$this->linhas_lote = $linhas_lote;
	}

	function getValoresLote(){
		return $this->valores_lote;
	}

	function setValoresLote($valores_lote){
		$this->valores_lote = $valores_lote;
	}

	function getFormaLancamento(){
		return $this->forma_lancamento;
	}

	function setFormaLancamento($forma_lancamento){
		$this->forma_lancamento = $forma_lancamento;
	}

	function getLotes(){
		return $this->lotes;
	}

	function setLotes($lotes){
		$this->lotes = $lotes;
	}

	function getMapaLote(){
		return $this->mapa_lote;
	}
	
	function setMapaLote($mapa, $header = true){
		if($mapa){
			if($header){
				$this->mapa_lote['header'] = convertToObject($mapa);
			}else{
				$this->mapa_lote['trailer'] = convertToObject($mapa);
			}
		}
		return $this;
	}
}