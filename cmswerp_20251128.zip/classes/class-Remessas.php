<?php
// class Remessas extends RemessaArquivo{
// 	private 
// 		$registros,
//         $remessas;
        
	
// 	function __construct($controller, $registros = null){
// 		parent::__construct($controller);
//         if($registros){
//             $this->setRegistros($registros);
//         }
// 	}

//     function setRegistros($registros){
//         $this->registros = $registros;
//     }

//     function getRegistros(){

//     }

//     function separarEmpresas($registros, $delRegistros = true){
//         //separa as despesas por empresa
//         foreach($this->registros as $key => $value){
//             $i = $value->id_cm;
//             $this->remessas[$i][] = $value;
//         }

//         if($delRegistros){
//             $this->setRegistros(null);
//         }
//     }

//     function processaRegistros($registros = null){
//         if($registros){
//             $this->registros = $registros;
//         }

//         if($this->registros) {
//             $this->separarEmpresas($this->registros);
//         }else{
//             return false;
//         }
//     }
// }