<?php
	/**
	* Julio
	* Classe para log de eventos no sistema
	*/
class Report{
	protected $data_hora_atual, $log, $obj_movimento, $obj_nf, $controller;
	function __construct( $controller, $parametros = null){
		$this->controller         = $controller;
		$this->data_hora_atual    = $this->controller->data_hora_atual;
		$this->obj_nf             = $this->controller->load_model('notas-fiscais/notas-fiscais', true);
		$controller_movimento     = new MainController(null, 'tarifador', false);
		$db_movimento['db_name']  = DB_NAME_MOVIMENTO;
		$this->obj_movimento      = $controller_movimento->load_model('movimento/movimento', true);
		$this->obj_movimento->setDb(new Db($db_movimento));
		//Objeto com acesso a base de dados de cadastros;
	}

	function performance($tipo, $dia, $codigo_produto, $data_limite){
		$result    = null;
		$dados 	   = null;
		$total_dia = null;
		$media	   = null;
		$total_transacoes = null;	 
		if('mes' == $tipo){
			exit;
			$dados = json_decode($this->obj_movimento->getAllTransacoesByDiaMes($dia, $codigo_produto, $data_limite));
			if($dados){
				$total_dia = json_decode($this->obj_movimento->getTotalTransacoesByDia($codigo_produto, $data_limite));
				exit;
				if($total_dia){
					foreach ($dados as $key => $value) {
						$total_transacoes += $value->total_transacoes; 
					}
					$media = ($total_transacoes / count($dados));
					$result = (abs(1-($media / $total_dia[0]->total_transacoes))*100);
				}else{
					$this->controller->log->writeLog('Erro ao gerar dados report mes '.$codigo_produto.' - '.$tipo.' - '.$dia.' - '.$this->data_hora_atual->format('Y-m-d'));
				}
			}else{
				$this->controller->log->writeLog('Erro ao gerar dados report mes '.$codigo_produto.' - '.$tipo.' - '.$dia.' - '.$this->data_hora_atual->format('Y-m-d'));
			}
		}elseif('semana' == $tipo){
			$dados = json_decode($this->obj_movimento->getAllTransacoesByDiaSemana($dia, $codigo_produto, $data_limite));
			if($dados){
				$total_dia = json_decode($this->obj_movimento->getTotalTransacoesByDia($codigo_produto, $data_limite));
				if($total_dia){
					foreach ($dados as $key => $value) {
						$total_transacoes += $value->total_transacoes; 
					}
					$media  = ($total_transacoes / count($dados));
					$result = (abs(1-($media / $total_dia[0]->total_transacoes))*100);
				}else{
					$this->controller->log->writeLog('Erro ao gerar dados report mes '.$codigo_produto.' - '.$tipo.' - '.$dia.' - '.$this->data_hora_atual->format('Y-m-d'));
				}
			}else{
				$this->controller->log->writeLog('Erro ao gerar dados report mes '.$codigo_produto.' - '.$tipo.' - '.$dia.' - '.$this->data_hora_atual->format('Y-m-d'));
			}
		}
		return $result;
	}

	function countTransacoesTask($codigo_produto, $codigo_indicador, $data_object){
		$param['quantidade'] = null;
		$ano = $data_object->format('Y');
		$mes = $data_object->format('m');
		if($codigo_produto == 'ADM0001'){
			$dados_mov_aux = json_decode($this->obj_nf->getTotalMovAuxPorProduto($codigo_produto, $ano, $mes));
			if(isset($dados_mov_aux[0]->transacoes)){
				$param['quantidade'] += $dados_mov_aux[0]->transacoes;	
			}else{
				$param['quantidade'] += 0;
			}

			$nf_adm = json_decode($this->obj_nf->getTotalNFPorProduto($codigo_produto, $ano,  $mes));
			if($nf_adm){
				$param['quantidade'] += $nf_adm[0]->transacoes;
			}else{
				$param['quantidade'] += 0;	
			}

		}elseif($codigo_produto == 'ECS0001'){
			
			$dados_mov_aux = json_decode($this->obj_nf->getTotalNFPorProduto($codigo_produto, $ano, $mes));
			$param['quantidade'] += $dados_mov_aux[0]->transacoes;

		}else{
			$dados = json_decode($this->obj_movimento->countTransacoesTask($ano, $mes, $codigo_produto));
			if($dados){
				foreach ($dados as $key => $value) {
					$param['quantidade'] += $value->transacoes;
				}
			}else{
				$param['quantidade'] = 0;
			}
		}

		$param['codigo'] = $codigo_indicador;
		$param['tipo']   = 'indicador';
		$param['ano'] 	 = $ano;
		$param['mes'] 	 = $mes;
		// echo $param['quantidade'].'<br>';
		return json_encode($param);
	}
}
