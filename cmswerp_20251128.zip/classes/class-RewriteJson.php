<?php

	/**
	* Julio
	* Classe para log de eventos no sistema
	*/
    class RewriteJson{
        protected $json, $codigo_produto;
        function __construct(){
        }

        function setJson( $json ){
            $this->json = $json;
            return $this;
        }

        function setCodigo( $codigo_produto ){
            $this->codigo_produto = $codigo_produto;
            return $this;
        }

        function RewriteMqDefault( $tipo = 'tarifacao' ){
            $this->json->produto = $this->codigo_produto;
            if($tipo != 'status'){
                switch ($this->codigo_produto){
                    case 'FSP0001':
                        $this->json->modulo  = 'STR0001';
                    break;
                    case 'SOE0001':
                        if(isset($this->json->modulo) && !empty($this->json->modulo)){
                            switch ($this->json->modulo){
                                case 'MEL0001':
                                    $this->json->modulo  = 'SOE0010';
                                break;
                                case 'MEL0002':
                                    $this->json->modulo  = 'SOE0010';
                                break;
                                case 'MEL0004':
                                    // SOE0011 extinto depois da mudança de cobrança
                                    // $this->json->modulo  = 'SOE0011';
                                    $this->json->modulo  = 'SOE0037';
                                break;
                                case 'MEL0005':
                                    $this->json->modulo  = 'SOE0014';
                                break;
                                case 'MEL0006':
                                    $this->json->modulo  = 'SOE0015';
                                break;
                                case 'MEL0007':
                                    $this->json->modulo  = 'SOE0016';
                                break;
                                case 'MEL0008':
                                    $this->json->modulo  = 'SOE0017';
                                break;
                            }
                        }else{
                            $this->json->modulo  = 'ERR0001';
                        }
                    break;
                    case 'SPB0001':
                        if(isset($this->json->modulo) && !empty($this->json->modulo)){
                            switch ($this->json->modulo){
                                case 'MEL0001':
                                    $this->json->modulo  = 'SPB0010';
                                break;
                                case 'MEL0002':
                                    $this->json->modulo  = 'SPB0011';
                                break;
                                case 'MEL0005':
                                    $this->json->modulo  = 'SOE0014';
                                break;
                                case 'MEL0006':
                                    $this->json->modulo  = 'SOE0015';
                                break;
                                case 'MEL0007':
                                    $this->json->modulo  = 'SOE0016';
                                break;
                                case 'MEL0008':
                                    $this->json->modulo  = 'SOE0017';
                                break;
                            }
                        }else{
                            $this->json->modulo  = 'ERR0001';
                        }
                    break;
                    case 'COR0001':
                        switch ($this->json->modulo) {
                            case 'COR0017':
                                switch ($periodo) {
                                    case 'manha':
                                        $this->json->modulo  = 'COR0017';
                                        break;
                                    case 'tarde':
                                        $this->json->modulo  = 'COR0018';
                                        break;
                                    case 'noite':
                                        $this->json->modulo  = 'COR0019';
                                        break;
                                    case 'madrugada':
                                        $this->json->modulo  = 'COR0020';
                                        break;
                                    default:
                                        $this->json->erro_msg = 'PERIODO PIX DESCONHECIDO CREDITO COD: 307 REWRITE';
                                        break;
                                }
                                break;
                            case 'COR0021':
                                switch ($periodo) {
                                    case 'manha':
                                        $this->json->modulo  = 'COR0021';
                                        break;
                                    case 'tarde':
                                        $this->json->modulo  = 'COR0022';
                                        break;
                                    case 'noite':
                                        $this->json->modulo  = 'COR0023';
                                        break;
                                    case 'madrugada':
                                        $this->json->modulo  = 'COR0024';
                                        break;
                                    default:
                                        $this->json->erro_msg = 'PERIODO PIX DESCONHECIDO DEBITO COD: 307 REWRITE';
                                        break;
                                }
                                break;
        
                            default:
                                $this->json->erro_msg = 'MODULO CORNER FULL PIX DESCONHECIDO cCOD: 307 REWRITE';
                                break;
                        }
                        break;
                }
            }
            $this->json->erro_msg = 'Teste erro';
            return $this->json;
        }

        function RewriteMqEspecial(){
            $this->json->erro_msg = NULL;
            if (isset($this->json->data) && isset($this->json->hora)) {
                $obj_date = new DateTime($this->json->data . ' ' . $this->json->hora);
                $periodo = $this->checkData($obj_date);
                $this->json->produto = $this->codigo_produto;
            } else {
                $this->json->erro_msg = 'DATA OU HORA NÃO ESPECIFICADA PARA TRANSAÇÃO PIX, CLIENTE ISPB: ' . $this->json->ispb . ' PRODUTO: ' . $this->json->produto . ' MODULO: ' . $this->json->modulo;
                return $this->json;
            }
            switch ($this->codigo_produto){
                case 'FSP0001':
                    switch ($periodo) {
                        case 'manha':
                            if($this->json->modulo == 'MEL0023'){
                                $this->json->modulo  = 'PIX0010';
                            }else{
                                $this->json->modulo  = 'PIX0014';
                            }
                        break;
                        case 'tarde':
                            if($this->json->modulo == 'MEL0023'){
                                $this->json->modulo  = 'PIX0011';
                            }else{
                                $this->json->modulo  = 'PIX0015';
                            }
                        break;
                        case 'noite':
                            if($this->json->modulo == 'MEL0023'){
                                $this->json->modulo  = 'PIX0012';
                            }else{
                                $this->json->modulo  = 'PIX0016';
                            }
                        break;
                        case 'madrugada':
                            if($this->json->modulo == 'MEL0023'){
                                $this->json->modulo  = 'PIX0013';
                            }else{
                                $this->json->modulo  = 'PIX0017';
                            }
                        break;
                    }
                break;
                case 'SOE0001':
                    switch ($periodo) {
                        case 'manha':
                            if($this->json->modulo == 'MEL0023'){
                                $this->json->modulo  = 'SOE0018';
                            }else{
                                $this->json->modulo  = 'SOE0022';
                            }
                        break;
                        case 'tarde':
                            if($this->json->modulo == 'MEL0023'){
                                $this->json->modulo  = 'SOE0019';
                            }else{
                                $this->json->modulo  = 'SOE0023';
                            }
                        break;
                        case 'noite':
                            if($this->json->modulo == 'MEL0023'){
                                $this->json->modulo  = 'SOE0020';
                            }else{
                                $this->json->modulo  = 'SOE0024';
                            }
                        break;
                        case 'madrugada':
                            if($this->json->modulo == 'MEL0023'){
                                $this->json->modulo  = 'SOE0021';
                            }else{
                                $this->json->modulo  = 'SOE0025';
                            }
                        break;
                    }
                break;
                case 'SPB0001':
                    switch ($periodo) {
                        case 'manha':
                            if($this->json->modulo == 'MEL0023'){
                                $this->json->modulo  = 'SPB0014';
                            }else{
                                $this->json->modulo  = 'SPB0018';
                            }
                        break;
                        case 'tarde':
                            if($this->json->modulo == 'MEL0023'){
                                $this->json->modulo  = 'SPB0015';
                            }else{
                                $this->json->modulo  = 'SPB0019';
                            }
                        break;
                        case 'noite':
                            if($this->json->modulo == 'MEL0023'){
                                $this->json->modulo  = 'SPB0016';
                            }else{
                                $this->json->modulo  = 'SPB0020';
                            }
                        break;
                        case 'madrugada':
                            if($this->json->modulo == 'MEL0023'){
                                $this->json->modulo  = 'SPB0017';
                            }else{
                                $this->json->modulo  = 'SPB0021';
                            }
                        break;
                    }
                break;
                case 'SPI0001':
                    switch ($periodo) {
                        case 'manha':
                            if($this->json->modulo == 'MEL0023'){
                                $this->json->modulo  = 'SPI0010';
                            }else{
                                $this->json->modulo  = 'SPI0014';
                            }
                        break;
                        case 'tarde':
                            if($this->json->modulo == 'MEL0023'){
                                $this->json->modulo  = 'SPI0011';
                            }else{
                                $this->json->modulo  = 'SPI0015';
                            }
                        break;
                        case 'noite':
                            if($this->json->modulo == 'MEL0023'){
                                $this->json->modulo  = 'SPI0012';
                            }else{
                                $this->json->modulo  = 'SPI0016';
                            }
                        break;
                        case 'madrugada':
                            if($this->json->modulo == 'MEL0023'){
                                $this->json->modulo  = 'SPI0013';
                            }else{
                                $this->json->modulo  = 'SPI0017';
                            }
                        break;
                    }
                break;
                case 'COR0001':
                switch ($this->json->modulo) {
                    case 'COR0017':
                        switch ($periodo) {
                            case 'manha':
                                $this->json->modulo  = 'COR0017';
                            break;
                            case 'tarde':
                                $this->json->modulo  = 'COR0018';
                            break;
                            case 'noite':
                                $this->json->modulo  = 'COR0019';
                            break;
                            case 'madrugada':
                                $this->json->modulo  = 'COR0020';
                            break;
                            default:
                                $this->json->erro_msg = 'PERIODO PIX DESCONHECIDO CREDITO COD: 307 REWRITE';
                            break;
                        }
                    break;
                    case 'COR0021':
                        switch ($periodo) {
                            case 'manha':
                                $this->json->modulo  = 'COR0021';
                            break;
                            case 'tarde':
                                $this->json->modulo  = 'COR0022';
                            break;
                            case 'noite':
                                $this->json->modulo  = 'COR0023';
                            break;
                            case 'madrugada':
                                $this->json->modulo  = 'COR0024';
                            break;
                            default:
                                $this->json->erro_msg = 'PERIODO PIX DESCONHECIDO DEBITO COD: 307 REWRITE';
                            break;
                        }
                    break;
                    default:
                        $this->json->erro_msg = 'MODULO CORNER FULL PIX DESCONHECIDO cCOD: 307 REWRITE';
                    break;
                }
                break;
            }
            return $this->json;
        }

        function checkData( $data ){
            $periodo = null;
            if($data->format('Hi') >= '0600' && $data->format('Hi') < '1200'){
                $periodo = 'manha';
            }elseif($data->format('Hi') >= '1200' && $data->format('Hi') < '1530'){
                $periodo = 'tarde';
            }elseif($data->format('Hi') >= '1530' && $data->format('Hi') < '2200'){
                $periodo = 'noite';
            }elseif($data->format('Hi') >= '2200' && $data->format('Hi') < '0600'){
                $periodo = 'madrugada';
            }else{
                $periodo = 'madrugada';
            }
            return $periodo;
        }
    }


