<?php
	/**
	* Julio
	* Classe para log de eventos no sistema
	*/
class Rh extends Main{
	function __construct($controller, $parametros = null){
        parent::__construct($controller);
	}
}
