<?php
	ini_set('memory_limit', '1500000M');
	ini_set("pcre.backtrack_limit", "3000000");
	class RhPonto extends Main{
		/* versao antiga */
		protected
			$error = false,
			$error_msg,
			$retorno,
			/* versao nova */
			$user_model,
			$dicionario,
			$ponto_model,
			$marcacoes_ocorrencia,
			$obj_ged;
		public
			$user,
			$feriados,
			$dias_jornada,
			$jornadas,
			$ultimo_fechamento,
			$saldo_anterior,
			$resumo_jornada,
			$data_inicio,
			$data_fim,
			$data_search_ini,
			$data_search_fim,
			$matriz_horas,
			$mapa_ocorrencias,
			$dias_ocorrencias,
			// matrizes 
			$matriz_marcacoes,
			$calendario,
			$matriz_calendario,
			$mapa_registros,
			$marcacoes_ponto,
			$marcacoes_extra,
			$mapa_marcacoes,
			$dias_jornadas;

		function __construct($controller, $user_id = null)
		{
			$this->setMapaOcorrencias();
			$this->ponto_model = $controller->load_model('ponto/ponto', true);
			$this->user_model = $controller->load_model('usuarios/usuarios', true);
			$this->obj_ged = $controller->load_model('ged/ged', true);
			if ($user_id) {
				$this->setPontoUser($user_id);
			}
			parent::__construct($controller);
			$this->setNotificacion();
		}

		function setMapaOcorrencias()
		{
			$this->mapa_ocorrencias = array(
				'B01' => array(
					'fonte_ocorrencia' => 'R',
					'tipo_ocorrencia' => '1',
					'tipo_abono' => 'ponto',
					'texto' => 'ENTRADA',
				),
				'B02' => array(
					'fonte_ocorrencia' => 'R',
					'tipo_ocorrencia' => '1',
					'tipo_abono' => 'ponto',
					'texto' => 'SAIDA ALMOÇO',
				),
				'B03' => array(
					'fonte_ocorrencia' => 'R',
					'tipo_ocorrencia' => '1',
					'tipo_abono' => 'ponto',
					'texto' => 'RETORNO ALMOÇO',
				),
				'B04' => array(
					'fonte_ocorrencia' => 'R',
					'tipo_ocorrencia' => '1',
					'tipo_abono' => 'ponto',
					'texto' => 'SAIDA',
				),
				'B05' => array(
					'fonte_ocorrencia' => 'R',
					'tipo_ocorrencia' => '1',
					'tipo_abono' => 'pausa',
					'texto' => 'INICIO PAUSA',
				),
				'B06' => array(
					'fonte_ocorrencia' => 'R',
					'tipo_ocorrencia' => '1',
					'tipo_abono' => 'pausa',
					'texto' => 'FIM PAUSA',
				),
				'B07' => array(
					'fonte_ocorrencia' => 'R',
					'tipo_ocorrencia' => '1',
					'tipo_abono' => 'extra',
					'texto' => 'ENTRADA EXTRA',
				),
				'B08' => array(
					'fonte_ocorrencia' => 'R',
					'tipo_ocorrencia' => '1',
					'tipo_abono' => 'extra',
					'texto' => 'SAIDA EXTRA',
				),
				'A1' => array(
					'tipo_abono' => 'dias',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '1',
					'texto' => 'LICENÇA MATERNIDADE - 120 DIAS',
				),
				'A2' => array(
					'tipo_abono' => 'dias',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '2',
					'texto' => 'ATESTADO DIAS',
				),
				'A3' => array(
					'tipo_abono' => 'horas',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '3',
					'texto' => 'ATESTADO HORAS',
				),
				'A4' => array(
					'tipo_abono' => 'horas',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '4',
					'texto' => 'PERCURSO',
				),
				'A5' => array(
					'tipo_abono' => 'dias',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '5',
					'texto' => 'FALTA ABONADA PELO SUPERIOR',
				),
				'A6' => array(
					'tipo_abono' => 'dias',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '6',
					'texto' => 'FOLGA ESCALADA',
				),
				'A7' => array(
					'tipo_abono' => 'dias',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '7',
					'texto' => 'VIAGEM',
				),
				'A8' => array(
					'tipo_abono' => 'dias',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '8',
					'texto' => 'ERRO DE SISTEMA',
				),
				'A9' => array(
					'tipo_abono' => 'horas',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '9',
					'texto' => 'HORA EXTRA',
				),
				'A10' => array(
					'tipo_abono' => 'horas',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '10',
					'texto' => 'REUNIÃO EXTERNA',
				),
				'A11' => array(
					'tipo_abono' => 'dias',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '11',
					'texto' => 'LICENÇA PATERNIDADE',
				),
				'A12' => array(
					'tipo_abono' => 'horas',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '12',
					'texto' => 'LICENÇA MATERNINDADE',
				),
				'A13' => array(
					'tipo_abono' => 'dias',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '13',
					'texto' => 'AFASTAMENTO INSS',
				),
				'A14' => array(
					'tipo_abono' => 'dias',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '14',
					'texto' => 'LICENÇA OBITO PAIS',
				),
				'A15' => array(
					'tipo_abono' => 'dias',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '15',
					'texto' => 'LICENÇA OBITO FILHOS',
				),
				'A16' => array(
					'tipo_abono' => 'dias',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '16',
					'texto' => 'LICENÇA OBITO AVÓS',
				),
				'A17' => array(
					'tipo_abono' => 'dias',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '17',
					'texto' => 'LICENÇA CASAMENTO',
				),
				'A18' => array(
					'tipo_abono' => 'dias',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '18',
					'texto' => 'LICENÇA NASCIMENTO',
				),
				'A19' => array(
					'tipo_abono' => 'dias',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '19',
					'texto' => 'ELEIÇÃO',
				),
				'A20' => array(
					'tipo_abono' => 'horas',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '20',
					'texto' => 'COMPARECIMENTO JUDICIAL',
				),
				'A21' => array(
					'tipo_abono' => 'dias',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '21',
					'texto' => 'DOAÇÃO DE SANGUE',
				),
				'A22' => array(
					'tipo_abono' => 'horas',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '22',
					'texto' => 'CURSO',
				),
				'A23' => array(
					'tipo_abono' => 'horas',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '23',
					'texto' => 'FESTA DE FIM DE ANO',
				),
				'A24' => array(
					'tipo_abono' => 'horas',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '24',
					'texto' => 'JOGO BRASIL - COPA',
				),
				'A25' => array(
					'tipo_abono' => 'horas',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '25',
					'texto' => 'ABONO DE HORAS - BANCO',
				),
				'A26' => array(
					'tipo_abono' => 'horas',
					'fonte_ocorrencia' => 'A',
					'tipo_ocorrencia' => '26',
					'texto' => 'ABONO DE HORAS - FOLHA',
				),
				'D1' => array(
					'tipo_abono' => 'nenhum',
					'fonte_ocorrencia' => 'D',
					'tipo_ocorrencia' => '1',
					'texto' => 'DESCONTO EM FOLHA',
				),
				'D2' => array(
					'tipo_abono' => 'horas',
					'fonte_ocorrencia' => 'D',
					'tipo_ocorrencia' => '2',
					'texto' => 'DESCONTO EM BANCO',
				),
				'D3' => array(
					'tipo_abono' => 'troca',
					'fonte_ocorrencia' => 'D',
					'tipo_ocorrencia' => '3',
					'texto' => 'TROCA DE FOLGA',
				),
				'D4' => array(
					'tipo_abono' => 'debito',
					'fonte_ocorrencia' => 'D',
					'tipo_ocorrencia' => '4',
					'texto' => 'HORA DE ALMOÇO EXTERNO',
				),
				'AL1' => array(
					'texto' => 'FÉRIAS',
				),
			);
		}

		function setPontoUser($user_id)
		{
			$dados_usuario = json_decode($this->user_model->getUser($user_id));
			if ($dados_usuario) {
				$this->user = $dados_usuario[0];
			}
			return $this;
		}

		function setRegistros($tipo = 'ponto', $dt_ini = null, $dt_fim = null)
		{
			if ($dt_ini) {
				$this->data_search_ini = $dt_ini;
			}

			if ($dt_fim) {
				$this->data_search_fim = $dt_fim;
			}

			switch ($tipo) {
				case 'ponto':
					$this->marcacoes_ponto = json_decode($this->ponto_model->getPonto($this->data_search_ini->format('Y-m-d'), $this->data_search_fim->format('Y-m-d'), $this->user->id, array('B01', 'B02', 'B03', 'B04')));
					break;
				case 'extra':
					$this->marcacoes_extra = json_decode($this->ponto_model->getPonto($this->data_search_ini->format('Y-m-d'), $this->data_search_fim->format('Y-m-d'), $this->user->id, array('B07', 'B08')));
					break;
				case 'pausa':
					$this->marcacoes_pausa = json_decode($this->ponto_model->getPonto($this->data_search_ini->format('Y-m-d'), $this->data_search_fim->format('Y-m-d'), $this->user->id, array('B05', 'B06')));
					break;
			}
		}

		function setOcorrencias($dt_ini = null, $dt_fim = null)
		{
			if ($dt_ini) {
				$this->data_search_ini = $dt_ini;
			}

			if ($dt_fim) {
				$this->data_search_fim = $dt_fim;
			}
			$this->marcacoes_ocorrencia = json_decode($this->ponto_model->getOcorrenciaByUser($this->user->id, $this->data_search_ini, $this->data_search_fim));
		}

		function setFeriados($validade_ini, $validade_fim)
		{
			$this->feriados = json_decode($this->ponto_model->getFeriados($validade_ini, $validade_fim));
			if ($this->feriados) {
				$feriados = null;
				foreach ($this->feriados as $key => $value) {
					$i1 = nomeMes($value->mes);
					$i2 = str_pad($value->dia, 2, "0", STR_PAD_LEFT);
					$feriados[$i1][$i2]['nome'] = $value->titulo;
					if ($value->valido_ate) {
						$validade = getDataAtual($value->valido_ate);
						$feriados[$i1][$i2]['validade'] = $validade->format('Y-m-d');
					} else {
						$validade = null;
					}
					$feriados[$i1][$i2]['tipo'] = $value->tipo;
				}
				$this->feriados = $feriados;
			}
		}

		function setJornadas()
		{
			$this->jornadas = $this->ponto_model->getJornadaByUsuarioArray($this->user->id);
		}

		function sendAlertas($tipo)
		{
			switch ($tipo) {
				case 'marcacao_ausente':
					# code...
					break;
				case 'ausencia_prolongada':
					# code...
					break;
			}
		}

		function getUltimaMarcacao($userId)
		{
			$ultima_marcacao 	= json_decode($this->ponto_model->ultima_marcacao($userId));
			$ultima_ocorrencia 	= json_decode($this->ponto_model->getUltimaOcorrenciaRegistro($userId));
			$data_marcacao 		= ($ultima_marcacao) ? getDateTime($ultima_marcacao[0]->data_marcacao . ' ' . $ultima_marcacao[0]->hora_marcacao) : null;
			$data_ocorrencia 	= ($ultima_ocorrencia) ? getDateTime($ultima_ocorrencia[0]->data . ' ' . $ultima_ocorrencia[0]->hora) : null;
			if ($ultima_marcacao && $ultima_ocorrencia) {
				if(isset($ultima_ocorrencia[0]) && $ultima_ocorrencia[0]->fonte == 'R'){
					if ($data_marcacao >= $data_ocorrencia) {
						$obj_marcacao 			= $ultima_marcacao[0];
						$obj_marcacao->obj_date = $data_marcacao;
					} elseif ($data_marcacao < $data_ocorrencia) {
						$obj_marcacao 				 = new Custom();
						$obj_marcacao->id 			 = $ultima_ocorrencia[0]->id;
						$obj_marcacao->id_registro 	 = $ultima_ocorrencia[0]->id_registro;
						$obj_marcacao->id_usuario 	 = $ultima_ocorrencia[0]->id_usuario;
						$obj_marcacao->tipo_marcacao = $ultima_ocorrencia[0]->classe;
						$obj_marcacao->data_marcacao = $ultima_ocorrencia[0]->data;
						$obj_marcacao->hora_marcacao = $ultima_ocorrencia[0]->hora;
						$obj_marcacao->status 		 = $ultima_ocorrencia[0]->status;
						$obj_marcacao->obj_date 	 = $data_ocorrencia;
					}
				}else{
					$obj_marcacao = $ultima_marcacao[0];
					$obj_marcacao->obj_date = $data_marcacao;
				}
			} elseif ($ultima_marcacao) {
				$obj_marcacao = $ultima_marcacao[0];
				$obj_marcacao->obj_date = $data_marcacao;
			} elseif ($ultima_ocorrencia) {
				$obj_marcacao = new Custom();
				$obj_marcacao->id = $ultima_ocorrencia[0]->id;
				$obj_marcacao->id_registro = $ultima_ocorrencia[0]->id_registro;
				$obj_marcacao->id_usuario = $ultima_ocorrencia[0]->id_usuario;
				$obj_marcacao->tipo_marcacao = $ultima_ocorrencia[0]->classe;
				$obj_marcacao->data_marcacao = $ultima_ocorrencia[0]->data;
				$obj_marcacao->hora_marcacao = $ultima_ocorrencia[0]->hora;
				$obj_marcacao->status = $ultima_ocorrencia[0]->status;
				$obj_marcacao->obj_date = $data_ocorrencia;
			} else {
				return false;
			}
			return $obj_marcacao;
		}

		function montaJornada()
		{
			if ($this->jornadas) {
				foreach ($this->jornadas as $key => $value) {
					$i1 = $value['id_rel'];
					$i2 = nomeSemana($value['dia_semana']);
					$i3 = $value['dia_semana'];
					$this->dias_jornada[$i3]['nome'] = $i2;
					$this->dias_jornada[$i3]['dados'] = $value;
					$this->resumo_jornada[$i1]['id'] = $value['id_jornada'];
					$this->resumo_jornada[$i1]['nome'] = $value['nome_jornada'];
					$this->resumo_jornada[$i1]['inicio'] = $value['data_inicio'];
					$this->resumo_jornada[$i1]['semana'][$i3]['entrada'] = $value['entrada'];
					$this->resumo_jornada[$i1]['semana'][$i3]['saida'] = $value['saida'];
					$this->resumo_jornada[$i1]['semana'][$i3]['tempo_almoco_min'] = $value['tempo_almoco_min'];
					$this->resumo_jornada[$i1]['semana'][$i3]['nome_semana'] = nomeSemana($value['dia_semana']);
					$jornadas[$i1]['aderir_feriado'] = $value['aderir_feriado'];
					$jornadas[$i1]['aderir_add_noturno'] = $value['aderir_add_noturno'];
					$jornadas[$i1]['dt_ini'] = $value['data_inicio'];
					if ($value['data_fim']) {
						$jornadas[$i1]['dt_fim'] = $value['data_fim'];
					} else {
						$jornadas[$i1]['dt_fim'] = $this->data_search_fim->format('Y-m-d');
					}
					$jornadas[$i1]['dias'][$i2] = $value;
				}

				ksort($this->dias_jornada);
				if ($jornadas) {
					foreach ($jornadas as $key => $value) {
						$dt_ini = getDataAtual($value['dt_ini']);
						$dt_fim = getDataAtual($value['dt_fim']);
						$dt_diff = $dt_ini->diff($dt_fim);
						$inicio = clone $dt_ini;
						for ($i = 0; $i <= $dt_diff->days; $i++) {
							$i1 = $inicio->format('Y-m-d');
							$ns = $inicio->format('w');
							$ds = nomeSemana($inicio->format('w'));
							$this->dias_jornadas[$i]['data'] = $inicio->format('Y-m-d');
							if (isset($value['dias'][$ds]['entrada']) && !empty($value['dias'][$ds]['entrada'])) {
								$this->calendario['diario'][$i1]['horario_entrada'] = $value['dias'][$ds]['entrada'];
								$this->dias_jornadas[$i]['inicio'] = $value['dias'][$ds]['entrada'];
							} else {
								$this->calendario['diario'][$i1]['horario_entrada'] = null;
								$this->dias_jornadas[$i]['inicio'] = null;
							}

							if (isset($value['dias'][$ds]['saida']) && !empty($value['dias'][$ds]['saida'])) {
								$this->calendario['diario'][$i1]['horario_saida'] = $value['dias'][$ds]['saida'];
							} else {
								$this->calendario['diario'][$i1]['horario_saida'] = null;
							}


							if ($inicio >= $this->data_search_ini && $inicio <= $this->data_search_fim) {
								$minutos = 0;
								$this->calendario['diario'][$i1]['jornada'] = null;
								$this->calendario['diario'][$i1]['dia_util'] = false;
								$this->calendario['diario'][$i1]['aderir_feriado'] = $value['aderir_feriado'];
								$this->calendario['diario'][$i1]['aderir_add_noturno'] = $value['aderir_add_noturno'];
								$this->calendario['diario'][$i1]['num_semana'] = $ns;
								$this->calendario['diario'][$i1]['dia_semana'] = $ds;
								$this->calendario['diario'][$i1]['marcacoes'] = null;
								$this->calendario['diario'][$i1]['ocorrencias'] = null;
								$this->calendario['diario'][$i1]['horas_previstas'] = 0;
								if (isset($value['dias'][$ds])) {
									$this->calendario['diario'][$i1]['status'][0] = 'UTIL';
									$this->calendario['diario'][$i1]['jornada'] = $value['dias'][$ds];
									$this->calendario['diario'][$i1]['dia_util'] = true;
									$entrada = getDateTime($i1 . ' ' . $value['dias'][$ds]['entrada']);
									$this->calendario['diario'][$i1]['jornada']['ini_prev'] = $entrada;
									$timestamp_entrada = convertHorasMinutos($value['dias'][$ds]['entrada'], 'hora>decimal');
									$timestamp_saida = convertHorasMinutos($value['dias'][$ds]['saida'], 'hora>decimal');
									if ($timestamp_entrada > $timestamp_saida) {
										$saida = getDateTime($i1 . ' ' . $value['dias'][$ds]['saida']);
										$saida->modify('+1 day');
									} else {
										$saida = getDateTime($i1 . ' ' . $value['dias'][$ds]['saida']);
									}

									$this->calendario['diario'][$i1]['jornada']['fim_prev'] = $saida;
									$diff_jornada = $entrada->diff($saida);
									$minutos = ((($diff_jornada->h * 60) + $diff_jornada->i) - $value['dias'][$ds]['tempo_almoco_min']);
									if ($inicio >= $this->data_inicio && $inicio <= $this->data_fim) {
										$this->calendario['diario'][$i1]['jornada']['carga_horaria'] = $minutos;
										$this->calendario['total']['horas_previstas'] -= $minutos;
										$this->calendario['diario'][$i1]['horas_previstas'] -= $minutos;
									}
								} else {
									$this->calendario['diario'][$i1]['status'][0] = 'FOLGA';
								}

								$this->calendario['diario'][$i1]['pendencia'] = false;
								if ($minutos > 0) {
									$this->calendario['ultima_jornada'] = $minutos;
								}
							}
							$inicio->modify('+1 day');
						}
					}
				}
			}
		}

		function checkSaldoAnterior()
		{
			$saldo_anterior = json_decode($this->ponto_model->getSaldoAnterior($this->user->id));
			if ($saldo_anterior) {
				foreach ($saldo_anterior as $key => $value) {
					if ($value->operacao == 'credito') {
						$this->saldo_anterior += $value->valor;
					} else {
						$this->saldo_anterior -= $value->valor;
					}
				}
			}
			$this->calendario['total']['saldo_anterior'] = $this->saldo_anterior;
		}

		function checkUltimoFechamento()
		{
			$ultimo_fechamento = json_decode($this->ponto_model->getUltimoFechamento($this->user->id));
			if ($ultimo_fechamento) {
				$this->ultimo_fechamento['saldo'] = $ultimo_fechamento[0]->saldo_fechamento;
				$this->ultimo_fechamento['id'] = $ultimo_fechamento[0]->id;
				$this->ultimo_fechamento['id_anexo'] = $ultimo_fechamento[0]->id_anexo;
				$this->ultimo_fechamento['periodo_fim'] = $ultimo_fechamento[0]->periodo_fim;
				$this->calendario['total']['saldo_anterior'] = $ultimo_fechamento[0]->saldo_fechamento;
			}
		}

		function getError()
		{
			return $this->error;
		}

		function getRetorno()
		{
			return $this->retorno;
		}

		/* Começando novo codigo aqui */
		function createObjDate($marcacao, $data = 'marcacao')
		{
			switch ($data) {
				case 'marcacao':
					return new DateTime($marcacao->data_marcacao . ' ' . $marcacao->hora_marcacao, new DateTimeZone(TIME_ZONE));
					break;
				case 'referencia':
					return new DateTime($marcacao->data_referencia . ' ' . $marcacao->hora_marcacao, new DateTimeZone(TIME_ZONE));
					break;
			}
		}

		function processaOcorrencias()
		{
			if ($this->marcacoes_ocorrencia) {
				foreach ($this->marcacoes_ocorrencia as $key => $value) {
					$i1 = $value->data;
					$i2 = $value->classe;
					$this->dias_ocorrencias[$i1][$i2] = $value;
					switch (strtoupper($value->fonte)) {
						case 'R':
							$this->checkOcorrenciaTipoR($i1, $value);
							break;
						default:
							$this->checkOcorrenciaDefault($value);
							break;
					}
				}
			} else {
				// setar erro quando nao encontrar
			}
		}

		function checkOcorrenciaTipoR($data, $ocorrencia)
		{
			$i1 = null;
			$count = count($this->matriz_marcacoes['marcacoes']['ponto'][$data]);
			$obj_correncia = $this->criarObjMarcacao($ocorrencia, 'ocorrencia');
			$data_ocorrencia = new DateTime($ocorrencia->data . ' ' . $ocorrencia->hora);

			if (isset($this->mapa_marcacoes['marcacoes']['ponto']) && !empty($this->mapa_marcacoes['marcacoes']['ponto'])) {
				ksort($this->mapa_marcacoes['marcacoes']['ponto']);
			}

			if (!empty($ocorrencia->id_registro)) {
				if (array_key_exists($ocorrencia->id_registro, $this->mapa_registros['ponto'])) {
					$i1 = $this->mapa_registros['ponto'][$ocorrencia->id_registro];
					$o1 = $data_ocorrencia->format('YmdHis');
					$this->mapa_marcacoes['marcacoes']['ponto'][$o1] = $obj_correncia;
					$this->mapa_marcacoes['marcacoes']['ponto'][$o1]->status = $ocorrencia->status;
					if ($i1 != $o1) {
						unset($this->mapa_marcacoes['marcacoes']['ponto'][$i1]);
						$this->mapa_registros['ponto'][$ocorrencia->id_registro] = $o1;
					}
				}
			} else {
				$i1 = $data_ocorrencia->format('YmdHis');
				$this->mapa_marcacoes['marcacoes']['ponto'][$i1] = $obj_correncia;
			}

			if ($ocorrencia->status == 'pendente') {
				$d1 = $ocorrencia->data;
				$this->calendario['diario'][$d1]['pendencia'] = true;
				$this->calendario['pendencias']['status'] = true;
			}

			if (!empty($o1)) {
				$this->mapa_marcacoes['marcacoes']['ponto'][$o1]->status = $ocorrencia->status;
			} elseif (!empty($i1)) {
				$this->mapa_marcacoes['marcacoes']['ponto'][$i1]->status = $ocorrencia->status;
			}
		}

		function checkOcorrenciaTipoT($ocorrencia)
		{
			$im = $ocorrencia->id_registro;
			if (array_key_exists($ocorrencia->id_registro, $this->mapa_registros['ponto'])) {
				$i1 = $ocorrencia->data;
				$k1 = $this->mapa_registros['ponto'][$im];
				$this->mapa_marcacoes['marcacoes']['ponto'][$k1]->status = $ocorrencia->status;
			}
		}

		function checkOcorrenciaDefault($ocorrencia)
		{
			$dias = null;
			if ($ocorrencia->periodo_ini) {
				$ini_ocorrencia = getDateTime($ocorrencia->periodo_ini);
				$dt_ini = getDateTime($ocorrencia->periodo_ini);
				$dt_ini->setTime(00, 00, 00);
			}

			if ($ocorrencia->periodo_fim) {
				$fim_ocorrencia = getDateTime($ocorrencia->periodo_fim);
				$dt_fim = getDateTime($ocorrencia->periodo_fim);
				$dt_fim->setTime(23, 59, 59);
			}

			if ($dt_ini && $dt_fim) {
				$diff = $dt_ini->diff($dt_fim);
				$dias = ($diff->days + 1);
			}

			if ($dias > 0) {
				$inicio = clone $dt_ini;
				for ($i = 0; $i < $dias; $i++) {
					$i1 = $inicio->format('Y-m-d');
					$inicio_dia = clone $inicio;
					$final_dia = clone $inicio;
					$final_dia->setTime(23, 59, 59);
					if ($inicio >= $this->data_inicio && $inicio <= $this->data_fim) {
						if (empty($ocorrencia->minutos)) {
							$diff_ocorrencia = $ini_ocorrencia->diff($fim_ocorrencia);
							$ocorrencia->minutos = $this->calcMinutosDiff($diff_ocorrencia);
						}

						$jornada = $this->calendario['diario'][$i1]['jornada'];
						$horas_previstas = $this->calendario['diario'][$i1]['horas_previstas'];
						$this->calendario['diario'][$i1]['ocorrencias'][] = $ocorrencia;
						if ($ocorrencia->status == 'aprovado') {

							if ($ini_ocorrencia >= $inicio_dia && $fim_ocorrencia <= $final_dia) {
								$ocorrencia->periodo_ini = $ini_ocorrencia->format('Y-m-d H:i:s');
								$ocorrencia->periodo_fim = $fim_ocorrencia->format('Y-m-d H:i:s');
							} elseif ($ini_ocorrencia >= $inicio_dia && $fim_ocorrencia > $final_dia) {
								$ocorrencia->periodo_ini = $ini_ocorrencia->format('Y-m-d H:i:s');
								$ocorrencia->periodo_fim = $final_dia->format('Y-m-d H:i:s');
							} elseif ($ini_ocorrencia < $inicio_dia && $fim_ocorrencia <= $final_dia) {
								$ocorrencia->periodo_ini = $inicio_dia->format('Y-m-d H:i:s');
								$ocorrencia->periodo_fim = $fim_ocorrencia->format('Y-m-d H:i:s');
							} elseif ($ini_ocorrencia < $inicio_dia && $fim_ocorrencia > $final_dia) {
								$ocorrencia->periodo_ini = $inicio_dia->format('Y-m-d H:i:s');
								$ocorrencia->periodo_fim = $final_dia->format('Y-m-d H:i:s');
							} else {
								echo '645';
								exit;
							}

							$ini_marcacao = getDateTime($ocorrencia->periodo_ini);
							$fim_marcacao = getDateTime($ocorrencia->periodo_fim);
							$dia_util = $this->calendario['diario'][$i1]['dia_util'];
							switch ($ocorrencia->fonte) {
								case 'T':
									$this->checkOcorrenciaTipoT($ocorrencia);
									break;
								case 'A':
									switch ($ocorrencia->tipo) {
										case '1':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['mensagem'][] = 'LICENÇA MATERNIDADE';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '2':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['mensagem'][] = 'ATESTADO';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '3':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['mensagem'][] = 'COMPROVANTE DE HORAS';
											$this->abonarHoras('horas', $ocorrencia);
											break;
										case '4':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['mensagem'][] = 'PERCURSO';

											$this->abonarHoras('minutos', $ocorrencia);
											break;
										case '5':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['mensagem'][] = 'FALTA ABONADA';
											$this->abonarHoras('intervalo', $inicio);
											break;
										case '6':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['mensagem'][] = 'FOLGA ESCALADA';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '7':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['mensagem'][] = 'VIAGEM';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '8':
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['mensagem'][] = 'Erro de sistema';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '9':
											// dados padrao
											$obj = new Custom();
											$obj->id_registro = null;
											$obj->id_ocorrencia = $ocorrencia->id;
											$obj->id_usuario = $this->user->id;
											$obj->status = $ocorrencia->status;
											// inicio
											$i1 = $ini_marcacao->format('YmdHis');
											$obj->tipo_marcacao = 'B07';
											$obj->data_marcacao = $ini_marcacao->format('Y-m-d');
											$obj->hora_marcacao = $ini_marcacao->format('H:i');
											$this->mapa_marcacoes['marcacoes']['extra'][$i1] = $this->criarObjMarcacao($obj, 'extra');
											// fim
											$i1 = $fim_marcacao->format('YmdHis');
											$obj->tipo_marcacao = 'B08';
											$obj->data_marcacao = $fim_marcacao->format('Y-m-d');
											$obj->hora_marcacao = $fim_marcacao->format('H:i');
											$this->mapa_marcacoes['marcacoes']['extra'][$i1] = $this->criarObjMarcacao($obj, 'extra');
											break;
										case '10':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['mensagem'][] = 'REUNIÃO EXTERNA';
											$this->abonarHoras('extras', $ocorrencia);
											break;
										case '11':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['mensagem'][] = 'LICENÇA PATERNIDADE';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '12':
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['mensagem'][] = 'Licença amamentação';
											$ocorrencia->com_marcacoes = true;
											$this->abonarHoras('minutos', $ocorrencia, $param);
											break;
										case '13':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['mensagem'][] = 'AFASTAMENTO INSS';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '14':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['mensagem'][] = 'LICENÇA ÓBITO PAÍS';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '15':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['mensagem'][] = 'LICENÇA ÓBITO FILHOS';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '16':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['mensagem'][] = 'LICENÇA ÓBITO AVÓ/AVÔ';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '17':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['mensagem'][] = 'LICENÇA CASAMENTO';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '18':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['mensagem'][] = 'LICENÇA NASCIMENTO FILHO';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '19':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['mensagem'][] = 'LICENÇA ELEIÇÃO';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '20':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['mensagem'][] = 'COMPARECIMENTO JUDICIAL';
											$this->abonarHoras('horas', $ocorrencia);
											break;
										case '21':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['mensagem'][] = 'DOAÇÃO DE SANGUE';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '22':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['mensagem'][] = 'CURSO';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '23':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['mensagem'][] = 'FESTA DE FIM DE ANO';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '24':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['mensagem'][] = 'JOGO BRASIL - COPA';
											$this->abonarHoras('intervalo', $ocorrencia);
											break;
										case '25':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['mensagem'][] = 'ABONO DE HORAS EM BANCO';
											$this->abonarHoras('minutos', $ocorrencia);
											break;
										case '26':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['mensagem'][] = 'ABONO DE HORAS EM FOLHA';
											$this->abonarHoras('folha', $ocorrencia, ['operacao' => '+']);
											break;
										default:
											// echo '<pre>';
											// var_dump('AVISE O RH', '454', $ocorrencia);
											// echo '</pre>';
											// exit;
											break;
									}
									break;
								case 'D':
									switch ($ocorrencia->tipo) {
										case '1':
											$this->calendario['diario'][$i1]['flag'] = 'debitar';
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['mensagem'][] = 'DESCONTO EM FOLHA';
											$this->abonarHoras('folha', $ocorrencia, ['operacao' => '-']);
											break;
										case '2':
											$this->calendario['diario'][$i1]['flag'] = 'debitar';
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['mensagem'][] = 'BANCO DE HORAS';
											break;
										case '3':
											$this->calendario['diario'][$i1]['flag'] = 'troca';
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['mensagem'][] = 'TROCA DE FOLGA';
											$this->abonarHoras('intervalo', $inicio);
											break;
										case '4':
											$this->calendario['diario'][$i1]['flag'] = 'debitar';
											$this->calendario['diario'][$i1]['dia_util'] = true;
											$this->calendario['diario'][$i1]['mensagem'][] = 'HORARIO DE ALMOÇO EXTERNO';
											$this->abonarHoras('minutos', $inicio);
											break;
										default:
											echo '<pre>';
											var_dump('671', $ocorrencia);
											echo '</pre>';
											exit;
											break;
									}
									break;
								case 'AL':
									switch ($ocorrencia->tipo) {
										case '1':
											$this->calendario['diario'][$i1]['flag'] = 'abono';
											$this->calendario['diario'][$i1]['motivo'][] = 'ferias';
											$this->calendario['diario'][$i1]['mensagem'][] = 'Férias';
											$this->abonarHoras('intervalo', $inicio);
											break;
										default:
											echo '<pre>';
											var_dump('918', $ocorrencia);
											echo '</pre>';
											exit;
											break;
									}
									break;
								default:
									echo '<pre>';
									var_dump('854', $ocorrencia);
									echo '</pre>';
									exit;
									break;
							}
						} else {
							$this->calendario['diario'][$i1]['pendencia'] = true;
							$this->calendario['pendencias']['status'] = true;
							$this->calendario['pendencias']['dados'][] = $ocorrencia;
						}
					}
					$inicio->modify('+1 day');
				}
			}
		}

		function checkMarcacaoExiste($data)
		{
			if ($data) {
				if (isset($this->calendario['diario'][$data]['marcacoes']) && count($this->calendario['diario'][$data]['marcacoes']) > 0) {
					foreach ($this->calendario['diario'][$data]['marcacoes'] as $key => $value) {
						foreach ($value as $k1 => $v1) {
							if (!empty($v1->hora_marcacao)) {
								return true;
							}
						}
					}
				}
			}
			return false;
		}

		function abonarHoras($tipo, $dados, $param = null)
		{

			if (isset($dados) && $dados instanceof DateTime) {
				$ini_ocorrencia = $dados;
				$fim_ocorrencia = $dados;
			} else {
				$ini_ocorrencia = (isset($dados->periodo_ini)) ? getDateTime($dados->periodo_ini) : null;
				$fim_ocorrencia = (isset($dados->periodo_fim)) ? getDateTime($dados->periodo_fim) : null;
			}

			if ($ini_ocorrencia) {
				$data = $ini_ocorrencia->format('Y-m-d');
			}

			if (isset($dados->com_marcacoes) && $dados->com_marcacoes == true) {
				$this->calendario['diario'][$data]['com_marcacoes'] = true;
			}

			switch ($tipo) {
				case 'extras':
					$minutos_abono = 0;
					$jornada = $this->calendario['diario'][$data]['jornada'];
					$this->calendario['diario'][$data]['tipo_abono'][] = $tipo;
					if ($dados->minutos) {
						if ($jornada) {
							$minutos_jornada = $jornada['carga_horaria'];
						}

						if ($dados->minutos == $minutos_jornada) {
							$minutos_abono = $dados->minutos;
						} elseif ($dados->minutos >= $minutos_jornada) {
							$minutos_abono = ($dados->minutos - $jornada['tempo_almoco_min']);
						} else {
							$minutos_abono = $dados->minutos;
						}
					}
					$this->calendario['diario'][$data]['horas_abonadas'][0] += $minutos_abono;
					$this->calendario['diario'][$data]['valor_abono'][] = $minutos_abono;
					break;
				case 'minutos':
					$this->calendario['diario'][$dados->data]['tipo_abono'][] = $tipo;
					$this->calendario['diario'][$dados->data]['valor_abono'][] = $dados->minutos;
					break;
				case 'horas':
					$jornada = $this->calendario['diario'][$data]['jornada'];
					$hora_entrada = $jornada['ini_prev'];
					$hora_saida = $jornada['fim_prev'];
					if ($ini_ocorrencia >= $hora_entrada && $fim_ocorrencia <= $hora_saida) {
						$diff_ocorrencia = $ini_ocorrencia->diff($fim_ocorrencia);
					} elseif ($ini_ocorrencia >= $hora_entrada && $ini_ocorrencia <= $hora_saida && $fim_ocorrencia > $hora_saida) {
						$diff_ocorrencia = $ini_ocorrencia->diff($hora_saida);
					} elseif ($ini_ocorrencia < $hora_entrada && $fim_ocorrencia >= $hora_entrada && $fim_ocorrencia <= $hora_saida) {
						$diff_ocorrencia = $hora_entrada->diff($fim_ocorrencia);
					}
					// quando a pausa está no meio da jornada de trabalho
					$minutos = (isset($diff_ocorrencia)) ? $this->calcMinutosDiff($diff_ocorrencia) : null;
					if ($minutos) {
						$this->calendario['diario'][$data]['tipo_abono'][] = $tipo;
						$this->calendario['diario'][$data]['valor_abono'][] = $minutos;
					}
					break;
				case 'folha':
					$minutos = 0;
					if ($dados->minutos !== null) {
						$minutos = (int) $dados->minutos;
					}

					if ($ini_ocorrencia->format('Y-m-d H:i:s') !== $fim_ocorrencia->format('Y-m-d H:i:s')) {
						$minutos = $this->calcMinutosDiff($diff_ocorrencia = $ini_ocorrencia->diff($fim_ocorrencia));
					}
					if ($param['operacao'] == '+') {
						$this->calendario['total']['devedor_folha'] += $minutos;
						$this->calendario['diario'][$data]['devedor_folha'] += $minutos;
					} else {
						$this->calendario['total']['devedor_folha'] -= $minutos;
						$this->calendario['diario'][$data]['devedor_folha'] -= $minutos;
					}


					break;
				case 'intervalo':
					if ($ini_ocorrencia) {
						$data = $ini_ocorrencia->format('Y-m-d');
					}
					$this->controller->arrayDinamico($this->calendario['diario'], $data, 'dia_abonado', null);
					$this->controller->arrayDinamico($this->calendario['diario'], $data, 'jornada', null);
					$this->controller->arrayDinamico($this->calendario['diario'], $data, 'horas_previstas', null);
					$jornada = $this->calendario['diario'][$data]['jornada'];
					$horas_previstas = $this->calendario['diario'][$data]['horas_previstas'];
					if ($jornada) {
						if (!$this->calendario['diario'][$data]['dia_abonado']) {
							$this->calendario['diario'][$data]['tipo_abono'][] = $tipo;
							$this->calendario['diario'][$data]['valor_abono'][] = abs(-$horas_previstas);
							$this->calendario['diario'][$data]['dia_abonado'][] = true;
						}
					}
					break;
				case 'dia':
					$data = new DateTime($dados);
					$data = $data->format('Y-m-d');
					$jornada = $this->calendario['diario'][$data]['jornada'];
					$horas_previstas = $this->calendario['diario'][$data]['horas_previstas'];
					if ($jornada) {
						if (!$this->calendario['diario'][$data]['dia_abonado']) {
							$this->calendario['diario'][$data]['tipo_abono'][] = $tipo;
							$this->calendario['diario'][$data]['valor_abono'][] = abs(-$horas_previstas);
							$this->calendario['diario'][$data]['dia_abonado'][] = true;
						}
					}
					break;
				case 'troca':
					if (!is_object($dados)) {
						$data = new DateTime($dados);
						$data = $data->format('Y-m-d');
					} else {
						$data = $dados->format('Y-m-d');
					}
					$horas_previstas = $this->calendario['diario'][$data]['horas_previstas'];
					if ($horas_previstas) {
						$this->calendario['total']['horas_previstas'] -= $horas_previstas;
						$this->calendario['diario'][$data]['horas_previstas'] -= $horas_previstas;
						$this->calendario['diario'][$data]['dia_util'][] = true;
						$this->calendario['diario'][$data]['dia_abonado'][] = false;
					} else {
						$this->calendario['total']['horas_previstas'] -= $this->calendario['ultima_jornada'];
						$this->calendario['diario'][$data]['horas_previstas'] -= $this->calendario['ultima_jornada'];
						$this->calendario['diario'][$data]['tipo_abono'][] = $tipo;
						$this->calendario['diario'][$data]['dia_util'][] = true;
						$this->calendario['diario'][$data]['dia_abonado'][] = false;
					}
					break;
			}
		}

		function verDia($tipo = 'ponto')
		{
			switch ($tipo) {
				case 'ponto':
					if (count($this->marcacoes_ponto) > 0) {
						foreach ($this->marcacoes_ponto as $key => $value) {
							$data = new DateTime($value->data_marcacao . ' ' . $value->hora_marcacao);
							$i1 = $data->format('YmdHis');
							$i2 = $value->id;
							$i3 = $data->format('Y-m-d');
							$i4 = $value->tipo_marcacao;
							$i5 = $value->hora_marcacao;
							$value->hora_marcacao = $data->format('H:i');
							$this->mapa_registros['dias'][$i3][$i5] = $i4;
							$this->mapa_registros['ponto'][$i2] = $i1;
							$this->mapa_marcacoes['marcacoes']['ponto'][$i1] = $this->criarObjMarcacao($value, 'ponto');
							$this->mapa_marcacoes['marcacoes']['dias'][$i3][] = $this->criarObjMarcacao($value, 'ponto');
						}
					}
					break;
				case 'pausa':
					if (count($this->marcacoes_pausa) > 0) {
						foreach ($this->marcacoes_pausa as $key => $value) {
							$data = $this->createObjDate($value);
							$i1 = $data->format('YmdHis');
							$i2 = $value->id;
							$this->mapa_registros['pausa'][$i2] = $i1;
							$this->mapa_marcacoes['marcacoes']['pausa'][$i1] = $this->criarObjMarcacao($value, 'pausa');
						}
					}
					break;
				case 'extra':
					if (count($this->marcacoes_extra) > 0) {
						foreach ($this->marcacoes_extra as $key => $value) {
							$data = $this->createObjDate($value);
							$i1 = $data->format('YmdHis');
							$i2 = $value->id;
							$this->mapa_registros['extra'][$i2] = $i1;
							$this->mapa_marcacoes['marcacoes']['extra'][$i1] = $this->criarObjMarcacao($value, 'extra');
						}
					}
					break;
			}
		}

		function criarObjMarcacao($dados, $tipo = 'ponto')
		{
			$obj = new Custom();
			switch ($tipo) {
				case 'ponto':
					$obj->tipo_registro = $tipo;
					$obj->id_registro = $dados->id_registro;
					$obj->id_ocorrencia = (isset($dados->id_ocorrencia)) ? $dados->id_ocorrencia : null;
					$obj->id_usuario = $dados->id_usuario;
					$obj->tipo_marcacao = $dados->tipo_marcacao;
					$obj->data_marcacao = $dados->data_marcacao;
					$obj->data_referencia = (isset($dados->data_referencia)) ? $dados->data_referencia : $dados->data_marcacao;
					$obj->hora_marcacao = $dados->hora_marcacao;
					$obj->hora_referencia = $dados->hora_marcacao;
					$obj->status = $dados->status;
					break;
				case 'pausa':
					$obj->tipo_registro = $tipo;
					$obj->id_registro = $dados->id;
					$obj->id_ocorrencia = (isset($dados->id_ocorrencia)) ? $dados->id_ocorrencia : null;
					$obj->id_usuario = $dados->id_usuario;
					$obj->tipo_marcacao = $dados->tipo_marcacao;
					$obj->data_marcacao = $dados->data_marcacao;
					$obj->data_referencia = $dados->data_marcacao;
					$obj->hora_marcacao = $dados->hora_marcacao;
					$obj->status = $dados->status;
					break;
				case 'extra':
					$obj->tipo_registro = $tipo;
					$obj->id_registro = (isset($dados->id)) ? $dados->id : null;
					$obj->id_ocorrencia = (isset($dados->id_ocorrencia)) ? $dados->id_ocorrencia : null;
					$obj->id_usuario = $dados->id_usuario;
					$obj->tipo_marcacao = $dados->tipo_marcacao;
					$obj->data_marcacao = $dados->data_marcacao;
					$obj->data_referencia = $dados->data_marcacao;
					$obj->hora_marcacao = $dados->hora_marcacao;
					$obj->status = $dados->status;
					break;
				case 'ocorrencia':
					$obj->tipo_registro = $tipo;
					$obj->id_ocorrencia = (isset($dados->id_ocorrencia)) ? $dados->id_ocorrencia : $dados->id;
					$obj->id_registro = $dados->id_registro;
					$obj->id_usuario = $dados->id_usuario;
					$obj->tipo_marcacao = $dados->classe;
					$obj->data_marcacao = $dados->data;
					$obj->data_referencia = $dados->data;
					$obj->hora_marcacao = $dados->hora;
					$obj->status = $dados->status;
					break;
			}
			return $obj;
		}

		function criarObjMarcacaoVazio($data, $array_tipo, $tipo = 'ponto')
		{
			$retorno = null;
			switch ($tipo) {
				case 'ponto':
					foreach ($array_tipo as $key => $value) {
						$obj = new Custom();
						$obj->id_ocorrencia = null;
						$obj->id_registro = null;
						$obj->data_marcacao = $data;
						$obj->data_referencia = $data;
						$obj->tipo_marcacao = $value;
						$obj->hora_marcacao = null;
						$obj->hora_referencia = '00:00';
						$obj->criado = true;
						$retorno[] = $obj;
					}
					break;
				case 'extra':
					foreach ($array_tipo as $key => $value) {
						$obj = new Custom();
						$obj->tipo = $tipo;
						$obj->id_ocorrencia = null;
						$obj->id_registro = null;
						$obj->data_marcacao = $data;
						$obj->data_referencia = $data;
						$obj->tipo_marcacao = $value;
						$obj->hora_marcacao = null;
						$obj->hora_referencia = '00:00';
						$obj->criado = true;
						$retorno[] = $obj;
					}
					break;
			}
			return $retorno;
		}

		function criarObjMarcacaoVazioEmMatriz($dados, $array_tipo, $tipo = 'ponto')
		{
			switch ($tipo) {
				case 'ponto':
					foreach ($array_tipo as $key => $value) {
						$obj = $this->criarObjMarcacao($dados, $tipo);
						$obj->id_registro = null;
						$obj->tipo_marcacao = $value;
						$obj->hora_marcacao = null;
						$obj->criado = true;
						$this->matriz_marcacoes['ponto'][] = $obj;
					}
					break;
				case 'pausa':
					foreach ($array_tipo as $key => $value) {
						$obj = $this->criarObjMarcacao($dados, $tipo);
						$obj->id_registro = null;
						$obj->tipo_marcacao = $value;
						$obj->hora_marcacao = null;
						$obj->criado = true;
						$this->matriz_marcacoes['pausa'][] = $obj;
					}
					break;
				case 'extra':
					foreach ($array_tipo as $key => $value) {
						$obj = $this->criarObjMarcacao($dados, $tipo);
						$obj->id_registro = null;
						$obj->tipo_marcacao = $value;
						$obj->hora_marcacao = null;
						$obj->criado = true;
						$this->matriz_marcacoes['extra'][] = $obj;
					}
					break;
			}
		}

		function checkHorasDiff($dt1, $dt2, $return = false)
		{
			if ($dt1 && $dt2) {
				$diff = $dt1->diff($dt2);
				if ($return) {
					return $diff;
				} else {
					if ($diff->days > 0 || $diff->h >= 11) {
						return true;
					} else {
						return false;
					}
				}
			} else {
				return false;
			}
		}

		function createDate($dados, $tipo = 'marcacao')
		{
			if ($dados) {
				switch ($tipo) {
					case 'marcacao':
						if ($dados->hora_marcacao) {
							return new DateTime($dados->data_marcacao . ' ' . $dados->hora_marcacao);
						} else {
							return new DateTime($dados->data_marcacao . ' ' . $dados->hora_referencia);
						}
						break;
					case 'referencia':
						return new DateTime($dados->data_referencia . ' ' . $dados->hora_marcacao);
						break;
					case 'jornada':
						if ($dados['entrada'] > $dados['saida']) {
							$data['entrada'] = new DateTime($dados['data_referencia'] . ' ' . $dados['entrada']);
							$data['saida'] = new DateTime($dados['data_referencia'] . ' ' . $dados['saida']);
							$data['saida']->modify('+1 day');
						} else {
							$data['entrada'] = new DateTime($dados['data_referencia'] . ' ' . $dados['entrada']);
							$data['saida'] = new DateTime($dados['data_referencia'] . ' ' . $dados['saida']);
						}
						return $data;
						break;
				}
			}
		}

		function calcMinutosDiff($diff)
		{
			if ($diff) {
				return (($diff->days * 24 * 60) + ($diff->h * 60) + $diff->i);
			} else {
				return false;
			}
		}

		function checkAdicional($tipo = 'noturno')
		{
			switch ($tipo) {
				case 'noturno':
					# code...
					break;
				case 'extra':
					# code...
					break;
			}
		}

		function calculahorasDia($dia, $marcacao_atual = null)
		{
			if (!empty($marcacao_atual) && is_array($marcacao_atual)) {
				$marcacao_atual = json_decode(json_encode($marcacao_atual));
			}

			if (isset($this->calendario['diario'][$dia]['marcacoes']) && is_array($this->calendario['diario'][$dia]['marcacoes'])) {
				$marcacoes = end($this->calendario['diario'][$dia]['marcacoes']);
			} else {
				$marcacoes = null;
			}

			$minutos = 0;
			if ($marcacao_atual) {
				switch ($marcacao_atual->tipo_marcacao) {
					case 'B02':
						if (isset($marcacoes[0]->hora_marcacao) && !empty($marcacoes[0]->hora_marcacao)) {
							$d1 = getDateTime($marcacoes[0]->data_marcacao . ' ' . $marcacoes[0]->hora_marcacao);
							$d2 = getDateTime($marcacao_atual->data_marcacao . ' ' . $marcacao_atual->hora_marcacao);
							$diff = $d1->diff($d2);
							$minutos += $this->calcMinutosDiff($diff);
						}
						break;
					case 'B04':
						if (
							isset($marcacoes[0]->hora_marcacao) &&
							isset($marcacoes[1]->hora_marcacao) &&
							isset($marcacoes[2]->hora_marcacao)
						) {
							$d1 = getDateTime($marcacoes[0]->data_marcacao . ' ' . $marcacoes[0]->hora_marcacao);
							$d2 = getDateTime($marcacoes[1]->data_marcacao . ' ' . $marcacoes[1]->hora_marcacao);

							$d3 = getDateTime($marcacoes[2]->data_marcacao . ' ' . $marcacoes[2]->hora_marcacao);
							$d4 = getDateTime($marcacao_atual->data_marcacao . ' ' . $marcacao_atual->hora_marcacao);

							$diff1 = $d1->diff($d2);
							$diff2 = $d3->diff($d4);
							$minutos += $this->calcMinutosDiff($diff1);
							$minutos += $this->calcMinutosDiff($diff2);
						} elseif (
							isset($marcacoes[0]->hora_marcacao)
						) {
							$d1 = getDateTime($marcacoes[0]->data_marcacao . ' ' . $marcacoes[0]->hora_marcacao);
							$d2 = getDateTime($marcacao_atual->data_marcacao . ' ' . $marcacao_atual->hora_marcacao);
							$diff = $d1->diff($d2);
							$minutos += $this->calcMinutosDiff($diff);
						} else {
							if (isset($marcacoes[0]->hora_marcacao)) {
								$this->error = true;
								$this->error_msg = 'Falta marcação de entrada';
								return false;
							}

							if (isset($marcacoes[1]->hora_marcacao)) {
								$this->error = true;
								$this->error_msg = 'Falta marcação de saida para almoço';
								return false;
							}

							if (isset($marcacoes[2]->hora_marcacao)) {
								$this->error = true;
								$this->error_msg = 'Falta marcação de retorno do almoço';
								return false;
							}
						}
						break;
				}
			} else {
				if ($dia) {
					if (
						isset($marcacoes[0]->hora_marcacao) && !empty($marcacoes[0]->hora_marcacao) &&
						isset($marcacoes[1]->hora_marcacao) && !empty($marcacoes[1]->hora_marcacao)
					) {
						$d1 = getDateTime($marcacoes[0]->data_marcacao . ' ' . $marcacoes[0]->hora_marcacao);
						$d2 = getDateTime($marcacoes[1]->data_marcacao . ' ' . $marcacoes[1]->hora_marcacao);
						$diff = $d1->diff($d2);
						$minutos += $this->calcMinutosDiff($diff);
					}

					if (
						isset($marcacoes[2]->hora_marcacao) && !empty($marcacoes[2]->hora_marcacao) &&
						isset($marcacoes[3]->hora_marcacao) && !empty($marcacoes[3]->hora_marcacao)
					) {
						$d1 = getDateTime($marcacoes[2]->data_marcacao . ' ' . $marcacoes[2]->hora_marcacao);
						$d2 = getDateTime($marcacoes[3]->data_marcacao . ' ' . $marcacoes[3]->hora_marcacao);
						$diff = $d1->diff($d2);
						$minutos += $this->calcMinutosDiff($diff);
					}

					if (
						!isset($marcacoes[1]->hora_marcacao) &&
						empty($marcacoes[1]->hora_marcacao) &&
						!isset($marcacoes[2]->hora_marcacao) &&
						empty($marcacoes[2]->hora_marcacao)
					) {
						$d1 = getDateTime($marcacoes[0]->data_marcacao . ' ' . $marcacoes[0]->hora_marcacao);
						$d2 = getDateTime($marcacoes[3]->data_marcacao . ' ' . $marcacoes[3]->hora_marcacao);
						$diff = $d1->diff($d2);
						$minutos += $this->calcMinutosDiff($diff);
					}
				}
			}
			return $minutos;
		}

		function chkHourArray($hora, $array, $search)
		{
			switch ($search) {
				case 'ultima':
					$hora_marcacao = end($array);
					if ($hora_marcacao->hora_marcacao) {
						$hora_marcacao = $this->createObjDate($hora_marcacao);
						if ($hora > $hora_marcacao) {
							return $hora_marcacao;
						} else {
							return $hora;
						}
					} else {
						return false;
					}
					break;
				case 'primeira':
					if ($array[0]->hora_marcacao) {
						$hora_marcacao = $this->createObjDate($array[0]);
						if ($hora < $hora_marcacao) {
							return $hora;
						} else {
							return $hora_marcacao;
						}
					} else {
						return false;
					}
					break;
				default:
					echo '1134';
					exit;
					break;
			}
		}

		function checkNoturno($d1, $d2, $ponto_partida, $jornada = null)
		{
			if ($d1 && $d2) {
				$hora_ini = null;
				$hora_fim = null;
				$ini_marcacao = $this->createObjDate($d1);
				$fim_marcacao = $this->createObjDate($d2);
				if ($jornada) {
					$ini_noturno = clone $jornada['ini_prev'];
					$ini_noturno->setTime(22, 00, 00);

					$fim_noturno = clone $jornada['fim_prev'];
					$fim_noturno->setTime(06, 00, 00);

					if ($ini_noturno > $jornada['ini_prev']) {
						$ini_noturno->modify('-1 day');
					}
				} else {
					$ini_noturno = getDataAtual($ponto_partida);
					$ini_noturno->setTime(22, 00, 00);
					$fim_noturno = getDataAtual($ponto_partida);
					$fim_noturno->modify('+1 day');
					$fim_noturno->setTime(06, 00, 00);
				}

				if (
					$ini_marcacao <= $ini_noturno &&
					$fim_marcacao <= $ini_noturno
				) {
					$ini_noturno->modify('-1 day');
					$fim_noturno->modify('-1 day');
				} elseif (
					$ini_marcacao >= $fim_noturno &&
					$fim_marcacao >= $fim_noturno
				) {
					$ini_noturno->modify('+1 day');
					$fim_noturno->modify('+1 day');
				}

				if (
					$ini_marcacao >= $ini_noturno &&
					$ini_marcacao <= $fim_noturno
				) {
					$hora_ini = $ini_marcacao;
				} else {
					if ($ini_marcacao < $ini_noturno) {
						$hora_ini = $ini_noturno;
					}
				}

				if (
					$fim_marcacao >= $ini_noturno &&
					$fim_marcacao <= $fim_noturno
				) {
					$hora_fim = $fim_marcacao;
				} else {
					if ($fim_marcacao > $fim_noturno) {
						$hora_fim = $fim_noturno;
					}
				}

				if ($hora_ini && $hora_fim) {
					$diff = $hora_ini->diff($hora_fim);
					$minutos = $this->calcMinutosDiff($diff);
					return $minutos;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}

		function checkHoraExtra($d1, $d2, $ponto_partida)
		{
			$minutos = 0;
			$jornada = $this->calendario['diario'][$ponto_partida]['jornada'];
			$jornada_ini = $jornada['ini_prev'];
			$jornada_fim = $jornada['fim_prev'];
			$ini_marcacao = $this->createObjDate($d1);
			$fim_marcacao = $this->createObjDate($d2);

			if ($jornada_ini > $jornada_fim) {
				$jornada_fim->modify('+1 day');
			}

			if ($ini_marcacao >= $jornada_fim || $fim_marcacao < $jornada_ini) {
				$diff = $this->checkHorasDiff($ini_marcacao, $fim_marcacao, true);
				$minutos = $this->calcMinutosDiff($diff);
			} elseif ($ini_marcacao <= $jornada_ini && $fim_marcacao > $jornada_ini && $fim_marcacao <= $jornada_fim) {
				$diff = $this->checkHorasDiff($ini_marcacao, $jornada_ini, true);
				$minutos = $this->calcMinutosDiff($diff);
			} elseif ($ini_marcacao >= $jornada_ini || $fim_marcacao <= $jornada_fim) {
				// quando marcacao extra é dentro da jornada de trabalho, não contabiliza
				$minutos = 0;
			} elseif ($ini_marcacao <= $jornada_ini && $fim_marcacao >= $jornada_fim) {
				$diff1 = $this->checkHorasDiff($ini_marcacao, $jornada_ini, true);
				$minutos = $this->calcMinutosDiff($diff1);
				$diff2 = $this->checkHorasDiff($jornada_fim, $fim_marcacao, true);
				$minutos += $this->calcMinutosDiff($diff2);
				if ($jornada['ini_prev'] && $jornada['fim_prev']) {
					$diff_jornada = $this->checkHorasDiff($jornada_ini, $jornada_fim, true);
					$this->calendario['diario'][$ponto_partida]['add_extra_jornada'] = $this->calcMinutosDiff($diff_jornada);
				}
			} else {
				echo 'avisar RH ERRO CODIGO: 1325';
				echo '<pre>';
				var_dump($ini_marcacao, $fim_marcacao, $minutos, $jornada_ini, $jornada_fim);
				echo '</pre>';
				exit;
			}
			return $minutos;
		}

		function calcularHoras($tipo = 'ponto')
		{
			switch ($tipo) {
				case 'ponto':
					if (isset($this->matriz_calendario['diario']['marcacoes']) && is_array($this->matriz_calendario['diario']['marcacoes'])) {
						foreach ($this->matriz_calendario['diario']['marcacoes'] as $value) {
							$da = ($value[0]->data_referencia) ? $value[0]->data_referencia : $value[0]->data_marcacao;
							$this->calendario['diario'][$da]['marcacoes'][] = $value;
						}
					}

					if (isset($this->calendario['diario']) && is_array($this->calendario['diario'])) {
						foreach ($this->calendario['diario'] as $key => $value) {
							$atual = getDataAtual($key);
							$horas_noturnas = 0;
							$this->calendario['diario'][$key]['horas_trabalhadas'] = null;
							$this->calendario['diario'][$key]['pendencia'] = null;
							$this->calendario['diario'][$key]['mensagem'] = null;
							if ($atual >= $this->data_inicio && $atual <= $this->data_fim) {
								if ($value['marcacoes']) {
									if ($value['marcacoes'] != false && count($value['marcacoes']) > 0) {
										foreach ($value['marcacoes'] as $k1 => $v1) {
											$minuto_tolerancia = 5;
											$horas_noturnas = null;
											$incluir_noturnas = false;
											$this->calendario['diario'][$key]['horas_trabalhadas'][$k1] = null;
											if (!$this->checkFeriado($key, $v1)) {
												$jornada = $this->calendario['diario'][$key]['jornada'];
												// contabilizando horas de entrada
												if ($v1[0]->status == 'aprovado' && $v1[1]->status == 'aprovado') {
													if ($v1[0]->hora_marcacao && $v1[1]->hora_marcacao) {
														$d1 = $this->createObjDate($v1[0], 'marcacao');
														$d2 = $this->createObjDate($v1[1], 'marcacao');
														$horas_noturnas = $this->checkNoturno($v1[0], $v1[1], $key, $jornada);
														$diff = $this->checkHorasDiff($d1, $d2, true);
														$minutos = $this->calcMinutosDiff($diff);
														if ($horas_noturnas) {
															$this->calendario['diario'][$key]['horas_noturnas'][$k1] += $horas_noturnas;
															$add_noturnas = (($horas_noturnas / 100) * 30);
															$this->calendario['diario'][$key]['add_noturnas'][$k1] += $add_noturnas;
														}

														if ($d1 > $value['jornada']['ini_prev']) {
															$diff_atraso = $this->checkHorasDiff($value['jornada']['ini_prev'], $d1, true);
															$minuto_extras = $this->calcMinutosDiff($diff_atraso);
															if ($minuto_extras > 0) {
																if ($minuto_extras == $minuto_tolerancia) {
																	$minutos += $minuto_tolerancia;
																} elseif ($minuto_extras < $minuto_tolerancia) {
																	$minutos += $minuto_extras;
																}
															}
														} elseif ($d1 < $value['jornada']['ini_prev']) {
															$diff_atraso = $this->checkHorasDiff($d1, $value['jornada']['ini_prev'], true);
															$minuto_extras = $this->calcMinutosDiff($diff_atraso);
															$this->calendario['diario'][$key]['horas_excedidas'][$k1] += $minuto_extras;
															if ($minuto_extras > 0) {
																if ($minuto_extras == $minuto_tolerancia) {
																	$minutos -= $minuto_tolerancia;
																} elseif ($minuto_extras < $minuto_tolerancia) {
																	$minutos -= $minuto_extras;
																}
															}
														}
														$this->calendario['diario'][$key]['horas_trabalhadas'][$k1] += $minutos;
													}
												} elseif ($v1[0]->status == 'pendente' || $v1[1]->status == 'pendente') {
													$this->calendario['diario'][$key]['pendencia'] = true;
													$this->calendario['diario'][$key]['mensagem'][$k1] = 'APROVACAO PENDENTE 2';
													$this->calendario['diario'][$key]['horas_trabalhadas'][$k1] += 0;
												} else {
													$this->calendario['diario'][$key]['horas_trabalhadas'][$k1] += 0;
												}

												// contabilizando horas de saida
												if ($v1[2]->status == 'aprovado' && $v1[3]->status == 'aprovado') {
													if ($v1[2]->hora_marcacao && $v1[3]->hora_marcacao) {
														$d1 = $this->createObjDate($v1[2], 'marcacao');
														$d2 = $this->createObjDate($v1[3], 'marcacao');
														$horas_noturnas = $this->checkNoturno($v1[2], $v1[3], $key, $jornada);
														$diff = $this->checkHorasDiff($d1, $d2, true);
														$minutos = $this->calcMinutosDiff($diff);
														if ($horas_noturnas) {
															$this->calendario['diario'][$key]['horas_noturnas'][$k1] += $horas_noturnas;
															$add_noturnas = (($horas_noturnas / 100) * 30);
															$this->calendario['diario'][$key]['add_noturnas'][$k1] += $add_noturnas;
														}

														if ($d2 > $value['jornada']['fim_prev']) {
															$diff_atraso = $this->checkHorasDiff($value['jornada']['fim_prev'], $d2, true);
															$minuto_extras = $this->calcMinutosDiff($diff_atraso);
															$this->calendario['diario'][$key]['horas_excedidas'][$k1] += $minuto_extras;
															if ($minuto_extras > 0) {
																if ($minuto_extras == $minuto_tolerancia) {
																	$minutos -= $minuto_tolerancia;
																} elseif ($minuto_extras < $minuto_tolerancia) {
																	$minutos -= $minuto_extras;
																}
															}
														} elseif ($d2 < $value['jornada']['fim_prev']) {
															$diff_atraso = $this->checkHorasDiff($d2, $value['jornada']['fim_prev'], true);
															$minuto_extras = $this->calcMinutosDiff($diff_atraso);
															if ($minuto_extras > 0) {
																if ($minuto_extras == $minuto_tolerancia) {
																	$minutos += $minuto_tolerancia;
																} elseif ($minuto_extras < $minuto_tolerancia) {
																	$minutos += $minuto_extras;
																}
															}
														}
														$this->calendario['diario'][$key]['horas_trabalhadas'][$k1] += $minutos;
													}
												} elseif ($v1[2]->status == 'pendente' || $v1[3]->status == 'pendente') {
													
													$this->calendario['diario'][$key]['pendencia'] = true;
													$this->calendario['diario'][$key]['mensagem'][$k1] = 'APROVACAO PENDENTE 1';
													$this->calendario['diario'][$key]['horas_trabalhadas'][$k1] += 0;
												} else {
													$this->calendario['diario'][$key]['horas_trabalhadas'][$k1] += 0;
												}

												// contabilizando horario de almoço
												if ($v1[1]->status == 'aprovado' && $v1[2]->status == 'aprovado') {
													if ($v1[1]->hora_marcacao && $v1[2]->hora_marcacao) {
														$d1 = $this->createObjDate($v1[1], 'marcacao');
														$d2 = $this->createObjDate($v1[2], 'marcacao');
														$diff = $this->checkHorasDiff($d1, $d2, true);
														$minutos_almoco = $this->calcMinutosDiff($diff);
														$this->calendario['diario'][$key]['tempo_almoco_min'][$k1] += $minutos_almoco;
													} else {
														$this->calendario['diario'][$key]['tempo_almoco_min'][$k1] += 0;
													}
												} else {
													$this->calendario['diario'][$key]['tempo_almoco_min'][$k1] += 0;
												}

												// quando não há marcações do almoço
												if (!$v1[1]->hora_marcacao && !$v1[2]->hora_marcacao) {
													$this->calendario['diario'][$key]['tempo_almoco_min'][$k1] += 0;
													if ($v1[0]->status == 'aprovado' && $v1[3]->status == 'aprovado') {
														if ($v1[0]->hora_marcacao && $v1[3]->hora_marcacao) {

															$d1 = $this->createObjDate($v1[0], 'marcacao');
															$d2 = $this->createObjDate($v1[3], 'marcacao');
															$horas_noturnas = $this->checkNoturno($v1[0], $v1[3], $key, $jornada);

															$diff = $this->checkHorasDiff($d1, $d2, true);
															$minutos = $this->calcMinutosDiff($diff);

															if ($horas_noturnas) {
																$add_noturnas = (($horas_noturnas / 100) * 30);
																$this->calendario['diario'][$key]['horas_noturnas'][$k1] += $horas_noturnas;
																$this->calendario['diario'][$key]['add_noturnas'][$k1] += $add_noturnas;
															}

															if ($d1 > $value['jornada']['ini_prev']) {
																$diff_atraso = $this->checkHorasDiff($value['jornada']['ini_prev'], $d1, true);
																$minuto_extras = $this->calcMinutosDiff($diff_atraso);
																$this->calendario['diario'][$key]['horas_excedidas'][$k1] += $minuto_extras;
																if ($minuto_extras > 0) {
																	if ($minuto_extras == $minuto_tolerancia) {
																		$minutos += $minuto_tolerancia;
																	} elseif ($minuto_extras < $minuto_tolerancia) {
																		$minutos += $minuto_extras;
																	}
																}
															} elseif ($d1 < $value['jornada']['ini_prev']) {
																$diff_atraso = $this->checkHorasDiff($d1, $value['jornada']['ini_prev'], true);
																$minuto_extras = $this->calcMinutosDiff($diff_atraso);
																$this->calendario['diario'][$key]['horas_excedidas'][$k1] += $minuto_extras;
																if ($minuto_extras > 0) {
																	if ($minuto_extras == $minuto_tolerancia) {
																		$minutos -= $minuto_tolerancia;
																	} elseif ($minuto_extras < $minuto_tolerancia) {
																		$minutos -= $minuto_extras;
																	}
																}
															}
															$this->calendario['diario'][$key]['horas_trabalhadas'][$k1] += $minutos;
														}
													} elseif ($v1[0]->status == 'pendente' || $v1[3]->status == 'pendente') {
														$this->calendario['diario'][$key]['pendencia'] = true;
														$this->calendario['diario'][$key]['mensagem'][$k1] = 'APROVACAO PENDENTE';
														$this->calendario['diario'][$key]['horas_trabalhadas'][$k1] += 0;
													} else {
														$this->calendario['diario'][$key]['horas_trabalhadas'][$k1] += 0;
													}
												}
											}
										}
									} else {
										echo '987';
										exit;
									}
								} else {
									if ($value['dia_util']) {
										$this->checkFeriado($key);
									}
								}
							}
						}
					}
					break;
				case 'pausa':
					if (isset($this->matriz_calendario['diario']['pausa'])) {
						foreach ($this->matriz_calendario['diario']['pausa'] as $key => $value) {
							if (isset($value) && is_array($value)) {
								$div_pausas = 0;
								$sum = 0;
								foreach ($value as $k1 => $v1) {
									$i = $k1;
									$p1 = ($k1 + 1);
									$atual = $value[$i];
									$proximo = $value[$p1];
									$da = $atual->data_referencia;
									$resumo = $this->calendario['diario'][$da];
									$count_div = count($this->calendario['diario'][$da]['marcacoes']);
									if (isset($resumo['dia_util']) && $resumo['dia_util'] == true) {

										if (!$atual->hora_marcacao) {
											$atual->falta_pausa = true;
											continue;
										}

										if (!$proximo->hora_marcacao) {
											$proximo->falta_pausa = true;
											continue;
										}
										
										if ($atual && $proximo) {
											$minutos = 0;
											if ($atual->tipo_marcacao == 'B05' && $proximo->tipo_marcacao == 'B06') {
												$d1 = $this->createObjDate($atual, 'marcacao');
												$d2 = $this->createObjDate($proximo, 'marcacao');
												$arr_pausa = [];
												array_push($arr_pausa, [$d1, $d2]);
												// $diff = $this->checkHorasDiff($d1, $d2, true);
												$minutos = (strtotime($d2->format('Y-m-d H:i:s')) - strtotime($d1->format('Y-m-d H:i:s'))) / 60;
												// para incluir os minutos de tolerancia descomente abaixo
												// if( $minutos >= 10){
												// 	$minutos -= 10;
												// }
												$this->calendario['diario'][$da]['calc_pausas'][0] += $minutos;
												if ($count_div > 2) {
													$div_pausas = array_chunk($this->calendario['diario'][$da]['calc_pausas'], $count_div);
												} else {
													$div_pausas = null;
													if (isset($this->calendario['diario'][$da]['calc_pausas'])) {
														$div_pausas = array_chunk($this->calendario['diario'][$da]['calc_pausas'], 2);
													}
												}
											} else {
												$this->calendario['diario']['resumo'][$da]['erro'] = true;
												$this->calendario['diario']['resumo'][$da]['mensagem'] = 'FALTA MARCAÇÃO B05 ou B06';
											}
										}
									}
								}
							}

							if ($div_pausas) {
								$this->calendario['diario'][$da]['minutos_pausa'] = $div_pausas[0][0];
								$this->calendario['diario'][$da]['arr_pausas'][$key] = $arr_pausa;
							}
						}
					}

					if (isset($this->calendario['diario']) && is_array($this->calendario['diario'])) {
						foreach ($this->calendario['diario'] as $key => $value) {
							if (isset($value['minutos_pausa']) && count($value['minutos_pausa']) > 0) {
								foreach ($value['minutos_pausa'] as $k1 => $v1) {
									if (is_array($v1)) {
										$this->calendario['diario'][$key]['minutos_pausa'][$k1] = array_sum($v1);
									}
								}
							}
						}
					}
					break;
				case 'extra':
					if (!empty($this->matriz_calendario['diario']['extra'])) {
						foreach ($this->matriz_calendario['diario']['extra'] as $key => $value) {
							$div_extras = null;
							$div_noturnas = null;
							$div_noturnas = null;
							$div_add_noturnas = null;
							foreach ($value as $k1 => $v1) {
								$i = $k1;
								$p1 = ($k1 + 1);
								$atual = $value[$i];
								$proximo = $value[$p1];
								$da = $atual->data_referencia;
								$minutos_extra = 0;
								$count_div = count($this->calendario['diario'][$da]['marcacoes']);
								$marcacoes = $this->calendario['diario'][$da]['marcacoes'][$key];
								if (!$atual->hora_marcacao) {
									$atual->falta_extra = true;
									continue;
								}

								if (!$proximo->hora_marcacao) {
									$proximo->falta_extra = true;
									continue;
								}

								if ($atual && $proximo) {
									if ($atual->data_referencia == $proximo->data_referencia) {
										$da = $atual->data_referencia;
									} else {
										$da = $proximo->data_referencia;
									}

									$minutos = 0;
									$jornada = $this->calendario['diario'][$da]['jornada'];
									$aderir_feriado = $this->calendario['diario'][$da]['aderir_feriado'];
									$dia_semana = $this->calendario['diario'][$da]['dia_semana'];
									if ($atual->tipo_marcacao == 'B07' && $proximo->tipo_marcacao == 'B08') {
										if ($this->checkFeriado($da, $value, 'extra') || $dia_semana == 'dom') {
											$hora_inicio = $this->createObjDate($atual);
											$hora_final = $this->createObjDate($proximo);
											$diff = $this->checkHorasDiff($hora_inicio, $hora_final, true);
											$minutos_extra = $this->calcMinutosDiff($diff);
											if ($minutos_extra) {
												$this->calendario['diario'][$da]['calc_add_extras'][$k1] += (($minutos_extra / 100) * 40);
											}
										} else {
											$minutos_extra = $this->checkHoraExtra($value[$i], $value[$p1], $da);
										}

										if ($minutos_extra) {
											$this->calendario['diario'][$da]['calc_extras'][$k1] += $minutos_extra;
										} else {
											$this->calendario['diario'][$da]['calc_extras'][$k1] += 0;
											$this->calendario['diario'][$da]['calc_add_extras'][$k1] += 0;
										}

										$horas_noturnas = $this->checkNoturno($atual, $proximo, $da);
										if ($horas_noturnas) {
											$this->calendario['diario'][$da]['horas_noturnas'][$k1] += $horas_noturnas;
											$this->calendario['diario'][$da]['calc_add_noturnas'][$k1] += (($horas_noturnas / 100) * 30);
										}

										if ($count_div > 2) {
											$div_extras = array_chunk($this->calendario['diario'][$da]['calc_extras'], $count_div);
											$div_add_extras = array_chunk($this->calendario['diario'][$da]['calc_add_extras'], $count_div);
											$div_add_noturnas = array_chunk($this->calendario['diario'][$da]['calc_add_noturnas'], $count_div);
										} elseif ($count_div == 2) {
											$div_extras = array_chunk($this->calendario['diario'][$da]['calc_extras'], 2);
											$div_add_extras = array_chunk($this->calendario['diario'][$da]['calc_add_extras'], 2);
											$div_add_noturnas = array_chunk($this->calendario['diario'][$da]['calc_add_noturnas'], 2);
										} else {
											$div_extras[0] = $this->calendario['diario'][$da]['calc_extras'];
											$div_add_extras[0] = $this->calendario['diario'][$da]['calc_add_extras'];
											$div_add_noturnas[0] = $this->calendario['diario'][$da]['calc_add_noturnas'];
										}
									} else {
										$this->calendario['diario']['resumo'][$da]['erro'] = true;
										$this->calendario['diario']['resumo'][$da]['mensagem'] = 'FALTA MARCAÇÃO B07 ou B08';
									}
								}
							}
							$this->calendario['diario'][$da]['horas_extras'] = $div_extras;
							$this->calendario['diario'][$da]['add_extras'] = $div_add_extras;
							$this->calendario['diario'][$da]['add_noturnas'] = $div_add_noturnas;
						}
					}

					if (isset($this->calendario['diario']) && is_array($this->calendario['diario'])) {
						foreach ($this->calendario['diario'] as $key => $value) {
							if (isset($value['horas_extras'])) {
								foreach ($value['horas_extras'] as $k1 => $v1) {
									if (is_array($v1)) {
										$this->calendario['diario'][$key]['horas_extras'][$k1] = array_sum($v1);
									}
								}
							}

							if (isset($value['add_extras'])) {
								foreach ($value['add_extras'] as $k1 => $v1) {
									if (array_sum($v1)) {
										$this->calendario['diario'][$key]['add_extras'][$k1] = array_sum($v1);
									}
								}
							}

							if (isset($value['add_noturnas'])) {
								foreach ($value['add_noturnas'] as $k1 => $v1) {
									if (array_sum($v1)) {
										$this->calendario['diario'][$key]['add_noturnas'][$k1] = array_sum($v1);
									}
								}
							}
						}
					}
					break;
				default:
					echo '774';
					exit;
					break;
			}
		}

		function calcularSaldo($linha = null)
		{
			$saldo = false;
			$total_extra = null;
			$add_noturnas = null;
			$add_extras = null;
			if (isset($this->calendario['diario']) && is_array($this->calendario['diario'])) {
				foreach ($this->calendario['diario'] as $key => $value) {
					if (isset($this->calendario['diario'][$key]['jornada'])) {
						$jornada = $this->calendario['diario'][$key]['jornada'];
					} else {
						$jornada = null;
					}

					$d1 = getDataAtual($key);
					if ($d1 >= $this->data_inicio && $d1 <= $this->data_fim) {
						if (!empty($value['marcacoes']) || count($value['marcacoes']) > 0) {
							foreach ($value['marcacoes'] as $k1 => $v1) {
								if (!$this->checkFeriado($key, $v1)) {
									if (!$value['dia_abonado']) {
										if (!isset($v1[0]->hora_marcacao) || empty($v1[0]->hora_marcacao)) {
											$this->calendario['diario'][$key]['mensagem'][0] = 'FALTA ENTRADA';
										}
									}

									if (!$value['dia_abonado']) {
										if (!isset($v1[3]->hora_marcacao) || empty($v1[3]->hora_marcacao)) {
											$this->calendario['diario'][$key]['mensagem'][0] = 'FALTA SAIDA';
										}
									}

									if (!$value['dia_abonado']) {
										if (!isset($v1[1]->hora_marcacao) || empty(isset($v1[1]->hora_marcacao))) {
											if (!$v1[0]->hora_marcacao || !$v1[3]->hora_marcacao) {
												$this->calendario['diario'][$key]['mensagem'][$k1] = 'FALTA SAIDA ALMOÇO';
											}
										}
									}

									if (!$value['dia_abonado']) {
										if (!isset($v1[2]->hora_marcacao) || empty(isset($v1[2]->hora_marcacao))) {
											if (!$v1[0]->hora_marcacao || !$v1[3]->hora_marcacao) {
												$this->calendario['diario'][$key]['mensagem'][$k1] = 'FALTA RETORNO ALMOÇO';
											}
										}
									}
								}
							}
						} else {
							if ($value['dia_util']) {
								$this->checkFeriado($key);
							}
						}

						$saldo_horas = $value['horas_previstas'];
						if (isset($value['horas_trabalhadas'])) {
							if (count($value['horas_trabalhadas']) > 1) {
								$saldo_horas += $value['horas_previstas'];
								$this->calendario['total']['horas_previstas'] += $value['horas_previstas'];
							}

							foreach ($value['horas_trabalhadas'] as $k1 => $v1) {
								$saldo_horas = $value['horas_previstas'];
								$saldo_horas += $v1;
								$this->calendario['diario'][$key]['saldo'][$k1] = $saldo_horas;
								$this->calendario['total']['horas_trabalhadas'] += $v1;
							}
						} else {
							$saldo_horas += 0;
							$this->calendario['diario'][$key]['saldo'][0] = $saldo_horas;
						}


						if (isset($value['calc_pausas'])) {
							foreach ($value['calc_pausas'] as $k1 => $v1) {
								$saldo_horas -= $v1;
								$this->calendario['diario'][$key]['saldo'][$k1] = $saldo_horas;
								$this->calendario['total']['minutos_pausa'] += $v1;
							}
						}

						if (isset($value['horas_extras']) && is_array($value['horas_extras']) && array_sum($value['horas_extras']) > 0) {
							foreach ($value['horas_extras'] as $k1 => $v1) {
								if (!$value['horas_trabalhadas']) {
									$total_extra = ($value['add_extra_jornada'] + $v1);
									$saldo_horas += $total_extra;
									$this->calendario['total']['horas_extras'] += $total_extra;
								} else {
									$saldo_horas += $v1;
									$this->calendario['total']['horas_extras'] += $v1;
								}
								$this->calendario['diario'][$key]['saldo'][$k1] = $saldo_horas;
							}
							$total_extra = $this->calendario['total']['horas_extras'];
						}

						if (isset($value['add_extras']) && is_array($value['add_extras']) && array_sum($value['add_extras']) > 0) {
							foreach ($value['add_extras'] as $k1 => $v1) {
								$this->calendario['diario'][$key]['add_extras'][$k1] = $v1;
								if (is_array($v1)) {
									$this->calendario['total']['add_extras'] += array_sum($v1);
								} else {

									$this->calendario['total']['add_extras'] += $v1;
								}
							}
							$add_extras = $this->calendario['total']['add_extras'];
						} else {
							$add_extras += 0;
						}

						if (isset($value['horas_abonadas']) && is_array($value['horas_abonadas']) && array_sum($value['horas_abonadas']) > 0) {
							$saldo = true;
							foreach ($value['horas_abonadas'] as $k1 => $v1) {
								$saldo_horas += $v1;
								$this->calendario['diario'][$key]['saldo'][$k1] = $saldo_horas;
								$this->calendario['total']['horas_abonadas'] += $v1;
							}
						}

						if (isset($value['horas_noturnas']) && is_array($value['horas_noturnas']) && array_sum($value['horas_noturnas']) > 0) {
							foreach ($value['horas_noturnas'] as $k1 => $v1) {
								$this->calendario['total']['horas_noturnas'] += $v1;
							}
						}

						if (isset($value['add_noturnas']) && is_array($value['add_noturnas']) && array_sum($value['add_noturnas']) > 0) {
							foreach ($value['add_noturnas'] as $k1 => $v1) {
								$saldo_horas += $v1;
								if ($jornada['aderir_add_noturno'] === 0) {
									$this->calendario['diario'][$key]['saldo'][$k1] = $saldo_horas;
								}
								$this->calendario['total']['add_noturnas'] += $v1;
							}

							if ($jornada['aderir_add_noturno'] === 0) {
								$add_noturnas = $this->calendario['total']['add_noturnas'];
							}
						}
					}
				}
				if ($this->calendario['total']['horas_previstas'] < 0) {
					$creditos = ($this->calendario['total']['horas_previstas'] - $this->calendario['total']['minutos_pausa']);
				} else {
					$creditos = ($this->calendario['total']['horas_previstas'] + $this->calendario['total']['minutos_pausa']);
				}
				$debitos = ($this->calendario['total']['horas_abonadas'] + $this->calendario['total']['horas_trabalhadas'] + $total_extra + $add_extras + $add_noturnas);
				$this->calendario['total']['saldo_parcial'] = ($creditos + $debitos);
				$this->calendario['total']['saldo'] = ($this->calendario['total']['saldo_parcial'] + $this->calendario['total']['saldo_anterior']);
			}
		}

		function checkFeriado($data, $dados = null, $tipo = 'marcacao', $linha = null)
		{
			switch ($tipo) {
				case 'marcacao':
					$nome_mes = returnMesData($data, 'mes');
					$dia_mes = returnMesData($data, 'dia');
					$feriados = null;
					if (isset($this->feriados[$nome_mes][$dia_mes])) {
						$feriados = $this->feriados[$nome_mes][$dia_mes];
					}

					// Check feriado
					if (($feriados['tipo'] == 'F02' && $feriados['validade'] == $data) || ($feriados['tipo'] == 'F01')) {
						if ($this->calendario['diario'][$data]['jornada']['aderir_feriado']) {
							$this->calendario['diario'][$data]['feriado'] = true;
							$this->calendario['diario'][$data]['status'][0] = 'FERIADO';
							$this->calendario['diario'][$data]['mensagem'][] = $feriados['nome'];
							$this->abonarHoras('dia', $data);
							return true;
						}
					}
					// Check abono
					if ($dados) {
						if (
							!$dados[0]->hora_marcacao &&
							!$dados[1]->hora_marcacao &&
							!$dados[2]->hora_marcacao &&
							!$dados[3]->hora_marcacao
						) {
							$this->calendario['diario'][$data]['feriado'] = false;
							$this->calendario['diario'][$data]['status'][0] = 'DSR';
							return true;
						} else {
							// $this->calendario['diario'][$data]['valor_abono']     = 0;
							// $this->calendario['diario'][$data]['horas_previstas'] = 0;
							return false;
						}
					} else {
						if (isset($this->calendario['diario'][$data]['dia_abonado'])) {
							$this->calendario['diario'][$data]['feriado'] = false;
							if (isset($this->calendario['diario'][$data]['motivo'][0])) {
								$this->calendario['diario'][$data]['status'][0] = $this->calendario['diario'][$data]['motivo'][0];
							} else {
								$this->calendario['diario'][$data]['status'][0] = 'DSR';
							}
						}
					}

					if ($this->calendario['diario'][$data]['dia_util']) {
						if ($dados) {
							if (
								!$dados[0]->hora_marcacao &&
								!$dados[1]->hora_marcacao &&
								!$dados[2]->hora_marcacao &&
								!$dados[3]->hora_marcacao
							) {
								$this->calendario['diario'][$data]['feriado'] = false;
								$this->calendario['diario'][$data]['status'][0] = 'FALTA COD 1209';
								return true;
							} else {
								return false;
							}
						} else {
							return false;
						}
					} else {
						$this->calendario['diario'][$data]['feriado'] = false;
						$this->calendario['diario'][$data]['status'][0] = 'FOLGA';
						return true;
					}
					break;
				case 'extra':
					$nome_mes = returnMesData($data, 'mes');
					$dia_mes = returnMesData($data, 'dia');
					$feriados = $this->feriados[$nome_mes][$dia_mes];
					// Check feriado
					if (($feriados['tipo'] == 'F02' && $feriados['validade'] == $data) || ($feriados['tipo'] == 'F01')) {
						return true;
					}
					return false;
					break;
			}
		}

		function checarAbono()
		{
			if (isset($this->calendario['diario']) && is_array($this->calendario['diario'])) {
				foreach ($this->calendario['diario'] as $key => $value) {
					if (isset($value['tipo_abono'])) {
						$tipo_abono = $value['tipo_abono'];
					} else {
						$tipo_abono = null;
					}

					switch ($tipo_abono) {
						case 'extras':
							if ($value['marcacoes'] != false && count($value['marcacoes']) > 0) {
								foreach ($value['marcacoes'] as $k1 => $v1) {
									if ($value['horas_trabalhadas'][$k1] >= abs($value['horas_previstas'])) {
										echo '1372';
										exit;
									} else {
										echo '1375';
										exit;
									}
									$this->calendario['diario'][$key]['horas_abonadas'][$k1] = ($value['valor_abono'] - $value['minutos_pausa'][$k1]);
								}
							}
							break;
						default:
							$abonar = true;
							$this->calendario['diario'][$key]['horas_abonadas'][0] = 0;
							if ($this->calendario['diario'][$key]['ocorrencias']) {
								$tempo_abonado = 0;
								foreach ($this->calendario['diario'][$key]['ocorrencias'] as $k => $ocorrencia) {
									// $tempo_abonado += $ocorrencia['minuto'];
									$this->calendario['total']['devedor_folha'] -= $ocorrencia->minuto;
								}
							}

							if (isset($value['horas_previstas']) && $value['horas_previstas'] < 0) {
								if ($value['dia_util'] && isset($value['valor_abono']) && !empty($value['valor_abono'])) {
									$pausas = 0;
									if (isset($value['minutos_pausa'])) {
										$pausas = $value['minutos_pausa'];
									} 

									if (isset($value['valor_abono'])) {
										$soma_abono = array_sum($value['valor_abono']);
									} else {
										$soma_abono = 0;
									}

									if (isset($value['tempo_almoco_min'])) {
										$excesso_almoco = ($value['jornada']['tempo_almoco_min'] - array_sum($value['tempo_almoco_min']));
									} else {
										$excesso_almoco = 0;
									}

									if ($excesso_almoco >= 0) {
										$excesso_almoco = 0;
									}

									if (isset($value['horas_excedidas'])) {
										$horas_excedidas = array_sum($value['horas_excedidas']);
									} else {
										$horas_excedidas = 0;
									}

									if (isset($value['horas_excedidas'])) {
										$horas_excedidas = array_sum($value['horas_excedidas']);
										$horas_normais = (array_sum($value['horas_trabalhadas']) - $horas_excedidas);
									} else {
										$horas_excedidas = 0;
										$horas_normais = 0;
									}

									if ($value['dia_abonado'][0] == true) {
										$saldo_restante = ($value['horas_previstas'] + array_sum($value['horas_trabalhadas']));
										if ($saldo_restante < 0) {
											$this->calendario['diario'][$key]['horas_abonadas'][0] = abs(-$saldo_restante);
										}
									} else {
										if (isset($value['com_marcacoes']) && $value['com_marcacoes'] == true) {
											if (!$this->checkMarcacaoExiste($key)) {
												$abonar = false;
											}
										}

										if ($abonar) {
											$debitos = ($excesso_almoco + $pausas);
											$saldo_restante = ($value['horas_previstas'] + $debitos + $horas_normais);
											if ($debitos < 0) {
												if (abs(-$saldo_restante) > $soma_abono) {
													$this->calendario['diario'][$key]['horas_abonadas'][0] = ($soma_abono);
												} else {
													$this->calendario['diario'][$key]['horas_abonadas'][0] = (abs(-$debitos));
												}
											} else {
												if($pausas < $soma_abono){
													if($saldo_restante >= 0){
														$this->calendario['diario'][$key]['horas_abonadas'][0] = $pausas;
													}else{
														$this->calendario['diario'][$key]['horas_abonadas'][0] = $soma_abono;
													}
												}elseif($soma_abono > $debitos){
													$this->calendario['diario'][$key]['horas_abonadas'][0] = $debitos;
												}else{
													$this->calendario['diario'][$key]['horas_abonadas'][0] = $soma_abono;
												}
											}
										}
									}
								} else {
									if (!$value['dia_util']) {
										$this->calendario['diario'][$key]['pendencia'] = false;
										$this->calendario['diario'][$key]['status'][0] = 'FOLGA';
									}
								}
							}
							break;
					}
					$this->calendario['diario'][$key]['pendencia'] = false;
				}
			}
		}

		function finalizaMatriz($value, $tipo = 'ponto')
		{
			switch ($tipo) {
				case 'ponto':
					switch ($value->tipo_marcacao) {
						case 'B01':
							$this->matriz_marcacoes['ponto'][] = $value;
							$array_tipo = array('B02', 'B03', 'B04');
							$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
							break;
						case 'B02':
							$array_tipo = array('B01');
							$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
							$this->matriz_marcacoes['ponto'][] = $value;
							$array_tipo = array('B03', 'B04');
							$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
							break;
						case 'B03':
							$array_tipo = array('B01', 'B02');
							$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
							$this->matriz_marcacoes['ponto'][] = $value;
							$array_tipo = array('B04');
							$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
							break;
						case 'B04':
							$array_tipo = array('B01', 'B02', 'B03');
							$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
							$this->matriz_marcacoes['ponto'][] = $value;
							break;
					}
					break;
			}
		}

		function preencheMatriz($ultima_marcacao, $value, $tipo = 'ponto', $end = false)
		{
			switch ($tipo) {
				case 'ponto':
					$data_ultima = $this->createObjDate($ultima_marcacao);
					$data_atual = $this->createObjDate($value);
					if (!$ultima_marcacao) {
						switch ($value->tipo_marcacao) {
							case 'B01':
								$this->matriz_marcacoes['ponto'][] = $value;
								break;
							case 'B02':
								$array_tipo = array('B01');
								$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
								$this->matriz_marcacoes['ponto'][] = $value;
								break;
							case 'B03':
								$array_tipo = array('B01', 'B02');
								$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
								$this->matriz_marcacoes['ponto'][] = $value;
								break;
							case 'B04':
								$array_tipo = array('B01', 'B02', 'B03');
								$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
								$this->matriz_marcacoes['ponto'][] = $value;
								break;
						}
					} elseif (!$end) {
						switch ($ultima_marcacao->tipo_marcacao) {
							case 'B01':
								switch ($value->tipo_marcacao) {
									case 'B01': // um entrada seguida de outra indica novo começo de jornada
										$array_tipo = array('B02', 'B03', 'B04');
										$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'ponto');
										$this->matriz_marcacoes['ponto'][] = $value;
										break;
									case 'B02':
										// checa a diferença entre o ultimo registro e o atual, se passar de 10 horas considera-se uma nova jornada
										if ($this->checkHorasDiff($data_ultima, $data_atual)) {
											$array_tipo = array('B02', 'B03', 'B04');
											$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'ponto');

											$array_tipo = array('B01');
											$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
										} else {
											$value->data_referencia = $ultima_marcacao->data_referencia;
										}
										$this->matriz_marcacoes['ponto'][] = $value;
										break;
									case 'B03':
										if ($this->checkHorasDiff($data_ultima, $data_atual)) {
											$array_tipo = array('B02', 'B03', 'B04');
											$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'ponto');

											$array_tipo = array('B01', 'B02');
											$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
										} else {
											$value->data_referencia = $ultima_marcacao->data_referencia;
											$array_tipo = array('B02');
											$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
										}
										$this->matriz_marcacoes['ponto'][] = $value;
										break;
									case 'B04':
										// checa a diferença entre o ultimo registro e o atual, se passar de 10 horas considera-se uma nova jornada
										if ($this->checkHorasDiff($data_ultima, $data_atual)) {
											$array_tipo = array('B02', 'B03', 'B04');
											$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'ponto');

											$array_tipo = array('B01', 'B02', 'B03');
											$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
										} else {
											$array_tipo = array('B02', 'B03');
											$value->data_referencia = $ultima_marcacao->data_referencia;
											$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
											$this->matriz_marcacoes['ponto'][] = $value;
										}
										break;
								}
								break;
							case 'B02':
								switch ($value->tipo_marcacao) {
									case 'B01': // um entrada seguida de outra indica novo começo de jornada
										$array_tipo = array('B03', 'B04');
										$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'ponto');
										$this->matriz_marcacoes['ponto'][] = $value;
										break;
									case 'B02':
										$array_tipo = array('B03', 'B04');
										$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'ponto');

										$array_tipo = array('B01');
										$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
										$this->matriz_marcacoes['ponto'][] = $value;
										break;
									case 'B03':
										// checa a diferença entre o ultimo registro e o atual, se passar de 10 horas considera-se uma nova jornada
										if ($this->checkHorasDiff($data_ultima, $data_atual)) {
											$array_tipo = array('B03', 'B04');
											$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'ponto');

											$array_tipo = array('B01', 'B02');
											$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
										} else {
											$value->data_referencia = $ultima_marcacao->data_referencia;
										}
										$this->matriz_marcacoes['ponto'][] = $value;
										break;
									case 'B04':
										// checa a diferença entre o ultimo registro e o atual, se passar de 10 horas considera-se uma nova jornada
										if ($this->checkHorasDiff($data_ultima, $data_atual)) {
											$array_tipo = array('B03', 'B04');
											$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'ponto');

											$array_tipo = array('B01', 'B02', 'B03');
											$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
										} else {
											$value->data_referencia = $ultima_marcacao->data_referencia;
											$array_tipo = array('B03');
											$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
											$this->matriz_marcacoes['ponto'][] = $value;
										}
										break;
								}
								break;
							case 'B03':
								switch ($value->tipo_marcacao) {
									case 'B01': // um entrada seguida de outra indica novo começo de jornada
										$array_tipo = array('B04');
										$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'ponto');
										$this->matriz_marcacoes['ponto'][] = $value;
										break;
									case 'B02':
										$array_tipo = array('B04');
										$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'ponto');
										$array_tipo = array('B01');
										$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
										$this->matriz_marcacoes['ponto'][] = $value;
										break;
									case 'B03':
										$array_tipo = array('B04');
										$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'ponto');
										$array_tipo = array('B01', 'B02');
										$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
										$this->matriz_marcacoes['ponto'][] = $value;
										break;
									case 'B04':
										// checa a diferença entre o ultimo registro e o atual, se passar de 10 horas considera-se uma nova jornada
										if ($this->checkHorasDiff($data_ultima, $data_atual)) {
											$array_tipo = array('B04');
											$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'ponto');
											$array_tipo = array('B01', 'B02', 'B03');
											$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
										} else {
											$value->data_referencia = $ultima_marcacao->data_referencia;
										}
										$this->matriz_marcacoes['ponto'][] = $value;
										break;
								}
								break;
							case 'B04':
								switch ($value->tipo_marcacao) {
									case 'B01': // um entrada seguida de outra indica novo começo de jornada
										$this->matriz_marcacoes['ponto'][] = $value;
										break;
									case 'B02':
										$array_tipo = array('B01');
										$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
										$this->matriz_marcacoes['ponto'][] = $value;
										break;
									case 'B03':
										// checa a diferença entre o ultimo registro e o atual, se passar de 10 horas considera-se uma nova jornada
										$array_tipo = array('B01', 'B02');
										$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
										$this->matriz_marcacoes['ponto'][] = $value;
										break;
									case 'B04':
										// checa a diferença entre o ultimo registro e o atual, se passar de 10 horas considera-se uma nova jornada
										$array_tipo = array('B01', 'B02', 'B03');
										$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'ponto');
										$this->matriz_marcacoes['ponto'][] = $value;
										break;
								}
								break;
						}
					} else {
						switch ($ultima_marcacao->tipo_marcacao) {
							case 'B01':
								$array_tipo = array('B02', 'B03', 'B04');
								$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'ponto');
								break;
							case 'B02':
								$array_tipo = array('B03', 'B04');
								$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'ponto');
								break;
							case 'B03':
								$array_tipo = array('B04');
								$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'ponto');
								break;
							case 'B04':
								// echo '<pre>';
								// 	var_dump( $ultima_marcacao, $value );
								// echo '</pre>';
								// $array_tipo = array('B04');
								// $this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'ponto');
								break;
							default:
								switch ($value->tipo_marcacao) {
									case 'B04':
										if ($value->hora_marcacao) {
											$this->matriz_marcacoes['ponto'][] = $value;
										} else {
											echo '<pre>';
											var_dump('1484');
											echo '</pre>';
											exit;
										}
										break;
								}
								break;
						}
					}
					break;
				case 'pausa':
					$data_ultima = $this->createObjDate($ultima_marcacao);
					$data_atual = $this->createObjDate($value);
					switch ($ultima_marcacao->tipo_marcacao) {
						case 'B05':
							switch ($value->tipo_marcacao) {
								case 'B05': // um entrada seguida de outra indica novo começo de jornada
									$array_tipo = array('B06');
									$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'pausa');
									$this->matriz_marcacoes['pausa'][] = $value;
									break;
								case 'B06':
									// checa a diferença entre o ultimo registro e o atual, se passar de 10 horas considera-se uma nova jornada
									if ($this->checkHorasDiff($data_ultima, $data_atual)) {
										$array_tipo = array('B06');
										$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'pausa');
										$array_tipo = array('B05');
										$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'pausa');
									} else {
										$value->data_referencia = $ultima_marcacao->data_referencia;
									}
									$this->matriz_marcacoes['pausa'][] = $value;
									break;
							}
							break;
						case 'B06':
							switch ($value->tipo_marcacao) {
								case 'B05': // um entrada seguida de outra indica novo começo de jornada
									$this->matriz_marcacoes['pausa'][] = $value;
									break;
								case 'B06':
									$array_tipo = array('B05');
									$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'pausa');
									$this->matriz_marcacoes['pausa'][] = $value;
									break;
							}
							break;
					}
					break;
				case 'extra':
					$data_ultima = $this->createObjDate($ultima_marcacao);
					$data_atual = $this->createObjDate($value);
					switch ($ultima_marcacao->tipo_marcacao) {
						case 'B07':
							switch ($value->tipo_marcacao) {
								case 'B07': // um entrada seguida de outra indica novo começo de jornada
									$array_tipo = array('B08');
									$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'extra');
									$this->matriz_marcacoes['extra'][] = $value;
									break;
								case 'B08':
									// checa a diferença entre o ultimo registro e o atual, se passar de 10 horas considera-se uma nova jornada
									if ($this->checkHorasDiff($data_ultima, $data_atual)) {
										$array_tipo = array('B08');
										$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'extra');

										$array_tipo = array('B07');
										$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'extra');
									} else {
										$value->data_referencia = $ultima_marcacao->data_referencia;
									}
									$this->matriz_marcacoes['extra'][] = $value;
									break;
							}
							break;
						case 'B08':
							switch ($value->tipo_marcacao) {
								case 'B07': // um entrada seguida de outra indica novo começo de jornada
									$this->matriz_marcacoes['extra'][] = $value;
									break;
								case 'B08':
									$array_tipo = array('B07');
									$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'extra');
									$this->matriz_marcacoes['extra'][] = $value;
									break;
							}
							break;
					}
					break;
			}
		}

		function eachMarcacao($ultima, $dias = 0, $linha = 0)
		{
			$dini = $this->createDate($ultima);
			for ($i = 0; $i < $dias; $i++) {
				$dini->modify('+1 day');
				$dindex = $dini->format('Y-m-d');
				$mdini = $this->mapa_marcacoes['marcacoes']['dias'][$dindex];
				// verificar se existe marcacoes nos dias seguintes
				if (!$mdini) {
					$array_tipo = array('B01');
					$objEmpty = $this->criarObjMarcacaoVazio($dindex, $array_tipo, 'ponto');
					$this->reorderPonto($ultima, $objEmpty[0], 1605);
				} else {
					$this->reorderPonto($ultima, $objEmpty[0], 1620);
				}
			}
		}

		function switchMarcacao($atual, $linha)
		{
			if (!$atual) {
				return false;
			}

			$marcacaoOntem = null;
			$escala_anterior = false;
			$ultima = end($this->matriz_marcacoes['ponto']);
			$objDataAtual = $this->createDate($atual);
			$objDataOntem = clone $objDataAtual;
			$objDataOntem->modify('-1 day');
			$data_atual = $objDataAtual->format('Y-m-d');
			$data_ontem = $objDataOntem->format('Y-m-d');

			if (!$ultima) {
				// verifica se tem marcacao no dia anterior
				$marcacoes_ontem = $this->mapa_marcacoes['marcacoes']['dias'][$data_ontem];
				// verifica se tem marcacoes ontem
				if ($marcacoes_ontem) {
					$ultima = end($marcacoes_ontem);
					if ($ultima) {
						$ultima_data = new DateTime($ultima->data_marcacao . ' ' . $ultima->hora_marcacao);
						$atual_data = new DateTime($atual->data_marcacao . ' ' . $atual->hora_marcacao);
						$diff_data = $ultima_data->diff($atual_data);
						if ($diff_data->days > 0) {
							$this->eachMarcacao($atual, $diff_data->days, 1652);
						} else {
							if (!$this->checkHorasDiff($ultima_data, $atual_data)) {
								$this->reorderPonto($ultima, $atual, 1643);
							} else {
								if ($atual->tipo_marcacao != 'B01') {
									$this->reorderPonto($ultima, null, 1655);
								}
								$this->reorderPonto($ultima, $atual, 1657);
							}
						}
					} else {
						if ($atual->tipo_marcacao != 'B01') {
							$this->reorderPonto($ultima, null, 1667);
						}
						$this->reorderPonto($ultima, $atual, 1669);
					}
				} else {
					switch ($atual->tipo_marcacao) {
						case 'B02':
							$array_tipo = array('B01');
							$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
							break;
						case 'B03':
							$array_tipo = array('B01', 'B02');
							$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
							break;
						case 'B04':
							$array_tipo = array('B01', 'B02', 'B03');
							$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
							break;
					}
					$ultima = end($this->matriz_marcacoes['ponto']);
					$this->reorderPonto($ultima, $atual, 1687);
				}
			} else {
				$ultima_data = new DateTime($ultima->data_marcacao . ' ' . $ultima->hora_marcacao);
				$atual_data = new DateTime($atual->data_marcacao . ' ' . $atual->hora_marcacao);
				$diff_data = $ultima_data->diff($atual_data);
				if ($diff_data->days > 0) {
					$this->eachMarcacao($ultima, $diff_data->days, 1689);
					$ultima = end($this->matriz_marcacoes['ponto']);
					$this->reorderPonto($ultima, $atual, 1725);
				} else {
					$this->reorderPonto($ultima, $atual, 1727);
				}
			}
		}

		function completMarcacao()
		{
			$ultima = end($this->matriz_marcacoes['ponto']);
			switch ($ultima->tipo_marcacao) {
				case 'B01':
					$array_tipo = array('B02', 'B03', 'B04');
					$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');
					break;
				case 'B02':
					$array_tipo = array('B03', 'B04');
					$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');
					break;
				case 'B03':
					$array_tipo = array('B04');
					$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');
					break;
			}
		}

		function reorderPonto($ultima, $atual = null, $linha)
		{
			$data_entrada = null;
			if ((isset($ultima) && $ultima->hora_marcacao)) {
				$objUltimaData = $this->createDate($ultima);
			} elseif ((isset($ultima) && !$ultima->hora_marcacao)) {
				$ultima_data = new DateTime($atual->data_marcacao);
				$ds_semana = $ultima_data->format('w');
				if (isset($this->dias_jornada[$ds_semana]) && $this->dias_jornada[$ds_semana]) {
					$ultima->hora_referencia = $this->dias_jornada[$ds_semana]['dados']['entrada'];
					$objUltimaData = $this->createDate($ultima);
				} else {
					$objUltimaData = $this->createDate($ultima);
				}
			}

			if (isset($atual->hora_marcacao) && empty($atual->hora_marcacao)) {
				$data_atual = new DateTime($atual->data_marcacao);
				$ds_semana = $data_atual->format('w');
				if ($this->dias_jornada[$ds_semana]) {
					$atual->hora_referencia = $this->dias_jornada[$ds_semana]['dados']['entrada'];
					$objDataAtual = $this->createDate($atual);
				} else {
					$objDataAtual = $this->createDate($atual);
				}
			} else {
				$objDataAtual = $this->createDate($atual);
			}

			if ($ultima && $atual) {
				$ultima_data = $ultima->data_marcacao;
				$atual_data = $atual->data_marcacao;
				switch ($ultima->tipo_marcacao) {
					case 'B01':
						switch ($atual->tipo_marcacao) {
							case 'B01':
								$array_tipo = array('B02', 'B03', 'B04');
								$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');
								$this->matriz_marcacoes['ponto'][] = $atual;
								break;
							case 'B02':
								if (!$this->checkHorasDiff($objUltimaData, $objDataAtual)) {
									$atual->data_referencia = $ultima->data_referencia;
									$this->matriz_marcacoes['ponto'][] = $atual;
								} else {
									$array_tipo = array('B02', 'B03', 'B04');
									$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');

									$array_tipo = array('B01');
									$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
									$this->matriz_marcacoes['ponto'][] = $atual;
								}
								break;
							case 'B03':
								if (!$this->checkHorasDiff($objUltimaData, $objDataAtual)) {
									$array_tipo = array('B02');
									$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');

									$atual->data_referencia = $ultima->data_referencia;
									$this->matriz_marcacoes['ponto'][] = $atual;
								} else {
									$array_tipo = array('B02', 'B03', 'B04');
									$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');

									$array_tipo = array('B01', 'B02');
									$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
									$this->matriz_marcacoes['ponto'][] = $atual;
								}
								break;
							case 'B04':
								if (!$this->checkHorasDiff($objUltimaData, $objDataAtual)) {
									$array_tipo = array('B02', 'B03');
									$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');

									$atual->data_referencia = $ultima->data_referencia;
									$this->matriz_marcacoes['ponto'][] = $atual;
								} else {
									$array_tipo = array('B02', 'B03', 'B04');
									$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');

									$array_tipo = array('B01', 'B02', 'B03');
									$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
									$this->matriz_marcacoes['ponto'][] = $atual;
								}
								break;
							default:
								echo '<pre>';
								var_dump('1693');
								var_dump($linha, $ultima, $atual, $this->matriz_marcacoes['ponto']);
								echo '</pre>';
								exit;
								break;
						}
						break;
					case 'B02':
						switch ($atual->tipo_marcacao) {
							case 'B01':
								$array_tipo = array('B03', 'B04');
								$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');
								$this->matriz_marcacoes['ponto'][] = $atual;
								break;
							case 'B02':
								$array_tipo = array('B03', 'B04');
								$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');

								$array_tipo = array('B01');
								$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
								$this->matriz_marcacoes['ponto'][] = $atual;
								break;
							case 'B03':
								if (!$this->checkHorasDiff($objUltimaData, $objDataAtual)) {
									$atual->data_referencia = $ultima->data_referencia;
									$this->matriz_marcacoes['ponto'][] = $atual;
								} else {
									$array_tipo = array('B03', 'B04');
									$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');

									$array_tipo = array('B01', 'B02');
									$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
									$this->matriz_marcacoes['ponto'][] = $atual;
								}
								break;
							case 'B04':
								if (!$this->checkHorasDiff($objUltimaData, $objDataAtual)) {
									$array_tipo = array('B03');
									$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');

									$atual->data_referencia = $ultima->data_referencia;
									$this->matriz_marcacoes['ponto'][] = $atual;
								} else {
									$array_tipo = array('B03', 'B04');
									$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');

									$array_tipo = array('B01', 'B02', 'B03');
									$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
									$this->matriz_marcacoes['ponto'][] = $atual;
								}
								break;
							default:
								echo '<pre>';
								var_dump('1874');
								var_dump($ultima, $atual, $this->matriz_marcacoes['ponto']);
								echo '</pre>';
								exit;
								break;
						}
						break;
					case 'B03':
						switch ($atual->tipo_marcacao) {
							case 'B01':
								if (!$this->checkHorasDiff($objUltimaData, $objDataAtual)) {
									$atual->data_referencia = $ultima->data_referencia;
									$array_tipo = array('B04');
									$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');
									$this->matriz_marcacoes['ponto'][] = $atual;
								} else {
									$array_tipo = array('B04');
									$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');
									$this->matriz_marcacoes['ponto'][] = $atual;
								}
								break;
							case 'B02':
								$array_tipo = array('B04');
								$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');

								$array_tipo = array('B01');
								$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
								$this->matriz_marcacoes['ponto'][] = $atual;
								break;
							case 'B03':
								$array_tipo = array('B04');
								$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');

								$array_tipo = array('B01', 'B02');
								$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
								$this->matriz_marcacoes['ponto'][] = $atual;
								break;
							case 'B04':
								if (!$this->checkHorasDiff($objUltimaData, $objDataAtual)) {
									$atual->data_referencia = $ultima->data_referencia;
									$this->matriz_marcacoes['ponto'][] = $atual;
								} else {
									$array_tipo = array('B04');
									$this->criarObjMarcacaoVazioEmMatriz($ultima, $array_tipo, 'ponto');

									$array_tipo = array('B01', 'B02', 'B03');
									$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
									$this->matriz_marcacoes['ponto'][] = $atual;
								}
								break;
							default:
								echo '<pre>';
								var_dump('1795', $ultima, $atual, $this->matriz_marcacoes['ponto']);
								echo '</pre>';
								exit;
								break;
						}
						break;
					case 'B04':
						switch ($atual->tipo_marcacao) {
							case 'B01':
								$this->matriz_marcacoes['ponto'][] = $atual;
								break;
							case 'B02':
								$array_tipo = array('B01');
								$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
								$this->matriz_marcacoes['ponto'][] = $atual;
								break;
							case 'B03':
								$array_tipo = array('B01', 'B02');
								$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
								$this->matriz_marcacoes['ponto'][] = $atual;
								break;
							case 'B04':
								$array_tipo = array('B01', 'B02', 'B03');
								$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
								$this->matriz_marcacoes['ponto'][] = $atual;
								break;
							default:
								// echo '<pre>';
								// 	var_dump( '1803', $ultima, $atual, $this->matriz_marcacoes['ponto']);
								// echo '</pre>';
								// exit;
								break;
						}
						break;
					default:
						echo '<pre>';
						var_dump('1835', $ultima, $atual, $this->matriz_marcacoes['ponto']);
						echo '</pre>';
						exit;
						break;
				}
			} elseif (!$atual) {
				if (!$this->matriz_marcacoes['ponto']) {
					$this->matriz_marcacoes['ponto'][] = $ultima;
				} else {
					$chk_ultima = end($this->matriz_marcacoes['ponto']);
					if ($chk_ultima != $ultima) {
						$this->matriz_marcacoes['ponto'][] = $ultima;
					}
				}
			} elseif (!$ultima) {
				$hoje = new DateTime($atual->data_marcacao);
				$ontem = clone $hoje;
				$ontem->modify('-1 day');
				$do = $ontem->format('Y-m-d');
				if (isset($this->mapa_marcacoes['marcacoes']['dias'][$do])) {
					$marcacoes_ontem = $this->mapa_marcacoes['marcacoes']['dias'][$do];
				} else {
					$marcacoes_ontem = null;
				}

				if ($marcacoes_ontem) {
					echo '1863';
					exit;
				} else {
					if ($atual->tipo_marcacao == 'B01') {
						$this->matriz_marcacoes['ponto'][] = $atual;
					} else {
						switch ($atual->tipo_marcacao) {
							case 'B02':
								$array_tipo = array('B01');
								$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
								$this->matriz_marcacoes['ponto'][] = $atual;
								break;
							case 'B03':
								$array_tipo = array('B01', 'B02');
								$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
								$this->matriz_marcacoes['ponto'][] = $atual;
								break;
							case 'B04':
								$array_tipo = array('B01', 'B02', 'B03');
								$this->criarObjMarcacaoVazioEmMatriz($atual, $array_tipo, 'ponto');
								$this->matriz_marcacoes['ponto'][] = $atual;
								break;
						}
					}
				}
			}
		}

		function organizaPonto()
		{
			$contador = 1;
			$count_marcacoes = count($this->mapa_marcacoes['marcacoes']['ponto']);
			if ($this->mapa_marcacoes['marcacoes']['ponto']) {
				foreach ($this->mapa_marcacoes['marcacoes']['ponto'] as $key => $value) {
					if (!$value->hora_referencia) {
						$value->hora_referencia = $value->hora_marcacao;
					}

					if (isset($this->matriz_marcacoes['ponto']) && is_array($this->matriz_marcacoes['ponto'])) {
						$ultima = end($this->matriz_marcacoes['ponto']);
					} else {
						$ultima = null;
					}

					$objDataUltima = $this->createDate($ultima);
					$objDataAtual = $this->createDate($value);
					$keys = array_keys($this->mapa_marcacoes['marcacoes']['ponto']);
					if (end($keys) == $key) {
						if ($ultima) {
							if ($ultima->data_marcacao == $value->data_marcacao && $ultima->data_referencia == $value->data_referencia) {
								$this->reorderPonto($ultima, $value, 2037);
							} elseif ($ultima->data_marcacao != $value->data_marcacao && $ultima->data_referencia != $value->data_referencia) {
								$this->reorderPonto($ultima, $value, 2037);
							} else {
								if ($ultima->data_marcacao == $value->data_marcacao) {
									$this->reorderPonto($ultima, $value, 2037);
								} elseif ($ultima->data_referencia == $value->data_referencia) {
									echo '<pre>';
									var_dump('2040', $objDataUltima, $ultima, $objDataAtual, $value, $this->matriz_marcacoes['ponto']);
									echo '</pre>';
									exit;
								} else {
									echo '2041';
									exit;
								}
							}
							$this->completMarcacao();
						} else {
							if (1 == $count_marcacoes) {
								$this->finalizaMatriz($value, 'ponto');
							} else {
								$this->reorderPonto($value, null, 2067);
							}
						}
					} else {
						if ($ultima) {
							$objDataUltima = $this->createDate($ultima);
							$diff_data = $objDataAtual->diff($objDataUltima);
							if ($ultima->data_marcacao == $value->data_marcacao && $ultima->data_referencia == $value->data_referencia) {
								$this->reorderPonto($ultima, $value, 2027);
							} elseif ($ultima->data_marcacao != $value->data_marcacao && $ultima->data_referencia != $value->data_referencia) {
								if ($diff_data->days > 0) {
									$inicio = clone $objDataUltima;
									for ($i = 0; $i < $diff_data->days; $i++) {
										$inicio->modify('+1 day');
										$dt_ini = $inicio->format('Y-m-d');
										$ultima = end($this->matriz_marcacoes['ponto']);
										$objDataAtual = $this->createDate($value);
										$this->controller->arrayDinamico($this->mapa_marcacoes['marcacoes']['dias'], $dt_ini);
										$marcacoes_inicio = $this->mapa_marcacoes['marcacoes']['dias'][$dt_ini];
										if ($marcacoes_inicio) {
											if ($value != end($marcacoes_inicio)) {
												$this->reorderPonto($ultima, $value, 2049);
											}
										} else {
											if ($dt_ini != $value->data_marcacao) {
												$array_tipo = array('B01');
												$objEmpty = $this->criarObjMarcacaoVazio($dt_ini, $array_tipo, 'ponto');
												$this->reorderPonto($ultima, $objEmpty[0], 2051);
											}
										}
									}
									$ultima = end($this->matriz_marcacoes['ponto']);
									if ($ultima != $value) {
										$this->reorderPonto($ultima, $value, 2051);
									}
								} else {
									$this->reorderPonto($ultima, $value, 2031);
								}
							} else {
								if ($ultima->data_marcacao == $value->data_marcacao) {
									$this->reorderPonto($ultima, $value, 2027);
								} elseif ($ultima->data_referencia == $value->data_referencia) {
									echo '2168';
									exit;
								} else {
									echo '2032';
									exit;
								}
							}
						} else {
							$this->reorderPonto($ultima, $value, 2027);
						}
					}
				}
			}

			if (isset($this->matriz_marcacoes['ponto']) && is_array($this->matriz_marcacoes['ponto'])) {
				$this->matriz_calendario['diario']['marcacoes'] = array_chunk($this->matriz_marcacoes['ponto'], 4);
			}
		}

		function organizaPausa()
		{
			$contador = 1;
			if (isset($this->mapa_marcacoes['marcacoes']['pausa'])) {
				$count_marcacoes = count($this->mapa_marcacoes['marcacoes']['pausa']);
			} else {
				$count_marcacoes = 0;
			}

			if (isset($this->mapa_marcacoes['marcacoes']['pausa']) && is_array($this->mapa_marcacoes['marcacoes']['pausa'])) {
				foreach ($this->mapa_marcacoes['marcacoes']['pausa'] as $key => $value) {
					$objDate = $this->createDate($value);
					if (isset($this->matriz_marcacoes['pausa']) && !empty($this->matriz_marcacoes['pausa'])) {
						$ultima_marcacao = end($this->matriz_marcacoes['pausa']);
					} else {
						$ultima_marcacao = null;
					}

					if ($objDate >= $this->data_inicio) {
						if ($objDate <= $this->data_fim) {
							if ($ultima_marcacao) {
								switch ($ultima_marcacao->tipo_marcacao) {
									case 'B05':
										switch ($value->tipo_marcacao) {
											case 'B05':
												$array_tipo = array('B06');
												$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'pausa');
												$this->matriz_marcacoes['pausa'][] = $value;
												break;
											case 'B06':
												$this->matriz_marcacoes['pausa'][] = $value;
												break;
										}
										break;
									case 'B06':
										switch ($value->tipo_marcacao) {
											case 'B05':
												$this->matriz_marcacoes['pausa'][] = $value;
												break;
											case 'B06':
												$array_tipo = array('B05');
												$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'pausa');
												$this->matriz_marcacoes['pausa'][] = $value;
												break;
										}
										break;
								}
							} else {
								switch ($value->tipo_marcacao) {
									case 'B05':
										$this->matriz_marcacoes['pausa'][] = $value;
										break;
									case 'B06':
										$array_tipo = array('B05');
										$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'pausa');
										$this->matriz_marcacoes['pausa'][] = $value;
										$dif = 0;

										break;
								}
							}
						} else {
							$data_ultima = $this->createObjDate($ultima_marcacao);
							$data_atual = $this->createObjDate($value);
							if (!$this->checkHorasDiff($data_ultima, $data_atual)) {
								if ($value->tipo_marcacao == 'B06') {
									$this->matriz_marcacoes['pausa'][] = $value;
									break;
								} else {
									$this->preencheMatriz($ultima_marcacao, $value, 'pausa');
								}
							}
						}
					}

					if ($contador == $count_marcacoes) {
						if (isset($this->matriz_marcacoes['pausa']) && !empty($this->matriz_marcacoes['pausa'])) {
							$ultima_marcacao = end($this->matriz_marcacoes['pausa']);
						}

						if ($ultima_marcacao->id_registro != $value->id_registro && $ultima_marcacao->id_ocorrencia != $value->id_ocorrencia) {
							if ($ultima_marcacao) {
								switch ($ultima_marcacao->tipo_marcacao) {
									case 'B05':
										switch ($value->tipo_marcacao) {
											case 'B05':
												$array_tipo = array('B06');
												$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'pausa');
												break;
											case 'B06':
												$this->matriz_marcacoes['pausa'][] = $value;
												break;
										}
										break;
									case 'B06':
										switch ($value->tipo_marcacao) {
											case 'B06':
												$array_tipo = array('B05');
												$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'pausa');
												$this->matriz_marcacoes['pausa'][] = $value;
												break;
										}
										break;
								}
							} else {
								switch ($value->tipo_marcacao) {
									case 'B05':
										$this->matriz_marcacoes['pausa'][] = $value;
										break;
									case 'B06':
										$array_tipo = array('B05');
										$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'pausa');
										$this->matriz_marcacoes['pausa'][] = $value;
										break;
								}
							}
						}
					}
					$contador++;
				}
			}

			if (isset($this->matriz_marcacoes['pausa']) && count($this->matriz_marcacoes['pausa']) >= 2) {
				if (count($this->matriz_marcacoes['pausa']) >= 2) {
					$this->matriz_calendario['diario']['pausa'] = array_chunk($this->matriz_marcacoes['pausa'], 2);
				} else {
					$this->matriz_calendario['diario']['pausa'][0] = $this->matriz_marcacoes['pausa'];
				}
			}
		}

		function organizaExtra()
		{
			$contador = 1;
			if (isset($this->mapa_marcacoes['marcacoes']['extra'])) {
				$count_marcacoes = count($this->mapa_marcacoes['marcacoes']['extra']);
			} else {
				$count_marcacoes = 0;
			}

			if (isset($this->mapa_marcacoes['marcacoes']['extra'])) {
				foreach ($this->mapa_marcacoes['marcacoes']['extra'] as $key => $value) {
					$objDate = $this->createDate($value);
					if (isset($this->matriz_marcacoes['extra']) && !empty($this->matriz_marcacoes['extra'])) {
						$ultima_marcacao = end($this->matriz_marcacoes['extra']);
					}

					if ($objDate >= $this->data_inicio) {
						if ($objDate <= $this->data_fim) {
							if ($contador == $count_marcacoes) {
								if ($value->tipo_marcacao == 'B08') {
									$this->matriz_marcacoes['extra'][] = $value;
									break;
								} else {
									$this->preencheMatriz($ultima_marcacao, $value, 'extra');
								}
							} else {
								if ($ultima_marcacao) {
									$data_ultima = $this->createObjDate($ultima_marcacao);
									$data_atual = $this->createObjDate($value);
									switch ($ultima_marcacao->tipo_marcacao) {
										case 'B07':
											switch ($value->tipo_marcacao) {
												case 'B07':
													$array_tipo = array('B08');
													$this->criarObjMarcacaoVazioEmMatriz($ultima_marcacao, $array_tipo, 'extra');
													$this->matriz_marcacoes['extra'][] = $value;
													break;
												case 'B08':
													if (!$this->checkHorasDiff($data_ultima, $data_atual)) {
														$value->data_referencia = $ultima_marcacao->data_marcacao;
													}
													$this->matriz_marcacoes['extra'][] = $value;
													break;
											}
											break;
										case 'B08':
											switch ($value->tipo_marcacao) {
												case 'B07':
													$this->matriz_marcacoes['extra'][] = $value;
													break;
												case 'B08':
													$array_tipo = array('B07');
													$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'extra');
													$this->matriz_marcacoes['extra'][] = $value;
													break;
											}
											break;
									}
								} else {
									switch ($value->tipo_marcacao) {
										case 'B07':
											$this->matriz_marcacoes['extra'][] = $value;
											break;
										case 'B08':
											$array_tipo = array('B07');
											$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'extra');
											$this->matriz_marcacoes['extra'][] = $value;
											break;
									}
								}
							}
						} else {
							$data_ultima = $this->createObjDate($ultima_marcacao);
							$data_atual = $this->createObjDate($value);
							if (!$this->checkHorasDiff($data_ultima, $data_atual)) {
								if ($value->tipo_marcacao == 'B08') {
									$value->data_referencia = $ultima_marcacao->data_marcacao;
									$this->matriz_marcacoes['extra'][] = $value;
									break;
								} else {
									$this->preencheMatriz($ultima_marcacao, $value, 'extra');
								}
							}
						}
					}
					if ($contador == $count_marcacoes) {
						switch ($value->tipo_marcacao) {
							case 'B07':
								$this->matriz_marcacoes['extra'][] = $value;
								$array_tipo = array('B08');
								$this->criarObjMarcacaoVazioEmMatriz($value, $array_tipo, 'extra');
								break;
							case 'B08':
								$this->matriz_marcacoes['extra'][] = $value;
								break;
						}
					}
					$contador++;
				}
			}

			if (isset($this->matriz_marcacoes['extra'])) {
				if (count($this->matriz_marcacoes['extra']) > 2) {
					$this->matriz_calendario['diario']['extra'] = array_chunk($this->matriz_marcacoes['extra'], 2);
				} else {
					$this->matriz_calendario['diario']['extra'][0] = $this->matriz_marcacoes['extra'];
				}
			}
		}

		function gerarEspelho($data_inicio, $data_fim, $tipo_espelho = 'fechamento')
		{
			$this->calendario['total']['horas_previstas'] = 0;
			$this->calendario['total']['saldo_anterior'] = 0;
			$this->calendario['total']['horas_abonadas'] = 0;
			$this->calendario['total']['minutos_pausa'] = 0;
			$this->calendario['total']['horas_trabalhadas'] = 0;
			$this->calendario['total']['devedor_folha'] = 0;
			$this->setJornadas();

			if (isset($data_inicio) && is_object($data_inicio)) {
				$this->data_inicio = $data_inicio;
			} else {
				$this->data_inicio = getDataAtual($data_inicio);
			}

			if (isset($data_fim) && is_object($data_fim)) {
				$this->data_fim = $data_fim;
			} else {
				$this->data_fim = getDataAtual($data_fim);
			}

			$this->data_inicio->setTime(00, 00, 00);
			$this->data_fim->setTime(23, 59, 59);
			switch ($tipo_espelho) {
				case 'espelho':
				case 'fechamento':
					$this->checkUltimoFechamento();
					if ($this->ultimo_fechamento) {
						$this->data_inicio = getDataAtual($this->ultimo_fechamento['periodo_fim']);
						$this->data_inicio->setTime(00, 00, 00);
						$this->data_inicio->modify('+1 day');
					} else {
						$this->checkSaldoAnterior();
						$this->data_inicio = getDataAtual($this->jornadas[0]['data_inicio']);
						$this->data_inicio->setTime(00, 00, 00);
					}
					break;
			}

			$this->data_search_ini = clone $this->data_inicio;
			$this->data_search_ini->modify('-1 day');

			$this->data_search_fim = clone $this->data_fim;
			$this->data_search_fim->modify('+1 day');
			$this->data_inicio->setTime(00, 00, 00);

			if (isset($tipo) && $tipo == "diario") {
				$this->montaJornadaDia();
			} else {
				$this->montaJornada();
			}
			// seta as marcações ponto, extra, pausa e ocorencias
			$this->setRegistros('ponto', $this->data_search_ini, $this->data_search_fim);
			$this->setRegistros('pausa', $this->data_search_ini, $this->data_search_fim);
			$this->setRegistros('extra', $this->data_search_ini, $this->data_search_fim);
			$this->setFeriados($this->data_inicio->format('Y-m-d'), $this->data_fim->format('Y-m-d'));
			$this->setOcorrencias($this->data_search_ini, $this->data_search_fim);

			$this->verDia();
			$this->processaOcorrencias();
			if (isset($this->mapa_marcacoes['marcacoes']['ponto']) && count($this->mapa_marcacoes['marcacoes']['ponto']) > 0) {
				ksort($this->mapa_marcacoes['marcacoes']['ponto']);
			}

			$this->organizaPonto();

			$this->verDia('pausa');
			if (isset($this->mapa_marcacoes['marcacoes']['pausa']) && count($this->mapa_marcacoes['marcacoes']['pausa']) > 0) {
				ksort($this->mapa_marcacoes['marcacoes']['pausa']);
			}
			$this->organizaPausa();

			$this->verDia('extra');
			if (isset($this->mapa_marcacoes['marcacoes']['extra']) && count($this->mapa_marcacoes['marcacoes']['extra']) > 0) {
				ksort($this->mapa_marcacoes['marcacoes']['extra']);
			}

			$this->organizaExtra();

			$this->calcularHoras('ponto');
			$this->calcularHoras('pausa');
			$this->calcularHoras('extra');
			$this->checarAbono();
			$this->calcularSaldo(2518);
		}

		function addOcorrencia($dados)
		{
			if (empty($dados['ocorrencia'])) {
				$this->retorno = 'Informe os dados da ocorrencia';
			}

			if (!isset($dados['ocorrencia']['funcionario']) || empty($dados['ocorrencia']['funcionario'])) {
				$this->retorno = 'informe o funcionario';
				$this->error = true;
			}

			if (!isset($dados['ocorrencia']['tipo_ocorrencia']) || empty($dados['ocorrencia']['tipo_ocorrencia'])) {
				$this->retorno = 'informe o tipo de ocorrencia';
				$this->error = true;
			}

			if (!isset($dados['ocorrencia']['minutos']) || empty($dados['ocorrencia']['minutos'])) {
				if (!isset($dados['ocorrencia']['data_periodo_ini']) || empty($dados['ocorrencia']['data_periodo_ini'])) {
					$this->retorno = 'informe o periodo inicial';
					$this->error = true;
				}

				if (!isset($dados['ocorrencia']['data_periodo_fim']) || empty($dados['ocorrencia']['data_periodo_fim'])) {
					$this->retorno = 'informe o periodo final';
					$this->error = true;
				}
			}

			if (!$this->error) {
				//patrick, luciano, julio e selma
				$array_adm = [3000012, 42, 05, 13];
				$status = 'pendente';
				if (in_array($_SESSION['cmswerp']['userdata']->id, $array_adm) && ($dados['ocorrencia']['tipo_ocorrencia'] == 'A26' || $dados['ocorrencia']['tipo_ocorrencia'] == 'D1')) {
					$status = 'aprovado';
				}

				$classe = $dados['ocorrencia']['tipo_ocorrencia'];
				$param['id_registro'] = null;
				$param['id_usuario'] = $this->user->id;
				$param['permissivo'] = 0;
				$param['fonte'] = $this->mapa_ocorrencias[$classe]['fonte_ocorrencia'];
				$param['tipo'] = $this->mapa_ocorrencias[$classe]['tipo_ocorrencia'];
				$param['classe'] = $dados['ocorrencia']['tipo_ocorrencia'];
				$param['texto'] = $dados['ocorrencia']['texto'];
				$param['data'] = convertDate($dados['ocorrencia']['data_periodo_ini']);
				$param['hora'] = $dados['ocorrencia']['hora_ini_marcacao'];
				$param['data_lancamento'] = $this->controller->data_hora_atual->format('Y-m-d');
				$param['periodo_ini'] = convertDate($dados['ocorrencia']['data_periodo_ini']) . ' ' . $dados['ocorrencia']['hora_ini_marcacao'];
				$param['periodo_fim'] = convertDate($dados['ocorrencia']['data_periodo_fim']) . ' ' . $dados['ocorrencia']['hora_fim_marcacao'];
				$param['minutos'] = (isset($dados['ocorrencia']['minutos'])) ? $dados['ocorrencia']['minutos'] : null;
				$param['status'] = $status;
				$param['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
				$param['alterado_em'] = $this->controller->data_hora_atual->format('Y-m-d H:i:s');
				$param['deleted'] = 0;
				$this->ponto_model->setTable('rh_jornada_ocorrencia');
				$is_save = $this->ponto_model->save($param);
				if ($is_save) {
					if (isset($dados['arquivo']['name_upload_arquivo']['name']) && !empty($dados['arquivo']['name_upload_arquivo']['name'])) {
						$file = pathinfo($dados['arquivo']['name_upload_arquivo']['name']);
						$nome_documento = $this->user->cpf . '_' . $classe . '_' . $this->controller->data_hora_atual->format('YmdHis') . '.' . $file['extension'];
						$upload = $this->uploadAnexo($dados['arquivo'], $dados['ocorrencia']['tipo_ocorrencia'], $this->user, $nome_documento);
						if ($upload['codigo'] == 0) {
							$ged['nome_documento'] = $nome_documento;
							$ged['data_documento'] = $this->controller->data_hora_atual->format('Y-m-d');
							$ged['valido_ate'] = null;
							$ged['id_origem'] = $is_save;
							$ged['doc_origem'] = 'pessoal';
							$ged['tipo'] = 'ocorrencia';
							$ged['subtipo'] = 'comprovante';
							$ged['classificacao'] = null;
							$ged['descricao'] = $dados['ocorrencia']['texto'];
							$ged['versao'] = 'original';
							$ged['owner'] = $this->user->id;
							$ged['data_criacao'] = $this->controller->data_hora_atual->format('Y-m-d');
							$ged['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
							$ged['alterado_em'] = $this->controller->data_hora_atual->format('Y-m-d H:i:s');
							$ged['deleted'] = 0;
							$this->obj_ged->setTable('ged_documento');
							$save_ged_documento = $this->obj_ged->save($ged);
							if ($save_ged_documento) {
								$ged_anexo['id_documento'] = $save_ged_documento;
								$ged_anexo['nome_amigavel'] = $ged['nome_documento'];
								$ged_anexo['path_root'] = $upload['mensagem']->path;
								$ged_anexo['path_objeto'] = '/ponto/ocorrencias/';
								$ged_anexo['nome_hash'] = $ged['nome_documento'];
								$ged_anexo['hash_arquivo'] = md5($ged['nome_documento']);
								$ged_anexo['data_criacao'] = $ged['data_criacao'];
								$ged_anexo['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
								$ged_anexo['alterado_em'] = $this->controller->data_hora_atual->format('Y-m-d H:i:s');
								$ged_anexo['deleted'] = 0;
								$this->obj_ged->setTable('ged_anexo');
								$save_anexo = $this->obj_ged->save($ged_anexo);
								if ($save_anexo) {
									$this->retorno = 'Sucesso';
								} else {
									$this->retorno = 'Erro ao salvar anexo';
									$this->error = true;
								}
							} else {
								$this->retorno = 'Erro ao salvar no GED';
								$this->error = true;
							}
						} else {
							$this->retorno = 'Erro ao fazer o upload';
							$this->error = true;
						}
					} else {
						$this->retorno = 'Sucesso';
					}

					if (!$this->error) {
						$send_message = true;
						$this->ponto_model->setTable("rh_token");
						$dados_token = $this->dadosToken($is_save, $this->user);
						$save_token = $this->ponto_model->save($dados_token);
						$mensagem = "Uma nova ocorrência " . $this->mapa_ocorrencias[$classe]['texto'] . " para o funcionario " . $this->user->nome . " com ID " . $is_save . " acesse o tarifador e acesso o menu ponto / ocorrencias para aprova-la ou envie o token de liberação para o funcionario. TOKEN AUTORIZAÇÃO: " . $dados_token['token'];
						$parametros['tipo_destinatario'] = "user";
						$parametros['email_to'] = $this->user->email_chefe;
						$parametros['mensagem'] = $mensagem;
						$permissoes = json_decode($_SESSION['cmswerp']['userdata']->permissoes);

						if ($_POST['funcionario'] != $_SESSION['cmswerp']['userdata']->id) {
							if (isset($permissoes->modulos->Pessoal->{1000006}->permissoes) && $permissoes->modulos->Pessoal->{1000006}->permissoes >= 4) {
								$send_message = false;
							}
						}

						if ($send_message) {
							$this->controller->obj_notificacao->enviar('teams', $parametros);
						}
					}
				} else {
					$this->retorno = 'Erro ao salvar ocorrencia';
					$this->error = true;
				}
			}
			return $this;
		}

		function uploadAnexo($file, $tipo_arquivo, $usuario, $nome_arquivo = null)
		{
			if (!is_dir(GED_PONTO)) {
				mkdir(GED_PONTO);
			}
			if (!is_dir(GED_PONTO . $usuario->cpf)) {
				mkdir(GED_PONTO . $usuario->cpf);
			}

			if (!is_dir(GED_PONTO . $usuario->cpf)) {
				$retorno["codigo"] = 1;
				$retorno["input"] = $file;
				$retorno["output"] = null;
				$retorno["mensagem"] = "Erro, sem diretório!";
				throw new Exception(json_encode($retorno), 1);
			} else {
				if ($nome_arquivo) {
					$file['name_upload_arquivo']['name'] = $nome_arquivo;
					$nome_amigavel = $nome_arquivo;
				} else {
					$data_hash = date('YmdHms');
					$ext = explode("/", $file['name_upload_arquivo']['type']);
					$ext = $ext[1];
					$explode_nome = explode(".", $file['name_upload_arquivo']['name']);
					if (isset($explode_nome) && is_array($explode_nome)) {
						$file['name_upload_arquivo']['name'] = $explode_nome[0];
					}
					$nome_amigavel = $file['name_upload_arquivo']['name'];
				}
			}

			$config['allow_size'] = 164000000000;
			$config['pasta'] = GED_PONTO . $usuario->cpf . '/ponto/ocorrencias/';

			$class_upload = new Upload($this, $file['name_upload_arquivo'], $config);
			$class_upload->checkArquivo();
			$load = $class_upload->loadFile($file['name_upload_arquivo'], $config);
			$retorno_json = json_decode($load);

			if ($retorno_json->codigo != 0) {
				$retorno["codigo"] = 1;
				$retorno["input"] = $file;
				$retorno["output"] = null;
				$retorno["mensagem"] = $retorno_json->dados;
				return $retorno;
			} else {
				$retorno_json->dados->path = GED_PONTO . $usuario->cpf;
				$retorno["codigo"] = $retorno_json->codigo;
				$retorno["input"] = $nome_amigavel;
				$retorno["output"] = $nome_arquivo;
				$retorno["mensagem"] = $retorno_json->dados;
				return $retorno;
			}
		}

		function uploadGed($file, $tipo_arquivo, $usuario)
		{
			if (!is_dir(GED_PONTO)) {
				mkdir(GED_PONTO);
			}
			if (!is_dir(GED_PONTO . $usuario[0]->cpf)) {
				mkdir(GED_PONTO . $usuario[0]->cpf);
			}

			if (!is_dir(GED_PONTO . $usuario[0]->cpf)) {
				$retorno["codigo"] = 1;
				$retorno["input"] = $file;
				$retorno["output"] = null;
				$retorno["mensagem"] = "Erro, sem diretório!";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$data_hash = date('YmdHms');
				$ext = explode("/", $file['name_upload_arquivo']['type']);
				$ext = $ext[1];
				$explode_nome = explode(".", $file['name_upload_arquivo']['name']);
				if (isset($explode_nome) && is_array($explode_nome)) {
					$file['name_upload_arquivo']['name'] = $explode_nome[0];
				}
				$nome_amigavel = $file['name_upload_arquivo']['name'];
				$nome_arquivo = str_replace(" ", "_", $tipo_arquivo) . "_" . $file['name_upload_arquivo']['name'] . "_" . $data_hash . "." . $ext;
			}
			$file['name_upload_arquivo']['name'] = $nome_arquivo;
			$config['allow_size'] = 164000000000;
			$config['pasta'] = GED_PONTO . $usuario[0]->cpf;

			$class_upload = new Upload($this, $file['name_upload_arquivo'], $config);
			$class_upload->checkArquivo();
			$load = $class_upload->loadFile($file['name_upload_arquivo'], $config);
			$retorno_json = json_decode($load);

			if ($retorno_json->codigo != 0) {
				$retorno["codigo"] = 1;
				$retorno["input"] = $file;
				$retorno["output"] = null;
				$retorno["mensagem"] = $retorno_json->dados;
				return $retorno;
			} else {
				$retorno["codigo"] = $retorno_json->codigo;
				$retorno["input"] = $nome_amigavel;
				$retorno["output"] = $nome_arquivo;
				$retorno["mensagem"] = $retorno_json->dados;
				return $retorno;
			}
		}

		// Terminando novo codigo aqui 
		//By: Caio Freitas 02/06/2022
		function enviarNotificacao($enviar_como, $usuario, $ocorrencia = array())
		{
			$email_from = $usuario[0]->email;
			$email_to = $ocorrencia['email_boss'];
			if (TIPO_AMBIENTE != 'producao') {
				$email_to = "julio.gomes@cmsw.com";
			}

			if (!$enviar_como) {
				$retorno['codigo'] = 1;
				$retorno['output'] = null;
				$retorno['mensagem'] = 'Tipo de mensagem não informado';
			}

			if (!$email_to) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $ocorrencia;
				$retorno['output'] = $usuario;
				$retorno['mensagem'] = 'Usuario de destino não informado';
			}

			$parametros['email_from'] = $email_from;
			$parametros['email_to'] = $email_to;
			$parametros['tipo_destinatario'] = 'user';
			switch ($enviar_como) {
				// NOTIFICAÇÃO DE ATESTADO E COMPROVANTE P/ SELMA E DULCI
				case 'geral':
					$parametros['mensagem'] = $ocorrencia['mensagem'];
					return $this->controller->obj_notificacao->enviar('teams', $parametros);
					break;
				case 'copia_adm':
					$mensagem = "O funcionário " . strtoupper($usuario[0]->nome) . " Justificou " . $ocorrencia['tipo'] . ". <br> Data: " . $ocorrencia['data'] . " <br> link da ocorrência: " . URL_SISTEMA . "/ponto/ocorrenciaview/" . $ocorrencia['id'];
					$parametros['email_to'] = 'dulcineia.mata@cmsw.com';
					$parametros['mensagem'] = $mensagem;
					$this->notificacoes->enviar('teams', $parametros);
					$parametros['email_to'] = 'selma.oliveira@cmsw.com';
					$parametros['mensagem'] = $mensagem;
					return $this->notificacoes->enviar('teams', $parametros);
					break;
				//ESSE ALERTA É DE ERRO NO SITEMA.
				case 'alerta':
					$email = 'caio.freitas@cmsw.com';
					$mensagem = "FUNCIONÁRIO: " . strtoupper($usuario[0]->nome) . "  |  OCORRÊNCIA: " . $ocorrencia['tipo'] . "  |  PERÍODO: " . $ocorrencia['data'];
					$mensagem .= "\n | LINK: " . URL_SISTEMA . "/ponto/ocorrenciaview/" . $ocorrencia['id'];
					$parametros['email_to'] = $email;
					$parametros['mensagem'] = $mensagem;
					return $this->notificacoes->enviar('teams', $parametros);
					break;
				// REGISTROS FORA DO HORÁRIO NÚCLEO, FERIADOS, FORA JORNADA E MARCAÇÃO EXTRA 
				case 'horario_nucleo':
					$email = array($ocorrencia['email_boss']);
					$id_token = $ocorrencia['id_slack'];
					if ($ocorrencia['ocorrencia'] == "T1D") {
						$mensagem = "O funcionário " . strtoupper($usuario[0]->nome) . " registrou " . $ocorrencia['tipo'] . " às " . $ocorrencia['hora'];
					} elseif ($ocorrencia['ocorrencia'] == "T1B") {
						$mensagem = "O funcionário " . strtoupper($usuario[0]->nome) . " registrou " . $ocorrencia['tipo'] . " às " . $ocorrencia['hora'] . " fora da sua jornada de trabalho.";
					} elseif ($ocorrencia['ocorrencia'] == "T1C") {
						$mensagem = "O funcionário " . strtoupper($usuario[0]->nome) . " registrou " . $ocorrencia['tipo'] . " às " . $ocorrencia['hora'] . " no feriado.";
					} elseif ($ocorrencia['ocorrencia'] == "TB04") {
						$mensagem = "O funcionário " . strtoupper($usuario[0]->nome) . " registrou " . $ocorrencia['tipo'] . " às " . $ocorrencia['hora'] . " acima do horário máximo de saída permitido.";
						if (isset($ocorrencia['saida_max']) && !empty($ocorrencia['saida_max'])) {
							$mensagem .= "\n O horário de saída maxímo permitido: " . $ocorrencia['saida_max'];
						}
					} elseif ($ocorrencia['ocorrencia'] == "TB02" || $ocorrencia['ocorrencia'] == "TB03") {
						$mensagem = "O funcionário " . strtoupper($usuario[0]->nome) . " registrou " . $ocorrencia['tipo'] . " às " . $ocorrencia['hora'] . " fora do horário limite de almoço.";
						if ((isset($ocorrencia['almoco_min']) && !empty($ocorrencia['almoco_min'])) && (isset($ocorrencia['almoco_max']) && !empty($ocorrencia['almoco_max']))) {
							$mensagem .= "\n O horário limite de almoço: " . $ocorrencia['almoco_min'] . " às " . $ocorrencia['almoco_max'];
						}
					} else {
						$mensagem = "O funcionário " . strtoupper($usuario[0]->nome) . " registrou " . $ocorrencia['tipo'] . " às " . $ocorrencia['hora'] . " fora do horário núcleo.";
						if (!empty($ocorrencia['ini_horario_nucleo']) && !empty($ocorrencia['fim_horario_nucleo'])) {
							$mensagem .= "\n Horário núcleo: " . $ocorrencia['ini_horario_nucleo'] . " às " . $ocorrencia['fim_horario_nucleo'] . ".";
						}
					}
					$mensagem .= "\n Data: " . $ocorrencia['data'];
					$mensagem .= "\n Token da ocorrência: " . $ocorrencia['token'];
					$mensagem .= "\n link da ocorrência: " . URL_SISTEMA . "/ponto/ocorrenciaview/" . $ocorrencia['id'];
					$parametros['mensagem'] = $mensagem;
					if ('producao' == TIPO_AMBIENTE) {
						$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/12ad07a8afcc45b1a3d600758059232e/c8c7ff53-e294-4a3a-bcad-c9f04857e469';
					} else {
						$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9f2e2cc655bf4e76bfdb0531dd3a83d7/c328c206-070a-4beb-bbed-da82e018abec';
					}
					return $this->notificacoes->enviar('teams', $parametros);
					break;
				default:
					$id_token = $ocorrencia['id_slack'];
					if ($ocorrencia['ocorrencia'] == "T1D") {
						$mensagem = "O funcionário " . strtoupper($usuario[0]->nome) . " registrou " . $ocorrencia['tipo'] . " às " . $ocorrencia['hora'];
					} elseif ($ocorrencia['ocorrencia'] == "T1B") {
						$mensagem = "O funcionário " . strtoupper($usuario[0]->nome) . " registrou " . $ocorrencia['tipo'] . " às " . $ocorrencia['hora'] . " fora da sua jornada de trabalho.";
					} elseif ($ocorrencia['ocorrencia'] == "T1C") {
						$mensagem = "O funcionário " . strtoupper($usuario[0]->nome) . " registrou " . $ocorrencia['tipo'] . " às " . $ocorrencia['hora'] . " no feriado.";
					} elseif ($ocorrencia['ocorrencia'] == "T1A") {
						$mensagem = "O funcionário " . strtoupper($usuario[0]->nome) . " registrou " . $ocorrencia['tipo'] . " às " . $ocorrencia['hora'] . " fora do horário núcleo.";
						if (!empty($ocorrencia['ini_horario_nucleo']) && !empty($ocorrencia['fim_horario_nucleo'])) {
							$mensagem .= "\n Horário núcleo: " . $ocorrencia['ini_horario_nucleo'] . " às " . $ocorrencia['fim_horario_nucleo'] . ".";
						}
					} elseif ($ocorrencia['ocorrencia'] == "TB02" || $ocorrencia['ocorrencia'] == "TB03") {
						$mensagem = "O funcionário " . strtoupper($usuario[0]->nome) . " registrou " . $ocorrencia['tipo'] . " às " . $ocorrencia['hora'] . " fora do horário limite de almoço.";
						if ((isset($ocorrencia['almoco_min']) && !empty($ocorrencia['almoco_min'])) && (isset($ocorrencia['almoco_max']) && !empty($ocorrencia['almoco_max']))) {
							$mensagem .= "\n O horário limite de almoço: " . $ocorrencia['almoco_min'] . " às " . $ocorrencia['almoco_max'];
						}
					} elseif ($ocorrencia['ocorrencia'] == "TB04") {
						$mensagem = "O funcionário " . strtoupper($usuario[0]->nome) . " registrou " . $ocorrencia['tipo'] . " às " . $ocorrencia['hora'] . " acima do horário máximo de saída permitido.";
						if (isset($ocorrencia['saida_max']) && !empty($ocorrencia['saida_max'])) {
							$mensagem .= "\n O horário de saída maxímo permitido: " . $ocorrencia['saida_max'];
						}
					} else {
						$mensagem = "O funcionário " . strtoupper($usuario[0]->nome) . " justificou " . $ocorrencia['tipo'] . ".";
					}

					if (isset($ocorrencia['data'])) {
						$mensagem .= " \n Data: " . $ocorrencia['data'];
					}
					if (isset($ocorrencia['token'])) {
						$mensagem .= " \n Token da ocorrência: " . $ocorrencia['token'];
					}
					$mensagem .= " \n link da ocorrência: " . URL_SISTEMA . "/ponto/ocorrenciaview/" . $ocorrencia['id'];
					$parametros['mensagem'] = $mensagem;
					return $this->notificacoes->enviar('teams', $parametros);
					break;
			}
		}

		function tokenPendente($token = array())
		{
			$data_format = $this->controller->data_hora_atual->format('Y-m-d');
			if (isset($token)) {
				$validade_token = new DateTime($token[0]->validade);
				if (strtotime($validade_token->format('Y-m-d')) >= strtotime($data_format)) {
					if (strtotime($validade_token->format('Y-m-d')) == strtotime($data_format)) {
						if (strtotime($this->controller->data_hora_atual->format('H:i:s')) < strtotime($validade_token->format('H:i:s'))) {
							$token_pendente['token'] = true;
							$token_pendente['dados'] = $token;
						}
					} elseif (strtotime($validade_token->format('Y-m-d')) > strtotime($data_format)) {
						$token_pendente['token'] = true;
						$token_pendente['dados'] = $token;
					}
				}
			}
			return $token_pendente;
		}

		function getOcorrenciasPontoAcimaDe($dt_ini, $tipo = 'ponto')
		{
			$inicio = getDataAtual($dt_ini);
			switch ($tipo) {
				case 'ponto':
					return json_decode($this->ponto_model->getOcorrenciasPontoAcimaDe($inicio->format('Y-m-d'), $this->user->id, array('B01', 'B02', 'B03', 'B04')));
					break;
				case 'extras':
					return json_decode($this->ponto_model->getOcorrenciasPontoAcimaDe($inicio->format('Y-m-d'), $this->user->id, array('B07', 'B08')));
					break;
				case 'pausas':
					return json_decode($this->ponto_model->getOcorrenciasPontoAcimaDe($inicio->format('Y-m-d'), $this->user->id, array('B05', 'B06')));
					break;
			}
		}

		function replaceRegistro($id_user, $data_format)
		{
			$ocorrencia_r = json_decode($this->ponto_model->getOcorrencia(null, null, $data_format, null, null, $id_user, null, 'R'));
			if (isset($ocorrencia_r) && !empty($ocorrencia_r)) {
				foreach ($ocorrencia_r as $key => $value) {
					$matrix_regritro[$value->classe] = $value;
				}
			}
			$registro_dia = json_decode($this->ponto_model->getRegistro(null, $data_format, null, $id_user));
			if (isset($registro_dia) && !empty($registro_dia)) {
				foreach ($registro_dia as $key => $value) {
					if (isset($matrix_regritro[$value->tipo_marcacao])) {
						$value->hora_marcacao = $matrix_regritro[$value->tipo_marcacao]->hora;
						$value->status = $matrix_regritro[$value->tipo_marcacao]->status;
					}
				}
			}
			return $registro_dia;
		}

		function cargaHoraria($id_jornada, $dia_semana)
		{
			$jornada_dias = json_decode($this->ponto_model->getJornadaDias($id_jornada, $dia_semana));
			$jornada = json_decode($this->ponto_model->getJornada($id_jornada));
			$carga_horaria = (convertHorasMinutos($jornada_dias[0]->saida) - convertHorasMinutos($jornada_dias[0]->entrada)) - $jornada[0]->horas_almoco;
			return $carga_horaria;
		}

		function verificaJornadaNoturna($jornada_dias)
		{
			$dia_semana = $this->controller->data_hora_atual->format('w');
			foreach ($jornada_dias as $key => $value) {
				if ($value->dia_semana == $dia_semana) {
					$entrada_jornada = $value->entrada;
					$saida_jornada = $value->saida;
				}
			}

			if (strtotime($entrada_jornada) > strtotime($saida_jornada)) {
				$jornada_noturna = true;
			} else {
				$jornada_noturna = false;
			}
			return $jornada_noturna;
		}

		function checkLastjornada($id_user, DateTime $data, $tipo_marcacao, $id_jornada = null)
		{
			try {
				$need_token = null;
				$total_horas_normais = null;
				if ($id_user && is_numeric($id_user)) {
					$jornada_atual = json_decode($this->ponto_model->getLastJornada($id_user, $id_jornada));
					$check_jornada = $this->checkJornada($this->controller->data_hora_atual, $jornada_atual);
					if ($jornada_atual) {
						$output['token']['need'] = false;
						$dia_semana_hoje = nomeSemana($this->controller->data_hora_atual->format('w'));
						foreach ($jornada_atual as $key => $value) {
							$i1 = nomeSemana($value->dia_semana);
							$dados[$i1] = $value;
						}

						$dias_jornada = array_keys($dados);
						// verificar Horario nuclueo e entrada e saida.
						$dados_atuais_jornada = $dados[$dia_semana_hoje];
						$output['colaborador']['nome'] = $dados_atuais_jornada->nome_usuario;
						$output['colaborador']['id_chefe'] = $dados_atuais_jornada->id_chefe;
						$output['colaborador']['nome_chefe'] = $dados_atuais_jornada->nome_chefe;
						$output['colaborador']['email_chefe'] = $dados_atuais_jornada->email_chefe;
						$output['colaborador']['id_slack_chefe'] = $dados_atuais_jornada->id_slack_chefe;

						if (!array_key_exists($dia_semana_hoje, $dados)) {
							$output['colaborador']['nome'] = $jornada_atual[0]->nome_usuario;
							$output['colaborador']['id_chefe'] = $jornada_atual[0]->id_chefe;
							$output['colaborador']['nome_chefe'] = $jornada_atual[0]->nome_chefe;
							$output['colaborador']['email_chefe'] = $jornada_atual[0]->email_chefe;
							$output['colaborador']['id_slack_chefe'] = $jornada_atual[0]->id_slack_chefe;
							$output['token']['codigo'] = 'T1B';
							$output['token']['need'] = true;
							$output['token']['mensagem'] = "fora jornada";
							$output['colaborador']['codigo_ocorrencia'] = "T1B";
							$output['colaborador']['mensagem'] = 'Você deveria estar de folga, sua jornada ' . implode(",", $dias_jornada) . ' e hoje é ' . $dia_semana_hoje;
							return $output;
						}

						$hr_entrada = clone $data;
						if (isset($dados_atuais_jornada->entrada)) {
							$hr_entrada = $hr_entrada->setTime(str_replace(':', ",", $dados_atuais_jornada->entrada), 00);
						}

						$hr_saida = clone $data;
						if (isset($dados_atuais_jornada->saida)) {
							$hr_saida = $hr_entrada->setTime(str_replace(':', ",", $dados_atuais_jornada->saida), 00);
						}

						$hr_saida = $hr_saida->setTime(str_replace(':', ",", $dados_atuais_jornada->saida), 00);
						//VERIFICANDO SE EXISTE ENTRADA MIN E SAIDA MAX  
						if (isset($dados_atuais_jornada->entrada_min) && !empty($dados_atuais_jornada->entrada_min)) {
							$ex_entrada_min = explode(":", $dados_atuais_jornada->entrada_min);
							$entrada_min = clone $data;
							// No setTime necessário passar nos parâmetros hora,minuto,segundo
							$entrada_min = $entrada_min->setTime($ex_entrada_min[0], $ex_entrada_min[1], $ex_entrada_min[2]);
						}

						if (isset($dados_atuais_jornada->saida_max) && !empty($dados_atuais_jornada->saida_max)) {
							$ex_saida_max = explode(":", $dados_atuais_jornada->saida_max);
							$saida_max = clone $data;
							$saida_max = $saida_max->setTime($ex_saida_max[0], $ex_saida_max[1], $ex_saida_max[2]);
						}

						if (isset($dados_atuais_jornada->almoco_min) && !empty($dados_atuais_jornada->almoco_min)) {
							$ex_almoco_min = explode(":", $dados_atuais_jornada->almoco_min);
							$almoco_min = clone $data;
							$almoco_min = $almoco_min->setTime($ex_almoco_min[0], $ex_almoco_min[1], $ex_almoco_min[2]);
						}

						if (isset($dados_atuais_jornada->almoco_max) && !empty($dados_atuais_jornada->almoco_max)) {
							$ex_almoco_max = explode(":", $dados_atuais_jornada->almoco_max);
							$almoco_max = clone $data;
							$almoco_max = $almoco_max->setTime($ex_almoco_max[0], $ex_almoco_max[1], $ex_almoco_max[2]);
						}

						// verificando horario nucleo
						if ($dados_atuais_jornada->entrada && $dados_atuais_jornada->saida) {
							if ($dados_atuais_jornada->entrada < $dados_atuais_jornada->saida) {
								$hr_entrada = clone $data;
								$hr_entrada = $hr_entrada->setTime(str_replace(':', ",", $dados_atuais_jornada->entrada), 00);
								$hr_saida = clone $data;
								$hr_saida = $hr_saida->setTime(str_replace(':', ",", $dados_atuais_jornada->saida), 00);
							} else {
								$hr_entrada = clone $data;
								$hr_entrada = $hr_entrada->setTime(str_replace(':', ",", $dados_atuais_jornada->entrada), 00);
								$hr_saida = clone $data;
								$hr_saida->modify('+1 day');
								$hr_saida = $hr_saida->setTime(str_replace(':', ",", $dados_atuais_jornada->saida), 00);
							}
							$this->tempo_almoco = $dados_atuais_jornada->horas_almoco;
							$diff_previsto = $hr_entrada->diff($hr_saida);
							$this->horas_previstas = ((($diff_previsto->h * 60) + $diff_previsto->i) - $this->tempo_almoco);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $user_id;
							$retorno['output'] = $jornada_atual;
							$retorno['mensagem'] = 'Jornada sem horario de entrada ou saida definidos';
							throw new Exception(json_encode($retorno), 1);
						}

						$jornada_noturna = $this->verificaJornadaNoturna($jornada_atual);
						switch ($tipo_marcacao) {
							case 'B01':
								if ($jornada_noturna == false) {
									if (isset($data) && isset($entrada_min) && !empty($entrada_min)) {
										if ($data->format('His') < $entrada_min->format('His')) {
											$output['token']['need'] = false;
											$output['token']['mensagem'] = 'Aguarde até ás ' . $entrada_min->format('H:i') . " para registrar entrada início";;
											$output['token']['codigo'] = "TB01";
											return $output;
										}
									}
								}
								break;
							case 'B02':
							case 'B03':
								if ($jornada_noturna == false) {
									if (isset($data) && isset($almoco_min) && isset($almoco_max)) {
										if ($tipo_marcacao == "B02") {
											if ($data->format('His') < $almoco_min->format('His')) {
												$output['token']['need'] = true;
												$output['token']['almoco_min'] = $almoco_min->format('H:i');
												$output['token']['almoco_max'] = $almoco_max->format('H:i');
												$output['token']['mensagem'] = 'Início almoço fora do horário limite de almoço das ' . $almoco_min->format('H:i') . " às " . $almoco_max->format('H:i');
												$output['token']['codigo'] = "TB02";
												return $output;
											}
										} else if ($tipo_marcacao == "B03") {
											if ($data->format('His') > $almoco_max->format('His')) {
												$output['token']['need'] = true;
												$output['token']['almoco_min'] = $almoco_min->format('H:i');
												$output['token']['almoco_max'] = $almoco_max->format('H:i');
												$output['token']['mensagem'] = 'Retorno almoço fora do horário limite de almoço das ' . $almoco_min->format('H:i') . " às " . $almoco_max->format('H:i');
												$output['token']['codigo'] = "TB03";
												return $output;
											}
										}
									}
								}
								break;
							case 'B04':
								if ($jornada_noturna == false) {
									if (isset($data) && isset($saida_max)) {
										if ($data->format('His') > $saida_max->format('His')) {
											$output['token']['need'] = true;
											$output['token']['mensagem'] = 'Saída fora do horário máximo de saída às ' . $saida_max->format('H:i');
											$output['token']['codigo'] = "TB04";
											$output['token']['saida_max'] = $saida_max->format('H:i');
										}
									}
								}
								break;
						}

						if ($dados_atuais_jornada->nucleo_ini && $dados_atuais_jornada->nucleo_fim) {
							if ($dados_atuais_jornada->nucleo_ini < $dados_atuais_jornada->nucleo_fim) {
								$hr_nucleo_ini = clone $data;
								$hr_nucleo_ini = $hr_nucleo_ini->setTime(str_replace(':', ",", $dados_atuais_jornada->nucleo_ini), 00);
								$hr_nucleo_fim = clone $data;
								$hr_nucleo_fim = $hr_nucleo_fim->setTime(str_replace(':', ",", $dados_atuais_jornada->nucleo_fim), 00);
							} else {
								$hr_nucleo_ini = clone $data;
								$hr_nucleo_ini = $hr_nucleo_ini->setTime(str_replace(':', ",", $dados_atuais_jornada->nucleo_ini), 00);
								$hr_nucleo_fim = clone $data;
								$hr_nucleo_fim->modify('+1 day');
								$hr_nucleo_fim = $hr_nucleo_fim->setTime(str_replace(':', ",", $dados_atuais_jornada->nucleo_fim), 00);
							}

							switch ($tipo_marcacao) {
								case 'B01':
									//Verificando se a jornanda não é noturna															
									if ($data->format('His') > $hr_nucleo_ini->format('His')) {
										$output['token']['need'] = true;
										$output['token']['mensagem'] = 'O colaborador  ' . $dados_atuais_jornada->nome_usuario . '  registrou entrada após o horario nucleo estabelecido. Horario de entrada ' . $dados_atuais_jornada->nucleo_ini . ' horas';
										$output['token']['codigo'] = "T1A";
										$output['token']['horario_nucleo_ini'] = $dados_atuais_jornada->nucleo_ini;
										$output['token']['horario_nucleo_fim'] = $dados_atuais_jornada->nucleo_fim;
									}
									break;
								case 'B04':
									if ($data->format('His') < $hr_nucleo_fim->format('His')) {
										$output['token']['need'] = true;
										$output['token']['mensagem'] = 'O colaborador  ' . $dados_atuais_jornada->nome_usuario . '  registrou saida antes do horario nucleo estabelecido. Horario de saida ' . $dados_atuais_jornada->nucleo_fim;
										$output['token']['codigo'] = "T1A";
										$output['token']['horario_nucleo_ini'] = $dados_atuais_jornada->nucleo_ini;
										$output['token']['horario_nucleo_fim'] = $dados_atuais_jornada->nucleo_fim;
									}
									break;
							}
						}

						$feriado = json_decode($this->ponto_model->getOcorrencia(null, 'AL4', $data->format('Y-m-d'), null, 'aprovado'));
						if (isset($feriado) && !empty($feriado)) {
							$output['token']['need'] = true;
							$output['token']['mensagem'] = "Feriado";
							$output['token']['codigo'] = "T1C";
						}

						if ($check_jornada['codigo'] == 'C01' || $check_jornada['descricao'] == 'folga') {
							$output['token']['need'] = true;
							$output['token']['mensagem'] = "FOLGA";
							$output['token']['codigo'] = "T1B";
						}
						return $output;
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $user_id;
						$retorno['output'] = $jornada_atual;
						$retorno['mensagem'] = 'Jornada não encontrada';
						throw new Exception(json_encode($retorno), 1);
					}
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $user_id;
					$retorno['output'] = null;
					$retorno['mensagem'] = 'Usuario invalido';
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function checkJornada($data, $jornada)
		{
			// C01 - FOLGA
			// C02 - SEM ESCALA
			// C03 - DIA DE TRABALHO			
			$retorno['codigo'] = 'C01';
			$retorno['descricao'] = 'FOLGA';
			$retorno['carga_horaria'] = null;
			$retorno['jornada'] = $jornada;
			foreach ($jornada as $key => $value) {
				$p = ($key + 1);
				$ini_j = (isset($value->data_inicio)) ? getDataAtual($value->data_inicio) : getDataAtual();
				if (isset($jornada[$p]->data_inicio)) {
					$fim_j = getDataAtual($jornada[$p]->data_inicio);
					$fim_j->modify('-1 day');
				} else {
					$fim_j = getDataAtual();
				}
				if ($data->format('Ymd') >= $ini_j->format('Ymd') && $data->format('Ymd') <= $fim_j->format('Ymd')) {
					if (strstr($value->dia_semana, $data->format('w'))) {
						if (isset($value->id)) {
							$carga_horaria = $this->cargaHoraria($value->id_jornada, $data->format('w'));
							$retorno['codigo'] = 'C03';
							$retorno['descricao'] = 'dia de trabalho';
							$retorno['carga_horaria'] = $carga_horaria;
							$retorno['jornada'] = $value;
						} else {
							$retorno['codigo'] = 'C03';
							$retorno['descricao'] = 'Desconhecido';
							$retorno['carga_horaria'] = null;
							$retorno['jornada'] = null;
						}
						return $retorno;
					}
				} else {
					if ($data->format('Ymd') > $this->controller->data_hora_atual->format('Ymd')) {
						if (strstr($value->dia_semana, $data->format('w'))) {
							$carga_horaria = $this->cargaHoraria($value->id_jornada, $data->format('w'));
							$retorno['codigo'] = 'C03';
							$retorno['descricao'] = 'dia de trabalho';
							$retorno['carga_horaria'] = $carga_horaria;
							$retorno['jornada'] = $value;
							return $retorno;
						}
					} else {
						if ($key_data < $this->controller->data_hora_atual->format('Y-m-d')) {
							$retorno['codigo'] = 'C02';
							$retorno['descricao'] = 'sem escala';
							$retorno['carga_horaria'] = null;
							$retorno['jornada'] = $value;
						}
					}
				}
			}
			return $retorno;
		}

		function getFeriados($validade = null)
		{
			//$this->feriados = json_decode($this->ponto_model->getFeriados($validade));
			$this->feriados = json_decode($this->ponto_model->getFeriados($this->dt_inicio->format('Y-m-d'), $this->data_fim->format('Y-m-d')));
			if ($this->feriados) {
				$feriados = null;
				foreach ($this->feriados as $key => $value) {
					$i1 = nomeMes($value->mes);
					$i2 = str_pad($value->dia, 2, "0", STR_PAD_LEFT);
					$feriados[$i1][$i2]['nome'] = $value->titulo;
				}
				$this->feriados = $feriados;
			}
		}

		function getJornadas()
		{
			return $this->jornadas;
		}

		function verificacoes($tipo_ocorrencia, $post, $file, $id_usuario)
		{
			include "config_extras.php";
			$jornada = json_decode($this->ponto_model->getRhJornadaUsuario($id_usuario));
			if (!isset($jornada) || empty($jornada)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $post;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Usuário sem jornada, por gentileza cadastre o usuário em uma jornada.";
				throw new Exception(json_encode($retorno), 1);
			}

			switch ($tipo_ocorrencia) {
				// BATIDA INCORRETA / REGISTRO AUSENTE
				case 'R1':
				case 'R2':
					if (!isset($post['funcionario']) || empty($post['funcionario'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $post;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Selecione um funcionario.";
						throw new Exception(json_encode($retorno), 1);
					}
					if (!isset($post['data']) || empty($post['data'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $post;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe a data da ocorrência.";
						throw new Exception(json_encode($retorno), 1);
					}
					if (!isset($post['id_radio']) || empty($post['id_radio'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $post;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Selecione um registro.";
						throw new Exception(json_encode($retorno), 1);
					}
					if (!isset($post['horario_correto']) || empty($post['horario_correto'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $post;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe o horário.";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$valida_horas = validate_hour($post['horario_correto']);
						if ($valida_horas == false) {
							$retorno["codigo"] = 1;
							$retorno["input"] = $post;
							$retorno["output"] = $this->ponto_model->info;
							$retorno["mensagem"] = "Horário invalido.";
							throw new Exception(json_encode($retorno), 1);
						}
					}
					if (!isset($post['texto']) || empty($post['texto'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $post;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe a observação.";
						throw new Exception(json_encode($retorno), 1);
					}
					break;
				//ATESTADO / VIAGEN / FÉRIAS / FOLGA / AUSENCIA JUSTIFICADA / LICENÇAS: MATERNIDADE / OBITO / NASCIMENTO / CASAMENTO / PATERNIDADE // AFASTAMENTO INSS // ELEIÇÃO // DOAÇÃO DE SANGUE
				case 'A1':
				case 'A2':
				case 'A11':
				case 'A13':
				case 'A14':
				case 'A15':
				case 'A16':
				case 'A17':
				case 'A18':
				case 'AA2':
				case 'A7':
				case 'AL1':
				case 'A5':
				case 'AA7':
				case 'AA8':
				case 'AA9':
				case 'AA10':
				case 'AA11':
				case 'AA13':
				case 'AA17':
				case 'AA18':
					if (!isset($post['data_periodo_ini']) || empty($post['data_periodo_ini'])) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Informe o período inicial:";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($post['data_periodo_fim']) || empty($post['data_periodo_fim'])) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Informe o período final";
						throw new Exception(json_encode($retorno), 1);
					}

					if ($tipo_ocorrencia == 'AA18' || $tipo_ocorrencia == 'AA17') {
						if ($post['data_periodo_ini'] != $post['data_periodo_fim']) {
							$retorno["codigo"] = 1;
							$retorno["input"] = $post;
							$retorno["output"] = $this->ponto_model->info;
							$retorno["mensagem"] = "Ocorrência de " . $VAR_SYSTEM['CODIGO_OCORRENCIA'][$tipo_ocorrencia] . " serve apenas para um dia, PERÍODO INICIAL e PERÍODO FINAL deve ter a mesma data.";
							throw new Exception(json_encode($retorno), 1);
						}
					} else {
						if (strtotime(convertDate($post['data_periodo_ini'])) > strtotime(convertDate($post['data_periodo_fim']))) {
							$retorno["codigo"] = 1;
							$retorno["input"] = $post;
							$retorno["output"] = null;
							$retorno["mensagem"] = "Período inicial não pode ser maior que o período final:";
							throw new Exception(json_encode($retorno), 1);
						}
					}

					if (!isset($post['texto']) || empty($post['texto']) || strlen($post['texto']) < 5) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Informe uma descrição sobre a justificativa.";
						throw new Exception(json_encode($retorno), 1);
					}

					if ($tipo_ocorrencia == 'AA2' || $tipo_ocorrencia == 'AA13' || $tipo_ocorrencia == 'AA17' || $tipo_ocorrencia == 'AA18') {
						if (isset($file) && !empty($file)) {
							if (empty($file['name_upload_arquivo']['name']) || !isset($file['name_upload_arquivo']['name'])) {
								$retorno["codigo"] = 1;
								$retorno["input"] = $post;
								$retorno["output"] = null;
								$retorno["mensagem"] = "Anexe o documento na justificativa!";
								throw new Exception(json_encode($retorno), 1);
							}
						}
					}
					return true;
					break;
				//COMPROVANTE DE HORAS // PERCUSO DE TRAJETO // COMPARECIMENTO JUDICIAL
				case 'A3':
				case 'A4':
				case 'AA3':
				case 'AA4':
				case 'AA15':
					if (!isset($post['data_periodo_ini']) || empty($post['data_periodo_ini'])) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe o período inicial";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($post['data_periodo_fim']) || empty($post['data_periodo_fim'])) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe o período final";
						throw new Exception(json_encode($retorno), 1);
					}

					if ($post['data_periodo_ini'] != $post['data_periodo_fim']) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Ocorrência de " . $VAR_SYSTEM['CODIGO_OCORRENCIA'][$tipo_ocorrencia] . " serve apenas para um dia, PERÍODO INICIAL e PERÍODO FINAL deve ter a mesma data.";
						throw new Exception(json_encode($retorno), 1);
					}

					if (isset($post['hora_ini_marcacao']) && !empty($post['hora_ini_marcacao'])) {
						$valida_hora = validate_hour($post['hora_ini_marcacao']);
						if ($valida_hora == false) {
							$retorno["codigo"] = 1;
							$retorno["input"] = $post;
							$retorno["output"] = $this->ponto_model->info;
							$retorno["mensagem"] = "Hora inicial invalida.";
							throw new Exception(json_encode($retorno), 1);
						}
					} else {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe o horário inicial.";
						throw new Exception(json_encode($retorno), 1);
					}

					if (isset($post['hora_fim_marcacao']) && !empty($post['hora_fim_marcacao'])) {
						$valida_hora = validate_hour($post['hora_fim_marcacao']);
						if ($valida_hora == false) {
							$retorno["codigo"] = 1;
							$retorno["input"] = $post;
							$retorno["output"] = $this->ponto_model->info;
							$retorno["mensagem"] = "Hora final invalida.";
							throw new Exception(json_encode($retorno), 1);
						}
					} else {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe o horário final.";
						throw new Exception(json_encode($retorno), 1);
					}

					if ($post['hora_ini_marcacao'] >= $post['hora_fim_marcacao']) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "HORÁRIO INICIAL não pode ser maior ou igual que HORÁRIO FINAL.";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($post['texto']) || empty($post['texto']) || strlen($post['texto']) < 5) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe uma descrição sobre a justificativa.";
						throw new Exception(json_encode($retorno), 1);
					}

					if (isset($file) && !empty($file)) {
						if (empty($file['name_upload_arquivo']['name']) || !isset($file['name_upload_arquivo']['name'])) {
							$retorno["codigo"] = 1;
							$retorno["input"] = $post;
							$retorno["output"] = null;
							$retorno["mensagem"] = "Anexe o documento na justificativa!";
							throw new Exception(json_encode($retorno), 1);
						}
					}
					return true;
					break;
				// REUNIÃO EXTERNA // AMAMENTAÇÃO // FESTA FIM DE ANO // CURSO
				case 'A10':
				case 'A12':
				case 'A22':
				case 'A23':
				case 'AA12':
				case 'AA14':
				case 'AA16':
				case 'AA19':
					if (!isset($post['data_periodo_ini']) || empty($post['data_periodo_ini'])) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe o período inicial";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($post['data_periodo_fim']) || empty($post['data_periodo_fim'])) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe o período final";
						throw new Exception(json_encode($retorno), 1);
					}

					if ($post['data_periodo_ini'] != $post['data_periodo_fim']) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Ocorrência de " . $VAR_SYSTEM['CODIGO_OCORRENCIA'][$tipo_ocorrencia] . " serve apenas para um dia, PERÍODO INICIAL e PERÍODO FINAL deve ter a mesma data.";
						throw new Exception(json_encode($retorno), 1);
					}

					if (isset($post['hora_ini_marcacao']) && !empty($post['hora_ini_marcacao'])) {
						$valida_hora = validate_hour($post['hora_ini_marcacao']);
						if ($valida_hora == false) {
							$retorno["codigo"] = 1;
							$retorno["input"] = $post;
							$retorno["output"] = $this->ponto_model->info;
							$retorno["mensagem"] = "Hora inicial invalida.";
							throw new Exception(json_encode($retorno), 1);
						}
					} else {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe o horário inicial.";
						throw new Exception(json_encode($retorno), 1);
					}
					if (isset($post['hora_fim_marcacao']) && !empty($post['hora_fim_marcacao'])) {
						$valida_hora = validate_hour($post['hora_fim_marcacao']);
						if ($valida_hora == false) {
							$retorno["codigo"] = 1;
							$retorno["input"] = $post;
							$retorno["output"] = $this->ponto_model->info;
							$retorno["mensagem"] = "Hora final invalida.";
							throw new Exception(json_encode($retorno), 1);
						}
					} else {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe o horário final.";
						throw new Exception(json_encode($retorno), 1);
					}

					if ($post['hora_ini_marcacao'] >= $post['hora_fim_marcacao']) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "HORÁRIO INICIAL não pode ser maior ou igual que HORÁRIO FINAL.";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($post['texto']) || empty($post['texto']) || strlen($post['texto']) < 5) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe uma descrição sobre a justificativa.";
						throw new Exception(json_encode($retorno), 1);
					}
					return true;
					break;
				//FERIADO / ERRO SISTEMA	
				case 'AL4':
				case 'A8':
					if (!isset($post['data_ocorrencia']) || empty($post['data_ocorrencia'])) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe a data da ocorrência!";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($post['texto']) || empty($post['texto']) || strlen($post['texto']) < 5) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe uma descrição sobre a justificativa.";
						throw new Exception(json_encode($retorno), 1);
					}
					break;
				//ABONADA  / FOLGA
				case 'A5':
				case 'A6':
				case 'AA5':
				case 'AA6':
					if (!isset($post['data_periodo_ini']) || empty($post['data_periodo_ini'])) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Informe o período inicial:";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($post['data_periodo_fim']) || empty($post['data_periodo_fim'])) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Informe o período final";
						throw new Exception(json_encode($retorno), 1);
					}

					if (strtotime(convertDate($post['data_periodo_ini'])) > strtotime(convertDate($post['data_periodo_fim']))) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Período inicial não pode ser maior que o período final:";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($post['texto']) || empty($post['texto']) || strlen($post['texto']) < 5) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Informe uma descrição sobre a justificativa.";
						throw new Exception(json_encode($retorno), 1);
					}

					break;
				// MARCAÇÃO EXTRA
				case 'A9':

					if (!isset($post['data_periodo_ini']) || empty($post['data_periodo_ini'])) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe a data do período inicial.";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($post['data_periodo_fim']) || empty($post['data_periodo_fim'])) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe a data do período final.";
						throw new Exception(json_encode($retorno), 1);
					}

					if ($post['data_periodo_ini'] != $post['data_periodo_fim']) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Ocorrência de MARCAÇÃO EXTRA serve apenas para um dia, PERÍODO INICIAL e PERÍODO FINAL deve ter a mesma data.";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($post['hora_ini_marcacao']) || empty($post['hora_ini_marcacao'])) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe o horário do período inicial.";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$valida_horas = validate_hour($post['hora_ini_marcacao']);
						if ($valida_horas == false) {
							$retorno["codigo"] = 1;
							$retorno["input"] = $post;
							$retorno["output"] = $this->ponto_model->info;
							$retorno["mensagem"] = "Horário período inicial invalido.";
							throw new Exception(json_encode($retorno), 1);
						}
					}

					if (!isset($post['hora_fim_marcacao']) || empty($post['hora_fim_marcacao'])) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe o horário do período final.";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$valida_horas = validate_hour($post['hora_fim_marcacao']);
						if ($valida_horas == false) {
							$retorno["codigo"] = 1;
							$retorno["input"] = $post;
							$retorno["output"] = $this->ponto_model->info;
							$retorno["mensagem"] = "Horário período final invalido.";
							throw new Exception(json_encode($retorno), 1);
						}
					}

					if (strtotime($post['hora_ini_marcacao']) >= strtotime($post['hora_fim_marcacao'])) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Horário inicial não pode ser maior ou igual ao horário final.";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($post['texto']) || empty($post['texto']) || strlen($post['texto']) < 5) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Informe uma descrição sobre a justificativa.";
						throw new Exception(json_encode($retorno), 1);
					}

					break;
				//DESCONTO FOLHA
				case 'D1':
					break;
				//DESCONTO BANCO
				case 'D2':
					break;
				//VALIDAÇÃO TOKEN
				case 'T1':
					break;
				case 'D3':

					if (!isset($post['data_periodo_ini']) || empty($post['data_periodo_ini'])) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Informe o período inicial:";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($post['data_periodo_fim']) || empty($post['data_periodo_fim'])) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Informe o período final";
						throw new Exception(json_encode($retorno), 1);
					}

					if ($post['data_periodo_ini'] != $post['data_periodo_fim']) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Ocorrência de " . $VAR_SYSTEM['CODIGO_OCORRENCIA'][$tipo_ocorrencia] . " serve apenas para um dia, PERÍODO INICIAL e PERÍODO FINAL deve ter a mesma data.";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($post['texto']) || empty($post['texto']) || strlen($post['texto']) < 5) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Informe uma descrição sobre a justificativa.";
						throw new Exception(json_encode($retorno), 1);
					}

					foreach ($jornada as $key => $value) {
						$jornada_atual = $value;
					}

					$dia_semana = explode(",", $jornada_atual->dia_semana);
					$data_jus = getDataAtual($post['data_periodo_ini']);
					$dia = $data_jus->format('w');

					foreach ($dia_semana as $key => $value) {
						if ($dia === $value) {
							$dia_util = true;
						}
					}

					if (isset($dia_util) && $dia_util === true) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = $this->ponto_model->info;
						$retorno["mensagem"] = "Essa data é um dia útil na jornada, não necessário essa justificativa";
						throw new Exception(json_encode($retorno), 1);
					}

					return true;
					break;
				default:
					$retorno["codigo"] = 1;
					$retorno["input"] = $post;
					$retorno["output"] = null;
					$retorno["mensagem"] = "Tipo de justificativa desconhecida.";
					throw new Exception(json_encode($retorno), 1);
					break;
			}
		}

		function justificar($tipo_ocorrencia, $post, $id_usuario)
		{
			include "config_extras.php";
			$id_user = $_SESSION['cmswerp']['userdata']->id;
			// NOME // CÓDIGO
			// BATIDA AUSENTE = R1
			// AUSENCIA DE BATIDA = R2
			// FERIAS = AL1
			// ATESTADO = AA2
			// COMPROVANTE DE HORAS = AA3
			// FERIADO = AL4
			// ABONADA = A5
			// AUSENCIA/FOLGA = AA6
			// DESCONTO FOLHA = D1
			// DESCONTO BANCO = D2
			// VIAGEWM = A7
			// VALIDAÇÃO TOKEN = T1
			// ERRO SISTEMA = A8
			// MARCAÇÃO EXTRA = A9
			// REUNIÃO EXTERNA = A10 
			// CÓDIGO COMEÇA COM AA = NECESSITA DE FAZER UPLOAD DE ARQUIVO;
			// CÓDIGO COMEÇA COM A = ABONA PERÍODO OU DIA;
			// CÓDIGO COMEÇA COM AL = JUSTIFICATIVA EXCLUSIVA DO MENU DE LANÇAMENTOS;
			// CÓDIGO COMEÇA COM D = RELACIONADO A DESCONTO;
			// CÓDIGO COMEÇA COM R = RELACIONADO A REGISTRO;
			// CÓDIGO COMEÇA COM T = RELACIONADO A TOKEN;
			// ORGANIZANDO FONTE, TIPO, CLASSE		
			$classes = $this->returnClasse($tipo_ocorrencia);
			// END 		
			// VARIAVEIS PADRÃO QUE ESTÃO PRESENTE EM QUALQUER TIPO DE JUSTIFICATIVA
			$insert['data_lancamento'] = $this->controller->data_hora_atual->format('Y-m-d H:i:s');
			$insert['id_usuario'] = $id_usuario;
			$insert['texto'] = $post['texto'];
			$insert['status'] = 'pendente';
			$insert['classe'] = $tipo_ocorrencia;
			$insert['fonte'] = $classes['fonte'];
			$insert['tipo'] = $classes['tipo'];
			// END VARIAVEIS PADRÃO
			switch ($tipo_ocorrencia) {
				// BATIDA INCORRETA
				case 'R1':
				case 'R2':
					$insert['data'] = convertDate($_POST['data']);
					$insert['hora'] = $post['horario_correto'];
					$explode = explode("/", $_POST['id_radio']);
					$insert['classe'] = $explode[1];
					$insert['id_registro'] = $explode[0];
					if ($insert["id_registro"] == "undefined") {
						$insert["id_registro"] = null;
					} else {
						$get_registro = json_decode($this->ponto_model->getRegistro(null, null, null, null, null, null, $insert['id_registro']));
					}
					if (isset($get_registro)) {
						$insert['periodo_ini'] = $insert['data'] . " " . retirarSegundos($get_registro[0]->hora_marcacao);
					} else {
						$insert['periodo_ini'] = $insert['data'] . " " . $post['horario_correto'];
					}
					$insert['periodo_fim'] = $insert['data'] . " " . $post['horario_correto'];
					return $insert;
					break;
				//ATESTADO / VIAGEM / FÉRIAS / FOLGA / AUSENCIA JUS / LICENÇAS: MATERNIDADE / OBITO / NASCIMENTO / CASAMENTO / PATERNIDADE / AFASTAMENTO INSS // ELEIÇÃO
				case 'A1':
				case 'A2':
				case 'A5':
				case 'A9':
				case 'A11':
				case 'A12':
				case 'A14':
				case 'A15':
				case 'A16':
				case 'A19':
				case 'A20':
				case 'A21':
				case 'AA2': //ok 
				case 'A7':
				case 'AL1':
				case 'AA6': //ok
				case 'AA7': //ok
				case 'AA8': //ok
				case 'AA9': //ok
				case 'AA10': //ok
				case 'AA11': //ok		
				case 'AA13': //ok
				case 'AA17':
				case 'AA18':
					// Nessas justificativas está saindo com a data zerada pq agora essa justificativa é inserida apenas uma vez 
					// e estou usando o intervalo de periodo ini e periodo fim para obter a justificativa. 
					$insert['data'] = convertDate($post['data_periodo_ini']);
					$insert['periodo_ini'] = convertDate($post['data_periodo_ini']) . " " . "00:00:00";
					$insert['periodo_fim'] = convertDate($post['data_periodo_fim']) . " " . "00:00:00";
					$insert['permissivo'] = 1;

					if ($tipo_ocorrencia == "AL1" || $tipo_ocorrencia == "A11") {
						$insert['status'] = "aprovado";
						$insert['id_autorizado'] = $id_user;
					}

					if ($tipo_ocorrencia == "A7" || $tipo_ocorrencia == "A11") {
						$get_ocorrencia = json_decode($this->ponto_model->getOcorrenciaIntervalo(convertDate($post['data_periodo_ini']), convertDate($post['data_periodo_fim']), null, $insert['id_usuario']));
						if (isset($get_ocorrencia) && !empty($get_ocorrencia)) {
							foreach ($get_ocorrencia as $key => $value) {
								if ($value->classe == "A7" && $value->status != "reprovado") {
									$data_ini = new DateTime($value->periodo_ini);
									$data_fim = new DateTime($value->periodo_fim);
									$retorno["codigo"] = 1;
									$retorno["input"] = $post;
									$retorno["output"] = null;
									$retorno["mensagem"] = "Funcionário já tem justificatiava de " . strtoupper($VAR_SYSTEM['CODIGO_OCORRENCIA'][$value->classe]) . " no período de: " . $data_ini->format("d/m/Y") . " até: " . $data_fim->format("d/m/Y");
									throw new Exception(json_encode($retorno), 1);
								}
								if ($tipo_ocorrencia == "A11" && $value->classe == "A11" && $value->status != "reprovado") {
									$data_ini = new DateTime($value->periodo_ini);
									$data_fim = new DateTime($value->periodo_fim);
									$retorno["codigo"] = 1;
									$retorno["input"] = $post;
									$retorno["output"] = null;
									$retorno["mensagem"] = "Funcionário já tem justificatiava de " . strtoupper($VAR_SYSTEM['CODIGO_OCORRENCIA'][$value->classe]) . " no período de: " . $data_ini->format("d/m/Y") . " até: " . $data_fim->format("d/m/Y");
									throw new Exception(json_encode($retorno), 1);
								}
								if ($value->classe == "AA6" && $value->status != "reprovado") {
									$data = new DateTime($value->data);
									$retorno["codigo"] = 1;
									$retorno["input"] = $post;
									$retorno["output"] = null;
									$retorno["mensagem"] = "Funcionário já tem justificatiava de " . strtoupper($VAR_SYSTEM['CODIGO_OCORRENCIA'][$value->classe]) . " na data: " . $data->format("d/m/Y");
									throw new Exception(json_encode($retorno), 1);
								}
							}
						}
					}

					$get_atestado = json_decode($this->ponto_model->getOcorrenciaIntervalo(convertDate($post['data_periodo_ini']), convertDate($post['data_periodo_fim']), 'AA2', $insert['id_usuario'], 'aprovado'));
					if (isset($get_atestado) && !empty($get_atestado)) {
						$data_ini = new DateTime($get_atestado[0]->periodo_ini);
						$data_fim = new DateTime($get_atestado[0]->periodo_fim);
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Funcionário tem justificatiava de atestado no período de: " . $data_ini->format("d/m/Y") . " até: " . $data_fim->format("d/m/Y");
						throw new Exception(json_encode($retorno), 1);
					}

					$erro_sistema = json_decode($this->ponto_model->getOcorrenciaIntervalo(convertDate($post['data_periodo_ini']), convertDate($post['data_periodo_fim']), 'A8', $insert['id_usuario'], 'aprovado'));
					if (isset($erro_sistema) && !empty($erro_sistema)) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Justificativa de erro sistema no dia: " . convertDate($erro_sistema[0]->data);
						throw new Exception(json_encode($retorno), 1);
					}

					$ferias = json_decode($this->ponto_model->getOcorrenciaIntervalo(convertDate($post['data_periodo_ini']), convertDate($post['data_periodo_fim']), 'AL1', $insert['id_usuario'], 'aprovado'));
					if (isset($ferias) && !empty($ferias)) {
						$data_ini = new DateTime($ferias[0]->periodo_ini);
						$data_fim = new DateTime($ferias[0]->periodo_fim);
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Justificativa de férias no período de: " . $data_ini->format("d/m/Y") . " até: " . $data_fim->format("d/m/Y");
						throw new Exception(json_encode($retorno), 1);
					}

					if ($tipo_ocorrencia == "A11") {
						if ($post['funcionario'] == $id_user && $id_user != 3000000) {
							$retorno["codigo"] = 1;
							$retorno["input"] = $post;
							$retorno["output"] = null;
							$retorno["mensagem"] = "Usuário sem permissão para lançar a própria folga, entre em contato com a ADM.";
							throw new Exception(json_encode($retorno), 1);
						}
					}
					return $insert;
					break;
				//COMPROVANTE DE HORAS // PERCURSO
				case 'A3':
				case 'A4':
				case 'AA3':
				case 'AA4':
					$insert['data'] = convertDate($post['data_periodo_ini']);
					$insert['periodo_ini'] = convertDate($post['data_periodo_ini']) . " " . $post['hora_ini_marcacao'];
					$insert['periodo_fim'] = convertDate($post['data_periodo_fim']) . " " . $post['hora_fim_marcacao'];
					$insert['permissivo'] = 1;

					$get_atestado = json_decode($this->ponto_model->getOcorrenciaIntervalo($insert['data'], $insert['data'], 'AA2', $insert['id_usuario'], 'aprovado'));
					if (isset($get_atestado) && !empty($get_atestado)) {
						$data_ini = new DateTime($get_atestado[0]->periodo_ini);
						$data_fim = new DateTime($get_atestado[0]->periodo_fim);
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Funcionário tem justificatiava de atestado no período de: " . $data_ini->format("d/m/Y") . " até: " . $data_fim->format("d/m/Y");
						throw new Exception(json_encode($retorno), 1);
					}

					$erro_sistema = json_decode($this->ponto_model->getOcorrenciaIntervalo($insert['data'], $insert['data'], 'A8', $insert['id_usuario'], 'aprovado'));
					if (isset($erro_sistema) && !empty($erro_sistema)) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Justificativa de erro sistema no dia: " . convertDate($erro_sistema[0]->data);
						throw new Exception(json_encode($retorno), 1);
					}

					$ferias = json_decode($this->ponto_model->getOcorrenciaIntervalo(convertDate($post['data_periodo_ini']), convertDate($post['data_periodo_fim']), 'AL1', $insert['id_usuario'], 'aprovado'));
					if (isset($ferias) && !empty($ferias)) {
						$data_ini = new DateTime($get_atestado[0]->periodo_ini);
						$data_fim = new DateTime($get_atestado[0]->periodo_fim);
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Justificativa de férias no período de: " . $data_ini->format("d/m/Y") . " até: " . $data_fim->format("d/m/Y");
						throw new Exception(json_encode($retorno), 1);
					}

					if ($tipo_ocorrencia == "AA4") {
						$comprovante = json_decode($this->ponto_model->getOcorrenciaIntervalo(convertDate($post['data_periodo_ini']), convertDate($post['data_periodo_fim']), 'AA3', $insert['id_usuario'], 'aprovado'));
						if (!isset($comprovante) || empty($comprovante)) {
							$retorno["codigo"] = 1;
							$retorno["input"] = $post;
							$retorno["output"] = null;
							$retorno["mensagem"] = "Para usar a justificativa de PERCURSO necessario justificar primeiro COMRPOVANTE DE HORAS nesse período";
							throw new Exception(json_encode($retorno), 1);
						}
					}
					return $insert;
					// REUNIÃO EXTERNA // FESTA FIN DE ANO // LICENÇA AMAMENTAÇÃO // COMPARECIMENTO JUDICIAL // JOGO DO BRASIL // CURSO
				case 'A10':
				case 'A12':
				case 'AA12':
				case 'AA14':
				case 'AA15':
				case 'AA16':
				case 'AA19':
				case 'AA20':
				case 'AA21':
				case 'AA22':
				case 'AA23':
				case 'AA24':
					$insert['data'] = convertDate($post['data_periodo_ini']);
					$insert['periodo_ini'] = convertDate($post['data_periodo_ini']) . " " . $post['hora_ini_marcacao'];
					$insert['periodo_fim'] = convertDate($post['data_periodo_fim']) . " " . $post['hora_fim_marcacao'];
					$insert['permissivo'] = 1;

					$get_atestado = json_decode($this->ponto_model->getOcorrenciaIntervalo($insert['data'], $insert['data'], 'AA2', $insert['id_usuario'], 'aprovado'));
					if (isset($get_atestado) && !empty($get_atestado)) {
						$data_ini = new DateTime($get_atestado[0]->periodo_ini);
						$data_fim = new DateTime($get_atestado[0]->periodo_fim);
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Funcionário tem justificatiava de atestado no período de: " . $data_ini->format("d/m/Y") . " até: " . $data_fim->format("d/m/Y");
						throw new Exception(json_encode($retorno), 1);
					}

					$erro_sistema = json_decode($this->ponto_model->getOcorrenciaIntervalo($insert['data'], $insert['data'], 'A8', $insert['id_usuario'], 'aprovado'));
					if (isset($erro_sistema) && !empty($erro_sistema)) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Justificativa de erro sistema no dia: " . convertDate($erro_sistema[0]->data);
						throw new Exception(json_encode($retorno), 1);
					}

					$ferias = json_decode($this->ponto_model->getOcorrenciaIntervalo(convertDate($post['data_periodo_ini']), convertDate($post['data_periodo_fim']), 'AL1', $insert['id_usuario'], 'aprovado'));
					if (isset($ferias) && !empty($ferias)) {
						$data_ini = new DateTime($get_atestado[0]->periodo_ini);
						$data_fim = new DateTime($get_atestado[0]->periodo_fim);
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Justificativa de férias no período de: " . $data_ini->format("d/m/Y") . " até: " . $data_fim->format("d/m/Y");
						throw new Exception(json_encode($retorno), 1);
					}
					return $insert;
					break;
				//FERIADO	
				case 'AL4':
					$insert['status'] = 'aprovado';
					$insert['id_usuario'] = 3000013; // Usuário TESTE, necessario preencher o campo id_usuario da tabela.
					$insert['data'] = convertDate($post['data_ocorrencia']);
					$insert['periodo_ini'] = $insert['data'] . " " . "00:00:00";
					$insert['periodo_fim'] = $insert['data'] . " " . "00:00:00";
					$insert['permissivo'] = 1;
					return $insert;
					break;
				// MARCAÇÃO EXTRA.
				case 'A9':
					$post['data_periodo_ini'] = convertDate($post['data_periodo_ini']);
					$post['data_periodo_fim'] = convertDate($post['data_periodo_fim']);

					$insert['data'] = $post['data_periodo_ini'];
					$insert['periodo_ini'] = $post['data_periodo_ini'] . " " . $post['hora_ini_marcacao'];
					$insert['periodo_fim'] = $post['data_periodo_fim'] . " " . $post['hora_fim_marcacao'];
					$insert['permissivo'] = 1;

					$get_atestado = json_decode($this->ponto_model->getOcorrenciaIntervalo($insert['data'], $insert['data'], 'AA2', $insert['id_usuario'], 'aprovado'));
					if (isset($get_atestado) && !empty($get_atestado)) {
						$data_ini = new DateTime($get_atestado[0]->periodo_ini);
						$data_fim = new DateTime($get_atestado[0]->periodo_fim);
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Funcionário tem justificatiava de atestado no período de: " . $data_ini->format("d/m/Y") . " até: " . $data_fim->format("d/m/Y");
						throw new Exception(json_encode($retorno), 1);
					}

					$erro_sistema = json_decode($this->ponto_model->getOcorrenciaIntervalo($insert['data'], $insert['data'], 'A8', $insert['id_usuario'], 'aprovado'));
					if (isset($erro_sistema) && !empty($erro_sistema)) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Justificativa de erro sistema no dia: " . convertDate($erro_sistema[0]->data);
						throw new Exception(json_encode($retorno), 1);
					}

					$ferias = json_decode($this->ponto_model->getOcorrenciaIntervalo($insert['data'], $insert['data'], 'AL1', $insert['id_usuario'], 'aprovado'));
					if (isset($ferias) && !empty($ferias)) {
						$data_ini = new DateTime($get_atestado[0]->periodo_ini);
						$data_fim = new DateTime($get_atestado[0]->periodo_fim);
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Justificativa de férias no período de: " . $data_ini->format("d/m/Y") . " até: " . $data_fim->format("d/m/Y");
						throw new Exception(json_encode($retorno), 1);
					}

					return $insert;
					break;
				//DESCONTO FOLHA
				case 'D1':
					break;
				//DESCONTO BANCO
				case 'D2':
					break;
				//VALIDAÇÃO TOKEN
				case 'T1':
					break;
				//ERRO SISTEMA
				case 'A8':
					$insert['data'] = convertDate($post['data_ocorrencia']);
					$insert['periodo_ini'] = $insert['data'] . " " . "00:00:00";
					$insert['periodo_fim'] = $insert['data'] . " " . "00:00:00";
					$insert['permissivo'] = 1;

					$erro_sistema = json_decode($this->ponto_model->getOcorrenciaIntervalo($insert['data'], $insert['data'], 'A8', $insert['id_usuario'], 'aprovado'));
					if (isset($erro_sistema) && !empty($erro_sistema)) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Justificativa de erro sistema no dia: " . convertDate($erro_sistema[0]->data);
						throw new Exception(json_encode($retorno), 1);
					}
					return $insert;
					break;
				case 'D3':
					$insert['data'] = convertDate($post['data_periodo_ini']);
					$insert['periodo_ini'] = convertDate($post['data_periodo_ini']) . " " . "00:00:00";
					$insert['periodo_fim'] = convertDate($post['data_periodo_fim']) . " " . "00:00:00";
					$insert['permissivo'] = 1;
					$insert['status'] = "aprovado";
					$insert['id_autorizado'] = $id_user;
					$get_ocorrencia = json_decode($this->ponto_model->getOcorrenciaIntervalo(convertDate($post['data_periodo_ini']), convertDate($post['data_periodo_fim']), null, $insert['id_usuario']));
					if (isset($get_ocorrencia) && !empty($get_ocorrencia)) {
						foreach ($get_ocorrencia as $key => $value) {
							if (($value->fonte == "A" || $value->fonte == "AA") && $value->status != "reprovado") {
								$data_ini = new DateTime($value->periodo_ini);
								$data_fim = new DateTime($value->periodo_fim);
								$retorno["codigo"] = 1;
								$retorno["input"] = $post;
								$retorno["output"] = null;
								$retorno["mensagem"] = "Funcionário já tem justificatiava de " . strtoupper($VAR_SYSTEM['CODIGO_OCORRENCIA'][$value->classe]) . " no período de: " . $data_ini->format("d/m/Y") . " até: " . $data_fim->format("d/m/Y");
								throw new Exception(json_encode($retorno), 1);
							}
						}
					}

					$get_atestado = json_decode($this->ponto_model->getOcorrenciaIntervalo(convertDate($post['data_periodo_ini']), convertDate($post['data_periodo_fim']), 'AA2', $insert['id_usuario'], 'aprovado'));
					if (isset($get_atestado) && !empty($get_atestado)) {
						$data_ini = new DateTime($get_atestado[0]->periodo_ini);
						$data_fim = new DateTime($get_atestado[0]->periodo_fim);
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Funcionário tem justificatiava de atestado no período de: " . $data_ini->format("d/m/Y") . " até: " . $data_fim->format("d/m/Y");
						throw new Exception(json_encode($retorno), 1);
					}

					$erro_sistema = json_decode($this->ponto_model->getOcorrenciaIntervalo(convertDate($post['data_periodo_ini']), convertDate($post['data_periodo_fim']), 'A8', $insert['id_usuario'], 'aprovado'));
					if (isset($erro_sistema) && !empty($erro_sistema)) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Justificativa de erro sistema no dia: " . convertDate($erro_sistema[0]->data);
						throw new Exception(json_encode($retorno), 1);
					}

					$ferias = json_decode($this->ponto_model->getOcorrenciaIntervalo(convertDate($post['data_periodo_ini']), convertDate($post['data_periodo_fim']), 'AL1', $insert['id_usuario'], 'aprovado'));
					if (isset($ferias) && !empty($ferias)) {
						$data_ini = new DateTime($ferias[0]->periodo_ini);
						$data_fim = new DateTime($ferias[0]->periodo_fim);
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Justificativa de férias no período de: " . $data_ini->format("d/m/Y") . " até: " . $data_fim->format("d/m/Y");
						throw new Exception(json_encode($retorno), 1);
					}

					if ($post['funcionario'] == $id_user && $id_user != 3000000) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $post;
						$retorno["output"] = null;
						$retorno["mensagem"] = "Usuário sem permissão para lançar a própria folga, entre em contato com a ADM.";
						throw new Exception(json_encode($retorno), 1);
					}
					return $insert;
					break;
				default:
					$retorno["codigo"] = 1;
					$retorno["input"] = $post;
					$retorno["output"] = null;
					$retorno["mensagem"] = "Ocorrência invalida 2";
					throw new Exception(json_encode($retorno), 1);
					break;
			}
		}

		function returnClasse($classe)
		{
			if (
				$classe == "AA2" || $classe == "AA3" ||
				$classe == "AL1" || $classe == "AL4" ||
				$classe == "A10" || $classe == "AA6" ||
				$classe == "A11" || $classe == "AA7" ||
				$classe == "AA8" || $classe == "AA9" ||
				$classe == "AA10" || $classe == "AA11" ||
				$classe == "AA12" || $classe == "AA13" ||
				$classe == "AA14" || $classe == "AA15" ||
				$classe == "AA16" || $classe == "AA17" ||
				$classe == "AA18" || $classe == "AA19" ||
				$classe == "AA4"

			) {
				$fonte = substr($classe, 0, 1);
				$tipo = substr($classe, 1, 1);
				$dois_digitos = substr($classe, 2, 1);
				if ($classe == "A10" || $classe == "A11") {
					$fonte = $fonte;
					$tipo = $tipo . $dois_digitos;
				} else {
					if (strlen($classe) == 4) {
						$fonte = substr($classe, 0, 2);
						$tipo = substr($classe, 2, 2);
					} else {
						$fonte = $fonte . $tipo;
						$tipo = $dois_digitos;
					}
				}
			} else {
				$fonte = substr($classe, 0, 1);
				$tipo = substr($classe, 1, 1);
			}
			$retorno['fonte'] = $fonte;
			$retorno['tipo'] = $tipo;
			$retorno['classe'] = $classe;

			return $retorno;
		}

		function dadosToken($id, $usuario)
		{
			$now = clone $this->controller->data_hora_atual;
			$digito_token = mt_rand(1001, 9999);
			$insert_token['token'] = $digito_token;
			$insert_token['id_registro'] = $id;
			$insert_token['id_usuario'] = $usuario->id;
			$insert_token['id_responsavel'] = $usuario->boss;
			$validade = $now->add(new DateInterval('P1D'));
			$insert_token['validade'] = $validade->format('Y-m-d H:i:s');
			$insert_token['status'] = 'pendente';
			return $insert_token;
		}

		function saveFechamento($param)
		{
			try {
				$this->ponto_model->setTable('rh_fechamento_ponto');
				return $is_save = $this->ponto_model->save($param);
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function savePdfEspelho($param)
		{
			try {
				$retorno['codigo'] = 1;
				$url_report = URL_SISTEMA . 'report/createFechamentoPdf/';
				$dados = CurlExec($url_report, $param);
				if ($dados) {
					$dados_usuario = json_decode($param['dados_usuario']);
					$path1 = GED_PONTO . $dados_usuario->cpf . DS;
					$path2 = $path1 . 'espelho_ponto' . DS;
					$file_name = 'fechamento_' . $dados_usuario->cpf . '_' . $this->data_atual->format('YmdHis') . '.pdf';
					if (!file_exists($path1)) {
						if (!mkdir($path1)) {
							$retorno['mensagem'] = 'Erro ao criar diretorio do colaborador';
							throw new ErrorException(json_encode($retorno), 1);
						}
					}

					if (!file_exists($path2)) {
						if (!mkdir($path2)) {
							$retorno['mensagem'] = 'Erro ao criar diretorio de espelho de ponto';
							throw new ErrorException(json_encode($retorno), 1);
						}
					}

					require_once "libs/mpdf/vendor/autoload.php";
					set_time_limit(300);
					$mpdf = new \Mpdf\Mpdf();
					$style_documento = file_get_contents('assets/css/css_relatorio.css');
					$mpdf->SetHeader();
					$mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
					$mpdf->WriteHTML($dados);
					$mpdf->Output($path2 . $file_name, 'F');
					if (file_exists($path2 . $file_name)) {
						$ged['nome_documento'] = $file_name;
						$ged['data_documento'] = $this->data_atual->format('Y-m-d');
						$ged['valido_ate'] = null;
						$ged['doc_origem'] = 'pessoal';
						$ged['id_origem'] = $param['id_fechamento'];
						$ged['codigo_origem'] = null;
						$ged['produto'] = null;
						$ged['tipo'] = 'ponto';
						$ged['subtipo'] = 'fechamento';
						$ged['classificacao'] = 'espelho';
						$ged['descricao'] = 'Fechamento de folha de ponto do periodo de ' . convertDate($param['periodo_ini']) . ' á ' . convertDate($param['periodo_fim']);
						$ged['versao'] = 1;
						$ged['owner'] = $dados_usuario->id;
						$ged['data_criacao'] = $this->data_atual->format('Y-m-d');
						$ged['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
						$ged['alterado_em'] = $this->data_atual->format('Y-m-d H:i:s');
						$ged['deleted'] = 0;
						$this->obj_ged->setTable('ged_documento');
						$save_ged = $this->obj_ged->save($ged);
						if ($save_ged) {
							$anexo['id_documento'] = $save_ged;
							$anexo['nome_amigavel'] = $file_name;
							$anexo['path_root'] = GED_PONTO;
							$anexo['path_objeto'] = $dados_usuario->cpf . DS . 'espelho_ponto' . DS;
							$anexo['nome_hash'] = $file_name;
							$anexo['hash_arquivo'] = hash_file('md5', $path2 . $file_name);
							$anexo['data_criacao'] = $this->data_atual->format('Y-m-d');
							$anexo['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
							$anexo['alterado_em'] = $this->data_atual->format('Y-m-d H:i:s');
							$anexo['deleted'] = 0;
							$this->obj_ged->setTable('ged_anexo');
							$save_anexo = $this->obj_ged->save($anexo);
							if ($save_anexo) {
								$retorno['codigo'] = 0;
								$retorno['mensagem'] = 'Sucesso';
							} else {
								$retorno['mensagem'] = 'Erro ao salvar registro de anexo no GED';
								throw new ErrorException(json_encode($retorno), 1);
							}
						} else {
							$retorno['mensagem'] = 'Erro ao salvar registro no GED';
							throw new ErrorException(json_encode($retorno), 1);
						}
					} else {
						$retorno['mensagem'] = 'Erro ao gerar o pdf de fechamento';
						throw new ErrorException(json_encode($retorno), 1);
					}
					$retorno['mensagem'] = 'Erro desconhecido';
					throw new ErrorException(json_encode($retorno), 1);
				} else {
					$retorno['mensagem'] = 'Erro ao recuperar os dados de fechamento';
					throw new ErrorException(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function processarJustificativa()
		{
			try {
				$id_user = $_SESSION['cmswerp']['userdata']->id;
				if ($this->parametros[1] == "aprovar_ocorrencia" || $this->parametros[1] == "reprovar_ocorrencia") {
					$value_button = $this->parametros[1];
					if (empty($this->parametros[0]) || $this->parametros[0] == "null") {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Selecione uma ocorrência.";
						throw new Exception(json_encode($retorno), 1);
					} else {

						if ($this->parametros[1] == "aprovar_ocorrencia") {
							$insert['status'] = "aprovado";
							$texto_status = "aprovar";
						} elseif ($this->parametros[1] == "reprovar_ocorrencia") {
							$insert['status'] = "reprovado";
							$texto_status = "reprovar";
						}

						$id_explode = explode(",", $this->parametros[0]);
						if (is_array($id_explode)) {
							$this->modelo->setTable('rh_jornada_ocorrencia');
							foreach ($id_explode as $key => $value) {
								$get_ocorrencia[$value] = json_decode($this->modelo->getOcorrencia(null, null, null, null, null, null, $value));
								if (!isset($get_ocorrencia[$value])) {
									$retorno['codigo'] = 1;
									$retorno['input'] = $this->parametros;
									$retorno['output'] = $this->modelo->info;
									$retorno['mensagem'] = "Erro em obter ocorrência. L1876";
									throw new Exception(json_encode($retorno), 1);
								} else {
									if ($id_user == $get_ocorrencia[$value][0]->id_usuario) {
										$retorno['codigo'] = 1;
										$retorno['input'] = $this->parametros;
										$retorno['output'] = $this->modelo->info;
										$retorno['mensagem'] = "Usuario não pode " . $texto_status . " a própria ocorrência.";
										throw new Exception(json_encode($retorno), 1);
									}
								}

								$insert['id_autorizado'] = $id_user;
								$this->modelo->setTable('rh_jornada_ocorrencia');
								$update_ocorrencia = $this->modelo->save($insert, $value);
							}
							if ($update_ocorrencia) {
								$retorno['codigo'] = 0;
								$retorno['input'] = $this->parametros;
								$retorno['output'] = $this->modelo->info;
								$retorno['mensagem'] = "Sucesso em processar ocorrência.";
								throw new Exception(json_encode($retorno), 1);
							} else {
								$retorno['codigo'] = 1;
								$retorno['input'] = $this->parametros;
								$retorno['output'] = $this->modelo->info;
								$retorno['mensagem'] = "Erro em processar ocorrência.";
								throw new Exception(json_encode($retorno), 1);
							}
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro em processar ocorrência, não é um array!";
							throw new Exception(json_encode($retorno), 1);
						}
					}
				} else {

					$value_button = $this->parametros[0];
					$id_usuario = $this->parametros[1];
					$id_ocorrencia = $this->parametros[2];
					$data = $this->parametros[5] . "-" . $this->parametros[4] . "-" . $this->parametros[3];
					if (!isset($this->parametros[0])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Erro value button.";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($this->parametros[1])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Erro id usuario.";
						throw new Exception(json_encode($retorno), 1);
					}

					if (empty($this->parametros[2])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Selecione uma justificativa.";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($this->parametros[5]) || !isset($this->parametros[4]) || !isset($this->parametros[3])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Erro nos parametros.";
						throw new Exception(json_encode($retorno), 1);
					}
					$insert['id_autorizado'] = $id_user;
				}
				$get_ocorrencia = json_decode($this->modelo->getOcorrencia(null, null, $data, null, null, $id_usuario, $id_ocorrencia));

				if (!$get_ocorrencia) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro ao obter ocorrência!";
					throw new Exception(json_encode($retorno), 1);
				}

				if ($value_button == "aprovar") {
					$insert['status'] = "aprovado";
					if ($get_ocorrencia[0]->tipo == "batida_ausente") {
						$insert_registro['deleted'] = 0;
						$insert_registro['status'] = 'aprovado';
						$get_registro = json_decode($this->modelo->getRegistro(null, null, null, $id_usuario, null, null, $get_ocorrencia[0]->id_registro));

						if (!$get_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao obter registro de batida ausente!";
							throw new Exception(json_encode($retorno), 1);
						}
						$this->modelo->setTable('rh_registro_ponto');
						$update_registro = $this->modelo->save($insert_registro, $get_registro[0]->id);
						if (!$update_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao atualizar registro!";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "atestado") {
						$this->modelo->setTable('rh_jornada_ocorrencia');
						$obj_ini = new DateTime($get_ocorrencia[0]->periodo_ini);
						$obj_fim = new DateTime($get_ocorrencia[0]->periodo_fim);
						$diff_atestado = $obj_ini->diff($obj_fim);
						clone $data_aux = $obj_ini;
						for ($x = 0; $x < $diff_atestado->days + 1; $x++) {
							$key_data = $data_aux->format('Y-m-d');
							$data_aux->add(new DateInterval('P1D'));
							$get_ocorrencia_atestado[$key_data] = json_decode($this->modelo->getOcorrencia(null, null, $key_data, null, null, $id_usuario, $id_ocorrencia));
							$update_atestado = $this->modelo->save($insert, $get_ocorrencia_atestado[$key_data][0]->id);
						}
						if ($update_atestado) {
							$retorno['codigo'] = 0;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $get_ocorrencia;
							$retorno['mensagem'] = "Sucesso em aprovar atestado.";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao processar justificativa de atestado";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "ferias") {
						$this->modelo->setTable('rh_jornada_ocorrencia');
						$obj_ini = new DateTime($get_ocorrencia[0]->periodo_ini);
						$obj_fim = new DateTime($get_ocorrencia[0]->periodo_fim);
						$diff_ferias = $obj_ini->diff($obj_fim);
						clone $data_aux = $obj_ini;
						for ($x = 0; $x < $diff_ferias->days + 1; $x++) {
							$key_data = $data_aux->format('Y-m-d');
							$data_aux->add(new DateInterval('P1D'));
							$get_ocorrencia_ferias[$key_data] = json_decode($this->modelo->getOcorrencia(null, null, $key_data, null, null, $id_usuario, $id_ocorrencia));
							$update_ferias = $this->modelo->save($insert, $get_ocorrencia_ferias[$key_data][0]->id);
						}
						if ($update_ferias) {
							$retorno['codigo'] = 0;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $get_ocorrencia;
							$retorno['mensagem'] = "Sucesso em aprovar férias.";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao processar justificativa de férias";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "batida_incorreta") {
						$insert_registro['deleted'] = 0;
						$insert_registro['status'] = 'aprovado';
						$explode_registro_antigo = explode(" ", $get_ocorrencia[0]->periodo_fim);
						$explode_registro_antigo_2 = explode(":", $explode_registro_antigo[1]);
						$hora_marcacao = $explode_registro_antigo_2[0] . ":" . $explode_registro_antigo_2[1];
						$insert_registro['hora_marcacao'] = $hora_marcacao;
						$get_registro = json_decode($this->modelo->getRegistro($get_ocorrencia[0]->classe, $data, 'Justificativa de batida incorreta'));
						if (!$get_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO OBTER REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
						$update_registro = $this->modelo->save($insert_registro, $get_registro[0]->id);
						if (!$update_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO ATUALIZAR REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
					}
				} elseif ($value_button == "reprovar") {
					$insert['status'] = "reprovado";
					if ($get_ocorrencia[0]->tipo == "batida_ausente") {
						$insert_registro['deleted'] = 0;
						$insert_registro['status'] = 'reprovado';
						$get_registro = json_decode($this->modelo->getRegistro($get_ocorrencia[0]->classe, $data));
						if (!$get_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO OBTER REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
						$update_registro = $this->modelo->save($insert_registro, $get_registro[0]->id);
						if (!$update_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO ATUALIZAR REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "atestado") {
						$this->modelo->setTable('rh_jornada_ocorrencia');
						$obj_ini = new DateTime($get_ocorrencia[0]->periodo_ini);
						$obj_fim = new DateTime($get_ocorrencia[0]->periodo_fim);
						$diff_atestado = $obj_ini->diff($obj_fim);
						clone $data_aux = $obj_ini;
						for ($x = 0; $x < $diff_atestado->days + 1; $x++) {
							$key_data = $data_aux->format('Y-m-d');
							$data_aux->add(new DateInterval('P1D'));
							$get_ocorrencia_atestado[$key_data] = json_decode($this->modelo->getOcorrencia(null, null, $key_data, null, null, $id_usuario, $id_ocorrencia));
							$update_atestado = $this->modelo->save($insert, $get_ocorrencia_atestado[$key_data][0]->id);
						}
						if ($update_atestado) {
							$retorno['codigo'] = 0;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $get_ocorrencia;
							$retorno['mensagem'] = "Sucesso em reprovar atestado.";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao processar justificativa de atestado";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "ferias") {
						$this->modelo->setTable('rh_jornada_ocorrencia');
						$obj_ini = new DateTime($get_ocorrencia[0]->periodo_ini);
						$obj_fim = new DateTime($get_ocorrencia[0]->periodo_fim);
						$diff_ferias = $obj_ini->diff($obj_fim);
						clone $data_aux = $obj_ini;
						for ($x = 0; $x < $diff_ferias->days + 1; $x++) {
							$key_data = $data_aux->format('Y-m-d');
							$data_aux->add(new DateInterval('P1D'));
							$get_ocorrencia_ferias[$key_data] = json_decode($this->modelo->getOcorrencia(null, null, $key_data, null, null, $id_usuario, $id_ocorrencia));
							$update_ferias = $this->modelo->save($insert, $get_ocorrencia_ferias[$key_data][0]->id);
						}
						if ($update_ferias) {
							$retorno['codigo'] = 0;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $get_ocorrencia;
							$retorno['mensagem'] = "Sucesso em reprovar férias.";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao processar justificativa de férias";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "batida_incorreta") {
						$insert_registro['deleted'] = 0;
						$insert_registro['status'] = 'aprovado';
						$explode_registro_antigo = explode(" ", $get_ocorrencia[0]->periodo_ini);
						$explode_registro_antigo_2 = explode(":", $explode_registro_antigo[1]);
						$hora_marcacao = $explode_registro_antigo_2[0] . ":" . $explode_registro_antigo_2[1];
						$insert_registro['hora_marcacao'] = $hora_marcacao;
						$get_registro = json_decode($this->modelo->getRegistro($get_ocorrencia[0]->classe, $data, 'Justificativa de batida incorreta'));
						if (!$get_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO OBTER REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
						$update_registro = $this->modelo->save($insert_registro, $get_registro[0]->id);
						if (!$update_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO ATUALIZAR REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
					}
				} elseif ($value_button == "apagar") {
					$insert['deleted'] = 1;
					unset($insert['id_autorizado']);
					if ($get_ocorrencia[0]->tipo == "batida_ausente") {
						$rh_ocorrencia = "batida ausente";
						$get_registro = json_decode($this->modelo->getRegistro($get_ocorrencia[0]->classe, $data, $rh_ocorrencia));
						if (!$get_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO OBTER REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
						$update_registro = $this->modelo->save($insert, $get_registro[0]->id);
						if (!$update_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO ATUALIZAR REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "atestado") {
						$this->modelo->setTable('rh_jornada_ocorrencia');
						$obj_ini = new DateTime($get_ocorrencia[0]->periodo_ini);
						$obj_fim = new DateTime($get_ocorrencia[0]->periodo_fim);
						$diff_atestado = $obj_ini->diff($obj_fim);
						clone $data_aux = $obj_ini;
						for ($x = 0; $x < $diff_atestado->days + 1; $x++) {
							$key_data = $data_aux->format('Y-m-d');
							$data_aux->add(new DateInterval('P1D'));
							$get_ocorrencia_atestado[$key_data] = json_decode($this->modelo->getOcorrencia(null, null, $key_data, null, null, $id_usuario, $id_ocorrencia));
							$update_atestado = $this->modelo->save($insert, $get_ocorrencia_atestado[$key_data][0]->id);
						}
						if ($update_atestado) {
							$retorno['codigo'] = 0;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $get_ocorrencia;
							$retorno['mensagem'] = "Sucesso em apagar atestado.";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao processar justificativa de atestado";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "ferias") {
						$this->modelo->setTable('rh_jornada_ocorrencia');
						$obj_ini = new DateTime($get_ocorrencia[0]->periodo_ini);
						$obj_fim = new DateTime($get_ocorrencia[0]->periodo_fim);
						$diff_ferias = $obj_ini->diff($obj_fim);
						clone $data_aux = $obj_ini;
						for ($x = 0; $x < $diff_ferias->days + 1; $x++) {
							$key_data = $data_aux->format('Y-m-d');
							$data_aux->add(new DateInterval('P1D'));
							$get_ocorrencia_ferias[$key_data] = json_decode($this->modelo->getOcorrencia(null, null, $key_data, null, null, $id_usuario, $id_ocorrencia));
							$update_ferias = $this->modelo->save($insert, $get_ocorrencia_ferias[$key_data][0]->id);
						}
						if ($update_ferias) {
							$retorno['codigo'] = 0;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $get_ocorrencia;
							$retorno['mensagem'] = "Sucesso em apagar férias.";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao processar justificativa de férias";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "batida_incorreta") {
						$explode_registro_antigo = explode(" ", $get_ocorrencia[0]->periodo_ini);
						$explode_registro_antigo_2 = explode(":", $explode_registro_antigo[1]);
						$hora_marcacao = $explode_registro_antigo_2[0] . ":" . $explode_registro_antigo_2[1];
						$insert_registro['hora_marcacao'] = $hora_marcacao;
						$insert_registro['status'] = 'aprovado';
						$get_registro = json_decode($this->modelo->getRegistro($get_ocorrencia[0]->classe, $data, 'Justificativa de batida incorreta'));

						if (!$get_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO OBTER REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
						$update_registro = $this->modelo->save($insert_registro, $get_registro[0]->id);
						if (!$update_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO ATUALIZAR REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
					}
				}
				$this->modelo->setTable('rh_jornada_ocorrencia');
				$update = $this->modelo->save($insert, $get_ocorrencia[0]->id);
				if ($update) {
					$retorno['codigo'] = 0;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = $get_ocorrencia;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro ao processar justificativa";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function processarFalta()
		{
			try {
				$id_user = $_SESSION['cmswerp']['userdata']->id;
				if (empty($this->parametros[0]) || !isset($this->parametros[0])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro nos parametros!";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$value_button = $this->parametros[0];
				}

				if (empty($this->parametros[1]) || !isset($this->parametros[1])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro id_usuario!";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$id_usuario = $this->parametros[1];
				}

				if (empty($this->parametros[2]) || !isset($this->parametros[2])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Selecione uma data!";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$data_explode = explode(",", $this->parametros[2]);
				}

				if ($value_button == "abonada") {
					$insert['tipo'] = 5;
					$insert['fonte'] = "A";
					$insert['classe'] = "A5";
				} elseif ($value_button == "desconto_banco") {
					$insert['tipo'] = 2;
					$insert['fonte'] = "D";
					$insert['classe'] = "D2";
				} elseif ($value_button == "desconto_folha") {
					$insert['tipo'] = 1;
					$insert['fonte'] = "D";
					$insert['classe'] = "D1";
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro no value button!";
					throw new Exception(json_encode($retorno), 1);
				}

				$insert['id_usuario'] = $id_usuario;
				$insert['status'] = "aprovado";
				$insert['id_autorizado'] = $id_user;

				$this->modelo->setTable('rh_jornada_ocorrencia');
				if (is_array($data_explode)) {
					foreach ($data_explode as $key => $value) {
						$insert['data'] = $value;
						$insert['periodo_ini'] = $value;
						$insert['periodo_fim'] = $value;
						$get_ocorrencia = json_decode($this->modelo->getOcorrencia(null, "ocorrencia_tipo", $value, null, null, $id_usuario));
						if ($get_ocorrencia) {
							$update_desconto = $this->modelo->save($insert, $get_ocorrencia[0]->id);
						} else {
							$save_desconto = $this->modelo->save($insert);
						}
					}
				}
				if ($save_desconto || $update_desconto) {
					if ($value_button == "desconto_banco") {
						$retorno['mensagem'] = "Sucesso, desconto banco de horas.";
					} elseif ($value_button == "desconto_folha") {
						$retorno['mensagem'] = "Sucesso, desconto folha de pagamento.";
					} elseif ($value_button == "abonada") {
						$retorno['mensagem'] = "Sucesso em abonar dia.";
					} else {
						$retorno['mensagem'] = "Sucesso";
					}
					$retorno['codigo'] = 0;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro ao salvar ocorrência";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}
	}