<?php
	/**
	* Caio Freitas
    * 18/04/2023
	* Classe para gerar texto de minuta de contrato
	*/    
    class RotinaCrystal extends Main{
        private 
            $model_modelo,
            $model_produto,
            $dicionario,
            $data_extenso,
            $obj_sign,
            $obj_assinatura,
            $minuta,
            $codigo_produto,
            $proposta_model;

        function __construct( $controller ){
            require ABSPATH."/config_extras.php";
            setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
            $this->controller      = $controller;
            $this->model_modelo    = $this->controller->load_model('modelo/modelo', true);
            $this->model_produto   = $this->controller->load_model('produtos/produtos', true);
            $this->proposta_model  = $this->controller->load_model('propostas/propostas', true);
            $this->dicionario      = $VAR_SYSTEM;
            $this->data_extenso    = strftime('%d de %B de %Y', strtotime('today'));
            // fazer alterações e colocar nas classes corretas
            $this->obj_sign 	   = new D4Sign( $this->controller, "D4S002", false );
            $this->obj_assinatura  = new Assinatura( $this->controller, 'd4sign' );
            $this->minuta          = new Minuta( $this->controller );
            parent::__construct($controller);
        }

        function criarGedMinuta( $id_objeto, $codigo ){
            try{
                $this->codigo_produto = $codigo;
                $contato_cm = json_decode( $this->proposta_model->getContatoSign( "sign_cm", null, null, true ) );                        
                if(!isset($contato_cm) || empty($contato_cm)){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $id_objeto;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Necessario o cadastro de contato ATIVO de RESPONSÁVEL LEGAL e TESTEMUNHA da C&M Software, acesse o menu configurações e cadastre";
                    throw new Exception (json_encode($retorno), 1);
                }else{
                    foreach ($contato_cm as $key => $value) {
                        if(strtoupper($value->tipo_contato) == "JURIDICO"){
                            $juridico[] = $value;
                        }
                        if(strtoupper($value->tipo_contato) == "TESTEMUNHA"){
                            $testemunha[] = $value;
                        }
                        if(strtoupper($value->tipo_contato) == "RESPONSAVEL_LEGAL"){
                            $responsavel_legal[] = $value;
                        }
                    }

                    if(!isset($responsavel_legal) || empty($responsavel_legal)){
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $id_objeto;
                        $retorno['output']   = null;
                        $retorno['mensagem'] = "Necessario ter (UM) contato de REPRESENTANTE LEGAL da C&M Software cadastrado ATIVO, acesse o menu configurações e cadastre";
                        throw new Exception (json_encode($retorno), 1);         
                    }

                    if(!isset($juridico) || empty($juridico)){
                        if(!isset($testemunha) || empty($testemunha)){
                            $retorno['codigo']   = 1;
                            $retorno['input']    = $id_objeto;
                            $retorno['output']   = null;
                            $retorno['mensagem'] = "Necessario ter (UMA) TESTEMUNHA OU CONTATO JURIDICO da C&M Software cadastrado ATIVO, acesse o menu configurações e cadastre";
                            throw new Exception (json_encode($retorno), 1);
                        }
                    }
                }
            
                $contrato = json_decode( $this->proposta_model->getIfContratoCrystal( $id_objeto ) );                    		
                $ged 	  = json_decode( $this->proposta_model->gedDocumentoAnexo2( $id_objeto, 'minuta' ) );

                if( isset( $ged ) && !empty( $ged ) ){
                    $nome_hash     = $ged[0]->nome_hash;
                    $id_ged        = $ged[0]->id_ged_documento;
                    $id_ged_anexo  = $ged[0]->id_ged_anexo; 
                }else{
                    $data_hash    = date('YmdHms');
                    $nome_hash    = "minuta_".$id_objeto."_".$data_hash.".pdf";
                    $id_ged       = null;
                    $id_ged_anexo = null;
                }		

                $insert_ged_documento = [
                    'nome_documento' => 'minuta_'.$id_objeto.'.pdf',
                    'data_documento' => $this->data_atual->format('Y-m-d'),
                    'doc_origem'     => 'minuta',
                    'id_origem'      => $id_objeto, 
                    'produto'        => $contrato[0]->id_produto,
                    'tipo' 			 => 'minuta',
                    'subtipo' 		 => 'minuta',               
                    'owner' 		 => (isset($contrato[0]->id_owner))?$contrato[0]->id_owner:null,               
                    'data_criacao' 	 => $this->data_atual->format('Y-m-d H:i:s'),
                ];
                $this->proposta_model->setTable('ged_documento');
                $save_ged_documento = $this->proposta_model->save( $insert_ged_documento, $id_ged );
                if(!$save_ged_documento){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $insert_ged_documento;
                    $retorno['output']   = $this->proposta_model->info;
                    $retorno['mensagem'] = "Erro ged";
                    throw new Exception (json_encode($retorno), 1);
                }else{
                    $ged_documento = json_decode( $this->proposta_model->gedDocumento2( 'minuta', $id_objeto ) );							
                    if(!isset($ged_documento)){
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $id_objeto;
                        $retorno['output']   = $this->proposta_model->info;
                        $retorno['mensagem'] = "Erro ged documento";
                        throw new Exception (json_encode($retorno), 1);
                    }

                    if(isset($ged) && !empty($ged)){
                        $hash_arquivo = $ged[0]->nome_hash;                    
                    }else{
                        if(!is_dir(PATH_MINUTA.DS.$contrato[0]->cnpj)){
                            mkdir(PATH_MINUTA.DS.$contrato[0]->cnpj);
                        }
                        
                        $path_documento = PATH_MINUTA.DS.$contrato[0]->cnpj.DS.$nome_hash;
                        if( file_exists( $path_documento ) ){
                            $hash_arquivo = hash_file( 'md5', $path_documento );
                        }else{
                            $hash_arquivo = '';
                        }                 
                    }							
                }

                $insert_ged_anexo = [
                    'id_documento'  => $ged_documento[0]->id,
                    'nome_amigavel' => $ged_documento[0]->nome_documento,
                    'path_root'     => PATH_MINUTA,
                    'path_objeto'   => $contrato[0]->cnpj.DS,
                    'nome_hash'     => $nome_hash,
                    'hash_arquivo'  => $hash_arquivo,
                    'data_criacao'  => $this->data_atual->format('Y-m-d H:i:s'),
                ];
                
                $this->proposta_model->setTable('ged_anexo');							
                $save_ged_anexo = $this->proposta_model->save( $insert_ged_anexo, $id_ged_anexo );
                if( !$save_ged_anexo ){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $insert_ged_anexo;
                    $retorno['output']   = $this->proposta_model->info;;
                    $retorno['mensagem'] = "Erro save ged documento";
                    throw new Exception (json_encode($retorno), 1);
                }else{
                    $obj_pdf = json_decode( $this->gerarPDF( $contrato[0]->codigo, $id_objeto,$contrato[0]->id_proposta ) );
                    if( isset( $obj_pdf ) && $obj_pdf->codigo == 0 ){
                        $retorno['codigo']   = 0;
                        $retorno['etapa']    = 6;
                        $retorno['input']    = $ged;
                        $retorno['output']   = $id_objeto;
                        $retorno['mensagem'] = "Sucesso";
                        throw new Exception ( json_encode( $retorno ), 1 );	                    
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['mensagem'] = "Erro ao gerar PDF COD: 165";
                        throw new Exception ( json_encode( $obj_pdf ), 1 );
                    }
                }
            }catch(Exception $e){
                return $e->getMessage();
            }
        }

        function gerarPDF( $produto, $id_contrato, $id_proposta = null ){
            try{
                $texto  = json_decode( $this->model_modelo->getModelo( $produto ) );
                $ged    = json_decode( $this->proposta_model->gedDocumentoAnexo2( $id_contrato, 'minuta' ) );
                $path = $ged[0]->path_objeto;
                $nome_arquivo = $ged[0]->nome_hash;
                $path_full = PATH_MINUTA.DS.$path.$nome_arquivo;
                
                if(!is_dir(PATH_MINUTA)){
                    mkdir(PATH_MINUTA);
                }

                if(!is_dir(PATH_MINUTA.DS.$path)){
                    mkdir(PATH_MINUTA.DS.$path);
                }  
                
                switch ($produto) {
                    case 'CRY0002':
                        $pdf = $this->pdfCrystal( $texto, $path_full, $id_contrato );
                    break;
                    case 'CRY0003':
                        $pdf = $this->pdfCrystal( $texto, $path_full, $id_contrato );
                    break;
                    default:
                        $retorno['codigo']   = 1;						
                        $retorno['input']    = $produto;
                        $retorno['output']   = null;
                        $retorno['mensagem'] = "Produto indefinido";
                        throw new Exception (json_encode($retorno), 1);	
                    break;
                }

                if( isset( $pdf ) && !empty( $pdf ) ){
                    $retorno['codigo']   = 0;						
                    $retorno['input']    = $produto;
                    $retorno['output']   = $pdf;
                    $retorno['mensagem'] = "Sucesso";
                    throw new Exception (json_encode($retorno), 1);	
                }else{
                    $retorno['codigo']   = 1;						
                    $retorno['output']   = $pdf;
                    $retorno['mensagem'] = "Erro ao gerar pdf COD 219";
                    throw new Exception (json_encode($retorno), 1);		
                }                      
            }catch (Exception $e) {
                return $e->getMessage();
            }
        }

        function pdfCrystal( $texto, $path_full, $id_contrato ){
            require_once "libs/mpdf/vendor/autoload.php";       
            set_time_limit(300); 
            if( file_exists( $path_full ) ){
                unlink( $path_full ); 
            }     

            $style_documento = file_get_contents('assets/css/css_pdf.css');
            $mpdf = new \Mpdf\Mpdf();
            $mpdf->SetHeader();      
            $contador = 0;
            if( $texto ){
                foreach ( $texto as $key => $value ) {
                    if($contador == 0){
                        $value->texto = $this->replaceTag( $id_contrato, $value->texto, $this->codigo_produto );
                        $mpdf->WriteHTML($style_documento,\Mpdf\HTMLParserMode::HEADER_CSS);
                        $mpdf->WriteHTML("<br></br><br></br><br><br>".$value->texto);
                        $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img> <p style="font-size:10px">Barueri, '.$this->data_extenso.'</p></div>',null,true);
                    }elseif($contador == 1){
                        $value->texto = $this->replaceTag( $id_contrato, $value->texto, $this->codigo_produto );                     
                        $mpdf->AddPage();                
                        $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>',null,true);
                        $mpdf->WriteHTML($style_documento,\Mpdf\HTMLParserMode::HEADER_CSS);               
                        $mpdf->WriteHTML("<br></br><br></br><br></br>".$value->texto);               
                    }else{
                        $value->texto = $this->replaceTag($id_contrato, $value->texto, $this->codigo_produto);
                        $mpdf->AddPage();
                        $mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>',null,true);
                        $mpdf->WriteHTML($style_documento,\Mpdf\HTMLParserMode::HEADER_CSS);               
                        $mpdf->WriteHTML("<br></br><br>".$value->texto);                
                    }
                    $contador++;
                }
                $mpdf->Output( $path_full, 'F' ); 
                return true;
            }else{
                return false;
            }
        } 

        function replaceTag( $id_contrato, $texto, $cod_produto ){
            require ABSPATH."/config_extras.php";
            $dicionario = $VAR_SYSTEM;
            setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
            if( isset( $id_contrato ) && !empty( $id_contrato ) ){
                $contrato = json_decode( $this->proposta_model->getIfContrato( $id_contrato ) );
                $endereco = json_decode( $this->proposta_model->getIfEndereco( $id_contrato ) ); 
                $dados_minuta["CLIENTE"]["CLIENTE"]   = $contrato[0]->razao_social;
                $dados_minuta["CLIENTE"]["CNPJ"]      = formatarString( "cnpj", $contrato[0]->cnpj );
                $dados_minuta["ENDERECO"]["ENDERECO"] = $endereco[0]->endereco.", nº ".$endereco[0]->numero;
                $dados_minuta["ENDERECO"]["BAIRRO"]   = $endereco[0]->bairro;           
                $dados_minuta["ENDERECO"]["CEP"]      = formatarString("cep", $endereco[0]->cep);
                $dados_minuta["ENDERECO"]["CIDADE"]   = $endereco[0]->cidade;
                $dados_minuta["ENDERECO"]["UF"]       = $endereco[0]->estado;                       
                $contatos = json_decode( $this->proposta_model->getIfContato( $id_contrato, 'minuta' ) );            
                if( isset( $contatos ) && !empty( $contatos ) ){
                    $contador_representante = 0;
                    foreach ( $contatos as $key => $value ) {
                        if(strtoupper($value->tipo_contato) == "RESPONSAVEL_LEGAL"){
                            if($contador_representante == 0){                     
                                $dados_minuta["REPRESENTANTE"]["NOME"]      = $value->nome;
                                $dados_minuta["REPRESENTANTE"]["CARGO"]     = $value->cargo_setor;
                                $dados_minuta["REPRESENTANTE"]["CPF"]       = formatarString("cpf",$value->cpf);                      
                                $dados_minuta["REPRESENTANTE"]["TELEFONE"]  = formatarString("telefone",$value->telefone);
                                $dados_minuta["REPRESENTANTE"]["EMAIL"]     = $value->email;
                            }else{
                                $dados_minuta["REPRESENTANTE_2"]["NOME"]      = "<b>".$value->nome."</b>";
                                $dados_minuta["REPRESENTANTE_2"]["CARGO"]     = $value->cargo_setor;
                                $dados_minuta["REPRESENTANTE_2"]["CPF"]       = formatarString("cpf",$value->cpf);                      
                                $dados_minuta["REPRESENTANTE_2"]["TELEFONE"]  = formatarString("telefone",$value->telefone);
                                $dados_minuta["REPRESENTANTE_2"]["EMAIL"]     = $value->email;
                            }
                            $contador_representante++;
                        }

                        if(strtoupper($value->tipo_contato) == "TESTEMUNHA"){
                            $dados_minuta["TESTEMUNHA"]["NOME"]         = $value->nome;
                            $dados_minuta["TESTEMUNHA"]["CPF"]          = formatarString("cpf",$value->cpf);
                            $dados_minuta["TESTEMUNHA"]["EMAIL"]        = $value->email;
                            $dados_minuta["TESTEMUNHA"]["TIPO_CONTATO"] = strtoupper($value->tipo_contato);
                            $dados_minuta["TESTEMUNHA"]["TELEFONE"]     = formatarString("telefone",$value->telefone);
                        }

                        if(strtoupper($value->tipo_contato) == "TESTEMUNHA_2"){
                            $dados_minuta["TESTEMUNHA_2"]["NOME"]         = $value->nome;
                            $dados_minuta["TESTEMUNHA_2"]["CPF"]          = formatarString("cpf",$value->cpf);
                            $dados_minuta["TESTEMUNHA_2"]["EMAIL"]        = $value->email;
                            $dados_minuta["TESTEMUNHA_2"]["TIPO_CONTATO"] = "TESTEMUNHA";
                            $dados_minuta["TESTEMUNHA_2"]["TELEFONE"]     = formatarString("telefone",$value->telefone);
                        }

                        if(!isset($dados_minuta["CONTATO_FINANCEIRO"])){
                            if(strtoupper($value->tipo_contato) == "FINANCEIRO"){
                                $dados_minuta["CONTATO_FINANCEIRO"]["TIPO_CONTATO"] = strtoupper($value->tipo_contato);
                                $dados_minuta["CONTATO_FINANCEIRO"]["NOME"]         = $value->nome;
                                $dados_minuta["CONTATO_FINANCEIRO"]["EMAIL"]        = $value->email;
                                $dados_minuta["CONTATO_FINANCEIRO"]["TELEFONE"]     = formatarString("telefone",$value->telefone); 
                            }
                        }else{
                            if(strtoupper($value->tipo_contato) == "FINANCEIRO"){                            
                                $dados_minuta["CONTATO_FINANCEIRO"]["CONTATO_FINANCEIRO_2"] = "• FINANCEIRO: ".$value->nome." - e-mail: ".$value->email." - telefone: ".formatarString("telefone",$value->telefone);                          
                            }
                        }

                        if(strtoupper($value->tipo_contato) == "CONTATO_RESPONSAVEL"){
                            $contato_responsavel['status'] = true;
                            $contato_responsavel['dados'][] = $value;
                        }            
                    }

                    if( !isset( $dados_minuta["CONTATO_FINANCEIRO"]["CONTATO_FINANCEIRO_2"] ) ){
                        $dados_minuta["CONTATO_FINANCEIRO"]["CONTATO_FINANCEIRO_2"] = "";
                    }
                    
                    if(isset($contato_responsavel) && $contato_responsavel['status'] == true){
                        $dados_minuta["CONTATO_RESPONSAVEL"]["NOME"]     = $contato_responsavel["dados"][0]->nome;
                        $dados_minuta["CONTATO_RESPONSAVEL"]["EMAIL"]    = $contato_responsavel["dados"][0]->email;
                        $dados_minuta["CONTATO_RESPONSAVEL"]["TELEFONE"] = formatarString("telefone",$contato_responsavel["dados"][0]->telefone);
                    }else{
                        $dados_minuta["CONTATO_RESPONSAVEL"]["NOME"]     = $dados_minuta["REPRESENTANTE"]["NOME"];
                        $dados_minuta["CONTATO_RESPONSAVEL"]["EMAIL"]    = $dados_minuta["REPRESENTANTE"]["EMAIL"];
                        $dados_minuta["CONTATO_RESPONSAVEL"]["TELEFONE"] = $dados_minuta["REPRESENTANTE"]["TELEFONE"];
                    }               
                }
            
                $contato_cm = json_decode($this->proposta_model->getContatoSign("sign_cm", null, null, true));
                if(isset($contato_cm) && !empty($contato_cm)){
                    foreach ($contato_cm as $key => $value) {
                        if(strtoupper($value->tipo_contato) == "JURIDICO"){
                            $juridico[] = $value;
                        }
                        if(strtoupper($value->tipo_contato) == "TESTEMUNHA"){
                            $testemunha[] = $value;
                        }
                    }
                    if(isset($juridico) && !empty($juridico)){
                        $dados_minuta['TESTEMUNHA_CM']["NOME"]  = $juridico[0]->nome;
                        $dados_minuta['TESTEMUNHA_CM']["CPF"]   = formatarString("cpf",$juridico[0]->cpf);
                        $dados_minuta['TESTEMUNHA_CM']["EMAIL"] = $juridico[0]->email;
                    }else{
                        if(isset($testemunha) && !empty($testemunha)){
                            $dados_minuta['TESTEMUNHA_CM']["NOME"]  = $testemunha[0]->nome;
                            $dados_minuta['TESTEMUNHA_CM']["CPF"]   = formatarString("cpf",$testemunha[0]->cpf);
                            $dados_minuta['TESTEMUNHA_CM']["EMAIL"] = $testemunha[0]->email;
                        }
                    }
                }
                        
                $faturamento = json_decode($this->proposta_model->getInstrucaoFaturamento($id_contrato));          
                if(isset($faturamento) && !empty($faturamento)){
                    
                    if(isset($faturamento[0]->implantacao) && !empty($faturamento[0]->implantacao)){                             
                        $dados_minuta["FATURAMENTO"]["IMPLANTACAO"]         = funcValor($faturamento[0]->implantacao,  'C', 2);
                        $dados_minuta["FATURAMENTO"]["IMPLANTACAO_EXTENSO"] = "( ".Extenso::converte(funcValor($faturamento[0]->implantacao,'C',2), true, false)." )";
                    }
                    
                    if(isset($faturamento[0]->hospedagem) && !empty($faturamento[0]->hospedagem)){                   
                        $dados_minuta["FATURAMENTO"]["PACOTE"] = funcValor($faturamento[0]->hospedagem,'C',2);
                        $dados_minuta["FATURAMENTO"]["PACOTE_EXTENSO"] = "( ".Extenso::converte(funcValor($faturamento[0]->hospedagem,'C',2), true, false)." )";
                    }else{     
                        if($contrato[0]->id_proposta != 0){              
                            $pacote_propostas = json_decode($this->proposta_model->getPacotePropostas($contrato[0]->id_proposta));
                            if(isset($pacote_propostas) && !empty($pacote_propostas)){                       
                                $dados_minuta["FATURAMENTO"]["PACOTE"] = funcValor($pacote_propostas[0]->preco_pkt,'C',2);
                                $dados_minuta["FATURAMENTO"]["PACOTE_EXTENSO"] = "( ".Extenso::converte(funcValor($pacote_propostas[0]->preco_pkt,'C',2), true, false)." )";
                            }
                        }
                    }
                
                    $dados_minuta["FATURAMENTO"]["CORTE_FATURAMENTO"] = $faturamento[0]->faturamento_todo_dia;
                    $dados_minuta["FATURAMENTO"]["CORTE_FATURAMENTO_EXTENSO"] = "( ".Extenso::converte($faturamento[0]->faturamento_todo_dia,false,false)." )";                
                    if($faturamento[0]->tipo_data_faturamento == "dias_apos_faturamento" && !empty($faturamento[0]->dias_apos_faturamento)){                    
                        $dados_minuta["FATURAMENTO"]["PRAZO_PAGAMENTO"] = "de ".$faturamento[0]->dias_apos_faturamento;
                        $dados_minuta["FATURAMENTO"]["PRAZO_PAGAMENTO_EXTENSO"] = "( ".Extenso::converte($faturamento[0]->dias_apos_faturamento,false,false)." ) dias";
                    }else{
                        $dados_minuta["FATURAMENTO"]["PRAZO_PAGAMENTO"] = "todo dia ".$faturamento[0]->vencimento_todo_dia;
                        $dados_minuta["FATURAMENTO"]["PRAZO_PAGAMENTO_EXTENSO"] = "( ".Extenso::converte($faturamento[0]->vencimento_todo_dia,false,false)." ) de cada mês";
                    }
                        

                    $dados_minuta["FATURAMENTO"]["PRIMEIRO_FATURAMENTO"] = "<b> 29 (vinte e nove) </b>";
                    if(empty($faturamento[0]->duracao_contrato)){
                        $dados_minuta["FATURAMENTO"]["VIGENCIA_CONTRATO"] = "INDETERMINADO";
                        $dados_minuta["FATURAMENTO"]["VIGENCIA_CONTRATO_EXTENSO"] = "";
                    }else{
                        $dados_minuta["FATURAMENTO"]["VIGENCIA_CONTRATO"] = strtoupper(str_replace("meses","",$faturamento[0]->duracao_contrato));
                        $dados_minuta["FATURAMENTO"]["VIGENCIA_CONTRATO_EXTENSO"] = "(".Extenso::converte(str_replace("meses","",$faturamento[0]->duracao_contrato),false,false).") meses";
                    }
                                
                    $dados_minuta["FATURAMENTO"]["INDICE_REAJUSTE"] = strtoupper($faturamento[0]->reajuste);
                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS"] = $faturamento[0]->percentual_juros."%";  
                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"] = "(".Extenso::converte($faturamento[0]->percentual_juros,false,false)." porcento)";
                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA"] = $faturamento[0]->percentual_multa."%";
                    $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"] = "(".Extenso::converte($faturamento[0]->percentual_multa,false,false)." porcento)";     
                
                    if($cod_produto != "ADM0001"){                    
                        $empresa = json_decode($this->proposta_model->getEmpresaVendedora(2));                    
                    }else{
                        $empresa = json_decode($this->proposta_model->getEmpresaVendedora(4));
                    } 
                    
                    if(isset($empresa) && !empty($empresa)){
                        foreach ($empresa as $key => $value) {
                            $dados_minuta["FATURAMENTO"]["CM"]      = $value->razao_social;
                            $dados_minuta["FATURAMENTO"]["CM_CNPJ"] = formatarString("cnpj",$value->cnpj);
                        }
                    }                                         
                }  
                
                switch ( $cod_produto ) {
                    case 'CRY0001':
                        $lp_crystal = json_decode($this->proposta_model->getLpId( null, $contrato[0]->id_proposta, $cod_produto ) );
                        if(isset( $lp_crystal ) && is_array( $lp_crystal ) ){
                            foreach ($lp_crystal as $key => $value) {
                                if($value->cod_modulo == "CRY0011"){
                                    $dados_minuta["VALORES"]['OPEN_BANKING']         = funcValor($value->valor_real,'C',2);
                                    $dados_minuta["VALORES"]['OPEN_BANKING_EXTENSO'] = "(".Extenso::converte($dados_minuta["VALORES"]['OPEN_BANKING'],true,false).")";
                                    $dados_minuta["VALORES"]['OPEN_BANKING']         = "R$ ".$dados_minuta["VALORES"]['OPEN_BANKING']; 
                                }else if($value->cod_modulo == "CRY0012"){
                                    $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA']         = funcValor($value->valor_real,'C',2);
                                    $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA_EXTENSO'] = "(".Extenso::converte($dados_minuta["VALORES"]['TRANSACAO_EXECUTADA'],true,false).")";
                                    $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA']         = "R$ ".$dados_minuta["VALORES"]['TRANSACAO_EXECUTADA'];
                                }
                            }
                        }                    
            
                        if(isset($dados_minuta["VALORES"]['TRANSACAO_EXECUTADA'])){
                            $texto = str_replace( $dicionario["DICIONARIO_TAG"]["VALORES"]["CRYSTAL"]['TRANSACAO_EXECUTADA'], $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA'], $texto);
                        }

                        if(isset($dados_minuta["VALORES"]['TRANSACAO_EXECUTADA_EXTENSO'])){
                            $texto = str_replace($dicionario["DICIONARIO_TAG"]["VALORES"]["CRYSTAL"]['TRANSACAO_EXECUTADA_EXTENSO'],$dados_minuta["VALORES"]['TRANSACAO_EXECUTADA_EXTENSO'],$texto);
                        }

                        if(isset($dados_minuta["VALORES"]['OPEN_BANKING'])){
                            $texto = str_replace($dicionario["DICIONARIO_TAG"]["VALORES"]["CRYSTAL"]['OPEN_BANKING'],$dados_minuta["VALORES"]['OPEN_BANKING'],$texto);
                        }

                        if(isset($dados_minuta["VALORES"]['OPEN_BANKING_EXTENSO'])){
                            $texto = str_replace($dicionario["DICIONARIO_TAG"]["VALORES"]["CRYSTAL"]['OPEN_BANKING_EXTENSO'],$dados_minuta["VALORES"]['OPEN_BANKING_EXTENSO'],$texto);
                        }
                    break;                                                       
                    case 'CRY0003':
                        $cobranca = $this->controller->load_model( 'cobranca/cobranca', true );
                        // Lista de preço de proposta
                        $lista_preco = json_decode( $this->proposta_model->getLpId( null, $contrato[0]->id_proposta, $cod_produto ) );
                        if( !$lista_preco ){
                            // lista de preço padrão
                            $lista_preco = json_decode( $cobranca->getListaPrecoPadraoByCodigo( $cod_produto ) );
                        }

                        if( $lista_preco ){
                            foreach ( $lista_preco as $key => $value ) {
                                $i1              = $value->codigo_modulo;
                                $valor           = '**--'.$i1.'_VALOR--**';
                                $valor_extenso   = '**--'.$i1.'_EXTENSO--**';
                                $valor_descricao = '**--'.$i1.'_DESCRICAO--**';

                                $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA']         = funcValor( $value->valor_real,'C',2 );
                                $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA_EXTENSO'] = "(".Extenso::converte($dados_minuta["VALORES"]['TRANSACAO_EXECUTADA'],true,false).")";
                                $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA']         = "R$ ".$dados_minuta["VALORES"]['TRANSACAO_EXECUTADA'];

                                if( isset( $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA'] ) ){
                                    $texto = str_replace( $valor, $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA'], $texto );
                                }

                                if( isset( $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA_EXTENSO'] ) ){
                                    $texto = str_replace( $valor_extenso, $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA_EXTENSO'].' por cada transação executada', $texto );
                                }

                                if( isset( $dados_minuta["VALORES"]['TRANSACAO_EXECUTADA_EXTENSO'] ) ){
                                    $texto = str_replace( $valor_descricao, $value->titulo_modulo, $texto );
                                }
                            }
                        }
                    break;
                    default:
                        //default                   
                    break;
                }   
            }

            //CLIENTE
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["CLIENTE"],$dados_minuta["CLIENTE"],$texto);
            //ENDERECO
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["ENDERECO"],$dados_minuta["ENDERECO"],$texto);              
            //RESPONSÁVEL LEGAL 2
            if(isset($dados_minuta["REPRESENTANTE_2"])){
                $add_texto = "e ".$dados_minuta["REPRESENTANTE_2"]["NOME"].", ".$dados_minuta["REPRESENTANTE_2"]["CARGO"].", "."C.P.F. n°".$dados_minuta['REPRESENTANTE_2']["CPF"]
                .", e-mail ".$dados_minuta["REPRESENTANTE_2"]["EMAIL"].", telefone ".$dados_minuta["REPRESENTANTE_2"]["TELEFONE"];          
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["REPRESENTANTE"]['REPRESENTANTE_2'],$add_texto,$texto);                       
            }else{
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["REPRESENTANTE"]['REPRESENTANTE_2'],",",$texto);
            } 

            //RESPONSÁVEL LEGAL 
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["REPRESENTANTE"],$dados_minuta["REPRESENTANTE"],$texto);           
            //CONTATOS FINANCEIRO      
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["CONTATO"]['CONTATO_FINANCEIRO'],$dados_minuta["CONTATO_FINANCEIRO"]["NOME"],$texto);
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["CONTATO"]['CONTATO_FINANCEIRO/EMAIL'],$dados_minuta["CONTATO_FINANCEIRO"]["EMAIL"],$texto);     
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["CONTATO"]['CONTATO_FINANCEIRO/TELEFONE'],$dados_minuta["CONTATO_FINANCEIRO"]["TELEFONE"],$texto);
            
            //CONTATOS FINANCEIRO 2
            if(isset($dados_minuta["CONTATO_FINANCEIRO"]["CONTATO_FINANCEIRO_2"])){
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["CONTATO"]['CONTATO_FINANCEIRO_2'],$dados_minuta["CONTATO_FINANCEIRO"]["CONTATO_FINANCEIRO_2"],$texto);
            }
        
            //CONTATO RESPONSAVEL 
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["CONTATO"]['CONTATO_RESPONSAVEL/NOME'], $dados_minuta["CONTATO_RESPONSAVEL"]["NOME"],$texto);
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["CONTATO"]['CONTATO_RESPONSAVEL/EMAIL'], $dados_minuta["CONTATO_RESPONSAVEL"]["EMAIL"],$texto);
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["CONTATO"]['CONTATO_RESPONSAVEL/TELEFONE'], $dados_minuta["CONTATO_RESPONSAVEL"]["TELEFONE"],$texto);        
            //TESTEMUNHAS
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]['TESTEMUNHA'],$dados_minuta["TESTEMUNHA"]["NOME"],$texto);
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]['TESTEMUNHA_EMAIL'],$dados_minuta["TESTEMUNHA"]["EMAIL"],$texto);     
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]['TESTEMUNHA_CPF'],$dados_minuta["TESTEMUNHA"]["CPF"],$texto);
            //TESTEMUNHAS CM
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]['TESTEMUNHA_CMSW'],$dados_minuta["TESTEMUNHA_CM"]["NOME"],$texto);
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]['TESTEMUNHA_CMSW/CPF'],$dados_minuta["TESTEMUNHA_CM"]["CPF"],$texto);     
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["CONTATO"]["TESTEMUNHAS"]['TESTEMUNHA_CMSW/EMAIL'],$dados_minuta["TESTEMUNHA_CM"]["EMAIL"],$texto);

            //EMPRESA C&M
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["C&M"]["CM_SOFTWARE"],$dados_minuta["FATURAMENTO"]["CM"],$texto);
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["C&M"]["CM_SOFTWARE_CNPJ"],$dados_minuta["FATURAMENTO"]["CM_CNPJ"],$texto);

            if(isset($dados_minuta["FATURAMENTO"]["PACOTE"])){
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PACOTE"],$dados_minuta["FATURAMENTO"]["PACOTE"],$texto);
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PACOTE_EXTENSO"],$dados_minuta["FATURAMENTO"]["PACOTE_EXTENSO"],$texto);
            }

            $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["CORTE_FATURAMENTO"],$dados_minuta["FATURAMENTO"]["CORTE_FATURAMENTO"],$texto);
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["CORTE_FATURAMENTO_EXTENSO"],$dados_minuta["FATURAMENTO"]["CORTE_FATURAMENTO_EXTENSO"],$texto);
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PRAZO_PAGAMENTO"],$dados_minuta["FATURAMENTO"]["PRAZO_PAGAMENTO"],$texto);
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PRAZO_PAGAMENTO_EXTENSO"],$dados_minuta["FATURAMENTO"]["PRAZO_PAGAMENTO_EXTENSO"],$texto);
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PRIMEIRO_FATURAMENTO"],$dados_minuta["FATURAMENTO"]["PRIMEIRO_FATURAMENTO"],$texto);

            // $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["IMPLANTACAO_TEXTO"],$dados_minuta["FATURAMENTO"]["IMPLANTACAO_TEXTO"],$texto);
            // $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PRIMEIRO_FATURAMENTO_EXTENSO"],$dados_minuta["FATURAMENTO"]["PRIMEIRO_FATURAMENTO_EXTENSO"],$texto);        
        
            //PACOTE ENGINE
            if(isset($dados_minuta["FATURAMENTO"]["TRANSACOES_ENGINE"])){
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["TRANSACOES_ENGINE"],$dados_minuta["FATURAMENTO"]["TRANSACOES_ENGINE"],$texto);
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["TRANSACOES_ENGINE_EXTENSO"],$dados_minuta["FATURAMENTO"]["TRANSACOES_ENGINE_EXTENSO"],$texto);
            }       
            //ASSESSORIA STR        
            if(isset($dados_minuta["FATURAMENTO"]["ASSESSORIA_STR"])){
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["ASSESSORIA_STR"],$dados_minuta["FATURAMENTO"]["ASSESSORIA_STR"],$texto);
            }
            //ASSESSORIA BACEN        
            if(isset($dados_minuta["FATURAMENTO"]["ASSESSORIA_BACEN"])){
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["ASSESSORIA_BACEN"],$dados_minuta["FATURAMENTO"]["ASSESSORIA_BACEN"],$texto);
            }
            //ASSESSORIA PIX
            if(isset($dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"])){
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["ASSESSORIA_PIX"],$dados_minuta["FATURAMENTO"]["ASSESSORIA_PIX"],$texto); 
            }
            //HORA HOMEM
            if(isset($dados_minuta["FATURAMENTO"]["HORA_HOMEM"])){
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["HORA_HOMEM"],$dados_minuta["FATURAMENTO"]["HORA_HOMEM"],$texto);
            }
            if(isset($dados_minuta["VALORES"]["PACOTE_FULL"])){
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["VALORES"]["FULL"]["PACOTE_FULL_STR"],$dados_minuta["VALORES"]["PACOTE_FULL"],$texto);
            }
            if(isset( $dados_minuta["VALORES"]["VALORES_BASE_TARIFACAO"])){
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["VALORES"]["FULL"]["VALORES_BASE_TARIFACAO"], $dados_minuta["VALORES"]["VALORES_BASE_TARIFACAO"],$texto);
            }
            if(isset($dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS"])){
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_JUROS"], $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS"],$texto);
            }
            if(isset($dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"])){
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"], $dados_minuta["FATURAMENTO"]["PERCENTUAL_JUROS_EXTENSO"],$texto);
            }
            if(isset($dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA"])){
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_MULTA"], $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA"],$texto);
            }
            if(isset($dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"])){
                $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"], $dados_minuta["FATURAMENTO"]["PERCENTUAL_MULTA_EXTENSO"],$texto);
            }       
        
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["VIGENCIA_CONTRATO"],$dados_minuta["FATURAMENTO"]["VIGENCIA_CONTRATO"],$texto);
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["VIGENCIA_CONTRATO_EXTENSO"],$dados_minuta["FATURAMENTO"]["VIGENCIA_CONTRATO_EXTENSO"],$texto);
            $texto = str_replace($dicionario["DICIONARIO_TAG"]["FATURAMENTO"]["INDICE_REAJUSTE"],$dados_minuta["FATURAMENTO"]["INDICE_REAJUSTE"],$texto);
            
            return $texto; 
        }

        function uploadSing( $id_contrato ){
            try{
                if(!isset($id_contrato) || empty($id_contrato)){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $id_contrato;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Erro parâmetros";
                    throw new Exception (json_encode($retorno), 1);
                }

                $get_documento = json_decode( $this->proposta_model->gedDocumentoAnexoIf( $id_contrato, "minuta") );
                if(!isset($get_documento)){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $this->parametros;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Erro em obter ged documento";
                    throw new Exception (json_encode($retorno), 1);
                }else{
                    $documento = $get_documento[0];
                }   
                
                $retorno_sing = $this->obj_sign->upload( $documento );	           
                if(isset($retorno_sing) && $retorno_sing->codigo === 0){
                    $insert['id_ged_anexo'] = $get_documento[0]->id_ged_anexo;
                    $insert['document_key'] = $retorno_sing->output->uuid;
                    $insert['data_upload']  = $this->data_atual->format('Y-m-d H:i:s');
                    $insert['plataforma']   = "d4sign";
                    $this->proposta_model->setTable( 'ged_clicksign_documento' );
                    $save_sign = $this->proposta_model->save($insert);				
                    if($save_sign){
                        $retorno_anexo = json_decode( $this->anexarDocumentosUpload( $id_contrato, $get_documento[0]->id_ged_anexo ) );
                        if(isset( $retorno_anexo ) && $retorno_anexo->codigo == 0 ){
                            $add_sing = json_decode( $this->addSing( $id_contrato, $get_documento ) );
                            if( isset( $add_sing ) && $add_sing->codigo == 0 ){
                                $doc_webhook = json_decode( $this->cadastrarWebhook( $id_contrato ) );
                                if(isset($doc_webhook) && $doc_webhook->codigo == 0){
                                    $retorno['codigo']   = 0;
                                    $retorno['output']   = null;
                                    $retorno['mensagem'] = "Sucesso";
                                    throw new Exception (json_encode($retorno), 1);
                                }else{
                                    throw new Exception (json_encode($doc_webhook), 1);
                                }
                            }else{
                                throw new Exception ( json_encode( $add_sing ), 1 );
                            }
                        }else{
                            $retorno['codigo']   = 1;
                            $retorno['input']    = $retorno_anexo->input;
                            $retorno['output']   = $retorno_anexo->output;
                            $retorno['mensagem'] = $retorno_anexo->mensagem;
                            throw new Exception (json_encode($retorno), 1);
                        }
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $this->parametros;
                        $retorno['output']   = $this->proposta_model->info;
                        $retorno['mensagem'] = "Erro ao salvar no GED";
                        throw new Exception (json_encode($retorno), 1);
                    }
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $retorno_sing->input; 				
                    $retorno['output']   = $retorno_sing->output;
                    $retorno['mensagem'] = $retorno_sing->mensagem;
                    throw new Exception (json_encode($retorno), 1);
                }								
            }catch(Exception $e) {
                return $e->getMessage();
            }
        }

        function anexarDocumentosUpload( $id_objeto = null, $id_origem = null ){
            try{
                $if_contrato = json_decode($this->proposta_model->getIfContrato($id_objeto));
                if(isset($if_contrato) && !empty($if_contrato)){
                    $proposta = json_decode($this->proposta_model->getPropostas($if_contrato[0]->id_proposta));			
                    if(isset($proposta) && !empty($proposta)){
                        if($proposta[0]->codigo == "RCK0001"){
                            $doc = json_decode($this->proposta_model->gedDocumentoAnexo2($id_objeto));
                            if(isset($doc) && !empty($doc)){
                                foreach ($doc as $key => $value) {
                                    if($value->doc_origem == "customizacao"){
                                        $doc_customizacao = $value;
                                    }
                                }
                            }						
                        }
                    
                        $doc_proposta = json_decode($this->proposta_model->gedDocumentoAnexo2( $id_objeto, "minuta") );
                        if(isset($doc_proposta) && !empty($doc_proposta)){
                            $doc_proposta = $doc_proposta[0];
                        }					
                        $path_politica = PATH_POLITICA_CM;					
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $id_objeto; 				
                        $retorno['output']   = null;
                        $retorno['mensagem'] = "Erro ao obter proposta";
                        throw new Exception (json_encode($retorno), 1);
                    }
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $id_objeto; 				
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Erro ao obter contrato";
                    throw new Exception (json_encode($retorno), 1);
                }
                
                $documento_click = json_decode( $this->proposta_model->gedClicksign( $id_origem) );			
                if(!isset($documento_click) || empty($documento_click)){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $id_objeto; 				
                    $retorno['output']   = $id_origem;
                    $retorno['mensagem'] = "Erro ao obter key documento";
                    throw new Exception (json_encode($retorno), 1);
                }
                
                if(isset($doc_customizacao) && !empty($doc_customizacao)){
                    $retorno_sing = $this->obj_sign->anexarDocumento($doc_customizacao,$documento_click[0]->document_key);
                    if(isset($retorno_sing) && $retorno_sing['codigo'] == 1){
                        throw new Exception (json_encode($retorno_sing), 1);
                    }
                }
                
                if(isset($doc_proposta) && !empty($doc_proposta)){
                    $retorno_sing = $this->obj_sign->anexarDocumento($doc_proposta,$documento_click[0]->document_key,null);               
                    if(isset($retorno_sing) && $retorno_sing['codigo'] == 1){
                        throw new Exception (json_encode($retorno_sing), 1);
                    }
                }	

                if(isset($path_politica) && !empty($path_politica)){
                    $retorno_sing = $this->obj_sign->anexarDocumento(null,$documento_click[0]->document_key, $path_politica );
                    if(isset($retorno_sing) && $retorno_sing['codigo'] == 1){
                        throw new Exception (json_encode($retorno_sing), 1);
                    }
                }
                
                $retorno['codigo']   = 0;
                $retorno['input']    = $id_objeto; 				
                $retorno['output']   = $id_origem;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception (json_encode($retorno), 1);		
            }catch( Exception $e ){
                return $e->getMessage();
            }
        }
        
        function addSing( $id_doc, $documento = null ){
            try{
                if( !$id_doc ){
                    $retorno['codigo']   = 1;
                    $retorno['mensagem'] = "Informe o ID do documento";
                    throw new Exception (json_encode($retorno), 1);	
                }

                if( !isset( $documento->documento_key ) ){
                    $documento = json_decode( $this->proposta_model->gedClicksign( null, $id_doc ) );
                }
                
                if(!isset( $documento ) || empty( $documento )){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $this->parametros;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Erro documento key";
                    throw new Exception ( json_encode( $retorno ), 1 );	
                }else{
                    $documento_key = $documento[0];
                }			
                        
                $ordem_assinatura = $this->obj_assinatura->getAssinaturasDocumento( $id_doc );
                if( !isset( $ordem_assinatura ) || empty( $ordem_assinatura )){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $this->parametros;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Erro em obter contato do assinante";
                    throw new Exception (json_encode($retorno), 1);
                }else{
                    $contador = 1;
                    $this->proposta_model->setTable("ged_clicksign_assinatura");	
                    $data_prazo = $this->data_atual->modify('+90 days');	
                    foreach ( $ordem_assinatura as $key => $value ) {
                        $insert['email_assinatura'] = $value->email;
                        switch ( strtoupper( $value->origem ) ) {
                            case 'SIGN_CM':
                                switch ( strtoupper( $value->tipo_contato ) ) {
                                    case 'TESTEMUNHA':
                                    case 'TESTEMUNHA_2':
                                    case 'JURIDICO':
                                        $insert['metodo_assinatura']  = "email";
                                        $insert['tipo_assinatura']    = 5;
                                        $insert['ordem_assinatura']   = 1;
                                        $insert['enviar_assinatura']  = "sim";
                                    break;
                                    case 'RESPONSAVEL LEGAL':
                                    case 'RESPONSAVEL_LEGAL':
                                        $insert['metodo_assinatura']  = "email";
                                        $insert['tipo_assinatura']    = 4;
                                        $insert['ordem_assinatura']   = 1;
                                        $insert['enviar_assinatura']  = "sim";
                                    break;
                                    default:
                                        $insert['metodo_assinatura']  = "email";
                                        $insert['tipo_assinatura']    = 1;
                                        $insert['ordem_assinatura']   = 1;
                                        $insert['enviar_assinatura']  = "sim";   
                                    break;
                                }
                            break;
                            case 'MINUTA':
                                switch ( strtoupper( $value->tipo_contato ) ) {
                                    case 'TESTEMUNHA':
                                    case 'TESTEMUNHA_2':
                                        $insert['metodo_assinatura']  = "email";
                                        $insert['tipo_assinatura']    = 5;
                                        $insert['ordem_assinatura']   = 1;
                                        $insert['enviar_assinatura']  = "sim";
                                    break;
                                    case 'JURIDICO':
                                        $insert['metodo_assinatura']  = "email";
                                        $insert['tipo_assinatura']    = 2;
                                        $insert['ordem_assinatura']   = 1;
                                        $insert['enviar_assinatura']  = "sim";
                                    break;
                                    case 'RESPONSAVEL LEGAL':
                                    case 'RESPONSAVEL_LEGAL':
                                        $insert['metodo_assinatura']  = "email";
                                        $insert['tipo_assinatura']    = 4;
                                        $insert['ordem_assinatura']   = 1;
                                        $insert['enviar_assinatura']  = "sim";
                                    break;
                                    default:
                                        $insert['metodo_assinatura']  = "email";
                                        $insert['tipo_assinatura']    = 1;
                                        $insert['ordem_assinatura']   = 1;
                                        $insert['enviar_assinatura']  = "sim";   
                                    break;
                                }
                            break;
                            default:
                                $insert['metodo_assinatura']  = "email";
                                $insert['tipo_assinatura']    = 1;
                                $insert['ordem_assinatura']   = 1;
                                $insert['enviar_assinatura']  = "sim";   
                            break;
                        }

                        $set_param = $this->obj_sign->setParam( $insert );
                        if( $set_param === false ){
                            $retorno['codigo']   = 1;
                            $retorno['input']    = $this->parametros;
                            $retorno['output']   = null;
                            $retorno['mensagem'] = "Erro ao setar parâmetros";
                            throw new Exception (json_encode($retorno), 1);
                        }

                        $add_sing = $this->obj_sign->addSignatario( $documento_key->document_key );
                        if(!$add_sing){
                            $retorno['codigo']   = 1;
                            $retorno['input']    = $this->parametros;
                            $retorno['output']   = $add_sing;
                            $retorno['mensagem'] = "Erro API";
                            throw new Exception (json_encode($retorno), 1);												
                        }else{
                            $tipo_assinatura                     = $insert['tipo_assinatura'];
                            $insert_ged['id_ged_anexo']  		 = $documento[0]->id_ged_anexo;
                            $insert_ged['id_usuario']    		 = $value->id;
                            $insert_ged['plataforma']    		 = "d4sign";
                            $insert_ged['key_usuario']   		 = $add_sing->output->message[0]->key_signer;
                            $insert_ged['key_documento'] 		 = $documento[0]->document_key;
                            $insert_ged['assinar_como']  		 = $this->obj_sign->lista_tipos_assinatura[ $tipo_assinatura ];
                            $insert_ged['metodo_assinatura']  	 = "email";
                            $insert_ged['ordem_assinatura'] 	 = $contador;  
                            $insert_ged['status'] 				 = 'pendente'; 
                            $insert_ged['prazo_assinatura'] 	 = $data_prazo->format("Y-m-d");		
                            $insert_ged['request_signature_key'] = 0;		
                            $save_assinatura = $this->proposta_model->save( $insert_ged );
                            if(!$save_assinatura){
                                $retorno['codigo']   = 1;
                                $retorno['input']    = $this->parametros;
                                $retorno['output']   = $this->proposta_model->info;
                                $retorno['mensagem'] = "Erro ao salvar informação no BD ged_clicksign_assinatura";
                                throw new Exception (json_encode($retorno), 1);	
                            }
                            $contador++;						
                        }
                    }

                    $dados['skip_email'] = 0;
                    $dados['workflow']   = 1;
                    $dados['message']    = "Segue documento para assinatura.";	
                    $enviar_ass = $this->obj_sign->enviarParaAssinatura( $documento_key, $dados );	
                    if(isset($enviar_ass) && !empty($enviar_ass)){
                        $retorno['codigo']   = 0;
                        $retorno['input']    = $dados;
                        $retorno['output']   = $enviar_ass;
                        $retorno['mensagem'] = "Sucesso";
                        throw new Exception (json_encode($retorno), 1);
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $this->parametros;
                        $retorno['output']   = null;
                        $retorno['mensagem'] = "Erro em enviar para assinatura";
                        throw new Exception (json_encode($retorno), 1);
                    }
                    
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $this->parametros;
                    $retorno['mensagem'] = "Erro unknow 844";
                    throw new Exception (json_encode($retorno), 1);
                }						
            }catch(Exception $e){
                return $e->getMessage();
            }
        }
        
        function cadastrarWebhook( $id_origem ){
            try{
                $key_doc = json_decode( $this->proposta_model->gedClicksign( null, $id_origem ) );
                if( !isset( $key_doc ) || empty( $key_doc) ){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $webhook;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Erro em obter documento key";
                    throw new Exception (json_encode($retorno), 1);
                }else{
                    $doc_key = $key_doc[0]->document_key;
                }
            
                $return = $this->obj_sign->webhook( $doc_key );			
                if( $return === false ){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $doc_key;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Erro ao cadastrar webhook";
                    throw new Exception (json_encode($retorno), 1);
                }else{
                    $retorno['codigo']   = 0;
                    $retorno['input']    = $doc_key;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Sucesso cadastrar webhook";
                    throw new Exception (json_encode($retorno), 1);
                }
            }catch(Exception $e){
                return $e->getMessage();
            }
        }

        function listWebhook(){
            try{       
                // $get_contrato = json_decode($this->proposta_model->getIfContratoCrystal(null,$cnpj));
                // if(!isset($get_contrato) || empty($get_contrato)){
                //     $retorno['codigo']   = 1;
                //     $retorno['input']    = $webhook;
                //     $retorno['output']   = null;
                //     $retorno['mensagem'] = "Erro em obter contrato";
                //     throw new Exception (json_encode($retorno), 1);
                // }

                // $key_doc = json_decode($this->proposta_model->gedClicksign(null,$get_contrato[0]->id));
                // if(!isset($key_doc) || empty($key_doc)){
                //     $retorno['codigo']   = 1;
                //     $retorno['input']    = $webhook;
                //     $retorno['output']   = null;
                //     $retorno['mensagem'] = "Erro em obter documento key";
                //     throw new Exception (json_encode($retorno), 1);
                // }else{
                //     $doc_key = $key_doc[0]->document_key;
                // }

                $doc_key = "8d3a5724-7402-4af8-a98f-7c95a4644a0b";          
                $return = $this->obj_sign->listWebhook($doc_key);			
                if($return === false){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $doc_key;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Erro rm listar webhook";
                    throw new Exception (json_encode($retorno), 1);
                }else{
                    $retorno['codigo']   = 0;
                    $retorno['input']    = $doc_key;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Sucesso em listar webhook";
                    throw new Exception (json_encode($retorno), 1);
                }
            }catch(Exception $e){
                return $e->getMessage();
            }
        }
    }