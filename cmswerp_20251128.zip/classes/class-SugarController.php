<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 17/10/2016
 * Time: 17:21
 */

class SugarController{

    protected $usuario;

    protected $senha;

    protected $url;

    protected $parameters;

    protected $session_id;

    function __construct()
    {
        date_default_timezone_set('America/Sao_Paulo');
        $this->setConfig();
    }

    function setConfig(array $param = null){

        if($param){

            $this->usuario = $param['usuario'];
            $this->senha = $param['senha'];
            $this->url = $param['url'];

        }else{

            $this->usuario = 'system.operator';
            $this->senha = 'Ju290381';
            $this->url = 'http://localhost/sugarcrm/service/v4_1/rest.php';

        }

        $this->login();
    }

    function login(){

        $login_parameters = array(
            "user_auth" => array(
                "user_name" => $this->usuario,
                "password" => md5($this->senha),
                "version" => "1"
            ),
            "application_name" => "RestTest",
            "name_value_list" => array(),
        );

        $login_result = $this->call('login',$login_parameters, $this->url);
        $this->session_id = $login_result->id;
    }

    function getListAccounts( $type = null ){

        if($this->session_id){

            $get_entry_list_parameters = array(

                //session id
                'session' => $this->session_id,

                //The name of the module from which to retrieve records
                'module_name' => 'Accounts',

                //The SQL WHERE clause without the word "where".
                'query' => "",

                //The SQL ORDER BY clause without the phrase "order by".
                'order_by' => "",

                //The record offset from which to start.
                'offset' => '0',

                //Optional. A list of fields to include in the results.
                'select_fields' => array(
                    'id',
                    'name',
                    'cnpj_c',
                    'phone_office',
                    'billing_address_postalcode'
                ),

                /*
                A list of link names and the fields to be returned for each link name.
                Example: 'link_name_to_fields_array' => array(array('name' => 'email_addresses', 'value' => array('id', 'email_address', 'opt_out', 'primary_address')))
                */
                'link_name_to_fields_array' => array(
                ),

                //The maximum number of results to return.
                'max_results' => '50',

                //To exclude deleted records
                'deleted' => '0',

                //If only records marked as favorites should be returned.
                'Favorites' => false,
            );

            return $this->call('get_entry_list', $get_entry_list_parameters, $this->url);

        }else{
            return false;
        }
    }

    function getListRepresentantes( $type = null, $where = null ){

        if($this->session_id){

            $get_entry_list_parameters = array(

                //session id
                'session' => $this->session_id,

                //The name of the module from which to retrieve records
                'module_name' => 'gochk_representante',

                //The SQL WHERE clause without the word "where".
                'query' => $where,

                //The SQL ORDER BY clause without the phrase "order by".
                'order_by' => "",

                //The record offset from which to start.
                'offset' => '0',

                //Optional. A list of fields to include in the results.
                'select_fields' => array(
                    'id',
                    'name',
                    'title',
                    'cnpj',
                    'email',
                    'nome_contato',
                ),

                /*
                A list of link names and the fields to be returned for each link name.
                Example: 'link_name_to_fields_array' => array(array('name' => 'email_addresses', 'value' => array('id', 'email_address', 'opt_out', 'primary_address')))
                */
                'link_name_to_fields_array' => array(
                ),

                //The maximum number of results to return.
                'max_results' => '50',

                //To exclude deleted records
                'deleted' => '0',

                //If only records marked as favorites should be returned.
                'Favorites' => false,
            );

            return $this->call('get_entry_list', $get_entry_list_parameters, $this->url);

        }else{
            return false;
        }
    }

    function getRecordsRelated($beanName, $idBean, $beanRel, $paramBean = null, $paramRel = null){

        if($this->session_id){

            //retrieve related list ------------------------------
            $get_relationships_parameters = array(

                'session' => $this->session_id,

                //The name of the module from which to retrieve records.
                'module_name' => $beanName, //'gochk_representante',

                //The ID of the specified module bean.
                'module_id' => $idBean,

                //The relationship name of the linked field from which to return records.
                'link_field_name' => $beanRel, //'gochk_representante_accounts_1',

                //The portion of the WHERE clause from the SQL statement used to find the related items.
                'related_module_query' => '',

                //The related fields to be returned.
                'related_fields' => $paramBean,

                //For every related bean returned, specify link field names to field information.
                'related_module_link_name_to_fields_array' => $paramRel,

                //To exclude deleted records
                'deleted'=> '0',

                //order by
                'order_by' => '',

                //offset
                'offset' => 0,

                //limit
                'limit' => 5,
            );

            return $this->call('get_relationships', $get_relationships_parameters, $this->url);

        }else{
            return false;
        }

    }

    function getBeanById($beanName, $beanId, $param = null, $paramRel = null){

        if($this->session_id)
        {

            $get_entries_parameters = array(

                //session id
                'session' => $this->session_id,

                //The name of the module from which to retrieve records
                'module_name' => $beanName,

                //An array of SugarBean IDs
                'ids' => $beanId,

                //Optional. The list of fields to be returned in the results
                'select_fields' => $param,

                //A list of link names and the fields to be returned for each link name
                'link_name_to_fields_array' => $paramRel,
            );

            return $get_entries_result = $this->call("get_entries", $get_entries_parameters, $this->url);
        }
        else
        {
            return false;
        }
    }

    function saveRelationship($module, $module_id, $link_field_name, $related_ids, $name_value_list)
    {
        $set_relationship_parameters = array(
                //session id
                'session' => $this->session_id,

                //The name of the module.
                'module_name' => $module,

                //The ID of the specified module bean.
                'module_id' => $module_id,

                //The relationship name of the linked field from which to relate records.
                'link_field_name' => $link_field_name,

                //The list of record ids to relate
                'related_ids' => $related_ids,

                //Sets the value for relationship based fields
                'name_value_list' => $name_value_list,

                //Whether or not to delete the relationship. 0:create, 1:delete
                'delete'=> 0,
        );

        $set_relationship_result = $this->call("set_relationship", $set_relationship_parameters);
    }


    function saveRecord($bean, $param, $id = null)
    {
        if($id)
        {
            $param[] = array('name'=>'id', 'value'=>$id);
        }

        //create account ------------------------------------- 
        $set_entry_parameters = array(
            //session id
            "session" => $this->session_id,

            //The name of the module from which to retrieve records.
            "module_name" => $bean,

            //Record attributes
             "name_value_list" => $param,
        );

        $set_entry_result = $this->call("set_entry", $set_entry_parameters);
        return $set_entry_result;
    }

    function call($method, $parameters, $url = null)
    {
        if(!$url)
        {
            $url = $this->url;
        }

        ob_start();
        $curl_request = curl_init();

        curl_setopt($curl_request, CURLOPT_URL, $url);
        curl_setopt($curl_request, CURLOPT_POST, 1);
        curl_setopt($curl_request, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
        curl_setopt($curl_request, CURLOPT_HEADER, 1);
        curl_setopt($curl_request, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curl_request, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl_request, CURLOPT_FOLLOWLOCATION, 0);

        $jsonEncodedData = json_encode($parameters);

        $post = array(
            "method" => $method,
            "input_type" => "JSON",
            "response_type" => "JSON",
            "rest_data" => $jsonEncodedData
        );

        curl_setopt($curl_request, CURLOPT_POSTFIELDS, $post);
        $result = curl_exec($curl_request);
        curl_close($curl_request);

        $result = explode("\r\n\r\n", $result, 2);
        $response = json_decode($result[1]);
        ob_end_flush();

        return $response;
    }
}