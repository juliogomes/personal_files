<?php
	/**
	* Julio
	* Classe para log de eventos no sistema
	*/
	class Tarifador extends Main{
		protected 
			$origem,
			$mq,
			$obj_msg,
			$fmsg,
			$obj_fmsg,
			$obj_movimento,
			$obj_contrato,
			$obj_lp,
			$obj_email,
			$dados_contrato,
			$notificacoes,
			$tarifacao;
			
		function __construct($controller, $origem = 'mq'){
			$this->origem = $origem;
			parent::__construct($controller);
			// Objeto com acesso a base de dados de cadastros;
			$db_movimento['db_name'] = DB_NAME_MOVIMENTO;
			if( $origem == 'mq' ){
				$this->setMq();
			}
			$this->controller->load_model('contratos/contratos');
			$this->obj_contrato  = $this->controller->getModel();
			$this->obj_lp        = $this->controller->load_model('lista-precos/lista-precos', true);
			$this->obj_email     = new Email();
			$this->notificacoes  = new Notificacoes($controller);
			// Objeto com acesso a base de dados de movimento diario;
			$controller          = new MainController(null, 'tarifador', false);
			$this->obj_movimento = $controller->load_model('movimento/movimento', true);
			$this->obj_movimento->setDb( new Db( $db_movimento ) );
		}

		function spendQueue(){
			$this->mq->spendQueue();
		}
		
		function setMq($param = null){
			$this->mq = new Mq($param);
			return $this;
		}

		function setObjMsq($msg_json = null){
			if($this->origem == 'mq'){
				$this->mq->setObjMsq($msg_json);
			}else{
				$this->obj_fmsg = json_decode($this->fmsg);
			}
		}

		function setMsg($msg){
			if($this->origem == 'mq'){
				$this->mq->setMsg($msg);
			}else{
				$this->fmsg = $msg;
			}
		}

		function getMsg(){
			if ( $this->origem == 'mq' ) {
				return $this->mq->getMsg();
			}else{
				return $this->fmsg;
			}
		}

		function getObjMsg(){
			if ($this->origem == 'mq') {
				return $this->mq->getObjMsg();
			}else{
				return $this->obj_fmsg;
			}
		}

		function setJsonRewrite($dados_mq, $tipo = 'tarifacao'){
			if(isset($dados_mq->produto) && $dados_mq->produto == 'SPBALL'){
				$rewrite = New RewriteJson();
				$retorno = json_decode($this->obj_contrato->clientesPorCodigo($dados_mq->ispb));
				foreach ($retorno as $key => $value){
					switch ($value->codigo_produto){
						case 'SPB0001':
						case 'SPI0001':
						case 'SOE0001':
						case 'FSP0001':
							$rewrite->setJson($dados_mq);
							$rewrite->setCodigo($value->codigo_produto);
							if($tipo == 'tarifacao'){
								if(!isset($dados_mq->modulo) || empty($dados_mq->modulo)){
									$this->alerta( $dados_mq, 'MODULO NAO INFORMADO MSG TARIFADOR COD 105' );
								}
								if((isset($dados_mq->modulo) && !empty($dados_mq->modulo)) &&
								($dados_mq->modulo == 'MEL0023' || $dados_mq->modulo == 'MEL0024'))
								{
									$this->obj_msg = $rewrite->RewriteMqEspecial();
								}else{
									$this->obj_msg = $rewrite->RewriteMqDefault();
								}
							}else{
								$this->obj_msg = $rewrite->RewriteMqDefault();
							}
						break;
					}
				}
			}else{
			    switch ($dados_mq->modulo) {
    				case 'COR0017':
    				case 'COR0018':
    				case 'COR0019':
    				case 'COR0020':
    				case 'COR0021':
    				case 'COR0022':
    				case 'COR0023':
    				case 'COR0024':
    					$rewrite = new RewriteJson();
    					$rewrite->setJson($dados_mq);
    					$rewrite->setCodigo($dados_mq->produto);
    					if ($tipo == 'tarifacao') {
    						$this->obj_msg = $rewrite->RewriteMqEspecial();
    						echo '<pre>';
						    var_dump($this->obj_msg);
						    echo '</pre>';
    						if ($this->obj_msg->erro_msg) {
    							$this->alerta($dados_mq, $this->obj_msg->erro_msg);
    						}
    					}
    				break;
    				default:
    					$this->obj_msg = $dados_mq;
    				break;
    			}
			}
		}

		function setDadosContrato( $dados_mq ){
			$this->dados_contrato = json_decode( $this->obj_contrato->getContratosAndProdutosAndModulos( $dados_mq->ispb, $dados_mq->produto, $dados_mq->modulo ) );
			if( $this->dados_contrato ){
				return true;
			}else{
				return false;
			}
		}

		function exec(){
			$dados_mq = $this->getObjMsg();
			if( $dados_mq ){
				if( isset( $dados_mq->comando ) && $dados_mq->comando == 'status' ){
					$retorno['comando']  = $dados_mq->comando;
					$retorno['ispb'] 	 = $dados_mq->ispb;
					$retorno['produto']  = $dados_mq->produto;
					if( $dados_mq->produto == 'SPBALL' ){
						$contratos = $this->dados_contrato = json_decode($this->obj_contrato->getContratosAndProdutos( $dados_mq->ispb ) );
						if( $contratos ){
							foreach ( $contratos as $key => $value ) {
								switch ( $value->codigo_produto ) {
									case 'SOE0001':
									case 'SBP0001':
									case 'SPI0001':
									case 'FSP0001':
										$retorno['produto'] 		= $value->codigo_produto;
										$retorno['status_contrato'] = $value->status;
									break;
								}
							}

							if( !isset( $retorno['status_contrato'] ) || empty( $retorno['status_contrato'] ) ){
								$retorno['status_contrato'] = 'nenhum contrato encontrado do grupo SPBALL';
							}
						}else{
							$retorno['status_contrato'] = 'nenhum contrato encontrado';
						}
					}else{
						$contratos = $this->dados_contrato = json_decode($this->obj_contrato->getContratosAndProdutos( $dados_mq->ispb, $dados_mq->produto) );
						if($contratos){
							$retorno['status_contrato'] = $contratos[0]->status;
						}else{
							$retorno['status_contrato'] = 'nenhum contrato encontrado';
						}
					}
					$msg_status = json_encode( $retorno );
					$this->mq->putQueue( $msg_status, null );
				}else{
					$this->setJsonRewrite( $this->getObjMsg() );
					if( !isset( $dados_mq->comando ) || empty( $dados_mq->comando ) ){
						$this->alerta( $dados_mq, 'COMANDO NÂO INFORMADO' );
					}
					
					if( !isset( $dados_mq->ispb ) || empty( $dados_mq->ispb ) ){
						$this->alerta( $dados_mq, 'SPB NÂO INFORMADO');
					}
					
					if( !isset( $dados_mq->produto ) || empty( $dados_mq->produto ) ){
						$this->alerta( $dados_mq, 'PRODUTO NÂO INFORMADO');
					}
					
					if( !isset( $dados_mq->modulo ) || empty( $dados_mq->modulo ) ){
						$this->alerta( $dados_mq, 'MODULO NÂO INFORMADO');
					}
					
					if( !isset( $dados_mq->data ) || empty( $dados_mq->data ) ){
						$this->alerta( $dados_mq, 'DATA DE TARIFACAO NÂO INFORMADO');
					}
					
					if( !isset( $dados_mq->dados ) || empty( $dados_mq->dados ) || empty( $dados_mq->dados->count ) ){
						$this->alerta( $dados_mq, 'DADOS COUNT NÂO INFORMADO OU NULO' ); 
					}
					
					//setando informações de login
					if( empty( $dados_mq->login ) ){
						$this->tarifacao['login'] = 'nao_informado';
					}else{
						$this->tarifacao['login'] = $dados_mq->login;
					}

					//setando informacoes de centro de custo
					if(empty($dados_mq->centro_custo)){
						$this->tarifacao['centro_custo'] = 'nao_informado';
					}else{
						$this->tarifacao['centro_custo'] = $dados_mq->centro_custo;
					}

					//setando informações de valores
					if( isset( $dados_mq->dados->valor_baixa ) ){
						$this->tarifacao['valor'] = ( isset( $dados_mq->dados->valor_baixa) )?$dados_mq->dados->valor_baixa:null;
					}if(isset($dados_mq->dados->valor)){
						$this->tarifacao['valor'] = ( isset( $dados_mq->dados->valor ) )?$dados_mq->dados->valor:null;
					}elseif( isset( $dados_mq->dados->valor_tarifa ) ){
						$this->tarifacao['valor'] = $dados_mq->dados->valor_tarifa;
					}else{
						$this->tarifacao['valor'] = 0;
					}
					
					if(isset($dados_mq->dados->count)){
						$this->tarifacao['qtd_transacoes'] = $dados_mq->dados->count;
					}else{
						$this->tarifacao['qtd_transacoes'] = 1;
					}
					/*
					echo '<pre>';
                    var_dump('COD: 244', $dados_mq);
                    echo '</pre>';
                    exit;
                    */
                    
					// setando dados do contrato
					if( $this->setDadosContrato( $dados_mq ) ){
						$this->tarifacao['id_contrato'] = $this->dados_contrato[0]->id_contrato;
					}else{
						$this->alerta( $dados_mq, 'Contrato não encontrado' );
					}
					/*o '<pre>';
                    var_dump('COD: 254 ', $this->tarifacao);
                    echo '</pre>';
                    exit;
                    */
					if(
						isset($this->dados_contrato[0]->id_contrato)  &&
						!empty($this->dados_contrato[0]->id_contrato) &&
						isset($this->dados_contrato[0]->id_modulo)    &&
						!empty($this->dados_contrato[0]->id_modulo)
					){
						$lista_preco  = json_decode( $this->obj_lp->getLpByCustomer( $this->dados_contrato[0]->id_contrato, $this->dados_contrato[0]->id_modulo ) );
						$pacote_ativo = json_decode( $this->obj_lp->getPacotesByContratos( $this->dados_contrato[0]->id_contrato, $this->dados_contrato[0]->id_modulo ) );
						if( !$lista_preco && !$pacote_ativo ){
						    echo 'Linha 240';
						    $this->alerta( $dados_mq, 'MODULO TARIFADO SEM LISTA DE PREÇO CADASTRADO E SEM PACOTE CONTRATADO COD: 236' );
						}
					}else{
					    echo 'Linha 244';
					    $this->alerta( $dados_mq, json_encode( $this->dados_contrato[0]->id_contrato ) );
					}

					if( !$lista_preco ){
					    echo 'Linha 249';
					    $this->alerta( $dados_mq, 'MODULO TARIFADO SEM LISTA DE PREÇO CADASTRADO' );
					}

					if( !$lista_preco && !$pacote_ativo ){
					    $this->alerta( $dados_mq, 'MODULO TARIFADO SEM LISTA DE PREÇO CADASTRADO E SEM PACOTE CONTRATADO COD: 247' );
					}
					
					$this->tarifacao['mq_json']        = $this->getMsg();
					$this->tarifacao['data_operacao']  = $this->controller->data_hora_atual->format( 'Y-m-d' );
					$this->tarifacao['codigo_cliente'] = $dados_mq->ispb;
					$this->tarifacao['codigo_produto'] = $dados_mq->produto;
					$this->tarifacao['codigo_modulo']  = $dados_mq->modulo;
					$this->tarifacao['data_tarifacao'] = convertDate( $dados_mq->data );
					$this->tarifar();
				}
			}else{
				echo 'Sem mensagens';
				// implementar ação
			}
		}

		function tarifar( $dados = null ){
			if( $dados ){
				$this->tarifacao = convertToObject( $dados );
			}else{
				$this->tarifacao = convertToObject( $this->tarifacao );
			}

			$chk_rel = json_decode( 
				$this->obj_movimento->getRel( 
					$this->tarifacao->codigo_cliente, 
					$this->tarifacao->codigo_modulo, 
					$this->tarifacao->login, 
					$this->tarifacao->centro_custo, 
					$this->tarifacao->data_tarifacao 
				) 
			);
			
			if( isset( $chk_rel[0]->id) && !empty($chk_rel[0]->id ) ){
				$this->tarifacao->id = $chk_rel[0]->id;
				$this->tarifacao->qtd_transacoes += $chk_rel[0]->qtd_transacoes;
				if(isset($chk_rel[0]->valor) && !empty($chk_rel[0]->valor)){
					$this->tarifacao->valor += $chk_rel[0]->valor;
				}else{
					$this->tarifacao->valor += 0;
				}
			}else{
				$this->tarifacao->id = null;
			}

			if( !empty( $this->tarifacao->id ) ){
				$id = $this->tarifacao->id;
				unset($this->tarifacao->id);
				$is_save = $this->obj_movimento->save( $this->tarifacao, $id );
			}else{
				$is_save = $this->obj_movimento->save( $this->tarifacao );
			}
		}

		function alerta( $dados, $mensagem_add = null ){
			$mensagem = null;
			$mensagem .= "<p>O tarifador recebeu transação de um cliente ao qual não está cadastrado no sistema, ou de um modulo que não existe, verifique abaixo as informações: </p>";
			
			$mensagem .= "NSU: ";
			$mensagem .= (isset($dados->nsu))?$dados->nsu:null;
			$mensagem .= "<br>";
			
			$mensagem .= "Codigo Cliente: ";
			$mensagem .= (isset($dados->ispb))?$dados->ispb:null;
			$mensagem .= "<br>";
			
			$mensagem .= "Codigo Produto: ";
			$mensagem .= (isset($dados->produto))?$dados->produto:null;
			$mensagem .= "<br>";
			
			$mensagem .= "Codigo Modulo: ";
			$mensagem .= (isset($dados->modulo))?$dados->modulo:null;
			$mensagem .= "<br>";
			
			$mensagem .= "Data: ";
			$mensagem .= (isset($dados->data))?$dados->data:null;
			$mensagem .= "<br>";
			
			$mensagem .= "Mensagem recebida em: ";
			$mensagem .= (isset($this->controller->data_hora_atual))?$this->controller->data_hora_atual->format('d/m/Y H:i:s'):null;
			$mensagem .= "<br>";
			
			$mensagem .= "Quantidade: ";
			
			if( isset( $dados->dados->count ) ){
				$mensagem .= $dados->dados->count;
			}else{
				$mensagem .= 0;
			}
			$mensagem .= "<br>";
			if( $mensagem_add ){
				$mensagem .= $mensagem_add;
			}
			
			$mensagem .= "<br>";
			/*
			echo '<pre>';
				var_dump(TIPO_AMBIENTE, $mensagem);
			echo '</pre>';
			exit;
			*/
			if( 'producao' == TIPO_AMBIENTE ){
				$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/88437d8ab0ce4053ae3a7188b16d8baa/c8c7ff53-e294-4a3a-bcad-c9f04857e469';
			}else{
				$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/88437d8ab0ce4053ae3a7188b16d8baa/c8c7ff53-e294-4a3a-bcad-c9f04857e469';
			}

			$parametros['tipo_destinatario'] = 'user';
			$parametros['email_to']          = 'julio.gomes@cmsw.com';
			$parametros['mensagem']			 = $mensagem;
			if( $dados->ispb != '99999999' ){
				$send = $this->notificacoes->enviar( 'teams', $parametros );
			}
		}
	}