<?php
	/**
	* Julio
	* Classe para log de eventos no sistema
	*/
	class Tasks extends Main{
        function __construct( $controller){
			parent::__construct( $controller );
		}

        function Exec( $codigo ){
            echo 'Executando codigo: '.$codigo.' <br> '.PHP_EOL;
            try {
                switch ( $codigo ){
                    case 'NFE0001':
                        $obj_fatura      = $this->controller->load_model('faturas/faturas', true);
                        $remessas        = json_decode( $obj_fatura->getGrupoRemessasByStep( $this->data_atual, $this->data_atual, 'criado' ) );
                        if( $remessas ){
                            foreach( $remessas as $key => $value ){
                                $parametros['action'] = 'enviar';
                                $nome_arquivo         = 'rps_'.$value->cnpj_prestador.'_'.$value->numero_remessa.'.txt';
                                $envio_arquivo        = json_decode( $this->obj_faturamento->sendRpsNfe( $value->cnpj_prestador, $value->numero_remessa, $nome_arquivo, $parametros ) );
                                if( $envio_arquivo ){
                                    if( isset( $envio_arquivo->codigo ) && $envio_arquivo->codigo == 0 ){
                                        // logar sucesso
                                    }else{
                                        // logar erro
                                    }
                                }else{
                                    // logar erro
                                }
                            }
                        }else{
                            // log error
                        }
                    break;
                    case 'NFE0002':
                        $obj_fatura = $this->controller->load_model('faturas/faturas', true);
                        $remessas   = json_decode( $obj_fatura->getGrupoRemessasByStep( $this->data_atual, $this->data_atual, 'processando' ) );
                        if( $remessas ){
                            foreach( $remessas as $key => $value ){
                                $status_arquivo = json_decode( $this->obj_faturamento->updateStatusNfe( $value->cnpj_prestador, $value->numero_remessa ) );
                                if( !isset( $status_arquivo->codigo ) || $status_arquivo->codigo != 0 ){
                                    $parametros['tipo_destinatario'] = 'user';
									$parametros['email_to'] 		 = DEFAULT_ALERTA;
									$parametros['mensagem'] 		 = 'Erro ao enviar as verificar status de notas fiscais '.$codigo;
									return $this->notificacoes->enviar( 'teams', $parametros );
                                }
                            }
                        }else{
                            // log error
                        }
                    break;
                    case 'NFE0003':
                        $obj_fatura      = $this->controller->load_model('faturas/faturas', true);
                        $remessas_ok     = json_decode( $obj_fatura->getGrupoRemessasByStep( $this->data_atual, $this->data_atual, 'importado' ) );
                        $remessas_erro   = json_decode( $obj_fatura->getGrupoRemessasByStep( $this->data_atual, $this->data_atual, 'erro' ) );
                        if( $remessas_ok ){
                            foreach( $remessas_ok as $key => $value ){
                                $status_arquivo = json_decode( $this->obj_faturamento->checkRetornoRps( $value->cnpj_prestador, $value->numero_remessa ) );
                                if( !isset( $status_arquivo->codigo ) || $status_arquivo->codigo != 0 ){
                                    $parametros['tipo_destinatario'] = 'user';
									$parametros['email_to'] 		 = DEFAULT_ALERTA;
									$parametros['mensagem'] 		 = 'Erro ao enviar as verificar status de notas fiscais '.$codigo;
									return $this->notificacoes->enviar( 'teams', $parametros );
                                }
                            }
                        }else{
                            // log error
                        }

                        if( $remessas_erro ){
                            foreach( $remessas_erro as $key => $value ){
                                $status_arquivo = json_decode( $this->obj_faturamento->checkRetornoRps( $value->cnpj_prestador, $value->numero_remessa ) );
                                if( isset( $status_arquivo->codigo ) && $status_arquivo->codigo == 0 ){
                                    // logar sucesso
                                }else{
                                    // logar erro
                                }
                            }
                        }else{
                            // log error
                        }
                    break;
                    case 'NFE0004':
                        $nf_model       = $this->controller->load_model('/notas-fiscais/notas-fiscais', true);
                        $notas_vencidas = json_decode( $nf_model->getNotasVencidas() );
                        $dados_nota     = null;
                        if( $notas_vencidas ){
                            foreach ( $notas_vencidas as $key => $value ){
                                if( $value->dias_atraso >= 5 ){
                                    $i1 = $value->id_contrato;
                                    $i2 = $value->id_nf;
                                    $dados_nota[$i1]['contrato']['cliente']       = $value->cliente;
                                    $dados_nota[$i1]['contrato']['codigo_pais']   = $value->codigo_pais;
                                    $dados_nota[$i1]['contrato']['email_contato'] = $value->email_contato;
                                    $dados_nota[$i1]['nf'][$i2]['fatura']        = $value->numero_fatura;
                                    $dados_nota[$i1]['nf'][$i2]['emissao']       = $value->data_emissao;
                                    $dados_nota[$i1]['nf'][$i2]['vencimento']    = $value->data_vencimento;
                                    $dados_nota[$i1]['nf'][$i2]['valor']         = $value->valor_total;
                                }
                            }

                            if( $dados_nota ){
                                foreach( $dados_nota as $key => $value ){
                                    $destinatario = $value['contrato']['email_contato'];
                                    $table        = null;
                                    $msg_inicio   = null;
                                    $msg_final    = null;
                                    $msg_aviso    = null;
                                    $param_envio  = null;
                                    if( str_pad( $value['contrato']['codigo_pais'], 3, '0', STR_PAD_LEFT) != '076' ){
                                        $assunto     = 'Payment Reminder Notification';
                                        $param_envio['email']['email_remetente'] = 'admusa@cmsw.com';
                                        $param_envio['email']['nome_remetente']  = 'Invoice CMSW';
                                        $msg_inicio .= "<p>Dear ".$value['contrato']['cliente']."</p>";
                                        $msg_inicio .= "<p>We hope this message finds you well.</p>";
                                        $msg_inicio .= "<p>We would like to inform you that, as of today, we have not received payment for the following invoice.</p>";
                                        $table .= "
                                            <table border='0'>
                                                <tr bgcolor='#A9A9A9'>
                                                    <th>Invoice</th>
                                                    <th>Issuance date</th>
                                                    <th>Invoice due date</th>
                                                    <th>Amount</th>
                                                </tr>
                                        ";
                                        $msg_final .= "<p>Kindly contact us at admusa@cmsw.com so we can promptly resolve this matter.</p>";
                                        $msg_final .= "<p>If you have already made the payment, please disregard this email.</p>";
                                        $msg_final .= "<p>Thank you in advance for your attention and cooperation.</p>";
                                        $msg_final .= "<p>Best regards,</p>";
                                        $msg_final .= "<p>C&am Software LLC</p>";
                                    }else{
                                        $assunto     = 'Aviso fatura em atraso';
                                        $param_envio['email']['email_remetente'] = null;
                                        $param_envio['email']['nome_remetente']  = null;
                                        $msg_inicio .= "<p>Prezado Cliente ".$value['contrato']['cliente']."</p>";
                                        $msg_inicio .= "<p>Informamos que até a data de hoje não identificamos o pagamento da fatura abaixo. </p>";
                                        $table .= "
                                            <table border='0'>
                                                <tr bgcolor='#A9A9A9'>
                                                    <th>Fatura</th>
                                                    <th>Emissão</th>
                                                    <th>Vencimento</th>
                                                    <th>Valor</th>
                                                </tr>
                                        ";
                                        $msg_final .= "<p>Entre em contato conosco pelo telefone (11) 33652666  administracao@cmsw.com para que possamos solucionar essa pendência.</p>";
                                        $msg_final .= "<p><p>Caso já tenha efetuado o pagamento, por favor, desconsiderar este e-mail.</p><p>Atenciosamente!</p>";
                                    }

                                    foreach ( $value['nf'] as $k1 => $v1 ) {
                                        if( $value['contrato']['codigo_pais'] != '76' ){
                                            $table .= "
                                                <tr>
                                                    <td><b>".$v1['fatura']."</b></td>
                                                    <td><b>".convertDate($v1['emissao'])."</b></td>
                                                    <td><b>".convertDate($v1['vencimento'])."</b></td>
                                                    <td><b>".number_format($v1['valor'], '2', '.', ',')."</b></td>
                                                </tr>
                                            ";
                                        }else{
                                            $table .= "
                                                <tr>
                                                    <td><b>".$v1['fatura']."</b></td>
                                                    <td><b>".convertDate($v1['emissao'])."</b></td>
                                                    <td><b>".convertDate($v1['vencimento'])."</b></td>
                                                    <td><b>".number_format($v1['valor'], '2', ',', '.')."</b></td>
                                                </tr>
                                            ";
                                        }
                                    }
                                    $table     .= "</table>";
                                    $msg_aviso .= $msg_inicio.$msg_final.$table;
                                    $param_envio['email']['destinatario'] = $destinatario;
                                    $param_envio['email']['copia_oculta'] = SYSTEM_NOTIFY_TO;
                                    $param_envio['email']['assunto']      = $assunto;
                                    $param_envio['email']['mensagem']     = $msg_aviso;
                                    if( validar( $destinatario, 'email' ) ){
                                        $is_send = json_decode( $this->notificacoes->sendNotificacao( 'alertas', $param_envio ) );
                                    }else{
                                        // implementar alerta de cliente sem email para enviar alerta
                                    }
                                }
                            }
                        }
                    break;
                    case 'NFE0005':
                        try {
                            $retorno                 = false;
                            $nf_model                = $this->controller->load_model( '/notas-fiscais/notas-fiscais', true );
                            $nfs                     = json_decode( $nf_model->getNfPagaEmAtraso( 5 ) );
                            $db_movimento['db_name'] = DB_NAME_MOVIMENTO;
                            $obj_movimento           = $this->controller->load_model( 'movimento/movimento', true );
                            $obj_movimento->setDb( new Db( $db_movimento ) );
                            if( $nfs ){
                                foreach( $nfs as $key => $value ){
                                    $data_vencimento = getDataAtual( $value->data_vencimento );
                                    $recebido_em     = getDataAtual( $value->recebido_em );
                                    $multaJuros      = json_decode( $this->obj_faturamento->calcMultaJuros( $value->id_contrato, $data_vencimento, $recebido_em, $value->valor_total, true, 5 ) );
                                    if( $multaJuros->codigo == 0 ){
                                        $descricao_multa = "Multa referente a NF com vencimento em ".$data_vencimento->format('d/m/Y')." paga em ".$recebido_em->format('d/m/Y');
                                        $descricao_juros = "Juros referente a NF com vencimento em ".$data_vencimento->format('d/m/Y')." paga em ".$recebido_em->format('d/m/Y');
                                        $padm['id_contrato']    = $value->id_contrato;
                                        $padm['codigo_cliente'] = $value->codigo_cliente;
                                        $padm['codigo_produto'] = 'ADM0001';
                                        $padm['codigo_modulo']  = 'ADM0011';
                                        $padm['valor'] 	 		= $multaJuros->dados->subtotal;
                                        $padm['qtd_transacoes'] = 1;
                                        $padm['centro_custo']  	= 'nao_informado';
                                        $padm['data_tarifacao'] = $this->controller->data_hora_atual->format('Y-m-d');
                                        $padm['data_operacao']  = $this->controller->data_hora_atual->format('Y-m-d');
                                        $padm['tarifavel'] 		= 0;
                                        $padm['flag']  			= 'automatico';
                                        $id_mov_diario          = $obj_movimento->insertMov($padm);
                                        if( $id_mov_diario ){
                                            $param_mda['id_mov_diario']  = $id_mov_diario;
                                            $param_mda['id_contrato']    = $value->id_contrato;
                                            $param_mda['id_produto']     = $value->id_produto;
                                            $param_mda['codigo_produto'] = $value->codigo_produto;
                                            $param_mda['id_modulo'] 	 = 20;
                                            $param_mda['codigo_modulo']  = 'ADM0011';
                                            $param_mda['id_nf_origem']   = $value->id_nota;
                                            $param_mda['valor_base']     = $value->valor_total;
                                            $param_mda['data_tarifacao'] = $this->controller->data_hora_atual->format('Y-m-d');
                                            $param_mda['recebido_em']    = $value->recebido_em;
                                            $param_mda['vencimento_em']  = $value->data_vencimento;
                                            $param_mda['origem']         = 'nota fiscal';
                                            $param_mda['status']         = 'pendente';
                    
                                            $param_mda['tipo']           = 'multa';
                                            $param_mda['valor_calculado']       = $multaJuros->dados->valor_multa;
                                            $param_mda['descricao']             = $descricao_multa;
                                            $save_multa  = $nf_model->insertMovAux($param_mda);
                    
                                            $param_mda['tipo']            = 'juros';
                                            $param_mda['valor_calculado'] = $multaJuros->dados->valor_juros;
                                            $param_mda['descricao']       = $descricao_juros;
                                            $save_juros  = $nf_model->insertMovAux($param_mda);
                    
                                            if( $save_multa ){
                                                echo 'Multa lancada registro: '.$save_multa."\n";
                                            }else{
                                                $retorno['codigo']   = 1;
                                                $retorno['input']    = $nfs;
                                                $retorno['output']   = 'Erro ao lan�ar multa no para o cliente '.$value->razao_social;
                                                $retorno['mensagem'] = 1;
                                                throw new Exception(json_encode($retorno));
                                            }

                                            if( $save_juros ){
                                                echo 'Juros lancado registro: '.$save_juros."\n";
                                            }else{
                                                $retorno['codigo']   = 1;
                                                $retorno['input']    = $nfs;
                                                $retorno['output']   = 'Erro ao lan�ar juros no diario para o cliente '.$value->razao_social;
                                                $retorno['mensagem'] = 1;
                                            }
                                        }else{
                                            $retorno['codigo']   = 1;
                                            $retorno['input']    = $nfs;
                                            $retorno['output']   = 'Erro ao lan�ar multa e juros no movimento diario para o cliente '.$value->razao_social;
                                            $retorno['mensagem'] = 1;
                                        }
                                    }else {
                                        $retorno['codigo']   = 1;
                                        $retorno['mensagem'] = 'Nota fiscal ID: '.$value->id_nota.' - '.$multaJuros->mensagem;
                                    }
                                }

                                if( $retorno ){
                                    throw new Exception(json_encode($retorno));
                                }
                            }
                        } catch (Exception $e){
                            $retorno                         = json_decode($e->getMessage());
                            $parametros['webhook']           = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/88437d8ab0ce4053ae3a7188b16d8baa/c8c7ff53-e294-4a3a-bcad-c9f04857e469';
                            $parametros['tipo_destinatario'] = 'webhook';
                            if( isset( $retorno->mensagem ) ){
                                $parametros['mensagem']      = $retorno->mensagem;
                            }else{
                                $parametros['mensagem'] = 'Erro desconhecido em run_alertas.php funcao checkMultaJuros';
                            }
                            $this->notificacoes->enviar( 'teams', $parametros );
                            $parametros['tipo_destinatario'] = 'user';
                            $parametros['email_to'] 		 = DEFAULT_ALERTA;
                            $this->notificacoes->enviar( 'teams', $parametros );
                        }
                    break;
                    case 'RPS0001':
                        $data_atual      = getDataAtual();
                        $obj_nf          = $this->controller->load_model('notas-fiscais/notas-fiscais', true);
                        $notas_fiscais   = json_decode( $obj_nf->getNotaByEmissao( $data_atual->format('Y-m-d'), $data_atual->format('Y-m-d') ) );
                        if( $notas_fiscais ){
                            foreach ( $notas_fiscais as $key => $value ) {
                                $nfs[$value->id]['id_nf'] = $value->id;
                            }
                            $rps = json_decode( $this->obj_faturamento->gerarRps( json_encode( $nfs ), true ) );
                            if( $rps ){
                                foreach ($rps as $key => $value) {
                                    if( $value->status == 'success' ){
                                        // logar sucesso
                                    }else{
                                        // logar erro
                                    }
                                }
                            }else{
                                // logar erro
                            }
                        }else{
                            // logar erro
                        }
                    break;
                    case 'FAT0001':
                        $extras['cobrar_multa']    = 1;
			            $extras['cobrar_reajuste'] = 1;
			            $contrato_model  = $this->controller->load_model( 'contratos/contratos', true );
                        $nf_model        = $this->controller->load_model( 'notas-fiscais/notas-fiscais', true );
                        $contratos       = json_decode( $this->obj_faturamento->getContratosPorEmpresa() );
                        if( $contratos ){
                            foreach( $contratos as $key => $value ){
                                if($key > 0){
                                    break;
                                }
                                $faturar     = false;
                                $faturamento = null;
                                if( 1 == $value->nf_automatica ){
                                    $data_atual  = clone $this->data_atual;
                                    $dt_ini      = clone $data_atual;
                                    $dt_ini->sub(new DateInterval('P1M'));
                                    $dt_fim      = clone $data_atual;
                                    $dt_fim->sub(new DateInterval('P1D'));
                                    $ultimo_dia_mes  = cal_days_in_month( CAL_GREGORIAN, $data_atual->format('m'), $data_atual->format('Y') );
                                    $dia_faturamento = (int)$data_atual->format('d');
                                    $mes_faturamento = (int)$data_atual->format('m');
                                    if( 2 == ( int ) $mes_faturamento ){
                                        if( $dia_faturamento == (int) $value->data_corte_faturamento ){
                                            $faturar = true;
                                        }else{
                                            if( $value->data_corte_faturamento > 28 && $dia_faturamento > 28 ){
                                                $faturar = true;
                                            }
                                        }
                                    }elseif( $dia_faturamento == (int) $value->data_corte_faturamento ){
                                        $faturar = true;
                                    }elseif( 30 == (int) $ultimo_dia_mes ){
                                        if( $value->data_corte_faturamento > 30 ){
                                            $faturar = true;
                                        }
                                    }
                                    echo 'Dia faturamento contrato: '.$value->data_corte_faturamento.' dia atual '.$data_atual->format('d').' <br> '.PHP_EOL;
                                    if( $faturar ){
                                        $data_faturamento = clone $data_atual;
                                        $data_faturamento->setDate( $this->data_atual->format('Y'), $data_atual->format('m'), $value->data_corte_faturamento );
                                        $ultima_nota      = json_decode( $nf_model->getLastNota( $value->id_contrato ) );
                                        if( $ultima_nota ){
                                            $data_ultima_nota = getDataAtual( $ultima_nota[0]->data_emissao );
                                        }else{
                                            $data_ultima_nota = null;
                                        }

                                        if( isset( $data_ultima_nota ) && $data_ultima_nota->format('Ymd') >= $data_atual->format('Ymd') ){
                                            $faturar =  false;
                                        }
                                    }
                                }else{
                                    echo 'Nota fiscal automatica desativada o contrato '.$value->id_contrato.' - '.$value->razao_social.' e produto '.$value->codigo_produto.' <br> ';
                                }
                                
                                if( $faturar ){
                                    $faturamento = json_decode( $this->obj_faturamento->getDetalheFaturamento( $value->id, $dt_ini->format('Y-m-d'), $dt_fim->format('Y-m-d'), null, $extras ) );
                                    if( $faturamento ){
                                        if( $faturamento->receita->resumo->total_liquido > 0 ){
                                            $faturamento->data_faturamento = $this->data_atual->format('Y-m-d');
                                            $numero_nota = $this->obj_faturamento->gerarnf( $faturamento );
                                            if( $numero_nota ){
                                                // nota gerada com sucesso
                                                echo 'Gerado nota fiscal numero '.$numero_nota.' para contrato '.$value->id_contrato.' - '.$value->razao_social.' e produto '.$value->codigo_produto.' <br> ';
                                            }else{
                                                // erro ao gerar nota
                                                echo 'Erro ao gerar nota para contrato '.$value->id_contrato.' - '.$value->razao_social.' e produto '.$value->codigo_produto.' <br> ';
                                            }
    
                                        }
                                    }
                                }else{
                                    echo 'Não faturar o contrato '.$value->id_contrato.' - '.$value->razao_social.' e produto '.$value->codigo_produto.' <br> ';
                                }
                            }
                        }
                    break;
                    case 'FAT0002':
                        $data_atual = clone $this->data_atual;
                        // $data_atual = getDataAtual('2024-07-02');
                        $contrato_model   = $this->controller->load_model( 'contratos/contratos', true );
                        $produtos_model   = $this->controller->load_model( 'produtos/produtos', true );
                        $contratos        = json_decode( $contrato_model->getContratosPorEmpresa() );
                        if( $contratos ){
                            $nf_model        = $this->controller->load_model( 'notas-fiscais/notas-fiscais', true );
                            $lp_model        = $this->controller->load_model( 'lista-precos/lista-precos', true );
                            foreach( $contratos as $key => $value ){
                                $gerar_nf      = false;
                                echo '<br> ######################## <br>';
                                echo 'Contrato: '.$value->id.' - '.$value->razao_social.' - '.$value->codigo_produto.' assinatura '.$value->data_assinatura.' data fechamento '.$value->data_corte_faturamento.'<br>';
                                if( $value->status_contrato == 'ativo' && $value->taxa_inatividade ){
                                    $dia_faturamento = clone $data_atual;
                                    $dia_faturamento->add( new DateInterval( 'P1D' ) );
                                    $dia_atual = $dia_faturamento->format('d');
                                    $mes_atual = $dia_faturamento->format('m');
                                    $dia_corte = $value->data_corte_faturamento;
                                    if( $mes_atual == 2 ){
                                        // verifica se o ano é bisexto
                                        if( $dia_atual == $dia_corte ){
                                            $gerar_nf = true;
                                        }elseif( $data_atual->format("L") == 1 ){
                                            // quando o ano é bisexto
                                            if( $dia_corte >= 29  ){
                                                $gerar_nf = true;
                                            }
                                        }else{
                                            if( $dia_corte >= 28  ){
                                                $gerar_nf = true;
                                            }
                                        }
                                    }else{
                                        if( $dia_atual == $dia_corte ){
                                            $gerar_nf = true;
                                        }
                                    }

                                    $data_assinatura = getDataAtual( $value->data_assinatura );
                                    $diff            = $data_assinatura->diff( $data_atual );
                                    if( $diff->days >= (int) $value->prazo_inatividade ){
                                        $this->setNotificacion();
                                        $dados_modulo                   = json_decode( $produtos_model->getProdutoEmodulo( $value->codigo_produto, 'INT0001' ) );
                                        $ultima_nota = json_decode( $nf_model->getLastNota( $value->id_contrato ) );
                                        $lista_preco = json_decode( $lp_model->getLpContratosByModulo( $value->id_contrato, 'INT0001' ) );
                                        if( $ultima_nota ){
                                            echo 'Ultima nota tipo '.$ultima_nota[0]->tipo.' emissao '.$ultima_nota[0]->data_emissao.'<br>';
                                        }

                                        $param_mov = array(
                                            'origem'        => 'lancamento',
                                            'tipo'          => 'taxa_inatividade',
                                            'id_contrato'   => $value->id,
                                            'status'        => 'pendente',
                                        );

                                        $mov_diario = json_decode( $nf_model->getLastMovAux( $param_mov ) );
                                        if( !$lista_preco ){
                                            echo 'Não possui lista de preço para taxa de inatividade <br>';
                                            $destinatario = explode( ';', JUSTME );
                                            $gerar_nf = false;
                                            $param_team['mensagem']          = 'Contrato sem lista de preço para taxa de inatividade: '.$value->id.' - '.$value->razao_social.' - '.$dados_modulo[0]->descricao.' - '.$dados_modulo[0]->id;
                                            $param_team['tipo_destinatario'] = 'user';
                                            foreach ( $destinatario as $d1 => $d2 ) {
                                                $param_team['email_from'] = $d2;
                                                $param_team['email_to']   = $d2;
                                                $this->notificacoes->enviar( 'teams', $param_team );
                                            }
                                        }
                                        
                                        if( $gerar_nf ){
                                            $dados_nf                           = new Stdclass();
                                            $dados_nf->periodo_de               = getDataAtual();
                                            $dados_nf->periodo_ate              = getDataAtual();
                                            $dados_nf->contrato                 = $value;
                                            $dados_nf->contrato->valor          = $lista_preco[0]->valor_real;
                                            $dados_nf->contrato->id_modulo      = $dados_modulo[0]->id;
                                            $dados_nf->contrato->codigo_modulo  = $dados_modulo[0]->codigo;
                                            if( !$ultima_nota && !$mov_diario ){
                                                $mov_save = json_decode( $this->obj_faturamento->inserirLancamento( $dados_nf ) );
                                                echo 'lançamento de taxa de inatividade lançado para contrato ID '.$value->id.' com numero '.json_encode( $mov_save ).' <br>';
                                            }elseif( $ultima_nota && $mov_diario ){
                                                $data_emissao = getDataAtual( $ultima_nota[0]->data_emissao );
                                                $data_mov_aux = getDataAtual( $mov_diario[0]->data_tarifacao  );
                                                // echo 'tem ultima nota e mov diario '.$value->id.' <br>';
                                                if( $data_emissao > $data_mov_aux ){
                                                    $mov_save = json_decode( $this->obj_faturamento->inserirLancamento( $dados_nf ) );
                                                    echo 'lançamento de taxa de inatividade lançado para contrato ID '.$value->id.' com numero '.json_encode( $mov_save ).' <br>';
                                                }
                                            }else{
                                                if( $ultima_nota && !$mov_diario ){
                                                    $data_emissao = getDataAtual( $ultima_nota[0]->data_emissao );
                                                    $diff_emissao = $data_emissao->diff( $data_atual );
                                                    if( $ultima_nota[0]->tipo == 'N' ){
                                                        if( $diff_emissao->days > 29 ){
                                                            // verifica quando tem nota mas não é de inatividade
                                                            $mov_save = json_decode( $this->obj_faturamento->inserirLancamento( $dados_nf ) );
                                                            echo 'lançamento de taxa de inatividade lançado para contrato ID '.$value->id.' com numero '.json_encode( $mov_save ).' <br>';
                                                        }
                                                    }else{
                                                        if( $diff_emissao->days > $value->prazo_inatividade ){
                                                            // verifica quando tem nota mas não é de inatividade
                                                            $mov_save = json_decode( $this->obj_faturamento->inserirLancamento( $dados_nf ) );
                                                            echo 'lançamento de taxa de inatividade lançado para contrato ID '.$value->id.' com numero '.json_encode( $mov_save ).' <br>';
                                                        }
                                                    }
                                                }elseif( !$ultima_nota && $mov_diario ){
                                                    // echo 'Não tem ultima nota mas tem mov diario '.$value->id.' <br>';
                                                    $data_tarifacao = getDataAtual( $mov_diario[0]->data_tarifacao );
                                                    $diff_emissao   = $data_tarifacao->diff( $data_atual );
                                                    if( $diff_emissao->days > 29 ){
                                                        // echo 'Diferenca mais de 29 dias do ultimo mov diario até a data atual '.$value->id.' <br>';
                                                        $mov_save = json_decode( $this->obj_faturamento->inserirLancamento( $dados_nf ) );
                                                        echo 'lançamento de taxa de inatividade lançado para contrato ID '.$value->id.' com numero '.json_encode( $mov_save ).' <br>';
                                                    }
                                                }
                                            }
                                        }else{
                                            echo 'Não gerar taxa para contrato: '.$value->id.' - '.$value->razao_social.' - '.$dados_modulo[0]->codigo_produto.'<br>';
                                        }
                                    }else{
                                        echo 'o prazo para taxa de inatividade ainda não expirou <br>';    
                                    }
                                }else{
                                    echo 'Não possui taxa de inatividade ou está inativo <br>';
                                }
                                echo '<br> ######################## <br>';
                            }
                        }
                    break;
                    case 'FAT0003':
                        $contratos_model = $this->controller->load_model( 'contratos/contratos', true );
                        $movimento_model = $this->controller->load_model( 'movimento/movimento', true );
                        $contratos       = json_decode( $contratos_model->getJustContratos() );
                        if( $contratos ){
                            if('producao' == TIPO_AMBIENTE){
                                $parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/12ad07a8afcc45b1a3d600758059232e/c8c7ff53-e294-4a3a-bcad-c9f04857e469';
                            }else{
                                $parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9f2e2cc655bf4e76bfdb0531dd3a83d7/c328c206-070a-4beb-bbed-da82e018abec';
                            }
                            $parametros['tipo_destinatario'] = 'webhook';
                            foreach ($contratos as $key => $value) {
                                if($value->alerta_inatividade > 0){
                                    $ultima_transacao = json_decode($movimento_model->getLastTransacao($value->id_contrato));
                                    $data_tarifacao = new DateTime($ultima_transacao[0]->data_tarifacao);
                                    $diff = $this->controller->data_hora_atual->diff($data_tarifacao);
                                    $days = $diff->days;
                                    if( $diff->days > $value->alerta_inatividade ){
                                        $parametros['mensagem'] = "Alerta o cliente $value->razao_social est� a $days  dias sem tarifar!!! ";
                                        $this->notificacoes->enviar('teams', $parametros);
                                    }
                                }
                            }
                        }
                    break;
                    default:
                        // logar erro
                    break;
                }
            } catch ( Exception $e ) {
                return $e->getMessage();
            }
        }
	}