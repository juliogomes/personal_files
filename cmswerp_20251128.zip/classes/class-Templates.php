<?php
	/**
	* Julio
	* Classe para load telas do sistema
	*/
	class Templates{
        protected $path_folder;
        protected $modulo;
        protected $window;
        protected $param_page;
        function __construct( $param_page = null ){
            $this->path_folder = ABSPATH.DS.'template'.DS.'modulos'.DS;
            if( isset( $parametros['modulo'] ) && !empty( $parametros['modulo'] ) ){
                $this->modulo = $parametros['modulo'];
            }

            if( isset( $parametros['window'] ) && !empty( $parametros['window'] ) ){
                $this->window = $parametros['window'];
            }

            if( isset( $parametros['titulo'] ) && !empty( $parametros['titulo'] ) ){
                $this->titulo = $parametros['titulo'];
            }

		}

        function getParamPage(){
            return $this->param_page;
        }
        
        function setParamPage( $param_page ){
            $this->param_page = $param_page;
        }

        function getTitulo(){
            return $this->param_page['titulo'];
        }

        function load(){
            // implementar carregamento de templates padrões
        }

        function loadWindow( $modulo, $window ){
            $this->modulo = $modulo;
            $this->window = $window;
            $modulo_path = $this->path_folder.$this->modulo.DS.$this->window.'.php';
            if( file_exists( $modulo_path ) ){
                require_once( $modulo_path );
            }else{
                $this->redirectDefaultDefaultWindow( $modulo, $window );
            }
        }

        function redirectDefaultDefaultWindow( $modulo, $window ){
            $this->modulo = $modulo;
            $this->window = $window;
            $modulo_path = $this->path_folder.'default'.DS.$this->modulo.DS.$this->window.'.php';
            if( file_exists( $modulo_path ) ){
                require_once( $modulo_path );
            }else{
                echo 'Erro ao carregar window template COD:25';
                exit;
            }
        }
	}