<?php
	/**
	* Julio
	* Classe para log de eventos no sistema
	*/
	class Upload extends Main{
		
		protected $name;
		protected $tmp_name;
		protected $type;
		protected $pasta;
		protected $subpasta;
		protected $size;	
		protected $allow_size;
		protected $extensoes;
		protected $renomeia;
		protected $error;
		protected $string_erros;

		function __construct( $controller, $param = null, $config = null){
			parent::__construct( $controller );
			date_default_timezone_set('America/Sao_Paulo');
			$this->string_erros   = array( 
									0 => 'Não houve erro',
									1 => 'O arquivo no upload é maior do que o limite do PHP',
									2 => 'O arquivo ultrapassa o limite de tamanho especifiado no HTML',
									3 => 'O upload do arquivo foi feito parcialmente',
									4 => 'O tamanho do arquivo é maior que o permitido no sistema',
									5 => 'Erro ao fazer upload do arquivo',
								);

			if(isset($config['extensoes'])){
				$this->extensoes  = $config['extensoes'];
			}else{
				$this->extensoes  = array('txt', 'pdf', 'ofx', 'doc', 'csv');
			}

			if(isset($config['renomeia'])){
				$this->renomeia   = $config['renomeia'];
			}else{
				$this->renomeia   = false;
			}	

			if(isset($config['pasta'])){
				$this->pasta      = $config['pasta'];
			}else{
				$this->pasta  	  = UP_GED;
			}

			if(isset($config['allow_size'])){
				$this->allow_size = $config['allow_size'];
			}else{
				$this->allow_size = 64000000;
			}

			if( isset( $param ) ){
				$this->name      = $param['name'];
				$this->tmp_name  = $param['tmp_name'];
				$this->type      = $param['type'];
				$this->size   	 = $param['size'];
				$this->error     = $param['error'];
			}		
		}

		function loadFile( $param = null, $config = null ){
			try {
				$this->__construct( $this, $param, $config );
				$path_full = $this->pasta;
				if( $param ){
					if( $param['error'] != 0 ){
						$i      			 = $param['error'];
						$retorno['codigo']   = 2;
						$retorno['tipo']     = "danger";
						$retorno['mensagem'] = 'Erro desconhecido';
						$retorno['dados']    = $this->string_erros[$i];

					}elseif($param['size'] > $this->allow_size){

						$retorno['codigo']   = 2;
						$retorno['tipo']     = "danger";
						$retorno['mensagem'] = 'Tamho de arquivo maior que o permitido';
						$retorno['dados']    = $this->string_erros[4];
					}else{
						if( !file_exists( $path_full ) ){
							$is_create = mkdir( $path_full, 0777, true);
						}else{
							$is_create = true;
						}

						if($is_create){
							$is_move = move_uploaded_file( $this->tmp_name, $path_full.DS.$this->name );
							if($is_move) {
								$retorno['codigo']   = 0;
								$retorno['tipo']     = "success";
								$retorno['mensagem'] = 'Upload efetuado com sucesso';
								$retorno['dados']    = $param;
							} else {
								$retorno['codigo']   = 2;
								$retorno['tipo']     = "danger";
								$retorno['mensagem'] = 'Erro ao fazer upload do arquivo';
								$retorno['dados']    = $param;
							}
						}else{
							$retorno['codigo']   = 2;
							$retorno['tipo']     = "danger";
							$retorno['mensagem'] = 'Erro ao criar diretorio do cliente';
							$retorno['dados']    = $param;
						}
					}			
				}else{
					$retorno['codigo']   = 2;
					$retorno['tipo']     = "danger";
					$retorno['mensagem'] = 'Parametros vazios para upload de arquivo';
					$retorno['dados']    = $param;
				}
				throw new Exception(json_encode($retorno), 1);
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function checkArquivo(){
			try{
				$ext = pathinfo($this->name, PATHINFO_EXTENSION);
				if(!in_array($ext, $this->extensoes)){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Extensão $ext não permitido! ";
					throw new Exception(json_encode($retorno), 1);
				}

				if(empty($this->size)){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Arquivo vazio";
					throw new Exception(json_encode($retorno), 1);
				}

				if($this->size > $this->allow_size){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Tamanho: ".$this->size." maior que o permitido de ".($this->allow_size/1000000)." Mb";
					throw new Exception(json_encode($retorno), 1);
				}

				if(!file_exists($this->tmp_name)){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this;
					$retorno['output']   = $this->tmp_name;
					$retorno['mensagem'] = "Arquivo não encontrado";
					throw new Exception(json_encode($retorno), 1);
				}
				
				$retorno['codigo']   = 0;
				$retorno['input']    = null;
				$retorno['output']   = null;
				$retorno['mensagem'] = "Sucesso";
				throw new Exception(json_encode($retorno), 1);

			}catch (Exception $e){
				return $e->getMessage();
			}
		}

		function readFile(){
			try{
				$chk = json_decode($this->checkArquivo());
				if($chk->codigo != 0){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_FILES;
					$retorno['output']   = $chk;
					$retorno['mensagem'] = $chk->mensagem;
					throw new Exception(json_encode($retorno), 1);
				}
				
				$linhas = null;
				$rowarr = file($this->tmp_name, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				foreach($rowarr as $key => $value){
					$charset = mb_detect_encoding($value);
					// var_dump($charset, $value);
					if( $charset == 'ASCII' ){
						$linhas[] = iconv('ASCII', 'UTF-8//IGNORE', $value);
					}else{
						$linhas[] = utf8_encode($value);
					}			
				}
													
				if($linhas){				
					$retorno['codigo']   = 0;
					$retorno['input']    = null;
					$retorno['output']   = $linhas;
					$retorno['mensagem'] = 'Sucesso';				
					throw new Exception(json_encode($retorno), 1);
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = null;
					$retorno['output']   = $linhas;
					$retorno['mensagem'] = "Erro ao ler arquivo";
					throw new Exception(json_encode($retorno), 1);
				}

				// var_dump(json_encode($linhas));
				// switch (json_last_error()) {
				// 	case JSON_ERROR_NONE:
				// 		echo ' - No errors';
				// 	break;
				// 	case JSON_ERROR_DEPTH:
				// 		echo ' - Maximum stack depth exceeded';
				// 	break;
				// 	case JSON_ERROR_STATE_MISMATCH:
				// 		echo ' - Underflow or the modes mismatch';
				// 	break;
				// 	case JSON_ERROR_CTRL_CHAR:
				// 		echo ' - Unexpected control character found';
				// 	break;
				// 	case JSON_ERROR_SYNTAX:
				// 		echo ' - Syntax error, malformed JSON';
				// 	break;
				// 	case JSON_ERROR_UTF8:
				// 		echo ' - Malformed UTF-8 characters, possibly incorrectly encoded';
				// 	break;
				// 	default:
				// 		echo ' - Unknown error';
				// 	break;
				// }

				
			}catch(Exception $e){
				return $e->getMessage();
			}
		}
	}