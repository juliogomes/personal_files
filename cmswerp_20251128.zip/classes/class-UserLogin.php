<?php
class UserLogin{
    public $error;
	public $error_msg;
	public $login_error;
	/**
	 * Gravar log sistema
	 *
	 * Cria objeto de log
	 *
	 * @public
	 * @access protected
	 * @var Object
	*/
	protected $logSistema;
	
	/**
	 * Usuário logado ou não
	 *
	 * Verdadeiro se ele estiver logado.
	 *
	 * @public
	 * @access public
	 * @var bol
	 */
	public $logged_in;

	/**
	 * $permissoes_perfil
	 *
	 * Permissoes do usuario
	 *
	 * @access public
	 */
	public $cl_permissoes;

	/**
	 * Dados do usuário
	 *
	 * @public
	 * @access public
	 * @var array
	 */
	public $userdata;

	/**
	 * Mensagem de erro para o formulário de login
	 *
	 * @public
	 * @access public
	 * @var string
	 */
	// public $login_error;

	/**
	 * Verifica o login
	 *
	 * Configura as propriedades $logged_in e $login_error. Também
	 * configura o array do usuário em $userdata
	 */
	
	public $api, $user_model;
	function __construct(){
		// Instancia do DB
		$this->user_model =  $this->load_model('usuarios/usuarios', true);
		// carregando classe de permissões do sistema
		$this->cl_permissoes = new Permissoes( $this );
		$this->logSistema 	 = new LogSistema( $this );
	}

	public function check_userlogin(){
		if(isset($_POST['userdata'])){
			$this->userdata = $_POST['userdata'];
			$arr = explode('@', $this->userdata['email']); // pegar o usuario do email
		}elseif(isset($_SESSION['cmswerp']['userdata'])){
			$this->userdata = $_SESSION['cmswerp']['userdata'];
			$arr = explode('@', $this->userdata->email); // pegar o usuario do email
		}else{
			if(isset($_SERVER['REQUEST_URI'])){
				$url_atual = urlencode($_SERVER['REQUEST_URI']);
			}else{
				$url_atual = null;
			}
			
			if($url_atual != '%2F' && $url_atual != '%2Flogin%2F' && $url_atual != '%2Flogin' ){
				// A página em que o usuário estava
				if($_SERVER['REQUEST_URI']){
					$_SESSION['goto_url'] = urlencode( $_SERVER['REQUEST_URI'] );	
				}else{
					$_SESSION['goto_url'] = null;
				}

				if( $this->parametros[0] == 'json' ){
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Necessario fazer login novamente';
				    //echo json_encode($retorno);
				}else{
					$this->goto_login();	
				}
			}
		}

		if( isset( $arr[0] ) ){
			$email = $arr[0].'@cmsw.com';
			$email = filter_var($email, FILTER_SANITIZE_EMAIL);
			if ( filter_var( $email, FILTER_VALIDATE_EMAIL ) ){
				$user = json_decode( $this->user_model->getUserByEmail( strtolower( $email ) ) ); //busca as informações do
			}
			
			if(isset($user->permissoes) && !empty($user->permissoes)){
				$permissoes_perfil =  json_decode($user->permissoes);
				$lista_permissoes['nome'] = $permissoes_perfil->nome;
				foreach ($permissoes_perfil->modulos as $key => $value) {
					if((isset($value->permissoes) && $value->permissoes > 0) || $_SESSION['cmswerp']['userdata']->master == 1){
						if(isset($value->grupo) && isset($value->id)){
							$i1 = $value->grupo;
							$i2 = $value->id;
							$lista_permissoes['modulos'][$i1][$i2] = $value;
							// ksort($lista_permissoes['modulos'][$i1][$i2]);
						}
					}
				}
				ksort($lista_permissoes['modulos']);
				$user->permissoes       = json_encode($lista_permissoes);
			}else{
				$this->logSistema->saveLoginAction( $arr[0], encryptData($_POST['userdata']['senha']), 'erro', 'Usuario não encontrado' );
			}
		}

		if(isset($_POST['userdata'])){
			if($user){
				if($user->login_ldap){
					$ldap = new Ldap(); // instanciando a classe ldap
					$ldap->login(strtolower($arr[0]), $this->userdata['senha']);
					if( !$ldap->error ){
					    $this->logSistema->saveLoginAction( $arr[0], encryptData($_POST['userdata']['senha']), 'ok' );
						$_SESSION['cmswerp']['userdata']->master = $user->master;
						session_regenerate_id();
						$session_id = session_id();
						$senha_cripto = md5($this->userdata['senha']);
						$this->updateSessionId($session_id, $senha_cripto, $user->id);
						$user->user_session_id = $session_id;
						$_SESSION['cmswerp']['userdata'] = $user;
						$this->logged_in = true;
						session_name('cmswerp');
						if(isset($_SESSION['goto_url'])){
							$this->goto_page($_SESSION['goto_url']);
						}else{
							$this->goto_page('/home/index/');
						}
					}else{
					    $this->login_error = $ldap->error;
						$this->logSistema->saveLoginAction($arr[0], encryptData($_POST['userdata']['senha']), 'erro', $this->login_error);
					}
				}else{
					if( $user && $user->senha == md5( $_POST['userdata']['senha'] ) ){
						session_regenerate_id();
						$session_id = session_id();
						$senha_cripto = md5($this->userdata['senha']);
						$this->updateSessionId($session_id, $senha_cripto, $user->id);
						$user->user_session_id = $session_id;
						$_SESSION['cmswerp']['userdata'] = $user;
						$this->logged_in = true;
						if(isset($_SESSION['goto_url'])){
							$this->goto_page($_SESSION['goto_url']);
						}else{
							$this->goto_page('/home/index/');
						}
					}else{
					    $this->login_error = 'Senha incorreta!!!';
						$this->logSistema->saveLoginAction($arr[0], encryptData($_POST['userdata']['senha']), 'erro', $this->login_error);
					}
				}
			}else{ // caso usuario  não seja encontrado na base de dados ele não efetua login mesmo usando o usuario e senha correto do email
			    $this->logged_in = false;
				$this->login_error = 'Email não encontrado na base de dados!';
				$this->logSistema->saveLoginAction($arr[0], encryptData($_POST['userdata']['senha']), 'erro', $this->login_error);
			}
		}elseif(isset($_SESSION['cmswerp']['userdata'])){
			if(
				($_SESSION['cmswerp']['userdata']->user_session_id != $user->user_session_id) ||
				($_SESSION['cmswerp']['userdata']->email_hash != $user->email_hash)
			){
				$this->logout(true);
			}else{
				$_SESSION['cmswerp']['userdata'] = $user;
				$this->logged_in = true;
			}
		}else{
			if( isset( $this->parametros[0] ) && $this->parametros[0] == 'json' ){
				// $retorno['codigo']   = 1;
				// $retorno['mensagem'] = 'Necessario fazer login novamente';
				// echo json_encode($retorno);
			}
		}
	}

	function updateSessionId($session_id, $senha_cripto, $user_id){
		// Atualiza o ID da sessão na base de dados
		$query = $this->user_model->db->query(
			'UPDATE sistema_usuarios SET user_session_id = ?, senha = ? WHERE id = ?',
			array( $session_id, $senha_cripto, $user_id )
		);
	}

	/**
	 * Logout
	 *
	 * Desconfigura tudo do usuárui.
	 *
	 * @param bool $redirect Se verdadeiro, redireciona para a página de login
	 * @final
	 */
	protected function logout( $redirect = false ){
		// Remove all data from $_SESSION['cmswerp']['userdata']
		$_SESSION = null;
		$_SESSION['cmswerp']['userdata'] = null;
		unset( $_SESSION['cmswerp']['userdata']);
       	unset( $_SESSION['goto_url']);
       	//session_destroy();
		// Regenerates the session ID
		session_regenerate_id();
		if ( $redirect === true ){
			// Send the user to the login page
			$this->goto_login();
		}
	}

	protected function goto_login(){
        // // Verifica se a URL da HOME está configurada
		if ( defined( 'HOME_URI' ) ){
			$login_uri = HOME_URI.'login/';
			// Redireciona
			// echo '<meta http-equiv="Refresh" content="0; url=' . $login_uri . '">';
			// echo '<script type="text/javascript">window.location.href = "' . $login_uri . '";</script>';
			header('location: ' . $login_uri);
		}else{
			echo 'Erro recarregue a pagina!';
			exit;
		}
		return;
	}

	/**
	 * Envia para uma página qualquer
	 *
	 * @final
	 */
	final protected function goto_page( $page_uri = null ) {
		$page_uri  = urldecode( $page_uri);
		// if ( $page_uri ) {
		// 	// Redireciona
		// 	echo '<meta http-equiv="Refresh" content="0; url=' . $page_uri . '">';
		// 	echo '<script type="text/javascript">window.location.href = "' . $page_uri . '";</script>';
		// 	//header('location: ' . $page_uri);
		// 	return;
		// }
	}
}