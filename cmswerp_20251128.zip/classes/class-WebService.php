<?php

class WebService{
	
    protected $method;
    public    $cliente;
    public    $header;
    public    $error;
	public    $fault;	
	
	function __construct($host = null, $parametros = null, $method = 'SOAP'){
		require_once(ABSPATH.'/libs/nusoap/nusoap.php');
		$this->method = $method;
        if(!$host){
            $host = WS_RPA_HOST;
        }
        if($parametros){
            $this->setHeader($parametros);
        }else{
            $this->setHeader(array(
                'header' => array(
                     'empresa'=> WS_RPA_FLUXO_EMPRESA,
                     'usuario'=> WS_RPA_FLUXO_USUARIO,
                     'senha'  => WS_RPA_FLUXO_SENHA,
                     'fluxo'  => WS_RPA_FLUXO_SEND,
                     'hash'   =>'',
                     'ticket' =>''
                 ),
             ));
        }
        if($this->method == 'SOAP'){
            $this->cliente = new SoapClient($host, array("trace" => 1,"exceptions"=>1)); 
        }else{
        	//implementar outros 
            $this->cliente = new nusoap_client(
				$host.'webservice.php?wsdl',
				/*wsdl*/ null,
				/*proxyhost*/ false,
				/*proxyport*/ false,
				/*proxyusername*/ false,
				/*proxypassword*/ false,
				/*timeout*/ 3600, //here you can define timeout
				/*response_timeout*/ 3600, //here is what you want to define
				/*portName*/ '');
            $err = $this->cliente->getError();
            if($err) {
                $this->error = $err;
            }    
        }
	}

	function setHeader($parametros){
		if($parametros){
			$this->header = $parametros;	
		}
	}

	function getheader(){
		return $this->header;
    }
    
    function setError($error){
        $this->error = $error;
    }

    function getError(){
        return $this->error;
    }

	function call($funcao, $parametros){
        $this->fault = null;
        if($this->method == 'SOAP'){
            try{
                $exec = $this->cliente->__soapCall($funcao, $parametros);
                $retorno['codigo']     = 0;
                $retorno['tipo']       = 'success';
                $retorno['mensagem']   = 'Chamada do metodo '.$funcao.' excecutada com sucesso';
                $retorno['exec']       = $exec;
                $retorno['dados']      = $this;
                $retorno['parametros'] = $parametros[$funcao];
                return json_encode($retorno);
            }catch (SoapFault $fault) {
                $this->fault = "SOAP Fault: (faultcode: {$fault->faultcode}, faultstring: {$fault->faultstring})"; 
                $retorno['codigo']    = 2;
                $retorno['tipo']      = 'danger';
                $retorno['mensagem']  = $this->fault;
                $retorno['exec']      = null;
                $retorno['dados']     = $this;
                $retorno['parametros'] = $parametros[$funcao];
                return json_encode($retorno);
            }
        }else{
            return $this->cliente->call($funcao, $parametros);
        }        
	}
}