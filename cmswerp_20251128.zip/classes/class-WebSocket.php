<?php

class WebSocket{
	public $socket;
	public $bind;
	public $listen;
	public $resource;
	public $secKey;
	public $secAccept;
	public $upgrade;
	public $input;
	public $output;
	function __construct(){
		$this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		socket_set_option($this->socket, SOL_SOCKET, SO_REUSEADDR, 1);
		//$this->socket = socket_create(AF_INET, SOCK_STREAM, 0);
		$this->SocketBind();
		$this->listen();
		$this->getConnection();
		$this->getInput();
		$this->getOutPut();
		//$this->close();
	}

	function SocketBind($socket = null){
		if($socket){
			$this->bind = socket_bind($socket, WS_SERVER, WS_PORT);
		}else{
			$this->bind = socket_bind($this->socket, WS_SERVER, WS_PORT);
		}		
	}

	function listen($socket = null){
		if($socket){
			$this->listen = socket_listen($socket, 3);
		}else{
			$this->listen = socket_listen($this->socket, 3);
		}
	}

	function getConnection($socket = null){
		if($socket){
			$this->resource = socket_accept($socket);
		}else{
			$this->resource = socket_accept($this->socket);
		}
	}

	function getInput($mensagem = null){
		if($mensagem){
			$input = socket_read($this->resource, 1024) or die("Could not read input\n");
			// clean up input string
			$this->input = trim($input);
			echo 'Mensagem do cliente!'.$this->input;
		}	
	}

	function getOutPut($mensagem = null){
		//reverse client input and send back
		//$this->output = strrev($this->input) . "\n";
		
		$retorno['tipo']   = 'default';
		$retorno['codigo'] = 1;
		$retorno['valor']  = null;

		if($mensagem){
			$this->output = json_encode($retorno);
		}else{
			$retorno['tipo']     = 'default';
			$retorno['codigo']   = 1;
			$retorno['mensagem'] = 'mensagem de retorno padrão';
			$this->output = json_encode($retorno);
		}
		socket_write($this->resource, $this->output, strlen ($this->output)) or die("Could not write output\n");
	}

	function getSocket(){
		return $this->socket;
	}

	function close(){
		//socket_close($this->resource);
		//socket_close($this->socket);
	}

	//Unmask incoming framed message
	function unmask($text) {
	    $length = ord($text[1]) & 127;
	    if($length == 126) {
	        $masks = substr($text, 4, 4);
	        $data = substr($text, 8);
	    }
	    elseif($length == 127) {
	        $masks = substr($text, 10, 4);
	        $data = substr($text, 14);
	    }
	    else {
	        $masks = substr($text, 2, 4);
	        $data = substr($text, 6);
	    }
	    $text = "";
	    for ($i = 0; $i < strlen($data); ++$i) {
	        $text .= $data[$i] ^ $masks[$i%4];
	    }
	    return $text;
	}

	//Encode message for transfer to client.
	function mask($text)
	{
	    $b1 = 0x80 | (0x1 & 0x0f);
	    $length = strlen($text);

	    if($length <= 125)
	        $header = pack('CC', $b1, $length);
	    elseif($length > 125 && $length < 65536)
	        $header = pack('CCn', $b1, 126, $length);
	    elseif($length >= 65536)
	        $header = pack('CCNN', $b1, 127, $length);
	    return $header.$text;
	}
}