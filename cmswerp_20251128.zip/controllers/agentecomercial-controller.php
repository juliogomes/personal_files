<?php
	// require_once('classes/class-Validacao.php');
	class AgenteComercialController extends MainController{
		protected $meios_recebimento;
		protected $obj_metadados;
		protected $obj_mr;
		protected $obj_email;
		protected $obj_banco;
		protected $list_bancos;
		protected $obj_api;
		protected $empresa_cm;
		protected $produtos_modelo;
		protected $produtos_list;
		protected $integracao;
		
		function __construct( $parametros = null ){
			$this->setModulo('agentecomercial');
			$this->setView('agentecomercial');
			parent::__construct( $parametros );
			$this->obj_metadados   = new MetaDados( $this );
			$this->empresa_cm  	   = $this->load_model( 'empresas/empresas', true );
			$this->empresa_cm      = json_decode( $this->empresa_cm->getEmpresa() );
			$this->produtos_modelo = $this->load_model( 'produtos/produtos', true );		
			$this->produtos_list   = json_decode( $this->produtos_modelo->getAllCodigoProdutosAtivos( 4000001 ) );
			$this->obj_api         = new Api( $this );
			if( TIPO_AMBIENTE == 'producao' ){
				$this->integracao = new Integracoes( $this, 'CRY0003' );
			}else{
				$this->integracao = new Integracoes( $this, 'CRY0001' );
			}
		}

		function setObjectEmail(){
			$this->obj_email = new Email();	
		}

		function index(){
			$this->lista();
		}

		function lista(){
			$records = json_decode( $this->modelo->getAgente() ); 
			require_once ABSPATH . '/views/'.$this->nome_view.'/index-view.php';	
		}

		function detalhe(){
			if( isset( $this->parametros[1] ) && !empty( $this->parametros[1] ) ){
				$records       = json_decode( $this->modelo->getAgente( $this->parametros[1] ) );
				$meta_endereco = $this->obj_metadados->getMetaInfo( 'agentecomercial', $this->parametros[1], 'endereco' );
				$meta_contatos = $this->obj_metadados->getMetaInfo( 'agentecomercial', $this->parametros[1], 'contato' );
			}
			$produto = json_decode( $this->produtos_modelo->getProduto( 4000001 ) );   
			$empresa = json_decode( $this->modelo->getEmpresasCMById( 1000003 ) ); 
			require_once ABSPATH . '/views/'.$this->nome_view.'/agentecomercial-detalhe-view.php';
		}

		function indices(){
			$this->modelo->setTable('contratos');
			$records  = json_decode($this->modelo->customGetRecords(null, null, true));
			require_once ABSPATH . '/views/'.$this->nome_view.'/indices-view.php';
		}

		function save(){
			try{
				$retorno['codigo']   = 1;
				if( count( $_POST ) == 0 || empty( $_POST ) ){
					$retorno['mensagem'] = 'Dados do conrtato não informados';
					throw new Exception(json_encode($retorno), 1);	
				}
				
				switch ( $_POST['tipo_documento'] ) {
					case 'cpf':
						$param['tipo_documento']   = $_POST['tipo_documento'];
						$param['numero_documento'] = removeCaracteres( $_POST['numero_documento'], 'char' );
						if( !validar( $param['numero_documento'], 'cpf' )){
							$retorno['mensagem'] = 'CPF inválido!';
							throw new Exception(json_encode($retorno), 1);
						}
					break;
					case 'cnpj':
						$param['tipo_documento'] 	= $_POST['tipo_documento'];
						$param['numero_documento'] 	= removeCaracteres( $_POST['numero_documento'], 'char' );
						$param['insc_municipal'] 	= removeCaracteres( $_POST['insc_municipal'], 'char' );
						$param['insc_estadual'] 	= removeCaracteres( $_POST['insc_estadual'], 'char' );
						if( !validar( $param['numero_documento'], 'cnpj' )){
							$retorno['mensagem'] = 'CNPJ inválido!';
							throw new Exception(json_encode($retorno), 1);
						}
					break;
					default:
						$retorno['mensagem'] = 'INFORME O CNPJ OU CPF';
						throw new Exception(json_encode($retorno), 1);
					break;
				}

				if( !empty( $this->parametros[1] ) && is_numeric( $this->parametros[1] ) ){
					$id_contrato = $this->parametros[1];
				}else{
					$id_contrato = null;
				}

				if( !empty( $_POST['razao_social'] ) ){
					$param['razao_social'] = $_POST['razao_social'];
				}else{
					$retorno['mensagem'] = 'INFORME A RAZÃO SOCIAL';
					throw new Exception( json_encode( $retorno ), 1 );
				}

				if( !empty( $_POST['nome'] ) ){
					$param['nome'] = $_POST['nome'];
				}else{
					$param['nome'] = $_POST['razao_social'];
				}

				if( !empty( $_POST['id_empresa'] ) ){
					$param['id_empresa'] = $_POST['id_empresa'];
				}else{
					$retorno['mensagem'] = 'INFORME A EMPRESA';
					throw new Exception( json_encode( $retorno ), 1 );
				}

				if( !empty( $_POST['id_produto'] ) ){
					$param['id_produto'] = $_POST['id_produto'];
				}else{
					$retorno['mensagem'] = 'INFORME O PRODUTO';
					throw new Exception( json_encode( $retorno ), 1 );
				}

				if( !empty( $_POST['data_assinatura'] ) ){
					$param['data_assinatura'] = convertDate( $_POST['data_assinatura'] );
				}else{
					$retorno['mensagem'] = 'INFORME A DATA DA ASSINATURA';
					throw new Exception( json_encode( $retorno ), 1 );
				}

				if( !empty( $_POST['duracao_contrato'] ) ){
					$param['duracao_contrato'] = $_POST['duracao_contrato'];
				}else{
					$param['duracao_contrato'] = 12;
				}

				if( !empty( $_POST['percentual_comissao'] ) ){
					$param['percentual_comissao'] = removeCaracteres( $_POST['percentual_comissao'], 'moeda2' );
				}else{
					$param['percentual_comissao'] = null;
				}
				
				if( !empty( $_POST['renovacao_automatica'] ) ){
					$param['renovacao_automatica'] = $_POST['renovacao_automatica'];
				}else{
					$param['renovacao_automatica'] = 0;
				}

				if( !empty( $_POST['status'] ) ){
					$param['status'] = $_POST['status'];
				}else{
					$param['status'] = 'ATIVO';
				}

				if( !empty( $_POST['info'] ) ){
					$param['info'] = $_POST['info'];
				}else{
					$param['info'] = null;
				}
				
				$ultimo_contrato = json_decode( $this->modelo->getLastContratoAgente() );
				$ultimo_codigo 	 = json_decode( $this->modelo->getLastCodigoAgente() );
				if( !isset( $this->parametros[1] ) || empty( $this->parametros[1] ) ){
					$ultimo_contrato 		  = json_decode( $this->modelo->getLastContratoAgente() );
					$ultimo_codigo 	 		  = json_decode( $this->modelo->getLastCodigoAgente() );
					$param['numero_contrato'] = ( $ultimo_contrato[0]->numero_contrato + 1);
					$param['codigo_agente']   = ( $ultimo_codigo[0]->codigo_agente + 1 );
				}
				
				$chk_contrato = json_decode( $this->modelo->getAgenteByCnpj( $param['numero_documento'] ) );
				$chk_produto  = json_decode( $this->produtos_modelo->getProduto( $_POST['id_produto'] ) );

				if( $chk_contrato && empty( $id_contrato ) ){
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Já existe um contrato com esse cnpj e esse produto!';
					throw new Exception( json_encode( $retorno ), 1 );
				}
				
				if( !$chk_produto ){
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Produto não encontrado!';
					throw new Exception( json_encode( $retorno ), 1 );
				}
				
				$save_agente = $this->modelo->save( $param, $id_contrato );
				if( $save_agente ){
					$retorno['codigo']   = 0;
					$retorno['input']    = $_POST;
					$retorno['output']   = $save_agente;
					$retorno['mensagem'] = 'Sucesso ao salvar registro na tabela '.$this->modelo->getTable();
					throw new Exception(json_encode($retorno), 1);
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = $this->modelo->info->mensagem;
					throw new Exception(json_encode($retorno), 1);
				}	
			}catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function getComissao(){
			try{
				if(!isset($this->parametros[0]) || empty($this->parametros[0])){
					$retorno['codigo']   = 1;				
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Erro id_contrato';
					throw new Exception(json_encode($retorno), 1);
				}else{
					$id_contrato = $this->parametros[0];
				}	
				
				$contrato = json_decode($this->modelo->getIfContrato($id_contrato));
				if(!isset($contrato) || empty($contrato)){
					$retorno['codigo']   = 1;				
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $id_contrato;
					$retorno['mensagem'] = 'Contrato ativo não encontrado';
					throw new Exception(json_encode($retorno), 1);
				}			

				$comissao = json_decode($this->modelo->getFullComissao($contrato[0]->id));
				if(!isset($comissao) || empty($comissao)){
					$retorno['codigo']   = 1;				
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $id_contrato;
					$retorno['mensagem'] = 'Erro ao obter comissão';
					throw new Exception(json_encode($retorno), 1);
				}			

				$retorno['codigo']   = 0;				
				$retorno['input']    = $contrato;
				$retorno['output']   = $comissao;
				$retorno['mensagem'] = 'Sucesso';
				throw new Exception(json_encode($retorno), 1);		
			}catch (Exception $e){
				echo $e->getMessage();
			}
		}

		function saveEndereco(){
			try {
				$retorno['codigo'] = 1;
				if( isset( $_POST ) && count( $_POST ) > 0 ){
					$is_save = null;
					$cep 	 = removeCaracteres( $_POST['cep'], 'char' );
					if( empty( $cep ) || !is_numeric( $cep ) ){
						$retorno['mensagem'] = 'CEP INVALIDO';
						throw new Exception( json_encode( $retorno ), 1 );
					}

					if( empty( $_POST['meta_id_origem'] ) || !is_numeric( $_POST['meta_id_origem'] ) ){
						$retorno['mensagem'] = 'ID DE ORIGEM INVALIDO';
						throw new Exception( json_encode( $retorno ), 1 );
					}

					if( !isset( $_POST['logradouro'] ) || empty( $_POST['logradouro'] ) ){
						$retorno['mensagem'] = 'Informe o logradouro';
						throw new Exception( json_encode( $retorno ), 1 );
					}

					if( !isset( $_POST['numero_logradouro'] ) || empty( $_POST['numero_logradouro'] ) ){
						$retorno['mensagem'] = 'Informe o numero logradouro';
						throw new Exception( json_encode( $retorno ), 1 );
					}

					if( !isset( $_POST['bairro'] ) || empty( $_POST['bairro'] ) ){
						$retorno['mensagem'] = 'Informe o bairro';
						throw new Exception( json_encode( $retorno ), 1 );
					}

					if( !isset( $_POST['cidade'] ) || empty( $_POST['cidade'] ) ){
						$retorno['mensagem'] = 'Informe a cidade';
						throw new Exception( json_encode( $retorno ), 1 );
					}

					if( !isset( $_POST['uf'] ) || empty( $_POST['uf'] ) ){
						$retorno['mensagem'] = 'Informe o estado';
						throw new Exception( json_encode( $retorno ), 1 );
					}

					if( !isset( $_POST['cep'] ) || empty( $_POST['cep'] ) ){
						$retorno['mensagem'] = 'Informe o CEP';
						throw new Exception( json_encode( $retorno ), 1 );
					}

					if( !isset( $_POST['pais_codigo'] ) || empty( $_POST['pais_codigo'] ) ){
						$retorno['mensagem'] = 'Informe o pais';
						throw new Exception( json_encode( $retorno ), 1 );
					}

					$meta_info['id_agente'] 		 = trim( $_POST['meta_id_origem'] );
					$meta_info['uniq_id']    		 = uniqid();
					$meta_info['tipo_logradouro']    = $_POST['tipo_logradouro'];
					$meta_info['logradouro']		 = $_POST['logradouro'];
					$meta_info['numero_logradouro']	 = $_POST['numero_logradouro'];
					$meta_info['complemento']		 = $_POST['complemento'];
					$meta_info['bairro']		 	 = $_POST['bairro'];
					$meta_info['cidade']		 	 = $_POST['cidade'];
					$meta_info['uf']		 		 = $_POST['uf'];
					$meta_info['pais_codigo']		 = $_POST['pais_codigo'];
					$meta_info['cep']		 		 = $cep;
					// checar se existe metadado de endereco para esse agente
					$enderecos = json_decode ( $this->obj_metadados->getMetaDados( 'agentecomercial', $_POST['meta_id_origem'], 'endereco' ) );
					if( $enderecos ){
						$infos				       = json_decode( $enderecos[0]->meta_info, 1 );
						$infos[] 				   = $meta_info;
						$param_update['meta_info'] = json_encode( $infos );
						$is_save = $this->obj_metadados->save( $param_update, $enderecos[0]->id );
					}else{
						$param_add['meta_info'] 		 = json_encode( array( $meta_info ) );
						$param_add['meta_campo'] 		 = 'endereco';
						$param_add['meta_tipo'] 		 = 'endereco';
						$param_add['meta_classificacao'] = $_POST['tipo_logradouro'];
						$param_add['meta_origem'] 		 = 'agentecomercial';
						$param_add['meta_id_origem'] 	 = $_POST['meta_id_origem'];
						$param_add['meta_valor'] 		 = 0;
						$param_add['alterado_por'] 	 	 = $_SESSION['cmswerp']['userdata']->id;
						$param_add['alterado_em'] 	 	 = $this->data_hora_atual->format('Y-m-d H:i');
						$param_add['deleted'] 		 	 = 0;
						$is_save = $this->obj_metadados->save( $param_add );
					}

					if( $is_save ){
						$retorno['codigo']   = 0;
						$retorno['mensagem'] = 'Sucesso';
						throw new Exception( json_encode( $retorno ), 1 );
					}else{
						$retorno['codigo']   = 1;
						$retorno['mensagem'] = 'Erro ao salvar o endereço';
						throw new Exception( json_encode( $retorno ), 1 );
					}
				}else{
					$retorno['mensagem'] = 'Nenhum dado encontrado';
				}
				throw new Exception( json_encode( $retorno ), 1 );
			} catch ( Exception $e ) {
				echo $e->getMessage();
			}
		}

		function saveContato(){
			try {
				$retorno['codigo'] = 1;
				if( isset( $_POST ) && count( $_POST ) > 0 ){
					if( empty( $_POST['meta_id_origem'] ) || !is_numeric( $_POST['meta_id_origem'] ) ){
						$retorno['mensagem'] = 'ID DE ORIGEM INVALIDO';
						throw new Exception( json_encode( $retorno ), 1 );
					}

					$meta_info['id_agente'] 		 = trim( $_POST['meta_id_origem'] );
					$meta_info['uniq_id']    		 = uniqid();
					$meta_info['tipo_contato']       = $_POST['tipo_contato'];
					$meta_info['tipo_classificacao'] = $_POST['tipo_classificacao'];
					switch ( strtolower( $_POST['tipo_contato'] ) ){
						case 'telefone':
							if( !isset( $_POST['numero_telefone'] ) || empty( $_POST['numero_telefone'] ) ){
								$retorno['mensagem'] = 'Informe o numero do telefone';
								throw new Exception( json_encode( $retorno ), 1 );
							}
							// checar se existe metadado de contato para esse agente
							$contatos = json_decode ( $this->obj_metadados->getMetaDadosByCampo( 'agentecomercial', $_POST['meta_id_origem'], 'telefone' ) );
							$param_add['meta_campo']      = 'telefone';
							$meta_info['tipo_telefone']   = $_POST['tipo_telefone'];
							$meta_info['numero_telefone'] = $_POST['numero_telefone'];
						break;
						case 'email':
							if( !isset( $_POST['email'] ) || empty( $_POST['email'] ) ){
								$retorno['mensagem'] = 'Informe o email';
								throw new Exception( json_encode( $retorno ), 1 );
							}
							$contatos = json_decode ( $this->obj_metadados->getMetaDadosByCampo( 'agentecomercial', $_POST['meta_id_origem'], 'email' ) );
							$param_add['meta_campo'] = 'email';
							$meta_info['email']      = $_POST['email'];
						break;
					}

					if( $contatos ){
						$infos				       = json_decode( $contatos[0]->meta_info, 1 );
						$infos[] 				   = $meta_info;
						$param_update['meta_info'] = json_encode( $infos );
						$is_save = $this->obj_metadados->save( $param_update, $contatos[0]->id );
					}else{
						$param_add['meta_info'] 		 = json_encode( array( $meta_info ) );
						$param_add['meta_tipo'] 		 = 'contato';
						$param_add['meta_classificacao'] = $_POST['tipo_classificacao'];
						$param_add['meta_origem'] 		 = 'agentecomercial';
						$param_add['meta_id_origem'] 	 = $_POST['meta_id_origem'];
						$param_add['meta_valor'] 		 = 0;
						$param_add['alterado_por'] 	 	 = $_SESSION['cmswerp']['userdata']->id;
						$param_add['alterado_em'] 	 	 = $this->data_hora_atual->format('Y-m-d H:i');
						$param_add['deleted'] 		 	 = 0;
						$is_save = $this->obj_metadados->save( $param_add );
					}

					if( $is_save ){
						$retorno['codigo']   = 0;
						$retorno['mensagem'] = 'Sucesso';
						throw new Exception( json_encode( $retorno ), 1 );
					}else{
						$retorno['codigo']   = 1;
						$retorno['mensagem'] = 'Erro ao salvar o endereço';
						throw new Exception( json_encode( $retorno ), 1 );
					}
				}else{
					$retorno['mensagem'] = 'Nenhum dado encontrado';
				}
				throw new Exception( json_encode( $retorno ), 1 );
			} catch ( Exception $e ) {
				echo $e->getMessage();
			}
		}

		function apagarMetaDados(){
			try {
				if( !isset( $_POST['id_agente'] ) || empty( $_POST['id_agente'] ) || !is_numeric( $_POST['id_agente'] ) ){
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Informe o ID do agente';
					throw new Exception( json_encode( $retorno ), 1 );
				}

				if( !isset( $_POST['id'] ) || empty( $_POST['id'] ) ){
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Informe o id';
					throw new Exception( json_encode( $retorno ), 1 );
				}
				$metadados = json_decode ( $this->obj_metadados->getMetaDados( 'agentecomercial', $_POST['id_agente'] ) );
				if( $metadados ){
					foreach ( $metadados as $key => $value) {
						$metainfo = json_decode( $value->meta_info );
						if( $metainfo ){
							foreach ( $metainfo as $k1 => $v1 ) {
								if( $_POST['id'] == $v1->uniq_id ){
									unset( $metainfo[$k1] );
									$param_update['meta_info'] = json_encode( $metainfo );
									$is_save = $this->obj_metadados->save( $param_update, $value->id );
									if( $is_save ){
										$retorno['codigo']   = 0;
										$retorno['mensagem'] = 'Sucesso 450';
										throw new Exception( json_encode( $retorno ), 1 );
									}else{
										$retorno['codigo']   = 1;
										$retorno['mensagem'] = 'Erro ao salvar apagar COD: 456';
										throw new Exception( json_encode( $retorno ), 1 );
									}
								}
							}
						}else{
							$retorno['codigo']   = 1;
							$retorno['mensagem'] = 'Erro ao salvar apagar COD: 458';
							throw new Exception( json_encode( $retorno ), 1 );
						}
					}
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Nenhum dado encontrado para apagar COD:463';
					throw new Exception( json_encode( $retorno ), 1 );
				}else{
					$retorno['mensagem'] = 'Dados não encontrados COD: 485';
					throw new Exception( json_encode( $retorno ), 1 );
				}
			} catch ( Exception $e ) {
				echo $e->getMessage();
			}
		}

		function syncCrystal(){
			try {
				if( isset( $this->parametros[1] ) && !empty( $this->parametros[1] ) && is_numeric( $this->parametros[1] ) ){
					$records    = json_decode( $this->modelo->getAgente( $this->parametros[1] ) );
					$meta_dados = json_decode( $this->modelo->getMetaDado( 'agentecomercial', $this->parametros[1] ) );
					if( $meta_dados ){
						foreach( $meta_dados as $key => $value ){
							$i1 = $value->meta_tipo;
							$i2 = $value->meta_classificacao;
							$i3 = $value->id_conjunto; 
							$i4 = $value->meta_campo;
							$metadados[$i1][$i2][$i3][$i4] = strtoupper( $value->meta_valor );
						}
					}

					if( !isset( $metadados['contato']['email'] ) || empty( $metadados['contato']['email'] ) ){
						$retorno['codigo'] 	= 1;
						$retonro['mensagem']= 'É obrigatorio incluir ao menos um email';
						throw new Exception( json_encode( $retorno ), 1 );
					}

					if( !isset( $metadados['contato']['telefone'] ) || empty( $metadados['contato']['telefone'] ) ){
						$retorno['codigo'] 	= 1;
						$retonro['mensagem']= 'É obrigatorio incluir ao menos um telefone';
						throw new Exception( json_encode( $retorno ), 1 );
					}

					$email 	  = reset( $metadados['contato']['email'] );
					$telefone = reset( $metadados['contato']['telefone'] );
					if( $email && $telefone ){
						$param['tax_id_number'] = $records[0]->numero_documento;
						$param['name'] 			= $records[0]->nome;
						$param['company_name'] 	= $records[0]->razao_social;
						$param['email'] 	   	= $email['email'];
						$param['phone'] 	   	= str_replace(' ','', removeCaracteres( $telefone['numero_telefone'], 'char' ) );
						$sync = json_decode( $this->integracao->exec('agente', 'cadastrar', $param ) );
						throw new Exception( json_encode( $sync ), 1 );
					}else{
						$retorno['codigo'] 	= 1;
						$retonro['mensagem']= 'Email ou telefone não encontrado';
						throw new Exception( json_encode( $retorno ), 1 );
					}
				}
			} catch ( Exception $e ) {
				echo $e->getMessage();
			}
		}
	}