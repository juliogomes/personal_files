<?php
	//error_reporting(E_ALL);
	//ini_set("display_errors", 1);
	class ApiController extends MainController{
		protected $token_acesso;
		protected $bearerToken;
		protected $endpoint;
		protected $tipo_endpoint;
		protected $objWs;
		protected $cod_ws;
		protected $dados;
		protected $metodo;
		protected $apiClass;
		protected $notificacaoClass;
		protected $integracaoClass;
		protected $wsModel;
		protected $output;
		public 	  $error = false;
		public 	  $msg_retorno;
		function __construct( $parametros = null, $do_login = false ){
			$this->setModulo( 'api' );
			$this->setView( 'api' );
			parent::__construct( $parametros, false, $do_login );
			$this->notificacaoClass = new Notificacoes( $this );
			$this->wsModel  		= $this->load_model( 'webservice/webservice', true );
			$this->cod_ws   		= ( isset( $this->parametros[0] ) )?$this->parametros[0]:null;
			$this->loadWs();
		}

		function getAuthorizationHeader(){
			$headers = null;
			if (isset($_SERVER['Authorization'])) {
				$headers = trim($_SERVER["Authorization"]);
			}else if (isset($_SERVER['HTTP_AUTHORIZATION'])) { //Nginx or fast CGI
				$headers = trim($_SERVER["HTTP_AUTHORIZATION"]);
			}elseif( function_exists('apache_request_headers') ){
				$requestHeaders = apache_request_headers();
				// Server-side fix for bug in old Android versions (a nice side-effect of this fix means we don't care about capitalization for Authorization)
				$requestHeaders = array_combine(array_map('ucwords', array_keys($requestHeaders)), array_values($requestHeaders));
				//print_r($requestHeaders);
				if (isset($requestHeaders['Authorization'])) {
					$headers = trim($requestHeaders['Authorization']);
				}
			}
			return $headers;
		}

		function getBearerToken() {
			$headers = $this->getAuthorizationHeader();
			// HEADER: Get the access token from the header
			if ( !empty( $headers ) ) {
				if ( preg_match( '/Bearer\s(\S+)/', $headers, $matches ) ) {
					$this->bearerToken = $matches[1];
					return $matches[1];
				}
			}
		}

		function loadWs(){
			$objWs = json_decode( $this->wsModel->getWsByCod( $this->cod_ws ) );
			if( $objWs ){
				$this->objWs = new stdClass();
				foreach ( $objWs as $key => $value ) {
					$i1 = $value->identificador;
					$this->objWs->id 	  	= $value->id;
					$this->objWs->id_login 	= $value->id_login;
					$this->objWs->codigo 	= $value->codigo;
					$this->objWs->descricao = $value->descricao;
					$this->objWs->status 	= $value->status;
					$obj = new StdClass();
					$obj->id   = $value->id_endpoint;
					$obj->url  = $value->url;
					$obj->tipo = $value->tipo;
					$obj->auth = $value->auth;
					$this->objWs->endpoints[$i1] = $obj;
				}
			}else{
				return false;
			}
		}

		function setLog(){
			$infoLocal = json_decode( $this->getLocalInfo() );
			$param['id_cadastro'] = $this->objWs->id;
			$param['id_endpoint'] = $this->endpoint->id;
			$param['id_login']    = $this->objWs->id_login;
			$param['ip'] 	  	  = $infoLocal->ip;
			$param['data_acesso'] = $this->data_hora_atual->format('Y-m-d H:i:s');
			$param['browser'] 	  = $infoLocal->browser;
			$param['alterado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
			if( $this->error ){
				$param['status'] = 'erro';
			}else{
				$param['status'] = 'ok';
			}
			$param['mensagem'] = $this->msg_retorno;
			$this->wsModel->setTable('ws_log');
			$this->wsModel->save( $param );
		}

		function gerarTokenAcesso(){
			if( !$this->checkToken() ){
				$validade = getDataAtual();
				$validade->add( new DateInterval( 'P2D' ) );
				$token_acesso 		   = base64_encode( openssl_random_pseudo_bytes( 512 ) );
				$param['id_login']     = $this->objWs->id_login;
				$param['token_acesso'] = $token_acesso;
				$param['validade']     = $validade->format('Y-m-d');
				$this->wsModel->setTable('ws_token');
				if( $this->wsModel->save( $param ) ){
					$this->token_acesso = $token_acesso;
					return true;
				}else{
					return false;
				}
			}else{
				return true;
			}
		}

		function getLastToken( ){
			return json_decode( $this->wsModel->getLastToken( $this->objWs->id_login ) );
		}

		function checkToken(){
			$token = $this->getLastToken();
			if( $token ){
				$validade = getDataAtual( $token[0]->validade );
				if( $validade > $this->data_hora_atual ){
					$this->token_acesso = $token[0]->token_acesso;
					return true;
				}else{
					return false;
				}
			}else{
				return false;
			}
		}

		function getToken(){
			$bearerToken = json_decode( $this->wsModel->getToken( $this->getBearerToken() ) );
			if( $bearerToken ){
				if( $bearerToken[0]->token_acesso == $this->getBearerToken() ){
					return true;
				}else{
					return false;
				}
			}else{
				return false;
			}
		}

		function loginWs(){
			try {
				if( !isset( $this->dados->usuario ) || empty( $this->dados->usuario ) ){
					$this->error = true;
					throw new Exception('informe o usuario');
				}

				if( !isset( $this->dados->senha ) || empty( $this->dados->senha ) ){
					$this->error = true;
					throw new Exception('informe a senha');
				}

				$login = json_decode( $this->wsModel->getLogin( $this->objWs->id, $this->dados->usuario, md5( $this->dados->senha ) ) );
				if( $login ){
					$this->objWs->id_login = $login[0]->id;
					if( $this->gerarTokenAcesso() ){
						$output['endpoints'] = $this->objWs->endpoints;
						$output['token'] 	 = $this->token_acesso;
						$this->error 	 	 = false;
						$this->output 	 	 = $output;
						throw new Exception('Login efetuado com sucesso');
					}else{
						$this->error = true;
						throw new Exception('Erro ao gerar token de acesso, verifique se o codigo, usuario e senha estão corretos COD: 196');
					}
				}else{
					$this->error = true;
					throw new Exception('Erro ao gerar token de acesso, verifique se o codigo, usuario e senha estão corretos COD: 200');
				}
			} catch ( Exception $e ) {
				$this->msg_retorno = $e->getMessage();
				$this->retorno();
			}
		}

		function getDados(){
			$this->metodo = strtoupper( $_SERVER['REQUEST_METHOD'] );
			switch ( $this->metodo ) {
				case 'GET':
					if( !$this->dados = json_decode( file_get_contents( 'php://input' ) ) ){
						$path = rtrim( $_GET['path'], '/');
						$this->dados = explode( '/', filter_var( $path, FILTER_SANITIZE_URL ) );
					}
				break;
				default:
					$this->dados = json_decode( file_get_contents( 'php://input' ) );
				break;
			}
		}

		function v1(){
			try {
				$retorno['codigo'] 	 = 1;
				$this->cod_ws 		 = ( isset( $this->parametros[0] ) )?trim($this->parametros[0] ):null;
				$endpoint 	  		 = ( isset( $this->parametros[1] ) )?trim($this->parametros[1] ):null;
				$this->tipo_endpoint = ( isset( $this->parametros[2] ) )?trim($this->parametros[2] ):null;
				$this->getDados();
				if( isset( $this->objWs->endpoints[ $endpoint ] ) ){
					$this->endpoint = $this->objWs->endpoints[$endpoint];
				}else{
					$this->error = true;
					throw new Exception('Endpoint '.$endpoint.' não encontrado');
				}
				
				if( $endpoint != 'auth' && !$this->getToken() ){
					$this->error = true;
					throw new Exception( 'Erro no token de acesso COD - 216: '.$endpoint );
				}
				
				switch ( $endpoint ) {
					case 'auth':
					    if( isset( $this->dados->usuario ) && isset( $this->dados->senha ) ){
							$this->loginWs( $this->cod_ws, $this->dados->usuario, $this->dados->senha );
						}else{
							$this->error = true;
							throw new Exception( 'Informe o usuario e senha para autenticação' );
						}
					break;
					case 'email':
						switch ( $this->metodo ) {
							case 'POST':
								if( $this->dados ){
									if( isset( $this->dados->from ) && !empty( $this->dados->from ) && !validar( $this->dados->from, 'email' ) ){
										$this->error = true;
										throw new Exception('Email '.$this->dados->from.' parece ser invalido' );
									}

									if( !validar( $this->dados->to, 'email') ){
										$this->error = true;
										throw new Exception('Email destinatario '.$this->dados->to.' parece ser invalido' );
									}

									// $param_envio['email']['nome_remetente']  = $this->dados->from_name;
									// $param_envio['email']['email_remetente'] = $this->dados->from;
									$param_envio['email']['destinatario'] 	 = $this->dados->to;
									$param_envio['email']['copia_oculta']    = SYSTEM_NOTIFY_TO;
									$param_envio['email']['assunto']         = $this->dados->subject;
									$param_envio['email']['mensagem']        = $this->dados->message;
									$is_send = json_decode( $this->notificacaoClass->sendNotificacao( 'alertas', $param_envio ) );
									if( $is_send ){
										$this->error = false;
										throw new Exception('Email enviado para '.$this->dados->to );
									}else{
										$this->error = true;
										throw new Exception('Erro ao enviar email para '.$this->dados->to );
									}
								}else{
									$this->error = true;
									throw new Exception('Informe os dados de envio de email');
								}
							break;
						}
					break;
					case 'token':
						if( $this->dados ){
							if( $this->tipo_endpoint ){
								switch ( $this->tipo_endpoint ) {
									case 'email':
										switch ( $this->metodo ) {
											case 'POST':
												if( !validar( $this->dados->cpfCnpj, 'cpf' ) ){
													$this->error  = false;
													throw new Exception('CPF invalido COD: 282');
												}

												$check_request = json_decode( $this->wsModel->getRequestNumeroRequest( $this->dados->cpfCnpj, 'email' ) );
												if( isset( $check_request[0]->input ) && !empty( $check_request[0]->input ) ){
													$info_check 		= json_decode( $check_request[0]->input );
													$this->dados->token = $info_check->token;
													$save_request 		= true;
												}else{
													$this->dados->status = 'ok';
													$this->dados->token  = gerarNumeroRandom();
													$save_request 	     = $this->saveRequest();
												}

												if( $save_request ){
													$this->error  = false;
													$this->output = $this->dados;
													throw new Exception('token email registrado com sucesso');
												}else{
													$this->error = true;
													throw new Exception('Erro ao finalizar request COD: 292');
												}
											break;
											case 'GET':
												if( !validar( $this->dados->chave, 'email' ) ){
													$this->error = false;
													throw new Exception( 'Email invalido: '.$this->dados->chave );
												}

												$token = json_decode( $this->wsModel->getRequestChaveRequest( $this->dados->chave, 'email' ) );
												if( $token ){
													$output['id'] 		  = $token[0]->id;
													$output['cpf'] 		  = $token[0]->numero_request;
													$output['tipo_chave'] = $token[0]->tipo; 
													$output['chave'] 	  = $token[0]->chave_request;
													$output['status'] 	  = $token[0]->status;
													$output['info'] 	  = $token[0]->input; 
													$this->error  = false;
													$this->output = $output;
													throw new Exception('Token Recuperado com sucesso COD: 304');
												}else{
													$this->error  = false;
													$this->output = null;
													throw new Exception('Nenhum token encontrado para chave email');
												}
											break;
										}
									break;
									case 'pix':
										switch ( $this->metodo ) {
											case 'POST':
												$tipo_chave    = null;
												$check_request = json_decode( $this->wsModel->getRequestChaveRequest( $this->dados->chave, 'pix' ) );
												if( isset( $check_request[0]->input ) && !empty( $check_request[0]->input ) && $check_request[0]->status == 'ok' ){
													$info_check 		= json_decode( $check_request[0]->input );
													$this->dados->token = $info_check->token;
													$save_request 		= true;
												}else{
													$this->dados->token    = gerarNumeroRandom('money');
													$this->integracaoClass = new Integracoes( $this, 'BRD0001' );
													$token_bradesco		   = json_decode( $this->integracaoClass->Exec( 'token', 'gerar' ) );
													if( isset( $token_bradesco->status ) && $token_bradesco->status == 'ok' ){
														$this->dados->id_unico = gerarNumeroRandom( 'unico', 20 );
														if( $this->dados->tipo_chave ){
															switch ( $this->dados->tipo_chave ) {
																case 'telefone':
																	$tipo_chave = "TELEFONE";
																break;
																case 'email':
																	$tipo_chave = "EMAIL";
																break;
																case 'aleatoria':
																	$tipo_chave = "EVP";
																break;
																case 'cpf':
																case 'cnpj':
																	$tipo_chave = "CPFCNPJ";
																break;
																case 'agendaconta':
																	$tipo_chave = "AGENCIACONTA";
																	$parametros['recebedor']['cpfCnpj'] 	 = $this->dados->cpfCnpj;
																	$parametros['recebedor']['tipo_conta'] 	 = $this->dados->tipo_conta;
																	$parametros['recebedor']['ispb'] 		 = $this->dados->ispb;
																	$parametros['recebedor']['agencia'] 	 = $this->dados->agencia;
																	$parametros['recebedor']['conta'] 		 = $this->dados->conta;
																	$parametros['recebedor']['digito_conta'] = $this->dados->digito_conta;
																	$parametros['recebedor']['banco'] 		 = $this->dados->banco;
																	$parametros['recebedor']['favorecido'] 	 = $this->dados->favorecido;
																break;
															}
														}else{
															$this->dados->status = 'erro';
															$this->dados->output = 'Tipo da chave invalida '.$this->dados->chave;
															throw new Exception( $this->dados->output );
														}

														$parametros['token_bradesco'] 				= $token_bradesco->output;
														$parametros['pagador']['tipoChave'] 		= 'EMAIL';
														$parametros['pagador']['chavePix']  		= 'rocketpix@cmsw.com';
														$parametros['recebedor']['tipoChave'] 		= $tipo_chave;
														$parametros['recebedor']['chavePix'] 		= $this->dados->chave;
														$parametros['valor']  						= $this->dados->token;
														$parametros['idtransacao']  				= $this->dados->id_unico;
														$parametros['descricao']  					= "Token de validação bradesco";
														$executar_pix = json_decode( $this->integracaoClass->Exec( 'pix', 'enviar', $parametros ) );
														$this->dados->status = $executar_pix->status;
														if( $executar_pix->status == 'ok' ){
															$this->dados->cpfCnpj 	 = $executar_pix->output->recebedor->cpfCnpj;
															$this->dados->favorecido = $executar_pix->output->recebedor->nomeFavorecido;
															$this->dados->status  	 = 'ok';
															$this->dados->output  	 = json_encode( $executar_pix->output );
														}else{
															$this->dados->status = 'erro';
															$this->dados->output = json_encode( $executar_pix->output );
														}
													}else{
														$this->dados->status = 'erro';
														$this->dados->output = 'Erro ao gerar token de segurança bradesco';
													}
													$save_request = $this->saveRequest();
												}
												if( $save_request && $this->dados->status == 'ok' ){
													$this->error  = false;
													$this->output = $this->dados->output;
													throw new Exception('token pix registrado com sucesso');
												}else{
													$this->error = true;
													throw new Exception('Erro ao finalizar request COD: 386');
												}
											break;
											case 'GET':
												$token = json_decode( $this->wsModel->getRequestChaveRequest( $this->dados->chave, 'pix' ) );
												// echo $token = $this->wsModel->getRequestChaveRequest( $this->dados->chave, 'pix' );
												// echo '<pre>';
												// 	var_dump( $this->dados, $token );
												// echo '</pre>';
												// exit;
												if( $token ){
													$output['id'] 		  = $token[0]->id;
													$output['cpf'] 		  = $token[0]->numero_request;
													$output['tipo_chave'] = $token[0]->tipo; 
													$output['chave'] 	  = $token[0]->chave_request;
													$output['status'] 	  = $token[0]->status;
													$output['info'] 	  = $token[0]->input; 
													$this->error  = false;
													$this->output = $output;
													throw new Exception('Token Recuperado com sucesso COD: 398');
												}else{
													$this->error  = false;
													$this->output = null;
													throw new Exception('Nenhum token encontrado para chave pix');
												}
											break;
										}
									break;
									case 'chave':
										switch ( $this->metodo ) {
											case 'GET':
												$token = json_decode( $this->wsModel->getRequestChaveRequest( $this->dados->chave ) );
												if( $token ){
													$this->error  = false;
													$this->output = $token;
													throw new Exception('Token Recuperado com sucesso COD: 418');
												}else{
													$this->error  = false;
													$this->output = null;
													throw new Exception('Nenhum token encontrado para chave: '.$this->dados->chave );
												}
											break;
										}
									break;
									case '*':
										switch ( $this->metodo ) {
											case 'GET':
												$token = json_decode( $this->wsModel->getRequestNumeroRequest( $this->dados->cpfCnpj ) );
												if( $token ){
													$output['cpf'] 		  = $token[0]->numero_request;
													$output['tipo_chave'] = $token[0]->tipo; 
													$output['chave'] 	  = $token[0]->chave_request;
													$output['status'] 	  = $token[0]->status;
													$output['info'] 	  = $token; 
													$this->error  = false;
													$this->output = $output;
													throw new Exception('Token Recuperado com sucesso COD: 438');
												}else{
													$this->error  = false;
													$this->output = null;
													throw new Exception('Nenhum token encontrado para este CPF: '.$this->dados->cpfCnpj );
												}
											break;
										}
									break;
									case 'validatoken':
										// echo '<pre>';
										// 	var_dump( $this->metodo );
										// echo '</pre>';
										switch ( $this->metodo ) {
											case 'POST':
												if( !isset( $this->dados->id ) || !is_numeric( $this->dados->id ) || empty( $this->dados->id ) ){
													$this->error = true;
													throw new Exception( 'Informe o ID para ser validado' );
												}

												if( !isset( $this->dados->flag ) || empty( $this->dados->flag ) ){
													$this->error = true;
													throw new Exception( 'Infome a flag de validação' );
												}
												
												switch ( $this->dados->flag ) {
													case 'validado':
														$param_save['flag'] = 'validado';
														$this->wsModel->setTable( 'ws_request' );
														$is_save = $this->wsModel->save( $param_save, $this->dados->id );
														if( $is_save ){
															$this->error = false;
															throw new Exception( 'Sucesso ao validar token' );
														}else{
															$this->error = true;
															throw new Exception( 'Erro ao validar token' );
														}
													break;
													default:
														$this->error = true;
														throw new Exception( 'Flag '.$this->dados->flag.' informado invalido' );
													break;
												}
											break;
										}
									break; 
									default:
										$this->error = true;
										throw new Exception( 'EndPoint '.$endpoint.' Default não implementado');
									break;
								}
							}else{
								$this->error = true;
								throw new Exception('Tipo do token não informado');
							}
						}else{
							$this->error = true;
							throw new Exception('Informe os dados de envio de email');
						}
					break;
					case 'rocket':
						$this->integracaoClass = new Integracoes( $this, 'FRA0143' );
						if( $this->integracaoClass->getId() ){
							$incluir = json_decode( $this->integracaoClass->Exec( 'fraude', 'incluir', $this->dados ) );
							if( $incluir->codigo == 0 ){
								$this->tipo_endpoint = 'rocket';
								$this->dados->token  = $incluir->mensagem;
								$this->output 		 = $incluir->mensagem;
								$this->error  		 = false;
								$this->saveRequest();
								throw new Exception('sucesso');
							}else{
								$this->error = true;
								throw new Exception( $incluir->mensagem );
							}
						}else{
							$this->error = true;
							throw new Exception( 'Erro ao carregar integração...' );
						}
					break;
					case 'cliente':
						$this->error	 = false;
						$contratos_model = $this->load_model( 'contratos/contratos', true );
						$notas_model 	 = $this->load_model( 'notas-fiscais/notas-fiscais', true );
						switch ( $this->tipo_endpoint ){
							case 'extrato':
								switch ( $this->metodo ) {
									case 'GET':
										$cnpj_cliente 	 = ( isset( $this->parametros[3] ) )?trim( $this->parametros[3] ):null;
										$produto_cliente = ( isset( $this->parametros[4] ) )?trim( $this->parametros[4] ):null;
										$data_inicial 	 = ( isset( $this->parametros[5] ) )?trim( $this->parametros[5] ):null;
										$data_final 	 = ( isset( $this->parametros[6] ) )?trim( $this->parametros[6] ):null;
										if( validarCNPJ( $cnpj_cliente ) ){
											$cnpj_cliente = substr( removeCaracteres( $cnpj_cliente, 'char' ), 0, -6 );
										}else{
											$this->error = true;
											throw new Exception( 'CNPJ invalido' );
										}
										switch ( strtoupper( $produto_cliente ) ) {
											case 'CRY0003':
												$codigo_produto = $dados_request['produto'];
											break;
											default:
												$this->error = true;
												throw new Exception( 'Informe o produto' );
											break;
										}

										if( !isset( $data_inicial ) || empty( $data_inicial ) ){
											$this->error = true;
											throw new Exception( 'Informe o periodo inicial' );
										}

										if( !isset( $data_final ) || empty( $data_final ) ){
											$this->error = true;
											throw new Exception( 'Informe o periodo final' );
										}

										$contratos  = json_decode( $contratos_model->contratosByCnpjeProduto( removeCaracteres( $cnpj_cliente, 'char') ) );
										$url 		= $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].'/report/extratoByPeriodo/'.$cnpj_cliente."/".$produto_cliente."/".$data_inicial."/".$data_final;
										$dados 		= json_decode( file_get_contents( $url ) );
										if( $dados ){
											$this->error  = false;
											$this->output = $dados;
											throw new Exception( 'sucesso' );
										}else{
											$this->error = true;
											throw new Exception( 'Nenhum dado encontrado' );
										}
									break;
									default:
									break;
								}
							break;
							case 'faturamento':
							break;
							default:
							break;
						}
					break;
				}
			} catch ( Exception $e ) {
				$this->msg_retorno = $e->getMessage();
				$this->retorno();
			}
		}

		function saveRequest(){
			$input['token'] 	 = $this->dados->token;
			$input['cpfCnpj']    = $this->dados->cpfCnpj;
			$input['favorecido'] = $this->dados->favorecido;
			$input['tipo_chave'] = $this->dados->tipo_chave;
			$input['chave']		 = $this->dados->chave;
			$input['email'] 	 = $this->dados->email;
			$infoLocal 			 			 = json_decode( getLocalInfo() );
			$param_request['id_endpoint'] 	 = $this->endpoint->id;
			$param_request['entrada'] 		 = 1;
			$param_request['tipo'] 		 	 = $this->tipo_endpoint;
			$param_request['url'] 			 = $infoLocal->url;
			$param_request['ip'] 			 = $infoLocal->ip;
			$param_request['browser'] 		 = $infoLocal->browser;
			$param_request['input'] 		 = json_encode( $input );
			$param_request['output'] 		 = $this->dados->output;
			$param_request['id_request'] 	 = $this->dados->id_unico;
			$param_request['status'] 		 = $this->dados->status;
			$param_request['chave_request']  = $this->dados->chave;
			$param_request['numero_request'] = $this->dados->cpfCnpj;
			$param_request['data'] 		 	 = $this->data_hora_atual->format('Y-m-d H:i:s');
			$this->wsModel->setTable('ws_request');
			return $this->wsModel->save( $param_request );
		}

		function retorno(){
			// $this->setLog();
			if( $this->error ){
				$retorno['status'] = 'erro';
			}else{
				$retorno['status'] = 'ok';	
			}
			$retorno['output'] 	 = $this->output;
			$retorno['mensagem'] = $this->msg_retorno;
			echo json_encode( $retorno );
		}

		function crystal(){
			try {
				$request_method   = $_SERVER['REQUEST_METHOD'];
				$request_uri      = $_SERVER['REQUEST_URI'];
				$obj_crystal      = new RotinaCrystal( $this );
				$obj_assinatura   = new Assinatura( $this, 'd4sign' );
				$base_point		  = ( isset( $this->parametros[0] ) )?$this->parametros[0]:null; 
				$end_point 	 	  = ( isset( $this->parametros[1] ) )?$this->parametros[1]:null;
				$agente_model     = $this->load_model( 'agentecomercial/agentecomercial', true );
				$produtos_model   = $this->load_model( 'produtos/produtos', true );
				switch ( $request_method ) {
					case 'GET':
						$dados_request = filter_input_array(INPUT_GET,FILTER_DEFAULT);		
					break;
					default:
						$dados_request = json_decode( file_get_contents( 'php://input' ) );
					break;
				}

				if( 'producao' == TIPO_AMBIENTE ){
					if( $this->getBearerToken() != 'CTBT@2023?' ){
						$retorno['status']   = 'erro';
						$retorno['mensagem'] = 'Token invalido';
						throw new Exception( json_encode( $retorno ), 1 );
					}
				}else{
					if( $this->getBearerToken() != 'CRYSTAL202310' ){
						$retorno['status']   = 'erro';
						$retorno['mensagem'] = 'Token invalido';
						throw new Exception( json_encode( $retorno ), 1 );
					}
				}
				
				switch( $base_point ){
					case 'cliente':
						$contratos_model = $this->load_model( 'contratos/contratos', true );
						switch ( $end_point ){
							case 'add':
								if( isset( $dados_request->contrato ) && !empty( $dados_request->contrato ) ){
									$contrato = $dados_request->contrato;
									if( !validar( removeCaracteres( $contrato->cnpj_agente, 'char'), 'cnpj' ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'CNPJ Agente invalido';
										throw new Exception( json_encode( $retorno ), 1 );
									}

									if( !validar( removeCaracteres( $contrato->cnpj_crystal, 'char'), 'cnpj' ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'CNPJ Crystal invalido';
										throw new Exception( json_encode( $retorno ), 1 );
									}else{
										$empresa_cm = json_decode( $contratos_model->getEmpresasCM( null, removeCaracteres( $contrato->cnpj_crystal, 'char') ) );
										if( !$empresa_cm ){
											$retorno['status']   = 'erro'; 
											$retorno['mensagem'] = 'Empresa Crystal não encontrada';
											throw new Exception( json_encode( $retorno ), 1 );
										}
									}

									if( !isset( $contrato->cnpj_cliente ) || empty( $contrato->cnpj_cliente ) ){
										$retorno['status']   = 'erro';
										$retorno['mensagem'] = 'Informe o CNPJ ou CPF do contrato';
										throw new Exception( json_encode( $retorno ), 1 );
									}else{
										$cnpj_cpf_cliente = removeCaracteres( $contrato->cnpj_cliente, 'char' );
									}

									// verificando tipo de pessoa
									if( strlen( removeCaracteres( $contrato->cnpj_cliente, 'char') ) > 11 ){ //pessoa juridica
										if( !validar( removeCaracteres( $contrato->cnpj_cliente, 'char'), 'cnpj' ) ){
											$retorno['status']   = 'erro'; 
											$retorno['mensagem'] = 'CNPJ invalido';
											throw new Exception( json_encode( $retorno ), 1 );
										}
										$codigo_cliente	= substr( removeCaracteres( $contrato->cnpj_cliente, 'char' ), 0, -6 ); 
									}else{ // pessoa fisica
										if( !validar( removeCaracteres( $contrato->cnpj_cliente, 'char'), 'cpf' ) ){
											$retorno['status']   = 'erro'; 
											$retorno['mensagem'] = 'CPF invalido';
											throw new Exception( json_encode( $retorno ), 1 );
										}
										$codigo_cliente	  = removeCaracteres( $contrato->cnpj_cliente, 'char' );
									}

									if( !isset( $contrato->razao_social ) || empty( $contrato->razao_social ) ){
										$retorno['status']   = 'erro';
										$retorno['mensagem'] = 'Razao social invalido';
										throw new Exception(json_encode($retorno), 1);
									}

									if( !isset($contrato->nome_fantasia) || empty($contrato->nome_fantasia ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'Informe o nome fantasia';
										throw new Exception( json_encode( $retorno ), 1 );
									}

									if( !isset( $contrato->segmento ) || empty( $contrato->segmento ) ){
										$ifcontrato['segmento'] = 'financeiro';
									}else{
										$ifcontrato['segmento'] = $contrato->segmento;
									}

									if( !isset($contrato->inscricao_estadual) || empty($contrato->inscricao_estadual ) ){
										$ifcontrato['inscricao_estadual'] = null;
									}

									if( !isset( $contrato->inscricao_municipal ) || empty( $contrato->inscricao_municipal ) ){
										$ifcontrato['inscricao_municipal'] = null;
									}

									if( !isset( $contrato->codigo_produto ) || empty( $contrato->codigo_produto ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'Informe o codigo produto';
										throw new Exception( json_encode( $retorno ), 1 );
									}else{
										$get_produto = json_decode( $produtos_model->getProdutoByCodigo( $contrato->codigo_produto ) );
										if( isset( $get_produto ) && !empty( $get_produto ) ){
											$ifcontrato['id_produto'] = $get_produto[0]->id;
										}else{
											$retorno['status']   = 'erro'; 
											$retorno['mensagem'] = 'Erro ao obter produto, codigo do produto inválido';
											throw new Exception( json_encode( $retorno ), 1 );
										}                                            
									}

									$check_contrato	  = json_decode( $agente_model->getfContratoByCnpj( $cnpj_cpf_cliente ) );
									if( $check_contrato ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'Contrato já existe';
										throw new Exception( json_encode( $retorno ), 1 );
									}
									
									// capturar agente comercial
									$dados_agente = json_decode( $agente_model->getAgenteByCnpj( $contrato->cnpj_agente ) );
									if( $dados_agente ){
										$ifcontrato['id_agente'] = $dados_agente[0]->id;
									}else{
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'Agente comercial não encontrado';
										throw new Exception( json_encode( $retorno ), 1 );
									}
									
									$ifcontrato['id_proposta'] 	   	= 0;
									$ifcontrato['id_contrato'] 	   	= null;
									$ifcontrato['numero_contrato']  = $contrato->codigo_produto.$this->data_hora_atual->format('YmdHi');
									$ifcontrato['cnpj'] 		   	= $cnpj_cpf_cliente;
									$ifcontrato['razao_social'] 	= $contrato->razao_social;
									$ifcontrato['nome_fantasia'] 	= $contrato->nome_fantasia;
									$ifcontrato['id_produto'] 		= $get_produto[0]->id;
									$ifcontrato['status'] 		    = 'ativo';
									$ifcontrato['codigo_cliente'] 	= $codigo_cliente;
									$ifcontrato['finalizado'] 		= 0;
									$ifcontrato['alterado_por']		= null;
									$ifcontrato['alterado_em']		= $this->data_hora_atual->format('Y-m-d H:i:s');
									$ifcontrato['deleted']			= 0;
									
									$agente_model->setTable("if_contrato");
									$save_ifcontrato = $agente_model->save( $ifcontrato );
									if( !$save_ifcontrato ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'Erro em salvar contrato';
										throw new Exception(json_encode($retorno), 1);
									}

									$ifendereco['id_contrato'] 	= $save_ifcontrato;
									$ifendereco['endereco'] 	= $contrato->logradouro;
									$ifendereco['numero'] 		= $contrato->numero_logradouro;
									$ifendereco['complemento']  = $contrato->complemento;
									$ifendereco['cep'] 			= removeCaracteres( $contrato->cep, 'char');
									$ifendereco['bairro'] 		= $contrato->bairro;
									$ifendereco['cidade'] 		= $contrato->cidade;
									$ifendereco['estado'] 		= $contrato->uf;
									$ifendereco['tipo_endereco'] = 'principal';
									$ifendereco['alterado_por'] = 1;

									$agente_model->setTable("if_endereco");
									$save_endereco = $agente_model->save($ifendereco);
									if( !$save_endereco ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'Erro em salvar endereço';
										throw new Exception(json_encode($retorno), 1);
									}
									
									$agente_model->setTable("if_contato");
									$contrato_representante['id_contrato'] 	= $save_ifcontrato;
									$contrato_representante['origem']       = "minuta";
									$contrato_representante['cpf'] 			= $contrato->cpf_representante_legal;
									$contrato_representante['tipo_contato'] = "responsavel_legal";
									$contrato_representante['nome'] 		= $contrato->nome_representante_legal;
									$contrato_representante['email'] 		= $contrato->email_representante_legal;
									$contrato_representante['telefone'] 	= $contrato->telefone_representante_legal;
									$contrato_representante['alterado_por'] = 1;
									$save_representante = $agente_model->save($contrato_representante);
									if( !$save_representante ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'Erro em salvar representante';
										throw new Exception(json_encode($retorno), 1);
									}

									$contato_financeiro['id_contrato'] 		= $save_ifcontrato;
									$contato_financeiro['origem']       	= "minuta";
									$contato_financeiro['cpf']           	= $contrato->cpf_representante_financeiro;
									$contato_financeiro['tipo_contato']  	= "financeiro";
									$contato_financeiro['nome'] 			= $contrato->nome_representante_financeiro;
									$contato_financeiro['email'] 			= $contrato->email_representante_financeiro;
									$contato_financeiro['telefone'] 		= $contrato->telefone_representante_financeiro;
									$contato_financeiro['alterado_por'] 	= 1;
									$save_financeiro = $agente_model->save($contato_financeiro);
									if( !$save_financeiro ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'Erro em salvar financeiro';
										throw new Exception(json_encode($retorno), 1);
									}

									$contato_testemunha['id_contrato'] 	= $save_ifcontrato;
									$contato_testemunha['origem']      	= "minuta";
									$contato_testemunha['cpf'] 			= $contrato->cpf_representante_testemunha;
									$contato_testemunha['tipo_contato']	= "testemunha";
									$contato_testemunha['nome'] 		= $contrato->nome_representante_testemunha;
									$contato_testemunha['email'] 		= $contrato->email_representante_testemunha;
									$contato_testemunha['telefone'] 	= $contrato->telefone_representante_testemunha;
									$contato_testemunha['alterado_por'] = 1;
									$save_testemunha = $agente_model->save($contato_testemunha);
									if( !$save_testemunha ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'Erro em salvar testemunha';
										throw new Exception(json_encode($retorno), 1);
									}

									if( !isset( $contrato->preco_com_imposto ) || empty( $contrato->preco_com_imposto ) ){
										$faturamento['preco_imposto'] = 0;
									}

									if( !isset( $contrato->reajuste ) || empty( $contrato->reajuste ) ){
										$faturamento['reajuste'] = 'igpm';
									}else{
										$faturamento['reajuste'] = $contrato->indice_reajute;
									}

									if( !isset( $contrato->faturamento_todo_dia ) || empty( $contrato->faturamento_todo_dia ) ){
										$faturamento['faturamento_todo_dia'] = '28';
									}else{
										$faturamento['faturamento_todo_dia']  = $contrato->dia_corte;
									}

									$faturamento['id_contrato']       	  	  = $save_ifcontrato;
									$faturamento['empresa_vendedora'] 	  	  = $empresa_cm[0]->razao_social;
									$faturamento['id_empresa'] 	  		  	  = $empresa_cm[0]->id;
									$faturamento['data_assinatura'] 	  	  = null;
									$faturamento['data_reajuste'] 	  	  	  = null;
									$faturamento['duracao_contrato']  	  	  = "36 meses";
									$faturamento['renovacao_automatica']  	  = 1;
									$faturamento['indeterminado']  		  	  = 0;
									$faturamento['moeda']             	  	  = "real";
									$faturamento['implantacao']       	  	  =  null;
									$faturamento['parcelas']          	  	  = 1;
									$faturamento['primeira_parcela']      	  = null;
									$faturamento['percentual_multa']  	  	  = 2;
									$faturamento['percentual_juros']  	  	  = 1;
									$faturamento['tipo_data_faturamento'] 	  = "dias_apos_faturamento";     
									$faturamento['dias_apos_faturamento'] 	  = "5";
									$faturamento['vencimento_todo_dia']   	  = null;
									$faturamento['data_primeiro_faturamento'] = null;
									$faturamento['data_producao'] 			  = null;
									$faturamento['alterado_por']      	  	  = null;
									$faturamento['alterado_em']      	  	  = $this->data_hora_atual->format('Y-m-d H:i:s');
									$faturamento['deleted']      	  	  	  = 0;
									$agente_model->setTable("if_faturamento");
									$save_faturamento = $agente_model->save( $faturamento );
									if( !$save_faturamento ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'Erro em salvar faturamento';
										throw new Exception( json_encode($retorno ), 1 );
									}
									$retorno['status']   = 'ok';        
									$retorno['id']       = $save_ifcontrato;
									$retorno['mensagem'] = 'Sucesso';
									throw new Exception(json_encode($retorno), 1);
								}else{
									$retorno['status']   = 'validacao';
									$retorno['mensagem'] = 'Dados invalidos';
								}
							break;
							case 'list':
								if( isset( $dados_request['produto'] ) && !empty( $dados_request['produto'] ) ){
									$dados_request['produto'] = strtoupper( $dados_request['produto'] );
									switch ( $dados_request['produto'] ) {
										case 'CRY0001':
										case 'CRY0002':
										case 'CRY0003':
											$codigo_produto = $dados_request['produto'];
										break;
										default:
											$retorno['status']   = 'erro'; 
											$retorno['mensagem'] = 'Informe o produto';
											throw new Exception( json_encode( $retorno ), 1 );
										break;
									}
								}else{
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o produto';
									throw new Exception( json_encode( $retorno ), 1 );
								}
								
								if( !isset( $dados_request['cnpj_cpf'] ) || empty( $dados_request['cnpj_cpf'] ) ){
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o CNPJ ou CPF';
									throw new Exception( json_encode( $retorno ), 1 );
								}
								
								// verificando tipo de pessoa
								if( strlen( removeCaracteres( $dados_request['cnpj_cpf'], 'char') ) > 11 ){ //pessoa juridica
									if( !validar( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), 'cnpj' ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'CNPJ invalido';
										throw new Exception( json_encode( $retorno ), 1 );
									}
									$CnpjCpf	= removeCaracteres( $dados_request['cnpj_cpf'], 'char' ); 
								}else{ // pessoa fisica
									if( !validar( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), 'cpf' ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'CPF invalido';
										throw new Exception( json_encode( $retorno ), 1 );
									}
									$CnpjCpf	= removeCaracteres( $dados_request['cnpj_cpf'], 'char' );
								}

								$contratos = json_decode( $agente_model->getClientesPorCnpjProduto( $CnpjCpf, $codigo_produto ) );
								if( $contratos ){
									$retorno['status'] = 'ok'; 
									$retorno['dados']  = $contratos;
									throw new Exception( json_encode( $retorno ), 1 );
								}else{
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Cliente não encontrado';
									throw new Exception( json_encode( $retorno ), 1 );
								}
							break;
							case 'faturamento':
								if( isset( $dados_request['status'] ) && !empty( $dados_request['status'] ) ){
									switch ( strtoupper( $dados_request['status'] ) ) {
										case 'RECEBER':
										case 'ABERTO':
											$status_nf = 'receber';
										break;
										case 'RECEBIDO':
										case 'LIQUIDADO':
											$status_nf = 'recebido';
										break;
									}
								}else{
									$status_nf = null;
								}

								if( isset( $dados_request['produto'] ) && !empty( $dados_request['produto'] ) ){
									switch ( strtoupper( $dados_request['produto'] ) ) {
										case 'CRY0001':
										case 'CRY0002':
										case 'CRY0003':
											$codigo_produto = $dados_request['produto'];
										break;
										default:
											$retorno['status']   = 'erro'; 
											$retorno['mensagem'] = 'Informe o produto';
											throw new Exception( json_encode( $retorno ), 1 );
										break;
									}
								}else{
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o produto';
									throw new Exception( json_encode( $retorno ), 1 );
								}

								if( !isset( $dados_request['periodo_ini'] ) || empty( $dados_request['periodo_ini'] ) ){
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o periodo inicial';
									throw new Exception( json_encode( $retorno ), 1 );
								}

								if( !isset( $dados_request['periodo_fim'] ) || empty( $dados_request['periodo_fim'] ) ){
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o periodo final';
									throw new Exception( json_encode( $retorno ), 1 );
								}
								
								if( !isset( $dados_request['cnpj_cpf'] ) || empty( $dados_request['cnpj_cpf'] ) ){
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o CNPJ ou CPF';
									throw new Exception( json_encode( $retorno ), 1 );
								}

								// verificando tipo de pessoa
								if( strlen( removeCaracteres( $dados_request['cnpj_cpf'], 'char') ) > 11 ){ //pessoa juridica
									if( !validar( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), 'cnpj' ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'CNPJ contrato invalido';
										throw new Exception( json_encode( $retorno ), 1 );
									}
									$codigo_cliente	= removeCaracteres( $dados_request['cnpj_cpf'], 'char' );
								}else{ // pessoa fisica
									if( !validar( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), 'cpf' ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'CPF contrato invalido';
										throw new Exception( json_encode( $retorno ), 1 );
									}
									$codigo_cliente	= removeCaracteres( $dados_request['cnpj_cpf'], 'char' );
								}
								
								$notas_model 	 = $this->load_model( 'notas-fiscais/notas-fiscais', true );
								$dt_ini 		 = getDataAtual( $dados_request['periodo_ini'] );
								$dt_fim 		 = getDataAtual( $dados_request['periodo_fim'] );
								$pesquisa_ini 	 = $dt_ini->format('Y-m-d');
								$pesquisa_fim 	 = $dt_fim->format('Y-m-d');
								$cliente = json_decode( $agente_model->getClientesPorCnpjProduto( $codigo_cliente, $codigo_produto ) );
								if( $cliente ){
									foreach ( $cliente as $key => $value ) {
										$ids[] = $value->id;
									}
									$notas_fiscais = json_decode( $notas_model->getNotasByPeriodoEcontrato( $pesquisa_ini, $pesquisa_fim, $ids, 'emissao', $status_nf ) );
									if( $notas_fiscais ){
										$faturamento = null;
										foreach ( $notas_fiscais as $key => $value ) {
											$i2 = $value->cnpj_cpf_cliente;
											$i3 = $value->id;
											$faturamento[$i2]['razao_social'] 	  			 	     = $value->cliente;
											$faturamento[$i2]['search_ini']							 = $dt_ini;
											$faturamento[$i2]['search_fim']							 = $dt_fim;
											$faturamento[$i2]['totais']['valor_liquido']   			 += $value->valor_liquido;
											$faturamento[$i2]['totais']['valor_fatura']   			 += $value->valor_fatura;
											$faturamento[$i2]['totais']['valor_total']    			 += $value->valor_total;
											$faturamento[$i2]['totais']['valor_desconto'] 			 += $value->valor_desconto;
											$faturamento[$i2]['totais']['valor_impostos'] 			 += $value->valor_impostos;
											$faturamento[$i2]['totais']['fatura'] 		  			 += $value->valor_fatura;
											$faturamento[$i2]['faturamento'][$i3]['valor_fatura'] 	 = $value->valor_fatura;
											$faturamento[$i2]['faturamento'][$i3]['valor_total'] 	 = $value->valor_total;
											$faturamento[$i2]['faturamento'][$i3]['valor_desconto']  = $value->valor_desconto;
											$faturamento[$i2]['faturamento'][$i3]['valor_impostos']  = $value->valor_impostos;
											$faturamento[$i2]['faturamento'][$i3]['data_emissao'] 	 = $value->data_emissao;
											$faturamento[$i2]['faturamento'][$i3]['data_vencimento'] = $value->data_vencimento;
											$faturamento[$i2]['faturamento'][$i3]['status'] 	 	 = $value->status;
											$faturamento[$i2]['faturamento'][$i3]['recebido_em'] 	 = $value->recebido_em;
										}
										$retorno['status'] = 'ok'; 
										$retorno['output'] = $faturamento;
										throw new Exception( json_encode( $retorno ), 1 );
									}else{
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'Nenhuma nota fiscal não encontrado';
										throw new Exception( json_encode( $retorno ), 1 );	
									}
								}else{
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'cliente não encontrado';
									throw new Exception( json_encode( $retorno ), 1 );
								}
							break;
							case 'extrato':
								if( isset( $dados_request['produto'] ) && !empty( $dados_request['produto'] ) ){
									switch ( strtoupper( $dados_request['produto'] ) ) {
										case 'CRY0001':
										case 'CRY0002':
										case 'CRY0003':
											$codigo_produto = $dados_request['produto'];
										break;
										default:
											$retorno['status']   = 'erro'; 
											$retorno['mensagem'] = 'Informe o produto';
											throw new Exception( json_encode( $retorno ), 1 );
										break;
									}
								}else{
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o produto';
									throw new Exception( json_encode( $retorno ), 1 );
								}

								if( !isset( $dados_request['periodo_ini'] ) || empty( $dados_request['periodo_ini'] ) ){
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o periodo inicial';
									throw new Exception( json_encode( $retorno ), 1 );
								}

								if( !isset( $dados_request['periodo_fim'] ) || empty( $dados_request['periodo_fim'] ) ){
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o periodo final';
									throw new Exception( json_encode( $retorno ), 1 );
								}
								
								if( !isset( $dados_request['cnpj_cpf'] ) || empty( $dados_request['cnpj_cpf'] ) ){
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o CNPJ ou CPF';
									throw new Exception( json_encode( $retorno ), 1 );
								}

								// verificando tipo de pessoa
								if( strlen( removeCaracteres( $dados_request['cnpj_cpf'], 'char') ) > 11 ){ //pessoa juridica
									if( !validar( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), 'cnpj' ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'CNPJ contrato invalido';
										throw new Exception( json_encode( $retorno ), 1 );
									}
									$CnpjCpf = substr( removeCaracteres( $dados_request['cnpj_cpf'], 'char' ), 0, -6 );
								}else{ // pessoa fisica
									if( !validar( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), 'cpf' ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'CPF contrato invalido';
										throw new Exception( json_encode( $retorno ), 1 );
									}
									$CnpjCpf = removeCaracteres( $dados_request['cnpj_cpf'], 'char' );
								}
								
								$contratos 	  = json_decode( $contratos_model->contratosByCnpjeProduto( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), $dados_request['produto'] ) );
								$dt_ini 	  = getDataAtual( $dados_request['periodo_ini'] );
								$dt_fim 	  = getDataAtual( $dados_request['periodo_fim'] );
								$pesquisa_ini = $dt_ini->format('Y-m-d');
								$pesquisa_fim = $dt_fim->format('Y-m-d');
								if( $contratos ){
									$url = $_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].'/report/extratoByPeriodo/'.$CnpjCpf."/".$codigo_produto."/".$pesquisa_ini."/".$pesquisa_fim;
									$dados = json_decode( file_get_contents( $url ) );
									if( isset( $dados ) ){
										$retorno['status'] = 'ok'; 
										$retorno['output'] = $dados;
										throw new Exception( json_encode( $retorno ), 1 );
									}else{
										$retorno['status'] = 'erro'; 
										$retorno['output'] = 'Dados não encontrados';
										throw new Exception( json_encode( $retorno ), 1 );
									}
								}else{
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'cliente não encontrado';
									throw new Exception( json_encode( $retorno ), 1 );
								}
							break;
							default:
								$retorno['status']   = 'erro';
								$retorno['mensagem'] = 'END POINT ERRO';
								throw new Exception( json_encode( $retorno ), 1 );
							break;
						}
					break;
					case 'contrato':
						switch ( $end_point ){
							case 'list':
								if( isset( $dados_request['produto'] ) && !empty( $dados_request['produto'] ) ){
									switch ( strtoupper( $dados_request['produto'] ) ) {
										case 'CRY0001':
										case 'CRY0002':
										case 'CRY0003':
											$codigo_produto = $dados_request['produto'];
										break;
										default:
											$retorno['status']   = 'erro'; 
											$retorno['mensagem'] = 'Informe o produto';
											throw new Exception( json_encode( $retorno ), 1 );
										break;
									}
								}else{
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o produto';
									throw new Exception( json_encode( $retorno ), 1 );
								}

								if( !isset( $dados_request['cnpj_cpf'] ) || empty( $dados_request['cnpj_cpf'] ) ){
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o CNPJ ou CPF';
									throw new Exception( json_encode( $retorno ), 1 );
								}
								
								// verificando tipo de pessoa
								if( strlen( removeCaracteres( $dados_request['cnpj_cpf'], 'char') ) > 11 ){ //pessoa juridica
									if( !validar( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), 'cnpj' ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'CNPJ contrato invalido';
										throw new Exception( json_encode( $retorno ), 1 );
									}
									$codigo_cliente	= substr( removeCaracteres( $dados_request['cnpj_cpf'], 'char' ), 0, -6 ); 
								}else{ // pessoa fisica
									if( !validar( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), 'cpf' ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'CPF contrato invalido';
										throw new Exception( json_encode( $retorno ), 1 );
									}
									$codigo_cliente	= removeCaracteres( $dados_request['cnpj_cpf'], 'char' );
								}
								
								// verificando tipo de pessoa
								if( strlen( removeCaracteres( $dados_request['cnpj_cpf'], 'char') ) > 11 ){ //pessoa juridica
									if( !validar( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), 'cnpj' ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'CNPJ do contrato invalido';
										throw new Exception( json_encode( $retorno ), 1 );
									}
									$codigo_cliente	= removeCaracteres( $dados_request['cnpj_cpf'], 'char' ); 
								}else{ // pessoa fisica
									if( !validar( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), 'cpf' ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'CPF invalido';
										throw new Exception( json_encode( $retorno ), 1 );
									}
									$codigo_cliente	= removeCaracteres( $dados_request['cnpj_cpf'], 'char' );
								}

								$contratos = json_decode( $agente_model->getfContratoByCnpjProduto( $codigo_cliente, $codigo_produto ) );
								if( $contratos ){
									foreach ( $contratos as $key => $value ){
										$contrato = json_decode( $obj_assinatura->getIfDocumentoAssinaturaByCnpj( $value->cnpj, 'd4sign' ) );
										if( $contrato ){
											$assinatura = json_decode( $obj_assinatura->statusAssinaturaDocumento( $contrato[0]->document_key ) );
											if( $assinatura->codigo == 0 ){
												// $dados_assinatura = $assinatura->output
												$dados_retorno['cnpj_cpf'] 	      = $value->cnpj;
												$dados_retorno['razao_social'] 	  = $value->razao_social;
												$dados_retorno['codigo_produto']  = $value->codigo_produto;
												$dados_retorno['nome_produto'] 	  = $value->nome_produto;
												$dados_retorno['status_contrato'] = $value->status;
												$dados_retorno['id_doc'] 		  = $assinatura->output->id_doc ;
												$dados_retorno['nome_doc'] 		  = $assinatura->output->nome_doc ;
												$dados_retorno['cod_assinatura']  = $assinatura->output->id_status;
												$dados_retorno['txt_assinatura']  = $assinatura->output->nome_status;
												$dados_retorno['obs_status'] 	  = $assinatura->output->obs_status;
												$retorno['status']   = 'ok'; 
												$retorno['output'] = $dados_retorno;
												throw new Exception( json_encode( $retorno ), 1 );
											}else{
												$retorno['status']   = 'erro'; 
												$retorno['mensagem'] = $assinatura->mensagem;
												throw new Exception( json_encode( $retorno ), 1 );
											}
										}else{
											$retorno['status']   = 'erro'; 
											$retorno['mensagem'] = 'Contrato não encontrado para assinatura';
											throw new Exception( json_encode( $retorno ), 1 );
										}
									}
									$retorno['status'] = 'ok'; 
									$retorno['dados']  = $contratos;
									throw new Exception( json_encode( $retorno ), 1 );
								}else{
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Nenhum contrato encontrado';
									throw new Exception( json_encode( $retorno ), 1 );
								}
							break;
							default:
								$retorno['status']   = 'erro'; 
								$retorno['mensagem'] = 'END POINT UNKNOW';
								throw new Exception( json_encode( $retorno ), 1 );
							break;
						}
					break;
					case 'agente':
						switch ( $end_point ) {
							case 'list':
								if( !isset( $dados_request['cnpj_cpf'] ) || empty( $dados_request['cnpj_cpf'] ) ){
									$codigo_cliente = null;
								}else{
									// verificando tipo de pessoa
									if( strlen( removeCaracteres( $dados_request['cnpj_cpf'], 'char') ) > 11 ){ //pessoa juridica
										if( !validar( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), 'cnpj' ) ){
											$retorno['status']   = 'erro'; 
											$retorno['mensagem'] = 'CNPJ contrato invalido';
											throw new Exception( json_encode( $retorno ), 1 );
										}
										$codigo_cliente	= removeCaracteres( $dados_request['cnpj_cpf'], 'char' ); 
									}else{ // pessoa fisica
										if( !validar( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), 'cpf' ) ){
											$retorno['status']   = 'erro'; 
											$retorno['mensagem'] = 'CPF contrato invalido';
											throw new Exception( json_encode( $retorno ), 1 );
										}
										$codigo_cliente	= removeCaracteres( $dados_request['cnpj_cpf'], 'char' );
									}
								}
								
								$agente = json_decode( $agente_model->getAllAgentes( $codigo_cliente ) );
								if( $agente ){
									$retorno['status']   = 'ok'; 
									$retorno['output'] = $agente;
									throw new Exception( json_encode( $retorno ), 1 );
								}else{
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Agente não encontrado';
									throw new Exception( json_encode( $retorno ), 1 );
								}
							break;
							case 'clientes':
								if( !isset( $dados_request['cnpj_cpf'] ) || empty( $dados_request['cnpj_cpf'] ) ){
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o CNPJ ou CPF';
									throw new Exception( json_encode( $retorno ), 1 );
								}
								
								// verificando tipo de pessoa
								if( strlen( removeCaracteres( $dados_request['cnpj_cpf'], 'char') ) > 11 ){ //pessoa juridica
									if( !validar( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), 'cnpj' ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'CNPJ contrato invalido';
										throw new Exception( json_encode( $retorno ), 1 );
									}
									$codigo_cliente	= removeCaracteres( $dados_request['cnpj_cpf'], 'char' );
								}else{ // pessoa fisica
									if( !validar( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), 'cpf' ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'CPF contrato invalido';
										throw new Exception( json_encode( $retorno ), 1 );
									}
									$codigo_cliente	= removeCaracteres( $dados_request['cnpj_cpf'], 'char' );
								}
								$clientes = json_decode( $agente_model->getClientesByCnpjCpfAgente( $codigo_cliente ) );
								if( $clientes ){
									$retorno['status'] = 'ok'; 
									$retorno['output'] = $clientes;
									throw new Exception( json_encode( $retorno ), 1 );
								}else{
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Nenhum cliente encontrado';
									throw new Exception( json_encode( $retorno ), 1 );
								}
							break;
							case 'faturamento':
								if( isset( $dados_request['status'] ) && !empty( $dados_request['status'] ) ){
									switch ( strtoupper( $dados_request['status'] ) ) {
										case 'RECEBER':
										case 'ABERTO':
											$status_nf = 'receber';
										break;
										case 'RECEBIDO':
										case 'LIQUIDADO':
											$status_nf = 'recebido';
										break;
									}
								}else{
									$status_nf = null;
								}

								if( isset( $dados_request['produto'] ) && !empty( $dados_request['produto'] ) ){
									switch ( strtoupper( $dados_request['produto'] ) ) {
										case 'CRY0001':
										case 'CRY0002':
										case 'CRY0003':
											$codigo_produto = $dados_request['produto'];
										break;
										default:
											$retorno['status']   = 'erro'; 
											$retorno['mensagem'] = 'Informe o produto';
											throw new Exception( json_encode( $retorno ), 1 );
										break;
									}
								}else{
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o produto';
									throw new Exception( json_encode( $retorno ), 1 );
								}

								$contratos_model = $this->load_model( 'contratos/contratos', true );
								$notas_model 	 = $this->load_model( 'notas-fiscais/notas-fiscais', true );
								if( !isset( $dados_request['periodo_ini'] ) || empty( $dados_request['periodo_ini'] ) ){
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o periodo inicial';
									throw new Exception( json_encode( $retorno ), 1 );
								}

								if( !isset( $dados_request['periodo_fim'] ) || empty( $dados_request['periodo_fim'] ) ){
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o periodo final';
									throw new Exception( json_encode( $retorno ), 1 );
								}
								
								if( !isset( $dados_request['cnpj_cpf'] ) || empty( $dados_request['cnpj_cpf'] ) ){
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o CNPJ ou CPF do Agente comercial';
									throw new Exception( json_encode( $retorno ), 1 );
								}

								if( isset( $dados_request['cliente'] ) && !empty( $dados_request['cliente'] ) ){
									// verificando tipo de pessoa
									if( strlen( removeCaracteres( $dados_request['cliente'], 'char') ) > 11 ){ //pessoa juridica
										if( !validar( removeCaracteres( $dados_request['cliente'], 'char'), 'cnpj' ) ){
											$retorno['status']   = 'erro'; 
											$retorno['mensagem'] = 'CNPJ licenciado invalido';
											throw new Exception( json_encode( $retorno ), 1 );
										}
										$CnpjCpfLicenciado = removeCaracteres( $dados_request['cliente'], 'char' );
									}else{ // pessoa fisica
										if( !validar( removeCaracteres( $dados_request['cliente'], 'char'), 'cpf' ) ){
											$retorno['status']   = 'erro'; 
											$retorno['mensagem'] = 'CPF licenciado invalido';
											throw new Exception( json_encode( $retorno ), 1 );
										}
										$CnpjCpfLicenciado = removeCaracteres( $dados_request['cliente'], 'char' );
									}	
								}else{
									$CnpjCpfLicenciado = null;
								}
								
								// verificando tipo de pessoa
								if( strlen( removeCaracteres( $dados_request['cnpj_cpf'], 'char') ) > 11 ){ //pessoa juridica
									if( !validar( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), 'cnpj' ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'CNPJ do agente invalido';
										throw new Exception( json_encode( $retorno ), 1 );
									}
									$CnpjCpfAgente = removeCaracteres( $dados_request['cnpj_cpf'], 'char' );
								}else{ // pessoa fisica
									if( !validar( removeCaracteres( $dados_request['cnpj_cpf'], 'char'), 'cpf' ) ){
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'CPF do agente invalido';
										throw new Exception( json_encode( $retorno ), 1 );
									}
									$CnpjCpfAgente = removeCaracteres( $dados_request['cnpj_cpf'], 'char' );
								}

								$dt_ini = getDataAtual( $dados_request['periodo_ini'] );
								$dt_fim = getDataAtual( $dados_request['periodo_fim'] );
								
								$pesquisa_ini = $dt_ini->format('Y-m-d');
								$pesquisa_fim = $dt_fim->format('Y-m-d');
								$agente = json_decode( $agente_model->getAgenteByCnpj( $CnpjCpfAgente ) );
								if( $agente ){
									$clientes = json_decode( $contratos_model->getContratosByIdAgenteComercial( $agente[0]->id, $codigo_produto, $CnpjCpfLicenciado ) );
									if( $clientes ){
										foreach ( $clientes as $key => $value ) {
											$i1    = $value->cnpj;
											$ids[] = $value->id;
											$faturamento[$i1]['cnpj_cpf']     = $value->cnpj;
											$faturamento[$i1]['razao_social'] = $value->razao_social;
											$faturamento[$i1]['totais'] 	  = null;
											$faturamento[$i1]['faturamento']  = null;
										}
										$notas_fiscais = json_decode( $notas_model->getNotasByPeriodoEcontrato( $pesquisa_ini, $pesquisa_fim, $ids, 'emissao', $status_nf ) );
										if( $notas_fiscais ){
											foreach ( $notas_fiscais as $key => $value ) {
												$i2 	  = $value->cnpj_cpf_cliente;
												$i3 	  = $value->id;
												$comissao = null;
												$comissao = ( ( ( $value->valor_liquido - $value->valor_desconto ) / 100 ) * $agente[0]->percentual_comissao );
												
												$faturamento[$i2]['search_ini']							 = $dt_ini;
												$faturamento[$i2]['search_fim']							 = $dt_fim;
												$faturamento[$i2]['totais']['percentual_comissao']		 = number_format( $agente[0]->percentual_comissao,'2',',','.');
												$faturamento[$i2]['totais']['comissoes'] 	  			 += $comissao;
												$faturamento[$i2]['totais']['valor_liquido']   			 += $value->valor_liquido;
												$faturamento[$i2]['totais']['valor_fatura']   			 += $value->valor_fatura;
												$faturamento[$i2]['totais']['valor_total']    			 += $value->valor_total;
												$faturamento[$i2]['totais']['valor_desconto'] 			 += $value->valor_desconto;
												$faturamento[$i2]['totais']['valor_impostos'] 			 += $value->valor_impostos;
												$faturamento[$i2]['totais']['fatura'] 		  			 += $value->valor_fatura;
												$faturamento[$i2]['faturamento'][$i3]['comissoes'] 	 	 = $comissao;
												$faturamento[$i2]['faturamento'][$i3]['valor_fatura'] 	 = $value->valor_fatura;
												$faturamento[$i2]['faturamento'][$i3]['valor_total'] 	 = $value->valor_total;
												$faturamento[$i2]['faturamento'][$i3]['valor_desconto']  = $value->valor_desconto;
												$faturamento[$i2]['faturamento'][$i3]['valor_impostos']  = $value->valor_impostos;
												$faturamento[$i2]['faturamento'][$i3]['data_emissao'] 	 = $value->data_emissao;
												$faturamento[$i2]['faturamento'][$i3]['data_vencimento'] = $value->data_vencimento;
												$faturamento[$i2]['faturamento'][$i3]['status'] 	 	 = $value->status;
												$faturamento[$i2]['faturamento'][$i3]['recebido_em'] 	 = $value->recebido_em;
											}
											$retorno['status'] = 'ok'; 
											$retorno['output'] = $faturamento;
											throw new Exception( json_encode( $retorno ), 1 );
										}else{
											$retorno['status']   = 'erro'; 
											$retorno['mensagem'] = 'Nenhuma nota fiscal não encontrado';
											throw new Exception( json_encode( $retorno ), 1 );	
										}
									}else{
										$retorno['status']   = 'erro'; 
										$retorno['mensagem'] = 'Nenhum cliente não encontrado';
										throw new Exception( json_encode( $retorno ), 1 );
									}
								}else{
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Agente não encontrado';
									throw new Exception( json_encode( $retorno ), 1 );
								}
							break;
							default:
								$retorno['status']   = 'erro';
								$retorno['mensagem'] = 'END POINT ERRO';
								throw new Exception( json_encode( $retorno ), 1 );
							break;
						}
					break;
					case 'produto':
						switch ( $end_point ) {
							case 'modulos':
								if( isset( $dados_request['produto'] ) && !empty( $dados_request['produto'] ) ){
									switch ( strtoupper( $dados_request['produto'] ) ) {
										case 'CRY0001':
										case 'CRY0002':
										case 'CRY0003':
											$codigo_produto = $dados_request['produto'];
										break;
										default:
											$retorno['status']   = 'erro'; 
											$retorno['mensagem'] = 'Codigo produto invalido';
											throw new Exception( json_encode( $retorno ), 1 );
										break;
									}
								}else{
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Informe o produto';
									throw new Exception( json_encode( $retorno ), 1 );
								}

								$produtos_model = $this->load_model( 'produtos/produtos', true );
								$modulos 		= json_decode( $produtos_model->getProdutoEmodulo( $codigo_produto ) );
								if( $modulos ){
									$retorno['status'] = 'ok'; 
									$retorno['output'] = $modulos;
									throw new Exception( json_encode( $retorno ), 1 );
								}else{
									$retorno['status']   = 'erro'; 
									$retorno['mensagem'] = 'Produto não encontrado';
									throw new Exception( json_encode( $retorno ), 1 );
								}
							break;
							default:
								$retorno['status']   = 'erro';
								$retorno['mensagem'] = 'END POINT ERRO';
								throw new Exception( json_encode( $retorno ), 1 );
							break;
						}
					break;
					default:
						$retorno['status']   = 'erro';
						$retorno['mensagem'] = 'BASE POINT ERRO';
						throw new Exception( json_encode( $retorno ), 1 );
					break;
				}
			} catch ( Exception $e ){
				echo $e->getMessage();
			}
		}
	}