<?php
class apivbacontratoController extends MainController
{
    private $dicionario;
    public function __construct($parametros = null, $nome_modulo = "", $do_login = false)
    {
        require ABSPATH . "/config_extras.php";
        $this->dicionario = $VAR_SYSTEM['DICIONARIO_TAG'];
        parent::__construct($parametros, $nome_modulo, $do_login);
    }
    public function index()
    {
        $func = $_GET['func'];
        switch ($func) {
            case 'tipos':
                $params = $this->defineParamsTipo();
                echo json_encode($params);
            break;
            case 'subtipos':
                $subtipo = $_GET['selected'];
                $params = $this->defineParamsSubTipo($subtipo);
                echo json_encode($params);
            break;
        }
    }
    private function defineParamsTipo()
    {
        $params = [
            "CM",
            "CLIENTE",
            "CONTATOS",
            "CONTRATO",
            "FATURAMENTO",
            "VALORES_ADMINISTRATIVOS",
            "IMPLANTACAO",
            "PRODUTO_CORNER_FULL",
        ];

        asort($params);
        return $params;
    }

    private function defineParamsSubTipo($subtipo)
    {

        switch ($subtipo) {
            case "CM":
                $params = [
                    'CM_NOME_EMRRESA',
                    'CM_CNPJ',
                    'CM_REPRESENTANTE_LEGAL_NOME',
                    'CM_REPRESENTANTE_LEGAL_CPF',
                    'CM_REPRESENTANTE_LEGAL_EMAIL',
                    'CM_REPRESENTANTE_LEGAL_TELEFONE',
                    'CM_REPRESENTANTE_LEGAL_CARGO',

                    'CM_TESTEMUNHA_1_NOME',
                    'CM_TESTEMUNHA_1_CPF',
                    'CM_TESTEMUNHA_1_EMAIL',
                    'CM_TESTEMUNHA_1_TELEFONE',
                    'CM_TESTEMUNHA_1_CARGO',

                    'CM_TESTEMUNHA_2_NOME',
                    'CM_TESTEMUNHA_2_CPF',
                    'CM_TESTEMUNHA_2_EMAIL',
                    'CM_TESTEMUNHA_2_TELEFONE',
                    'CM_TESTEMUNHA_2_CARGO',

                ];
                break;
            case 'CLIENTE':
                $params = [
                    'CLIENTE_NOME',
                    'CLIENTE_CNPJ',
                    'CLIENTE_ENDERECO',
                    'CLIENTE_BAIRRO',
                    'CLIENTE_CEP',
                    'CLIENTE_CIDADE',
                    'CLIENTE_UF',
                ];
                break;
            case 'CONTRATO':
                $params = [
                    'VIGENCIA_CONTRATO_NUMERICO',
                    'VIGENCIA_CONTRATO_EXTENSO',
                ];
                break;
            case 'CONTATOS':
                $params = [
                    'REPRESENTANTE_LEGAL_1_NOME',
                    'REPRESENTANTE_LEGAL_1_CARGO',
                    'REPRESENTANTE_LEGAL_1_CPF',
                    'REPRESENTANTE_LEGAL_1_TELEFONE',
                    'REPRESENTANTE_LEGAL_1_EMAIL',

                    'REPRESENTANTE_LEGAL_2_NOME',
                    'REPRESENTANTE_LEGAL_2_CARGO',
                    'REPRESENTANTE_LEGAL_2_CPF',
                    'REPRESENTANTE_LEGAL_2_TELEFONE',
                    'REPRESENTANTE_LEGAL_2_EMAIL',

                    'REPRESENTANTE_LEGAL_3_NOME',
                    'REPRESENTANTE_LEGAL_3_CARGO',
                    'REPRESENTANTE_LEGAL_3_CPF',
                    'REPRESENTANTE_LEGAL_3_TELEFONE',
                    'REPRESENTANTE_LEGAL_3_EMAIL',

                    'FINANCEIRO_1_NOME',
                    'FINANCEIRO_1_EMAIL',
                    'FINANCEIRO_1_TELEFONE',
                    'FINANCEIRO_1_CPF',

                    'FINANCEIRO_2_NOME',
                    'FINANCEIRO_2_EMAIL',
                    'FINANCEIRO_2_TELEFONE',
                    'FINANCEIRO_2_CPF',

                    'JURIDICO_NOME',
                    'JURIDICO_EMAIL',
                    'JURIDICO_TELEFONE',
                    'JURIDICO_CPF',

                    'RESPONSAVEL_NOME',
                    'RESPONSAVEL_EMAIL',
                    'RESPONSAVEL_TELEFONE',

                    'TECNICO_NOME',
                    'TECNICO_EMAIL',
                    'TECNICO_TELEFONE',

                    'TESTEMUNHA_NOME',
                    'TESTEMUNHA_CPF',
                    'TESTEMUNHA_EMAIL',
                    'TESTEMUNHA_TELEFONE',
                ];
                break;
            case 'FATURAMENTO':
                $params = [
                    'DATA_CORTE_NUMERICO',
                    'DATA_CORTE_EXTENSO',
                    'PRAZO_PAGAMENTO_NUMERICO',
                    'PRAZO_PAGAMENTO_EXTENSO',
                    'PRIMEIRO_FATURAMENTO',
                    'PRAZO_CONTRATO',
                    'INDICE_REAJUSTE',
                    'PERCENTUAL_JUROS_NUMERICO',
                    'PERCENTUAL_JUROS_EXTENSO',
                    'PERCENTUAL_MULTA_NUMERICO',
                    'PERCENTUAL_MULTA_EXTENSO',
                    'TEXTO_IMPLANTACAO',
                ];
                break;
            case 'VALORES_ADMINISTRATIVOS':
                $params = [
                    'MENSALIDADE_NUMERICO',
                    'MENSALIDADE_EXTENSO',
                    'JUROS_NUMERICO',
                    'JUROS_EXTENSO',
                    'INATIVIDADE_NUMERICO',
                    'INATIVIDADE_EXTENSO',
                    'CUSTOMIZACAO_SOFTWARE_NUMERICO',
                    'CUSTOMIZACAO_SOFTWARE_EXTENSO',
                ];
                break;
            case 'IMPLANTACAO':
                $params = [
                    'IMPLANTACAO_VALOR_NUMERICO',
                    'IMPLANTACAO_VALOR_EXTENSO',
                    'IMPLANTACAO_TEXTO',
                ];
                break;

            case 'PRODUTO_CORNER_FULL':
                $params = [
                    "TABELA_TRANSACOES_DOMINIO_01",
                    "TABELA_TRANSACOES_DOMINIO_02",
                    "TABELA_SPB_02_TRATAMENTO_DE_INCONSISTENCIA",
                    "TABELA_SPB_02_TRANSACOES_WEBSERVICE",
                    "TABELA_SPB_02_TRANSACOES_WEBSERVICE_LOTE",
                    "TABELA_SPB_02_REMESSA_BAIXA_CONVERSAO_BATCH_XML",
                    "TABELA_SPB_02_REGISTRO_E_BAIXA_NOVACOB",
                    "TABELA_PIX_TRANSACAO_A_CREDITO_06H00_11H59",
                    "TABELA_PIX_TRANSACAO_A_CREDITO_12H00_15H30",
                    "TABELA_PIX_TRANSACAO_A_CREDITO_15H31_22H00",
                    "TABELA_PIX_TRANSACAO_A_CREDITO_22H01_05H59",
                    "TABELA_PIX_TRANSACAO_A_DEBITO_06H00_11H59",
                    "TABELA_PIX_TRANSACAO_A_DEBITO_12H00_15H30",
                    "TABELA_PIX_TRANSACAO_A_DEBITO_15H31_22H00",
                    "TABELA_PIX_TRANSACAO_A_DEBITO_22H01_05H59",
                    "TABELA_PIX_AUTOMATICO_EVENTO_TRANSACAO_ACEITACAO_CONSENTIMENTO",
                    "TABELA_PIX_AUTOMATICO_EVENTO_TRANSACAO_ACEITACAO_AGENDAMENTO",
                    "TABELA_ANTIFRAUDE_TRANSACAO_RECUSADA_PAGAMENTO",
                    "TABELA_ANTIFRAUDE_TRANSACAO_DETALHADA_PAGAMENTO",
                    "TABELA_ANTIFRAUDE_TRANSACAO_APROVADA_PAGAMENTO",
                    "TABELA_OPEN_FINANCE_RESPONSE_API_OPEN_BANKING",
                    "TABELA_OPEN_FINANCE_REQUEST_API_OPEN_BANKING",
                    "TABELA_BH_GERACAO_FATURA_PDF_COM_DADOS_VARIAVEIS",
                    "TABELA_BH_GERACAO_BOLETO_PDF_COM_DADOS_VARIAVEIS",
                    "TABELA_BH_ENVIO_DE_SMS",
                    "TABELA_BH_ENVIO_DE_EMAIL",
                    "TABELA_BH_BAIXA_QR_CODE",
                    "TABELA_PIX_SINACOR",
                    "TABELA_TRIPLE_PIX_CONSOLIDACAO",
                    "TABELA_ITP_MODE_POR_CONSULTA_DICT",
                    "TABELA_PACOTE_COMPROMISSADO_PIX",
                    "TABELA_ASSESSORIA_BACEN",
                    "TABELA_SERPRO_PIX",
                    "TABELA_GERACAO_ARQUIVOS_ROC_605",
                    "TABELA_CERTIFICACAO OPEN FINANCE",

                    "TRANSACOES_DOMINIO_01_NUMERICO",
                    "TRANSACOES_DOMINIO_01_EXTENSO",
                    "TRANSACOES_DOMINIO_02_NUMERICO",
                    "TRANSACOES_DOMINIO_02_EXTENSO",
                    "SPB_02_TRATAMENTO_DE_INCONSISTENCIA_NUMERICO",
                    "SPB_02_TRATAMENTO_DE_INCONSISTENCIA_EXTENSO",
                    "SPB_02_TRANSACOES_WEBSERVICE_NUMERICO",
                    "SPB_02_TRANSACOES_WEBSERVICE_EXTENSO",
                    "SPB_02_TRANSACOES_WEBSERVICE_LOTE_NUMERICO",
                    "SPB_02_TRANSACOES_WEBSERVICE_LOTE_EXTENSO",
                    "SPB_02_REMESSA_BAIXA_CONVERSAO_BATCH_XML_NUMERICO",
                    "SPB_02_REMESSA_BAIXA_CONVERSAO_BATCH_XML_EXTENSO",
                    "SPB_02_REGISTRO_E_BAIXA_NOVACOB_NUMERICO",
                    "SPB_02_REGISTRO_E_BAIXA_NOVACOB_EXTENSO",
                    "PIX_TRANSACAO_A_CREDITO_06H00_11H59_NUMERICO",
                    "PIX_TRANSACAO_A_CREDITO_06H00_11H59_EXTENSO",
                    "PIX_TRANSACAO_A_CREDITO_12H00_15H30_NUMERICO",
                    "PIX_TRANSACAO_A_CREDITO_12H00_15H30_EXTENSO",
                    "PIX_TRANSACAO_A_CREDITO_15H31_22H00_NUMERICO",
                    "PIX_TRANSACAO_A_CREDITO_15H31_22H00_EXTENSO",
                    "PIX_TRANSACAO_A_CREDITO_22H01_05H59_NUMERICO",
                    "PIX_TRANSACAO_A_CREDITO_22H01_05H59_EXTENSO",
                    "PIX_TRANSACAO_A_DEBITO_06H00_11H59_NUMERICO",
                    "PIX_TRANSACAO_A_DEBITO_06H00_11H59_EXTENSO",
                    "PIX_TRANSACAO_A_DEBITO_12H00_15H30_NUMERICO",
                    "PIX_TRANSACAO_A_DEBITO_12H00_15H30_EXTENSO",
                    "PIX_TRANSACAO_A_DEBITO_15H31_22H00_NUMERICO",
                    "PIX_TRANSACAO_A_DEBITO_15H31_22H00_EXTENSO",
                    "PIX_TRANSACAO_A_DEBITO_22H01_05H59_NUMERICO",
                    "PIX_TRANSACAO_A_DEBITO_22H01_05H59_EXTENSO",
                    "PIX_AUTOMATICO_EVENTO_TRANSACAO_ACEITACAO_CONSENTIMENTO_NUMERICO",
                    "PIX_AUTOMATICO_EVENTO_TRANSACAO_ACEITACAO_CONSENTIMENTO_EXTENSO",
                    "PIX_AUTOMATICO_EVENTO_TRANSACAO_ACEITACAO_AGENDAMENTO_NUMERICO",
                    "PIX_AUTOMATICO_EVENTO_TRANSACAO_ACEITACAO_AGENDAMENTO_EXTENSO",
                    "ANTIFRAUDE_TRANSACAO_RECUSADA_PAGAMENTO_NUMERICO",
                    "ANTIFRAUDE_TRANSACAO_RECUSADA_PAGAMENTO_EXTENSO",
                    "ANTIFRAUDE_TRANSACAO_DETALHADA_PAGAMENTO_NUMERICO",
                    "ANTIFRAUDE_TRANSACAO_DETALHADA_PAGAMENTO_EXTENSO",
                    "ANTIFRAUDE_TRANSACAO_APROVADA_PAGAMENTO_NUMERICO",
                    "ANTIFRAUDE_TRANSACAO_APROVADA_PAGAMENTO_EXTENSO",
                    "OPEN_FINANCE_RESPONSE_API_OPEN_BANKING_NUMERICO",
                    "OPEN_FINANCE_RESPONSE_API_OPEN_BANKING_EXTENSO",
                    "OPEN_FINANCE_REQUEST_API_OPEN_BANKING_NUMERICO",
                    "OPEN_FINANCE_REQUEST_API_OPEN_BANKING_EXTENSO",
                    "BH_GERACAO_FATURA_PDF_COM_DADOS_VARIAVEIS_NUMERICO",
                    "BH_GERACAO_FATURA_PDF_COM_DADOS_VARIAVEIS_EXTENSO",
                    "BH_GERACAO_BOLETO_PDF_COM_DADOS_VARIAVEIS_NUMERICO",
                    "BH_GERACAO_BOLETO_PDF_COM_DADOS_VARIAVEIS_EXTENSO",
                    "BH_ENVIO_DE_SMS_NUMERICO",
                    "BH_ENVIO_DE_SMS_EXTENSO",
                    "BH_ENVIO_DE_EMAIL_NUMERICO",
                    "BH_ENVIO_DE_EMAIL_EXTENSO",
                    "BH_BAIXA_QR_CODE_NUMERICO",
                    "BH_BAIXA_QR_CODE_EXTENSO",
                    "PIX_SINACOR_NUMERICO",
                    "PIX_SINACOR_EXTENSO",
                    "TRIPLE_PIX_CONSOLIDACAO_NUMERICO",
                    "TRIPLE_PIX_CONSOLIDACAO_EXTENSO",
                    "ITP_MODE_POR_CONSULTA_DICT_NUMERICO",
                    "ITP_MODE_POR_CONSULTA_DICT_EXTENSO",
                    "PACOTE_COMPROMISSADO_PIX_NUMERICO",
                    "PACOTE_COMPROMISSADO_PIX_EXTENSO",
                    "ASSESSORIA_BACEN_NUMERICO",
                    "ASSESSORIA_BACEN_EXTENSO",
                    "SERPRO_PIX_NUMERICO",
                    "SERPRO_PIX_EXTENSO",
                    "CERTIFICACAO OPEN FINANCE_NUMERICO",
                    "CERTIFICACAO OPEN FINANCE_EXTENSO",

                ];
                break;
        }

        asort($params);
        return $params;
    }
}
