<?php
	class BancoController extends MainController{
		protected $module = 'banco';
		protected $class_conta_bancaria, $obj_fat, $obj_contas, $obj_nf, $obj_desp, $obj_banco, $obj_orcamento, $obj_fornecedor, $upload, $conf_upload, $obj_movimento;

		function __construct($parametros = null){
			$this->nome_modulo = 'banco';
			parent::__construct($parametros);
			// $this->obj_banco      = new Banco();
			// require_once ABSPATH . '/classes/class-Banco.php';
			// require_once ABSPATH . '/classes/class-Upload.php';
			// $this->conf_upload['pasta']    = UP_ABSPATH;
			// $this->conf_upload['subpasta'] = 'extrato';
			// $this->obj_fat        = new Faturamento();
			// $this->upload         = new Upload();
			// $this->obj_nf         = $this->load_model('notas-fiscais/notas-fiscais', true);
			// $this->obj_desp       = $this->load_model('despesas/despesas', true);
			// $this->obj_orcamento  = $this->load_model('orcamento/orcamento', true);
			// $this->obj_fornecedor = $this->load_model('fornecedores/fornecedores', true);
			// $controller           = new MainController(null, 'tarifador', $parametros);
			// $controller->Db       = new Db(DB_NAME_MOVIMENTO);// Configurando o banco de dados movimento
			// $this->obj_movimento  = $controller->load_model('movimento/movimento', true);
			$this->class_conta_bancaria    = new ContaBancaria($this);
		}

		function index(){
			$this->lista();
		}

		function lista(){
			$records  = json_decode($this->class_conta_bancaria->getBanco());
			require_once ABSPATH . '/views/'.$this->module.'/banco-view.php';
		}

		function detalhe(){
			if($this->parametros[1])	{
				$records  = json_decode($this->class_conta_bancaria->getBanco($this->parametros[1]));
			}
			require_once ABSPATH . '/views/'.$this->module.'/banco-edit.php';
		}

		function upload(){
			$this->obj_contas = json_decode($this->class_conta_bancaria->getBanco());
			require_once ABSPATH . '/views/'.$this->module.'/upload.php';
		}

		function processarExtrato(){
			$bank_id       = null;
			$dados_banco   = null;
			$file_agencia  = null;
			$conta         = null;
			if(!isset($_FILES) || empty($_FILES)){
				$_FILES = $_POST;
			}else{
				$_FILES['extrato']['id_banco']   = $_POST['id_banco'];
			}
			
			if(isset($_FILES) && !empty($_FILES['extrato']['tmp_name'])){
				$ext 		   = end((explode(".", $_FILES['extrato']['name']))); # extra () to prevent notice
				$path_file     = $_FILES['extrato']['tmp_name'];
				$banco 		   = json_decode($this->class_conta_bancaria->getBanco($_FILES['extrato']['id_banco']));
				
				if($ext == 'RET'){
					
					$dados_extrato   = json_decode($this->obj_banco->extractRetFile($path_file));
					$bank_id 	     = $dados_extrato->file->header_file->codigo_banco;
					$agencia         = $dados_extrato->file->header_file->agencia;
					$conta           = $dados_extrato->file->header_file->conta;
					$conta_confirma  = $banco[0]->numero_conta;
					$conta_confirma2 = $banco[0]->numero_agencia.$conta_confirma;

				}elseif($ext == 'csv'){
					$dados_extrato   = $this->obj_banco->extractRetFile($path_file, 'csv');
					$bank_id         = (int)$banco[0]->id;
					$conta           = $dados_extrato[0][3];
					$conta_confirma  = $banco[0]->numero_conta.$banco[0]->digito_conta;
					$conta_confirma2 = $banco[0]->numero_agencia.$conta_confirma;
				}else{
					$dados_extrato = $this->obj_banco->getDados($path_file);
					$bank_id       = (int)$dados_extrato->BANKMSGSRSV1->STMTTRNRS->STMTRS->BANKACCTFROM->BANKID;
					$conta   	   = $dados_extrato->BANKMSGSRSV1->STMTTRNRS->STMTRS->BANKACCTFROM->ACCTID;
					if($banco[0]->codigo_banco == 237){
						$conta_confirma = $banco[0]->numero_conta;
					}else{
						
						$arr_conta = explode('-',$conta);
						if(count($arr_conta) > 1){
							$conta = $arr_conta[0];
						}

						$conta_confirma = $banco[0]->numero_conta.$banco[0]->digito_conta;
						$conta_confirma2 = $banco[0]->numero_agencia.$conta_confirma;
					}
				}

				if($conta == $conta_confirma || $conta == $conta_confirma2){
					if($conta){
						if($_FILES['extrato']['id_banco'] == $banco[0]->id){
							if($this->parametros[1] == 'credito'){
								$this->processarCreditos($banco);
							}elseif($this->parametros[1] == 'debito'){
								$this->processarDebitos($banco);	
							}
						}else{
							$msg = base64_encode('O banco selecionado não é compativel com o arquivo!');	
							header('location: /banco/upload/?msg='.$msg);
						}
					}else{
						$msg = base64_encode('Conta no arquivo de lote não encontrada no sistema!');
					}				
				}else{
					$msg = base64_encode('O arquivo selecionado não tem bancos correspondentes cadastrado!');
					header('location: /banco/upload/?msg='.$msg);
				}
			}else{
				echo 'Arquivo não encontrado!';
			}
		}

		function processarDebitos($banco = null){
			$operacoes = null;
			if(isset($_POST)){
				$_FILES = $_POST;
			}else{
				$_FILES['extrato']['id_banco']   = $_POST['id_banco'];	
			}

			if(isset($_FILES['extrato'])){
				$path_file = $_FILES['extrato']['tmp_name'];
				$fornecedores = json_decode($this->obj_fornecedor->getFornecedores());
				$contas = json_decode($this->obj_orcamento->getConta());
				$subcontas = json_decode($this->obj_orcamento->getSubConta());
				$centro_custo = json_decode($this->obj_orcamento->getCentroCusto());
				$grupos = json_decode($this->obj_orcamento->getGrupo());
				$x = 0;
				if($banco[0]->codigo_banco == 341){
					$arquivo = json_decode($this->obj_banco->extractRetFile($path_file));
					foreach ($arquivo->file->lotes as $key => $value) {
						$dia_ini = substr($value->header_lote->data_inicial, 0, 2);
						$mes_ini = substr($value->header_lote->data_inicial, 2, 2);
						$ano_ini = substr($value->header_lote->data_inicial, 4, 4);
						$dia_fim = substr($value->trailer_lote->data_final, 0, 2);
						$mes_fim = substr($value->trailer_lote->data_final, 2, 2);
						$ano_fim = substr($value->trailer_lote->data_final, 4, 4);
						$dtstart = new DateTime($ano_ini.'-'.$mes_ini.'-'.$dia_ini);
						$dtend   = new DateTime($ano_fim.'-'.$mes_fim.'-'.$dia_fim);
						foreach ($value->lancamentos as $k1 => $v1){
							$CHECKNUM = null;
							$dia_oper = substr($v1->data_lancamento, 0, 2);
							$mes_oper = substr($v1->data_lancamento, 2, 2);
							$ano_oper = substr($v1->data_lancamento, 4, 4);
							$data_operacao   = new DateTime($ano_oper.'-'.$mes_oper.'-'.$dia_oper);
							$centavos = substr($v1->valor, -2);
							$valor    = (int)substr($v1->valor, 0, 16);
							$valor    = $valor  = removeCaracteres($valor.'.'.$centavos, 'moeda3');
							$id_lcto  = $v1->data_lancamento.$v1->codigo_lote.$v1->numero_registro;
							if($dtend->format('Ymd') >= $data_operacao->format('Ymd')){
								if($v1->lancamento == 'D'){
									$CHECKNUM = json_decode($this->obj_desp->getDespesaPorExtrato($id_lcto));
									if(!$CHECKNUM){
										if($this->parametros[3] == 'finded'){
											$debitos  = json_decode($this->obj_desp->getDespesas(null, $data_operacao->format('Y-m-d'), $data_operacao->format('Y-m-d'), $valor, 'aberto', null, $banco[0]->id_cm));
											$operacoes['debitos']['finded'][$x]['codigo_banco']  = $banco[0]->codigo_banco;
											$operacoes['debitos']['finded'][$x]['tp_operacao']  = $v1->lancamento;
											$operacoes['debitos']['finded'][$x]['CHECKNUM']     = $id_lcto;
											$operacoes['debitos']['finded'][$x]['FITID']        = $v1->historico;
											$operacoes['debitos']['finded'][$x]['MEMO']         = $v1->historico;
											if($debitos){
												foreach ($debitos as $k2 => $v2){
													//sobrescreve o valor da data de pagamento de acordo com o valor oriundo do arquivo
													$v2->data_operacao = $data_operacao->format('Y-m-d');
													$operacoes['debitos']['finded'][$x]['debito'][] = $v2;
												}
											}										
										}else{
											$debitos  = json_decode($this->obj_desp->getDespesas(null, null, null, $valor, 'aberto', null, $banco[0]->id_cm));
											if($debitos){
												foreach ($debitos as $k2 => $v2) {
													if(!$v2->status){
														$status = 'aberto';
													}else{
														$status = $v2->status;
													}
													$operacoes['debitos']['unfinded'][$x]['codigo_banco']       = $banco[0]->codigo_banco;
													$operacoes['debitos']['unfinded'][$x]['tp_operacao']        = $v1->lancamento;
													$operacoes['debitos']['unfinded'][$x]['status']             = $status;
													$operacoes['debitos']['unfinded'][$x]['status_autorizacao'] = $v2->status_autorizacao;
													$operacoes['debitos']['unfinded'][$x]['data_operacao']      = $data_operacao->format('Y-m-d');
													$operacoes['debitos']['unfinded'][$x]['data_vencimento']    = $data_operacao->format('Y-m-d');
													$operacoes['debitos']['unfinded'][$x]['CHECKNUM']           = $id_lcto;
													$operacoes['debitos']['unfinded'][$x]['FITID']              = $v1->historico;
													$operacoes['debitos']['unfinded'][$x]['MEMO']               = $v1->historico;
													$operacoes['debitos']['unfinded'][$x]['valor']              = $valor;	
													$operacoes['debitos']['unfinded'][$x]['debito'][]           = $v2;
												}
											}else{
												$operacoes['debitos']['unfinded'][$x]['codigo_banco']       = $banco[0]->codigo_banco;
												$operacoes['debitos']['unfinded'][$x]['tp_operacao']        = $v1->lancamento;
												$operacoes['debitos']['unfinded'][$x]['status']             = 'ND';
												$operacoes['debitos']['unfinded'][$x]['status_autorizacao'] = 'ND';
												$operacoes['debitos']['unfinded'][$x]['data_operacao']      = $data_operacao->format('Y-m-d');
												$operacoes['debitos']['unfinded'][$x]['data_vencimento']    = $data_operacao->format('Y-m-d');
												$operacoes['debitos']['unfinded'][$x]['CHECKNUM']           = $id_lcto;
												$operacoes['debitos']['unfinded'][$x]['FITID']              = $v1->historico;
												$operacoes['debitos']['unfinded'][$x]['MEMO']               = $v1->historico;
												$operacoes['debitos']['unfinded'][$x]['valor']              = $valor;		
											}
										}
									}
								}
							}
							$x++;							
						}					
					}
				}else{
					$arquivo     = $this->obj_banco->getDados($path_file);
					$extrato     = $arquivo->BANKMSGSRSV1->STMTTRNRS->STMTRS->BANKTRANLIST->STMTTRN;
					$dtstart     = new DateTime(substr($arquivo->BANKMSGSRSV1->STMTTRNRS->STMTRS->BANKTRANLIST->DTSTART, 0, 8));
					$dtend       = new DateTime(substr($arquivo->BANKMSGSRSV1->STMTTRNRS->STMTRS->BANKTRANLIST->DTEND, 0, 8));
					if($arquivo){
						foreach ($extrato as $key => $value){
							$CHECKNUM = null;
							$data_operacao   = substr($value->DTPOSTED, 0, 14);
							$data_operacao   = new DateTime($data_operacao);
							$valor    = str_replace('-', '',  $value->TRNAMT);
							$valor    = removeCaracteres($valor, 'moeda3');
							$valor    = number_format($valor, '2', '.', '');
							if($dtend->format('Ymd') >= $data_operacao->format('Ymd')){
								if($value->TRNTYPE == 'DEBIT'){
									
									$CHECKNUM = json_decode($this->obj_desp->getDespesaPorExtrato($value->FITID.$value->CHECKNUM));
									if(!$CHECKNUM){
										if($this->parametros[3] == 'finded'){
											$debitos  = json_decode($this->obj_desp->getDespesas(null, $data_operacao->format('Y-m-d'), $data_operacao->format('Y-m-d'), $valor, 'aberto', null, $banco[0]->id_cm));
											$operacoes['debitos']['finded'][$x]['codigo_banco'] = $banco[0]->codigo_banco;
											$operacoes['debitos']['finded'][$x]['CHECKNUM']     = $value->CHECKNUM;
											$operacoes['debitos']['finded'][$x]['FITID']        = $value->FITID;
											$operacoes['debitos']['finded'][$x]['MEMO']         = $value->MEMO;
											if($debitos){
												foreach ($debitos as $k1 => $v1){
													$v1->data_operacao = $data_operacao->format('Y-m-d');
													$operacoes['debitos']['finded'][$x]['debito'][] = $v1;
												}
											}										
										}else{
											$debitos  = json_decode($this->obj_desp->getDespesas(null, null, null, $valor, 'aberto', null, $banco[0]->id_cm));
											if($debitos){
												foreach ($debitos as $k1 => $v1) {
													if(!$v1->status){
														$status = 'aberto';
													}
													$operacoes['debitos']['unfinded'][$x]['codigo_banco']       = $banco[0]->codigo_banco;
													$operacoes['debitos']['unfinded'][$x]['status']             = $status;
													$operacoes['debitos']['unfinded'][$x]['status_autorizacao'] = $v1->status_autorizacao;
													$operacoes['debitos']['unfinded'][$x]['data_operacao']      = $data_operacao->format('Y-m-d');
													$operacoes['debitos']['unfinded'][$x]['data_vencimento']    = $data_operacao->format('Y-m-d');
													$operacoes['debitos']['unfinded'][$x]['CHECKNUM']           = $value->CHECKNUM;
													$operacoes['debitos']['unfinded'][$x]['FITID']              = $value->FITID;
													$operacoes['debitos']['unfinded'][$x]['MEMO']               = $value->MEMO;
													$operacoes['debitos']['unfinded'][$x]['valor']              = $valor;	
													$operacoes['debitos']['unfinded'][$x]['debito'][]           = $v1;
												}
											}else{
												$operacoes['debitos']['unfinded'][$x]['codigo_banco']       = $banco[0]->codigo_banco;
												$operacoes['debitos']['unfinded'][$x]['status']             = 'ND';
												$operacoes['debitos']['unfinded'][$x]['status_autorizacao'] = 'ND';
												$operacoes['debitos']['unfinded'][$x]['data_operacao']      = $data_operacao->format('Y-m-d');
												$operacoes['debitos']['unfinded'][$x]['data_vencimento']    = $data_operacao->format('Y-m-d');
												$operacoes['debitos']['unfinded'][$x]['CHECKNUM']           = $value->CHECKNUM;
												$operacoes['debitos']['unfinded'][$x]['FITID']              = $value->FITID;
												$operacoes['debitos']['unfinded'][$x]['MEMO']               = $value->MEMO;
												$operacoes['debitos']['unfinded'][$x]['valor']              = $valor;		
											}
										}
									}						
								}
							}					
							$x++;
						}
					}
				}			
			}
			if($this->parametros[3] == 'finded'){
				require_once ABSPATH . '/views/'.$this->module.'/debitos-view.php';
			}else{
				require_once ABSPATH . '/views/'.$this->module.'/debitos-unfinded-view.php';
			}		
		}

		function processarCreditos($banco = null){
			$operacoes = null;
			if(isset($_FILES['extrato'])){
				$_FILES['extrato']['id_empresa'] = $banco[0]->id_empresa;
				//$path_file = $this->upload->loadFile($_FILES['extrato'], $this->conf_upload);
				$retorno      = explode('#', $this->upload->loadFile($_FILES['extrato'], $this->conf_upload));
				$path_file    = $retorno[2];
				
				$fornecedores = json_decode($this->obj_fornecedor->getFornecedores());
				$contas       = json_decode($this->obj_orcamento->getConta());
				$subcontas    = json_decode($this->obj_orcamento->getSubConta());
				$centro_custo = json_decode($this->obj_orcamento->getCentroCusto());
				$grupos       = json_decode($this->obj_orcamento->getGrupo());
				$x            = 0;

				if($banco[0]->codigo_banco == 341){
					$arquivo = json_decode($this->obj_banco->extractRetFile($path_file));
					
					if($arquivo){
						foreach ($arquivo->file->lotes as $key => $value) {
							$dia_ini = substr($value->header_lote->data_inicial, 0, 2);
							$mes_ini = substr($value->header_lote->data_inicial, 2, 2);
							$ano_ini = substr($value->header_lote->data_inicial, 4, 4);
							$dia_fim = substr($value->trailer_lote->data_final, 0, 2);
							$mes_fim = substr($value->trailer_lote->data_final, 2, 2);
							$ano_fim = substr($value->trailer_lote->data_final, 4, 4);
							$dtstart = new DateTime($ano_ini.'-'.$mes_ini.'-'.$dia_ini);
							$dtend   = new DateTime($ano_fim.'-'.$mes_fim.'-'.$dia_fim);
							foreach ($value->lancamentos as $k1 => $v1){
								
								$CHECKNUM = null;
								$dia_oper = substr($v1->data_lancamento, 0, 2);
								$mes_oper = substr($v1->data_lancamento, 2, 2);
								$ano_oper = substr($v1->data_lancamento, 4, 4);
								$data_operacao   = new DateTime($ano_oper.'-'.$mes_oper.'-'.$dia_oper);
								$centavos = substr($v1->valor, -2);
								$valor    = (int)substr($v1->valor, 0, 16);
								$valor    = $valor  = removeCaracteres($valor.'.'.$centavos, 'moeda3');
								$id_lcto  = $v1->data_lancamento.$v1->codigo_lote.$v1->numero_registro;
								//$valor  = number_format((int), 0, '', '.');
								if($dtend->format('Ymd') >= $data_operacao->format('Ymd')){
									if($v1->lancamento == 'C'){
										$CHECKNUM = json_decode($this->obj_nf->getNotaPorIdExtrato($id_lcto));
										if(!$CHECKNUM){
											$creditos = json_decode($this->obj_nf->getNota(null, null, $valor, 'receber', $banco[0]->cnpj_cm));
											if($creditos){
												$operacoes['creditos']['finded'][$x]['CHECKNUM']   = $banco[0]->codigo_banco;
												$operacoes['creditos']['finded'][$x]['CHECKNUM']   = $id_lcto;
												$operacoes['creditos']['finded'][$x]['FITID']      = $v1->historico;
												$operacoes['creditos']['finded'][$x]['MEMO']       = $v1->historico;
												foreach ($creditos as $k2 => $v2) {
													$v2->recebido_em = $data_operacao->format('Y-m-d');
													$operacoes['creditos']['finded'][$x]['credito'][] = $v2;
												}

											}else{
												$operacoes['creditos']['unfinded'][$x]['codigo_banco']     = $banco[0]->codigo_banco;
												$operacoes['creditos']['unfinded'][$x]['recebido_em']      = $data_operacao->format('Y-m-d');
												$operacoes['creditos']['unfinded'][$x]['data_vencimento']  = $data_operacao->format('Y-m-d');
												$operacoes['creditos']['unfinded'][$x]['CHECKNUM']         = $id_lcto;
												$operacoes['creditos']['unfinded'][$x]['FITID']            = $v1->historico;
												$operacoes['creditos']['unfinded'][$x]['MEMO']             = $v1->historico;
												$operacoes['creditos']['unfinded'][$x]['valor']            = $valor;
											}
										}
									}
								}
								$x++;							
							}					
						}
					}				
				}else{
					$arquivo      = $this->obj_banco->getDados($path_file);
					$extrato      = $arquivo->BANKMSGSRSV1->STMTTRNRS->STMTRS->BANKTRANLIST->STMTTRN;
					$dtstart      = new DateTime(substr($arquivo->BANKMSGSRSV1->STMTTRNRS->STMTRS->BANKTRANLIST->DTSTART, 0,8));
					$dtend        = new DateTime(substr($arquivo->BANKMSGSRSV1->STMTTRNRS->STMTRS->BANKTRANLIST->DTEND, 0, 8));
					if($arquivo){
						foreach ($extrato as $key => $value){
							$CHECKNUM = null;
							$data_operacao = substr($value->DTPOSTED, 0, 14);
							$data_operacao = new DateTime($data_operacao);
							$valor  = str_replace('-', '', $value->TRNAMT);
							$valor  = removeCaracteres($valor, 'moeda3');
							if($dtend->format('Ymd') >= $data_operacao->format('Ymd')){
								if($value->TRNTYPE == 'CREDIT' || $value->TRNTYPE == 'DEP'){
									$CHECKNUM = json_decode($this->obj_nf->getNotaPorIdExtrato($value->FITID.$value->CHECKNUM));
									if(!$CHECKNUM){
										$creditos = json_decode($this->obj_nf->getNota(null, null, $valor, 'receber', $banco[0]->cnpj_cm));
										if($creditos){
											$operacoes['creditos']['finded'][$x]['codigo_banco'] = $banco[0]->codigo_banco;
											$operacoes['creditos']['finded'][$x]['CHECKNUM']     = $value->CHECKNUM;
											$operacoes['creditos']['finded'][$x]['FITID']        = $value->FITID;
											$operacoes['creditos']['finded'][$x]['MEMO']         = $value->MEMO;
											foreach ($creditos as $k1 => $v1){
												$v1->recebido_em = $data_operacao->format('Y-m-d');
												$operacoes['creditos']['finded'][$x]['credito'][]   = $v1;
											}
										}else{
											$operacoes['creditos']['unfinded'][$x]['codigo_banco']    = $banco[0]->codigo_banco;
											$operacoes['creditos']['unfinded'][$x]['recebido_em']     = $data_operacao->format('Y-m-d');
											$operacoes['creditos']['unfinded'][$x]['data_vencimento'] = $data_operacao->format('Y-m-d');
											$operacoes['creditos']['unfinded'][$x]['CHECKNUM']        = $value->CHECKNUM;
											$operacoes['creditos']['unfinded'][$x]['FITID']           = $value->FITID;
											$operacoes['creditos']['unfinded'][$x]['MEMO']            = $value->MEMO;
											$operacoes['creditos']['unfinded'][$x]['valor']           = $valor;
										}
									}							
								}
							}
							$x++;
						}
					}	
				}
			}
			require_once ABSPATH . '/views/'.$this->module.'/creditos-view.php';
		}

		function processarAll(){
			if(isset($_FILES['extrato'])){
				$fornecedores = json_decode($this->obj_fornecedor->getFornecedores());
				$contas = json_decode($this->obj_orcamento->getConta());
				$subcontas = json_decode($this->obj_orcamento->getSubConta());
				$centro_custo = json_decode($this->obj_orcamento->getCentroCusto());
				$grupos = json_decode($this->obj_orcamento->getGrupo());
				$x = 0;
				$arquivo     = $this->banco->getDados($_FILES['extrato']['tmp_name']);
				$extrato     = $arquivo->BANKMSGSRSV1->STMTTRNRS->STMTRS->BANKTRANLIST->STMTTRN;
				$dtstart     = new DateTime($extrato->DTSTART);
				$dtend       = new DateTime($extrato->DTEND);
				if($arquivo){
					foreach ($extrato as $key => $value){
						$CHECKNUM = null;
						$data_operacao = substr($value->DTPOSTED, 0, 14);
						$data_operacao = new DateTime($data_operacao);
						$valor  = str_replace('-', '', $value->TRNAMT);
						if($value->TRNTYPE == 'DEBIT'){
							$CHECKNUM = json_decode($this->obj_desp->getDespesaPorExtrato($value->CHECKNUM));
							if(!$CHECKNUM){
								$debitos  = json_decode($this->obj_desp->getDespesas(null, null, null, $valor, 'aberto', 'aprovado', $value->CHECKNUM));
								if($debitos){
									$operacoes['debitos']['finded'][$x]['CHECKNUM']     = $value->CHECKNUM;
									$operacoes['debitos']['finded'][$x]['FITID']        = $value->FITID;
									foreach ($debitos as $k1 => $v1) {
										$operacoes['debitos']['finded'][$x]['debito'][] = $v1;
									}							
								}else{
									$operacoes['debitos']['unfinded'][$x]['data_vencimento'] = $data_operacao->format('Y-m-d');
									$operacoes['debitos']['unfinded'][$x]['CHECKNUM']        = $value->CHECKNUM;
									$operacoes['debitos']['unfinded'][$x]['FITID']           = $value->FITID;
									$operacoes['debitos']['unfinded'][$x]['valor']           = $valor; 
								}
							}						
						}elseif($value->TRNTYPE == 'CREDIT'){
							$CHECKNUM = json_decode($this->obj_nf->getNotaPorIdExtrato($value->CHECKNUM));
							if(!$CHECKNUM){
								$creditos = json_decode($this->obj_nf->getNota(null, $data_operacao->format('Y-m-d'), $valor, 'receber'));
								if($creditos){
									$operacoes['creditos']['finded'][$x]['CHECKNUM']   = $value->CHECKNUM;
									$operacoes['creditos']['finded'][$x]['FITID']      = $value->FITID;
									foreach ($creditos as $k1 => $v1) {
										$operacoes['creditos']['finded'][$x]['credito'][] = $v1;
									}
								}else{
									$operacoes['creditos']['unfinded'][$x]['data_vencimento'] = $data_operacao->format('Y-m-d');
									$operacoes['creditos']['unfinded'][$x]['CHECKNUM']         = $value->CHECKNUM;
									$operacoes['creditos']['unfinded'][$x]['FITID']            = $value->FITID;
									$operacoes['creditos']['unfinded'][$x]['valor']            = $valor;
								}
							}							
						}
						$x++;
					}
				}
			}
			require_once ABSPATH . '/views/'.$this->module.'/debitos-view.php';
		}

		function setStatus(){
			try {
				if(isset($_POST['tipo_record']) && $_POST['tipo_record'] == 'debito'){
					if(isset($_POST['id_record']) && !empty($_POST['id_record']) && is_numeric($_POST['id_record'])){
						
						$param['status'] 	     	 = 'pago';
						$param['flag_aprovacao'] 	 = 'automatico';
						$param['id_extrato']     	 = $_POST['fitid'].$_POST['id_extrato'];
						$param['requer_autorizacao'] = 0;
						
						if(isset($_POST['data_operacao']) && !empty($_POST['data_operacao'])){
							$param['data_pagamento'] = $_POST['data_operacao'];
						}else{
							$param['data_pagamento'] = $this->data_hora_atual->format('Y-m-d H:i:s');
						}
						$despesa  = json_decode($this->obj_desp->getDespesas($_POST['id_record']));
						if($despesa){
							$is_save = $this->obj_desp->save($param, $_POST['id_record']);
							if($is_save){
								$retorno['codigo']   = 0;
								$retorno['tipo']     = 'success';
								$retorno['mensagem'] = 'registro atualizado com sucesso';
								$retorno['dados']    = $_POST;
								throw new Exception(json_encode($retorno), 1);
							}else{
								$retorno['codigo']   = 0;
								$retorno['tipo']     = 'danger';
								$retorno['mensagem'] = 'Erro ao atualizar registro';
								$retorno['dados']    = $_POST;
								throw new Exception(json_encode($retorno), 1);
							}
						}
					}
				}elseif(isset($_POST['tipo_record']) && $_POST['tipo_record'] == 'credito'){
					//verificar se o id da nota fiscal é valido
					if(isset($_POST['id_record']) && !empty($_POST['id_record']) && is_numeric($_POST['id_record'])){
						//get dados da nota fiscal
						$nf = json_decode($this->obj_nf->getNota($_POST['id_record']));
						//verifica se a nota fiscal existe
						if($nf){
							$param['status'] 	  = 'recebido';
							$param['id_extrato']  = $_POST['fitid'].$_POST['id_extrato'];
							$param['observacoes'] = $_POST['fitid'];
							//caso da data de lancamento(recebimento) não seja informado assume a data atual da operacao
							if(isset($_POST['data_operacao']) && !empty($_POST['data_operacao'])){
								$data_operacao        = new DateTime($_POST['data_operacao']);
								$param['recebido_em'] = $_POST['data_operacao'];
							}else{
								$data_operacao        = clone $this->data_hora_atual;
								$param['recebido_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
							}
							//verifica se as datas são objetos do tipo datetime
							if(is_object($data_operacao)){
								//chama a funcão que irá calcular multa e juros
								$vencimento_em = new DateTime($nf[0]->data_vencimento);
								$juros_multa   = json_decode($this->obj_fat->calcMultaJuros($nf[0]->id_contrato, $vencimento_em, $data_operacao, $nf[0]->valor_total));
								if($juros_multa && $juros_multa->tipo != 'danger'){
									$descricao_multa = "Multa referente a NF com vencimento em ".$vencimento_em->format('d/m/Y')." paga em ".$data_operacao->format('d/m/Y');
									$descricao_juros = "Juros referente a NF com vencimento em ".$vencimento_em->format('d/m/Y')." paga em ".$data_operacao->format('d/m/Y');
									$padm['id_contrato'] 	 = $nf[0]->id_contrato;
									$padm['codigo_cliente']  = $nf[0]->codigo_cliente;
									$padm['codigo_produto']  = 'ADM0001';
									$padm['codigo_modulo']   = 'ADM0011';
									$padm['qtd_transacoes']  = 1;
									$padm['valor_calculado'] = $juros_multa->dados->subtotal;
									$padm['data_tarifacao']  = $data_operacao->format('Y-m-d');
									$padm['data_operacao']   = $this->data_hora_atual->format('Y-m-d');
									$padm['status_trans']    = 'ativo';
									$padm['nsu'] 			 = '0000000000';
									$padm['tipo_tarifacao']  = 'auto';
									$id_mov_diario = $this->obj_movimento->insertMov($padm);
									if($id_mov_diario){
										$pm['id_mov_diario']  = $id_mov_diario;
										$pm['id_contrato']    = $nf[0]->id_contrato;
										$pm['codigo_produto'] = $nf[0]->codigo_produto;
										$pm['id_nf_origem']   = $nf[0]->id;
										$pm['origem']         = 'nota fiscal';
										$pm['tipo']           = 'multa';
										$pm['valor_base']     = $nf[0]->valor_total;
										$pm['valor_calculado']= $juros_multa->dados->valor_multa;
										$pm['data_tarifacao'] = $this->data_hora_atual->format('Y-m-d');
										$pm['vencimento_em']  = $vencimento_em->format('Y-m-d');
										$pm['recebido_em']    = $data_operacao->format('Y-m-d');
										$pm['descricao']      = $descricao_multa;
										$pm['status']         = 'pendente';
										
										$pj['id_mov_diario']  = $id_mov_diario;
										$pj['id_contrato']    = $nf[0]->id_contrato;
										$pj['codigo_produto'] = $nf[0]->codigo_produto;
										$pj['id_nf_origem']   = $nf[0]->id;
										$pj['origem']         = 'nota fiscal';
										$pj['tipo']           = 'juros';
										$pj['valor_base']     = $nf[0]->valor_total;
										$pj['valor_calculado']= $juros_multa->dados->valor_juros;
										$pj['data_tarifacao'] = $this->data_hora_atual->format('Y-m-d');
										$pj['vencimento_em']  = $vencimento_em->format('Y-m-d');
										$pj['recebido_em']    = $data_operacao->format('Y-m-d');
										$pj['descricao']      = $descricao_juros;
										$pj['status']         = 'pendente';
										$id_mov_aux_multa = $this->obj_nf->insertMovAux($pm);
										$id_mov_aux_juros = $this->obj_nf->insertMovAux($pj);
										if(!$id_mov_aux_multa || !$id_mov_aux_juros){
											$retorno['codigo']   = 1;
											$retorno['tipo']     = 'danger';
											$retorno['mensagem'] = 'Erro ao lançar multa e juros para a proxima fatura';
											$retorno['dados']    = $juros_multa ;
											throw new Exception(json_encode($retorno), 1);
										}
									}
								}else{
									$retorno['codigo']   = 1;
									$retorno['tipo']     = 'danger';
									$retorno['mensagem'] = 'Erro ao calcular juros e multa';
									$retorno['dados']    = $juros_multa ;
									throw new Exception(json_encode($retorno), 1);
								}
								//salva as informacoes da nota
								$is_save = $this->obj_nf->save($param, $_POST['id_record']);
								if($is_save){
									$retorno['codigo']   = 0;
									$retorno['tipo']     = 'success';
									$retorno['mensagem'] = 'Lançamento conciliado com sucesso';
									$retorno['dados']    = $_POST;
									throw new Exception(json_encode($retorno), 1);
								}else{
									$retorno['codigo']   = 1;
									$retorno['tipo']     = 'danger';
									$retorno['mensagem'] = 'Erro ao salvar registro NF';
									$retorno['dados']    = $_POST;
									throw new Exception(json_encode($retorno), 1);
								}
							}else{
								$retorno['codigo']   = 1;
								$retorno['tipo']     = 'danger';
								$retorno['mensagem'] = 'Erro na data de vencimento ou de operação!';
								$retorno['dados']    = $_POST;
								throw new Exception(json_encode($retorno), 1);
							}
						}else{
							$retorno['codigo']   = 1;
							$retorno['tipo']     = 'danger';
							$retorno['mensagem'] = 'NF não localizada!';
							$retorno['dados']    = $_POST;
							throw new Exception(json_encode($retorno), 1);
						}					
					}else{
						$retorno['codigo']   = 1;
						$retorno['tipo']     = 'danger';
						$retorno['mensagem'] = 'ID NF invalido';
						$retorno['dados']    = $_POST;
						throw new Exception(json_encode($retorno), 1);
					}
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}				
		}

		function insertDespesa(){
			try {
				if($_POST){
					if($_POST['codigo_banco'] == 341){
						$param['id_extrato'] = $_POST['checknum'];
					}else{
						$param['id_extrato'] = $_POST['fitid'].$_POST['checknum'];	
					}
					$param['id_cm']			     = $_POST['id_cm'];				
					$param['id_fornecedor']	     = $_POST['id_fornecedor'];	
					$param['id_centro_custo']    = $_POST['id_centro_custo'];	
					$param['id_grupo']		     = $_POST['id_grupo'];
					$param['id_conta']		     = $_POST['id_conta'];
					$param['id_subconta'] 	     = $_POST['id_subconta'];
					$param['data_vencimento']    = $_POST['data_operacao'];
					$param['data_pagamento']     = $_POST['data_operacao'];
					$param['valor']              = $_POST['valor'];
					$param['descricao']          = $_POST['fitid'];
					$param['tipo']       	     = $_POST['tipo'];
					$param['tipo_cobranca']      = $_POST['tipo_cobranca'];
					$param['prioridade']         = $_POST['prioridade'];
					$param['meio_pagamento']     = $_POST['meio_pagamento'];
					$param['historico']          = $_POST['historico'];
					$param['tipo']       	     = $_POST['tipo'];
					$param['flag_aprovacao']     = 'automatico';
					$param['status']  		     = 'pago';
					$param['parcelado']          = '0';
					$param['numero_parcelas']    = '1';
					$param['status_autorizacao'] = 'pendente';
					$param['autorizado_por']     = $this->userdata->id;
					$param['autorizado_em']      = $this->data_hora_atual->format('Y-m-d H:i:s');
					$is_save = $this->obj_desp->save($param);
					if($is_save){
						$retorno['codigo']   = 0;
						$retorno['tipo']     = 'success';
						$retorno['mensagem'] = 'Despesa classificada com sucesso';
						$retorno['dados']    = $param;
						throw new Exception(json_encode($retorno), 1);
					}else{
						$retorno['codigo']   = 1;
						$retorno['tipo']     = 'danger';
						$retorno['mensagem'] = 'Erro ao classificar a despesa';
						$retorno['dados']    = $param;
						throw new Exception(json_encode($retorno), 1);
					}			
				}else{
					$retorno['codigo']   = 1;
					$retorno['tipo']     = 'danger';
					$retorno['mensagem'] = 'Dados inconsistentes';
					$retorno['dados']    = $param;
					throw new Exception(json_encode($retorno), 1);
				}	
			} catch (Exception $e) {
				echo $e->getMessage();
			}
			
		}

		// function getBancosJson(){
		// 	try {
		// 		$bancos = null;
		// 		if(!is_numeric($this->parametros[1]) || empty($this->parametros[1])){
		// 			$retorno['codigo']   = 2;
		// 			$retorno['tipo']     = 'warning';
		// 			$retorno['mensagem'] = 'Cadastro novo não possui banco cadastrado';
		// 			$retorno['input']    = $_POST;
		// 			$retorno['output']   = $this->parametros;
		// 			throw new Exception(json_encode($retorno), 1);
		// 		}
				
		// 		if('fornecedor' == $this->parametros[0]){
		// 			$bancos = json_decode($this->class_conta_bancaria->getContaByFornecedor($this->parametros[1]));
		// 		}else{
		// 			$bancos = json_decode($this->class_conta_bancaria->getContaByEmpresa($this->parametros[1]));
		// 		}

		// 		if($bancos){
		// 			$retorno['codigo']   = 0;
		// 			$retorno['tipo']     = 'success';
		// 			$retorno['mensagem'] = 'Bancos cadastrados';
		// 			$retorno['input']    = $this->parametros;
		// 			$retorno['output']   = $bancos;
		// 			throw new Exception(json_encode($retorno), 1);
		// 		}else{
		// 			$retorno['codigo']   = 2;
		// 			$retorno['tipo']     = 'warning';
		// 			$retorno['mensagem'] = 'Nenhum banco cadastrado';
		// 			$retorno['input']    = $this->parametros;
		// 			$retorno['output']   = $bancos;
		// 			throw new Exception(json_encode($retorno), 1);
		// 		}
		// 	} catch (Exception $e) {
		// 		echo $e->getMessage();
		// 	}
		// }

		function save(){
			try {
				$clean_default = null;
				$param['ispb_banco']       = $_POST['ispb_banco'];
				$param['nome_reduzido']    = $_POST['nome_reduzido'];
				$param['codigo_banco']     = $_POST['codigo_banco'];
				$param['participa_compe']  = $_POST['participa_compe'];
				$param['acesso_principal'] = $_POST['acesso_principal'];
				$param['nome_extenso']     = $_POST['nome_extenso'];
				$param['inicio_operacao']  = convertDate($_POST['inicio_operacao']);
				$param['status']           = $_POST['status'];
				$is_save                   = $this->modelo->save($param);
				if($is_save){
					$retorno['codigo']   = 0;
					$retorno['tipo']     = 'success';
					$retorno['mensagem'] = 'Dados Salvos com sucesso';
					$retorno['input']    = $_POST;
					$retorno['output']   = $is_save;
					header('location: /banco/detalhe/id/'.$is_save);
				}else{
					$retorno['codigo']   = 1;
					$retorno['tipo']     = 'danger';
					$retorno['mensagem'] = 'Erro ao salvar banco';
					$retorno['input']    = $_POST;
					$retorno['output']   = $is_save;
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function action(){
			try {
				switch ($this->parametros[0]) {
					case 'apagar':
						if(is_numeric($this->parametros[1]) && !empty($this->parametros[1])){
							$param['deleted'] = 1;
							$is_save = $this->modelo->save($param, $this->parametros[1]);
							if($is_save){
								$retorno['codigo']   = 0;
								$retorno['tipo']     = 'success';
								$retorno['mensagem'] = 'Registro apagado com sucesso';
								$retorno['input']    = $this->parametros;
								$retorno['output']   = $is_save;
								throw new Exception(json_encode($retorno), 1);
							}else{
								$retorno['codigo']   = 1;
								$retorno['tipo']     = 'danger';
								$retorno['mensagem'] = 'Erro ao apagar registro';
								$retorno['input']    = $this->parametros;
								$retorno['output']   = $is_save;
								throw new Exception(json_encode($retorno), 1);	
							}
						}else{
							$retorno['codigo']   = 1;
							$retorno['tipo']     = 'danger';
							$retorno['mensagem'] = 'ID do banco invalido';
							$retorno['input']    = $this->parametros;
							$retorno['output']   = null;
							throw new Exception(json_encode($retorno), 1);
						}
					break;
					default:
						# code...
					break;
				}
			}catch (Exception $e) {
				echo $e->getMessage();
			}
		}
	}
