<?php

class BoletosController extends MainController{
	protected $module = 'boletos';
	protected $obj_nf;
	protected $obj_boleto;
	function __construct($parametros = null){
		set_time_limit(1800);//coloque no inicio do arquivo
		ob_implicit_flush(true);
		$this->nome_modulo = 'boletos';
		parent::__construct($parametros);
		$this->obj_nf 	  = $this->load_model('notas-fiscais/notas-fiscais', true);
		$this->obj_boleto = new Boleto();
	}

	function index(){
		$this->listar();
	}

	function listar(){
		$id_remessa = null;
		$id_boleto  = null;
		if(isset($this->parametros[0]) && $this->parametros[0] == 'id'){
			if(!empty($this->parametros[1]) && is_numeric($this->parametros[1])){
				$id_boleto = $this->parametros[1];
			}
		}

		if(isset($this->parametros[0]) && $this->parametros[0] == 'id_remessa'){
			if(!empty($this->parametros[1]) && is_numeric($this->parametros[1])){
				$id_remessa = $this->parametros[1];
			}
		}

		$boletos = json_decode($this->obj_boleto->getBoleto($id_boleto, $id_remessa));
		require_once ABSPATH . '/views/'.$this->module.'/boletos-list-view.php';
	}

	function detalhe(){
		if(isset($this->parametros[1]) && is_numeric($this->parametros[1])){
			$boleto = json_decode($this->obj_boleto->getBoleto($this->parametros[1]));	
		}else{
			echo 'ID boleto invalido';
			exit;
		}
	}
	
	function remessas(){
		$remessas = json_decode($this->obj_boleto->getRemessa());
		require_once ABSPATH . '/views/'.$this->module.'/remessas-list-view.php';
	}

	function retorno(){

		require_once ABSPATH . '/views/'.$this->module.'/retorno-list-view.php';
	}

	function processarRetorno(){
		$arquivo = fopen ($_POST['file_retorno']['tmp_name'], 'r');
		while(!feof($arquivo)){
			$row = fgets($arquivo, 1024);
			if($row){
				$linha[] = $row;
			}
		}
	}

	function gerar(){
		try {
			if(isset($_POST['contrato']) && !empty($_POST['contrato'])){
				if($_POST['banco_boleto'] && !empty($_POST['banco_boleto'])){
					$nfs     = null;
					$boletos = null;
					foreach ($_POST['contrato'] as $key => $value){
						if(!empty($value['id_nf']) && is_numeric($value['id_nf'])){
							$array_nf[] = $value['id_nf'];
						}else{
							$retorno[$key]['codigo']   = 1;
							$retorno[$key]['tipo']	   = 'danger';
							$retorno[$key]['mensagem'] = 'Erro nos dados da nota';
							$retorno[$key]['dados']    = $value;
							throw new Exception(json_encode($retorno), 1);
						}
					}
					if(count($array_nf) > 0){
						$nfs     = json_decode($this->obj_nf->getNotaEcontrato($array_nf));
						$boletos = json_decode($this->obj_boleto->gerarBoleto($_POST['banco_boleto'], $nfs));
						if(!$boletos->erro_processo){
							header('Location: /boletos/');
						}else{
							//implementar erro
							echo 'Erro ao gerar boleto';
						}
					}else{
						$retorno[$key]['codigo']   = 1;
						$retorno[$key]['tipo']	   = 'danger';
						$retorno[$key]['mensagem'] = 'Erro ao contabilizar notas';
						$retorno[$key]['dados']    = $array_nf;
					}
				}else{
					$retorno[$key]['codigo']   = 1;
					$retorno[$key]['tipo']	   = 'danger';
					$retorno[$key]['mensagem'] = 'Informe o banco conveniado para geração de boleto';
					$retorno[$key]['dados']    = $_POST['contrato'];
				}
			}else{
				$retorno[$key]['codigo']   = 1;
				$retorno[$key]['tipo']	   = 'danger';
				$retorno[$key]['mensagem'] = 'Informe os dados da nota para gerar o boleto';
				$retorno[$key]['dados']    = $_POST['contrato'];
			}
			throw new Exception(json_encode($retorno), 1);
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function gerarremessa(){
		try {
			if(is_array($_POST)){
				$boletos = json_decode($this->obj_boleto->getBoleto($_POST['boletos']));
				if($boletos){
					$dados_remessa = json_decode($this->obj_boleto->tratarDados($boletos));
					if($dados_remessa && !$dados_remessa->erro_processo){
						$result = json_decode($this->obj_boleto->gerarRemessa($dados_remessa->{0}->dados));
						if(!$result->erro_processo){
							header('Location: /boletos/remessas/');
						}else{
							$retorno[0]['codigo']   = 2;
							$retorno[0]['tipo']	    = 'danger';
							$retorno[0]['mensagem'] = 'Erro ao gerar remessa na camada controller';
							$retorno[0]['dados']    = $dados_remessa[0]->dados;
						}
					}else{
						$retorno[0]['codigo']   = 2;
						$retorno[0]['tipo']	    = 'danger';
						$retorno[0]['mensagem'] = 'Erro ao tratar dados da remessa camada controller';
						$retorno[0]['dados']    = $boletos;
					}
				}else{
					$retorno[0]['codigo']   = 2;
					$retorno[0]['tipo']	    = 'danger';
					$retorno[0]['mensagem'] = 'Dados de boletos não encontrados';
					$retorno[0]['dados']    = $dados_remessa[0]->dados;
				}
			}else{
				$retorno[0]['codigo']   = 2;
				$retorno[0]['tipo']	    = 'danger';
				$retorno[0]['mensagem'] = 'Dados de POST não podem ser nulos';
				$retorno[0]['dados']    = $_POST;
			}
			throw new Exception(json_encode($retorno), 1);
		} catch (Exception $e){
			echo $e->getMessage();
		}
	}

	function downloadRemessa(){
		try {
			if(isset($this->parametros[1]) && is_numeric($this->parametros[1])){
				$gerar_arquivo = json_decode($this->obj_boleto->gerarArquivo($this->parametros[1]));
				if($gerar_arquivo[0]->codigo == 0){
					$convenio = $gerar_arquivo[0]->dados[0]->codigo_convenio;
					$arquivo  = $gerar_arquivo[0]->dados[0]->nome_arquivo;
					$this->obj_boleto->downloadArquivo($convenio, $arquivo);
				}else{
					$retorno[0]['codigo']   = 2;
					$retorno[0]['tipo']	    = 'danger';
					$retorno[0]['mensagem'] = 'Erro ao gerar arquivo';
					$retorno[0]['dados']    = $gerar_arquivo;
					$retorno[0]['erro']     = '';
					throw new Exception(json_encode($retorno), 1);
				}
			}else{
				$retorno[0]['codigo']   = 2;
				$retorno[0]['tipo']	    = 'danger';
				$retorno[0]['mensagem'] = 'ID remessa invalido';
				$retorno[0]['dados']    = $this->parametros;
				$retorno[0]['erro']     = '';
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function viewpdf(){
		try {
			if(isset($this->parametros[1]) && is_numeric($this->parametros[1])){
				$boleto = json_decode($this->obj_boleto->getBoleto($this->parametros[1]));
				if($boleto){
					$data_vencimento = new DateTime($boleto[0]->vencimento);
					$sacado = new OpenBoleto\Agente($boleto[0]->razao_social_sacado, $boleto[0]->cnpj_cedente, $boleto[0]->endereco_cedente, $boleto[0]->cep_cedente, null, null);
					$cedente = new OpenBoleto\Agente($boleto[0]->razao_social_cedente, $boleto[0]->cnpj_cedente, $boleto[0]->endereco_cedente, $boleto[0]->cep_cedente, null, null);
					$obj_boleto = new OpenBoleto\Banco\Bradesco(array(
					    // Parâmetros obrigatórios
					    'dataVencimento' => $data_vencimento,
					    'valor' => $boleto[0]->valor,
					    'sequencial' => $boleto[0]->nosso_numero, // Até 11 dígitos
					    'sacado' => $sacado,
					    'cedente' => $cedente,
					    'agencia' => $boleto[0]->agencia, // Até 4 dígitos
					    'carteira' => 9, // 3, 6 ou 9
					    'conta' => $boleto[0]->conta, // Até 7 dígitos
					    // Parâmetros recomendáveis
					    //'logoPath' => 'http://empresa.com.br/logo.jpg', // Logo da sua empresa
					    'contaDv' => $boleto[0]->conta_dv,
					    'agenciaDv' => $boleto[0]->agencia_dv,
					    'carteiraDv' => 1,
					    'descricaoDemonstrativo' => array( // Até 5
					        'Após o '.$data_vencimento->format('d/m/Y').' cobrar R$ '.number_format($boleto[0]->valor_multa, '2',',','.').' de multa e R$ '.number_format($boleto[0]->valor_dia_atraso, '2',',','.').' por dia de atraso.',
					        'Protestar 5 dias após o vencimento',
					    ),
					    'instrucoes' => array('Após o '.$data_vencimento->format('d/m/Y').' cobrar R$ '.number_format($boleto[0]->valor_multa, '2',',','.').' de multa e R$ '.number_format($boleto[0]->valor_dia_atraso, '2',',','.').' por dia de atraso.',
					        'Protestar 5 dias após o vencimento',
					    ),
					    'numeroDocumento' => $boleto[0]->nosso_numero,
					    'moeda' => 9,
					    'aceite' => 'N',
					    'quantidade' => '',
					    'valorCobrado' => '',
					    'valorUnitario' => '',
					    // Parâmetros opcionais
					    //'resourcePath' => '../resources',
					    //'cip' => '000', // Apenas para o Bradesco
					    //'moeda' => Bradesco::MOEDA_REAL,
					    //'dataDocumento' => new DateTime(),
					    //'dataProcessamento' => new DateTime(),
					    //'contraApresentacao' => true,
					    //'pagamentoMinimo' => 23.00,
					    //'aceite' => 'N',
					    //'especieDoc' => 'ABC',
					    //'numeroDocumento' => '123.456.789',
					    //'usoBanco' => 'Uso banco',
					    //'layout' => 'layout.phtml',
					    //'logoPath' => 'http://boletophp.com.br/img/opensource-55x48-t.png',
					    //'sacadorAvalista' => new Agente('Antônio da Silva', '02.123.123/0001-11'),
					    //'descontosAbatimentos' => 123.12,
					    //'moraMulta' => 123.12,
					    //'outrasDeducoes' => 123.12,
					    //'outrosAcrescimos' => 123.12,
					    //'valorCobrado' => 123.12,
					    //'valorUnitario' => 123.12,
					    //'quantidade' => 1,
						));
					echo $obj_boleto->getOutput();
				}else{
					//implementar erro
				}
			}else{
				//implementar erro
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function downloadBoleto(){
		try{
			if(isset($this->parametros[0]) && is_numeric($this->parametros[0])){
				$boleto = json_decode($this->obj_boleto->getBoleto($this->parametros[0]));
				if($boleto){
					$path_file = UP_ABSPATH.'remessa-boleto'.DS.$boleto[0]->codigo_convenio.DS.'BC'.$boleto[0]->num_seq_boleto.'.pdf';
					if(!file_exists($path_file)){
						//gera o arquivo caso não exista
						$this->obj_boleto->gerarMidiaBoleto($this->parametros[0]);
					}
					header('Cache-control:private');
					header('Content-type: application/pdf');
					header('Content-Length:'.filesize($path_file));
					header('Content-Disposition:filename='.'BC'.$boleto[0]->num_seq_boleto.'.pdf');
					header("Content-Disposition:attachment; filename=".'BC'.$boleto[0]->num_seq_boleto.'.pdf');
					readfile($path_file);
				}else{
					$retorno[0]['codigo']   = 2;
					$retorno[0]['tipo']	    = 'danger';
					$retorno[0]['mensagem'] = 'Boleto não encontrado';
					$retorno[0]['dados']    = $this->parametros;
					$retorno[0]['erro']     = '';
					throw new Exception(json_encode($retorno), 1);	
				}		
			}else{
				$retorno[0]['codigo']   = 2;
				$retorno[0]['tipo']	    = 'danger';
				$retorno[0]['mensagem'] = 'identificaçao do boleto invalido';
				$retorno[0]['dados']    = $this->parametros;
				$retorno[0]['erro']     = '';
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function gerarPdf(){
		if(isset($this->parametros[0]) && is_numeric($this->parametros[0])){
			return $this->obj_boleto->gerarMidiaBoleto($this->parametros[0]);
		}
	}
}