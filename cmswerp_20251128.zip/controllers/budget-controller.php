<?php
set_time_limit(30600);//coloque no inicio do arquivo
class BudgetController extends MainController{
	protected $module = 'budget';
	public $obj_contrato;
	public $obj_orcamento;
	public $obj_despesa;
	public $obj_quotas;
	public $obj_faturamento;
	public $obj_nf;
	public $centro_custo;
	public $grupo;
	public $conta;
	public $subconta;
	public $quotas;
	public $orcamento;
	public $despesas;
	public $faturado;
	public $recebido;
	
	function __construct($parametros = null){
		$this->nome_modulo = 'budget';
		parent::__construct($parametros);
		$this->obj_contrato    = $this->load_model('contratos/contratos', true);
		$this->obj_orcamento   = $this->load_model('orcamento/orcamento', true);
		$this->obj_despesa     = $this->load_model('despesas/despesas', true);
		$this->obj_faturamento = $this->load_model('faturamento/faturamento', true);
		$this->obj_quotas      = $this->load_model('quotas/quotas', true);
		$this->obj_nf          = $this->load_model('notas-fiscais/notas-fiscais', true);
	}

	function index(){
		$this->listar();
	}

	function listar(){
		set_time_limit(1800);//coloque no inicio do arquivo
		
		$tabela_budget = null;
		$param = null;
		$faturamento_upselling = null;
		$contratos = json_decode($this->obj_contrato->contratosAtivos(null, false, true));
		
		// if(
		// 	$_SESSION['cmswerp']['userdata']->email != 'orli@cmsw.com' &&
		// 	$_SESSION['cmswerp']['userdata']->email != 'jaqueline@cmsw.com@cmsw.com' &&
		// 	$_SESSION['cmswerp']['userdata']->email != 'julio.gomes@cmsw.com'
		// ){
		// 	echo 'Erro de permissÃ£o';
		// 	exit;
		// }
			
			$tabela_budget         	= null;
			$faturamento_global    	= null;
			$faturamento_comercial 	= null;

			//$soma_pacote_global 	 = json_decode($this->obj_faturamento->getSomaPacote());
			//$soma_pacote_comercial = json_decode($this->obj_faturamento->getSomaPacote(null, 'comercial'));
			//$soma_pacote_upselling = json_decode($this->obj_faturamento->getSomaPacote(null, 'upselling'));
			
			$this->centro_custo 	= json_decode($this->obj_orcamento->getCentroCusto());
			$this->grupo 			= json_decode($this->obj_orcamento->getGrupo());
			$this->conta 			= json_decode($this->obj_orcamento->getConta());
			$this->subconta 		= json_decode($this->obj_orcamento->getSubConta());
	
			if(isset($_POST['ano']) && !empty($_POST['ano']) && is_numeric($_POST['ano'])){
				$ano             = $_POST['ano'];
				$param['ano']    = $ano;
				$param['dt_ini'] = new DateTime($_POST['ano'].'-01-01');
				$param['dt_fim'] = new DateTime($_POST['ano'].'-12-31');
			}else{
				$ano             = $this->data_hora_atual->format('Y');
				$_POST['ano']	 = $ano;
				$_POST['ano']    = $this->data_hora_atual->format('Y');
				$param['ano']    = $ano;
				$param['dt_ini'] = clone $this->data_hora_atual;
				$param['dt_ini']->modify('first day of January');
				$param['dt_fim'] = clone $this->data_hora_atual;
				$param['dt_fim']->modify('last day of December');
			}

			if(isset($_POST['agrupar']) && !empty($_POST['agrupar'])){
				$agrupar = $_POST['agrupar'];
				$param['agrupar'] = $agrupar;
			}else{
				$agrupar = 'centro_custo';
				$param['agrupar'] = $agrupar;
			}

			if(isset($_POST['centro_custo']) && !empty($_POST['centro_custo'])){
				$param['filtro'][0]['nome'] = 'centro_custo';
				$param['filtro'][0]['id'] = $_POST['centro_custo'];
				$centro_custo = $_POST['centro_custo'];
			}

			if(isset($_POST['grupo']) && !empty($_POST['grupo'])){
				$param['filtro'][1]['nome'] = 'grupo';
				$param['filtro'][1]['id'] = $_POST['grupo'];
				$grupo = $_POST['grupo'];
			}

			if(isset($_POST['conta']) && !empty($_POST['conta'])){
				$param['filtro'][2]['nome'] = 'conta';
				$param['filtro'][2]['id'] = $_POST['conta'];
				$conta = $_POST['conta'];
			}else{
				$conta = null;
			}

			if(isset($_POST['subconta']) && !empty($_POST['subconta'])){
				$param['filtro'][3]['nome'] = 'subconta';
				$param['filtro'][3]['id'] = $_POST['subconta'];
				$subconta = $_POST['subconta'];
			}

			if(isset($_POST['view']) && !empty($_POST['view'])){
				$param['view'] = $_POST['view'];
				$view          = $_POST['view'];
			}else{
				$view = null;
			}

			if($conta){
				$this->subconta  = json_decode($this->obj_orcamento->getSubContaByConta($conta));
			}else{
				$this->subconta  = null;
			}

			$this->orcamento    = json_decode($this->obj_orcamento->getOrcamentoByParametro($param));
			
			// Orli pediu que no budget mostrasse as contas lanÃ§adas independnetemente de aprovadas ou nÃ£o, caso mude descomente a linha abaixo
			//$param['filtro'][0]['status_autorizacao'] = 'aprovado';

			$this->despesas  = json_decode($this->obj_despesa->getDespesasParametro($param, $view));
			$dados_global    = json_decode($this->obj_faturamento->getFaturamentoPorAno($ano, 'global'));
			$dados_comercial = json_decode($this->obj_faturamento->getFaturamentoPorAno($ano, 'comercial'));
			
			if($dados_global){
				foreach ($dados_global as $k1 => $v1){
					$ano = $v1->ano;
					$mes = $v1->mes;
					$faturamento_global[$ano][$mes] += $v1->valor_total;
				}
			}

			if($dados_comercial){
				foreach ($dados_comercial as $k1 => $v1){
					$ano = $v1->ano;
					$mes = $v1->mes;
					$faturamento_comercial[$ano][$mes] += $v1->valor_total;
				}
			}

			if($contratos){
				foreach ($contratos as $key => $value){
					$dados_upselling = json_decode($this->obj_faturamento->getFaturamentoUpsellingPorAno($ano, 'upselling', $value->id_contrato));
					if($dados_upselling){
						foreach ($dados_upselling as $k1 => $v1){
							$ano = $v1->ano;
							$mes = $v1->mes;
							$faturamento_upselling[$ano][$mes] += $v1->valor_total;
						}
					}else{

						$ano = $this->data_hora_atual->format('Y');
						$mes = $this->data_hora_atual->format('m');
						if($value->upselling == 1){
							$dados_pacote = json_decode($this->obj_faturamento->getSomaPacote($value->id_contrato));
						}else{
							$dados_pacote = null;
						}
						if($dados_pacote){
							$faturamento_upselling[$ano][$mes] += $dados_pacote[0]->valor;
						}else{
							$faturamento_upselling[$ano][$mes] += 0;
						}
						unset($dados_pacote);
					}
				}//fim do foreach sobre contratos
			}//fim if contratos
			
			if($faturamento_global){
				foreach ($faturamento_global as $key => $value){
					foreach ($value as $k1 => $v1) {
						$ano = $key;
						$mes = nomeMes($k1);
						$ultimo_dia_mes = cal_days_in_month(CAL_GREGORIAN, $k1, $ano);
						$dt_ini = new DateTime($ano.$k1.'01');
						$dt_fim = new DateTime($ano.$k1.$ultimo_dia_mes);
						$ultimo_corte = json_decode($this->obj_contrato->getLastDataPagamento());
						if($this->data_hora_atual->format('d') < $ultimo_corte[0]->data_corte_faturamento){
							//$pacotes_restantes = json_decode($this->obj_faturamento->getRestSumPacote($dt_ini->format('Y-m-d'), $dt_fim->format('Y-m-d')));
						}else{
							$pacotes_restantes = 0;
						}
						if(isset($pacotes_restantes)){
							$total_faturamento = ((float)$pacotes_restantes[0]->valor + (float)$v1);
						}else{
							$total_faturamento = ((float) 0 + (float)$v1);
						}
						$tabela_faturamento_global[$mes] = number_format((float)$total_faturamento, 0, ',','.');
						$tabela_faturamento_total[$mes]  += (float)$total_faturamento;
					}
				}
			}

			if($faturamento_comercial){
				foreach ($faturamento_comercial as $key => $value){
					foreach ($value as $k1 => $v1){
						$mes = nomeMes($k1);
						$tabela_faturamento_comercial[$mes] = number_format((float)$v1, 0, ',','.');
						$tabela_faturamento_total[$mes]     += (float)$v1;
					}
				}
			}
			
			if($faturamento_upselling){
				foreach ($faturamento_upselling as $key => $value){
					foreach ($value as $k1 => $v1) {
						$mes = nomeMes($k1);
						$tabela_faturamento_upselling[$mes] = number_format((float)$v1, 0, '.','');
					}
				}
			}

			if($this->orcamento){
				foreach ($this->orcamento as $key => $value) {

					$mes = nomeMes($value->mes);
					$cc  = strtoupper($value->alias_centro_custo);
					$tabela_budget['orcamento']['total'][$mes] += (float)$value->valor;
					$tabela_budget[$cc]['orcamento']['saldo'][$mes] = (float)$value->valor;
					$tabela_budget[$cc]['orcamento'][$mes] = number_format((float)$value->valor, 0, ',','.');
				}
			}

			if($this->despesas){
				foreach ($this->despesas as $key => $value) {
					$mes = nomeMes($value->mes);
					$saldo[$mes] = ($saldo[$mes] - $value->valor);
					$cc = strtoupper($value->nome);
					$tabela_budget['despesas']['total'][$mes] += (float)$value->valor;

					$tabela_budget[$cc]['despesas']['saldo'][$mes] = (float)$value->valor;
					$tabela_budget[$cc]['despesas'][$mes] = number_format((float)$value->valor, 0, ',','.');
				}
			}

			$param['filtro'][5]['status'] = 'pago';
			$despesas_pagas = $this->despesas = json_decode($this->obj_despesa->getDespesasParametro($param, $view));
			if($despesas_pagas){
				foreach ($despesas_pagas as $key => $value) {
					$mes = nomeMes($value->mes);
					$tipo = strtoupper($value->tipo);
					$nome_cc = strtoupper($value->nome);
					$tabela_budget['despesa_paga']['total'][$mes] += (float)$value->valor;
					$tabela_budget[$nome_cc]['despesa_paga'][$mes] = number_format($value->valor, 0, ',','.');
				}
			}

			for($x=1;$x<13;$x++){
				$mes = nomeMes($x);
				if(empty($tabela_faturamento_upselling[$mes])){
					$tabela_faturamento_upselling[$mes] = 0;
				}
			}
			require_once ABSPATH . '/views/'.$this->module.'/budget-view.php';
	}


	function budgetTrimestre(){
		
		set_time_limit(1800);//coloque no inicio do arquivo
		
		$tabela_budget = null;
		$param         = null;
		$view		   = null;	
		
		$this->centro_custo 	= json_decode($this->obj_orcamento->getCentroCusto());
		$this->grupo 			= json_decode($this->obj_orcamento->getGrupo());
		$this->conta 			= json_decode($this->obj_orcamento->getConta());
		$this->subconta 		= json_decode($this->obj_orcamento->getSubConta());

		if(isset($_POST['ano']) && !empty($_POST['ano']) && is_numeric($_POST['ano'])){
			$ano             = $_POST['ano'];
			$param['ano']    = $ano;
			$param['dt_ini'] = new DateTime($_POST['ano'].'-01-01');
			$param['dt_fim'] = new DateTime($_POST['ano'].'-12-31');
		}else{
			$ano             = $this->data_hora_atual->format('Y');
			$_POST['ano']	 = $ano;
			$_POST['ano']    = $this->data_hora_atual->format('Y');
			$param['ano']    = $ano;
			$param['dt_ini'] = clone $this->data_hora_atual;
			$param['dt_ini']->modify('first day of January');
			$param['dt_fim'] = clone $this->data_hora_atual;
			$param['dt_fim']->modify('last day of December');
		}

		if(isset($_POST['agrupar']) && !empty($_POST['agrupar'])){
			$agrupar = $_POST['agrupar'];
			$param['agrupar'] = $agrupar;
		}else{
			$agrupar = 'centro_custo';
			$param['agrupar'] = $agrupar;
		}

		$this->orcamento = json_decode($this->obj_orcamento->getOrcamentoByParametro($param));
		$param['filtro'][5]['status'] = 'pago';
		$this->despesas = json_decode($this->obj_despesa->getDespesasPeriodo('pagamento', $param['dt_ini'], $param['dt_fim'], 'pago'));
		$this->faturado = json_decode($this->obj_faturamento->getFaturamentoPeriodo('emissao', $param['dt_ini'], $param['dt_fim']));
		$this->recebido = json_decode($this->obj_faturamento->getFaturamentoPeriodo('recebimento', $param['dt_ini'], $param['dt_fim']));
		// Orli pediu que no budget mostrasse as contas lançadas independnetemente de aprovadas ou não, caso mude descomente a linha abaixo
		//$param['filtro'][0]['status_autorizacao'] = 'aprovado';
		
		if($this->faturado){
			foreach ($this->faturado as $key => $value) {
				$dt_emissao = new DateTime($value->data_emissao);
				if($dt_emissao->format('m') <= 3){
					$mes = 1;
					$nm  = 't1';
				}elseif($dt_emissao->format('m') > 3 && $dt_emissao->format('m') <= 6){
					$mes = 2;
					$nm  = 't2';
				}elseif($dt_emissao->format('m') > 6 && $dt_emissao->format('m') <= 9){
					$mes = 3;
					$nm  = 't3';
				}elseif($dt_emissao->format('m') > 9 && $dt_emissao->format('m') <= 12){
					$mes = 4;
					$nm  = 't4';
				}
				$mes = $nm ;
				$tabela_faturamento['faturado'][$mes]['valor'] += $value->valor_total;
			}

			foreach ($tabela_faturamento['faturado'] as $key => $value){
				$tabela_faturamento['faturado'][$key]['valor'] = number_format((float)$value['valor'], 0, ',','.');
			}
		}

		if($this->recebido){
			foreach ($this->recebido as $key => $value) {
				$recebido_em = new DateTime($value->recebido_em);
				if($recebido_em->format('m') <= 3){
					$mes = 1;
					$nm  = 't1';
				}elseif($recebido_em->format('m') > 3 && $recebido_em->format('m') <= 6){
					$mes = 2;
					$nm  = 't2';
				}elseif($recebido_em->format('m') > 6 && $recebido_em->format('m') <= 9){
					$mes = 3;
					$nm  = 't3';
				}elseif($recebido_em->format('m') > 9 && $recebido_em->format('m') <= 12){
					$mes = 4;
					$nm  = 't4';
				}
				$mes = $nm ;
				$tabela_faturamento['recebido'][$mes]['valor'] += $value->valor_total;
			}

			foreach ($tabela_faturamento['recebido'] as $key => $value) {
				$tabela_faturamento['recebido'][$key]['valor'] = number_format((float)$value['valor'], 0, ',','.');
			}
		}

		if($this->orcamento){
			foreach ($this->orcamento as $key => $value) {
				if($value->mes <= 3){
					$mes = 1;
					$nm  = 't1';
				}elseif($value->mes > 3 && $value->mes <= 6){
					$mes = 2;
					$nm  = 't2';
				}elseif($value->mes > 6 && $value->mes <= 9){
					$mes = 3;
					$nm  = 't3';
				}elseif($value->mes > 9 && $value->mes <= 12){
					$mes = 4;
					$nm  = 't4';
				}
				$mes = $nm ;
				$cc  = strtoupper($value->alias_centro_custo);
				$tabela_budget['orcamento']['total'][$mes] += (float)$value->valor;
				$tabela_budget[$cc]['orcamento'][$mes]     += $value->valor;
				$tabela_budget[$cc]['saldo'][$mes]         += $value->valor;
			}
		}

		if($this->despesas){
			foreach ($this->despesas as $key => $value) {
				$data_pagamento = new DateTime($value->data_pagamento);
				if($data_pagamento->format('m') <= 3){
					$mes = 1;
					$nm  = 't1';
				}elseif($data_pagamento->format('m') > 3 && $data_pagamento->format('m') <= 6){
					$mes = 2;
					$nm  = 't2';
				}elseif($data_pagamento->format('m') > 6 && $data_pagamento->format('m') <= 9){
					$mes = 3;
					$nm  = 't3';
				}elseif($data_pagamento->format('m') > 9 && $data_pagamento->format('m') <= 12){
					$mes = 4;
					$nm  = 't4';
				}

				$mes = $nm;
				$cc = strtoupper($value->alias);
				$tabela_budget['despesa']['total'][$mes] += (float)$value->valor;
				$tabela_budget[$cc]['despesa'][$mes]     += $value->valor;
				$tabela_budget[$cc]['saldo'][$mes]       -= $value->valor;
			}
		}

		if($tabela_budget){
			foreach ($tabela_budget as $key => $value) {
				if($key != 'despesa' && $key != 'orcamento'){
					foreach ($value as $k1 => $v1) {
						
						if(isset($v1['t1'])) $tabela_budget[$key][$k1]['t1'] = number_format($v1['t1'], '0', ',', '.');
						if(isset($v1['t2'])) $tabela_budget[$key][$k1]['t2'] = number_format($v1['t2'], '0', ',', '.');
						if(isset($v1['t3'])) $tabela_budget[$key][$k1]['t3'] = number_format($v1['t3'], '0', ',', '.');
						if(isset($v1['t4'])) $tabela_budget[$key][$k1]['t4'] = number_format($v1['t4'], '0', ',', '.');
					}
				}
			}
		}

		require_once ABSPATH . '/views/'.$this->module.'/budget-trimestre.php';
	}

	function relacionamento(){
		
		if(isset($_POST['ano']) && is_numeric($_POST['ano'])){
			$ano = $_POST['ano'];
		}else{
			$ano = $this->data_hora_atual->format('Y');
		}

		if(isset($_POST['tipo']) && !empty($_POST['tipo'])){
			$tipo = $_POST['tipo'];
		}else{
			$tipo = 'todos';
		}

		if(isset($this->parametros[0]) && $this->parametros[0] == 'tipo'){
			if($this->parametros[1] == 'upselling'){
				$tipo = 'upselling';
			}else{
				$tipo = 'todos';
			}
		}

		$nfs = json_decode($this->obj_nf->getNfRelacionamento($ano, $tipo));
			
		if($nfs){
			$qac    = 0;
			$meta   = json_decode($this->obj_quotas->quotasUpSelling($ano));
			$quotas = json_decode($this->obj_quotas->getQuotasByAnoEvendedor($ano, null, 'quota_mensal'));
			
			if($meta){
				foreach ($meta as $key => $value) {
					$m = nomeMes($value->mes); //str_pad($value->mes, 2, 0, STR_PAD_LEFT);
					$meta_mensal[$m] = $value->valor;
				}
			}

			if($quotas){
				foreach ($quotas as $key => $value) {
					$m = nomeMes($value->mes); //str_pad($value->mes, 2, 0, STR_PAD_LEFT);
					$quota_mensal[$m] = $value->valor;
				}
			}

			foreach ($nfs as $key => $value) {
				
				$ic = $value->codigo_cliente;
				$im = nomeMes($value->mes);
				$ip = $value->codigo_produto;
				
				if($tipo != 'todos'){
					$param_rel['lanc'][$ic][$ip]['mes'][$im]['valor'] = $value->valor_liquido;
					$param_rel['total_mensal'][$im]                  += $value->valor_liquido;
				}else{
					$param_rel['lanc'][$ic][$ip]['mes'][$im]['valor'] = $value->valor_total;
					$param_rel['total_mensal'][$im]                  += $value->valor_total;
				}

				$param_rel['lanc'][$ic][$ip]['total_anual']      += $value->valor_total;
				$param_rel['lanc'][$ic][$ip]['razao_social']      = $value->razao_social;
				$param_rel['lanc'][$ic][$ip]['nome_fantasia']     = $value->nome_fantasia;
				$param_rel['lanc'][$ic][$ip]['codigo_cliente']    = $value->codigo_cliente;
				$param_rel['lanc'][$ic][$ip]['codigo_produto']    = $value->codigo_produto;
				$param_rel['lanc'][$ic][$ip]['ano']               = $value->ano;
				$param_rel['lanc'][$ic][$ip]['mes'][$im]['mes']   = $value->mes;
				
			}
			
			for($x = 1; $x <= 12; $x++){
				$m = nomeMes($x);
				
				if(!isset($param_rel['total_mensal'][$m])){
					$param_rel['total_mensal'][$m] = 0;
				}

				if(!isset($meta_mensal[$m])){
					$param_rel['meta_mensal'][$m] = 0;
				}else{
					$param_rel['meta_mensal'][$m]  = $meta_mensal[$m];
				}

				if(!isset($quota_mensal[$m])){
					$param_rel['quota_mensal'][$m] = 0;
				}else{
					$param_rel['quota_mensal'][$m] = $quota_mensal[$m];
				}
				
				if($param_rel['total_mensal'][$m] > 0){
					if($param_rel['total_mensal'][$m] > $param_rel['meta_mensal'][$m]){
						$param_rel['meta_acumulada'][$m] = (($param_rel['total_mensal'][$m] - $param_rel['meta_mensal'][$m])+$qac);
						$qac = $param_rel['meta_acumulada'][$m];
					}else{
						if($qac > 0){
							$qac = ($qac - $quota_mensal[$m]);
							$param_rel['meta_acumulada'][$m] = $qac;
						}else{
							$qac -= $quota_mensal[$m];
							$param_rel['meta_acumulada'][$m] = $qac;
						}
					}
				}else{
					$param_rel['meta_acumulada'][$m] = 0;
				}

				if($param_rel['meta_acumulada'][$m] != 0){
					$total_meta_acumulada = $param_rel['meta_acumulada'][$m];	
				}

				$total_meta_mensal    += $param_rel['meta_mensal'][$m];
				$total_quota_mensal   += $param_rel['quota_mensal'][$m];
				$total_anual          += $param_rel['total_mensal'][$m];
			}
			$param_rel = json_encode($param_rel);
			$param_rel = json_decode($param_rel);
		}
		require_once ABSPATH . '/views/'.$this->module.'/relacionamento-view.php';
	}

	function recebimento(){
		if(isset($_POST['ano']) && is_numeric($_POST['ano'])){
			$ano = $_POST['ano'];
		}else{
			$ano = $this->data_hora_atual->format('Y');
		}
		
		$despesas = json_decode($this->obj_despesa->getSomaDespesasAnoMesByPagamento($ano, 'pago'));

		if($despesas){
			foreach ($despesas as $key => $value) {
				$mes = nomeMes($value->mes);
				$param['total']                   += ($value->valor_total + $value->juros_total + $value->multa_total + $value->atmon_total + $value->outros_total - $value->desconto_total - $value->abatimento_total);
				$param['despesas'][$mes]['total']  = ($value->valor_total + $value->juros_total + $value->multa_total + $value->atmon_total + $value->outros_total - $value->desconto_total - $value->abatimento_total);
			}
		}
		
		$nfs = json_decode($this->obj_nf->getNfRecebimento($ano));

        if($nfs){
			$qac    = 0;
			$meta   = json_decode($this->obj_quotas->quotasUpSelling($ano));
			$quotas = json_decode($this->obj_quotas->getQuotasByAnoEvendedor($ano, null, 'quota_mensal'));
			
			if($meta){
				foreach ($meta as $key => $value) {
					$m = nomeMes($value->mes); //str_pad($value->mes, 2, 0, STR_PAD_LEFT);
					$meta_mensal[$m] = $value->valor;
				}
			}

			if($quotas){
				foreach ($quotas as $key => $value) {
					$m = nomeMes($value->mes); //str_pad($value->mes, 2, 0, STR_PAD_LEFT);
					$quota_mensal[$m] = $value->valor;
				}
			}

			foreach ($nfs as $key => $value) {
				
				$ic = $value->codigo_cliente;
				$im = nomeMes($value->mes);
				$ip = $value->codigo_produto;
				
				$param_rel['lanc'][$ic][$ip]['mes'][$im]['valor'] = $value->valor_fatura;
				$param_rel['total_mensal'][$im]                  += $value->valor_fatura;
				// var_dump($value->valor_fatura);
				// exit;
				// $param_rel['lanc'][$ic][$ip]['mes'][$im]['valor'] = $value->valor_total;
				// $param_rel['total_mensal'][$im]                  += $value->valor_total;

				$param_rel['lanc'][$ic][$ip]['total_anual']      += $value->valor_total;
				$param_rel['lanc'][$ic][$ip]['razao_social']      = $value->razao_social;
				$param_rel['lanc'][$ic][$ip]['nome_fantasia']     = $value->nome_fantasia;
				$param_rel['lanc'][$ic][$ip]['codigo_cliente']    = $value->codigo_cliente;
				$param_rel['lanc'][$ic][$ip]['codigo_produto']    = $value->codigo_produto;
				$param_rel['lanc'][$ic][$ip]['ano']               = $value->ano;
				$param_rel['lanc'][$ic][$ip]['mes'][$im]['mes']   = $value->mes;
				
			}
			
			for($x = 1; $x <= 12; $x++){
				$m = nomeMes($x);
				if(!isset($param['despesas'][$m])){
					$param['despesas'][$m]['total'] = 0;
				}

				if(!isset($param_rel['total_mensal'][$m])){
					$param_rel['total_mensal'][$m] = 0;
				}

				if(!isset($meta_mensal[$m])){
					$param_rel['meta_mensal'][$m] = 0;
				}else{
					$param_rel['meta_mensal'][$m]  = $meta_mensal[$m];
				}

				if(!isset($quota_mensal[$m])){
					$param_rel['quota_mensal'][$m] = 0;
				}else{
					$param_rel['quota_mensal'][$m] = $quota_mensal[$m];
				}
				
				if($param_rel['total_mensal'][$m] > 0){
					if($param_rel['total_mensal'][$m] > $param_rel['meta_mensal'][$m]){
						$param_rel['meta_acumulada'][$m] = (($param_rel['total_mensal'][$m] - $param_rel['meta_mensal'][$m])+$qac);
						$qac = $param_rel['meta_acumulada'][$m];
					}else{
						if($qac > 0){
							$qac = ($qac - $quota_mensal[$m]);
							$param_rel['meta_acumulada'][$m] = $qac;
						}else{
							$qac -= $quota_mensal[$m];
							$param_rel['meta_acumulada'][$m] = $qac;
						}
					}
				}else{
					$param_rel['meta_acumulada'][$m] = 0;
				}

				if($param_rel['meta_acumulada'][$m] != 0){
					$total_meta_acumulada = $param_rel['meta_acumulada'][$m];	
				}

				$total_meta_mensal    += $param_rel['meta_mensal'][$m];
				$total_quota_mensal   += $param_rel['quota_mensal'][$m];
				$total_anual          += $param_rel['total_mensal'][$m];
			}
			$param_rel = json_encode($param_rel);
			$param_rel = json_decode($param_rel);
		}
		require_once ABSPATH . '/views/'.$this->module.'/recebimento-view.php';
	}

	function hunterview(){
		if(isset($_POST['ano']) && is_numeric($_POST['ano'])){
			$ano = $_POST['ano'];
		}else{
			$ano = $this->data_hora_atual->format('Y');
		}

		if(isset($_POST['tipo']) && !empty($_POST['tipo'])){
			$tipo = $_POST['tipo'];
		}else{
			$tipo = 'todos';
		}

		$nfs = json_decode($this->obj_quotas->getQuotasByTipo($ano));
			
			if($nfs){
				$param_rel['lanc'] = null;
				$param_rel['total_mensal'] = null;
				$qac    = 0;
				$meta   = json_decode($this->obj_quotas->quotasUpSelling($ano));
				$quotas = json_decode($this->obj_quotas->getQuotasByAnoEvendedor($ano, null, 'vendedor', 'hunter'));

				if($meta){
					foreach ($meta as $key => $value) {
						$m = nomeMes($value->mes); //str_pad($value->mes, 2, 0, STR_PAD_LEFT);
						$meta_mensal[$m] = $value->valor;
					}
				}

				if($quotas){
					foreach ($quotas as $key => $value) {
						$m   = nomeMes($value->mes); //str_pad($value->mes, 2, 0, STR_PAD_LEFT);
						if($value->id_vendedor){
							$idv = $value->id_vendedor;
							$quota_mensal[$idv]['nome_vendedor'] = $value->nome_vendedor;
							$quota_mensal[$idv]['meses'][$m]['valor']     = $value->faturamento_minimo;
						}else{
							$idv = 'unknow';
							$quota_mensal[$idv]['nome_vendedor'] = $idv;
							$quota_mensal[$idv]['meses'][$m]['valor']     = 0;
						}
					}
				}

				foreach ($nfs as $key => $value) {
					
					if(empty($value->nome_vendedor)){
						$value->nome_vendedor = 'unknow';
					}
					
					$ic = $value->codigo_cliente;
					$im = nomeMes($value->nf_mes_emissao);
					$ip = $value->codigo_produto;

					$param_rel['total_mensal'][$im]                   += $value->vr_nf_total;
					$param_rel['lanc'][$ic][$ip]['mes'][$im]['valor'] += $value->vr_nf_total;
					$param_rel['lanc'][$ic][$ip]['total_anual']       += $value->vr_nf_total;
					
					$param_rel['lanc'][$ic][$ip]['nome_vendedor']     = $value->nome_vendedor;
					$param_rel['lanc'][$ic][$ip]['razao_social']      = $value->razao_social;
					$param_rel['lanc'][$ic][$ip]['nome_fantasia']     = $value->nome_fantasia;
					$param_rel['lanc'][$ic][$ip]['codigo_cliente']    = $value->codigo_cliente;
					$param_rel['lanc'][$ic][$ip]['codigo_produto']    = $value->codigo_produto;
					$param_rel['lanc'][$ic][$ip]['ano']               = $value->nf_ano_emissao;
					$param_rel['lanc'][$ic][$ip]['mes'][$im]['mes']   = $value->nf_mes_emissao;
				}
				
				for($x = 1; $x <= 12; $x++){
					
					$m = nomeMes($x);
					
					if(!isset($param_rel['total_mensal'][$m])){
						$param_rel['total_mensal'][$m] = 0;
					}

					if(!isset($meta_mensal[$m])){
						$param_rel['meta_mensal'][$m] = 0;
					}else{
						$param_rel['meta_mensal'][$m]  = $meta_mensal[$m];
					}
					
					foreach ($quota_mensal as $k1 => $v1) {
						$param_rel['quota_mensal'][$k1]['nome_vendedor'] = $v1['nome_vendedor'];
						foreach ($v1['meses'] as $k2 => $v2) {
							if($k2 == $m){
								$param_rel['quota_mensal'][$k1]['meses'][$k2]['valor'] = $v2['valor'];
							}else{
								if(!isset($param_rel['quota_mensal'][$k1]['meses'][$m]['valor'])){
									//echo 'Mes '.$m.' não encontrado <br>';
									$param_rel['quota_mensal'][$k1]['meses'][$m]['valor'] = 0;
								}
							}
						}
					}
				}
			$param_rel = json_encode($param_rel);
			$param_rel = json_decode($param_rel);
		}
		require_once ABSPATH . '/views/'.$this->module.'/hunter-view.php';
	}
}
?>