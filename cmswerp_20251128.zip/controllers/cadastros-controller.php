<?php
	require_once('classes/class-Faturamento.php');
	class CadastrosController extends MainController{
		protected $module = 'cadastros';
		protected $class_conta_bancaria, $obj_indice, $obj_contrato, $obj_produto, $obj_lp_cliente, $obj_movimento, $nf, $dir_historico;
		function __construct($parametros){
			$this->dir_historico = ABSPATH.DS.'arquivos'.DS.'historicos'.DS.'reajustes'.DS;
			$this->nome_modulo   = 'cadastros';
			parent::__construct($parametros);
			$controller           = new MainController(null, 'tarifador', false);
			$this->obj_indice     = $controller->load_model('cadastros/indices-reajuste', true);
			$this->obj_contrato   = $controller->load_model('contratos/contratos', true);
			$this->obj_produto   = $controller->load_model('produtos/produtos', true);
			$this->obj_nf         = $controller->load_model('notas-fiscais/notas-fiscais', true);
			$this->obj_lp_cliente = $controller->load_model('cadastros/lp-cliente', true);
			$controller           = new MainController(null, 'tarifador', false);
			$controller->Db       = new Db(DB_NAME_MOVIMENTO);// Configurando o banco de dados movimento
			$this->obj_movimento  = $controller->load_model('movimento/movimento', true);
			$this->class_conta_bancaria = new ContaBancaria($this);
		}
		

		function index(){
			header('location: /contratos/lista/');
		}

		function diretores(){
			$this->modelo->setTable('diretor_comercial');
			if(!isset($this->parametros[0]) || $this->parametros[0] == 'list')
			{
				$records  = json_decode($this->modelo->getRecords('nome'));
				require_once ABSPATH . '/views/'.$this->module.'/diretores/diretores-view.php';
			}
			if(isset($this->parametros[0]) && $this->parametros[0] == 'detalhe')
			{
				$records  = json_decode($this->modelo->getById($this->parametros[2]));
				require_once ABSPATH . '/views/'.$this->module.'/diretores/diretores-detalhe-view.php';
			}
			if(isset($this->parametros[0]) && $this->parametros[0] == 'save'){
				$check = validaForm($_POST, $required = 'all');
				if($check){
					$this->save($this->parametros[2]);
				}else{
					$this->modelo->error = 'Campos obrigatorios não preenchido';
				}
				$records  = json_decode($this->modelo->getById($this->parametros[2]));
				//require_once ABSPATH . '/views/'.$this->module.'/diretores/diretores-detalhe-view.php';
				header('location: /cadastros/diretores/list/');
			}
		}

		function empresas(){
			$bancos_bacen = json_decode($this->class_conta_bancaria->getBanco());
			$this->modelo->setTable('empresa_vendedora');
			if(!isset($this->parametros[0]) || $this->parametros[0] == 'list'){
				$records  = json_decode($this->modelo->getRecords('nome_fantasia'));
				require_once ABSPATH . '/views/'.$this->module.'/empresas/empresas-view.php';
			}
			if(isset($this->parametros[0]) && $this->parametros[0] == 'detalhe'){
				$records  = json_decode($this->modelo->getById($this->parametros[2]));
				require_once ABSPATH . '/views/'.$this->module.'/empresas/empresas-detalhe-view.php';
			}
			if(isset($this->parametros[0]) && $this->parametros[0] == 'save')	{
				$_POST['cnpj'] = removeCaracteres($_POST['cnpj'], 'char', null);
				$_POST['inscricao_estadual'] = removeCaracteres($_POST['inscricao_estadual'], true, null);
				$_POST['inscricao_municipal'] = removeCaracteres($_POST['inscricao_municipal'], true, null);
				$_POST['cep'] = removeCaracteres($_POST['cep'], 'char');
				$is_save = $this->save($this->parametros[2]);
				header('location: /cadastros/empresas/detalhe/id/'.$this->parametros[2]);
			}

			if(isset($this->parametros[0]) && $this->parametros[0] == 'mudastatus'){
				$is_save = $this->save($this->parametros[2]);
				header('location: /cadastros/empresas/list/');
			}
		}

		function produtos(){
			$this->obj_produto->setTable('produtos');
			if(!isset($this->parametros[0]) || $this->parametros[0] == 'produtos-list'){
				$records  = json_decode($this->obj_produto->getProduto());
				require_once ABSPATH . '/views/'.$this->module.'/produtos/produtos-list.php';
			}

			if(isset($this->parametros[0]) && $this->parametros[0] == 'produto-cadastro'){
				$records  = json_decode($this->obj_produto->getProduto($this->parametros[2]));
				require_once ABSPATH . '/views/'.$this->module.'/produtos/produto-cadastro.php';
			}

			if(isset($this->parametros[0]) && $this->parametros[0] == 'produto-save'){
				$check = validaForm($_POST, $required = 'all');
				if($check){
					$id = $this->save($this->parametros[2]);
					header('location: /cadastros/produtos/produto-detalhe/id/'.$id);
				}else{
					$this->modelo->error = 'Campos obrigatorios não preenchido';
				}
				require_once ABSPATH . '/views/'.$this->module.'/produtos/produto-cadastro.php';
			}

			if(isset($this->parametros[0]) && $this->parametros[0] == 'produto-detalhe'){
				$records  = json_decode($this->obj_produto->getProduto($this->parametros[2]));
				// $this->modelo->setTable('modulos_tarifaveis');
				// $modules  = json_decode($this->obj_produto->getModulosByProdutos($this->parametros[2],'codigo'));
				require_once ABSPATH . '/views/'.$this->module.'/produtos/produto-detalhe.php';
			}

			if(isset($this->parametros[0]) && $this->parametros[0] == 'produto-status'){
				$this->save($this->parametros[2]);
				header('location: /cadastros/produtos/produtos-list/');
			}
			
			if(isset($this->parametros[0]) && $this->parametros[0] == 'modulo-cadastro'){
				$this->modelo->setTable('produtos');
				$produto  = json_decode($this->modelo->getById($this->parametros[1]));
				$this->modelo->setTable('modulos_tarifaveis');
				$modulo  = json_decode($this->modelo->getById($this->parametros[2]));
				require_once ABSPATH . '/views/'.$this->module.'/produtos/modulo-cadastro.php';
			}

			if(isset($this->parametros[0]) && $this->parametros[0] == 'modulo-detalhe'){
				$obj_contrato = $this->load_model('contratos/contratos', true);
				$this->modelo->setTable('produtos');
				$produto = json_decode($this->modelo->getById($this->parametros[1]));
				$this->modelo->setTable('modulos_tarifaveis');
				$modulo  = json_decode($this->modelo->getById($this->parametros[2]));
				// $this->load_model(pricesModelByType(strtolower($modulo->tipo_cobranca)));
				// $precos  = json_decode($this->modelo->getRecordsByModule($modulo->id));
				require_once ABSPATH . '/views/'.$this->module.'/produtos/modulo-detalhe.php';
			}

			if(isset($this->parametros[0]) && $this->parametros[0] == 'modulo-save'){
				$check = validaForm($_POST, $required = 'all');
				if($check){
					$this->modelo->setTable('modulos_tarifaveis');
					$isSave = $this->save($this->parametros[2]);
					header('location: /cadastros/produtos/modulo-detalhe/'.$this->parametros[1].'/'.$isSave);
				}else{
					$this->modelo->error = 'Campos obrigatorios não preenchido';
				}
				require_once ABSPATH . '/views/'.$this->module.'/produtos/modulo-cadastro.php';
			}

			if(isset($this->parametros[0]) && $this->parametros[0] == 'modulo-faixa-save'){
				if(isset($_POST['valor_real'])){ $_POST['valor_real'] = removeCaracteres($_POST['valor_real'], 'moeda', null);}
				if(isset($_POST['valor_relativo'])){ $_POST['valor_relativo'] = removeCaracteres($_POST['valor_relativo'], 'moeda', null);}
				if(isset($_POST['valor_total'])){ $_POST['valor_total'] = removeCaracteres($_POST['valor_total'], 'moeda', null);}
				if(isset($_POST['valor'])){ $_POST['valor'] = removeCaracteres($_POST['valor'], 'moeda', null);}
				$check = validaForm($_POST, $required = 'all');
				if($check){
					$this->modelo->setTable('modulos_tarifaveis');
					$modulo  = json_decode($this->modelo->getById($this->parametros[2]));
					$this->load_model(pricesModelByType(strtolower($modulo->tipo_cobranca)));
					$this->save($this->parametros[3], $_POST);
					header('location: /cadastros/produtos/modulo-detalhe/'.$this->parametros[1].'/'.$this->parametros[2]);
				}else{
					$this->modelo->error = 'Campos obrigatorios não preenchido';
				}
			}
			// Voluetria Methods
			if(isset($this->parametros[0]) && $this->parametros[0] == 'modulo-faixa-cadastro'){
				$this->modelo->setTable('produtos');
				$produto  = json_decode($this->modelo->getById($this->parametros[1]));
				$this->modelo->setTable('modulos_tarifaveis');
				$modulo  = json_decode($this->modelo->getById($this->parametros[2]));
				$this->load_model(pricesModelByType(strtolower($modulo->tipo_cobranca)));
				$preco = json_decode($this->modelo->getRecords($this->parametros[3]));
				require_once ABSPATH . '/views/'.$this->module.'/produtos/faixa-cadastro-'.strtolower($modulo->tipo_cobranca).'.php';
			}

			if(isset($this->parametros[0]) && $this->parametros[0] == 'modulo-faixa-delete'){
				$this->modelo->setTable('produtos');
				$produto  = json_decode($this->modelo->getById($this->parametros[1]));
				$this->modelo->setTable('modulos_tarifaveis');
				$modulo  = json_decode($this->modelo->getById($this->parametros[2]));
				$this->load_model(pricesModelByType(strtolower($modulo->tipo_cobranca)));
				$this->modelo->delete($this->parametros[3]);
				header("location: /cadastros/produtos/modulo-detalhe/".$this->parametros[1]."/".$this->parametros[2]);
			}
		}

		function comerciais(){
			$this->modelo->setTable('comissionados');
			if(!isset($this->parametros[0]) || $this->parametros[0] == 'list'){
				$records  = json_decode($this->modelo->getRecords('nome'));
				require_once ABSPATH . '/views/'.$this->module.'/vendedores/vendedores-view.php';
			}

			if(isset($this->parametros[0]) && $this->parametros[0] == 'detalhe'){
				$records  = json_decode($this->modelo->getRecords($this->parametros[2]));
				require_once ABSPATH . '/views/'.$this->module.'/vendedores/vendedores-detalhe-view.php';
			}

			if(isset($this->parametros[0]) && $this->parametros[0] == 'save'){
				
				$param['nome'] = $_POST['nome'];
				$param['email']        = $_POST['email'];
				$param['cargo'] = 'vendedor';
				$param['departamento'] = 'comercial';
				$param['status'] = $_POST['status'];
				$param['cargo'] = $_POST['cargo'];
				$param['departamento'] = $_POST['departamento'];
				
				if($_POST['ano_entrada']){
					$param['data_admissao'] =  convertDate($_POST['ano_entrada'], true, null);
				}

				if(isset($_POST['ano_saida'] )){
					$param['data_demissao'] =  convertDate($_POST['ano_saida'], true, null);
				}

				if(isset($_POST['winrate'])){
					$param['winrate'] = removeCaracteres($_POST['winrate'], 'moeda2');
				}

				$is_save = $this->modelo->save($param, $this->parametros[2]);

				if($is_save){
					header('location: /cadastros/comerciais/detalhe/id/'.$is_save);
				}else{
					echo 'Erro ao salvar informações!';
				}
			}
		}

		function viewchanges(){
			$id_contrato = $this->parametros[1];
			$obj_contrato = $this->load_model('contratos/contratos', true);
			$cliente = json_decode($obj_contrato->getJustContratos($id_contrato));
			$param = $this->showlistadefault();
			require_once ABSPATH . '/views/contratos/lp-changes-view.php';
		}

		function replicarlista(){
			$id_contrato = $this->parametros[1];
			$id_modulo = $this->parametros[2];
			$obj_contrato = $this->load_model('contratos/contratos', true);
			$lp = $this->showlistadefault();
			$lp_cliente_model =  $this->load_model('cadastros/lp-cliente', true);
			if($lp){
				foreach ($lp as $key => $value) {
					$param['id_contrato']	= $value['id_contrato']	;
					$param['tipo_cobranca']	= $value['tipo_cobranca'];
					$param['id_modulo'] = $value['id_modulo'] ;
					$param['id_produto']	= $value['id_modulo'];
					$param['deleted']	= 0;	
					$param['status'] =  'ativo';

					if(is_array($value['valores'])){
						foreach ($value['valores'] as $chave => $valor) {
							foreach ($valor as $chave2 => $valor2) {
								$param[$chave2] = $valor2;
							}
							$lp_cliente_model->save($param);
						}
					}
				}
			}
			header('location: /cadastros/checklp/');
		}
		
		function checklp(){
			require_once ABSPATH.'/includes/variaveis_sistemas.php';
			global $VAR_SYSTEM;

			$obj_contrato = $this->load_model('contratos/contratos', true);
			$contratos  = json_decode($obj_contrato->getJustContratos());
			require_once ABSPATH . '/views/contratos/check-lp-view.php';
		}

		function chklpproduto(){
			require_once ABSPATH.'/includes/variaveis_sistemas.php';
			global $VAR_SYSTEM;

			$obj_contrato = $this->load_model('contratos/contratos', true);
			$contratos    = json_decode($obj_contrato->getJustContratos());
			$lista_preco  = json_decode($obj_contrato->getLpCodigoCliente($this->parametros[0]));

			if($lista_preco){
				foreach ($lista_preco as $key => $value) {
					
					if($value->ano_reajuste){
						$ano_reajuste = $value->ano_reajuste;
					}else{
						$ano_reajuste = 2010;
					}

					$lp[$value->nome_produto][$value->codigo_modulo]['nome_modulo']                                  = $value->nome_modulo;
					$lp[$value->nome_produto][$value->codigo_modulo][$value->qtd_de][$ano_reajuste]['faixa_de']      = $value->qtd_de;
					$lp[$value->nome_produto][$value->codigo_modulo][$value->qtd_de][$ano_reajuste]['faixa_ate']     = $value->qtd_ate;
					$lp[$value->nome_produto][$value->codigo_modulo][$value->qtd_de][$ano_reajuste]['valor']         = $value->valor_real;
					$lp[$value->nome_produto][$value->codigo_modulo][$value->qtd_de][$ano_reajuste]['status']        = $value->status;
					$lp[$value->nome_produto][$value->codigo_modulo][$value->qtd_de][$ano_reajuste]['ano_reajuste']  = $ano_reajuste;
					$lp[$value->nome_produto][$value->codigo_modulo][$value->qtd_de][$ano_reajuste]['deleted']       = $value->deleted;
					$lp[$value->nome_produto][$value->codigo_modulo][$value->qtd_de][$ano_reajuste]['alterado_em']   = $value->alterado_em;
				}
			}

			require_once ABSPATH . '/views/contratos/check-lp-detalhe.php';
		}

		function chkpctproduto(){
			require_once ABSPATH.'/includes/variaveis_sistemas.php';
			global $VAR_SYSTEM;

			$obj_contrato = $this->load_model('contratos/contratos', true);
			$contratos    = json_decode($obj_contrato->getJustContratos());
			$lista_preco  = json_decode($obj_contrato->getLpCodigoCliente($this->parametros[0]));

			if($lista_preco){
				foreach ($lista_preco as $key => $value) {
					if($value->ano_reajuste){
						$ano_reajuste = $value->ano_reajuste;
					}else{
						$ano_reajuste = 2010;
					}

					$lp[$value->nome_produto][$value->codigo_modulo]['nome_modulo']                                  = $value->nome_modulo;
					$lp[$value->nome_produto][$value->codigo_modulo][$value->qtd_de][$ano_reajuste]['faixa_de']      = $value->qtd_de;
					$lp[$value->nome_produto][$value->codigo_modulo][$value->qtd_de][$ano_reajuste]['faixa_ate']     = $value->qtd_ate;
					$lp[$value->nome_produto][$value->codigo_modulo][$value->qtd_de][$ano_reajuste]['valor']         = $value->valor_real;
					$lp[$value->nome_produto][$value->codigo_modulo][$value->qtd_de][$ano_reajuste]['status']        = $value->status;
					$lp[$value->nome_produto][$value->codigo_modulo][$value->qtd_de][$ano_reajuste]['ano_reajuste']  = $ano_reajuste;
					$lp[$value->nome_produto][$value->codigo_modulo][$value->qtd_de][$ano_reajuste]['deleted']       = $value->deleted;
					$lp[$value->nome_produto][$value->codigo_modulo][$value->qtd_de][$ano_reajuste]['alterado_em']   = $value->alterado_em;
				}
			}

			require_once ABSPATH . '/views/contratos/check-lp-detalhe.php';
		}

		function meiosrecebimentos(){

			if(isset($this->parametros[2]) && is_numeric($this->parametros[2])){
				$id = $this->parametros[2];
			}else{
				$id = null;
			}

			$obj_mr = $this->load_model('cadastros/meios-recebimentos', true);
			$records  = json_decode($obj_mr->getAllMeiosRecebimentos($id));

			if($this->parametros[0] == 'listar'){
				require_once ABSPATH . '/views/'.$this->module.'/meios-recebimentos/meio-recebimento-view.php';
			}elseif($this->parametros[0] == 'detalhe'){
				require_once ABSPATH . '/views/'.$this->module.'/meios-recebimentos/meio-recebimento-detalhe-view.php';
			}elseif($this->parametros[0] == 'save'){
				$obj_mr->save($_POST, $id);
				header('location: /cadastros/meiosrecebimentos/listar/');
			}
		}

		function showDash(){
			$dados = $this->processaGrafico();
			$json_dias = $dados['dias'];
			$json_rck   = $dados['rck'];
			$json_spb = $dados['spb'];
			require_once ABSPATH . '/views/'.$this->module.'/graficos/grafico-dash-view.php';
		}

		function showGrafico(){
			$dados = $this->processaGrafico();
			$json_dias = $dados['dias'];
			$json_rck   = $dados['rck'];
			$json_spb = $dados['spb'];
			require_once ABSPATH . '/views/'.$this->module.'/graficos/grafico-view.php';
		}

		function processaGrafico(){
			$json_dados = $this->getDadosGrafico();
			$obj_dados   = json_decode($json_dados);
			if($obj_dados){
				$data     = null;	
				$dia      = null;
				$p        = null;
				$produtos = null;
				foreach ($obj_dados as $key => $value) {
					$dia = str_replace('-', '', $value->data_tarifacao);
					$p = $value->codigo_produto;
					if(!in_array($dia, $dias)){
						$dias[] = $dia;
					}
					$produtos[$p][$dia] = $value->quantidade;
				}
			}

			if($produtos){
				$dados = null;
				foreach ($dias as $key => $value) {
					foreach ($produtos as $k1 => $v1) {
						if(!array_key_exists($value, $v1)){
							$dados[$k1][$value] = 0;
						}else{
							$dados[$k1][$value] = $v1[$value];
						}
					}
				}
			}

			foreach ($dados as $key => $value) {
				foreach ($value as $k1 => $v1) {
					$show[$key][] = $v1;
				}
			}
			$param['dias'] = json_encode($dias);
			$param['rck']   = json_encode($show['RCK0001']);
			$param['spb'] = json_encode($show['SPB0001']);
			return $param;
		}

		function getDadosGrafico(){
			$dados = $this->obj_movimento->getDadosGrafico();
			return $dados;
		}

		function save( $id = null, $param = null ){
			if( $param ){
				return $this->modelo->save( $param, $id );
			}else{
				return $this->modelo->save( $_POST, $id );
			}
		}

		function delete($param, $id){
			return $this->modelo->delete($param, $id);
		}
	}