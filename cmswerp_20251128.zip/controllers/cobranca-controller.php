<?php
	class CobrancaController extends MainController{
		protected $template;
		protected $cobrancaClass;
		protected $valores;
		public $contratoModel;
		public $movimentoModel;
		public $lpModel;

		function __construct($parametros){
			$this->setModulo('cobranca');
			$this->setView('cobranca');
			parent::__construct( $parametros );
			$this->template 		 = new Templates();
			$this->contratoModel   	 = $this->load_model('contratos/contratos', true);
			$this->lpModel       	 = $this->load_model('lista-precos/lista-precos', true);
			$this->cobrancaClass  	 = new Cobranca($this); 
			$controller           	 = new MainController(null, 'tarifador', false);
			$this->movimentoModel  	 = $controller->load_model('movimento/movimento', true);
			$this->movimentoModel->setDb(new Db( array( 'db_name' => DB_NAME_MOVIMENTO ) ) );
		}

		function index(){
			echo 'Shiii...';
			exit;
		}

		// lista os contratos para executar lancamento manual
		function listarcontratos(){
			$this->contratoModel = $this->load_model('contratos/contratos', true);
			$records  = json_decode($this->contratoModel->contratosAtivos(null, true, true));
			require_once ABSPATH . '/views/'.$this->nome_view.'/listar-contratos-view.php';
		}

		function lancamentomanual(){
			if( isset( $this->parametros[1] ) && is_numeric( $this->parametros[1] ) && !empty( $this->parametros[1] ) ){
				$records = json_decode( $this->contratoModel->contratosAtivos( $this->parametros[1], true, true ) );
				if($records){
					$modulos     = json_decode($this->contratoModel->getModulosByContrato($this->parametros[1], null, true, true ));
					$lancamentos = json_decode($this->movimentoModel->getRelUsuario($records[0]->codigo_cliente, $records[0]->codigo_produto));
					require_once ABSPATH . '/views/'.$this->nome_view.'/lancamento-manual-view.php';
				}else{
					echo 'Contrato não existe';
				}
			}
		}

		function deletelancamento(){
			if($_POST){
				if(isset($_POST['id_rel_usuario']) && !empty($_POST['id_rel_usuario'])){
					$param['deleted'] = 1;
					$this->movimentoModel->updateMov($_POST['id_mov_diario'], $param);
					$this->movimentoModel->updateRel($_POST['id_rel_usuario'], $param);
					header('location: /cobranca/lancamentomanual/id/'.$_POST['id_contrato'].'/');
				}else{
					echo 'Erro ao apagar tarifação informações insuficientes! ';
				}
			}else{
				echo 'Erro ao apagar tarifação! ';
			}
		}

		function savelancamento(){
			if($_POST){
				if(!isset($_POST['contador_trx']) || empty($_POST['contador_trx'])){
					$_POST['contador_trx'] = 1;
				}

				if(!isset($_POST['contador_horas']) || empty($_POST['contador_horas'])){
					$_POST['contador_horas'] = 0;
				}

				$param1['qtd_transacoes'] = $_POST['contador_trx'];
				$param1['valor']   		  = removeCaracteres($_POST['contador_fin'], 'moeda2', null);
				$param1['data_tarifacao'] = convertDate($_POST['data_tarifacao'], true, null);
				$param1['data_operacao']  = date('Y-m-d');
				$param1['id_contrato']    = $_POST['id_contrato'];
				$param1['codigo_cliente'] = $_POST['codigo_cliente'];
				$param1['codigo_produto'] = $_POST['codigo_produto'];
				$param1['flag']           = 'manual';
				$param1['codigo_modulo']  = $_POST['codigo_modulo'];
				// $param1['status_trans']   = 'ativo';
				// $param1['nsu'] = '0000000000';
				$is_save = $this->movimentoModel->insertMov($param1);
				header('location: /cobranca/lancamentomanual/id/'.$_POST['id_contrato'].'/');
			}else{
				echo 'Erro ao inserir tarifação! ';
			}
		}

		function ListaPrecoCliente(){
			$contrato     = $this->contratoModel->getModulosByContrato( $this->parametros[1], null, false, false, false);
			$contrato     = json_decode($contrato);
			if( !$contrato ){
				echo 'Contrato não existe.';
				exit;
			}
			require_once ABSPATH . '/views/'.$this->nome_view.'/cobranca-view.php';
		}

		function detalhe(){
			if( $this->parametros[1] && $this->parametros[2] && $this->parametros[3] ){
				$param_page['id_contrato'] = $this->parametros[1];
				$param_page['id_produto']  = $this->parametros[2];
				$param_page['id_modulo']   = $this->parametros[3];
			}else{
				echo 'Erro ao fornecer algum parametro';
				exit;
			}

			$contrato = json_decode( $this->contratoModel->getModulosByContrato($this->parametros[1], $this->parametros[3], null, null, false ) );
			if( $contrato ){
				$param_page['tipo_cobranca'] = $contrato[0]->tipo_cobranca;
				$param_page['empacotavel']   = $contrato[0]->empacotavel;
				$param_page['tipo_cobranca'] = $contrato[0]->tipo_cobranca;
				$param_page['lista_preco']   = json_decode( $this->lpModel->getLpByCustomer( $this->parametros[1], $this->parametros[3] ) );
				$param_page['pacote']		 = json_decode( $this->modelo->getPacote( $contrato[0]->id_contrato, $this->parametros[3], true ) );
			}else{
				echo 'Erro ao pesquisar contrato';
				exit;
			}
			
			$param_page['titulo'] = $contrato[0]->razao_social.' -> '. $contrato[0]->nome_produto.' -> '.$contrato[0]->nome_modulo.' -> '.$contrato[0]->tipo_cobranca;
			$this->template->setParamPage( $param_page );
			switch ( strtoupper( $contrato[0]->tipo_cobranca ) ) {
				case 'VALOR-FIXO':
					$this->template->loadWindow( $this->getModulo(), 'pacote' );
				break;
				default: // volumetria é o tipo padrão
					$this->template->loadWindow( $this->getModulo(), 'volumetria' );
				break;
			}
		}

		function listaPreco(){
			echo $this->cobrancaClass->listaPreco( $this->parametros[0], $_POST );
		}

		function pacote(){
			echo $this->cobrancaClass->pacote( $this->parametros[0], $_POST );
		}

		function historico(){
			echo $this->cobrancaClass->historico( $this->parametros[0], $this->parametros[1], $_POST );
		}

		function save( $param, $id = null ){
			$this->modelo->setTable('lp_clientes');
			if( isset( $param['action'] ) ){
				unset( $param['action'] );
			}
			return $this->modelo->save( $param, $id );
		}

		function importLpDefault(){
			try {
				if(isset($_POST['id_contrato']) && $_POST['id_contrato'] > 0){
					$dados_contrato = json_decode( $this->contratoModel->contratosAtivos($_POST['id_contrato'], false ) );
					if(!$dados_contrato){
						$retorno['codigo']   = 1;
						$retorno['input']    = $_POST;
						$retorno['output']   = null;
						$retorno['mensagem'] = "Dados do contrato não encontrados!";
						throw new Exception(json_encode($retorno), 1);
					}

					if($dados_contrato[0]->status == 'inativo'){
						$retorno['codigo']   = 1;
						$retorno['input']    = $_POST;
						$retorno['output']   = null;
						$retorno['mensagem'] = "Contrato inativo!";
						throw new Exception(json_encode($retorno), 1);
					}

					$ck_lp = json_decode( $this->lpModel->getLpByCustomer( $_POST['id_contrato'] ) );
					if($ck_lp){
						$retorno['codigo']   = 1;
						$retorno['input']    = $_POST;
						$retorno['output']   = $ck_lp;
						$retorno['mensagem'] = "Este cliente já possui uma lista de preço cadastrada!";
						throw new Exception(json_encode($retorno), 1);
					}

					$lista_default = json_decode($this->modelo->getListaPrecoPadraoIdProduto($dados_contrato[0]->id_produto));
					if(!$lista_default){
						$retorno['codigo']   = 1;
						$retorno['input']    = $_POST;
						$retorno['output']   = null;
						$retorno['mensagem'] = "Nenhuma lista padrão encontrada!";
						throw new Exception(json_encode($retorno), 1);
					}

					$lista_default = json_decode($this->modelo->getListaPrecoPadraoIdProduto($dados_contrato[0]->id_produto));
					if(!$lista_default){
						$retorno['codigo']   = 1;
						$retorno['input']    = $_POST;
						$retorno['output']   = null;
						$retorno['mensagem'] = "Nenhuma lista padrão encontrada!";
						throw new Exception(json_encode($retorno), 1);
					}

					$import = $this->cobrancaClass->importLpDefault($_POST['id_contrato'], $lista_default);
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = "ID do contrato invalido";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}
	}