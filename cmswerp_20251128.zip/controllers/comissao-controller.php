<?php
class ComissaoController extends MainController{

    function __construct ($parametros = null){
        $this->setModulo('comissao');
        $this->setView('comissao');		
        parent::__construct($parametros);			
    }

    function index(){            
        require_once ABSPATH.'/views/'.$this->nome_view.'/index-view.php'; 
    }

    function perfil(){                     
        $comissao_perfil =  json_decode($this->modelo->getComissao()); 
        if(isset($_POST['id_perfil']) && !empty($_POST['id_perfil'])){
            $id_perfil = $_POST['id_perfil'];           
            $comissao = json_decode($this->modelo->getComissao($id_perfil)); 
        }else{
            $comissao = json_decode($this->modelo->getComissao()); 
        }        
        require_once ABSPATH.'/views/'.$this->nome_view.'/perfil_comissao-view.php'; 
    }

    function cadastro(){
        $usuarios_sales = json_decode($this->user_model->getUserByNomeDepartamento('COMERCIAL'));
		$perfil_comissao = json_decode($this->modelo->getPerfilComissao());        
        $comercial_cadastrado = json_decode($this->modelo->getComissaoUsuario());              
        require_once ABSPATH.'/views/'.$this->nome_view.'/comissao-view.php';
    }

    function adicionaComissao(){  

        if(!isset($_POST['nome']) || empty($_POST['nome'])){
            $retorno['codigo']   = 1;
            $retorno['input']    = $_POST;
            $retorno['output']   = null;
            $retorno['mensagem'] = "Informe o perfil comercial";
            throw new Exception (json_encode($retorno), 1);
        }else{					
            $insert['nome'] = strtoupper($_POST['nome']);
            $insert['descricao'] = strtoupper($_POST['nome']);												
        }       

        if(!isset($_POST['objeto']) || empty($_POST['objeto'])){
            $retorno['codigo']   = 1;
            $retorno['input']    = $_POST;
            $retorno['output']   = null;
            $retorno['mensagem'] = "Informe o objeto de comissão";
            throw new Exception (json_encode($retorno), 1);
        }else{					
            $insert['objeto'] = $_POST['objeto'];												
        }      

       if(!isset($_POST['valor_comissao']) || empty($_POST['valor_comissao'])){
            $retorno['codigo']   = 1;
            $retorno['input']    = $_POST;
            $retorno['output']   = null;
            $retorno['mensagem'] = "Informe o valor da comissão";
            throw new Exception (json_encode($retorno), 1);
        }else{	           
            $insert['percentual'] = removeCaracteres($_POST['valor_comissao'], 'moeda2');	
            if(is_numeric($insert['percentual']) != true){
                $retorno['codigo']   = 1;
                $retorno['input']    = $_POST;
                $retorno['output']   = null;
                $retorno['mensagem'] = "A porcentagem deve ser um número";
                throw new Exception (json_encode($retorno), 1);
            }else{
                $insert['percentual'] = $insert['percentual']."%";
            }            										
        }
        
        $this->modelo->setTable('comissoes_perfil');
        $save_perfil = $this->modelo->save($insert);
        if(!$save_perfil){
            $retorno['codigo']   = 1;
            $retorno['input']    = $insert_perfil;
            $retorno['output']   = $this->modelo->info;
            $retorno['mensagem'] = "Erro ao salvar perfil de comissão";
            throw new Exception (json_encode($retorno), 1);
        }else{
            $retorno['codigo']   = 0;
            $retorno['input']    = $insert_cadastro;
            $retorno['output']   = $this->modelo->info;
            $retorno['mensagem'] = "Sucesso";
            throw new Exception (json_encode($retorno), 1);
        }
       
    }

    function deletarComissao(){
        try {
            if(!isset($this->parametros[0]) || empty($this->parametros[0])){
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro parâmetros";
                throw new Exception (json_encode($retorno), 1);
            }else{
                $id_comissao = $this->parametros[0];
            }            

            $comissao_usuario = json_decode($this->modelo->getComissaoUsuario($id_comissao));                                 
            if(isset($comissao_usuario) && !empty($comissao_usuario)){
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Usuários cadastrados com perfil ".$comissao_usuario[0]->nome_perfil.", necessário excluir ";
                throw new Exception (json_encode($retorno), 1);
            }
            
            $comissao = json_decode($this->modelo->getComissao($id_comissao));           
            if(!isset($comissao) || empty($comissao)){
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $id_comissao;
                $retorno['mensagem'] = "Erro em obter comissão";
                throw new Exception (json_encode($retorno), 1);
            }else{
                $deleted['deleted'] = 1;
                $this->modelo->setTable('comissoes_perfil');               
                $save_perfil = $this->modelo->save($deleted, $id_comissao);
                if(!$save_perfil){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $comissao;
                    $retorno['output']   = $this->modelo->info;
                    $retorno['mensagem'] = "Erro ao deletar perfil de comissão";
                    throw new Exception (json_encode($retorno), 1);
                }else{
                    $retorno['codigo']   = 0;
                    $retorno['input']    = $comissao;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Sucesso";
                    throw new Exception (json_encode($retorno), 1);
                }
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
   
    //By: Caio Freitas - 12/07/2022
	function addComissao(){
		try{
			
			if(!isset($_POST['id_usuario']) || empty($_POST['id_usuario'])){
				$retorno['codigo']   = 1;
				$retorno['input']    = $_POST;
				$retorno['output']   = null;
				$retorno['mensagem'] = "Informe o comercial responsável";
				throw new Exception (json_encode($retorno), 1);
			}else{
				$insert_perfil['id_usuario'] = $_POST['id_usuario'];
			}	           

			if(!isset($_POST['id_perfil']) || empty($_POST['id_perfil'])){
				$retorno['codigo']   = 1;
				$retorno['input']    = $_POST;
				$retorno['output']   = null;
				$retorno['mensagem'] = "Informe o perfil de comissão";
				throw new Exception (json_encode($retorno), 1);
			}else{
				$insert_perfil['id_perfil'] = $_POST['id_perfil'];
                $comissao = json_decode($this->modelo->getComissao($insert_perfil['id_perfil']));
                if(!isset($comissao)){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $_POST;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Comissão não encontrada";
                    throw new Exception (json_encode($retorno), 1);
                }   
                $usuario_comissao = json_decode($this->modelo->getComissaoUsuario(null,$insert_perfil['id_usuario']));                
                if(isset($usuario_comissao) && !empty($usuario_comissao)){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $_POST;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Usuário já cadastrado com perfil ".$usuario_comissao[0]->nome_perfil;
                    throw new Exception (json_encode($retorno), 1);
                }             
			}	
                                  			            			
			$this->modelo->setTable('comissoes_usuario');
			$save_perfil = $this->modelo->save($insert_perfil);			
			if(!$save_perfil){
				$retorno['codigo']   = 1;
				$retorno['input']    = $_POST;
				$retorno['output']   = $this->modelo->info;
				$retorno['mensagem'] = "Erro em salvar perfil do usuário";
				throw new Exception (json_encode($retorno), 1);
			}else{
				$retorno['codigo']   = 0;
				$retorno['input']    = $_POST;
				$retorno['output']   = null;
				$retorno['mensagem'] = "Sucesso";
				throw new Exception (json_encode($retorno), 1);
			}

		}catch(Exception $e){
			echo $e->getMessage();
		}
	}

    //By: Caio Freitas - 12/07/2022
	function detalheComissao(){
		try{
			if(!isset($this->parametros[0]) || empty($this->parametros[0])){
				$retorno['codigo']   = 1;						
				$retorno['input']    = $this->parametros;
				$retorno['output']   = null;
				$retorno['mensagem'] = "Erro ao parâmetros";
				throw new Exception (json_encode($retorno), 1);	
			}else{
				$id_comissao = $this->parametros[0];				
			}
           			
			$comissao = json_decode($this->modelo->getComissaoUsuario(null,null,$id_comissao));           		          	
			if($comissao){
				$retorno['codigo']   = 0;						
				$retorno['input']    = $this->parametros;
				$retorno['output']   = $comissao;
				$retorno['mensagem'] = "Sucesso";
				throw new Exception (json_encode($retorno), 1);	
			}else{
				$retorno['codigo']   = 1;						
				$retorno['input']    = $this->parametros;
				$retorno['output']   = $this->modelo->info;
				$retorno['mensagem'] = "Erro ao obter detalhe de comissão";
				throw new Exception (json_encode($retorno), 1);	
			}
		}catch(Exception $e){
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 12/07/2022
	function excluirUsuarioComissao(){
		try{
			if(!isset($this->parametros[0]) || empty($this->parametros[0])){
				$retorno['codigo']   = 1;						
				$retorno['input']    = $this->parametros;
				$retorno['output']   = null;
				$retorno['mensagem'] = "Erro ao parâmetros";
				throw new Exception (json_encode($retorno), 1);	
			}else{
				$id_comissao_usuario = $this->parametros[0];
				$deleted['deleted'] = '1';
			}
			
			$usuario_comissao = json_decode($this->modelo->getComissaoUsuario(null,null,$id_comissao_usuario));           
			if(!isset($usuario_comissao) || empty($usuario_comissao)){
				$retorno['codigo']   = 1;						
				$retorno['input']    = $this->parametros;
				$retorno['output']   = null;
				$retorno['mensagem'] = "Usuario não encontrado";
				throw new Exception (json_encode($retorno), 1);	
			}
                      				
			$this->modelo->setTable('comissoes_usuario');
			$update = $this->modelo->save($deleted, $usuario_comissao[0]->id_comissao);
			if(!$update){
				$retorno['codigo']   = 1;						
				$retorno['input']    = $this->parametros;
				$retorno['output']   = $this->modelo->info;
				$retorno['mensagem'] = "Erro ao excluir usuário comercial";
				throw new Exception (json_encode($retorno), 1);	
			}else{
				$retorno['codigo']   = 0;						
				$retorno['input']    = $this->parametros;
				$retorno['output']   = $update;
				$retorno['mensagem'] = "Sucesso em excluir usuário comercial";
				throw new Exception (json_encode($retorno), 1);						
			}			
		}catch(Exception $e){
			echo $e->getMessage();
		}
	}

}