<?php
class ComissoesController extends MainController{
	
	protected 
		$obj_contrato, 
		$obj_nf;

	function __construct($parametros){
		$this->setModulo('comissoes');
		$this->setView('comissoes');
		parent::__construct($parametros);
		$this->obj_contrato = $this->load_model('contratos/contratos', true);
		$this->obj_nf = $this->load_model('notas-fiscais/notas-fiscais', true);
	}

	function index(){
		require_once ABSPATH . '/views/'.$this->nome_view.'/index.php';
	}
	
	// function listar(){
	// 	$ids_notas      = null;
	// 	$relatorio      = null;
	// 	$comissionados  = json_decode($this->modelo->listaComissionados());

	// 	if(isset($_POST['status'])){
	// 		$param['status'] = $_POST['status'];
	// 	}else{
	// 		$param['status'] = 'recebido';
	// 	}

	// 	if(isset($_POST['tipo_data'])){
	// 		$param['tipo_data'] = $_POST['tipo_data'];
	// 	}else{
	// 		$param['tipo_data'] = 'data_emissao';
	// 	}

	// 	if(isset($_POST['data_de'])){
	// 		$param['data_de'] = convertDate($_POST['data_de']);
	// 	}else{
	// 		$param['data_de'] = $this->data_hora_atual->format('Y-m-d');
	// 	}

	// 	if(isset($_POST['data_ate'])){
	// 		$param['data_ate'] = convertDate($_POST['data_ate']);
	// 	}else{
	// 		$param['data_ate'] = $this->data_hora_atual->format('Y-m-d');
	// 	}

	// 	if(isset($_POST['user_comercial']) && !empty($_POST['user_comercial'])){
	// 		$param['id_comercial']   = $_POST['user_comercial'];
	// 	}elseif(isset($this->parametros[1]) && is_numeric($this->parametros[1])){
	// 		$param['id_comercial'][] = $this->parametros[1];
	// 	}

	// 	$notas_fiscais = json_decode($this->obj_nf->getNotaByParametros($param));
		
	// 	if($notas_fiscais){
	// 		foreach ($notas_fiscais as $key => $value) {
	// 			$ids_notas[]  = $value->id;
	// 		}
	// 	}

	// 	if($ids_notas){
	// 		$comissoes_contrato = json_decode($this->modelo->getComissoesByIdContratoENf($ids_notas, $param['id_comercial'], null, $param['data_de']));
	// 	}else{
	// 		$comissoes_contrato = null;
	// 	}

	// 	// echo '<pre>';
	// 	// var_dump($comissoes_contrato);
	// 	// echo '</pre>';

	// 	if($comissoes_contrato){
	// 		foreach ($comissoes_contrato as $key => $value) {
				
	// 			$x = $value->id_nf;
	// 			$i = $value->nome_comercial;
				
	// 			if($value->recebido_em){
	// 				$dt_recebimento = new DateTime($value->recebido_em);
	// 				if($dt_recebimento->format('d') > 20){
	// 					$dt_recebimento->add(New DateInterval('P2M'));
	// 				}else{
	// 					$dt_recebimento->add(New DateInterval('P1M'));
	// 				}
	// 				$previsao_pagamento = $dt_recebimento->format('Y-m').'-05';
	// 			}
	// 			// var_dump($value->valor_desconto);
	// 			$relatorio[$i]['detalhes'][$x]['id_nota']              = $value->id_nf;
	// 			$relatorio[$i]['detalhes'][$x]['comerical']       = $value->nome_comercial;
	// 			$relatorio[$i]['detalhes'][$x]['cliente']         = $value->nome_fantasia;
	// 			$relatorio[$i]['detalhes'][$x]['produto']         = $value->codigo_produto;
	// 			$relatorio[$i]['detalhes'][$x]['valor_liquido']   = ($value->valor_liquido - $value->valor_desconto);
	// 			$relatorio[$i]['detalhes'][$x]['data_emissao']    = $value->data_emissao;
	// 			$relatorio[$i]['detalhes'][$x]['data_vencimento'] = $value->data_vencimento;
	// 			$relatorio[$i]['detalhes'][$x]['valida_de']       = $value->valida_de;
	// 			$relatorio[$i]['detalhes'][$x]['valida_ate']      = $value->valida_ate;
	// 			$relatorio[$i]['detalhes'][$x]['recebido_em']     = $value->recebido_em;
	// 			$relatorio[$i]['detalhes'][$x]['status']     	  = $value->nf_status;
	// 			$relatorio[$i]['detalhes'][$x]['valor_receber']   = ((($value->valor_liquido - $value->valor_desconto) / 100) * $value->valor_comissao);
	// 			$relatorio[$i]['detalhes'][$x]['pagamento_previsto'] = $previsao_pagamento;
	// 		}
	// 	}
	// 	// var_dump($param);
	// 	require_once ABSPATH . '/views/'.$this->module.'/comissoes-view.php';
	// }

	// function comissionados(){//ok
	// 	$id_comissao  = null;
	// 	$id_comercial = null;
	// 	$status       = null;
	// 	$nome         = null;
	// 	$cargo        = null;
		
	// 	if(isset($_POST['status']) && !empty($_POST['status'])){
	// 		$status = $_POST['status'];
	// 	}else{
	// 		$status = 'A';
	// 	}

	// 	if(isset($_POST['nome']) && !empty($_POST['nome'])){
	// 		$nome = $_POST['nome'];
	// 	}else{
	// 		$nome = null;
	// 	}

	// 	if(isset($_POST['cargo']) && !empty($_POST['cargo'])){
	// 		$cargo = $_POST['cargo'];
	// 	}else{
	// 		$cargo = null;
	// 	}
		
	// 	if(isset($this->parametros[1]) && is_numeric($this->parametros[1]) && $this->parametros[1] > 0){
	// 		$comissionados = json_decode($this->modelo->getComissionadoByContrato($this->parametros[1], $id_comercial, $nome, $cargo, $status));
	// 		$id_comissao = $comissionados[0]->id_comissao;
	// 	}else{
	// 		$comissionados = json_decode($this->modelo->listaComissionados());
	// 	}
	// 	require_once ABSPATH . '/views/'.$this->module.'/comissionados-view.php';
	// }

	// function comercial(){//ok
	// 	if(isset($this->parametros[1]) && is_numeric($this->parametros[1]) && $this->parametros[1] > 0){
	// 		//$comissionado = json_decode($this->modelo->listaComissionados($this->parametros[1], false));
	// 		//$contratos    = json_decode($this->modelo->getComissoes(null, $this->parametros[1]));
	// 	}
	// 	require_once ABSPATH . '/views/'.$this->module.'/comissionado-edit.php';
	// }

	// function contratos(){ //ok
	// 	if(isset($this->parametros[1]) && is_numeric($this->parametros[1]) && $this->parametros[1] > 0){
	// 		$comissionado = json_decode($this->modelo->listaComissionados($this->parametros[1], false));
	// 		$contratos    = json_decode($this->modelo->getComissoes(null, $this->parametros[1]));
	// 	}
	// 	require_once ABSPATH . '/views/'.$this->module.'/contratos-view.php';
	// }

	// function comissoes(){
	// 	$comissoes = json_decode($this->modelo->getComissionadoByContrato($this->parametros[1], null));
	// 	require_once ABSPATH . '/views/'.$this->module.'/comissoes-contratos.php';
	// }

	// function editar(){
	// 	if(isset($this->parametros[1]) && is_numeric($this->parametros[1]) && $this->parametros[1] > 0){
	// 		$comissao     = json_decode($this->modelo->getComissoes($this->parametros[1]));
	// 		$contratos    = json_decode($this->modelo->getComissionadoByContrato($comissao[0]->id_contrato, $comissao[0]->id_comercial));
	// 		$comissionado = json_decode($this->modelo->listaComissionados($comissao[0]->id_comercial, false));
	// 	}else{
	// 		$contratos    = json_decode($this->modelo->getComissionadoByContrato($this->parametros[3]));
	// 		$comissionado = json_decode($this->modelo->listaComissionados());
	// 	}
	// 	require_once ABSPATH . '/views/'.$this->module.'/comissoes-edit.php';
	// }

	// function comissionadoSave(){
		
	// 	if(isset($_POST['data_admissao']) && !empty($_POST['data_admissao'])){
	// 		$_POST['data_admissao'] = convertDate($_POST['data_admissao']);	
	// 	}

	// 	if(isset($_POST['data_demissao']) && !empty($_POST['data_demissao'])){
	// 		$_POST['data_demissao'] = convertDate($_POST['data_demissao']);	
	// 	}

	// 	if(isset($this->parametros[1]) && is_numeric($this->parametros[1])){
	// 		$id_comissionado = $this->parametros[1];
	// 	}else{
	// 		$id_comissionado = null;
	// 	}
		
	// 	$this->modelo->table = 'comissionados';
	// 	$is_save = $this->modelo->save($_POST, $id_comissionado);
	// 	if($is_save){
	// 		header('location: /comissoes/comercial/id_comercial/'.$is_save);
	// 	}else{
	// 		echo 'Erro ao salvar informações!!';
	// 	}
	// }

	// function save(){
	// 	$id_comissao = null;
	// 	if(isset($this->parametros[1]) && is_numeric($this->parametros[1]) && $this->parametros[1] > 0){
	// 		$id_comissao = $this->parametros[1];
	// 	}
	// 	if(isset($_POST) && count($_POST) > 0){
	// 		$_POST['valida_de'] = convertDate($_POST['valida_de']); 
	// 		$_POST['valida_ate'] = convertDate($_POST['valida_ate']);
	// 		$_POST['valor_comissao'] = removeCaracteres($_POST['valor_comissao'], 'moeda2'); 
	// 	}
	// 	$is_save = $this->modelo->save($_POST, $id_comissao);
	// 	if($is_save){
	// 		header('location: /comissoes/editar/id/'.$is_save);
	// 	}else{
	// 		echo 'Erro ao salvar informações!!';
	// 	}
	// }
}
?>
