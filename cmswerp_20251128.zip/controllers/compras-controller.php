<?php
class ComprasController extends MainController
{
	private $comprasModel;
	private $usuariosModel;
	private $controller;
	private $gedModel;

	private $notificadorClass;

	function __construct($parametros)
	{
		$this->setModulo('compras');
		parent::__construct($parametros);
		$this->controller = new MainController(null, 'compras', false);
		$this->comprasModel = $this->load_model('compras/compras', true);
		$this->usuariosModel = $this->load_model('usuarios/usuarios', true);
		$this->gedModel = $this->load_model('ged/ged', true);
		$this->notificadorClass = new Notificador($this, $parametros);
	}

	function index()
	{
		$this->listar();
	}

	function listar()
	{
		$cotacoes = json_decode($this->comprasModel->listarCotacoes());
		$usuarios = json_decode($this->usuariosModel->getAllUser());
		require_once ABSPATH . '/views/compras/cotacao-view.php';
	}

	function detalhe()
	{
		$id = $this->parametros[1];
		$cotacao = json_decode($this->comprasModel->obterCotacaoById($id));
		if (gettype($cotacao) == 'array') {
			$cotacao = $cotacao[0];
		}
		$usuarios = json_decode($this->usuariosModel->getAllUser());
		// $etapasAprovacao = json_decode($this->comprasModel->obterEtapasCotacao($cotacao->tipo, $id));
		$etapasAprovacao = json_decode($this->comprasModel->abtemAprovadores($cotacao->tipo, $cotacao->id_solicitante, $id));
		$etapasAprovacao = $this->trataAprovacao($etapasAprovacao, $cotacao->id_solicitante);

		$documentos = json_decode($this->comprasModel->obterDocumentos($id));
		$orcamentos = [];
		switch ($cotacao->tipo) {
			case 'serviço':
			case 'compra':
				if ($cotacao->tipo == 'serviço') {
					$this->comprasModel->setTable('cotacao_servicos');
				} else if ($cotacao->tipo == 'compra') {
					$this->comprasModel->setTable('cotacao_produtos');
				}
				$orcamentos = json_decode($this->comprasModel->obterOrcamentos($cotacao->tipo, $id));
				$this->comprasModel->setTable('fornecedores');
				$fornecedores = json_decode($this->comprasModel->obterFornecedores());
				break;
			case 'contratação': // NÃO UTILIZADO
			// $this->comprasModel->setTable('cotacao_contratacoes');
			// $fornecedores = json_decode($this->comprasModel->obterContratacoes());
			// break;

		}
		require_once ABSPATH . '/views/compras/cotacao-detalhe-view.php';
	}

	function trataAprovacao($etapasAprovacao, $id_solicitante)
	{
		if (!$etapasAprovacao) {
			return false;
		}

		$objEtapasAprovacao = new stdClass();
		$objEtapasAprovacao->proximaEtapa = new stdClass();
		// $objEtapasAprovacao->etapaAtual = new stdClass();

		// Remove usuario solicitante do fluxo de aprovação
		foreach ($etapasAprovacao as $key => $etapaAprovacao) {
			if ($etapaAprovacao->id_usuario == $id_solicitante) {
				unset($etapasAprovacao[$key]);
			}
		}

		//Agrupa os aprovadores por ordem - se houver mais de um usuario com a mesma ordem, sera feito um array com eles e validado(na aprovacao) por qualquer um que aprove ou reprove
		foreach ($etapasAprovacao as $key => $etapaAprovacao) {
			if ($etapaAprovacao->status) {
				$objEtapasAprovacao->etapas->{$etapaAprovacao->ordem}->statusAprovacao = $etapaAprovacao->status;
				if ($etapaAprovacao->status == 'r') {
					$objEtapasAprovacao->status = 'r';
					$objEtapasAprovacao->etapas->{$etapaAprovacao->ordem}->justificativa = $etapaAprovacao->justificativa;
				}

				if ($etapaAprovacao->status == 'p') {
					$objEtapasAprovacao->status = 'aprovacao';
				}

			} else {
				$objEtapasAprovacao->etapas->{$etapaAprovacao->ordem}->statusAprovacao = false;
			}

			$objEtapasAprovacao->etapas->{$etapaAprovacao->ordem}->aprovadores[] = [
				'etapa' => $etapaAprovacao->ordem,
				'aprovador' => $etapaAprovacao->id_usuario,
				'nome' => $etapaAprovacao->nome,
				'id_grupo' => $etapaAprovacao->id_grupo,
				'aprovacao_id' => $etapaAprovacao->aprovacao_id,
				'status' => $etapaAprovacao->status,
				// 'justificativa' => $etapaAprovacao->justificativas
			];
		}

		// Ajusta o(s) proximo(s) aprovador(es)
		$continueLoop = true;
		$etapa = 0;
		foreach ($objEtapasAprovacao->etapas as $key => $etapa) {
			foreach ($etapa->aprovadores as $key => $aprovador) {
				if ((!$aprovador['status'] && $continueLoop) || (isset($objEtapasAprovacao->proximaEtapa->aprovadores->{$aprovador['etapa']}))) {

					$continueLoop = false;
					$objEtapasAprovacao->proximaEtapa->aprovadores->{$aprovador['etapa']}[] = $aprovador;
					$objEtapasAprovacao->proximaEtapa->id_grupo = $aprovador['id_grupo'];
					if (!$objEtapasAprovacao->proximaEtapa->arrIdAprovadores) {
						// $objEtapasAprovacao->proximaEtapa->aprovadores->{$aprovador['etapa']}->arrIdAprovadores = [];
						$objEtapasAprovacao->proximaEtapa->arrIdAprovadores = [];
					}
					$objEtapasAprovacao->proximaEtapa->arrIdAprovadores[] = $aprovador['aprovador'];
				}
			}
		}

		// Ajusta o(s) proximo(s) aprovador(es)
		$ordemAtual = false;
		$continueLoop = true;
		foreach ($objEtapasAprovacao->etapas as $key => $etapa) {
			foreach ($etapa->aprovadores as $key => $aprovador) {
				if (($aprovador['status'] == 'p')) {
					$ordemAtual = $aprovador['etapa'];
					break;
				}
			}
		}
		$objEtapasAprovacao->etapaAtual->aprovadores = false;
		if ($ordemAtual) {
			foreach ($objEtapasAprovacao->etapas as $key => $etapa) {
				foreach ($etapa->aprovadores as $key => $aprovador) {
					if (($aprovador['etapa'] == $ordemAtual)) {
						$objEtapasAprovacao->etapaAtual->aprovadores[] = $aprovador['aprovador'];
						$objEtapasAprovacao->etapaAtual->ids_aprovacao[] = $aprovador['aprovacao_id'];
					}
				}
			}

		}
		if (!$objEtapasAprovacao->status) {
			$objEtapasAprovacao->status = 'elaboracao';
		}

		// $objEtapasAprovacao->proximaEtapa->arrIdAprovadores[] = 42;
		return $objEtapasAprovacao;

		// $objEtapasAprovacao = new stdClass();
		// foreach ($etapasAprovacao as $key => $etapaAprovacao) {
		// 	if ($etapaAprovacao->id_usuario == $id_solicitante) {
		// 		unset($etapasAprovacao[$key]);
		// 	}
		// }
		// $objEtapasAprovacao->proximaEtapa[0] = false;
		// $objEtapasAprovacao->etapaAtual = [];

		// foreach ($etapasAprovacao as $key => $etapaAprovacao) {
		// 	$objEtapasAprovacao->etapas->{$etapaAprovacao->ordem}[] = $etapaAprovacao;
		// 	// $objEtapasAprovacao->aprovadores[$key] = $etapaAprovacao->id_usuario;
		// 	if ($etapaAprovacao->status) {
		// 		$objEtapasAprovacao->etapaAtual[] = [
		// 			'etapa' => $etapaAprovacao->ordem,
		// 			'aprovador' => $etapaAprovacao->id_usuario,
		// 			'id_grupo' => $etapaAprovacao->id_grupo,
		// 			'aprovacao_id' => $etapaAprovacao->aprovacao_id,
		// 			'status' => $etapaAprovacao->status
		// 		];
		// 	}

		// 	if ($key == 0 && !$etapaAprovacao->status) {
		// 		$objEtapasAprovacao->proximaEtapa = [
		// 			'etapa' => $etapaAprovacao->ordem,
		// 			'aprovador' => $etapaAprovacao->id_usuario,
		// 			'id_grupo' => $etapaAprovacao->id_grupo,
		// 		];

		// 	} else if ($etapaAprovacao->status && $etapasAprovacao[$key + 1] && !$etapasAprovacao[$key + 1]->status) {

		// 		if ($etapasAprovacao[$key + 2] && !$etapasAprovacao[$key + 2]->status && $etapasAprovacao[$key + 1]->ordem == $etapasAprovacao[$key + 2]->ordem) {
		// 			$objEtapasAprovacao->duplaAprovacao->{$etapasAprovacao[$key + 1]->id_usuario} = $etapasAprovacao[$key + 1];
		// 			$objEtapasAprovacao->duplaAprovacao->{$etapasAprovacao[$key + 2]->id_usuario} = $etapasAprovacao[$key + 2];
		// 		}

		// 		$objEtapasAprovacao->proximaEtapa = [
		// 			'etapa' => $etapasAprovacao[$key + 1]->ordem,
		// 			'aprovador' => $etapasAprovacao[$key + 1]->id_usuario,
		// 			'id_grupo' => $etapasAprovacao[$key + 1]->id_grupo,
		// 		];

		// 	} else if ($etapaAprovacao->status && $key == count($etapasAprovacao) - 1) {
		// 		$objEtapasAprovacao->etapaAtual = [
		// 			'etapa' => false,
		// 			'aprovador' => false,
		// 			'id_grupo' => false,
		// 		];
		// 	}
		// }
		// return $objEtapasAprovacao;
	}

	function obtemProdutosByFornecedor()
	{
		try {
			$id = $this->parametros[1];
			$produtos = json_decode($this->comprasModel->obtemProdutosByFornecedor($id));

			if (!$produtos) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['mensagem'] = "Erro ou nenhum produto encontrado.";
				throw new Exception(json_encode($retorno), 1);
			}

			$retorno['codigo'] = 1;
			$retorno['input'] = $_POST;
			$retorno['output'] = null;
			$retorno['output'] = $produtos;

			throw new Exception(json_encode($retorno), 1);

		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function autoCompleteProdutos()
	{
		try {
			$term = $this->parametros[1];
			$produtos = json_decode($this->comprasModel->obtemProdutosByName($term));

			if (!$produtos) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['mensagem'] = "Erro ou nenhum produto encontrado.";
				throw new Exception(json_encode($retorno), 1);
			}

			$retorno['codigo'] = 1;
			$retorno['input'] = $_POST;
			$retorno['output'] = null;
			$retorno['output'] = $produtos;

			throw new Exception(json_encode($retorno), 1);

		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function atualizaCotacao()
	{
		try {
			$id = $this->parametros[1];
			$this->comprasModel->setTable('compras_cotacao');
			$cotaca_contratacao = [
				'id_cotacao' => $id,
				'valor' => $_POST['valor_total'],
				'departamento' => $_POST['departamento'],
				'cargo' => $_POST['cargo'],
				'forma_contratacao' => $_POST['forma_contratacao'],
				'tipo_contrato' => $_POST['tipo_contrato'],
				'criado_por' => $_SESSION['cmswerp']['userdata']->id
			];
			unset($_POST['departamento'], $_POST['cargo'], $_POST['forma_contratacao'], $_POST['tipo_contrato'], $_POST['contratacao_id'], $_POST['valor_total']);
			if ($_POST['tipo'] == 'contratação') {
				$_POST['valor'] = $_POST['valor_total'];
				$contratacao_id = $_POST['contratacao_id'];
			}
			$result = $this->comprasModel->save($_POST, $id);

			if (!$result) {
				$retorno['codigo'] = 0;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao atualizar cotação.";
				throw new Exception(json_encode($retorno), 1);
			}

			if ($result && $_POST['tipo'] == 'contratação') {
				$this->comprasModel->setTable('cotacao_contratacoes');
				if ($contratacao_id == 0) {
					$result = $this->comprasModel->save($cotaca_contratacao);
				} else {
					$result = $this->comprasModel->save($cotaca_contratacao, $id);
				}
			}

			if (!$result) {
				$retorno['codigo'] = 0;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao atualizar cotação.";
				throw new Exception(json_encode($retorno), 1);
			}

			$retorno['codigo'] = 1;
			$retorno['input'] = $_POST;
			$retorno['output'] = null;
			$retorno['mensagem'] = "Cotação atualizada.";
			throw new Exception(json_encode($retorno), 1);

		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function adicionarCotacao()
	{
		header('Content-Type: application/json; charset=utf-8');
		//etapas: elaboração;aprovação gestor;aprovação diretoria responsável;aprovação presidência;Administração'
		try {
			$this->comprasModel->setTable('compras_cotacao');
			$data = $_POST;
			$data['valor'] = '0.00';
			$data['status'] = 'andamento';
			$data['deleted'] = 0;

			$save = $this->comprasModel->save($data);

			if ($save) {
				// Alterar
				//
				// $this->comprasModel->setTable('compras_aprovacao');
				// $aprovacao['id_cotacao'] = $save;
				// $aprovacao['id_usuario_aprovacao'] = $_SESSION['cmswerp']['userdata']->boss;
				// $aprovacao['deleted'] = 0;
				// $aprovacao['status'] = 'andamento';
				// $aprovacao['etapa'] = 'elaboração';
				// $saveAprovacao = $this->comprasModel->save($aprovacao);

				// if (!$saveAprovacao) {
				// 	$retorno['codigo'] = 1;
				// 	$retorno['input'] = $_POST;
				// 	$retorno['output'] = null;
				// 	$retorno['mensagem'] = "Cotação adicionada, mas houve falha ao adicionar aprovação";
				// 	throw new Exception(json_encode($retorno), 1);
				// }

				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Cotação adicionada com sucesso</br><a href='/compras/detalhe/id/$save'>Acessar cotação</a>";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 0;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao adicionar cotação";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}
	function adicionarEditarOrcamento()
	{
		header('Content-Type: application/json; charset=utf-8');

		try {
			$this->comprasModel->setTable('compras_orcamentos');
			$input = (object) json_decode(file_get_contents("php://input"), true);

			$compras_orcamento = [
				'id_cotacao' => $input->dados_cotacao['id_cotacao'],
				'id_fornecedor' => $input->dados_cotacao['id_fornecedor'],
				'valor' => $input->dados_cotacao['total'],
				'codigo_orcamento' => date('Ymd') . $input->dados_cotacao['id_cotacao']
			];

			if (isset($input->dados_cotacao['id_orcamento']) && ($input->dados_cotacao['id_orcamento'] == 0 || !$input->dados_cotacao['id_orcamento'])) {
				$compras_orcamentos = $this->comprasModel->save($compras_orcamento);
				if (!$compras_orcamentos) {
					$message = "Erro ao adicionar orçamento";
				} else {
					$message = "Orçamento adicionado com sucesso";
				}
			} else {
				$compras_orcamentos = $this->comprasModel->save($compras_orcamento, $input->dados_cotacao['id_orcamento']);
				if (!$compras_orcamentos) {
					$message = "Erro ao editar orçamento";
				} else {
					$message = "Orçamento editado com sucesso";
				}
			}

			if (!$compras_orcamentos) {
				$retorno['codigo'] = 0;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = $message;
				throw new Exception(json_encode($retorno), 1);
			}

			$temErro = false;

			switch ($input->dados_cotacao['type']) {
				case 'servico':
					if (isset($input->dados_servicos) && !empty($input->dados_servicos)) {
						$this->comprasModel->setTable('cotacao_servicos');
						foreach ($input->dados_servicos as $servico) {
							$data_orcamento_id = $servico['data_orcamento_id'];
							unset($servico['data_orcamento_id']);
							$servico['id_orcamento'] = $compras_orcamentos;
							if (isset($data_orcamento_id) && !empty($data_orcamento_id) && is_numeric($data_orcamento_id) && $data_orcamento_id != 0) {
								$cotacao_servico = $this->comprasModel->save($servico, $data_orcamento_id);
							} else {
								$cotacao_servico = $this->comprasModel->save($servico);
							}
							if (!$cotacao_servico) {
								$temErro = true;
							}
						}
					}
					break;
				case 'compra':
					if (isset($input->dados_produtos) && !empty($input->dados_produtos)) {
						$this->comprasModel->setTable('cotacao_produtos');
						foreach ($input->dados_produtos as $produto) {
							$data_orcamento_id = $produto['data_orcamento_id'];
							unset($produto['data_orcamento_id']);
							$produto['id_orcamento'] = $compras_orcamentos;
							if (isset($data_orcamento_id) && !empty($data_orcamento_id) && is_numeric($data_orcamento_id) && $data_orcamento_id != 0) {
								$cotacao_produtos = $this->comprasModel->save($produto, $data_orcamento_id);
							} else {
								$cotacao_produtos = $this->comprasModel->save($produto);
							}
							if (!$cotacao_produtos) {
								$temErro = true;
							}
						}
					}
					break;
				case 'contratacao':
					$this->comprasModel->setTable('cotacao_contratacoes');
					break;
				default:
					$retorno['codigo'] = 0;
					$retorno['input'] = null;
					$retorno['output'] = null;
					$retorno['mensagem'] = 'Orçamento criado, mas houve erro ao adicionar ou alterar serviço(s)';
					throw new Exception(json_encode($retorno), 1);
			}

			if ($temErro) {
				$retorno['codigo'] = 1;
				$retorno['input'] = null;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Orçamento criado, mas houve erro ao adicionar ou alterar serviço(s)";
				throw new Exception(json_encode($retorno), 1);
			}

			$retorno['codigo'] = 1;
			$retorno['input'] = null;
			$retorno['output'] = null;
			$retorno['mensagem'] = $message;
			throw new Exception(json_encode($retorno), 1);
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function obterdadosorcamento()
	{
		header('Content-Type: application/json; charset=utf-8');

		try {
			$id_cotacao = $_POST['id_cotacao'];
			$id_orcamento = $_POST['id_orcamento'];
			$tipo = $_POST['tipo'];

			$dados_orcamento = json_decode($this->comprasModel->obterDadosOrcamento($id_cotacao, $id_orcamento, $tipo));

			if ($dados_orcamento === false) {
				$retorno['codigo'] = 0;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao obter dados do orçamento ou nenhum produto encontrado.";
				throw new Exception(json_encode($retorno), 1);
			}

			$retorno['codigo'] = 1;
			$retorno['input'] = $_POST;
			$retorno['output'] = null;
			$retorno['output'] = ['dados' => $dados_orcamento, 'fornecedor_id' => $dados_orcamento[0]->fornecedor_id];
			throw new Exception(json_encode($retorno), 1);

		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function deleteorcamento()
	{
		header('Content-Type: application/json; charset=utf-8');
		$this->comprasModel->setTable('compras_orcamentos');

		try {
			$id_orcamento = $_POST['id_orcamento'];
			$data['deleted'] = 1;

			if (!$this->comprasModel->save($data, $id_orcamento)) {
				$retorno['codigo'] = 0;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao obter dados do orçamento ou nenhum produto encontrado.";
				throw new Exception(json_encode($retorno), 1);
			}

			$retorno['codigo'] = 1;
			$retorno['input'] = $_POST;
			$retorno['output'] = null;
			$retorno['output'] = null;
			$retorno['mensagem'] = "Orçamento excluído com sucesso.";
			throw new Exception(json_encode($retorno), 1);

		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}
	function deleteCotacao()
	{
		header('Content-Type: application/json; charset=utf-8');
		$this->comprasModel->setTable('compras_cotacao');

		try {
			$id_cotacao = $this->parametros[1];
			$data['deleted'] = 1;

			if (!$this->comprasModel->save($data, $id_cotacao)) {
				$retorno['codigo'] = 0;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao excluir cotação.";
				throw new Exception(json_encode($retorno), 1);
			}

			$retorno['codigo'] = 1;
			$retorno['input'] = $_POST;
			$retorno['output'] = null;
			$retorno['output'] = null;
			$retorno['mensagem'] = "Cotação excluída com sucesso.";
			throw new Exception(json_encode($retorno), 1);

		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function definirganhoorcamento()
	{
		$this->comprasModel->setTable('compras_orcamentos');
		header('Content-Type: application/json; charset=utf-8');

		try {
			$id_orcamento_novo = $_POST['id_orcamento'];
			$id_cotacao = $_POST['id_cotacao'];

			$data['ganho'] = 0;

			$this->comprasModel->setTable('compras_orcamentos');
			$orcamentoGanho = json_decode($this->comprasModel->obterOrcamentoGanho($id_cotacao));

			if ($orcamentoGanho === false) {
				$retorno['codigo'] = 0;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao obter orçamentos.";
				throw new Exception(json_encode($retorno), 1);
			}

			if ($orcamentoGanho && isset($orcamentoGanho[0]->id)) {
				$id_orcamento = $orcamentoGanho[0]->id;
				if (!$this->comprasModel->save($data, $id_orcamento)) {
					$retorno['codigo'] = 0;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro ao atuaizar cotação.";
					throw new Exception(json_encode($retorno), 1);
				}
			}

			$data['ganho'] = 1;

			if (!$this->comprasModel->save($data, $id_orcamento_novo)) {
				$retorno['codigo'] = 0;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao atuaizar cotação.";
				throw new Exception(json_encode($retorno), 1);
			}

			$retorno['codigo'] = 1;
			$retorno['input'] = $_POST;
			$retorno['output'] = null;
			$retorno['output'] = null;
			$retorno['mensagem'] = "Cotação atualizada com sucesso.";
			throw new Exception(json_encode($retorno), 1);

		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function adicionarDocumento()
	{
		try {

			$id_cotacao = $_POST['id_cotacao'];
			$referencia = $_POST['referencia'];
			$descricao = $_POST['descricao'];

			if (!$_FILES['documento']['name']) {
				$retorno['codigo'] = 0;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao enviar o arquivo ou arquivo vazio.";
				throw new Exception(json_encode($retorno), 1);
			}

			foreach ($_FILES as $file) {
				$cotacao = [
					'id' => $id_cotacao,
					'referencia' => $referencia
				];
				$res = json_decode($this->uploadAnexo($file, (object) $cotacao));
				if (!$res || $res->codigo == 0) {
					$retorno['codigo'] = 0;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = $res->mensagem;
					throw new Exception(json_encode($retorno), 1);
				}

				$this->gedModel->setTable('ged_documento');

				$extencao = pathinfo($file['name'], PATHINFO_EXTENSION);
				$output = (object) $res->output;
				$ged['nome_documento'] = $output->name;
				$ged['data_documento'] = $this->controller->data_hora_atual->format('Y-m-d');
				$ged['valido_ate'] = null;
				$ged['id_origem'] = $id_cotacao;
				$ged['doc_origem'] = 'cotação';
				$ged['tipo'] = 'cotação';
				$ged['subtipo'] = 'cotação';
				$ged['classificacao'] = null;
				$ged['descricao'] = $descricao;
				$ged['versao'] = 'original';
				$ged['owner'] = $this->user->id;
				$ged['data_criacao'] = $this->controller->data_hora_atual->format('Y-m-d');
				$ged['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
				$ged['alterado_em'] = $this->controller->data_hora_atual->format('Y-m-d H:i:s');
				$ged['deleted'] = 0;

				$save_ged_documento = $this->gedModel->save($ged);
				if ($save_ged_documento) {
					$ged_anexo['id_documento'] = $save_ged_documento;
					$ged_anexo['nome_amigavel'] = $output->name;
					$ged_anexo['path_root'] = GED_COTACOES;
					$ged_anexo['path_objeto'] = $output->relative_path;
					$ged_anexo['nome_hash'] = md5($output->name);
					$ged_anexo['hash_arquivo'] = md5(file_get_contents(GED_COTACOES . $output->relative_path . $output->name));
					$ged_anexo['data_criacao'] = $this->controller->data_hora_atual->format('Y-m-d H:i:s');
					$ged_anexo['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
					$ged_anexo['alterado_em'] = $this->controller->data_hora_atual->format('Y-m-d H:i:s');
					$ged_anexo['deleted'] = 0;
					$this->gedModel->setTable('ged_anexo');
					$save_anexo = $this->gedModel->save($ged_anexo);
					if (!$save_anexo) {
						$retorno['codigo'] = 0;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Erro ao salvar o anexo.";
						throw new Exception(json_encode($retorno), 1);
					}

					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Arquivo enviado com sucesso.";
					throw new Exception(json_encode($retorno), 1);

				}

			}

		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function uploadAnexo($file, $cotacao)
	{
		try {

			$relative_path_arquivo = $cotacao->id . DS;
			$config['pasta'] = GED_COTACOES . $cotacao->id;

			if (!is_dir(GED_COTACOES)) {
				mkdir(GED_COTACOES);
			}
			if (!is_dir(GED_COTACOES . $cotacao->id)) {
				mkdir(GED_COTACOES . $cotacao->id);
				$relative_path_arquivo = $cotacao->id . DS;
				$config['pasta'] = GED_COTACOES . $cotacao->id;
			}

			if ($cotacao->referencia !== 'cotacao') {
				$relative_path_arquivo = $cotacao->id . DS . $cotacao->referencia . DS;
				$config['pasta'] = GED_COTACOES . $cotacao->id . DS . $cotacao->referencia . DS;
				if (!is_dir(GED_COTACOES . $cotacao->id . DS . $cotacao->referencia)) {
					mkdir(GED_COTACOES . $cotacao->id . DS . $cotacao->referencia);
				}
			}

			if (
				!is_dir(GED_COTACOES . $cotacao->id) ||
				($cotacao->referencia !== 'cotacao' && !is_dir(GED_COTACOES . $cotacao->id . DS . $cotacao->referencia))
			) {
				$retorno["codigo"] = 0;
				$retorno["input"] = $file;
				$retorno["output"] = null;
				$retorno["mensagem"] = "Erro. Sem diretório!";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$extencao = pathinfo($file['name'], PATHINFO_EXTENSION);
				$novo_nome = 'cotacao_' . $cotacao->id . '_' . date('Ymdhims') . "." . $extencao;
				$file['name'] = $novo_nome;
			}

			$config['allow_size'] = 164000000000;

			$class_upload = new Upload($this, $file, $config);
			$class_upload->checkArquivo();
			$load = $class_upload->loadFile($file, $config);
			$retorno_json = json_decode($load);

			if ($retorno_json->codigo != 0) {
				$retorno["codigo"] = 0;
				$retorno["input"] = $file;
				$retorno["output"] = null;
				$retorno["mensagem"] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno_json->dados->path = GED_COTACOES . $cotacao->id;
				$retorno["codigo"] = 1;
				$retorno["input"] = $file;
				$retorno["output"] = ['relative_path' => $relative_path_arquivo, 'name' => $novo_nome];
				$retorno["mensagem"] = "Arquivo enviado com sucesso.";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}


	function excluirDocumento()
	{
		try {
			$this->gedModel->setTable('ged_documento');

			$documento_id = $_POST['documento_id'];

			$data = ['deleted' => 1];

			if (!$this->gedModel->save($data, $documento_id)) {
				$retorno['codigo'] = 0;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao excluir o documento.";
				throw new Exception(json_encode($retorno), 1);
			}

			$retorno['codigo'] = 1;
			$retorno['input'] = $_POST;
			$retorno['output'] = null;
			$retorno['mensagem'] = "Documento excluído com sucesso.";
			throw new Exception(json_encode($retorno), 1);

		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function downloadFile()
	{
		$inline = false;
		$documento_id = $this->parametros[1];
		$documento = json_decode($this->comprasModel->obterPathDocumentById($documento_id));

		if ($documento === false) {
			die("Erro ao obter documento.");
		}

		if (!$documento) {
			die("Documento não encontrado");
		}

		$filepath = $documento[0]->path_root . $documento[0]->path_objeto . $documento[0]->nome_documento;
		if (!file_exists($filepath) || !is_readable($filepath)) {
			die("Documento não encontrado");
		}

		if (function_exists('finfo_open')) {
			$finfo = finfo_open(FILEINFO_MIME_TYPE);
			$mimeType = finfo_file($finfo, $filepath);
			finfo_close($finfo);
		} elseif (function_exists('mime_content_type')) {
			$mimeType = mime_content_type($filepath);
		} else {
			$mimeType = 'application/octet-stream';
		}

		$filename = basename($filepath);
		$disposition = $inline ? 'inline' : 'attachment';
		header('Content-Description: File Transfer');
		header('Content-Type: ' . $mimeType);
		header("Content-Disposition: $disposition; filename=\"$filename\"");
		header('Expires: 0');
		header('Cache-Control: must-revalidate');
		header('Pragma: public');
		header('Content-Length: ' . filesize($filepath));
		ob_clean();
		flush();
		readfile($filepath);
	}

	function aprovaCotacao()
	{
		try {
			$cotacao_id = $_POST['cotacao_id'];
			$ids_aprovacao = $_POST['ids_aprovacao'];
			$proxima_etapa = $_POST['proxima_etapa'];
			$this->comprasModel->setTable('grupo_aprovacoes');
			if ($ids_aprovacao != 'false' && $ids_aprovacao != false) {

				$data = ['status' => 'a', 'alterado_por' => $_SESSION['cmswerp']['userdata']->id];
				$errAprovacao = false;
				foreach ($ids_aprovacao as $id_aprovacao) {
					if (!$this->comprasModel->save($data, $id_aprovacao)) {
						$errAprovacao = true;
					}
				}

				if ($errAprovacao) {
					$retorno['codigo'] = 0;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro ao finalizar etapa.";
					throw new Exception(json_encode($retorno), 1);
				}
			}

			if ($proxima_etapa != 'false' && $proxima_etapa != false) {
				$errNovaAprovacao = false;
				foreach ($proxima_etapa['aprovadores'] as $aprovadorEtapa) {
					foreach ($aprovadorEtapa as $aprovador) {
						$nova_aprovacao = [
							'id_grupo' => $aprovador['id_grupo'],
							'id_usuario' => $aprovador['aprovador'],
							'id_item' => $cotacao_id,
							'status' => 'p',
							'justificativa' => ''
						];

						if (!$this->comprasModel->save($nova_aprovacao)) {
							$errNovaAprovacao = true;
						}

						if ($errNovaAprovacao) {
							$retorno['codigo'] = 0;
							$retorno['input'] = $_POST;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Erro ao avançar com cotação.";
							throw new Exception(json_encode($retorno), 1);
						}

						$aprovador = json_decode($this->usuariosModel->getUser($aprovador['aprovador']));
						$aprovador_email = $aprovador[0]->email;
						// $aprovador_email = 'luciano.silva@cmsw.com';

						$cotacao = json_decode($this->comprasModel->obterCotacaoById($cotacao_id));
						$mensagem['solicitante'] = $cotacao[0]->solicitante;
						$mensagem['abertura'] = date('d/m/y', strtotime($cotacao[0]->criado_em));
						$mensagem['tipoCotacao'] = $cotacao[0]->tipo;
						$mensagem['departamento'] = $cotacao[0]->departamento;
						$mensagem['justificativa'] = $cotacao[0]->justificativa;
						$mensagem['valor'] = $cotacao[0]->valor;
						$mensagem['urlCotacao'] = URL_SISTEMA . "compras/detalhe/id/" . $cotacao_id;
						$paramentros['to'] = $aprovador_email;
						$canais['teams'] = 'teams';
						// $canais['email'] = 'email';
						$this->notificadorClass->enviar('cotacao', 'Aprovação de cotação', $mensagem, $paramentros, $canais);
					}

				}
			} else {
				$this->comprasModel->setTable('compras_cotacao');
				$data = ['status' => 'finalizada'];
				if (!$this->comprasModel->save($data, $cotacao_id)) {
					$retorno['codigo'] = 0;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Etapa finalizada, mas houve erro ao avançar com a cotação.";
					throw new Exception(json_encode($retorno), 1);
				}

				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Cotação finalizada com sucesso.";
				throw new Exception(json_encode($retorno), 1);
			}

			$retorno['codigo'] = 1;
			$retorno['input'] = $_POST;
			$retorno['output'] = null;
			$retorno['mensagem'] = "Etapa finalizada com sucesso.";
			throw new Exception(json_encode($retorno), 1);
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function reprovaCotacao()
	{
		try {

			$cotacao_id = $_POST['cotacao_id'];
			$ids_aprovacao = $_POST['ids_aprovacao'];

			$this->comprasModel->setTable('grupo_aprovacoes');
			if (count($ids_aprovacao) > 1) {
				$justificativa = "Reprovado por: " . $_SESSION['cmswerp']['userdata']->nome . '</br>Justificativa: ' . $_POST['justificativa'];

			} else {
				$justificativa = $_POST['justificativa'];

			}
			$data = ['status' => 'r', 'justificativa' => $justificativa, 'alterado_por' => $_SESSION['cmswerp']['userdata']->id];

			foreach ($ids_aprovacao as $id_aprovacao) {
				if (!$this->comprasModel->save($data, $id_aprovacao)) {
					$errAprovacao = true;
				}

				if ($errAprovacao) {
					$retorno['codigo'] = 0;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro ao finalizar etapa.";
					throw new Exception(json_encode($retorno), 1);
				}
			}




			// if (!$this->comprasModel->save($data, $aprovacao_id)) {
			// 	$retorno['codigo'] = 0;
			// 	$retorno['input'] = $_POST;
			// 	$retorno['output'] = null;
			// 	$retorno['mensagem'] = "Erro ao reprovar cotação.";
			// 	throw new Exception(json_encode($retorno), 1);
			// }
			$this->comprasModel->setTable('compras_cotacao');
			$data = ['status' => 'reprovada'];
			if (!$this->comprasModel->save($data, $cotacao_id)) {
				$retorno['codigo'] = 0;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao reprovar cotação.";
				throw new Exception(json_encode($retorno), 1);
			}

			$retorno['codigo'] = 1;
			$retorno['input'] = $_POST;
			$retorno['output'] = null;
			$retorno['mensagem'] = "Cotação reprovada com sucesso.";
			throw new Exception(json_encode($retorno), 1);

		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

}