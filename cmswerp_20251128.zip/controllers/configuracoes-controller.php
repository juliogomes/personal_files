<?php
	class ConfiguracoesController extends MainController{
		protected $module = 'configuracoes';
		protected $obj_usuario;
		protected $model_proposta;

		function __construct($parametros = null){
			$this->nome_modulo = 'configuracoes';
			parent::__construct( $parametros );
			$this->obj_usuario 	  = $this->load_model( 'usuarios/usuarios', true );
			$this->model_proposta = $this->load_model( 'propostas/propostas', true );
		}

		function index(){
			$this->listar();
		}

		function listar(){
			$configuracoes = json_decode( $this->modelo->getConfiguracoes(1) );
			if($configuracoes){
				$conf_orcamento = json_decode($configuracoes[0]->controle_orcamento);
			}
			$new_config = json_decode($this->modelo->getConfiguracoes(null,"configuracoes"));
			require_once ABSPATH . '/views/'.$this->module.'/list-view.php';
		}

		function detalhe(){
			$usuarios = json_decode($this->obj_usuario->getAllUser());
			if(isset($this->parametros[1])  && is_numeric($this->parametros[1])){
				$configuracoes = json_decode($this->modelo->getConfiguracoes($this->parametros[1]));
				if($configuracoes){
					$conf_orcamento = json_decode($configuracoes[0]->controle_orcamento);
				}
			}
			require_once ABSPATH . '/views/'.$this->module.'/edit-view.php';
		}

		function contato(){
			$usuarios 		= json_decode( $this->obj_usuario->getAllUser() );
			$contatos 		= json_decode( $this->model_proposta->getContatoSign( "sign_cm" ) );
			$lista_empresas = json_decode( $this->modelo->getEmpresas() );
			require_once ABSPATH . '/views/'.$this->module.'/contato-view.php';
		}

		function fluxoAprovacao(){
			$lista_empresas = json_decode( $this->modelo->getEmpresas() );
			$fluxo_aprovacao = json_decode( $this->modelo->getAllFluxoConjunto() );
			$usuarios 		 = json_decode( $this->obj_usuario->getAllUser() );
			require_once ABSPATH . '/views/'.$this->module.'/aprovacao-view.php';
		}

		function empresaVendedora(){
			$empresa = json_decode($this->modelo->getEmpresas());
			
			
			require_once ABSPATH . '/views/'.$this->module.'/empresa-vendedora.php';
		}

		//By Caio Freitas - 29/08/2022
		function statusContato(){
			try{
				if(!isset($this->parametros[0]) || empty($this->parametros[0])){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Erro parâmetros ação";
					throw new Exception(json_encode($retorno),1);
				}else{
					$acao = $this->parametros[0];
					if($acao == "inativar"){
						$update['status'] = "1";
					}else if($acao == "ativar"){
						$update['status'] = "0";
					}else{
						$update['deleted'] = "1";
					}
				}
				
				if(!isset($this->parametros[1]) || empty($this->parametros[1])){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Erro parâmetros id";
					throw new Exception(json_encode($retorno),1);
				}else{
					$id_contato = $this->parametros[1]; 
					$get_contato = json_decode($this->model_proposta->getContatoSign("sign_cm",null,$id_contato));
					if(!isset($get_contato) || empty($get_contato)){
						$retorno['codigo']   = 1;
						$retorno['input']    = $this->parametros;
						$retorno['output']   = null;
						$retorno['mensagem'] = "Erro ao obter contato";
						throw new Exception(json_encode($retorno),1);
					}else{
						if($update['status'] == "1" || $update['deleted'] == "1"){
							$get_contatos = json_decode($this->model_proposta->getContatoSign("sign_cm"));								
							if(isset($get_contatos) && !empty($get_contatos)){
								foreach ($get_contatos as $key => $value) {	
									if($value->status == 0 && strtoupper($value->tipo_contato) == "RESPONSAVEL_LEGAL"){								
										$contato_responsavel[] = $value;
									}
									if($value->status == 0 && strtoupper($value->tipo_contato) == "JURIDICO"){								
										$contato_juridico[] = $value;
									}
									if($value->status == 0 && strtoupper($value->tipo_contato) == "TESTEMUNHA"){														
										$contato_testemunha[] = $value;
									}							
								}
								if(isset($contato_responsavel) && is_array($contato_responsavel)){
									foreach ($contato_responsavel as $key => $value) {
										if($get_contato[0]->id == $value->id){
											$contato_ativo = true;
										}
									}
								}
															
								if(strtoupper($get_contato[0]->tipo_contato) == "RESPONSAVEL_LEGAL"){
									if(count($contato_responsavel) <= 1 && $update['status'] == "1"){
										$retorno['codigo']   = 1;
										$retorno['input']    = $this->parametros;
										$retorno['output']   = null;
										$retorno['mensagem'] = "Necessário ter ao menos um contato (REPRESENTANTE LEGAL) ativo";
										throw new Exception(json_encode($retorno),1);
									}	
									if(count($contato_responsavel) <= 1 && $update['deleted']  == "1" && $contato_ativo == true){
										$retorno['codigo']   = 1;
										$retorno['input']    = $this->parametros;
										$retorno['output']   = null;
										$retorno['mensagem'] = "Necessário ter ao menos um contato (REPRESENTANTE LEGAL) ativo";
										throw new Exception(json_encode($retorno),1);
									}							
								}
								if(strtoupper($get_contato[0]->tipo_contato) == "JURIDICO" || strtoupper($get_contato[0]->tipo_contato) == "TESTEMUNHA"){																
									if(count($contato_juridico) <= 1){
										if(strtoupper($get_contato[0]->tipo_contato) == "JURIDICO"){
											if(count($contato_testemunha) < 1 && count($contato_juridico) <= 1){
												$retorno['codigo']   = 1;
												$retorno['input']    = $this->parametros;
												$retorno['output']   = null;
												$retorno['mensagem'] = "Necessário ter ao menos um contato (JURIDICO) ou (TESTEMUNHA) ativo";
												throw new Exception(json_encode($retorno),1);
											}	
										}else{
											if(count($contato_testemunha) <= 1 && count($contato_juridico) < 1){
												$retorno['codigo']   = 1;
												$retorno['input']    = $this->parametros;
												$retorno['output']   = null;
												$retorno['mensagem'] = "Necessário ter ao menos um contato (JURIDICO) ou (TESTEMUNHA) ativo";
												throw new Exception(json_encode($retorno),1);
											}
										}
									}															
								}							
							}else{
								$retorno['codigo']   = 1;
								$retorno['input']    = $this->parametros;
								$retorno['output']   = null;
								$retorno['mensagem'] = "Sem contatos padrão da C&M Software cadastrados";
								throw new Exception(json_encode($retorno),1);
							}
						}
					}
				}

				$this->modelo->setTable("if_contato");
				$save = $this->modelo->save($update,$get_contato[0]->id);
				if($save){
					$retorno['codigo']   = 0;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $get_contato;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno),1);
				}else{
					$retorno['codigo']   = 0;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno),1);
				}
				
			}catch(Exception $e) {
				echo $e->getMessage();
			}
		}

		function addContato(){
			try{
				if(!isset($_POST['usuario']) || empty($_POST['usuario'])){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Informe o USUÁRIO";
					throw new Exception(json_encode($retorno),1);
				}else{
					$insert['id_contrato'] = $_POST['usuario'];
					$sign_contato = json_decode($this->model_proposta->getContatoSign("sign_cm",$insert['id_contrato']));
					if(isset($sign_contato) && !empty($sign_contato)){
						$retorno['codigo']   = 1;
						$retorno['input']    = $_POST;
						$retorno['output']   = null;
						$retorno['mensagem'] = "Usuário já adicionado, exclua ele primeiro";
						throw new Exception(json_encode($retorno),1);
					}

					$get_user = json_decode($this->model_proposta->getUsuarios($insert['id_contrato']));
					if(!isset($get_user) || empty($get_user)){
						$retorno['codigo']   = 1;
						$retorno['input']    = $_POST;
						$retorno['output']   = null;
						$retorno['mensagem'] = "Erro ao obter dados do usuário";
						throw new Exception(json_encode($retorno),1);
					}else{
						$insert['cpf']         = $get_user[0]->cpf;
						$insert['nome']        = $get_user[0]->nome;
						$insert['email']       = $get_user[0]->email;	
						$insert['telefone']    = $get_user[0]->telefone;
						$insert['cargo_setor'] = $get_user[0]->cargo;
					}				
				}

				if(!isset($_POST['tipo_contato']) || empty($_POST['tipo_contato'])){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Informe o TIPO DE CONTATO";
					throw new Exception(json_encode($retorno),1);
				}else{
					$insert['tipo_contato'] = $_POST['tipo_contato'];
				}
				$insert['id_cm']  = $_POST['id_cm'];
				$insert['origem'] = "sign_cm";
				$this->modelo->setTable("if_contato");
				$save = $this->modelo->save( $insert );
				if($save){
					$retorno['codigo']   = 0;
					$retorno['input']    = $_POST;
					$retorno['output']   = $insert;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno),1);
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $insert;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = "Erro ao salvar contato";
					throw new Exception(json_encode($retorno),1);
				}
			}catch(Exception $e) {
				echo $e->getMessage();
			}
		}

		function save(){
			if(isset($_POST) && count($_POST) > 0){
				if(isset($this->parametros[1])  && is_numeric($this->parametros[1]) && $this->parametros[1] > 0){
					$id_config = $this->parametros[1];
				}else{
					$id_config = null;
				}

				$param['controle_orcamento'] = json_encode($_POST['orcamento']);
				$is_save = $this->modelo->save($param, $id_config);
				if($is_save){
					header('location:/configuracoes/detalhe/id/'.$is_save);
				}else{
					echo 'Erro';
				}
			}
		}

		function newSave(){
			try{
				if( !isset( $_POST['id_empresa'] ) || empty( $_POST['id_empresa'] ) ){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Informe a empresa";
					throw new Exception(json_encode($retorno),1);
				}else{
					$insert['id_empresa'] = $_POST['id_empresa'];

				}

				if( !isset($_POST['objeto'] ) || empty( $_POST['objeto'] ) ){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Informe o objeto";
					throw new Exception(json_encode($retorno),1);
				}else{
					$insert['objeto'] = $_POST['objeto'];

				}

				if( !isset($_POST['acao']) || empty($_POST['acao'] ) ){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Informe a ação";
					throw new Exception(json_encode($retorno),1);
				}else{
					$insert['acao'] = $_POST['acao'];

				}

				if( !isset( $_POST['id_usuario'] ) || empty( $_POST['id_usuario'] ) ){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Informe o aprovador";
					throw new Exception(json_encode($retorno),1);
				}else{
					$insert['id_usuario'] = $_POST['id_usuario'];				
				}

				if( !isset( $_POST['ordem'] ) || empty( $_POST['ordem'] ) ){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Informe a ordem de aprovação";
					throw new Exception(json_encode($retorno),1);
				}else{
					$insert['ordem'] = $_POST['ordem'];				
				}
				
				$update_fluxo = json_decode( $this->modelo->getFluxoByEmpresaEUser( $insert['id_empresa'], $insert['id_usuario'], $insert['objeto'] ) );
				if( $update_fluxo ){
					$id_fluxo = $update_fluxo[0]->id;
				}else{
					$id_fluxo = null;
				}

				$this->modelo->setTable("fluxo_ordem_aprovacao");			
				$save = $this->modelo->save( $insert, $id_fluxo );
				if($save){
					$retorno['codigo']   = 0;
					$retorno['input']    = $insert;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno),1);
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $insert;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = "Erro ao salvar fluxo";
					throw new Exception(json_encode($retorno),1);
				}	
			}catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function detalheFluxoAprovacao(){
			try{
				if( !isset( $this->parametros[0] ) || empty( $this->parametros[0] ) ){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Erro parâmetros";
					throw new Exception(json_encode($retorno),1);
				}else{
					$objeto = $this->parametros[0];
				}

				if( !isset( $this->parametros[1] ) || empty( $this->parametros[1] ) ){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Erro parâmetros";
					throw new Exception(json_encode($retorno),1);
				}else{
					$empresa = $this->parametros[1];
				}
				
				$fluxo = json_decode( $this->modelo->getAprovacoesPorEmpresa( $this->parametros[1], $this->parametros[0] ) );
				if(!isset($fluxo) || empty($fluxo)){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = "Erro em obter fluxo de aprovação";
					throw new Exception(json_encode($retorno),1);
				}else{
					$retorno['codigo']   = 0;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $fluxo;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno),1);
				}			
			}catch(Exception $e){
				echo $e->getMessage();
			}
		}

		function deletarFluxo(){
			try{
				if(!isset($this->parametros[0]) || empty($this->parametros[0])){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Erro parâmetros";
					throw new Exception(json_encode($retorno),1);
				}else{
					$id_fluxo = $this->parametros[0];				
				}

				if(!isset($this->parametros[1]) || empty($this->parametros[1])){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Erro parâmetros";
					throw new Exception(json_encode($retorno),1);
				}else{
					$objeto = $this->parametros[1];				
				}
				
				$ordem_fluxo = json_decode($this->modelo->getFluxo(null,$objeto,null,null,false));
				if(!isset($ordem_fluxo) || empty($ordem_fluxo)){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = "Erro ordem do objeto do fluxo de aprovação";
					throw new Exception(json_encode($retorno),1);
				}
				$fluxo_user = json_decode($this->modelo->getFluxo(null,$objeto,$id_fluxo));	
				if(!isset($fluxo_user) || empty($fluxo_user)){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = "Erro em excluir aprovador do fluxo de aprovação";
					throw new Exception(json_encode($retorno),1);
				}		
				
				
				if(is_array($ordem_fluxo)){
					foreach ($ordem_fluxo as $key => $value) {
						$check_ordem[$value->ordem][] = $value;
					}
					foreach ($ordem_fluxo as $key => $value) {
						if( $fluxo_user[0]->ordem < $value->ordem && count($check_ordem[$value->ordem]) == 1 ){
							$retorno['codigo']   = 1;
							$retorno['input']    = $this->parametros;
							$retorno['output']   = $this->modelo->info;
							$retorno['mensagem'] = "Erro em excluir aprovador, necessário primeiro excluir o ".$value->ordem."° aprovador: ".$value->nome;
							throw new Exception(json_encode($retorno),1);
						}
					}
				}
			
				$deleted['deleted'] = 1;
				$this->modelo->setTable('fluxo_ordem_aprovacao');
				$save = $this->modelo->save($deleted,$id_fluxo);
				if($save){
					$retorno['codigo']   = 0;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno),1);
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = "Erro em excluir aprovador do fluxo de aprovação";
					throw new Exception(json_encode($retorno),1);
				}
							
			}catch(Exception $e) {
				echo $e->getMessage();
			}
		}

		function atualizarEmpresaVendedora(){
			try{
				if(isset($this->parametros[0]) && !empty($this->parametros[0])){
					$id = $this->parametros[0];
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Erro parâmetros id empresa";
					throw new Exception(json_encode($retorno),1);
				}
				$this->modelo->setTable("empresa_vendedora");
				$get_empresa_vendedora = json_decode($this->modelo->getEmpresas(null,true));
				if(isset($get_empresa_vendedora) && !empty($get_empresa_vendedora)){
					$insert['empresa_vendedora'] = "1";
					foreach ($get_empresa_vendedora as $key => $value) {
						$update = $this->modelo->save($insert,$value->id);
						if(!$update){
							$retorno['codigo']   = 1;
							$retorno['input']    = $this->parametros;
							$retorno['output']   = null;
							$retorno['mensagem'] = "Erro atualizar empresa vendedora";
							throw new Exception(json_encode($retorno),1);
						}
					}
				}

				$empresa = json_decode($this->modelo->getEmpresas($id));						
				if(isset($empresa) && !empty($empresa)){
					$insert['empresa_vendedora'] = "0";
					$save = $this->modelo->save($insert,$empresa[0]->id);
					if($save){
						$retorno['codigo']   = 0;
						$retorno['input']    = $this->parametros;
						$retorno['output']   = null;
						$retorno['mensagem'] = "Sucesso";
						throw new Exception(json_encode($retorno),1);
					}else{
						$retorno['codigo']   = 1;
						$retorno['input']    = $this->parametros;
						$retorno['output']   = null;
						$retorno['mensagem'] = "Erro em save empresa vendedora";
						throw new Exception(json_encode($retorno),1);
					}
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Erro em encontrar empresa";
					throw new Exception(json_encode($retorno),1);
				}
			}catch(Exception $e){
				echo $e->getMessage();
			}
		}
		
		function alerta(){
			$usuarios   = json_decode($this->obj_usuario->getAllUser());
			$get_alerta = json_decode($this->modelo->getAlertas());
			
			require_once ABSPATH . '/views/'.$this->module.'/alerta-view.php';
		}

		function addAlerta(){
			try{
				if(isset($_POST['usuario']) && !empty($_POST['usuario'])){
					$insert['id_usuario'] = $_POST['usuario'];
				}else{				
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Informe o Usuário";
					throw new Exception (json_encode($retorno), 1);
				}

				if(isset($_POST['objeto']) && !empty($_POST['objeto'])){
					$insert['objeto'] = $_POST['objeto'];
				}else{				
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Informe o objeto";
					throw new Exception (json_encode($retorno), 1);
				}

				if(isset($_POST['alerta'])){
					$insert['alerta'] = $_POST['alerta'];
				}else{				
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Informe o alerta";
					throw new Exception (json_encode($retorno), 1);
				}

			
				$get_user = json_decode($this->modelo->getAlertas($insert['id_usuario'],$insert['objeto']));
				if(isset($get_user) && !empty($get_user)){			
					$update_id = $get_user[0]->id;
				}else{
					$update_id = null;
				}			
							
				$this->modelo->setTable("alertas");
				$save = $this->modelo->save($insert,$update_id);
				if($save){
					$retorno['codigo']   = 0;
					$retorno['input']    = $insert;
					$retorno['output']   = $save;
					if(isset($update_id) && !empty($update_id)){
						$retorno['mensagem'] = "Update realizado";
					}else{
						$retorno['mensagem'] = "Sucesso";
					}
					throw new Exception (json_encode($retorno), 1);
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $insert;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = "Erro em salvar na base";
					throw new Exception (json_encode($retorno), 1);
				}			
			}catch(Exception $e){
				echo $e->getMessage();
			}
		}

		function deletarAlerta(){
			try{
				if(isset($this->parametros[0]) && !empty($this->parametros[0])){
					$id = $this->parametros[0];
					$update['deleted'] = 1;
				}else{				
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Erro nos parâmetros para deletar alerta";
					throw new Exception (json_encode($retorno), 1);
				}
				
				$this->modelo->setTable("alertas");
				$save = $this->modelo->save($update,$id);
				if($save){				
					$retorno['codigo']   = 0;
					$retorno['input']    = $insert;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception (json_encode($retorno), 1);
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $insert;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = "Erro em salvar no banco de dados";
					throw new Exception (json_encode($retorno), 1);
				}			
			}catch(Exception $e){
				echo $e->getMessage();
			}
		}
	}