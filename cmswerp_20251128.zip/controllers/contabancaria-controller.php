<?php
class ContaBancariaController extends MainController{
	
	protected $module = 'contabancaria';
	
	protected $class_conta_bancaria;
	//protected $obj_fat, $obj_contas, $obj_nf, $obj_desp, $obj_banco, $obj_orcamento, $obj_fornecedor, $upload, $conf_upload, $obj_movimento;

	function __construct($parametros = null){
		$this->nome_modulo = 'contabancaria';
		$this->class_conta_bancaria = new ContaBancaria($this, false);
		parent::__construct($parametros);
	}

	function index(){
		$this->lista();
	}

	function lista(){
		$records  = json_decode($this->class_conta_bancaria->getContaBancariaConvenio());
		require_once ABSPATH . '/views/'.$this->module.'/conta-view.php';
	}

	function detalhe(){
		try {
			if(is_numeric($this->parametros[1])){
				$bancos   = json_decode($this->class_conta_bancaria->getBanco());
				require_once ABSPATH . '/views/'.$this->module.'/conta-edit.php';
			}else{
				loadRetorno('1', $this->parametros[1], null, 'ID da conta invalida!', 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function save(){
		try {

			$clean_default = null;
			$param['id_empresa'] 			  = $_POST['id_empresa'];
			$param['origem_conta']            = $_POST['origem_conta'];
			$param['id_banco']                = $_POST['id_banco_bacen'];
			$param['tipo_conta']              = $_POST['tipo_conta'];
			$param['numero_agencia']          = $_POST['numero_agencia'];
			$param['digito_agencia']          = $_POST['digito_agencia'];
			$param['numero_conta']            = $_POST['numero_conta'];
			$param['digito_conta']            = $_POST['digito_conta'];
			$param['chave_pix']               = $_POST['chave_pix'];
			$param['codigo_convenio_cnab400'] = $_POST['codigo_convenio_cnab400'];
			$param['codigo_convenio_cnab240'] = $_POST['codigo_convenio_cnab240'];
			$param['email']                   = $_POST['email'];
			$param['conta_default'] 		  = $_POST['conta_default'];
			
			if(empty($param['id_empresa']) && $param['origem_conta'] == 'despesa'){
				$retorno['codigo']   = 1;
				$retorno['tipo']     = 'error';
				$retorno['mensagem'] = 'Despesa invalida, caso seja uma despesa nova, primeiro salve a despesa e depois insira a conta';
				$retorno['input']    = $_POST;
				$retorno['output']   = $this->modelo->controller->Db;
				throw new Exception(json_encode($retorno), 1);
			}

			if($param['conta_default'] == '1'){
				if('empresa_cm' == $param['origem_conta']){
					$chk_default = json_decode($this->modelo->getContaBancariaDefault($param['id_empresa'], 'empresa_cm'));
				}elseif('fornecedor' == $param['origem_conta']){
					$chk_default = json_decode($this->modelo->getContaBancariaDefault($param['id_empresa'], 'fornecedor'));
				}elseif('despesa' == $param['origem_conta']){
					$chk_default = json_decode($this->modelo->getContaBancariaDefault($param['id_empresa'], 'despesa'));
				}

				if($chk_default){
					foreach ($chk_default as $key => $value) {
						$clean_default[] = $value->id;
					}
				}
			}else{
				$param['conta_default'] = 0;
			}

			$is_save = $this->modelo->save($param);

			if($is_save){
				if($clean_default){
					foreach ($clean_default as $key => $value) {
						$param_clean['conta_default'] = 0;
						$this->modelo->save($param_clean, $value);
					}
				}
				
				$retorno['codigo']   = 0;
				$retorno['tipo']     = 'success';
				$retorno['mensagem'] = 'Dados Salvos com sucesso';
				$retorno['input']    = $_POST;
				$retorno['output']   = $is_save;;
				throw new Exception(json_encode($retorno), 1);
			}else{
				$retorno['codigo']   = 1;
				$retorno['tipo']     = 'danger';
				$retorno['mensagem'] = 'Erro ao salvar banco';
				$retorno['input']    = $_POST;
				$retorno['output']   = $this->modelo->controller->Db->error;
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}

		// if(empty($this->parametros[1])){
		// 	$return = $this->modelo->save($_POST);
		// }else{
		// 	$return = $this->modelo->save($_POST, $this->parametros[1]);	
		// }
		// header('location: /banco/detalhe/id/'.$return);
	}

	function apagar(){
		try {
			if(!is_numeric($this->parametros[1]) || empty($this->parametros[1])){
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = 'ID da conta invalido';
				throw new Exception(json_encode($retorno), 1);
			}

			$param['deleted'] = 1;
			$is_save = $this->modelo->save($param, $this->parametros[1]);
			if($is_save){
				$retorno['codigo'] = 0;
				$retorno['input']  = $this->parametros;
				$retorno['output'] = $is_save;
				$retorno['mensagem'] = 'Conta apagada com sucesso';
			}else{
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = 'Erro ao apagar essa conta';
			}
			throw new Exception(json_encode($retorno), 1);
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function getContasBancariasJson(){
		try {
			$bancos = null;

			if(!is_numeric($this->parametros[1]) || empty($this->parametros[1])){
				$retorno['codigo']   = 2;
				$retorno['input']    = $_POST;
				$retorno['output']   = $this->parametros;
				$retorno['mensagem'] = 'Cadastro novo não possui conta bancaria cadastrado';
				throw new Exception(json_encode($retorno), 1);
			}
			
			if('despesa' == $this->parametros[0]){
				$bancos = json_decode($this->class_conta_bancaria->getContaByDespesa($this->parametros[1]));
			}elseif('empresa_cm' == $this->parametros[0]){
				$default = isset($_POST['default']) ? filter_var($_POST['default'], FILTER_VALIDATE_BOOLEAN) : true;
				$bancos = json_decode($this->class_conta_bancaria->getContaByEmpresa($this->parametros[1], null, $default));
			}else{
				$bancos = json_decode($this->class_conta_bancaria->getContaByFornecedor($this->parametros[1]));
			}

			if($bancos){
				$retorno['codigo']   = 0;
				$retorno['input']    = $this->parametros;
				$retorno['output']   = $bancos;
				$retorno['mensagem'] = 'Sucesso';
				throw new Exception(json_encode($retorno), 1);
			}else{
				$retorno['codigo']   = 2;
				$retorno['input']    = $this->parametros;
				$retorno['output']   = $bancos;
				$retorno['mensagem'] = 'Nenhuma conta bancaria encontrada';
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function checkContaDefault(){
		try {
			if(isset($this->parametros[2]) && is_numeric($this->parametros[2])){
				if($this->parametros[0] == 'empresa_cm'){
					$contas_bancarias = json_decode($this->modelo->getContaByEmpresa($this->parametros[2]));
				}elseif($this->parametros[0] == 'despesa'){
					$contas_bancarias = json_decode($this->modelo->getContaByDespesa($this->parametros[2]));
				}else{
					$contas_bancarias = json_decode($this->modelo->getContaByFornecedor($this->parametros[2]));
				}
				if($contas_bancarias){
					foreach ($contas_bancarias as $key => $value){
						if($value->id != $this->parametros[3]){
							$param['conta_default'] = 0;
						}else{
							$param['conta_default'] = 1;
						}
						$is_save = $this->modelo->save($param, $value->id);
					}
				}
				$retorno['codigo']   = 0;
				$retorno['input']    = $this->parametros;
				$retorno['output']   = null;
				$retorno['mensagem'] = 'Checked com sucesso';
			}else{
				$retorno['codigo']   = 1;
				$retorno['input']    = $this->parametros;
				$retorno['output']   = null;
				$retorno['mensagem'] = 'Conta desconhecida!';
			}
			throw new Exception(json_encode($retorno), 1);
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function getBancoList(){
		echo $this->class_conta_bancaria->getBancoByNome($_POST['search']);
	}
}
?>
