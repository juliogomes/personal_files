<?php
	class ContasReceberController extends MainController{
		protected $module = 'contas receber';
		protected $valores;
		protected $obj_contrato;
		protected $obj_nota;
		protected $obj_movimento;

		function __construct($parametros){
			$this->nome_modulo = 'cobranca';
			parent::__construct($parametros);
			$controller = new MainController(null, false, false);
			$controller->load_model('contratos/contratos');
			$this->obj_contrato = $controller->getModel();
			$this->obj_nota = $controller->load_model('notas-fiscais/notas-fiscais', true);
			$controller->Db = new Db(DB_NAME_MOVIMENTO);// Configurando o banco de dados movimento 
			$controller->load_model('movimento/movimento');
			$this->obj_movimento = $controller->getModel();
		}

		function index(){
			$this->lista();
		}

		function lista(){
			//Ainda não implementado
		}

		function modulos(){
			$obj_contrato = $this->load_model('contratos/contratos', true);
			$contrato = $obj_contrato->getModulosByContrato($this->parametros[1], null, false, false, false);
			$contrato = json_decode($contrato);
			if(!$contrato){
				echo 'Contrato não existe';
				exit;
			}
			require_once ABSPATH . '/views/'.$this->module.'/cobranca-view.php';
		}

		function detalhe(){
			$obj_contrato = $this->load_model('contratos/contratos', true);
			if(isset($this->parametros[3]) && !empty($this->parametros[3])){
				$contrato = $obj_contrato->getModulosByContrato($this->parametros[1], $this->parametros[3]);
			}else{
				$contrato = $obj_contrato->getModulosByContrato($this->parametros[1]);
			}

			$contrato = json_decode($contrato);
			if($this->parametros[1] && $this->parametros[2]){
				$modulo = json_decode($this->modelo->getLpByCustomer($this->parametros[1] , $this->parametros[3], true, $this->parametros[2]));
			}
			if(!$contrato){
				echo 'Erro ao pesquisar contrato';
			}else{
				require_once ABSPATH . '/views/'.$this->module.'/lp-view-detalhe.php';
			}
		}

		function listarcontratos(){
			$controller = new MainController(null, false, false);
			$controller->load_model('contratos/contratos');
			$this->obj_contrato = $controller->getModel();
			$records  = json_decode($this->obj_contrato->customGetRecords(null, null, true));
			require_once ABSPATH . '/views/'.$this->module.'/listar-contratos-view.php';
		}

		function lancamentomanual(){
			$controller = new MainController(null, false, false);
			$controller->load_model('contratos/contratos');
			$this->obj_contrato = $controller->getModel();
			$records  = json_decode($this->obj_contrato->customGetRecords($this->parametros[1], 'id', true));
			if($records){
				$modulos = json_decode($this->obj_contrato->getModulosByContrato($this->parametros[1], null, true, true ));
				$lancamentos = json_decode($this->obj_movimento->getMovManual($records[0]->codigo_cliente, $records[0]->codigo_produto));
				require_once ABSPATH . '/views/'.$this->module.'/lancamento-manual-view.php';
			}else{
				echo 'Contrato não existe';
			}
		}

		function deletelancamento(){
			if($_POST){
				if(isset($_POST['id_mov_diario']) && !empty($_POST['id_mov_diario'])){
					$this->obj_movimento->deleteRecords('mov_diario', $_POST['id_mov_diario']);
					header('location: /cobranca/lancamentomanual/id/'.$_POST['id_contrato'].'/');
				}else{
					echo 'Erro ao apagar tarifação informações insuficientes! ';
				}
			}else{
				echo 'Erro ao apagar tarifação! ';
			}
		}

		function savelancamento(){
			if($_POST){
				if(!isset($_POST['contador_trx']) || empty($_POST['contador_trx'])){
					$_POST['contador_trx'] = 1;
				}
				$param1['qtd_transacoes'] = $_POST['contador_trx'];
				$param1['valor'] 		  = removeCaracteres($_POST['contador_fin'], 'moeda2', null);
				$param1['data_tarifacao'] = convertDate($_POST['data_tarifacao'], true, null);
				$param1['data_operacao']  = date('Y-m-d');
				$param1['id_contrato']	  = $_POST['id_contrato'];
				$param1['codigo_cliente'] = $_POST['codigo_cliente'];
				$param1['codigo_produto'] = $_POST['codigo_produto'];
				$param1['tipo_tarifacao'] = $_POST['tipo_tarifacao'];
				$param1['codigo_modulo']  = $_POST['codigo_modulo'];
				$param1['codigo_cliente'] = $_POST['codigo_cliente'];
				$param1['status_trans']   = 'ativo';
				$param1['nsu']			  = '0000000000';
				$is_save = $this->obj_movimento->insertMov($param1);
				if($is_save){
					$param2['id_mov_diario']   = $is_save;
					$param2['id_contrato'] 	   = $_POST['id_contrato'];
					$param2['origem']		   = 'lancamento';
					$param2['descricao'] 	   = 'lancamento manual';
					$param2['qtd_transacoes']  = $_POST['contador_trx'];
					$param2['qtd_horas'] 	   = removeCaracteres($_POST['contador_horas'], 'moeda2', null);
					$param2['id_produto'] 	   = $_POST['id_produto'];
					$param2['codigo_produto']  = $_POST['codigo_produto'];
					$param2['id_modulo'] 	   = $_POST['id_modulo'];
					$param2['codigo_modulo']   = $_POST['codigo_modulo'];
					$param2['valor_base'] 	   = removeCaracteres($_POST['contador_fin'], 'moeda2', null);
					$param2['valor_calculado'] = removeCaracteres($_POST['contador_fin'], 'moeda2', null);
					$param2['data_tarifacao']  = convertDate($_POST['data_tarifacao'], true, null);
					$param2['vencimento_em']   = convertDate($_POST['data_vencimento'], true, null);
					$param2['tipo'] 		   = $_POST['tipo'];
					$param2['status']		   = 'pendente';
					$this->obj_nota->insertMovAux($param2);
				}
				header('location: /cobranca/lancamentomanual/id/'.$_POST['id_contrato'].'/');
			}else{
				echo 'Erro ao inserir tarifação! ';
			}
		}

		function valores(){
			$obj_contrato = $this->load_model('contratos/contratos', true);
			if(isset($this->parametros[3]) && !empty($this->parametros[3])){
				$contrato = $obj_contrato->getModulosByContrato($this->parametros[1], $this->parametros[3]);
			}else{
				$contrato = $obj_contrato->getModulosByContrato($this->parametros[1]);
			}
			$contrato = json_decode($contrato);
			if(!empty($this->parametros[4])){
				$preco = json_decode($this->modelo->getFaixa($this->parametros[4]));
			}
			require_once ABSPATH . '/views/'.$this->module.'/faixa-cadastro-'.strtolower($contrato[0]->tipo_cobranca).'.php';
		}

		function salvar(){
			$id_lista = $this->parametros['3'];
			$_POST['id_contrato']  =$this->parametros['0'];
			$_POST['id_produto'] =$this->parametros['1'];
			$_POST['id_modulo']  =$this->parametros['2'];
			$_POST['status'] =  'ativo';
			$this->save($_POST, $id_lista);
			header('location: /cobranca/detalhe/id/'.$this->parametros['0'].'/'.$this->parametros['1'].'/'.$this->parametros['2'].'/');
		}

		function pacote(){
			if($this->parametros[0] == 'save'){
				$this->modelo->table = 'pacote_contratado';

				if($_POST['id']){
					$id_pacote = $_POST['id'];
				}else{
					$id_pacote = null;
				}

				unset($_POST['id']);
				$_POST['id_contrato'] = $this->parametros[2];

				if($this->save($_POST, $id_pacote)){
					$msg = 'Pacote salvo com sucesso!';
				}else{
					$msg = 'Erro ao salvar pacote';
				}
				header("location: /cobranca/detalhe/id/".$this->parametros[2].'/'.$this->parametros[3].'/'.$this->parametros[4]."?msg=".base64_encode($msg));
			}
		}

		function delete(){
			if(isset($this->parametros[3]) && !empty($this->parametros[3])){
				$var = $this->modelo->deleteRecords('lp_clientes', $this->parametros[3]);
			}
			header('location: /cobranca/detalhe/id/'.$this->parametros['0'].'/'.$this->parametros['1'].'/'.$this->parametros['2']);
		}

		function save($param, $id = null){
			if(isset($param['action']))
			{
				unset($param['action']);
			}
			return $this->modelo->save($param, $id);
		}
	}
