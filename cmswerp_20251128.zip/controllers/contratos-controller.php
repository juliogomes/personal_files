<?php
	// require_once('classes/class-Validacao.php');
require_once ABSPATH . DS . "functions/form_helper.php";
class ContratosController extends MainController{
	protected $obj_email;
	protected $obj_api;
	protected $empresa_cm;
	protected $produtos_model;
	protected $agente_model;
		
	function __construct( $parametros = null, $do_login = true ){
		$this->setModulo('contratos');
		$this->setView('contratos');
		parent::__construct( $parametros, 'contratos', $do_login );
		$this->empresa_cm     = json_decode( $this->modelo->getEmpresasCM() );
		$this->produtos_model = $this->load_model('produtos/produtos', true);
		$this->agente_model	  = $this->load_model('agentecomercial/agentecomercial', true);
		$this->produtos_list  = json_decode($this->produtos_model->getAllCodigoProdutosAtivos());
		$this->obj_api        = new Api($this);		
	}

	function setObjectEmail(){
		$this->obj_email = new Email();	
	}

	function index(){
		$this->lista();
	}

	function lista(){
		$records  		   = json_decode($this->modelo->contratosAtivos(null, false, true));	
		require_once ABSPATH . '/views/'.$this->nome_view.'/contratos-view.php';
	}

	function detalhe(){
		if( isset( $this->parametros[1] ) && !empty($this->parametros[1] ) ){
			$class_conta_bancaria = new ContaBancaria($this, false);
			$contas_bancarias_nao_filtadas    = json_decode($class_conta_bancaria->getContaConvenio());

			$records = json_decode( $this->modelo->contratosAtivos( $this->parametros[1], false, true ) );
			$lista_meta_dados = json_decode($this->modelo->getMetaDadosStatus($this->parametros[1]));
			$item_id = $this->parametros[1];
			if(!$records[0]->mes_reajuste){
				$data_reajuste = new Datetime($records[0]->data_reajuste);
				$mes_reajuste = $data_reajuste->format('m');
			}else{
				$mes_reajuste = getDataAtual($records[0]->data_reajuste);
				$mes_reajuste = $mes_reajuste->format('m');
			}
		}
		require_once ABSPATH . '/views/'.$this->nome_view.'/contratos-detalhe-view.php';
	}

	function gravarObervacao(){
		try {
			$this->modelo->setTable('meta_dados');
			$item_id = $_POST["item_id"];
			$observacao = null;
			if ($_POST['confirmacao'] == '1') {
				$id_conjunto = gerarNumeroRandom('unico', 14);
				$meta_observacao['id_conjunto']     = $id_conjunto;
				$meta_status['id_conjunto'] 		= $id_conjunto;
			}

			$meta_valor = json_encode([
				'meta_tipo' => $_POST['meta_tipo'],
				'meta_classificacao' => $_POST['meta_classificacao'],
				'textarea_observacao' => $_POST['textarea_observacao'],
				'confirmacao' => $_POST['confirmacao'],
			]);

			$meta_observacao['meta_campo'] 			= 'observacao';
			$meta_observacao['meta_tipo'] 			= 'observacao';
			$meta_observacao['meta_classificacao'] 	= 'detalhes';
			$meta_observacao['meta_valor'] 			= $meta_valor;
			$meta_observacao['meta_origem'] 		= 'contrato';
			$meta_observacao['meta_id_origem'] 		= $_POST["item_id"];
			$meta_observacao['id_owner'] 			= $this->userdata->id;
			$meta_observacao['data_registro'] 		= $this->data_hora_atual->format('Y-m-d');
			$meta_observacao['meta_default'] 		= 0;
			$meta_observacao['alterado_por'] 		= $this->userdata->id;
			$meta_observacao['alterado_em'] 		= $this->data_hora_atual->format('Y-m-d H:i:s');
			$meta_observacao['deleted'] 			= 0;

			if(isset($_POST['meta_id'])){
				$new_id_observacao = $this->modelo->save($meta_observacao, $_POST['meta_id']);
			}else{
				$new_id_observacao = $this->modelo->save($meta_observacao);
			}

			if ($new_id_observacao == false) {
				throw new Exception('Erro ao inserir observação');
			}

			if(isset($_POST['pendencia_id']) && $_POST['pendencia_id'] != ''){
				$update_status = [];

				$update_status['deleted'] = $_POST['confirmacao'] == 0 ? 1: 0;
				$observacao = json_encode([
					'limite_notificação' => $_POST['limite_notificacao']
				]);
				$update_status['meta_default'] 		= $_POST['validado'];
				$update_status['meta_info'] 		= $observacao;
				$update_status['alterado_por'] 		= $this->userdata->id;
				$update_status['alterado_em'] 		= $this->data_hora_atual->format('Y-m-d H:i:s');
				if($this->modelo->save($update_status, $_POST['pendencia_id']) == false){
					throw new Exception('Erro ao editar observação');
				}
			}

			if ($_POST['confirmacao'] == '1' && (!isset($_POST['pendencia_id']) || $_POST['pendencia_id'] == '')) {
				$observacao = json_encode([
					'limite_notificação' => $_POST['limite_notificacao']
				]);

				$meta_status['meta_campo'] 			= 'observacao';
				$meta_status['meta_tipo'] 			= 'pendencia';
				$meta_status['meta_classificacao'] 	= 'observacao';
				$meta_status['meta_valor'] 			= "Pendência referente a validação do contrato $item_id";
				$meta_status['meta_info'] 			= $observacao;
				$meta_status['meta_origem'] 		= 'observacao';
				$meta_status['meta_id_origem'] 		= $new_id_observacao;
				$meta_status['id_owner'] 			= $this->userdata->id;
				$meta_status['data_registro'] 		= $this->data_hora_atual->format('Y-m-d');
				$meta_status['meta_default'] 		= 1;
				$meta_status['alterado_por'] 		= $this->userdata->id;
				$meta_status['alterado_em'] 		= $this->data_hora_atual->format('Y-m-d H:i:s');
				$meta_status['deleted'] 			= 0;

				$new_id_status = $this->modelo->save($meta_status);
				if ($new_id_status == false) {
					throw new Exception('Erro ao inserir observação');
				}
			}
			$this->retorno('ok', 'Registro salvo com sucesso', $item_id);
		} catch (Exception $e) {
			$this->retorno('erro', $e->getMessage());
		}
	}

	function obtemObservacao() {
		$lista_meta_dados = json_decode($this->modelo->getMetaDadosStatusById($_GET['item_id']));
		if(!$lista_meta_dados) {
			$this->retorno('erro', 'Erro ao obter observação!');
		}else{
			$this->retorno('ok', '',$lista_meta_dados[0]);	
		}
	}
	
	function confirmStatus(){
		try {
			$this->modelo->setTable('meta_dados');
			$item_id = $_POST["id_meta"];
			$meta_status_update = [
				'meta_default' => 0,
				'alterado_por' => $this->userdata->id,
			];

			if ($this->modelo->save($meta_status_update, $item_id) == true) {
				$this->retorno('ok', 'Registro salvo com sucesso');
			} else {
				$this->retorno('erro', 'Erro ao atualizar observação');
			}
		} catch (Exception $e) {
			$this->retorno('erro', $e->getMessage());
		}
	}

		function indices(){
			$this->modelo->setTable('contratos');
			$records  = json_decode($this->modelo->customGetRecords(null, null, true));
			require_once ABSPATH . '/views/'.$this->nome_view.'/indices-view.php';
		}
		
		function save(){
			try {
				if( isset( $_POST['cnpj'] ) && !empty( $_POST['cnpj'] ) ){
					$_POST['cnpj'] = removeCaracteres($_POST['cnpj'], 'char', null);
				}else{
					$retorno['codigo']   = 1;
					$retorno['tipo']     = 'error';
					$retorno['input']    = $_POST;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Informe o CNPJ';
					throw new Exception(json_encode($retorno), 1);
				}

				if (isset($_POST['codigo_pais']) && !empty($_POST['codigo_pais'])) {
    				$_POST['codigo_pais'] = ltrim($_POST['codigo_pais'], 0);
    				if ($_POST['codigo_pais'] == '076' && $_POST['codigo_pais'] == 76) {
    					$_POST['cidade'] = $_POST['municipio'];
    					$_POST['estado'] = $_POST['uf'];
    				}
    				unset($_POST['municipio']);
    				unset($_POST['uf']);
    			} else {
    				$retorno['codigo']   = 1;
    				$retorno['tipo']     = 'error';
    				$retorno['mensagem'] = 'Informe o pais';
    				throw new Exception(json_encode($retorno), 1);
    			}

				if(isset( $_POST['cnpj_fantasia']) && !empty( $_POST['cnpj_fantasia'] ) ){
					$_POST['cnpj_fantasia'] = removeCaracteres($_POST['cnpj_fantasia'], 'char', null);
				}else{
					$_POST['cnpj_fantasia'] = $_POST['cnpj'];
				}

				if( empty( $_POST['nome_fantasia'] ) ){
					$_POST['nome_fantasia'] = $_POST['razao_social'];
				}

				if( $_POST['status'] == 'inativo' || $_POST['status'] == 'suspenso' ){
					$_POST['inativado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
				}else{
					$_POST['inativado_em'] = null;
				}
				
				if( !empty( $_POST['data_assinatura'] ) && $_POST['data_assinatura']!= '00/00/0000' ){
					$_POST['data_assinatura'] = convertDate( $_POST['data_assinatura'], true, null);
				}

				if(!empty( $_POST['data_reajuste'] ) && $_POST['data_reajuste']!= '00/00/0000' ){
					$_POST['data_reajuste'] = convertDate( $_POST['data_reajuste'], true, null);
				}else{
					//caso a data de reajuste não seja configurada ela será igual a data de assinatura.
					$_POST['data_reajuste'] = $_POST['data_assinatura'];
				}

				if( !isset( $_POST['indice_reajuste'] ) || empty( $_POST['indice_reajuste'] ) ){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Informe o indice de reajuste!';
					throw new Exception(json_encode($retorno), 1);
				}

				if( isset( $_POST['cnpj_fantasia']) && !empty($_POST['cnpj_fantasia'] ) ){
					$_POST['codigo_cliente'] = substr(removeCaracteres($_POST['cnpj_fantasia'], 'char', null), '0', '8');
				}else{
					$_POST['codigo_cliente'] = substr(removeCaracteres($_POST['cnpj'], 'char', null), '0', '8');
				}

				if( isset( $_POST['ddi_pais'] ) && !empty( $_POST['ddi_pais'] ) ){
					$_POST['ddi_pais'] = ltrim( $_POST['ddi_pais'], 0);
				}

				$chk = json_decode($this->modelo->getContratosPorProdutos( $_POST['id_produto'], $_POST['codigo_cliente'] ) );
				if( $chk && $this->parametros[1] == 0 ){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = $chk;
					$retorno['mensagem'] = 'Já existe um contrato com esse cnpj e esse produto!';
					throw new Exception(json_encode($retorno), 1);
				}

				$_POST['cep']                       = removeCaracteres($_POST['cep'], 'char', null);
				$_POST['isento_de']                 = ( !empty( $_POST['isento_de'] ) && $_POST['isento_de'] != '00/00/0000')?convertDate( $_POST['isento_de'], true, null ):null;
				$_POST['isento_ate']                = ( !empty( $_POST['isento_ate'] ) && $_POST['isento_ate']!= '00/00/0000')?convertDate( $_POST['isento_ate'], true, null ):null;
				$_POST['data_primeiro_faturamento'] = ( !empty( $_POST['data_primeiro_faturamento'] ) && $_POST['data_primeiro_faturamento']!= '00/00/0000')?convertDate( $_POST['data_primeiro_faturamento'], true, null ):null;
				$_POST['inativar_em']               = ( !empty( $_POST['inativar_em'] ) && $_POST['inativar_em']!= '00/00/0000')?convertDate( $_POST['inativar_em'], true, null ):null;
				$_POST['inicio_producao_em']        = ( !empty( $_POST['inicio_producao_em'] ) && $_POST['inicio_producao_em'] != '00/00/0000')?convertDate( $_POST['inicio_producao_em'], true, null ):null;
				$_POST['ultima_data_demo']          = ( !empty( $_POST['ultima_data_demo'] ) && $_POST['ultima_data_demo']!= '00/00/0000')?convertDate( $_POST['ultima_data_demo'], true, null ):null;
				$_POST['carencia_de_uso']           = ( !empty( $_POST['carencia_de_uso'] ) && $_POST['carencia_de_uso']!= '00/00/0000')?convertDate( $_POST['carencia_de_uso'], true, null ):null;
				$_POST['primeira_parcela_em'] 		= ( !empty( $_POST['primeira_parcela_em'] ) && $_POST['primeira_parcela_em']!= '00/00/0000')?convertDate( $_POST['primeira_parcela_em'], true, null ):null;
				$_POST['valor_implantacao'] 		= removeCaracteres( $_POST['valor_implantacao'], 'moeda2', null );
				$_POST['hospedagem_mensal'] 		= removeCaracteres( $_POST['hospedagem_mensal'], 'moeda2', null );
				$_POST['licenca_uso_mensal'] 		= removeCaracteres( $_POST['licenca_uso_mensal'], 'moeda2', null );
				$_POST['data_corte_faturamento'] 	= ( !empty($_POST['data_corte_faturamento'] ) )?$_POST['data_corte_faturamento']:01;
				
				if( count( $_POST ) > 0 ){
					$produto = json_decode( $this->produtos_model->getProduto($_POST['id_produto'] ) );
					if(!$produto){
						$retorno['codigo']   = 1;
						$retorno['input']    = $_POST;
						$retorno['output']   = $produto;
						$retorno['mensagem'] = 'Produto não encontrado!';
						throw new Exception(json_encode($retorno), 1);
					}

					if( empty( $this->parametros[1] ) || empty( $_POST['numero_contrato'] ) ){
						$_POST['numero_contrato'] = substr($produto[0]->codigo, 0,3).$this->data_hora_atual->format('YmdHis');
					}
					
					$save_contrato = $this->modelo->save( $_POST, $this->parametros[1] );
					if( $save_contrato ){
						if( !isset( $this->parametros[1] ) || empty( $this->parametros[1] ) ){
							if( $_POST['id_produto'] == 6000000 ){
								// ativa contrato crytal
								$integracao       = new Integracoes( $this, 'CRY0001');
								$ativacao_crystal = json_decode( $integracao->Exec( 'cliente', 'onboarding', $_POST ) );
								// enviar alerta de inclusão de contrato crystal
								$obj_notificacoes = new Notificacoes( $this );
								$param_envio['email']['destinatario'][0] = 'roberto.vergili@cmsw.com';
								$param_envio['email']['destinatario'][1] = 'renata.ribeiro@cmsw.com';
								$param_envio['email']['copia_oculta'] 	 = SYSTEM_NOTIFY_TO;
								$param_envio['email']['assunto']      	 = 'Teste contrato crystal';
								if( $ativacao_crystal->codigo == 0 ){
									$param_envio['email']['mensagem'] = 'OnBOarding do cliente '.$_POST['razao_social'].' efetuado com sucesso';
								}else{
									$param_envio['email']['mensagem'] = 'OnBOarding do cliente '.$_POST['razao_social'].' com falha. - '.json_encode( $ativacao_crystal->output );
								}
								$is_send = json_decode( $obj_notificacoes->sendNotificacao('alertas', $param_envio ) );
							}
						}
						$retorno['codigo']   = 0;
						$retorno['input']    = $_POST;
						$retorno['output']   = $save_contrato;
						$retorno['mensagem'] = 'Sucesso ao salvar registro';
						throw new Exception(json_encode($retorno), 1);
					}else{
						$retorno['codigo']   = 1;
						$retorno['input']    = $_POST;
						$retorno['output']   = $this->modelo->info;
						$retorno['mensagem'] = $this->modelo->info->mensagem;
						throw new Exception(json_encode($retorno), 1);
					}	
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Dados do conrtato não informados';
					throw new Exception(json_encode($retorno), 1);
				}
			}catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function getComissao(){
			try{
				if(!isset($this->parametros[0]) || empty($this->parametros[0])){
					$retorno['codigo']   = 1;				
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Erro id_contrato';
					throw new Exception(json_encode($retorno), 1);
				}else{
					$id_contrato = $this->parametros[0];
				}	
				
				$contrato = json_decode($this->modelo->getIfContrato($id_contrato));
				if(!isset($contrato) || empty($contrato)){
					$retorno['codigo']   = 1;				
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $id_contrato;
					$retorno['mensagem'] = 'Contrato ativo não encontrado';
					throw new Exception(json_encode($retorno), 1);
				}			

				$comissao = json_decode($this->modelo->getFullComissao($contrato[0]->id));
				if(!isset($comissao) || empty($comissao)){
					$retorno['codigo']   = 1;				
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $id_contrato;
					$retorno['mensagem'] = 'Erro ao obter comissão';
					throw new Exception(json_encode($retorno), 1);
				}			

				$retorno['codigo']   = 0;				
				$retorno['input']    = $contrato;
				$retorno['output']   = $comissao;
				$retorno['mensagem'] = 'Sucesso';
				throw new Exception(json_encode($retorno), 1);		
			}catch (Exception $e){
				echo $e->getMessage();
			}
		}
		
		// Funcao utilizada para migrar dados da coluna obs_contrato em contrados para meta_dados apos atualizacao da view detalhes_controtos;
		// update at 2025-07-23 by Luciano Damasceno
	function  migraObservacaoContrato(){
	    echo 'desativado';
	    return;
		$modulo_temporario = $this->load_model( 'ponto/ponto', true );
		$contratos = json_decode( $modulo_temporario->obtemContratosComObs());
		$this->modelo->setTable('meta_dados');

		foreach($contratos as $key => $contrato){
			$meta_valor = json_encode([
				'meta_tipo' => 'outros',
				'meta_classificacao' => 'outros',
				'textarea_observacao' => $contrato->obs_contrato,
				'confirmacao' => 0,
			]);

			$meta_observacao['meta_campo'] 			= 'observacao';
			$meta_observacao['meta_tipo'] 			= 'observacao';
			$meta_observacao['meta_classificacao'] 	= 'detalhes';
			$meta_observacao['meta_valor'] 			= $meta_valor;
			$meta_observacao['meta_origem'] 		= 'contrato';
			$meta_observacao['meta_id_origem'] 		= $contrato->id;
			$meta_observacao['id_owner'] 			= $this->userdata->id;
			$meta_observacao['data_registro'] 		= $this->data_hora_atual->format('Y-m-d');
			$meta_observacao['meta_default'] 		= 0;
			$meta_observacao['alterado_por'] 		= $this->userdata->id;
			$meta_observacao['alterado_em'] 		= $this->data_hora_atual->format('Y-m-d H:i:s');
			$meta_observacao['deleted'] 			= 0;
			$new_id_observacao = $this->modelo->save($meta_observacao, $_POST['meta_id']);
			echo ($new_id_observacao !== false) ? $new_id_observacao .' Ok<br>' : $new_id_observacao .' Com erro<br>';
		}
	}
		
		
	}