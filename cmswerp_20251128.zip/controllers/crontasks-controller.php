<?php
    class CronTasksController extends MainController{
        function __construct( $parametros = null, $do_login = true ){
            $this->setModulo('crontasks');
            $this->setView('crontasks');
            parent::__construct( $parametros, 'crontasks', $do_login );
        }
        
        public function run(){
            $model = new CronTasksModel();
            $tasks = json_decode($model->listarAtivas());
            if($tasks){
                foreach ($tasks as $task) {
                    Logger::log("CRON: {$task->nome} Iniciando execução.");
                    // Se não chegou a hora
                    if (!empty($task->proxima_execucao) 
                        && new DateTime($task->proxima_execucao) > new DateTime()
                    ) {
                        continue;
                    }

                    // Tenta LOCK (evita execuções simultâneas)
                    // if (!$model->setLock($task->id)) {
                    //     continue; // alguém já está executando
                    // }

                    try {
                        $this->executar($task);
                    } catch (Exception $e) {
                        Logger::log("CRON ERRO {$task->nome}: ".$e->getMessage());
                    }
                    
                    // // Libera lock
                    // $model->releaseLock($task->id);
                    // // Recalcular next_run
                    // $proxima = CronScheduler::calcularProximaExecucao($task);
                    // $model->atualizarExecucao(
                    //     $task->id,
                    //     $this->data_hora_atual->format('Y-m-d H:i:s'),
                    //     $proxima->format("Y-m-d H:i:s")
                    // );
                    Logger::log("CRON: {$task->nome} Finalizando execução.");
                }
            }else{
                Logger::log("Nenhuma tarefa CRON ativa encontrada.");
            }
        }

        private function executar($task){
            if(!$task->controlador){
                Logger::log("Controlador: {$task->controlador} não existe");
                return;
            }
            
            if(!$task->metodo){
                Logger::log("Método não existe: {$task->metodo} no controlador: {$task->controlador}");
                return;
            }

            $file = ABSPATH.DS."services".DS."{$task->controlador}-services.php";
            if(!file_exists($file)){
                Logger::log("Arquivo de serviço não encontrado: {$file}");
                return;
            }

            require_once( $file );
            $className = ucfirst($task->controlador).'Services';
            if(!class_exists($className)){
                Logger::log("Classe de serviço não encontrada: {$className}");
                return;
            }
            
            $obj = new $className($this);
            if(!method_exists($obj, $task->metodo)){
                Logger::log("Método não encontrado: {$task->metodo} na classe: {$className}");
                return;
            }
            $obj->{$task->metodo}($this);
        }
    }