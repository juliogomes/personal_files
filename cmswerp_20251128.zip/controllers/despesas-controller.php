<?php
	require_once( ABSPATH.DS."includes/lista_erros_bradesco.php" );
	set_time_limit (3600);
	class DespesasController extends MainController{
		//linha a ser apagada futuramente
		protected $orcamento,
			$fornecedor_model,
			$cl_notificacao,
			$obj_contrato,
			$obj_nf,
			$banco_model,
			$cmsw_model,
			$arquivo_model,
			$class_despesa,
			$objRemessa;
		public
			$objContabancaria,
			$empresas;
		function __construct( $parametros = null, $do_login = true ){
			$this->setModulo('despesas');
			$this->setView('despesas');
			parent::__construct($parametros, $this->nome_modulo, $do_login );
			if( $do_login && !$this->globals['NOLOGIN_EXEC'][ $_SERVER['REQUEST_URI'] ] ){
				$this->cl_permissoes->verificarPermissao( $this->nome_modulo );
			}
			
			$this->objContabancaria = new ClienteContaBancaria($this);
			$this->cl_notificacao	= new Notificacoes($this);
			$this->class_despesa 	= new Despesas($this);
			$this->arquivo_model = $this->load_model('arquivos/arquivos', true);
			$this->obj_contrato  = $this->load_model('contratos/contratos', true);
			$this->orcamento     = $this->load_model('orcamento/orcamento', true);
			$this->fornecedor    = $this->load_model('fornecedores/fornecedores', true);
			$this->obj_nf        = $this->load_model('notas-fiscais/notas-fiscais', true);
			$this->empresas      = json_decode($this->obj_contrato->getEmpresasCM());
		}

		function index(){
			$this->listar();
		}

		function listar(){
			// Inclui e inicia a classe
			require_once("libs/mobiledetect/Mobile_Detect.php");
			$detect             = new Mobile_Detect;
			$vencimento_de      = null;		
			$vencimento_ate     = null;
			$status             = null;
			$status_autorizacao = null;
			$meio_pagamento     =  null;
			if(isset($_POST['meio_pagamento'])){
				$meio_pagamento = $_POST['meio_pagamento'];
			}
			
			if(isset($_POST['dt_ini']) && !empty($_POST['dt_ini'])){
				$dt_ini = new DateTime(convertDate($_POST['dt_ini']));
			}else{
				$dt_ini = new DateTime($this->data_hora_atual->format('Y-m-d'));
				//  $dt_ini = new DateTime('2020-01-01');
			}

			if(isset($_POST['dt_fim']) && !empty($_POST['dt_fim'])){
				$dt_fim = new DateTime(convertDate($_POST['dt_fim']));
			}else{
				$dt_fim = new DateTime($this->data_hora_atual->format('Y-m-d'));
				$dt_fim->add(new DateInterval('P7D'));
			}
			
			if(isset($_POST['tipo_data']) && !empty($_POST['tipo_data']) ){
				$tipo_data = $_POST['tipo_data'];
			}else{
				$tipo_data = 'vencimento';
			}
			
			if( $detect->isMobile() ){
				
				$is_mobile    = 'sim';
				$fornecedores = json_decode($this->fornecedor->getFornecedores());
				$contas       = json_decode($this->orcamento->getConta());
				$subcontas    = json_decode($this->orcamento->getSubConta());
				$centro_custo = json_decode($this->orcamento->getCentroCusto());
				$grupos       = json_decode($this->orcamento->getGrupo());
				$despesas     = json_decode($this->modelo->getDespesas(null, $dt_ini->format('Y-m-d'), $dt_fim->format('Y-m-d'), null, null, 'pendente'));
				
				if(isset($_POST['indice']) && $_POST['indice'] > count($despesas)){
					$_POST['indice'] = 0;
				}

				if($despesas){
					if(isset($_POST['indice'])){
						$atual = $_POST['indice'];
					}else{
						$atual = key($despesas);
					}
					
					if((count($despesas)-1) == $atual){
						$atual = 0;
					}elseif(isset($_POST['action']) && $_POST['action'] == 'anterior'){
						if($atual > 0){
							$atual--;
						}
					}else{
						$atual++;
					}
					$records[0]   = $despesas[$atual];
				}
				require_once ABSPATH . '/views/'.$this->nome_view.'/despesas-mobile-view.php';
			}else{
				$is_mobile = 'nao';
				if(isset($_POST['status_autorizacao']) && !empty($_POST['status_autorizacao'])){
					$status_autorizacao = $_POST['status_autorizacao'];
				}elseif(isset($this->parametros[3]) && !empty($this->parametros[3])){
					$status_autorizacao = $this->parametros[3];
				}

				if(isset($_POST['status']) && !empty($_POST['status'])){
					$status = $_POST['status'];
				}

				if(isset($this->parametros[0]) && $this->parametros[0] == 'filter'){
					$vencimento_de      = convertDate($this->parametros[2]);
					$vencimento_ate     = convertDate($this->parametros[2]);
				}elseif(isset($_REQUEST['vencimento_de']) && isset($_REQUEST['vencimento_ate'])){
					$vencimento_de  = $_REQUEST['vencimento_de'];
					$vencimento_ate = $_REQUEST['vencimento_ate'];
				}

				if( $vencimento_de && $vencimento_ate ){
					$dt_ini = convertDate($vencimento_de);
					$dt_fim = convertDate($vencimento_ate);
					$records = json_decode($this->modelo->getDespesas(null, $dt_ini, $dt_fim, null, $status, $status_autorizacao, null, $meio_pagamento, $tipo_data));
				}else{
					$vencimento_de  = $dt_ini->format('d/m/Y');
					$vencimento_ate = $dt_fim->format('d/m/Y');
					$records = json_decode($this->modelo->getDespesas(null, $dt_ini->format('Y-m-d'), $dt_fim->format('Y-m-d'), null, null, $status_autorizacao, null, $meio_pagamento, $tipo_data));
				}
				require_once ABSPATH . '/views/'.$this->nome_view.'/despesas-view.php';
			}		
		}

		function listarSaldo(){
			$vencimento_de      = null;		
			$vencimento_ate     = null;
			$status_autorizacao = null;
			$meio_pagamento     =  null;
			if(isset($_POST['meio_pagamento'])){
				$meio_pagamento = $_POST['meio_pagamento'];
			}
			
			if(isset($_POST['dt_ini']) && !empty($_POST['dt_ini'])){
				$dt_ini = new DateTime(convertDate($_POST['dt_ini']));
			}if(isset($this->parametros[0]) && !empty($this->parametros[0])){
				$dt_ini = new DateTime($this->parametros[0]);
			}else{
				$dt_ini = new DateTime($this->data_hora_atual->format('Y-m-d'));
				//  $dt_ini = new DateTime('2020-01-01');
			}

			if(isset($_POST['dt_fim']) && !empty($_POST['dt_fim'])){
				$dt_fim = new DateTime(convertDate($_POST['dt_fim']));
			}elseif(isset($this->parametros[1]) && !empty($this->parametros[1])){
				$dt_fim = new DateTime($this->parametros[1]);
			}else{
				$dt_fim = new DateTime($this->data_hora_atual->format('Y-m-d'));
				$dt_fim->add(new DateInterval('P7D'));
			}
			
			switch ($this->parametros[2]) {
				case 'aberto':
					$status = 'aberto';
				break;
				case 'pago':
					$status = 'pago';
				break;
				default:
					$status = null;
				break;
			}

			switch ($this->parametros[3]) {
				case 'aprovado':
					$status_autorizacao = 'aprovado';
				break;
				case 'reprovado':
					$status_autorizacao = 'reprovado';
				break;
				case 'pendente':
					$status_autorizacao = 'pendente';
				break;
				default:
					$status_autorizacao = null;
				break;
			}

			$records = json_decode($this->modelo->getDespesas(null, $dt_ini->format('Y-m-d'), $dt_fim->format('Y-m-d'), null, $status, $status_autorizacao));
			require_once ABSPATH . '/views/'.$this->nome_view.'/despesas-view.php';
		}

		function detalhe(){
			// Inclui e inicia a classe
			$bancos = json_decode($this->objContabancaria->getBanco());
			require_once("libs/mobiledetect/Mobile_Detect.php");
			$detect = new Mobile_Detect;
			
			
			if(isset($_POST['data_vencimento']) && !empty($_POST['data_vencimento'])){
				$data_vencimento = new DateTime(convertDate($_POST['data_vencimento']));
			}else{
				$data_vencimento = new DateTime();
				$data_vencimento->add(new DateInterval('P5D'));
			}

			if($this->parametros[1] != 0 && is_numeric($this->parametros[1] )){
				$records  = json_decode($this->modelo->getDespesas($this->parametros[1]));
			}

			if(isset($records[0]->ano_mes) && !empty($records[0]->ano_mes)){
				$ano_mes = explode('-', $records[0]->ano_mes);
				$ano_mes = $ano_mes[1].'/'.$ano_mes[0];
			}else{
				$ano_mes = null;
			}

			$fornecedores = json_decode($this->fornecedor->getFornecedores());
			$contas       = json_decode($this->orcamento->getConta());
			$subcontas    = json_decode($this->orcamento->getSubConta());
			$centro_custo = json_decode($this->orcamento->getCentroCusto());
			$grupos       = json_decode($this->orcamento->getGrupo());
			
			if ($detect->isMobile()) {
				require_once ABSPATH . '/views/'.$this->nome_view.'/despesas-detalhe-mobile-view.php';
			}else{
				require_once ABSPATH . '/views/'.$this->nome_view.'/despesas-detalhe-view.php';
			}
		}

		function reprocessaDespesas(){
			$despesas = json_decode($this->modelo->getDespesas($this->parametros[1]));
			foreach ($despesas as $key => $value) {
				if($value->status_autorizacao != 'automatico'){
					$obj_dt_vencimento    = new DateTime($value->data_vencimento);
					$lancamentos_despesas = json_decode($this->modelo->checkTotalLancamentos(
						$value->id_centro_custo,
						$value->id_grupo,
						$value->id_conta,
						$value->id_subconta,
						$obj_dt_vencimento->format('Y'),
						$obj_dt_vencimento->format('m')
					));
					$lancamentos_orcamento = json_decode($this->orcamento->checkTotalOrcamento(
						$value->id_centro_custo,
						$value->id_grupo,
						$value->id_conta,
						$value->id_subconta,
						$obj_dt_vencimento->format('Y'),
						$obj_dt_vencimento->format('m')
					));
					$total_despesas = (float)$lancamentos_despesas[0]->total_lancamentos;
					$total_orcamento = (float)$lancamentos_orcamento[0]->total_orcamento;
					if($total_orcamento >= $total_despesas){
						$param['status_autorizacao'] = 'automatico';
						$this->modelo->save($param, $value->id_despesa);
					}
				}
			}
		}	
		
		function autorizar(){
			try{
			    /*
			    error_reporting(E_ALL);
	            ini_set("display_errors", 1);
				*/
				$usuario_aprovacao = null;
				$retorno['codigo'] = 0;
				if(!isset($_POST['despesas']) || count($_POST['despesas']) < 1){
					$retorno['codigo']      = '1';
					$retorno['input']       = $_POST;
					$retorno['output']      = null;
					$retorno['mensagem']    = "Despesas não informadas";
					throw new Exception(json_encode($retorno));	
				}
	
				if($_POST['acao'] == 'aprovar'){
					$status_autorizacao = 'aprovado';
				}else{
					$status_autorizacao = 'reprovado';
				}
	
				if(isset($_POST['senha_aprovacao']) && !empty($_POST['senha_aprovacao'])){
					$param_aprovacao['senha_autorizacao']  = md5($_POST['senha_aprovacao']);
				}else{
					$param_aprovacao['senha_autorizacao']  = null;
				}
	
				if(
					(isset( $param_aprovacao['senha_autorizacao'] ) && !empty( $param_aprovacao['senha_autorizacao'] )) ||
					(isset( $_POST['email_aprovacao'] ) && !empty( $_POST['email_aprovacao'] ))
				){
					$email       = trim($_POST['email_aprovacao']);
					$email_array = explode('@', $email);
					
					if(isset($email_array[1]) && !empty($email_array[1])){
						$email = trim($_POST['email_aprovacao']);
					}else{
						$email = trim($email_array[0]).DOMINIO_EMAIL;
					}
	
					if(!isset($_POST['email_aprovacao']) || empty($_POST['email_aprovacao'])){
						$retorno['codigo']      = 1;
						$retorno['status']      = 'warning';
						$retorno['input']       = $_POST;
						$retorno['output']      = null;
						$retorno['mensagem']    = "Informe a o email";
						throw new Exception(json_encode($retorno));
					}
	
					if(!filter_var($email, FILTER_SANITIZE_EMAIL)){
						$retorno['codigo']      = 1;
						$retorno['status']      = 'warning';
						$retorno['input']       = $_POST;
						$retorno['output']      = null;
						$retorno['mensagem']    = "Email informado invalido";
						throw new Exception(json_encode($retorno));
					}
	
					if(!isset($_POST['senha_aprovacao']) || empty($_POST['senha_aprovacao'])){
						$retorno['codigo']      = 1;
						$retorno['status']      = 'warning';
						$retorno['input']       = $_POST;
						$retorno['output']      = null;
						$retorno['mensagem']    = "Informe a senha";
						throw new Exception(json_encode($retorno));
					}
					$usuario = json_decode($this->user_model->getUserByEmail( $email ) );
					if( $usuario ){
						if( $usuario->login_ldap ){
							$ldap_user = explode( '@', $usuario->email);
							$ldap = new Ldap(); // instanciando a classe ldap
							$ldap_login = $ldap->login( strtolower( $ldap_user[0] ), $_POST['senha_aprovacao'] );
							if( !$ldap_login ){
								$retorno['codigo']      = 1;
								$retorno['status']      = 'warning';
								$retorno['mensagem']    = $ldap->error;
								$this->logSistema->saveLoginAction(strtolower($ldap_user[0]), encryptData($_POST['senha_aprovacao']), 'erro', $ldap->error, 'despesas');
								throw new Exception(json_encode($retorno));
							} else {
							    $this->logSistema->saveLoginAction(strtolower($ldap_user[0]), encryptData($_POST['senha_aprovacao']), 'ok', null, 'despesas');
						    }
						}else{
							if( $usuario->senha != md5( $_POST['senha_aprovacao'] ) ) {
								$retorno['codigo']      = 1;
								$retorno['status']      = 'warning';
								$retorno['input']       = $_POST;
								$retorno['output']      = null;
								$retorno['mensagem']    = "Senha invalida";
								$this->logSistema->saveLoginAction(strtolower($usuario->email), encryptData($_POST['senha_aprovacao']), 'erro', $retorno['mensagem'], 'despesas');
								throw new Exception(json_encode($retorno));
							} else {
							    $this->logSistema->saveLoginAction(strtolower($usuario->email), encryptData($_POST['senha_aprovacao']), 'ok', null, 'despesas');
						    }
						}
					}else{
						$retorno['codigo']      = 1;
    					$retorno['status']      = 'warning';
    					$retorno['input']       = $_POST;
    					$retorno['output']      = null;
    					$retorno['mensagem']    = "Usuario não encontrado";
    					$this->logSistema->saveLoginAction(strtolower($_POST['email_aprovacao']), encryptData($_POST['senha_aprovacao']), 'erro', $retorno['mensagem'], 'despesas');
    					throw new Exception(json_encode($retorno));
					}
					
					$permissao_extras = $this->cl_permissoes->checkPermissoesExtras('despesas', $usuario->id);
					if($permissao_extras){
						$usuario_aprovacao 				       = $usuario->id;
						$param_aprovacao['autorizado_por']     = $usuario_aprovacao;
						$param_aprovacao['status_autorizacao'] = 'aprovado';
						$param_aprovacao['senha_autorizacao']  = md5($_POST['senha_aprovacao']);
					}else{
						$retorno['codigo']     = 1;
						$retorno['status']     = 'danger';
						$retorno['input']      = $_POST['email_aprovacao'];
						$retorno['output']     = $permissao_extras;
						$retorno['mensagem']   = 'Usuario não autorizado';
						throw new Exception(json_encode($retorno));
					}
				}
				
				$despesas = json_decode($this->modelo->getDespesas($_POST['despesas']));
				if(!$despesas){
					$retorno['codigo']   = '1';
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = " Despesas não encontradas ";
					throw new Exception(json_encode($retorno));
				}
	
				if(!$usuario_aprovacao){
					$permissao_nivel = $this->cl_permissoes->checkPermissaoByUsuario($_SESSION['cmswerp']['userdata']->id, 'despesas', 'listar');
					if($permissao_nivel < 4){
						$retorno['codigo']   = 'auth_required';
						$retorno['input']    = $_POST;
						$retorno['output']   = null;
						$retorno['mensagem'] = " Necessario login com acesso a está ação! ";
						throw new Exception(json_encode($retorno));
					}
				}
	
				foreach($despesas as $key => $value){
					$destinatario = null;
					$mensagem     = null;	
					$data_vencimento = new DateTime($value->data_vencimento);
					$ano = $data_vencimento->format('Y');
					$mes = null;
					
					if(!isset($value->id_cm) || empty($value->id_cm)){
						$retorno["codigo"]   = 1;
						$retorno["input"]    = $value;
						$retorno["output"]   = null;
						$retorno["mensagem"] = 'Informe a empresa CM para a despesa';
						throw new Exception(json_encode($retorno), 1);
					}
	
					if(!isset($value->id_fornecedor) || empty($value->id_fornecedor)){
						$retorno["codigo"]   = 1;
						$retorno["input"]    = $value;
						$retorno["output"]   = null;
						$retorno["mensagem"] = 'Informe o fornecedor';
						throw new Exception(json_encode($retorno), 1);
					}
	
					if(!isset($value->id_centro_custo) || empty($value->id_centro_custo)){
						$retorno["codigo"]   = 1;
						$retorno["input"]    = $value;
						$retorno["output"]   = null;
						$retorno["mensagem"] = 'Informe o centro de custo';
						throw new Exception(json_encode($retorno), 1);
					}
	
					if(!isset($value->id_grupo) || empty($value->id_grupo)){
						$retorno["codigo"]   = 1;
						$retorno["input"]    = $value;
						$retorno["output"]   = null;
						$retorno["mensagem"] = 'Informe o grupo do centro de custo';
						throw new Exception(json_encode($retorno), 1);
					}
	
					if(!isset($value->id_conta) || empty($value->id_conta)){
						$retorno["codigo"]   = 1;
						$retorno["input"]    = $value;
						$retorno["output"]   = null;
						$retorno["mensagem"] = 'Informe a conta do centro de custo';
						throw new Exception(json_encode($retorno), 1);
					}
	
					if(!isset($value->id_subconta) || empty($value->id_subconta)){
						$retorno["codigo"]   = 1;
						$retorno["input"]    = $value;
						$retorno["output"]   = null;
						$retorno["mensagem"] = 'Informe a subconta para o centro de custo';
						throw new Exception(json_encode($retorno), 1);
					}
					
					// quanto saldo estiver indisponivel pede autorização
					if(!$usuario_aprovacao && $_POST['acao'] == 'aprovar'){
						$config_orcamento = json_decode($this->config_list[0]->controle_orcamento);
						switch ($config_orcamento->nivel_controle) {
							case 'centro_custo':
								$nivel_controle = 1;
							break;
							case 'grupo':
								$nivel_controle = 2;
							break;
							case 'conta':
								$nivel_controle = 3;
							break;
							case 'subconta':
								$nivel_controle = 4;
							break;
							default:
								$retorno["codigo"]   = 1;
								$retorno["input"]    = $config_orcamento;
								$retorno["output"]   = null;
								$retorno["mensagem"] = 'Erro ao carregar informações do orçamento';
								throw new Exception(json_encode($retorno), 1);
							break;
						}
						$saldo = $this->getSaldo($value, $data_vencimento, $config_orcamento->nivel_controle, $config_orcamento->periodo_controle, $config_orcamento->tipo_controle);
						if($nivel_controle > 0){
							if(isset($saldo['total_centro_custo']) && $saldo['total_centro_custo'] <= 0){
								$retorno['codigo']     = 'auth_required';
								$retorno['input']      = $_POST;
								$retorno['output'][]   = $saldo;
								$retorno['mensagem'][] = 'Saldo indisponivel para o centro de custo '.strtoupper($saldo['nome_centro_custo']).' saldo atual '.$saldo['saldo_centro_custo'];
								throw new Exception(json_encode($retorno), 1);
							}elseif(!isset($saldo['total_centro_custo'])){
								$retorno['codigo']     = 'auth_required';
								$retorno['input']      = $_POST;
								$retorno['output'][]   = $saldo;
								$retorno['mensagem'][] = 'Orçamento não disponivel para o periodo - centro de custo '.strtoupper($saldo['nome_centro_custo']);
								throw new Exception(json_encode($retorno), 1);
							}
						}
	
						if($nivel_controle >= 2){
							if(isset($saldo['total_grupo']) && $saldo['total_grupo'] <= 0){
								$retorno['codigo']     = 'auth_required';
								$retorno['input']      = $_POST;
								$retorno['output'][]   = $saldo;
								$retorno['mensagem'][] = 'Saldo indisponivel para o grupo '.strtoupper($saldo['nome_grupo']).' saldo atual '.$saldo['saldo_grupo'];
								throw new Exception(json_encode($retorno), 1);
							}elseif(!isset($saldo['total_grupo'])){
								$retorno['codigo']     = 'auth_required';
								$retorno['input']      = $_POST;
								$retorno['output'][]   = $saldo;
								$retorno['mensagem'][] = 'Orçamento não disponivel para o periodo - grupo '.strtoupper($saldo['nome_grupo']);
								throw new Exception(json_encode($retorno), 1);
							}
						}
	
						if($nivel_controle >= 3){
							if(isset($saldo['total_conta']) && $saldo['total_conta'] <= 0){
								$retorno['codigo']     = 'auth_required';
								$retorno['input']      = $_POST;
								$retorno['output'][]   = $saldo;
								$retorno['mensagem'][] = 'Saldo indisponivel para a conta '.strtoupper($saldo['nome_conta']).' saldo atual '.$saldo['saldo_conta'];
								throw new Exception(json_encode($retorno), 1);
							}elseif(!isset($saldo['total_conta'])){
								$retorno['codigo']     = 'auth_required';
								$retorno['input']      = $_POST;
								$retorno['output'][]   = $saldo;
								$retorno['mensagem'][] = 'Orçamento não disponivel para o periodo - conta '.strtoupper($saldo['nome_conta']);
								throw new Exception(json_encode($retorno), 1);
							}
						}
						
						if($nivel_controle >= 4){
							if(isset($saldo['total_subconta']) && $saldo['total_subconta'] > 0 && $nivel_controle >= 4){
								$retorno['codigo']     = 'auth_required';
								$retorno['input']      = $_POST;
								$retorno['output'][]   = $saldo;
								$retorno['mensagem'][] = 'Saldo indisponivel para a subconta '.strtoupper($saldo['nome_subconta']).' saldo atual '.$saldo['saldo_subconta'];
								throw new Exception(json_encode($retorno), 1);
							}elseif(!isset($saldo['total_subconta'])){
								$retorno['codigo']     = 'auth_required';
								$retorno['input']      = $_POST;
								$retorno['output'][]   = $saldo;
								$retorno['mensagem'][] = 'Orçamento não disponivel para o periodo - subconta '.strtoupper($saldo['nome_subconta']);
								throw new Exception(json_encode($retorno), 1);
							}
						}
					}
					
					if($usuario_aprovacao && is_numeric($usuario_aprovacao)){
						$param_aprovacao['autorizado_por'] = $usuario_aprovacao;
						$nome_aprovador = $usuario->nome;
					}else{
						$param_aprovacao['autorizado_por']    = $_SESSION['cmswerp']['userdata']->id;
						$param_aprovacao['senha_autorizacao'] = $_SESSION['cmswerp']['userdata']->senha;
						$nome_aprovador = $_SESSION['cmswerp']['userdata']->nome;
					}
					
					$param_aprovacao['status_autorizacao'] = $status_autorizacao;
					$param_aprovacao['flag_aprovacao']     = 'manual';
					$param_aprovacao['autorizado_em']      = $this->data_hora_atual->format('Y-m-d H:i:s');
	
					$is_save = $this->modelo->save($param_aprovacao, $value->id_despesa);
					if($is_save){
						if($value->status_autorizacao != $status_autorizacao){
							if(!$usuario_aprovacao){
								$mensagem  = " Despesa $status_autorizacao com sucesso, segue os dados \n ID: $value->id_despesa \n Empresa Pagadora: ".$value->nome_cm." \n Fornecedor: $value->nome_fornecedor \n Vencimento: ".convertDate($value->data_vencimento)." \n $status_autorizacao por: $nome_aprovador \n $status_autorizacao em: ".$this->data_hora_atual->format('d/m/Y H:i:s')." \n ";
							}else{
								$mensagem  = " Despesa $status_autorizacao com sucesso, segue os dados \n ID: $value->id_despesa \n Empresa Pagadora: ".$value->nome_cm." \n Fornecedor: $value->nome_fornecedor \n Vencimento: ".convertDate($value->data_vencimento)." \n Solicitado por: ".$_SESSION['cmswerp']['userdata']->nome." \n $status_autorizacao por: $nome_aprovador \n $status_autorizacao em: ".$this->data_hora_atual->format('d/m/Y H:i:s')." \n ";
							}
								
							$parametros['tipo_destinatario'] = 'webhook';
							if('producao' == TIPO_AMBIENTE){
								$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/06b48f3c-0684-46b4-ad04-63494a706bc7@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9cb6bfbfed3d4b1e9c34f76848ba6e61/c8c7ff53-e294-4a3a-bcad-c9f04857e469';
							}else{
								$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9f2e2cc655bf4e76bfdb0531dd3a83d7/c328c206-070a-4beb-bbed-da82e018abec';
							}
							$parametros['mensagem'] = $mensagem;
							$send = $this->cl_notificacao->enviar('teams', $parametros);
						}
						$retorno['codigo']     = 0;
						$retorno['input']      = $param_aprovacao;
						$retorno['output'][]   = array('id_despesa' => $is_save);
						$retorno['mensagem'][] = 'Despesa aprovada com sucesso';
					}else{
						$retorno['codigo']     = 1;
						$retorno['id_despesa'] = $value->id_despesa;
						$retorno['input']      = $param_aprovacao;
						$retorno['output']     = $saldo;
						$retorno['mensagem']   = 'Erro ao aprovar despesa no sistema';
					}
				}
				throw new Exception(json_encode($retorno), 1);
			}catch(Exception $e){
				echo $e->getMessage();
			}		
		}

		function pagarDespesa(){
			try{
				if( $_POST['auth'] > 0 ){
					$email       = trim($_POST['email_aprovacao']);
					$email_array = explode('@', $email);
					if(isset($email_array[1]) && !empty($email_array[1])){
						$email = trim($_POST['email_aprovacao']);
					}else{
						$email = trim($email_array[0]).DOMINIO_EMAIL;
					}

					if(!isset($_POST['email_aprovacao']) || empty($_POST['email_aprovacao'])){
						$retorno['codigo']      = 1;
						$retorno['input']       = $_POST;
						$retorno['output']      = null;
						$retorno['mensagem']    = "Informe a o email";
						throw new Exception(json_encode($retorno));
					}

					if(!filter_var($email, FILTER_SANITIZE_EMAIL)){
						$retorno['codigo']      = 1;
						$retorno['input']       = $_POST;
						$retorno['output']      = null;
						$retorno['mensagem']    = "Email informado invalido";
						throw new Exception(json_encode($retorno));
					}

					if(!isset($_POST['senha_aprovacao']) || empty($_POST['senha_aprovacao'])){
						$retorno['codigo']      = 1;
						$retorno['input']       = $_POST;
						$retorno['output']      = null;
						$retorno['mensagem']    = "Informe a senha";
						throw new Exception(json_encode($retorno));
					}

					$usuario = json_decode($this->user_model->getUserByEmail($email));
					$config_orcamento = json_decode($this->config_list[0]->controle_orcamento);
					
					if(!in_array($usuario->id, $config_orcamento->aprovadores)){
						$retorno['codigo']      = 1;
						$retorno['input']       = $_POST;
						$retorno['output']      = null;
						$retorno['mensagem']    = "Usuario informado não tem previlegios";
						throw new Exception(json_encode($retorno));
					}

					if(!$usuario){
						$retorno['codigo']      = 1;
						$retorno['input']       = $_POST;
						$retorno['output']      = null;
						$retorno['mensagem']    = "Usuario não encontrado";
						throw new Exception(json_encode($retorno));
					}
					
					if($usuario->senha != md5($_POST['senha_aprovacao'])){
						$retorno['codigo']      = 1;
						$retorno['status']      = 'warning';
						$retorno['input']       = $_POST;
						$retorno['output']      = null;
						$retorno['mensagem']    = "Senha invalida";
						throw new Exception(json_encode($retorno));
					}
					$usuario_aprovacao = $usuario->id;
				}
				
				if( !isset( $_POST['despesas'] ) || empty( $_POST['despesas'] ) ){
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Informe as despesas';
					throw new Exception( json_encode( $retorno ), 1);
				}

				$despesas = json_decode( $this->modelo->getDespesas( $_POST['despesas'] ) );
				if(!$despesas){
					$retorno['codigo']   = '1';
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = " Despesas não encontradas ";
					throw new Exception(json_encode($retorno));
				}

				foreach ($despesas as $key => $value){
					if($this->cl_permissoes->getNivelAcesso() < 3 ){
						$retorno['codigo']      = 1;
						$retorno['status']      = 'error';
						$retorno['input']       = $value;
						$retorno['output'][]    = null;
						$retorno['mensagem']    = "Usuario não tem permissão para executar essa ação.";
						throw new Exception(json_encode($retorno));
					}

					if('aprovado' != $value->status_autorizacao ){
						if(!$usuario_aprovacao ){
							$retorno['codigo']      = 1;
							$retorno['status']      = 'error';
							$retorno['input']       = $value;
							$retorno['output'][]    = null;
							$retorno['mensagem']    = "A despesa numero $value->id não está aprovada";
							throw new Exception(json_encode($retorno));
						}
					}else{
						if($this->cl_permissoes->getNivelAcesso() < 4 && !$usuario_aprovacao){
							$retorno['codigo']      = 1;
							$retorno['status']      = 'error';
							$retorno['input']       = $value;
							$retorno['output']      = null;
							$retorno['mensagem']    = "Necessario autenticação com previlegios para baixar";
							throw new Exception(json_encode($retorno));
						}
					}

					$param_aprovacao['status']             = 'pago';
					$param_aprovacao['flag_aprovacao']     = 'manual';
					$param_aprovacao['autorizado_em']      = $this->data_hora_atual->format('Y-m-d H:i:s');
					$param_aprovacao['data_pagamento']     = convertDate($_POST['data_acao']);
					$param_aprovacao['requer_autorizacao'] = 0;
					$param_aprovacao['alterado_por']       = $this->data_hora_atual->format('Y-m-d H:i:s');
					$param_aprovacao['alterado_em']        = $_SESSION['cmswerp']['userdata']->id;
		
					if($usuario){
						$nome_aprovador = $usuario->nome;
					}else{
						$nome_aprovador = $_SESSION['cmswerp']['userdata']->nome;
					}
					$is_save = $this->modelo->save($param_aprovacao, $value->id_despesa);
					if($is_save){
						if('pago' == $param_aprovacao['status'] ){
							$parametros['tipo_destinatario'] = 'webhook';
							if('producao' == TIPO_AMBIENTE){
								$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/06b48f3c-0684-46b4-ad04-63494a706bc7@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9cb6bfbfed3d4b1e9c34f76848ba6e61/c8c7ff53-e294-4a3a-bcad-c9f04857e469';
							}else{
								$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9f2e2cc655bf4e76bfdb0531dd3a83d7/c328c206-070a-4beb-bbed-da82e018abec';
							}
							$parametros['mensagem'] = "Despesa baixada com sucesso, segue os dados \n ID: $value->id_despesa \n Fornecedor: $value->nome_fornecedor \n Valor:      ".funcValor($value->valor, 'C')."\n Vencimento: ".convertDate($value->data_vencimento)." \n Status por: ".$param_aprovacao['status']." \n Baixado por: $nome_aprovador \n Data de baixa: ".$_POST['data_acao']." \n Executado em: ".$this->data_hora_atual->format('d/m/Y H:i:s')." \n ";
							$send = $this->cl_notificacao->enviar('teams', $parametros);
						}
					}else{
						$retorno['codigo']     = 1;
						$retorno['status']     = 'error';
						$retorno['input']      = $_POST;
						$retorno['output']     = $value;
						$retorno['mensagem']   = 'Erro ao atualizar despesa';
						throw new Exception(json_encode($retorno));
					}
				}
				
				$retorno['codigo']     = 0;
				$retorno['status']     = 'success';
				$retorno['input']      = $_POST;
				$retorno['output']     = $value;
				$retorno['id_despesa'] = $value->id_despesa;
				$retorno['mensagem']   = 'Despesa paga com sucesso';
				throw new Exception(json_encode($retorno));
			}catch (Exception $e){
				echo $e->getMessage();
			}
		}

		function permitirRemessa(){
			try{
				if(count($_POST['despesas']) > 0){
					foreach($_POST['despesas'] as $key => $value) {
						if(is_numeric($value)){
							$param['status_remessa'] = 'pendente';
							$is_save = $this->modelo->save($param, $value);
							if(!$is_save){
								$retorno['codigo']   = '1';
								$retorno['input']    = $_POST;
								$retorno['output']   = $this->modelo->db;
								$retorno['mensagem'] = 'Erro ao autorizar despesa numero: '.$is_save.' para remessa';
								throw new Exception(json_encode($retorno));
							}
						}
					}
					$retorno['codigo']   = '0';
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Remessas autorizadas com sucesso';
					throw new Exception(json_encode($retorno));
				}else{
					$retorno['codigo']   = '1';
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Nenhuma despesa selecionada';
					throw new Exception(json_encode($retorno));
				}
			}catch(Exception $e){
				echo $e->getMessage();
			}		
		}	

		function autorizarDetalhe(){
			if(isset($this->parametros[1]) && is_numeric($this->parametros[1])){
				$records  = json_decode($this->modelo->getDespesas($this->parametros[1]));
				if($records){
					$dt_vencimento    = new DateTime($records[0]->data_vencimento);
					$param['ano_mes'] = $dt_vencimento->format('Y-m');
					$param["agrupar"] = 'centro_custo';
					//retorna o valor para o centro de custo referente a conta para o mes de vencimento
					$saldo_centro_custo = json_decode($this->orcamento->getSaldoCentroCusto($records[0]->id_centro_custo, $dt_vencimento));
					//retorna o valor para o grupo referente a conta para o mes de vencimento
					$saldo_grupo = json_decode($this->orcamento->getSaldoGrupo($records[0]->id_grupo, $records[0]->id_centro_custo, $dt_vencimento));
					//retorna o valor para a conta referente a conta para o mes de vencimento
					$saldo_conta = json_decode($this->orcamento->getSaldoConta($records[0]->id_conta, $records[0]->id_centro_custo, $records[0]->id_grupo, $dt_vencimento));
					//retorna o valor para a subconta referente a conta para o mes de vencimento
					$saldo_subconta = json_decode($this->orcamento->getSaldoSubConta($records[0]->id_subconta, $records[0]->id_centro_custo, $records[0]->id_grupo, $records[0]->id_conta, $dt_vencimento));
					// retorna o valor total de contas para o mes de vencimento da respectiva despesa e centro de custo
					$param['filtro_centro_custo'] = $records[0]->id_centro_custo;
					$despesa_centro_custo = json_decode($this->modelo->getDespesasParametro($param, $view));
					// retorna o valor total de contas para o mes de vencimento da respectiva despesa, centro de custo, grupo
					$param['filtro_grupo'] = $records[0]->id_grupo;
					$despesa_grupo = json_decode($this->modelo->getDespesasParametro($param, $view));
					// retorna o valor total de contas para o mes de vencimento da respectiva despesa, centro de custo, grupo, conta
					$param['filtro_conta'] = $records[0]->id_conta;
					$despesa_conta = json_decode($this->modelo->getDespesasParametro($param, $view));
					// retorna o valor total de contas para o mes de vencimento da respectiva despesa, centro de custo, grupo, conta, subconta
					$param['filtro_subconta'] = $records[0]->id_subconta;
					$despesa_subconta = json_decode($this->modelo->getDespesasParametro($param, $view));
				}else{
					$saldo_centro_custo   = '0,00';
					$saldo_grupo          = '0,00';
					$saldo_conta          = '0,00';
					$saldo_subconta       = '0,00';
					$despesa_centro_custo = '0,00';
					$despesa_grupo        = '0,00';
					$despesa_conta        = '0,00';
					$despesa_subconta     = '0,00';
				}
			}
			require_once ABSPATH . '/views/'.$this->nome_view.'/autorizar-despesas-detalhe-view.php';
		}

		function save(){
			try {
				$_POST['valor'] = removeCaracteres(trim($_POST['valor']),'moeda2');
				$permission_save = true;
				
				if(!isset($_POST['id_cm']) || empty($_POST['id_cm'])){
					$retorno["codigo"]   = 1;
					$retorno["input"]    = $_POST;				
					$retorno["output"]   = null;
					$retorno["mensagem"] = 'Informe a empresa CM para a despesa';
					throw new Exception(json_encode($retorno), 1);
				}

				if(!isset($_POST['id_fornecedor']) || empty($_POST['id_fornecedor'])){
					$retorno["codigo"]   = 1;
					$retorno["input"]    = $_POST;
					$retorno["output"]   = null;
					$retorno["mensagem"] = 'Informe o fornecedor';
					throw new Exception(json_encode($retorno), 1);
				}

				if(!isset($_POST['id_centro_custo']) || empty($_POST['id_centro_custo'])){
					$retorno["codigo"]   = 1;
					$retorno["input"]    = $_POST;
					$retorno["output"]   = null;
					$retorno["mensagem"] = 'Informe o centro de custo';
					throw new Exception(json_encode($retorno), 1);
				}

				if(!isset($_POST['id_grupo']) || empty($_POST['id_grupo'])){
					$retorno["codigo"]   = 1;
					$retorno["input"]    = $_POST;	
					$retorno["output"]   = null;
					$retorno["mensagem"] = 'Informe o grupo do centro de custo';
					throw new Exception(json_encode($retorno), 1);
				}

				if(!isset($_POST['id_conta']) || empty($_POST['id_conta'])){
					$retorno["codigo"]   = 1;
					$retorno["input"]    = $_POST;
					$retorno["output"]   = null;
					$retorno["mensagem"] = 'Informe a conta do centro de custo';
					throw new Exception(json_encode($retorno), 1);
				}

				if(!isset($_POST['id_subconta']) || empty($_POST['id_subconta'])){
					$retorno["codigo"]   = 1;
					$retorno["input"]    = $_POST;
					$retorno["output"]   = null;
					$retorno["mensagem"] = 'Informe a subconta para o centro de custo';
					throw new Exception(json_encode($retorno), 1);
				}
				
				switch ($_POST['meio_pagamento']){
					case 'boleto_cc':
						$codigo_barras = removeCaracteres(trim($_POST['codigo_barra']), 'all');
						$tam_cb = strlen($codigo_barras);
						if($_POST['tipo_despesa'] == 'tributo'){
							if($tam_cb != 48){
								$retorno['codigo']   = 1;
								$retorno['tipo']     = 'error';
								$retorno['input']    = $_POST;
								$retorno['output']   = $codigo_barras;
								$retorno['mensagem'] = 'Codigo de barras deve ter 48 caracteres para o tipo tributo';
								throw new Exception(json_encode($retorno), 1);
							}
						}else{
							if($_POST['tipo_cobranca'] == 'concessionaria'){
								if($tam_cb != 48){
									$retorno['codigo']   = 1;
									$retorno['tipo']     = 'error';
									$retorno['input']    = $_POST;
									$retorno['output']   = $codigo_barras;
									$retorno['mensagem'] = 'Codigo de barras deve ter 48 caracteres para o tipo concessionaria';
									throw new Exception(json_encode($retorno), 1);
								}
							}else{
								if($tam_cb != 47){
									$retorno['codigo']   = 1;
									$retorno['tipo']     = 'error';
									$retorno['input']    = $_POST;
									$retorno['output']   = $codigo_barras;
									$retorno['mensagem'] = 'Codigo de barras parece estar inválido para pagamento de fornecedores';
									throw new Exception(json_encode($retorno), 1);
								}
							}
						}
						if(empty($codigo_barras)){
							$retorno['codigo']   = 1;
							$retorno['tipo']     = 'error';
							$retorno['input']    = $_POST;
							$retorno['output']   = $codigo_barras;
							$retorno['mensagem'] = 'Informe o codigo de barras';
							throw new Exception(json_encode($retorno), 1);
						}
						
						if(!is_numeric($codigo_barras)){
							$retorno['codigo']   = 1;
							$retorno['tipo']     = 'error';
							$retorno['input']    = $_POST;
							$retorno['output']   = $codigo_barras;
							$retorno['mensagem'] = 'Codigo de barras deve ser numerico';
							throw new Exception(json_encode($retorno), 1);
						}
					break;
					case 'transferencia':
						$conta_fornecedor = json_decode($this->objContabancaria->getContaByFornecedor($_POST['id_fornecedor']));
						$conta_despesa    = json_decode($this->objContabancaria->getContaByDespesa($this->parametros[4]));
						if(!$conta_fornecedor && !$conta_despesa){
							if(empty($codigo_barras)){
								$retorno['codigo']   = 1;
								$retorno['tipo']     = 'error';
								$retorno['input']    = $_POST;
								$retorno['output']   = null;
								$retorno['mensagem'] = 'Este fornecedor não possui conta bancaria cadastrada';
								throw new Exception(json_encode($retorno), 1);
							}
						}
					break;
					case 'guia_recolhimento':
						switch ($_POST['tipo_cobranca']) {
							case 'gps':
							case 'gps_parc':
							case 'darf_normal':
							case 'darf_simples':
								$identificacao_contribuinte = trim(removeCaracteres($_POST['identificacao_contribuinte'],'char'));
								if(empty($identificacao_contribuinte)){
									$retorno['codigo']   = 1;
									$retorno['tipo']     = 'error';
									$retorno['input']    = $_POST;
									$retorno['output']   = $identificacao_contribuinte;
									$retorno['mensagem'] = 'Informe o identificador do contribuinte';
									throw new Exception(json_encode($retorno), 1);
								}

								if(!is_numeric($identificacao_contribuinte)){
									$retorno['codigo']   = 1;
									$retorno['tipo']     = 'error';
									$retorno['input']    = $_POST;
									$retorno['output']   = $identificacao_contribuinte;
									$retorno['mensagem'] = 'identificador do contribuinte deve ser numerico';
									throw new Exception(json_encode($retorno), 1);
								}
							break;
						}
					break;
				}

				if(!isset($_POST['data_vencimento']) || empty($_POST['data_vencimento'])){
					$retorno['codigo']   = 1;
					$retorno['tipo']     = 'error';
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Informe a data de vencimento';
					throw new Exception(json_encode($retorno), 1);
				}else{
					$param['data_vencimento'] = convertDate($_POST['data_vencimento']);
				}

				if(isset($_POST['periodo_apuracao']) && !empty($_POST['periodo_apuracao'])){
					$_POST['periodo_apuracao'] = convertDate($_POST['periodo_apuracao']);
				}
				
				if(isset($_POST['valor']) && !empty($_POST['valor']) && $_POST['valor'] > 0){
					$param['valor'] = $_POST['valor'];
				}else{
					$retorno['codigo']   = 1;
					$retorno['tipo']     = 'error';
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Necessario informar o valor da despesa';
					throw new Exception(json_encode($retorno), 1);
				}

				if($_POST['status'] == 'pago' && (!isset($_POST['data_pagamento']) || empty($_POST['data_pagamento']))){
					$retorno['codigo']   = 1;
					$retorno['tipo']     = 'error';
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'informe a data de pagamento';
					throw new Exception(json_encode($retorno), 1);
				}elseif($_POST['status'] == 'pago' && isset($_POST['data_pagamento']) && !empty($_POST['data_pagamento'])){
					$param['data_pagamento'] = convertDate($_POST['data_pagamento']);
				}else{
					$param['data_pagamento'] = null;
				}

				if(!isset($this->parametros[1]) || empty($this->parametros[1])){
					$last_despesa = json_decode($this->modelo->getLastIdDoc());
					if($last_despesa){
						$param['id_doc'] = ($last_despesa[0]->id_doc + 1);
					}else{
						$param['id_doc'] = 1;  
					}
				}
				
				if(empty(removerEspacos($_POST['descricao'])) || strlen(removerEspacos($_POST['descricao'])) < 11 ){
					$retorno['codigo'] = 1;
					$retorno['input']  = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = 'Insira a descricao da despesas com no nimimo 10 caracteres';
					throw new Exception(json_encode($retorno), 1);
				}
				
				$param['descricao']        = $_POST['descricao'];
				$param['id_cm']            = $_POST['id_cm'];
				$param['numero_documento'] = $_POST['numero_documento'];
				$param['id_fornecedor']   = $_POST['id_fornecedor'];
				$param['id_grupo']        = $_POST['id_grupo'];
				$param['id_conta']        = $_POST['id_conta'];
				$param['id_subconta']     = $_POST['id_subconta'];
				$param['id_centro_custo'] = $_POST['id_centro_custo'];
				$param['prioridade']      = $_POST['prioridade'];
				$param['meio_pagamento']  = $_POST['meio_pagamento'];
				$param['periodo_apuracao'] = $_POST['periodo_apuracao'];
				$param['tipo_cobranca']   = $_POST['tipo_cobranca'];
				$param['historico']       = $_POST['historico'];
				$param['status']          = $_POST['status'];
				$param['tipo']            = $_POST['tipo'];
				$param['codigo_barra']    = $_POST['codigo_barra'];
				$param['tipo_despesa']    = $_POST['tipo_despesa'];
				$param['parcelado']       = $_POST['parcelado'];
				$param['multa']           = removeCaracteres($_POST['multa'],'moeda2');
				$param['juros']           = removeCaracteres($_POST['juros'],'moeda2');
				$param['outros_valores']  = removeCaracteres($_POST['outros_valores'],'moeda2');
				$param['abatimento']      = removeCaracteres($_POST['abatimento'],'moeda2');
				$param['desconto']        = removeCaracteres($_POST['desconto'],'moeda2');
				$param['codigo_receita']  = $_POST['codigo_receita'];
				$param['divida_ativa']    = $_POST['divida_ativa'];
				$param['identificacao_contribuinte'] = $_POST['identificacao_contribuinte'];
				$param['codigo_tributo']             = $_POST['codigo_tributo'];
				$param['competencia']                = $_POST['competencia'];
				$param['numero_referencia']          = $_POST['numero_referencia'];
				$param['atualizacao_monetaria']      = $_POST['atualizacao_monetaria'];
				$param['percentual_receita']         = removeCaracteres($_POST['percentual_receita'],'moeda2');
				$param['parcela_numero']             = $_POST['parcela_numero'];
				$param['numero_parcelas']            = $_POST['numero_parcelas'];

				if(isset($_POST['conta_default']) && $_POST['conta_default'] == '1' ){
					if(isset($_POST['id_banco_bacen']) && !empty($_POST['id_banco_bacen'])){
						$banco_bacen = json_decode($this->objContabancaria->getBanco($_POST['id_banco_bacen']));
						$param['id_banco_bacen'] = str_pad($_POST['id_banco_bacen'], 8, 0, STR_PAD_LEFT);
						$param['banco_ispb']     = $banco_bacen[0]->ispb_banco;
						$param['banco_codigo']   = $banco_bacen[0]->codigo_banco;
						$param['banco_nome']     = $banco_bacen[0]->nome_reduzido;
					}
				}

				if($_POST['status'] == 'pago'){
					$param['status_autorizacao'] = 'aprovado';
					$param['requer_autorizacao'] = 0;	
				}else{
					$param['status_autorizacao'] = 'pendente';
					$param['requer_autorizacao'] = 1;	
				}

				if(empty($_POST['numero_parcelas'])){
					$param['numero_parcelas'] = 0;
				}else{
					$param['numero_parcelas'] = $_POST['numero_parcelas'];
				}

				if($this->parametros[1] < 1 && $_POST['parcelado'] == 1 && $_POST['numero_parcelas'] > 1){
					$num_parcelas = $_POST['numero_parcelas'];
					$obj_dt_vencimento = new DateTime($param['data_vencimento']);
					for ($i=1; $i <= $num_parcelas; $i++) {
						$param['data_vencimento'] = $obj_dt_vencimento->format('Ymd');
						$is_save = $this->saveDespesa($param);
						$obj_dt_vencimento->add(new DateInterval('P1M'));
					}

				}else{
					if($this->parametros[1] > 0){
						$action  = 'atualizar';
						$despesa = json_decode($this->modelo->getDespesas($this->parametros[1]));
					}else{
						$action = 'criar';
						$despesa = null;
					}
					$is_save = $this->saveDespesa($param, $this->parametros[1]);
				}
				
				if($is_save && $permission_save){
					$despesa = json_decode($this->modelo->getDespesas($is_save));
					if(isset($this->parametros[1]) && !empty($this->parametros[1])){
						$mensagem  = "Despesa alterada \n ID: ".$despesa[0]->id_despesa." \n Empresa Pagadora: ".$despesa[0]->nome_cm." Fornecedor: ".$despesa[0]->nome_fornecedor." \n	Vencimento: ".convertDate($despesa[0]->data_vencimento)." \n ";    
					}else{
						$mensagem  = "Despesa incluida \n ID: ".$despesa[0]->id_despesa." \n Empresa Pagadora: ".$despesa[0]->nome_cm." Fornecedor: ".$despesa[0]->nome_fornecedor." \n	Vencimento: ".convertDate($despesa[0]->data_vencimento)." \n ";
					}
					$parametros['tipo_destinatario'] = 'webhook';
					if('producao' == TIPO_AMBIENTE){
						$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/06b48f3c-0684-46b4-ad04-63494a706bc7@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9cb6bfbfed3d4b1e9c34f76848ba6e61/c8c7ff53-e294-4a3a-bcad-c9f04857e469';
					}else{
						$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9f2e2cc655bf4e76bfdb0531dd3a83d7/c328c206-070a-4beb-bbed-da82e018abec';
					}
					$parametros['mensagem'] = $mensagem;
					$send = $this->cl_notificacao->enviar('teams', $parametros);
					$retorno['codigo']   = 0;
					$retorno['tipo']     = 'sucesso';
					$retorno['input']    = $_POST;
					$retorno['output']   = $is_save;
					$retorno['mensagem'] = 'Sucesso';
					throw new Exception(json_encode($retorno), 1);
				}else{
					$retorno['codigo']   = 1;
					$retorno['tipo']     = 'error';
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Erro ao salvar a despesa';
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function saveDespesa($param){
			
			$permission_save = true;
			
			if(isset($param['data_vencimento']) && !empty($param['data_vencimento'])){
				$obj_dt_vencimento = new datetime($param['data_vencimento']);
			}else{
				$permission_save = false;
			}
			
			$dif_dias = $this->data_hora_atual->diff($obj_dt_vencimento);

			// Regra desativada temporariamente
			// if($dif_dias->days < 10){
			// 	$msg = base64_encode('Necessario no minimo mais de quinze dias para a data de vencimento, quantidade dias = '.$dif_dias->days);
			// 	$permission_save = false;
			// }

			$orcamento = json_decode($this->orcamento->checkTotalOrcamento(
				$param['id_centro_custo'],
				$param['id_grupo'],
				$param['id_conta'],
				$param['id_subconta'],
				$obj_dt_vencimento->format('Y'),
				$obj_dt_vencimento->format('m')
			));

			$despesas = json_decode($this->modelo->checkTotalLancamentos(
				$param['id_centro_custo'],
				$param['id_grupo'],
				$param['id_conta'],
				$param['id_subconta'],
				$obj_dt_vencimento->format('Y'),
				$obj_dt_vencimento->format('m')
			));
		
			if(isset($this->parametros[1]) && !empty($this->parametros[1])){
				$despesa_existente  = json_decode($this->modelo->getDespesas($this->parametros[1]));
				if($param['valor'] > $despesa_existente[0]->valor){
				}
			}

			$total_orcamento = (float)$orcamento[0]->total_orcamento;
			$total_despesas  = ((float)$param['valor'] + (float)$despesas[0]->total_lancamentos);

			if(!is_float($total_orcamento) || !is_float($total_despesas)){
				echo 'Erro';
				exit;
			}
			
			if(!isset($param['requer_autorizacao'])){
				$param['requer_autorizacao'] = 1;
			}

			if(!isset($param['status_autorizacao'])){
				$param['status_autorizacao'] = 'pendente';	
			}
			
			$param['orcamento_atual']    = $total_orcamento;
			$param['total_lancamentos']  = $total_despesas;
			$param['saldo_atual']        = ($total_orcamento - $total_despesas);
			
			if($permission_save){
				if('pago' == $param['status']){
					$fornecedor = json_decode($this->fornecedor->getFornecedores($param['id_fornecedor']));
					$destinatario = explode(';',SYSTEM_NOTIFY_TO);
					$mensagem_email  = "
					<p><b>Despesa baixada com sucesso, segue os dados</b></p>
					<p>
						ID: ".$this->parametros[1]." <br>
						Fornecedor: ".$fornecedor[0]->razao_social." <br>
						Valor:      ".funcValor($param['valor'], 'C')."<br>
						Vencimento: ".convertDate($param['data_vencimento'])." <br>
						Status    : ".$param['status']." <br>
						Alterada por: ".$_SESSION['cmswerp']['userdata']->nome." <br>
						Alterada em: ".$this->data_hora_atual->format('d/m/Y H:i:s')." </p> ";
					$param_envio['email']['assunto']         = 'Aviso Despesa paga'; // emails separados por;
					$param_envio['email']['destinatario']    = $destinatario; // emails separados por;
					$param_envio['email']['mensagem']        = $mensagem_email;

					$mensagem = "Despesa baixada com sucesso, segue os dados <br> ID: ".$this->parametros[1]." <br> Fornecedor: ".$fornecedor[0]->razao_social." <br> Valor: ".funcValor($param['valor'], 'C')."<br>";
					$mensagem .= "Vencimento: ".convertDate($param['data_vencimento'])." <br> Status : ".$param['status']." Aprovado por: ".$_SESSION['cmswerp']['userdata']->nome." <br> Alterada em: ".$this->data_hora_atual->format('d/m/Y H:i:s')." \n ";
					$parametros['tipo_destinatario'] = 'webhook';
					if('producao' == TIPO_AMBIENTE){
						$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/06b48f3c-0684-46b4-ad04-63494a706bc7@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9cb6bfbfed3d4b1e9c34f76848ba6e61/c8c7ff53-e294-4a3a-bcad-c9f04857e469';
					}else{
						$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9f2e2cc655bf4e76bfdb0531dd3a83d7/c328c206-070a-4beb-bbed-da82e018abec';
					}
					$parametros['mensagem'] = $mensagem;
					$send = $this->cl_notificacao->enviar('teams', $parametros);

					$result['codigo']     = 0;
					$result['input']      = $param_aprovacao;
					$result['output']     = array('id_despesa' => $is_save);
					$result['mensagem']   = 'Despesa aprovada com sucesso';
				}

				$return = $this->modelo->save($param, $this->parametros[1]);

			}else{
				$return = false;
			}
			
			return $return;
		}

		function deletar(){
			try {
				if(!isset($this->parametros[1]) || !is_numeric($this->parametros[1])){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'ID da despesa inválido';
					throw new Exception(json_encode($retorno));
				}

				$records  = json_decode($this->modelo->getDespesas($this->parametros[1]));

				if($records[0]->status == 'pago'){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Essa despesa já foi debitada, não é possivel apagar!';
					throw new Exception(json_encode($retorno));
				}

				$id = $this->parametros[1];
				$param['deleted'] = 1;
				$is_save = $this->modelo->save($param, $id);
				
				if($is_save){
					$retorno['codigo']   = 0;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Sucesso';
					throw new Exception(json_encode($retorno));
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Erro ao apagar a despesa';
					throw new Exception(json_encode($retorno));	
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function calendario(){
			//$despesas = json_decode($this->modelo->getDadosCalendario());
			require_once ABSPATH . '/views/'.$this->nome_view.'/calendario-view.php';
		}

		function calendarioSaldo(){
			//$despesas = json_decode($this->modelo->getDadosCalendario());
			require_once ABSPATH . '/views/'.$this->nome_view.'/calendario-saldo-view.php';
		}

		function dadosCalendario(){
			//header('Content-Type: application/json');
			$debitos  = json_decode($this->modelo->getDadosCalendario());
			$creditos = json_decode($this->obj_nf->getDadosCalendario());
			$indice = 0;
			foreach ($debitos as $key => $value){
				$dt_vencimento = new DateTime($value->data_vencimento);
				$param[$indice]['title'] = $value->valor_total;
				
				$param[$indice]['start'] = $value->data_vencimento;
				$param[$indice]['end']   = $value->data_vencimento;
				// $param[$indice]['overlap'] = false;
				// $param[$indice]['rendering'] = "background";
				if($value->status_autorizacao == 'automatico' || $value->status_autorizacao == 'aprovado'){
					$param[$indice]['color'] = "green";
					$param[$indice]['textColor'] = "white";
					$param[$indice]['url'] = '/despesas/listar/filter/1/'.$value->data_vencimento.'/aprovado';
				}elseif($value->status_autorizacao == 'reprovado'){
					$param[$indice]['color'] = "red";
					$param[$indice]['textColor'] = "white";
					$param[$indice]['url'] = '/despesas/listar/filter/1/'.$value->data_vencimento.'/reprovado';
				}elseif($value->status_autorizacao == 'pendente'){
						$param[$indice]['color'] = "yellow";
						$param[$indice]['textColor'] = "black";
						$param[$indice]['url'] = '/despesas/listar/filter/1/'.$value->data_vencimento.'/pendente';
				}
				$indice++;
			}

			foreach ($creditos as $key => $value){
				$dt_vencimento = new DateTime($value->data_vencimento);
				$param[$indice]['title'] = $value->valor_total;
				if($value->status == 'recebido'){
					$param[$indice]['start'] = $value->recebido_em;
					$param[$indice]['end']   = $value->recebido_em;
					$param[$indice]['url'] = '/faturamento/listarnf/filter/vencimento/'.$value->data_vencimento.'/status/recebido/';
					$param[$indice]['color'] = "blue";
					$param[$indice]['textColor'] = "white";
					$indice++;
				}else{
					$param[$indice]['start'] = $value->data_vencimento;
					$param[$indice]['end']   = $value->data_vencimento;
					$param[$indice]['url'] = '/faturamento/listarnf/filter/vencimento/'.$value->data_vencimento.'/status/receber/';
					$param[$indice]['color']     = "purple";
					$param[$indice]['textColor'] = "white";
					$indice++;
				}
			}
			header('Access-Control-Allow-Origin: *');
			header('Content-type: application/json');
			echo json_encode($param);
		}

		function dadosCalendarioSaldo(){
			//header('Content-Type: application/json');
			$debitos  = json_decode($this->modelo->getDadosSaldo('aberto', 'aprovado'));
			foreach ($debitos as $key => $value) {
				$param[$key]['title']     += $value->valor_total;
				$param[$key]['start']     = $value->data_vencimento;
				$param[$key]['end']       = $value->data_vencimento;
				$param[$key]['url']       = '/despesas/listarSaldo/'.$value->data_vencimento.'/'.$value->data_vencimento.'/aberto/aprovado/';
				$param[$key]['color']     = "purple";
				$param[$key]['textColor'] = "white";
				switch ($value->id_cm) {
					case '1':
						$param[$key]['color']     = "purple";
						$param[$key]['textColor'] = "white";
					break;
					case '3':
						$param[$key]['color'] = "yellow";
						$param[$key]['textColor'] = "black";
					break;
					case '4':
						$param[$key]['color'] = "red";
						$param[$key]['textColor'] = "white";
					break;
					case '7':
						$param[$key]['color'] = "green";
						$param[$key]['textColor'] = "white";
					break;
					default:
						$param[$key]['color']     = "blue";
						$param[$key]['textColor'] = "white";
					break;
				}
			}

			foreach ($param as $key => $value) {
				$param[$key]['title'] = number_format($param[$key]['title'], '2', ',', '.');
			}

			/*
			"title": "18.866,15",
			"start": "2020-05-22",
			"end": "2020-05-22",
			"color": "green",
			"textColor": "white",
			"url": "/despesas/listar/filter/1/2020-05-22/aprovado"
			*/
			header('Access-Control-Allow-Origin: *');
			header('Content-type: application/json');
			echo json_encode($param);
		}

		function ajaxDadosOrcamento(){
			try {
				$config_orcamento = json_decode($this->config_list[0]->controle_orcamento);
				if(isset($_POST['id_despesa']) && is_numeric($_POST['id_despesa']) && !empty($_POST['id_despesa'])){
					$despesa = json_decode($this->modelo->getDespesas($_POST['id_despesa']));
					$despesa[0]->tipo              = $_POST['tipo'];
					$despesa[0]->tipo              = $_POST['tipo'];
					$despesa[0]->nome_centro_custo   = $_POST['nome_cc'];
					$despesa[0]->nome_grupo          = $_POST['nome_grupo'];
					$despesa[0]->nome_conta          = $_POST['nome_conta'];
					$despesa[0]->nome_subconta       = $_POST['nome_subconta'];
					$despesa[0]->id_centro_custo   = $_POST['id_cc'];
					$despesa[0]->id_grupo          = $_POST['id_grupo'];
					$despesa[0]->id_conta          = $_POST['id_conta'];
					$despesa[0]->id_subconta       = $_POST['id_subconta'];
				}else{
					$centro_custo                       = json_decode($this->orcamento->getCentroCusto($_POST['id_cc']));
					$grupo                              = json_decode($this->orcamento->getGrupo($_POST['id_grupo']));
					$conta                              = json_decode($this->orcamento->getConta($_POST['id_conta']));
					$subconta                           = json_decode($this->orcamento->getSubConta($_POST['id_subconta']));
					$param_despesa['id_despesa']        = null;
					$param_despesa['tipo']              = $_POST['tipo'];
					$param_despesa['id_centro_custo']   = $_POST['id_cc'];
					$param_despesa['id_grupo']          = $_POST['id_grupo'];
					$param_despesa['id_conta']          = $_POST['id_conta'];
					$param_despesa['id_subconta']       = $_POST['id_subconta'];
					$param_despesa['nome_centro_custo'] = $centro_custo[0]->nome;
					$param_despesa['nome_grupo']        = $grupo[0]->nome;
					$param_despesa['nome_conta']        = $conta[0]->nome;
					$param_despesa['nome_subconta']     = $subconta[0]->nome;;
					$param_despesa['valor']             = removeCaracteres($_POST['valor'], 'moeda2');
					$param_despesa['data_vencimento']   = convertDate($_POST['data_vencimento']);
					$despesa[0] = (object) $param_despesa;
				}
				
				if($despesa){
					$data_vencimento  = new DateTime($despesa[0]->data_vencimento);
					if($data_vencimento){
						$saldo = $this->getSaldo($despesa[0], $data_vencimento, $config_orcamento->nivel_controle, $config_orcamento->periodo_controle, $config_orcamento->tipo_controle);	
						
						if($saldo){
							$retorno['codigo']   = 0;
							$retorno['tipo']     = 'success';
							$retorno['mensagem'] = 'Saldo processado com sucesso';
							$retorno['post']     = $_POST;
							$retorno['dados']    = $saldo;
						}else{
							$retorno['codigo']   = 2;
							$retorno['tipo']     = 'danger';
							$retorno['mensagem'] = 'Saldo nao encontrado para essa despesa';
							$retorno['post']     = $_POST;
							$retorno['dados']    = $saldo;
						}
					}else{
						$retorno['codigo']   = 2;
						$retorno['tipo']     = 'danger';
						$retorno['mensagem'] = 'Despesa sem data de vencimento';
						$retorno['post']     = $_POST;
						$retorno['dados']    = null;
					}
				}else{
					$retorno['codigo']   = 2;
					$retorno['tipo']     = 'danger';
					$retorno['mensagem'] = 'Saldo nao encontrado para essa despesa';
					$retorno['post']     = $_POST;
					$retorno['dados']    = null;
				}
				throw new Exception(json_encode($retorno), 1);
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function getSaldo($despesa, $dt_base, $agrupar_por, $periodo, $tipo){
			
			$mes = null;
			$ano = $dt_base->format('Y');
			
			$a = false;
			$b = false;
			$c = false;
			$d = false;
			
			if($periodo == 'mensal'){
				$mes = $dt_base->format('m');
				$dt_ini = clone $dt_base;
				$dt_ini->modify('first day of this month');
				$dt_fim  = clone $dt_base;
				$dt_fim->modify('last day of this month');

				$retorno['mes']    = $mes;
				$retorno['dt_ini'] = $dt_ini;
				$retorno['dt_fim'] = $dt_fim;
				
			}elseif($periodo == 'trimestral'){
				if($dt_base->format('m') <= 3 ){
					$mes = array('ini' => 1, 'fim' => 3);
					$dt_ini = new DateTime($dt_base->format('Y-01-01'));
					$dt_fim  = new DateTime($dt_base->format('Y-03-31'));
				}elseif($dt_base->format('m') > 3 && $dt_base->format('m') <= 6){
					$mes = array('ini' => 4, 'fim' => 6);
					$dt_ini = new DateTime($dt_base->format('Y-04-01'));
					$dt_fim  = new DateTime($dt_base->format('Y-06-30'));
				}elseif($dt_base->format('m') > 6 && $dt_base->format('m') <= 9){
					$mes = array('ini' => 7, 'fim' => 9);
					$dt_ini = new DateTime($dt_base->format('Y-07-01'));
					$dt_fim  = new DateTime($dt_base->format('Y-09-30'));
				}elseif($dt_base->format('m') > 9 && $dt_base->format('m') <= 12){
					$mes = array('ini' => 10, 'fim' => 12);
					$dt_ini = new DateTime($dt_base->format('Y-10-01'));
					$dt_fim  = new DateTime($dt_base->format('Y-12-31'));
				}
			}elseif($periodo == 'semestral'){
				if($dt_base->format('m') <= 6 ){
					$mes = array('ini' => 1, 'fim' => 6);
					$dt_ini  = new DateTime($dt_base->format('Y-01-01'));
					$dt_fim  = new DateTime($dt_base->format('Y-06-30'));
				}elseif($dt_base->format('m') > 6 && $dt_base->format('m') <= 12){
					$mes = array('ini' => 7, 'fim' => 12);
					$dt_ini = new DateTime($dt_base->format('Y-07-01'));
					$dt_fim  = new DateTime($dt_base->format('Y-12-31'));
				}
			}elseif($periodo == 'anual'){
				$dt_ini = new DateTime($dt_base->format('Y-01-01'));
				$dt_fim  = new DateTime($dt_base->format('Y-12-31'));
			}

		
			$retorno['dt_base']            = $dt_base;
			$retorno['tipo']               = $tipo;
			$retorno['dt_ini']             = $dt_ini;
			$retorno['dt_fim']             = $dt_fim;
			$retorno['id_despesa']         = $despesa->id_despesa;
			$retorno['valor_despesa']      = number_format($despesa->valor, '2', ',','.');

			if($agrupar_por == 'centro_custo'){
				$a = true;
			}elseif($agrupar_por == 'grupo'){
				$a = true;
				$b = true;
			}elseif($agrupar_por == 'conta'){
				$a = true;
				$b = true;
				$c = true;
			}elseif($agrupar_por == 'subconta'){
				$a = true;
				$b = true;
				$c = true;
				$d = true;
			}
			
			//$param['filtro'][0]['status'] = 'pago';
			$param['filtro'][0]['status_autorizacao'] = 'aprovado';
			$param['filtro'][0]['view'] = $tipo;
			$param['ano']    = $ano;
			$param['mes']    = $mes;
			$param['dt_ini'] = $dt_ini;
			$param['dt_fim'] = $dt_fim;
			

			if($a){
				$param['agrupar']           = 'centro_custo';
				$param['filtro'][0]['nome'] = 'centro_custo';
				$param['filtro'][0]['id']   = $despesa->id_centro_custo;
				
				$orc_centro_custo     = json_decode($this->orcamento->getOrcamentoByParametro($param, false));
				$debitos_centro_custo = json_decode($this->modelo->getDespesasParametro($param, $tipo, false));

				if(!$orc_centro_custo){
					$orc_centro_custo[0]->centro_custo = $despesa->nome_centro_custo;
					$orc_centro_custo[0]->valor = 0;
				}

				if($debitos_centro_custo){
					$disp_centro_custo    = ($orc_centro_custo[0]->valor - $debitos_centro_custo[0]->valor);
					$total_centro_custo   = ($orc_centro_custo[0]->valor - ($debitos_centro_custo[0]->valor + $despesa->valor));
				}else{
					$disp_centro_custo  = $orc_centro_custo[0]->valor;
					$total_centro_custo = ($orc_centro_custo[0]->valor - $despesa->valor);
				}

				$retorno['nome_centro_custo']     = $orc_centro_custo[0]->centro_custo;
				$retorno['orc_centro_custo']      = number_format($orc_centro_custo[0]->valor, '2', ',', '.');
				$retorno['debitos_centro_custo']  = number_format($debitos_centro_custo[0]->valor, '2', ',', '.');
				$retorno['saldo_centro_custo']    = number_format($disp_centro_custo, '2', ',', '.');
				$retorno['total_centro_custo']    = number_format($total_centro_custo, '2', ',', '.');
			}

			if($b){
				$param['agrupar']             = 'grupo';
				$param['filtro'][1]['nome']   = 'grupo';
				$param['filtro'][1]['id']     = $despesa->id_grupo;
				
				$orc_grupo     = json_decode($this->orcamento->getOrcamentoByParametro($param, false));
				$debitos_grupo = json_decode($this->modelo->getDespesasParametro($param, $tipo, false));

				if(!$orc_grupo){
					$orc_grupo[0]->grupo = $despesa->nome_grupo;
					$orc_grupo[0]->valor = 0; 
				}

				if($debitos_grupo){
					$disp_grupo    = ($orc_grupo[0]->valor - $debitos_grupo[0]->valor);
					$total_grupo   = ($orc_grupo[0]->valor - ($debitos_grupo[0]->valor + $despesa->valor));
				}else{
					$disp_grupo  = $orc_grupo[0]->valor;
					$total_grupo = ($orc_grupo[0]->valor - $despesa->valor);
				}

				$retorno['nome_grupo']    = $orc_grupo[0]->grupo;
				$retorno['orc_grupo']     = number_format($orc_grupo[0]->valor, '2', ',', '.');
				$retorno['debitos_grupo'] = number_format($debitos_grupo[0]->valor, '2', ',', '.');
				$retorno['saldo_grupo']   = number_format($disp_grupo, '2', ',', '.');
				$retorno['total_grupo']   = number_format($total_grupo, '2', ',', '.');
			}

			if($c){
				$param['agrupar']           = 'conta';
				$param['filtro'][2]['nome'] = 'conta';
				$param['filtro'][2]['id']   = $despesa->id_conta;
				
				$orc_conta   = json_decode($this->orcamento->getOrcamentoByParametro($param, false));
				$debitos_conta = json_decode($this->modelo->getDespesasParametro($param, $tipo, false));
				
				if(!$orc_conta){
					$orc_conta[0]->conta = $despesa->nome_conta;
					$orc_conta[0]->valor = 0; 
				}

				if($debitos_conta){
					$disp_conta  = ($orc_conta[0]->valor - $debitos_conta[0]->valor);
					$total_conta = ($orc_conta[0]->valor - ($debitos_conta[0]->valor + $despesa->valor));
				}else{
					$disp_conta  = $orc_conta[0]->valor;
					$total_conta = ($orc_conta[0]->valor - $despesa->valor);
				}

				$retorno['nome_conta']    = $orc_conta[0]->conta;	
				$retorno['orc_conta']     = number_format($orc_conta[0]->valor, '2', ',', '.');
				$retorno['debitos_conta'] = number_format($debitos_conta[0]->valor, '2', ',', '.');
				$retorno['saldo_conta']   = number_format($disp_conta, '2', ',', '.');
				$retorno['total_conta']   = number_format($total_conta, '2', ',', '.');
			}
			
			if($d){
				$param['agrupar']           = 'subconta';
				$param['filtro'][3]['nome'] = 'subconta';
				$param['filtro'][3]['id']   = $despesa->id_subconta;
				
				$orc_subconta     = json_decode($this->orcamento->getOrcamentoByParametro($param, false));
				$debitos_subconta = json_decode($this->modelo->getDespesasParametro($param, $tipo, false));

				if(!$orc_subconta){
					$orc_subconta[0]->subconta = $despesa->nome_subconta;
					$orc_subconta[0]->valor = 0; 
				}

				if($debitos_subconta){
					$disp_subconta  = ($orc_subconta[0]->valor - $debitos_subconta[0]->valor);
					$total_subconta = ($orc_subconta[0]->valor - ($debitos_subconta[0]->valor + $despesa->valor));
				}else{
					$disp_subconta  = $orc_subconta[0]->valor;
					$total_subconta = ($orc_subconta[0]->valor - $despesa->valor);
				}
				
				$retorno['nome_subconta']    = $orc_subconta[0]->subconta;
				$retorno['orc_subconta']     = number_format($orc_subconta[0]->valor, '2', ',', '.');
				$retorno['debitos_subconta'] = number_format($debitos_subconta[0]->valor, '2', ',', '.');
				$retorno['saldo_subconta']   = number_format($disp_subconta, '2', ',', '.');
				$retorno['total_subconta']   = number_format($total_subconta, '2', ',', '.');
			}
			return $retorno;
		}
		
		function listarRemessa(){

			if(isset($_POST['data_ini']) && !empty($_POST['data_ini'])){
				$data_ini = getDataAtual(convertDate($_POST['data_ini']));
			}else{
				$data_ini = getDataAtual();
			}

			if(isset($_POST['data_ini']) && !empty($_POST['data_fim'])){
				$data_fim = getDataAtual(convertDate($_POST['data_fim']));
			}else{
				$data_fim = getDataAtual();
			}
			
			$remessas = json_decode($this->arquivo_model->getRemessaByPeriodo($data_ini->format('Y-m-d'), $data_fim->format('Y-m-d')));
			
			require_once ABSPATH . '/views/'.$this->nome_view.'/remessa-view.php';
		}

		function remessadespesas(){
			if(isset($this->parametros[1]) && is_numeric($this->parametros[1])){
				$remessa_detalhe = json_decode($this->arquivo_model->getDetalhesByRemessa($this->parametros[1]));
				if($remessa_detalhe){
					foreach ($remessa_detalhe as $key => $value) {
						$id_despesas[] = $value->id_despesa;
					}
					$despesas = json_decode($this->modelo->getDespesas($id_despesas));
				}
				require_once ABSPATH . '/views/'.$this->nome_view.'/remessa-detalhe.php';
			}else{
				echo 'Informe a remessa!';
			}
		}

		function apagarRemessa(){
			if(isset($this->parametros[1]) && is_numeric($this->parametros[1])){
				$param['deleted'] = 1 ;
				$deletar = $this->arquivo_model->save($param, $this->parametros[1]);
				if($deletar){
					header("location:".URL_SISTEMA."despesas/listarremessa/");
				}else{
					echo 'Erro ao deletar despesa';
				}
			}else{
				echo 'Informe a remessa!';
			}
		}

		function downloadRemessa(){
			if(isset($this->parametros[1]) && is_numeric($this->parametros[1])){
				$remessa = json_decode($this->arquivo_model->getRemessa($this->parametros[1]));
				if($remessa){
					// $param['status'] = 'enviado';
					// $save_remessa = $this->arquivo_model->save($param, $remessa[0]->id);
					$save_remessa = true;
					if($save_remessa){
						if($remessa[0]->codigo_banco == '237'){
							$banco = 'bradesco';
						}elseif($remessa[0]->codigo_banco == 341){
							$banco = 'itau';
						}
						$nome_arquivo = base64_encode($remessa[0]->nome_arquivo);
						$tipo_arquivo = $remessa[0]->tipo_arquivo;
						$modalidade   = $remessa[0]->modalidade;
						$url = '/download_file.php?banco='.$banco.'&tipo='.$tipo_arquivo.'&modalidade='.$modalidade.'&file='.$nome_arquivo;
						header('location: '.$url);
					}else{
						echo 'Erro ao atualizar remessa';
					}
				}else{
					echo 'Remessa não localizada!';
				}
			}else{
				echo 'Informe a remessa!';
			}
		}

		function gerarArquivoRemessa(){
			$pagamentos  = null;
			$dados_banco = null;
			$obj_lote    = null;
			$pagamentos  = null;
			$num_seq	 = null;
			try{
				// Buscando despesas que tenham conta propria
				$arr_despesas = null;
				$desp_cp = json_decode($this->modelo->getDespesasComConta($_POST['despesas']));
				if($desp_cp){
					foreach ($desp_cp as $key => $value) {
						if($value->id_conta_fornecedor){
							$i = $value->id_empresa_conta;
							$arr_despesas[] = $value;
							unset($_POST['despesas'][$i]);
						}
					}
				}
				
				if($_POST['despesas']){
					$despesas = json_decode($this->modelo->getDespesasCbDefault(true, $_POST['despesas']));
					if($despesas){
						if(count($arr_despesas) > 0){
							$arr_despesas = array_merge($arr_despesas, array_values($despesas));
						}else{
							$arr_despesas = (array_values($despesas));
						}
					}
				}

				if(!$desp_cp && !$despesas){
					$retorno[0]['codigo']   = 1;
					$retorno[0]['tipo']     = 'danger';
					$retorno[0]['input']    = $_POST;
					$retorno[0]['output']   = $despesas;
					$retorno[0]['mensagem'] = 'Despesas não encontrada!';
					throw new Exception(json_encode($retorno), 1);
				}

				if($_POST['banco_pagamento']){ // quando o banco é fornecido
					$banco_remessa = json_decode($this->objContabancaria->getBanco($_POST['banco_pagamento']));
					if(!$banco_remessa){
						$retorno[0]['codigo'] = 1;
						$retorno[0]['tipo']   = 'danger';
						$retorno[0]['input']  = $_POST;
						$retorno[0]['output'] = $banco_remessa;
						$retorno[0]['mensagem'] = 'Banco de remessa não encontrado';
						throw new Exception(json_encode($retorno), 1);
					}

					if(isset($_POST['cnab']) && !empty($_POST['cnab'])){
						$contas_cm[0]['banco']['cnab'] = $_POST['cnab'];
					}else{
						$contas_cm[0]['banco']['cnab'] = CNAB_DEFAULT;
					}

					if($contas_cm[0]['banco']['cnab'] == '240'){
						$contas_cm[0]['banco']['codigo_convenio'] = $banco_remessa[0]->codigo_convenio_cnab240;
					}elseif($contas_cm[0]['banco']['cnab'] == '400'){
						$contas_cm[0]['banco']['codigo_convenio'] = $banco_remessa[0]->codigo_convenio_cnab400;
					}
					
					$contas_cm[0]['banco']['tipo_arquivo']   = 'remessa';
					$contas_cm[0]['banco']['modalidade']     = 'pagamento';
					$contas_cm[0]['banco']['id_lancamento']  = 'PGCM';
					$contas_cm[0]['banco']['tipo_inscricao'] = 2; // 1 - CPF, 2 - CNPJ
					$contas_cm[0]['banco']['ispb']           = $banco_remessa[0]->ispb_banco_cm;
					$contas_cm[0]['banco']['nome_banco']     = $banco_remessa[0]->nome_reduzido;
					$contas_cm[0]['banco']['codigo_banco']   = $banco_remessa[0]->codigo_banco;
					$contas_cm[0]['banco']['tipo_conta']     = $banco_remessa[0]->tipo_conta;
					$contas_cm[0]['banco']['agencia']        = $banco_remessa[0]->numero_agencia;
					$contas_cm[0]['banco']['agencia_dig']    = $banco_remessa[0]->digito_agencia;
					$contas_cm[0]['banco']['conta']          = $banco_remessa[0]->numero_conta;
					$contas_cm[0]['banco']['dig_conta']      = $banco_remessa[0]->digito_conta;
					$contas_cm[0]['banco']['codigo_convenio'] = $banco_remessa[0]->codigo_convenio_cnab240;
					$contas_cm[0]['banco']['conta_default']      = 1;
					$contas_cm[0]['banco']['id_empresa']     = $banco_remessa[0]->id_cm;
					$contas_cm[0]['banco']['cnpj_cpf']       = $banco_remessa[0]->cnpj_cm;
					$contas_cm[0]['banco']['razao_social']   = $banco_remessa[0]->razao_social;
					$contas_cm[0]['banco']['email']          = $banco_remessa[0]->email;
					$contas_cm[0]['banco']['logradouro']     = $banco_remessa[0]->endereco;
					$contas_cm[0]['banco']['numero']         = $banco_remessa[0]->numero;
					$contas_cm[0]['banco']['complemento']    = $banco_remessa[0]->complemento;
					$contas_cm[0]['banco']['bairro']         = $banco_remessa[0]->bairro;
					$contas_cm[0]['banco']['cidade']         = $banco_remessa[0]->cidade;
					$contas_cm[0]['banco']['uf']             = $banco_remessa[0]->estado;
					$contas_cm[0]['banco']['cep']            = removeCaracteres($banco_remessa[0]->cep, 'all');
					$contas_cm[0]['banco']['data_gravacao']  = $this->data_hora_atual->format('Y-m-d');
					$contas_cm[0]['banco']['hora_gravacao']  = $this->data_hora_atual->format('H:i:s');
					$contas_cm[0]['banco']['id_sistema']     = 'MX';
					$contas_cm[0]['banco']['status']         = 'aberto';
					$dados['banco']['despesas'][] = $despesas;

				}else{ // quando o banco não é fornecido
					$fornecedores = null;
					if(count($arr_despesas) > 0){
						foreach ($arr_despesas as $key => $value) {
							$i = $value->id_cm;
							if($i){
								$contas_cm[$i]['banco']['tipo_arquivo']   = 'remessa';
								$contas_cm[$i]['banco']['modalidade']     = 'pagamento';
								$contas_cm[$i]['banco']['id_lancamento']  = 'PGCM';
								$contas_cm[$i]['banco']['tipo_inscricao'] = '2';
								$contas_cm[$i]['banco']['ispb']           = $value->ispb_banco_cm;
								$contas_cm[$i]['banco']['nome_banco']     = $value->nome_banco_cm;
								$contas_cm[$i]['banco']['codigo_banco']   = $value->codigo_banco_cm;
								$contas_cm[$i]['banco']['tipo_conta']     = $value->tipo_conta_cm;
								$contas_cm[$i]['banco']['agencia']        = $value->agencia_cm;
								$contas_cm[$i]['banco']['agencia_dig']    = $value->agencia_div_cm;
								$contas_cm[$i]['banco']['conta']          = $value->numero_conta_cm;
								$contas_cm[$i]['banco']['dig_conta']      = $value->digito_conta_cm;
								$contas_cm[$i]['banco']['codigo_convenio'] = $value->codigo_convenio_cnab240;
								$contas_cm[$i]['banco']['conta_default']  = $value->conta_default_cm;
								$contas_cm[$i]['banco']['id_empresa']     = $value->id_cm;
								$contas_cm[$i]['banco']['cnpj_cpf']       = $value->cnpj_cm;
								$contas_cm[$i]['banco']['razao_social']   = $value->nome_cm;
								$contas_cm[$i]['banco']['email']          = $value->email_conta;
								$contas_cm[$i]['banco']['logradouro']     = $value->endereco;
								$contas_cm[$i]['banco']['numero']         = $value->numero;
								$contas_cm[$i]['banco']['complemento']    = $value->complemento;
								$contas_cm[$i]['banco']['bairro']         = $value->bairro;
								$contas_cm[$i]['banco']['cidade']         = $value->cidade;
								$contas_cm[$i]['banco']['uf']             = $value->estado;
								$contas_cm[$i]['banco']['cep']            = removeCaracteres($value->cep, 'all');
								$contas_cm[$i]['banco']['data_gravacao']  = $this->data_hora_atual->format('Y-m-d');
								$contas_cm[$i]['banco']['hora_gravacao']  = $this->data_hora_atual->format('H:i:s');
								$contas_cm[$i]['banco']['id_sistema']     = 'MX';
								$contas_cm[$i]['banco']['status']         = 'aberto';
								$contas_cm[$i]['banco']['despesas'][]      = $value;
							}
						}
					}else{
						$retorno[0]['codigo']   = 1;
						$retorno[0]['tipo']     = 'danger';
						$retorno[0]['input']    = $_POST;
						$retorno[0]['output']   = $despesas;
						$retorno[0]['mensagem'] = 'Não foi possivel processar as despesas!';
						throw new Exception(json_encode($retorno), 1);
					}
				}
				
				foreach ( $contas_cm as $key => $value ){
					if( isset( $value['banco']['agencia']) && !empty( $value['banco']['agencia'] ) ){
						$create = $this->processaRemessa( $value );
						if($create['codigo'] == 0){
							foreach ($create['input'] as $k1 => $v1){
								$param['status_remessa'] = 'gerado';
								$is_save  = $this->modelo->save( $param, $v1->numero_documento );
							}

							$retorno[$key]['codigo']   = 0;
							$retorno[$key]['input']    = $_POST;
							$retorno[$key]['output']   = $create;
							$retorno[$key]['mensagem'] = 'Arquivo gerado com sucesso';

						}else{
							$retorno[$key]['codigo']   = 1;
							$retorno[$key]['input']    = $value;
							$retorno[$key]['output']   = $create;
							$retorno[$key]['mensagem'] = 'Erro ao gerar arquivo';
						}
					}else{
						$retorno[$key]['codigo']   = 1;
						$retorno[$key]['input']    = $_POST;
						$retorno[$key]['output']   = $value;
						$retorno[$key]['mensagem'] = 'Conta não cadastrada para a empresa '.$value['banco']['razao_social'].' as respectivas despesas não serão processadas!';
					}
				}
				
				throw new Exception(json_encode($retorno), 1);
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function processaRemessa( $dados ){
			if('237' == $dados['banco']['codigo_banco']){
				$remessa_banco = new RemessaBradesco($this, $dados['banco']);
			}elseif('341' == $dados['banco']['codigo_banco']){
				$remessa_banco = new RemessaItau($this, $dados['banco']);
			}else{
				$info['arquivo_base64'] = base64_encode($remessa_banco->getNomeArquivo());
				$info['arquivo_nome']   = $remessa_banco->getNomeArquivo();
				$retorno['codigo']   = 2;
				$retorno['tipo']     = 'warning';
				$retorno['input']    = $dados['banco'];
				$retorno['output']   = $info;
				$retorno['mensagem'] = 'O banco selecionado não possui convenio com sistema de pagamentos';
				throw new Exception(json_encode($retorno), 1);
			}

			foreach ( $dados['banco']['despesas'] as $key => $value ) {
				$data_vencimento = null;
				$data_vencimento = new DateTime($value->data_vencimento);
			
				if($value->tipo_empresa_fornecedor == 'fisica'){
					$value->tipo_empresa_fornecedor = 1;
				}else{
					$value->tipo_empresa_fornecedor = 2;
				}
			
				if($value->periodo_apuracao && $value->periodo_apuracao != '0000-00-00'){
					$periodo_apuracao = new DateTime($value->periodo_apuracao);
					$registros[$key]['periodo_apuracao'] = $periodo_apuracao->format('dmY');
				}else{
					$registros[$key]['periodo_apuracao'] = null;
				}

				$registros[$key]['numero_documento']           	= $value->id_despesa; // id na tabela da base
				$registros[$key]['id_doc']                     	= $value->id_doc; // id na tabela da base
				$registros[$key]['id_fornecedor']              	= $value->id_fornecedor;
				$registros[$key]['nome_fornecedor']            	= $value->nome_fornecedor;
				$registros[$key]['seu_numero']                 	= $value->id_despesa; // numero de identificação da despesa - id_despesa na tabela
				$registros[$key]['codigo_ispb']                	= $value->ispb_banco_fornecedor;
				$registros[$key]['tipo_inscricao']             	= $value->tipo_empresa_fornecedor;    //fisica - 1 cpf, juridica - 2 cnpj
				$registros[$key]['identificacao_contribuinte'] 	= $value->identificacao_contribuinte; //fisica - 1 cpf, juridica - 2 cnpj
				$registros[$key]['ie_cm']            	  		= $value->ie_cm;
				$registros[$key]['cnpj_cm']          	  		= removeCaracteres($value->cnpj_cm, 'char');
				$registros[$key]['cnpj_cpf']         	  		= removeCaracteres($value->cnpj_cpf, 'char');
				$registros[$key]['codigo_banco']     	  		= $value->codigo_banco_fornecedor;
				$registros[$key]['nome_banco']       	  		= $value->nome_banco_fornecedor;
				$registros[$key]['numero_agencia']   	  		= $value->agencia_fornecedor;
				$registros[$key]['digito_agencia']   	  		= $value->agencia_div_fornecedor;
				$registros[$key]['tipo_conta']       	  		= $value->tipo_conta_fornecedor;
				$registros[$key]['numero_conta']     	  		= $value->numero_conta_fornecedor;
				$registros[$key]['digito_conta']     	  		= $value->digito_conta_fornecedor;
				$registros[$key]['ag_conta_dig']     	  		= 0;
				
				$registros[$key]['codigo_barras']    	  		= (string)$value->codigo_barra;
				$registros[$key]['codigo_receita']   	  		= $value->codigo_receita;
				$registros[$key]['codigo_tributo']   	  		= $value->codigo_tributo;
				$registros[$key]['competencia']           		= $value->competencia;
				$registros[$key]['numero_referencia']     		= $value->numero_referencia;
				$registros[$key]['outros_valores']        		= $value->outros_valores;
				$registros[$key]['atualizacao_monetaria'] 		= $value->atualizacao_monetaria;
				$registros[$key]['percentual_receita']    		= $value->percentual_receita;
				$registros[$key]['inscricao_estadual']    		= $value->ie_fornecedor;
				$registros[$key]['divida_ativa']     	  		= $value->divida_ativa;
				$registros[$key]['numero_parcela']   	  		= $value->parcela_numero;
				$registros[$key]['data_vencimento']  	  		= $data_vencimento->format('dmY');
				$registros[$key]['valor']            	  		= $value->valor;
				$registros[$key]['abatimento']       	  		= $value->abatimento;
				$registros[$key]['desconto']         	  		= $value->desconto;
				$registros[$key]['multa']            	  		= $value->multa;
				$registros[$key]['mora']             	  		= $value->juros;
				$registros[$key]['descricao']        	  		= $value->descricao;
				$registros[$key]['tipo_despesa']     	  		= $value->tipo_despesa;
				$registros[$key]['tipo_cobranca']    	  		= $value->tipo_cobranca;
				$registros[$key]['meio_pagamento']   	  		= $value->meio_pagamento;
				$registros[$key]['endereco']     	 	  		= $value->endereco;
				$registros[$key]['numero']           	  		= $value->numero;
				$registros[$key]['complemento']      	  		= $value->complemento;
				$registros[$key]['bairro']           	  		= $value->bairro;
				$registros[$key]['cidade']           	  		= $value->cidade;
				$registros[$key]['estado']           	  		= $value->estado;
				$registros[$key]['cep']              	  		= $value->cep;
			}
			
			$return_remessa = $remessa_banco->setDetalhe($registros)->BuiltFile();
			return $return_remessa;
		}

		function remessapagamento(){
			if(isset($_POST['meio_pagamento'])){
				$meio_pagamento = $_POST['meio_pagamento'];
			}
			
			if(isset($_POST['vencimento_de']) && !empty($_POST['vencimento_de'])){
				$dt_ini = new DateTime(convertDate($_POST['vencimento_de']));
			}else{
				$dt_ini = getDataAtual();
				//  $dt_ini = new DateTime('2020-01-01');
			}
			
			if(isset($_POST['vencimento_ate']) && !empty($_POST['vencimento_ate'])){
				$dt_fim = new DateTime(convertDate($_POST['vencimento_ate']));
			}else{
				$dt_fim = getDataAtual();
				$dt_fim->add(new DateInterval('P7D'));
			}

			$despesas = json_decode($this->modelo->getDespesasToRemessa(null, $dt_ini->format('Y-m-d'), $dt_fim->format('Y-m-d'), 'aprovado', array('pendente', 'error'), 'aberto'));
			require_once ABSPATH . '/views/'.$this->nome_view.'/listar-despesas-remessa-view.php';
		}

		function checkRemessaEnvio(){
			$remessas = json_decode($this->arquivo_model->getRemessaByStatus("pendente","remessa","pagamento"));
			if ($remessas){
				foreach ($remessas as $key => $value) {
					$path_file =
						REMESSAS_ABSPATH .
						DS .
						"bradesco" .
						DS .
						"pagamento" .
						DS .
						"saida" .
						DS .
						$value->nome_arquivo;
					if (!file_exists($path_file)) {
						$param["status"] = "enviado";
						$save = $this->arquivo_model->save($param, $value->id);
					}
				}
			}
		}

		function checkRetornoRemessa(){
			$path_processar   = REMESSAS_ABSPATH."bradesco".DS."pagamento".DS."entrada".DS;
			$path_processados = REMESSAS_ABSPATH."bradesco".DS."pagamento".DS."processados".DS;
			$diretorio = dir( $path_processar );
			if ( $diretorio ){
				$lista_despesas = null;
				ob_implicit_flush(true);
				while(ob_get_level() > 0) ob_end_clean();
				$this->cmsw_model = $this->load_Model( "cmsw/cmsw", true );
				while ( $arquivo = $diretorio->read() ){
					// verificar se o nome do arquivo é valido
					if (
						$arquivo != "." &&
						$arquivo != ".." &&
						$arquivo != "RESTART"
					){
						$path = $path_processar . $arquivo;
						echo "processando arquivo $path .... <br>";
						//le a primeira linha do arquivo para identificar a remessa
						$file_handle = fopen($path, "r");
						$count_line  = 0;
						//lendo linha do arquivo
						while ( !feof( $file_handle ) ){
							$line 			= fgets( $file_handle );
							$data_pagamento = null;
							$id_documento 	= null;
							if( $count_line == 0 ){
								// echo "Linha Header.... $line <br>";
								//pegando codigo dados do banco e da empresa cm do arquivo
								$codigo_banco = substr( $line, 0, 3 );
								$tipo_empresa = substr( $line, 17, 1 );
								$cnpj_cpf     = substr( $line, 18, 14 );
								$nome_empresa = substr( $line, 72, 30 );
								// consulta os dados do cadastro da empresa cm
								$conta_bancaria = json_decode($this->cmsw_model->getContaDefaultCm($cnpj_cpf));
								$dados_banco = null;
								if( $conta_bancaria ){
									$dados_banco['codigo_banco']   = $conta_bancaria[0]->codigo_banco;
									$dados_banco['nome_banco']     = $conta_bancaria[0]->nome_reduzido;
									$dados_banco['tipo_inscricao'] = '2';
									$dados_banco['tipo_conta']     = $conta_bancaria[0]->codigo_banco;
									$dados_banco['agencia']        = $conta_bancaria[0]->numero_agencia;
									$dados_banco['agencia_dig'] = $conta_bancaria[0]->digito_agencia;
									$dados_banco['conta'] = $conta_bancaria[0]->numero_conta;
									$dados_banco['dig_conta'] = $conta_bancaria[0]->digito_conta;
									$dados_banco['codigo_convenio'] = $conta_bancaria[0]->codigo_convenio_cnab240;
									$dados_banco['id_empresa'] = $conta_bancaria[0]->id;
									$dados_banco['cnpj_cpf'] = $conta_bancaria[0]->cnpj;
									$dados_banco['razao_social'] = $conta_bancaria[0]->razao_social;
									$dados_banco['email'] = $conta_bancaria[0]->email;
									$dados_banco['logradouro'] = $conta_bancaria[0]->endereco;
									$dados_banco['numero'] = $conta_bancaria[0]->numero;
									$dados_banco['complemento'] = $conta_bancaria[0]->complemento;
									$dados_banco['bairro'] = $conta_bancaria[0]->bairro;
									$dados_banco['cidade'] = $conta_bancaria[0]->cidade;
									$dados_banco['uf'] = $conta_bancaria[0]->estado;
									$dados_banco['cep'] = $conta_bancaria[0]->cep;
									$dados_banco['tipo_arquivo'] = null;
									$dados_banco['modalidade'] = null;
								}

								switch ( $codigo_banco ){
									case "237";
										$obj_bradesco = new RemessaBradesco( $this, $dados_banco, false );
									break;
									case "341";
										// implementar
									break;
								}
							}else{
								$tipo_linha   = substr( $line, 7, 1 );
								$id_documento = null;
								switch ( $tipo_linha ){
									case '1':
										// Linha de inicio de lote
									break;
									case '3':
										$segmento    = substr( $line, 13, 1 );
										$ocorrencias = substr( $line, 230, 10 );
										$ocorrencias = str_split( $ocorrencias, 2 );
										switch ( $segmento ){
											case 'A':
												$data_pagamento = substr( $line, 154, 8 );
												$id_documento   = substr( $line, 73, 20 );
											break;
											case 'J':
												$data_pagamento = substr( $line, 144, 8 );
												$id_documento   = substr( $line, 182, 20 );
												if( substr( $line, 17, 2 ) == '52' ){
													$id_documento = null;
												}
											break;
											case 'N':
												$data_pagamento = substr( $line, 87, 8 );
												$id_documento   = substr( $line, 17, 20 );
											break;
											case 'O':
												$data_pagamento = substr( $line, 99, 8 );
												$id_documento   = substr( $line, 122, 20 );
											break;
										}

										if( !empty( trim( $id_documento ) ) && !empty( $ocorrencias ) ){
											if( $id_documento && is_numeric( trim( $id_documento ) ) ){
												$dados_despesa = json_decode( $this->modelo->getDespesaByIdDoc( trim( $id_documento ) ) );
												if( $dados_despesa ){
													switch ( $dados_despesa[0]->status ){
														case 'aberto':
															$i = $dados_despesa[0]->id;
															foreach( $ocorrencias as $key => $value ){
																if( !empty( trim( $value ) ) ){
																	$lista_despesas[$i]['id_doc'] 						     = trim( $id_documento );
																	$lista_despesas[$i]['data_pagamento'] 					 = $data_pagamento;
																	$lista_despesas[$i]['fornecedor'] 						 = $dados_despesa[0]->nome_fornecedor;
																	$lista_despesas[$i]['ocorrencias']['cod_numero'][$value] = $value;
																	$lista_despesas[$i]['ocorrencias']['cod_texto'][$value]  = $obj_bradesco->codigo_ocorrencias[$value];
																}
															}
														break;
													}
												}
											}
										}
									break;
									case '5':
										// Linha de fim de lote
									break;
								}
							}
							$count_line++;
						}
						flush();
						fclose( $file_handle );
						$is_move = rename( $path, $path_processados.$arquivo );
					}
				}
				
				if( $lista_despesas ){
					foreach ( $lista_despesas as $key => $value ){
						$value['status'] = null;
						if( in_array('00', $value['ocorrencias']['cod_numero'] ) ){
							$value['status'] = 'finalizado';
						}elseif( in_array('BD', $value['ocorrencias']['cod_numero'] ) ){
							$value['status'] = 'processado';
						}else{
							$value['status'] = 'erro';
						}
						$lista_despesas[$key]['status'] = $value['status'];
					}

					foreach ( $lista_despesas as $key => $value ){
						$data_pagamento = null;
						$param_save 	= null;
						switch ( $value['status'] ){
							case 'finalizado':
								$param_save['status_remessa'] = 'finalizado';
								$param_save['status']         = 'pago';
								if( $value['data_pagamento'] ){
									$data_pagamento               = getDataAtual( $value['data_pagamento'], 'DMY' );
									$param_save['data_pagamento'] = $data_pagamento->format('Y-m-d');
								}else{
									$param_save['data_pagamento'] = $this->data_hora_atual->format('Y-m-d');
								}
								$mensagem = "Processamento Bradesco despesa ID: $key Fornecedor: ".$value['fornecedor']." Status: ".$value['ocorrencias']['cod_texto']['00']."<br>";
							break;
							case 'processado':
								$param_save['status_remessa'] = 'processado';
								$mensagem = "Processamento Bradesco despesa ID: $key Fornecedor: ".$value['fornecedor']." Status: ".$value['ocorrencias']['cod_texto']['BD']."<br>";
							break;
							default:
								$param_save['status_remessa'] = 'error';
								$mensagem = "Processamento Bradesco despesa ID: $key Fornecedor: ".$value['fornecedor']."<br>";
								foreach ( $value['ocorrencias']['cod_numero'] as $k1 => $v1 ){
									$mensagem .= " ERRO: ".$value['ocorrencias']['cod_numero'][$k1]."<br>";
								}
							break;
						}

						$is_save = $this->modelo->save( $param_save, $key );
						if( $is_save ){
							$parametros['tipo_destinatario'] = 'webhook';
							if( 'producao' == TIPO_AMBIENTE ){
								$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/06b48f3c-0684-46b4-ad04-63494a706bc7@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9cb6bfbfed3d4b1e9c34f76848ba6e61/c8c7ff53-e294-4a3a-bcad-c9f04857e469';
							}else{
								$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9f2e2cc655bf4e76bfdb0531dd3a83d7/c328c206-070a-4beb-bbed-da82e018abec';
							}
							$parametros['mensagem'] = $mensagem;
							$send = $this->cl_notificacao->enviar('teams', $parametros);
						}
					}
				}
			}
		}
		
		function checkStatusDespesa(){
			try {
				if( isset( $_POST['id_despesa'] ) && !empty( $_POST['id_despesa'] ) && is_numeric( $_POST['id_despesa'] ) ){
					$dados_despesas = json_decode( $this->modelo->getDespesas( $_POST['id_despesa'] ) );
				}else{
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'ID da despesa não informada! ';
					throw new Exception( json_encode( $retorno ), 1);
				}
				
				global $lista_error;
				//caminho dir
				$lista_retorno 	= null;
				$path_root 		= ABSPATH.DS.'arquivos'.DS.'remessa'.DS.'bradesco'.DS.'pagamento'.DS.'processados';
				$conteudo 		= scandir( $path_root );
				foreach ( $conteudo as $arquivo ) {
					if ( $arquivo != '.' && $arquivo != '..' ){
						$matriz_arquivo = explode( '_', $arquivo );
						if( isset( $matriz_arquivo[1] ) && !empty( $matriz_arquivo[1] ) ){
							$matriz_data = str_split( $matriz_arquivo[1], 2 );
							$data_invert = $matriz_data[2].$matriz_data[3].'-'.$matriz_data[1].'-'.$matriz_data[0];
						}
						
						if( $dados_despesas[0]->data_vencimento == $data_invert ){
							$dados_despesas[0]->id_doc;
							$path_file 		= $path_root.DS.$arquivo;
							$fp_origem 	   	= fopen( $path_file, 'r' );
							if( $fp_origem ){
								while(!feof( $fp_origem ) ){
									$row			= fgets( $fp_origem, 1024 );
									$tipo_registro 	= substr( $row, 7, 1);
									$id_doc_len		= 20;
									$complemento 	= null;
									$ignore 	 	= false;
									switch ( $tipo_registro ) {
										case '3':
											$segmento = substr( $row, 13, 1 );
											switch ( $segmento ) {
												case 'J':
													$col_ini 	 = 202;
													$complemento = substr( $row, 17, 2 );
												break;
												case 'O':
													$col_ini = 142;
												break;
												case 'N':
													$col_ini = 37;
												break;
												case 'A':
													$col_ini = 134;
												break;
												case 'Z':
													$col_ini = 95;
													$id_doc_len = 25;
												break;
												case 'W':
												case 'H':
												case 'G':
												case 'Y':
												case 'B':
												case 'C':
												case '5':
													$ignore = true;
												break;
											}
											
											if( $ignore == false && $complemento != 52 ){
												$id_doc = trim( substr( $row, $col_ini, $id_doc_len ) );
												if( (int)$dados_despesas[0]->id_doc == (int) $id_doc ){
													$erros = str_split( substr( $row, 230, 10 ), 2);
													foreach ( $erros as $key => $value ) {
														if( !empty( trim( $value ) ) || $value == "00" ){
															$lista_retorno[ $id_doc ][$arquivo][ $value ] = $lista_error[ $value ];
														}
													}
												}
											}
										break;
									}
								}
							}
						}	
					}
				}

				if( count( $lista_retorno ) > 0 ){
					$retorno['codigo']   = 0;
					$retorno['output']   = $lista_retorno;
					$retorno['mensagem'] = 'Sucesso'.PHP_EOL;
					throw new Exception( json_encode( $retorno ), 1);
				}else{
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Nenhum arquivo de retorno encontrado para essa despesa';
					throw new Exception( json_encode( $retorno ), 1);
				}
			} catch ( Exception $e ) {
				echo $e->getMessage();
			}
		}

		function reordenarRemessa(){
			try {
				if(!isset($_POST['despesas']) || count($_POST['despesas']) < 1){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Informe as despesas';
					throw new Exception(json_encode($retorno), 1);
				}

				foreach($_POST['despesas'] as $key => $value){
					$dados_despesa = json_decode( $this->modelo->getById( $value ) );
					$last_iddoc    = json_decode( $this->modelo->getLastIdDoc() );
					if( !$dados_despesa ){
						$retorno['codigo']   = 1;
						$retorno['input']    = $_POST;
						$retorno['output']   = $last_iddoc;
						$retorno['mensagem'] = 'Despesa ID '.$value.' não encontrada';
						throw new Exception(json_encode($retorno), 1);
					}
					
					if( $last_iddoc ){
						$iddoc = $last_iddoc[0]->id_doc;
					}else{
						$retorno['codigo']   = 1;
						$retorno['input']    = $_POST;
						$retorno['output']   = $last_iddoc;
						$retorno['mensagem'] = 'Não foi possivel encontrar o ultimo ID DOC';
						throw new Exception(json_encode($retorno), 1);
					}
					
					$param_new = null;
					$iddoc++;
					foreach( $dados_despesa[0] as $k1 => $v1 ){
						$param_new[$k1] = $v1;
					}

					$param_new['id_doc'] = $iddoc;
					unset( $param_new['id'] );
					if( $param_new ){
						$param_old['deleted'] = 1;
						$is_saveold = $this->modelo->save( $param_old, $value );
						if( $is_saveold ){
							$is_savenew = $this->modelo->save($param_new);
							if( !$is_savenew ){
								$retorno['codigo']   = 1;
								$retorno['input']    = $_POST;
								$retorno['output']   = $is_savenew;
								$retorno['mensagem'] = 'Erro ao criar despesa nova';
								throw new Exception(json_encode($retorno), 1);
							}
						}else{
							$retorno['codigo']   = 1;
							$retorno['input']    = $_POST;
							$retorno['output']   = $is_saveold;
							$retorno['mensagem'] = 'Erro ao apagar despesa antiga';
							throw new Exception(json_encode($retorno), 1);
						}
					}else {
						$retorno['codigo']   = 1;
						$retorno['input']    = $_POST;
						$retorno['output']   = $param_new;
						$retorno['mensagem'] = 'Erro ao criar novos parametros';
						throw new Exception(json_encode($retorno), 1);
					}
				}
				// Caso não ocorra nenhum erro retorna sucesso
				$retorno['codigo']   = 0;
				$retorno['input']    = $_POST;
				$retorno['output']   = null;
				$retorno['mensagem'] = 'Despesas reordenadas com sucesso';
				throw new Exception(json_encode($retorno), 1);
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function viewImportFolha(){
			require_once ABSPATH ."/views/".$this->nome_view."/importfile-view.php";
		}

		function processaFile(){
			$result = json_decode( $this->importFile() );
			require_once ABSPATH ."/views/".$this->nome_view."/result-import-view.php";
		}

		function importFile(){
			try{
				
				// if(!isset($_POST['id_subconta']) || empty($_POST['id_subconta'])){
				//     $retorno['codigo']   = 0;
				//     $retorno['input']    = $_FILES;
				//     $retorno['output']   = null;
				//     $retorno['mensagem'] = "Informe a subconta do arquivo";
				//     throw new Exception(json_encode($retorno), 1);
				// }

				if(!isset($_FILES) || count($_FILES) < 1){
					$retorno['codigo']   = 0;
					$retorno['input']    = $_FILES;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Arquivo para upload não informado";
					throw new Exception(json_encode($retorno), 1);
				}
							
				if(!file_exists($_FILES['arquivo']['tmp_name'])){
					$retorno['codigo']   = 0;
					$retorno['input']    = $_FILES;
					$retorno['output']   = null;
					$retorno['mensagem'] = "Erro no upload do arquivo, tipo de arquivo";
					throw new Exception(json_encode($retorno), 1);
				}

				$obj_upload = new Upload( $this, $_FILES['arquivo'] );
				$linhas  	= json_decode( $obj_upload->readFile() );
				if($linhas->codigo == 0){
					$count = 0;
					foreach( $linhas->output as $key => $value ){
						$value = utf8_decode($value);
						if($count > 3){ // pular o cabeçalho do arquivo
							$colab = explode(';', $value);
							$enconding_nome = mb_detect_encoding($colab[2]);
							
							if( $enconding_nome === false ){
								$colab[2] = utf8_encode($colab[2]);
							}

							if( isset( $colab[0] ) && !empty( $colab[2] ) ){						
								$cpf = removeCaracteres( $colab[3], 'cpf' );
								if( strlen( $cpf ) < 11 ){
									$lancamentos[$cpf]['cpf'] = str_pad( $cpf, 11, '0', STR_PAD_LEFT);
								}else{
									$lancamentos[$cpf]['cpf'] = $cpf;
								}
								$lancamentos[$cpf]['nome']       = $colab[2];
								$lancamentos[$cpf]['valor']      = $colab[4];
								$lancamentos[$cpf]['vencimento'] = $colab[5];
								if( validar( $lancamentos[$cpf]['cpf'], 'cpf' ) ){
									$fornecedor = json_decode( $this->fornecedor->getFornecedoresByCpfCnpj( $lancamentos[$cpf]['cpf'] ) );							
									if( $fornecedor ){
										$chk_lancamento = json_decode( $this->modelo->getDespesaByFornecedor( $fornecedor[0]->id, convertDate( $colab[5] ), removeCaracteres($colab[4], 'moeda2' ) ) );
										if( !$chk_lancamento ){
											// $depto   = $colab[0];
											// $dep_ini = ( stripos( $depto, '- ') + 2 );
											// $abdep   = substr( $depto, $dep_ini, 5 );
											$param['id_centro_custo'] = null;
											switch ( $colab[0] ) {
												case 'ADMIN':
													$param['id_centro_custo'] = 2;
												break;
												case 'MARKE':
													$param['id_centro_custo'] = 4;
												break;
												case 'COMER':
													$param['id_centro_custo'] = 3;
												break;
												case 'OPERA':
													$param['id_centro_custo'] = 5;
												break;
												case 'SUPOR':
													$param['id_centro_custo'] = 5;
												break;
												case 'MODEL':
													$param['id_centro_custo'] = 6;
												break;
												case 'PRESI':
													$param['id_centro_custo'] = 1;
												break;
												case 'DESEN':
													$param['id_centro_custo'] = 5;
												break;
												case 'JURID':
													$param['id_centro_custo'] = 2;
												break;
												case 'PRODU':
													$param['id_centro_custo'] = 1000001;
												break;
											}
											//VERIFICA ID SUBCONTA
											switch (trim(strtolower($colab[1]))) {
												case 'salario':
													$param['id_subconta']   = "61";
													$param['tipo_cobranca'] = 'salario';
												break;
												case 'adiantamento':
													$param['id_subconta']   = "167";
													$param['tipo_cobranca'] = 'adiantamento';
												break;
												case 'recisao':
												case 'recisão':
													$param['id_subconta']   = "206";
													$param['tipo_cobranca'] = 'salario';
												break;
												case 'ferias':
												case 'férias':
													$param['id_subconta']   = "64";
													$param['tipo_cobranca'] = 'salario';
												break;
												case 'vale refeicao':
												case 'vale refeição':
												case 'vale refeicão':
													$param['id_subconta']   = "33";
													$param['tipo_cobranca'] = 'beneficio';
												break;
												case 'vale transporte':
													$param['id_subconta']   = "34";
													$param['tipo_cobranca'] = 'beneficio';
												break;
												case 'estacionamento':
													$param['id_subconta']   = "30";
													$param['tipo_cobranca'] = "outros";
												break;
												case '13 primeira parcela':
												case '13° primeira parcela':
													$param['id_subconta']   = "2000000";
													$param['tipo_cobranca'] = 'salario';
												break;
												case '13 segunda parcela':
												case '13° segunda parcela':
													$param['id_subconta']   = "2000001";
													$param['tipo_cobranca'] = 'salario';
												break;
												case '14 primeira parcela':
												case '14° primeira parcela':
													$param['id_subconta']   = "5000014";
													$param['tipo_cobranca'] = 'salario';
												break;
												case '14 segunda parcela':
												case '14° segunda parcela':
													$param['id_subconta']   = "5000015";
													$param['tipo_cobranca'] = 'salario';
												break;										
												default:
													$param['id_subconta']   = "61";
													$param['tipo_cobranca'] = 'outros';
												break;
											}
																			
											switch ($param['id_subconta']) {
												// Vare refeição, beneficios
												case '30':
												case '33':
												case '34':
													$param['id_conta'] = 4;
												break;
												default:
													$param['id_conta'] = 13;
												break;
											}
											
											$param['id_cm']      		 = $_POST['id_cm'];
											$param['id_fornecedor']      = $fornecedor[0]->id;
											$param['tipo_despesa']       = $_POST['tipo_despesa'];
											$param['meio_pagamento']     = 'transferencia';
											$param['valor']              = $colab[4];
											$param['data_vencimento']    = $colab[5];
											$param['id_grupo']           = 1;
											// $param['id_subconta']        = $_POST['id_subconta'];
											$param['tipo']               = 'global';
											$param['prioridade']         = 'primaria';
											$param['status']             = 'aberto';
											$param['requer_autorizacao'] = 1;
											$param['status_autorizacao'] = 'pendente';
											$param['status_remessa']     = 'pendente';
											$param['prioridade']         = 'primaria';
											$param['deleted']            = 0;
											$param['tipo_arquivo']		 = trim($colab[1]);
											$is_save = json_decode( $this->class_despesa->insert( $param ) );
											if( $param['id_centro_custo'] ){
												if( $is_save->codigo == 0 ){
													$lancamentos[$cpf]['status']   = 'sucesso';
													$lancamentos[$cpf]['mensagem'] = "Pagamento incluido com sucesso";
												}else{
													$lancamentos[$cpf]['status']   = 'erro';
													$lancamentos[$cpf]['mensagem'] = $is_save->mensagem;
												}
											}else{
												$lancamentos[$cpf]['status']   = 'erro';
												$lancamentos[$cpf]['mensagem'] = 'CENTRO DE CUSTO NÃO ENCONTRADO';
											}
										}else{
											$lancamentos[$cpf]['status']   = 'erro';
											$lancamentos[$cpf]['mensagem'] = 'Lançamento duplicado';
										}
									}else{
										$lancamentos[$cpf]['status']   = 'erro';
										$lancamentos[$cpf]['mensagem'] = 'Dados do colaborador não encontrado';
									}
								}else{
									$lancamentos[$count]['status']   = 'erro';
									$lancamentos[$count]['mensagem'] = 'CPF invalido';
								}
							}				
						}					
						$count++;
					}
					
					$retorno['codigo']   = 0;
					$retorno['input']    = $_FILES;
					$retorno['output']   = $lancamentos;
					$retorno['mensagem'] = 'Sucesso';				
					throw new Exception(json_encode($retorno), 1);
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $_FILES;
					$retorno['output']   = $linhas;
					$retorno['mensagem'] = $linhas->mensagem;
					throw new Exception(json_encode($retorno), 1);
				}
			}catch (Exception $e){
				return $e->getMessage();
			}
		}

		function reordenarIdDoc(){
			try {
				if( isset( $this->parametros['1'] ) && !empty( $this->parametros['1'] ) && is_numeric( $this->parametros['1'] ) ){
					$id_despesa = $this->parametros['1'];
				}elseif( isset( $_POST['id_despesa'] ) && !empty( $_POST['id_despesa'] ) && is_numeric( $_POST['id_despesa'] ) ){
					$id_despesa = $_POST['id_despesa'];
				}

				if( !isset( $id_despesa ) || empty( $id_despesa ) || !is_numeric( $id_despesa ) ){
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Informe a despesa';
					throw new Exception( json_encode( $retorno ), 1);
				}

				$dados_despesa = json_decode( $this->modelo->getById( $id_despesa ) );
				$ultimo_doc = json_decode( $this->modelo->getLastIdDoc() );
				if( $dados_despesa  && $ultimo_doc ){
					foreach ( $dados_despesa as $key => $value ) {
						foreach ( $value as $k1 => $v1 ) {
							$nova_despesa[ $k1 ] = $v1;
						}
					}

					$nova_despesa['id_doc'] = ( $ultimo_doc[0]->id_doc + 1 );
					$param_delete['deleted'] = 1;
					unset( $nova_despesa['id'] );
					$is_deleted = $this->modelo->save( $param_delete, $dados_despesa[0]->id );
					if( $is_deleted ){
						$is_save = $this->modelo->save( $nova_despesa );
						if( $is_save ){
							$retorno['codigo']   = 0;
							$retorno['mensagem'] = 'Sucesso novo ID DOC: '.$nova_despesa['id_doc'];
							throw new Exception( json_encode( $retorno ), 1);
						}else{
							$retorno['codigo']   = 1;
							$retorno['mensagem'] = ' Erro ao gravar nova despesa';
							throw new Exception( json_encode( $retorno ), 1);
						}
					}else{
						$retorno['codigo']   = 1;
						$retorno['mensagem'] = 'Erro ao renovar id doc despesa';
						throw new Exception( json_encode( $retorno ), 1);
					}
				}else{
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Despesa ou ultimo doc não encontrada';
					throw new Exception( json_encode( $retorno ), 1);
				}
			} catch ( Exception $e ) {
				echo $e->getMessage();
			}
		}
	}