<?php

class EmpresasController extends MainController{
	function __construct($parametros = null){
		$this->setModulo('empresas');
		$this->setView('empresas');
		parent::__construct($parametros);
    }

	function setObjectEmail(){
		$this->obj_email = new Email();	
	}

	function index(){
		$this->lista();
	}

	function lista(){
		$records  = json_decode($this->modelo->getEmpresa());
		require_once ABSPATH . '/views/'.$this->nome_view.'/empresas-view.php';
	}

	function detalhe(){
		if(isset($this->parametros[1]) && !empty($this->parametros[1])){
			$records  = json_decode($this->modelo->getEmpresa($this->parametros[1]));
		}
		require_once ABSPATH . '/views/'.$this->nome_view.'/empresas-detalhe-view.php';
	}
	
	function save(){
		$id_empresa = $this->parametros[1];
		$_POST['cnpj'] = removeCaracteres($_POST['cnpj'], 'char', null);
		$_POST['inscricao_estadual'] = removeCaracteres($_POST['inscricao_estadual'], true, null);
		$_POST['inscricao_municipal'] = removeCaracteres($_POST['inscricao_municipal'], true, null);
		$_POST['cep'] = removeCaracteres($_POST['cep'], 'char');
		$is_save = $this->modelo->save($_POST, $this->parametros[1]);
		if($is_save){
			header('location: /empresas/detalhe/id/'.$this->parametros[1]);
		}else{
			echo 'Erro ao salvar dados da empresa';
			exit;
		}
	}
}
?>
