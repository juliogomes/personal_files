<?php

class ExectaskController extends MainController
{
    function __construct($parametros = null)
    {
        parent::__construct($parametros);
    }

    function index()
    {
        $controller = new MainController(null, 'logacesso', false);
        $this->modelo = $controller->load_model('tasks/tasks', true);
        $tasks = new Tasks($this, 'FAT0002');
        $tasks->Exec('FAT0002');
    }

}
?>