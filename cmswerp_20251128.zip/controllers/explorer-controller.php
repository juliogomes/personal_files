<?php
    // app/Controllers/ExplorerController.php
    class ExplorerController extends MainController {
        protected $baseDir;
        protected $maxUpload = 10485760; // 10 MB
        protected $allowedExt = array('txt','pdf','jpg','jpeg','png','gif','zip','csv','xls','xlsx','doc','docx','json','html','css','js','php','env','ini','conf','log','pem','key','sql','sh');
        protected $sensitiveExt = array('env','key','pem'); // nunca edite estas sem confirmar
        protected $protectedDirs = array('app','config','controllers','models','views','vendor','core','.git'); // acesso com restrições
        protected $trashDir;
        protected $backupDir;
        protected $rateLimitMax = 60; // ações
        protected $rateLimitWindow = 60; // segundos

        function __construct($parametros = false){
            $this->setModulo('explorer');
            $this->setView('explorer');
            parent::__construct($parametros);

            // OPÇÃO D: acesso ao servidor inteiro — mas nós limitamos ações perigosas por padrão
            $this->baseDir = defined('ABSPATH') ? ABSPATH : realpath(__DIR__ . '/../../');
            // diretório da lixeira e backups (ocultos no ABSPATH)
            $this->trashDir = rtrim($this->baseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . '.fm_trash';
            $this->backupDir = rtrim($this->baseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . '.fm_backups';

            if (!is_dir($this->trashDir)) @mkdir($this->trashDir, 0755, true);
            if (!is_dir($this->backupDir)) @mkdir($this->backupDir, 0755, true);

            if (session_id() === '') session_start();
        }

        /* ---------- Segurança / utilitários ---------- */

        protected function isAllowed(){
            // Integrado ao seu sistema: aqui você já tinha a checagem para master
            return isset($_SESSION['cmswerp']['userdata']->master) && $_SESSION['cmswerp']['userdata']->master == 1;
        }

        // CSRF duplo: token + timestamp
        protected function genCsrf(){
            if (empty($_SESSION['_fm_csrf_token'])) {
                if (function_exists('random_bytes')) $_SESSION['_fm_csrf_token'] = bin2hex(random_bytes(16));
                elseif (function_exists('openssl_random_pseudo_bytes')) $_SESSION['_fm_csrf_token'] = bin2hex(openssl_random_pseudo_bytes(16));
                else $_SESSION['_fm_csrf_token'] = bin2hex(md5(uniqid(mt_rand(), true)));
                $_SESSION['_fm_csrf_time'] = time();
            }
            return $_SESSION['_fm_csrf_token'];
        }

        protected function checkCsrf($token){
            if (!isset($_SESSION['_fm_csrf_token']) || !isset($_SESSION['_fm_csrf_time'])) return false;
            $ok = (function_exists('hash_equals') ? hash_equals($_SESSION['_fm_csrf_token'], (string)$token) : ($_SESSION['_fm_csrf_token'] === $token));
            // tempo máximo: 30 minutos
            $fresh = (abs(time() - intval($_SESSION['_fm_csrf_time'])) <= 1800);
            return ($ok && $fresh);
        }

        // rate-limit simples por sessão
        protected function rateLimitCheck(){
            if (!isset($_SESSION['_fm_rate'])) $_SESSION['_fm_rate'] = array();
            // limpar antigas
            $now = time();
            $_SESSION['_fm_rate'] = array_filter($_SESSION['_fm_rate'], function($t) use ($now) {
                return ($t + $this->rateLimitWindow) >= $now;
            });
            if (count($_SESSION['_fm_rate']) >= $this->rateLimitMax) return false;
            $_SESSION['_fm_rate'][] = $now;
            return true;
        }

        // transforma um caminho relativo em absoluto e valida prefixo
        protected function safePath($rel){
            $rel = (string)$rel;
            // permitir vazio => base
            if ($rel === '' || $rel === null) return rtrim($this->baseDir, DIRECTORY_SEPARATOR);
            // normaliza barras
            $rel = str_replace(array('/', '\\'), DIRECTORY_SEPARATOR, $rel);
            $rel = ltrim($rel, DIRECTORY_SEPARATOR);
            $candidate = rtrim($this->baseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $rel;
            $realBase = realpath($this->baseDir);
            // se existir, use realpath do candidate
            $realCand = realpath($candidate);
            if ($realCand !== false) {
                if (strpos($realCand, $realBase) === 0) return $realCand;
                return false;
            }
            // para caminhos não existentes (criação), normalizar manualmente
            $parts = array();
            foreach (explode(DIRECTORY_SEPARATOR, $candidate) as $seg) {
                if ($seg === '' || $seg === '.') continue;
                if ($seg === '..') { array_pop($parts); } else { $parts[] = $seg; }
            }
            $normalized = DIRECTORY_SEPARATOR . ltrim(implode(DIRECTORY_SEPARATOR, $parts), DIRECTORY_SEPARATOR);
            // compara prefixo (coloca realBase no começo)
            $final = $realBase . DIRECTORY_SEPARATOR . ltrim(str_replace($realBase, '', $normalized), DIRECTORY_SEPARATOR);
            if (strpos($final, $realBase) === 0) return $final;
            return false;
        }

        protected function humanFileSize($size){
            if ($size <= 0) return '0 B';
            $units = array('B','KB','MB','GB','TB');
            $p = floor(log($size, 1024));
            return round($size / pow(1024, $p), 2) . ' ' . $units[$p];
        }

        protected function rrmdir($dir){
            if (!is_dir($dir)) return;
            $items = scandir($dir);
            foreach ($items as $it) {
                if ($it === '.' || $it === '..') continue;
                $p = $dir . DIRECTORY_SEPARATOR . $it;
                if (is_dir($p)) $this->rrmdir($p);
                else @unlink($p);
            }
            @rmdir($dir);
        }

        protected function inProtectedDir($path){
            // retorna true se o path (absoluto) estiver dentro de qualquer protectedDir
            $realBase = realpath($this->baseDir);
            foreach ($this->protectedDirs as $d) {
                $cand = realpath($realBase . DIRECTORY_SEPARATOR . $d);
                if ($cand !== false && strpos($path, $cand) === 0) return true;
            }
            return false;
        }

        protected function ext($path){
            return strtolower(pathinfo($path, PATHINFO_EXTENSION));
        }

        protected function logAction($action, $target){
            try {
                if (class_exists('App\Helpers\Logger')) {
                    \App\Helpers\Logger::info("[Explorer] {$action} -> {$target}");
                } else if (class_exists('Logger')) {
                    \Logger::info("[Explorer] {$action} -> {$target}");
                } else {
                    // fallback: session log (não ideal)
                    if (!isset($_SESSION['_fm_plainlog'])) $_SESSION['_fm_plainlog'] = array();
                    $_SESSION['_fm_plainlog'][] = date('Y-m-d H:i:s') . " {$action} -> {$target}";
                }
            } catch (Exception $e) { /* ignore */ }
        }

        protected function moveToTrash($path){
            // cria pasta dentro de .fm_trash com timestamp e move
            if (!file_exists($path)) return false;
            $now = date('Ymd_His');
            $rel = ltrim(str_replace(realpath($this->baseDir), '', $path), DIRECTORY_SEPARATOR);
            $trashSub = $this->trashDir . DIRECTORY_SEPARATOR . $now;
            if (!is_dir($trashSub)) @mkdir($trashSub, 0755, true);
            $dest = $trashSub . DIRECTORY_SEPARATOR . str_replace(DIRECTORY_SEPARATOR, '__', $rel);
            if (@rename($path, $dest)) return $dest;
            return false;
        }

        /* ---------- Actions (public) ---------- */

        // index - lista
        public function index(){
            $this->setView('explorer');
            if (!$this->isAllowed()) { $this->forbidden(); }

            $rel = isset($_GET['p']) ? $_GET['p'] : '';
            $rel = trim($rel, "/\\");
            $items = $this->listDir($rel);
            $csrf = $this->genCsrf();

            foreach (compact('items','rel','csrf') as $k=>$v) { $$k = $v; }
            $baseDir = $this->baseDir;
            $humanFileSize = array($this,'humanFileSize');
            require_once ABSPATH . '/views/' . $this->nome_view . '/index.php';
        }

        // upload
        public function upload(){
            if (!$this->isAllowed()) $this->forbidden();
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') $this->redirect();
            if (!$this->rateLimitCheck()) { $this->flash('Muitas requisições. Aguarde.', 'danger'); $this->redirect(); }
            if (!$this->checkCsrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) { $this->flash('CSRF inválido', 'danger'); $this->redirect(); }

            $rel = isset($_GET['p']) ? $_GET['p'] : '';
            $targetDir = $this->safePath($rel);
            if ($targetDir === false || !is_dir($targetDir)) { $this->flash('Pasta inválida', 'danger'); $this->redirect(); }

            // se for protected dir, proibir upload
            if ($this->inProtectedDir($targetDir)) {
                $this->flash('Upload proibido em pastas protegidas.', 'danger'); $this->redirect();
            }

            if (empty($_FILES['file'])) { $this->flash('Nenhum arquivo enviado', 'warning'); $this->redirect(); }
            $file = $_FILES['file'];
            if ($file['error'] !== UPLOAD_ERR_OK) { $this->flash('Erro no upload', 'danger'); $this->redirect(); }
            if ($file['size'] > $this->maxUpload) { $this->flash('Arquivo excede limite', 'danger'); $this->redirect(); }

            $ext = $this->ext($file['name']);
            // bloquear upload de arquivos executáveis perigosos (por padrão)
            if (in_array($ext, array('php','phtml','phar','exe','sh'))) {
                $this->flash('Upload de arquivo executável não permitido.', 'danger'); $this->redirect();
            }

            $dest = $targetDir . DIRECTORY_SEPARATOR . basename($file['name']);
            if (@move_uploaded_file($file['tmp_name'], $dest)) {
                @chmod($dest, 0644);
                $this->logAction('upload', $dest);
                $this->flash('Upload concluído', 'success');
            } else {
                $this->flash('Falha ao salvar arquivo', 'danger');
            }
            $this->redirect();
        }

        // create folder
        public function createFolder(){
            if (!$this->isAllowed()) $this->forbidden();
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') $this->redirect();
            if (!$this->checkCsrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) { $this->flash('CSRF inválido', 'danger'); $this->redirect(); }

            $rel = isset($_GET['p']) ? $_GET['p'] : '';
            $name = isset($_POST['folder_name']) ? trim($_POST['folder_name']) : '';
            if ($name === '') { $this->flash('Nome vazio', 'warning'); $this->redirect(); }

            $name = str_replace(array('/','\\','..'), '', $name);
            $target = $this->safePath(($rel === '' ? '' : $rel . DIRECTORY_SEPARATOR) . $name);
            if ($target === false) { $this->flash('Caminho inválido', 'danger'); $this->redirect(); }

            if ($this->inProtectedDir($target)) { $this->flash('Criação proibida em pasta protegida', 'danger'); $this->redirect(); }

            if (!file_exists($target)) {
                if (@mkdir($target, 0755, true)) {
                    $this->logAction('create_folder', $target);
                    $this->flash('Pasta criada', 'success');
                } else $this->flash('Falha ao criar pasta', 'danger');
            } else $this->flash('Pasta já existe', 'warning');
            $this->redirect();
        }

        // delete -> move to trash (salva backup)
        public function delete(){
            if (!$this->isAllowed()) $this->forbidden();
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') $this->redirect();
            if (!$this->checkCsrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) { $this->flash('CSRF inválido', 'danger'); $this->redirect(); }
            if (!$this->rateLimitCheck()) { $this->flash('Muitas requisições. Aguarde.', 'danger'); $this->redirect(); }

            $target = isset($_POST['target']) ? $_POST['target'] : '';
            $path = $this->safePath($target);
            if ($path === false || !file_exists($path)) { $this->flash('Alvo inválido', 'danger'); $this->redirect(); }

            // se for protected, não deletar — permitir somente mover para trash se não protegido
            if ($this->inProtectedDir($path)) { $this->flash('Deleção proibida em pastas protegidas', 'danger'); $this->redirect(); }

            $moved = $this->moveToTrash($path);
            if ($moved !== false) {
                $this->logAction('delete_move_trash', $path . ' -> ' . $moved);
                $this->flash('Item movido para Lixeira', 'success');
            } else {
                $this->flash('Falha ao mover para Lixeira', 'danger');
            }
            $this->redirect();
        }

        // download
        public function download(){
            if (!$this->isAllowed()) $this->forbidden();
            $target = isset($_GET['target']) ? $_GET['target'] : '';
            $path = $this->safePath($target);
            if ($path === false || !is_file($path)) { header("HTTP/1.1 404 Not Found"); echo "Arquivo não encontrado."; exit; }

            // permitir download de tudo (mesmo arquivos protegidos). Mas auditoria
            $basename = basename($path);
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="'.rawurlencode($basename).'"');
            header('Content-Length: ' . filesize($path));
            flush();
            readfile($path);
            $this->logAction('download', $path);
            exit;
        }

        // view (images, text, pdf)
        public function view(){
            if (!$this->isAllowed()) $this->forbidden();
            $target = isset($_GET['target']) ? $_GET['target'] : '';
            $path = $this->safePath($target);
            if ($path === false || !is_file($path)) { header("HTTP/1.1 404 Not Found"); echo "Não encontrado"; exit; }

            $ext = $this->ext($path);
            if (in_array($ext, array('jpg','jpeg','png','gif'))) {
                header('Content-Type: image/' . ($ext === 'jpg' ? 'jpeg' : $ext));
                readfile($path); exit;
            } elseif ($ext === 'pdf') {
                header('Content-Type: application/pdf');
                header('Content-Disposition: inline; filename="'.rawurlencode(basename($path)).'"');
                readfile($path); exit;
            } elseif (in_array($ext, array('txt','log','csv','json','html','css','js','php'))) {
                header('Content-Type: text/plain; charset=utf-8');
                echo file_get_contents($path);
                exit;
            } else {
                $this->flash('Visualização não suportada para esta extensão', 'warning');
                $this->redirect();
            }
        }

        // rename
        public function rename(){
            if (!$this->isAllowed()) $this->forbidden();
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') $this->redirect();
            if (!$this->checkCsrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) { $this->flash('CSRF inválido', 'danger'); $this->redirect(); }

            $target = isset($_POST['target']) ? $_POST['target'] : '';
            $newname = isset($_POST['newname']) ? trim($_POST['newname']) : '';
            if ($newname === '') { $this->flash('Nome vazio', 'warning'); $this->redirect(); }

            $old = $this->safePath($target);
            if ($old === false || !file_exists($old)) { $this->flash('Alvo inválido', 'danger'); $this->redirect(); }

            if ($this->inProtectedDir($old)) { $this->flash('Renomeação proibida em pastas protegidas', 'danger'); $this->redirect(); }

            $dir = dirname($old);
            $new = $dir . DIRECTORY_SEPARATOR . str_replace(array('/','\\','..'), '', $newname);
            if (@rename($old, $new)) {
                $this->logAction('rename', $old . ' -> ' . $new);
                $this->flash('Renomeado com sucesso', 'success');
            } else $this->flash('Falha ao renomear', 'danger');
            $this->redirect();
        }

        // move
        public function move(){
            if (!$this->isAllowed()) $this->forbidden();
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') $this->redirect();
            if (!$this->checkCsrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) { $this->flash('CSRF inválido', 'danger'); $this->redirect(); }

            $target = isset($_POST['target']) ? $_POST['target'] : '';
            $destDir = isset($_POST['dest']) ? $_POST['dest'] : '';
            $src = $this->safePath($target);
            $dstDir = $this->safePath($destDir);
            if ($src === false || !file_exists($src) || $dstDir === false || !is_dir($dstDir)) {
                $this->flash('Origem ou destino inválido', 'danger'); $this->redirect();
            }

            if ($this->inProtectedDir($src) || $this->inProtectedDir($dstDir)) {
                $this->flash('Operação proibida envolvendo pastas protegidas', 'danger'); $this->redirect();
            }

            $dest = rtrim($dstDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . basename($src);
            if (@rename($src, $dest)) {
                $this->logAction('move', $src . ' -> ' . $dest);
                $this->flash('Movido com sucesso', 'success');
            } else $this->flash('Falha ao mover', 'danger');
            $this->redirect();
        }

        // editor - mostra editor para arquivos permitidos
        public function edit(){
            if (!$this->isAllowed()) $this->forbidden();
            $target = isset($_GET['target']) ? $_GET['target'] : '';
            $path = $this->safePath($target);
            if ($path === false || !is_file($path)) { $this->flash('Arquivo inválido', 'danger'); $this->redirect(); }

            // proibir edição em protected dirs ou arquivos sensíveis
            if ($this->inProtectedDir($path) || in_array($this->ext($path), $this->sensitiveExt)) {
                $this->flash('Edição proibida neste arquivo/pasta', 'danger'); $this->redirect();
            }

            $content = file_get_contents($path);
            $csrf = $this->genCsrf();
            $rel = $target;
            require_once ABSPATH . '/views/' . $this->nome_view . '/editor.php';
        }

        // save edit (faz backup automático)
        public function saveEdit(){
            if (!$this->isAllowed()) $this->forbidden();
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') $this->redirect();
            if (!$this->checkCsrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) { $this->flash('CSRF inválido', 'danger'); $this->redirect(); }

            $target = isset($_POST['target']) ? $_POST['target'] : '';
            $content = isset($_POST['content']) ? $_POST['content'] : '';
            $path = $this->safePath($target);
            if ($path === false || !is_file($path)) { $this->flash('Arquivo inválido', 'danger'); $this->redirect(); }

            if ($this->inProtectedDir($path) || in_array($this->ext($path), $this->sensitiveExt)) {
                $this->flash('Edição proibida neste arquivo/pasta', 'danger'); $this->redirect();
            }

            // backup
            $now = date('Ymd_His');
            $backupSub = $this->backupDir . DIRECTORY_SEPARATOR . str_replace(DIRECTORY_SEPARATOR,'__', ltrim(str_replace(realpath($this->baseDir),'',$path),DIRECTORY_SEPARATOR));
            $backupFile = $backupSub . '.' . $now . '.bak';
            if (!is_dir(dirname($backupFile))) @mkdir(dirname($backupFile),0755,true);
            @copy($path, $backupFile);

            if (file_put_contents($path, $content) !== false) {
                $this->logAction('edit', $path);
                $this->flash('Arquivo salvo (backup criado)', 'success');
            } else {
                $this->flash('Falha ao salvar arquivo', 'danger');
            }
            $this->redirect();
        }

        // trash view
        public function trash(){
            if (!$this->isAllowed()) $this->forbidden();
            $files = array();
            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($this->trashDir));
            foreach ($it as $f) {
                if ($f->isDir()) continue;
                $files[] = str_replace($this->trashDir . DIRECTORY_SEPARATOR, '', $f->getPathname());
            }
            $csrf = $this->genCsrf();
            require_once ABSPATH . '/views/' . $this->nome_view . '/trash.php';
        }

        // restore from trash (simple: rename back to original if path available in name)
        public function restore(){
            if (!$this->isAllowed()) $this->forbidden();
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') $this->redirect();
            if (!$this->checkCsrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) { $this->flash('CSRF inválido', 'danger'); $this->redirect(); }
            $file = isset($_POST['file']) ? $_POST['file'] : '';
            $path = realpath($this->trashDir . DIRECTORY_SEPARATOR . $file);
            if ($path === false || strpos($path, realpath($this->trashDir)) !== 0) { $this->flash('Arquivo inválido', 'danger'); $this->redirect(); }
            // tentar inferir caminho original pela primeira parte do nome (essa lógica depende de moveToTrash)
            $bn = basename($path);
            // formato: timestamp/<original-with-__replace>
            $orig = str_replace('__', DIRECTORY_SEPARATOR, preg_replace('/^\d{8}_\d{6}_?/', '', $bn));
            $dest = rtrim($this->baseDir, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . ltrim($orig, DIRECTORY_SEPARATOR);
            // se destino existe, criar com sufixo
            if (file_exists($dest)) $dest .= '.restored_' . date('Ymd_His');
            if (@rename($path, $dest)) {
                $this->logAction('restore', $path . ' -> ' . $dest);
                $this->flash('Restaurado para: ' . $dest, 'success');
            } else $this->flash('Falha ao restaurar', 'danger');
            $this->redirect();
        }

        // zip create (compactar seleção)
        public function zipCreate(){
            if (!$this->isAllowed()) $this->forbidden();
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') $this->redirect();
            if (!$this->checkCsrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) { $this->flash('CSRF inválido', 'danger'); $this->redirect(); }
            $items = isset($_POST['items']) ? (array)$_POST['items'] : array();
            $rel = isset($_POST['p']) ? $_POST['p'] : '';
            if (empty($items)) { $this->flash('Nenhum item selecionado', 'warning'); $this->redirect(); }
            $zipName = isset($_POST['zip_name']) && $_POST['zip_name'] !== '' ? preg_replace('/[^a-zA-Z0-9_\-\.]/','',$_POST['zip_name']) : 'export_' . date('Ymd_His') . '.zip';
            $zipPath = $this->safePath($rel . DIRECTORY_SEPARATOR . $zipName);
            $zip = new ZipArchive();
            if ($zip->open($zipPath, ZipArchive::CREATE) !== true) { $this->flash('Falha ao criar ZIP', 'danger'); $this->redirect(); }
            foreach ($items as $it) {
                $p = $this->safePath($it);
                if ($p === false) continue;
                if (is_dir($p)) {
                    $files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($p));
                    foreach ($files as $f) {
                        if ($f->isDir()) continue;
                        $local = str_replace(realpath($this->baseDir) . DIRECTORY_SEPARATOR, '', $f->getPathname());
                        $zip->addFile($f->getPathname(), $local);
                    }
                } else $zip->addFile($p, str_replace(realpath($this->baseDir) . DIRECTORY_SEPARATOR, '', $p));
            }
            $zip->close();
            $this->logAction('zip_create', $zipPath);
            $this->flash('ZIP criado: ' . $zipName, 'success');
            $this->redirect();
        }

        // zip extract
        public function zipExtract(){
            if (!$this->isAllowed()) $this->forbidden();
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') $this->redirect();
            if (!$this->checkCsrf(isset($_POST['_csrf']) ? $_POST['_csrf'] : '')) { $this->flash('CSRF inválido', 'danger'); $this->redirect(); }
            $target = isset($_POST['target']) ? $_POST['target'] : '';
            $destRel = isset($_POST['dest']) ? $_POST['dest'] : '';
            $zipPath = $this->safePath($target);
            $dest = $this->safePath($destRel);
            if ($zipPath === false || !is_file($zipPath) || $dest === false || !is_dir($dest)) { $this->flash('ZIP ou destino inválido', 'danger'); $this->redirect(); }
            $zip = new ZipArchive();
            if ($zip->open($zipPath) !== true) { $this->flash('Falha ao abrir ZIP', 'danger'); $this->redirect(); }
            $zip->extractTo($dest);
            $zip->close();
            $this->logAction('zip_extract', $zipPath . ' -> ' . $dest);
            $this->flash('ZIP extraído', 'success');
            $this->redirect();
        }

        // search
        public function search(){
            if (!$this->isAllowed()) $this->forbidden();
            $q = isset($_GET['q']) ? trim($_GET['q']) : '';
            $results = array();
            if ($q !== '') {
                $it = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($this->baseDir));
                foreach ($it as $f) {
                    if ($f->isDir()) continue;
                    if (stripos($f->getFilename(), $q) !== false) {
                        $results[] = str_replace(realpath($this->baseDir) . DIRECTORY_SEPARATOR, '', $f->getPathname());
                    }
                }
            }
            $rel = '';
            $items = array();
            $csrf = $this->genCsrf();
            foreach (compact('baseDir','items','rel','csrf','q','results') as $k=>$v) { $$k = $v; }
            require_once ABSPATH . '/views/' . $this->nome_view . '/search.php';
        }

        /* ---------- helpers ---------- */

        protected function listDir($rel){
            $target = $this->safePath($rel);
            if ($target === false || !is_dir($target)) return false;
            $items = scandir($target);
            $list = array();
            foreach ($items as $it) {
                if ($it === '.' || $it === '..') continue;
                // ocultar pastas sistema do filemanager
                if ($it === '.fm_trash' || $it === '.fm_backups') continue;
                $full = $target . DIRECTORY_SEPARATOR . $it;
                $list[] = array(
                    'name' => $it,
                    'is_dir' => is_dir($full),
                    'size' => is_file($full) ? filesize($full) : null,
                    'mtime' => filemtime($full),
                    'relpath' => ltrim(str_replace(realpath($this->baseDir) . DIRECTORY_SEPARATOR, '', $full), DIRECTORY_SEPARATOR),
                    'protected' => $this->inProtectedDir($full)
                );
            }
            usort($list, function($a, $b) {
                if ($a['is_dir'] == $b['is_dir']) return strcasecmp($a['name'], $b['name']);
                return $a['is_dir'] ? -1 : 1;
            });
            return $list;
        }

        protected function redirect($to = null){
            $rel = isset($_GET['p']) ? $_GET['p'] : '';
            if ($to === null) header('Location: /explorer?p=' . rawurlencode($rel)); else header('Location: ' . $to);
            exit;
        }

        protected function forbidden(){
            header('HTTP/1.1 403 Forbidden'); echo "Acesso negado."; exit;
        }

        protected function flash($msg, $type = 'info'){
            if (!isset($_SESSION['_fm_flash'])) $_SESSION['_fm_flash'] = array();
            $_SESSION['_fm_flash'][] = array('msg'=>$msg,'type'=>$type);
        }
    }