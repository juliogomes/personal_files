<?php
	class FaturamentoController extends MainController{
		// variaveis
		protected $tolerancia_atraso = 5;
		protected $module = 'faturamento';
		protected $meios_recebimento;
		protected $empresas_cm;
		// modelos
		public    $obj_conta_bancaria;
		protected $obj_faturamento;
		protected $obj_notificacao;
		// objetos de classes
		protected $modelo_usuario;
		protected $modelo_contrato;
		protected $modelo_produto;
		protected $modelo_nota;
		protected $modelo_fatura;
		protected $modelo_movimento;

		function __construct($parametros = null){
			set_time_limit(1800); //coloque no inicio do arquivo
			ob_implicit_flush(true);
			//FUNCTION_ABSPATH;
			//$this->dt_hoje = new DateTime();
			$this->nome_modulo       = 'faturamento';
			parent::__construct($parametros);
			$this->obj_faturamento      = new Faturamento($this);
			$this->obj_notificacao      = new Notificacoes($this);
			$this->obj_conta_bancaria	= new ContaBancaria($this);

			$this->modelo_usuario   = $this->load_model('usuarios/usuarios', true);
			$this->modelo_contrato  = $this->load_model('contratos/contratos', true);
			$this->modelo_produto   = $this->load_model('produtos/produtos', true);
			$this->modelo_nota      = $this->load_model('notas-fiscais/notas-fiscais', true);
			$this->modelo_fatura    = $this->load_model('faturas/faturas', true);
			$controller             = new MainController(null, 'tarifador', false);
			$this->modelo_movimento = $controller->load_model('movimento/movimento', true);
			$this->modelo_movimento->setDb(new Db(DB_NAME_MOVIMENTO));
			$this->meios_recebimento    = json_decode($this->obj_conta_bancaria->getContaConvenio());
		}

		function listarnf(){
			if (isset($this->parametros[0]) && !empty($this->parametros[0]) && $this->parametros[0] != 'filter') {
				$status = $this->parametros[0];
			}
			if (isset($this->parametros[2]) && !empty($this->parametros[2])) {
				$menus = [
					'recebido' => 'contas a recebidas',
				];
				$menu = $menus[$this->parametros[2]];
			} else {
				$menu = 'contas a receber';
			}

			if (isset($_REQUEST['status']) && !empty($_REQUEST['status'])) {
				if ($_REQUEST['status'] == 'todas') {
					$status2 = null;
				} else {
					$status2 = $_REQUEST['status'];
				}
				$status  = $_REQUEST['status'];
			} else {
				$status2 = null;
				$status  = null;
			}

			if (isset($_REQUEST['tipo_data']) && !empty($_REQUEST['tipo_data'])) {
				$tipo_data = $_REQUEST['tipo_data'];
			} else {
				$tipo_data = 'emissao';
			}

			if (isset($_REQUEST['gerar_rps'])) {
				$gerar_rps = $_REQUEST['gerar_rps'];
			} else {
				$gerar_rps = null;
			}
			
			if (isset($this->parametros[0]) && $this->parametros[0] == 'filter') {
				$gerar_rps = '*';
				$tipo_data = 'vencimento';
				if ($this->parametros[1] == 'status') {
					$status = $this->parametros[2];
					$status2 = $this->parametros[2];
				} elseif ($this->parametros[3] == 'status') {
					$status = $this->parametros[4];
					$status2 = $this->parametros[4];
				}

				if ($this->parametros[1] == 'vencimento') {
					$vencimento_de  = convertDate($this->parametros[2]);
					$vencimento_ate = convertDate($this->parametros[2]);
				} else {
					$ultimo_dia = cal_days_in_month(CAL_GREGORIAN, $this->data_hora_atual->format('m'), $this->data_hora_atual->format('Y'));
					$vencimento_de = $this->data_hora_atual->format('01/m/Y');
					$vencimento_ate = $this->data_hora_atual->format($ultimo_dia . '/m/Y');
				}
			} elseif (isset($_REQUEST['vencimento_de']) && isset($_REQUEST['vencimento_ate'])) {
				$vencimento_de  = $_REQUEST['vencimento_de'];
				$vencimento_ate = $_REQUEST['vencimento_ate'];
			} else {
				$ultimo_dia = cal_days_in_month(CAL_GREGORIAN, $this->data_hora_atual->format('m'), $this->data_hora_atual->format('Y'));
				$vencimento_de = $this->data_hora_atual->format('01/m/Y');
				$vencimento_ate = $this->data_hora_atual->format($ultimo_dia . '/m/Y');
			}

			if ($vencimento_de && $vencimento_ate) {
				$dt_ini = convertDate($vencimento_de);
				$dt_fim = convertDate($vencimento_ate);
				$dados 	= json_decode($this->modelo_nota->getNotaPorPeriodo($dt_ini, $dt_fim, null, $status2, $gerar_rps, $tipo_data));
			} else {
				$dados = json_decode($this->modelo_nota->getNotaPorPeriodo(null, null, null, $status2, $gerar_rps, $tipo_data));
			}
			require_once ABSPATH . '/views/' . $this->module . '/notas-fiscais-view.php';
		}

		function processarnf(){
			try {
				$usuario_aprovacao = null;
				$retorno['codigo'] = 0;

				$this->config_model = $this->load_model('configuracoes/configuracoes', true);
				$this->config_list  = json_decode($this->config_model->getConfiguracoes());
				$obj_controle       = json_decode($this->config_list[0]->controle_orcamento);
				if (!isset($_POST['data_acao']) || empty($_POST['data_acao'])) {
					$retorno['codigo']               = 1;
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Informe a data da operaçao';
					throw new Exception(json_encode($retorno));
				}

				if (isset($_POST['nf']) && count($_POST['nf']) > 0) {
					if ($_POST['acao'] == 'cancelar') {
						$nf_cancelada_em = new DateTime(convertDate($_POST['data_acao']), new DateTimeZone('America/Sao_Paulo'));
						if (isset($_POST['email_aprovacao'])) {
							$arr_email = explode('@', $_POST['email_aprovacao']);
							if (isset($arr_email[1]) && !empty($arr_email[1])) {
								$email = trim($_POST['email_aprovacao']);
							} else {
								$email = trim($arr_email[0]) . DOMINIO_EMAIL;
							}

							if ($obj_controle && $obj_controle->aprovadores) {
								if (filter_var($email, FILTER_SANITIZE_EMAIL)) {
									$usuario = json_decode($this->modelo_usuario->getUserByEmail($email));
									$_POST['senha_aprovacao'] = md5($_POST['senha_aprovacao']);
									if ($usuario) {
										if ($usuario->senha == $_POST['senha_aprovacao']) {
											if (in_array($usuario->id, $obj_controle->aprovadores)) {
												$usuario_aprovacao = $usuario->id;
											} else {
												$retorno['codigo'] = 1;
												$retorno['processo']['codigo']      = 2;
												$retorno['processo']['tipo']        = 'danger';
												$retorno['processo']['post']        = $_POST;
												$retorno['processo']['dados']       = null;
												$retorno['processo']['mensagem']    = 'Este usuario não tem permissão para aprovar despesas';
												throw new Exception(json_encode($retorno));
											}
										} else {
											$retorno['codigo'] = 1;
											$retorno['processo']['codigo']      = 2;
											$retorno['processo']['tipo']        = 'danger';
											$retorno['processo']['post']        = $_POST;
											$retorno['processo']['dados']       = null;
											$retorno['processo']['mensagem']    = 'Senha invalida';
											throw new Exception(json_encode($retorno));
										}
									} else {
										$retorno['codigo'] = 1;
										$retorno['processo']['codigo']      = 2;
										$retorno['processo']['tipo']        = 'danger';
										$retorno['processo']['post']        = $_POST;
										$retorno['processo']['dados']       = null;
										$retorno['processo']['mensagem']    = 'Usuario não encontrado';
										throw new Exception(json_encode($retorno));
									}
								} else {
									$retorno['codigo'] = 1;
									$retorno['processo']['codigo']      = 2;
									$retorno['processo']['tipo']        = 'danger';
									$retorno['processo']['post']        = $_POST;
									$retorno['processo']['dados']       = null;
									$retorno['processo']['mensagem']    = 'Email invalido';
									throw new Exception(json_encode($retorno));
								}
							} else {
								$retorno['codigo'] = 1;
								$retorno['processo']['codigo']      = 2;
								$retorno['processo']['tipo']        = 'danger';
								$retorno['processo']['post']        = $_POST;
								$retorno['processo']['dados']       = null;
								$retorno['processo']['mensagem']    = 'Erro ao carregar configurações de controle de aprovaçao';
								throw new Exception(json_encode($retorno));
							}

							$param_nota['status']        = 'cancelado';
							$param_nota['cancelado_por'] = $usuario_aprovacao;
							$param_nota['cancelado_em']  = $this->data_hora_atual->format('Y-m-d');
							foreach ($_POST['nf'] as $key => $value) {
								$dados_nota   = json_decode($this->modelo_nota->getNotaEcontrato($value['id_nf']));
								if ($dados_nota) {
									$is_save_nota = $this->modelo_nota->save($param_nota, $value['id_nf']);
									if ($is_save_nota) {
										if ('producao' == TIPO_AMBIENTE) {
											$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/06b48f3c-0684-46b4-ad04-63494a706bc7@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9cb6bfbfed3d4b1e9c34f76848ba6e61/c8c7ff53-e294-4a3a-bcad-c9f04857e469';
										} else {
											$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9f2e2cc655bf4e76bfdb0531dd3a83d7/c328c206-070a-4beb-bbed-da82e018abec';
										}
										$parametros['mensagem']			 = "Nota cancelada \n ID: " . $dados_nota[0]->id . " \n Fatura: " . $dados_nota[0]->numero_fatura . " \n Cliente: " . $dados_nota[0]->cliente . " \n Emissao: " . convertDate($dados_nota[0]->data_emissao) . " \n Vencimento: " . convertDate($dados_nota[0]->data_vencimento) . " \n Alterado por: " . $_SESSION['cmswerp']['userdata']->nome . " \n Alterada em: " . $this->data_hora_atual->format('d/m/Y H:i:s') . " \n";
										$parametros['tipo_destinatario'] = 'webhook';
										$send = $this->obj_notificacao->enviar('teams', $parametros);

										$retorno['processo'][$key]['codigo']   = 0;
										$retorno['processo'][$key]['tipo']     = 'success';
										$retorno['processo'][$key]['mensagem'] = 'Notas cancelada com sucesso';
										$retorno['processo'][$key]['post']     = $_POST;
										$retorno['processo'][$key]['retorno']  = $value;
										$retorno['processo'][$key]['codigo']   = 1;
										$retorno['processo'][$key]['tipo']     = 'danger';
										$retorno['processo'][$key]['mensagem'] = 'Informe um usuario valido para cancelar a(s) nota(s)';
										$retorno['processo'][$key]['post']     = $_POST;
										$retorno['processo'][$key]['retorno']  = null;
									}
								} else {
									$retorno['codigo'] 					   = 1;
									$retorno['processo'][$key]['codigo']   = 1;
									$retorno['processo'][$key]['tipo']     = 'warning';
									$retorno['processo'][$key]['mensagem'] = 'nota não encontrada';
									$retorno['processo'][$key]['post']     = $_POST;
									$retorno['processo'][$key]['retorno']  = $dados_nota;
								}
							}
						} else {
							$retorno['codigo'] = 1;
							$retorno['processo'][0]['codigo']   = 2;
							$retorno['processo'][0]['tipo']     = 'danger';
							$retorno['processo'][0]['mensagem'] = 'Informe um usuario valido para cancelar a(s) nota(s)';
							$retorno['processo'][0]['post']     = $_POST;
							$retorno['processo'][0]['retorno']  = null;
						}
						throw new Exception(json_encode($retorno));
					} elseif ($_POST['acao'] == 'recebido') { //tratamento para notas recebidas
						$dias_s     = null;
						$diff_w     = null;
						$weekend    = null;
						$calc_multa = true;
						$nf_recebida_em = new DateTime(convertDate($_POST['data_acao']), new DateTimeZone('America/Sao_Paulo'));
						if ($nf_recebida_em) {
							//laço para processar as notas fiscais selecionadas
							foreach ($_POST['nf'] as $key => $value) {
								$dados_nota = json_decode($this->modelo_nota->getNotaEcontrato($value['id_nf']));
								if ($dados_nota) {
									if ($dados_nota[0]->status == 'receber') {
										$vencimento_em             =  new DateTime($dados_nota[0]->data_vencimento, new DateTimeZone('America/Sao_Paulo'));
										$param_nota['status']      = 'recebido';
										$param_nota['recebido_em'] = $nf_recebida_em->format('Y-m-d');
										$is_save_nota = $this->modelo_nota->save($param_nota, $dados_nota[0]->id);
										if ($is_save_nota) {
											if ('producao' == TIPO_AMBIENTE) {
												$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/06b48f3c-0684-46b4-ad04-63494a706bc7@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9cb6bfbfed3d4b1e9c34f76848ba6e61/c8c7ff53-e294-4a3a-bcad-c9f04857e469';
											} else {
												$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9f2e2cc655bf4e76bfdb0531dd3a83d7/c328c206-070a-4beb-bbed-da82e018abec';
											}
											$parametros['mensagem']			 = "Nota fiscal recebida \n ID: " . $dados_nota[0]->id . " \n Fatura: " . $dados_nota[0]->numero_fatura . " \n Cliente: " . $dados_nota[0]->cliente . " \n Emissao: " . convertDate($dados_nota[0]->data_emissao) . " \n Vencimento: " . convertDate($dados_nota[0]->data_vencimento) . " \n Recebida em: " . $nf_recebida_em->format('Y-m-d') . " \n Alterado por: " . $_SESSION['cmswerp']['userdata']->nome . " \n Alterada em: " . $this->data_hora_atual->format('d/m/Y H:i:s');
											$parametros['tipo_destinatario'] = 'webhook';
											$send = $this->obj_notificacao->enviar('teams', $parametros);
											$retorno['processo'][$key]['codigo']   = 0;
											$retorno['processo'][$key]['input']    = $_POST;
											$retorno['processo'][$key]['output']   = $value;
											$retorno['processo'][$key]['mensagem'] = 'Nota Fiscal recebida com sucesso';
										} else {
											$retorno['codigo']                     = 1;
											$retorno['processo'][$key]['codigo']   = 1;
											$retorno['processo'][$key]['input']    = $_POST;
											$retorno['processo'][$key]['output']   = $value;
											$retorno['processo'][$key]['mensagem'] = 'Erro ao baixar a nota';
										}

										// checando multa e juros
										$juros_multa = json_decode($this->obj_faturamento->calcMultaJuros($dados_nota[0]->id_contrato, $vencimento_em, $nf_recebida_em, $dados_nota[0]->valor_liquido, true, 5));
										if ($juros_multa && $juros_multa->codigo == 0) { // processar multa e juros caso haja valores a cobrar
											$descricao_multa 		 = "Multa referente a NF com vencimento em " . $vencimento_em->format('d/m/Y') . " paga em " . $nf_recebida_em->format('d/m/Y');
											$descricao_juros 		 = "Juros referente a NF com vencimento em " . $vencimento_em->format('d/m/Y') . " paga em " . $nf_recebida_em->format('d/m/Y');
											$id_contrato 	 		 = isset($dados_nota[0]->id_contrato) ? $dados_nota[0]->id_contrato : null;
											$codigo_cliente  		 = isset($dados_nota[0]->codigo_cliente) ? $dados_nota[0]->codigo_cliente : null;
											$codigo_produto  		 = isset($dados_nota[0]->codigo_produto) ? $dados_nota[0]->codigo_produto : null;
											$id_produto 	 		 = isset($dados_nota[0]->id_produto) ? $dados_nota[0]->id_produto : null;
											$id_modulo 	     		 = 20;
											$codigo_modulo   		 = 'ADM0011';
											$padm['id_contrato'] 	 = $id_contrato;
											$padm['codigo_cliente']	 = $codigo_cliente;
											$padm['codigo_produto']	 = $codigo_produto;
											$padm['codigo_modulo']	 = $codigo_modulo;
											$padm['valor'] 	 		 = ($juros_multa->dados->valor_multa + $juros_multa->dados->valor_juros);
											$padm['qtd_transacoes']  = 1;
											$padm['centro_custo']  	 = 'nao_informado';
											$padm['data_tarifacao']  = $this->data_hora_atual->format('Y-m-d');
											$padm['data_operacao']   = $this->data_hora_atual->format('Y-m-d');
											$padm['tarifavel'] 		 = 0;
											$padm['flag']  			 = 'automatico';
											$id_mov_diario 			 = $this->modelo_movimento->insertMov($padm);
											if ($id_mov_diario) {
												$pm['id_mov_diario']  = $id_mov_diario;
												$pm['id_contrato']    = $id_contrato;
												$pm['id_produto']     = $id_produto;
												$pm['codigo_produto'] = $codigo_produto;
												$pm['id_modulo'] 	  = $id_modulo;
												$pm['codigo_modulo']  = $codigo_modulo;
												$pm['id_nf_origem']   = $dados_nota[0]->id;
												$pm['origem']         = 'nota fiscal';
												$pm['tipo']           = 'multa';
												$pm['valor_base']     = $dados_nota[0]->valor_liquido;
												$pm['valor_calculado'] = $juros_multa->dados->valor_multa;
												$pm['data_tarifacao'] = $this->data_hora_atual->format('Y-m-d');
												$pm['vencimento_em']  = $vencimento_em->format('Y-m-d');
												$pm['recebido_em']    = $nf_recebida_em->format('Y-m-d');
												$pm['descricao']      = $descricao_multa;
												$pm['status']         = 'pendente';

												$pj['id_mov_diario']  = $id_mov_diario;
												$pj['id_contrato']    = $id_contrato;
												$pj['id_produto']     = $id_produto;
												$pj['codigo_produto'] = $codigo_produto;
												$pj['id_modulo'] 	  = $id_modulo;
												$pj['codigo_modulo']  = $codigo_modulo;
												$pj['id_nf_origem']   = $dados_nota[0]->id;
												$pj['origem']         = 'nota fiscal';
												$pj['tipo']           = 'juros';
												$pj['valor_base']     = $dados_nota[0]->valor_liquido;
												$pj['valor_calculado'] = $juros_multa->dados->valor_juros;
												$pj['data_tarifacao'] = $this->data_hora_atual->format('Y-m-d');
												$pj['vencimento_em']  = $vencimento_em->format('Y-m-d');
												$pj['recebido_em']    = $nf_recebida_em->format('Y-m-d');
												$pj['descricao']      = $descricao_juros;
												$pj['status']         = 'pendente';
												// if( !$prel['id_contrato'] || !$pm['id_contrato'] || !$pj['id_contrato'] ){
												// 	if('producao' == TIPO_AMBIENTE){
												// 		$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/74e0b6ee03c64aacbaaacff97e50f83b/c8c7ff53-e294-4a3a-bcad-c9f04857e469';
												// 	}else{
												// 		$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9f2e2cc655bf4e76bfdb0531dd3a83d7/c328c206-070a-4beb-bbed-da82e018abec';
												// 	}
												// 	$parametros['mensagem']			 = 'TRANSAÇÃO DE MULTA E JUROS SEM CONTRATO, VERIFICAR NO TARIFADOR!';
												// 	$parametros['tipo_destinatario'] = 'webhook';
												// 	$send = $this->obj_notificacao->enviar('teams', $parametros);
												// }
												$is_save_pm  = $this->modelo_nota->insertMovAux($pm);
												$is_save_pj  = $this->modelo_nota->insertMovAux($pj);
											}
										} elseif ($juros_multa && $juros_multa->codigo == 1) {
											$retorno['processo'][$key]['codigo']   = 1;
											$retorno['processo'][$key]['input']     = $_POST;
											$retorno['processo'][$key]['mensagem'] = 'Juros e multa não incide sobre a nota';
										} else {
											$retorno['codigo']                     = 1;
											$retorno['processo'][$key]['codigo']   = 1;
											$retorno['processo'][$key]['input']    = $_POST;
											$retorno['processo'][$key]['output']    = $value;
											$retorno['processo'][$key]['mensagem'] = 'Erro em calcular multa e juros';
										}
										//fim do calculo de multa e juros
									} else {
										// aqui não pode gerar erro apenas não executa a ação
										$retorno['processo'][$key]['codigo']   = 1;
										$retorno['processo'][$key]['input']     = $_POST;
										$retorno['processo'][$key]['output']    = $value;
										$retorno['processo'][$key]['mensagem'] = 'Nota já recebida';
									}
								} else {
									$retorno['processo'][$key]['codigo']   = 2;
									$retorno['processo'][$key]['input']     = $_POST;
									$retorno['processo'][$key]['output']    = $value;
									$retorno['processo'][$key]['mensagem'] = 'Nota não encontrada';
								}
							} //fim do foreach
						} else {
							$retorno['codigo']      = 1;
							$retorno['input']       = $_POST;
							$retorno['output']      = $dados_nota;
							$retorno['mensagem']    = 'Informe a data de recebimento';
							throw new Exception(json_encode($retorno));
						}
					} else { // caso a ação seja desconhecida, implementar metodo de erro posteriormente
						$retorno['codigo']                  = 1;
						$retorno['processo'][0]['codigo']   = 1;
						$retorno['processo'][0]['input']     = $_POST;
						$retorno['processo'][0]['mensagem'] = 'Ação desconhecida';
						throw new Exception(json_encode($retorno));
					}
				} else {
					$retorno['codigo']               = 1;
					$retorno['processo']['codigo']   = 1;
					$retorno['processo']['input']     = $_POST;
					$retorno['processo']['mensagem'] = 'Dados post vazio';
				}
				throw new Exception(json_encode($retorno));
			} catch (Exception $e) {
				$this->error = $e;
				echo $e->getMessage();
			}
		}

		function gerarrps(){
			$_POST['nf'][11000483]['id_nf'] = 11000483;
			if (isset($_POST['nf']) && !empty($_POST['nf'])) {
				$this->obj_faturamento->gerarrps(json_encode($_POST['nf']));
			} elseif (isset($this->parametros[1]) && is_numeric($this->parametros[1]) && !empty($this->parametros[1])) {
				$id_nf = $this->parametros[1];
				$notas['nf'][$id_nf]['id_nf'] = $id_nf;
				$this->obj_faturamento->gerarrps(json_encode($notas['nf']));
			}
		}

		function showNotas()
		{
			if (isset($_POST['ano']) && !empty($_POST['ano'])) {
				$ano = $_POST['ano'];
			} else {
				$ano = 2018;
			}

			if (isset($_POST['status']) && !empty($_POST['status'])) {
				$status = $_POST['status'];
			} else {
				$status = null;
			} 
			
			$dados = json_decode($this->modelo_nota->getNotasPorStatusOuAno($ano, $status));

			if (isset($this->parametros[2]) && !empty($this->parametros)) {
				$filter_dt_vencimento = convertDate($this->parametros[2]);
			} else {
				$filter_dt_vencimento = null;
			}
			require_once ABSPATH . '/views/' . $this->module . '/shownotas-view.php';
		}

		//funcoes revisadas
		function calendarioFaturamento(){
			$dados_calendario = $this->modelo_nota->countStatus();
			require_once ABSPATH . '/views/' . $this->module . '/calendario-view.php';
		}

		function listaCalendario(){
			$notas_status = json_decode($this->modelo_nota->countStatus());
			foreach ($notas_status as $key => $value) {
				$dt_vencimento = new DateTime($value->data_vencimento);
				$param[$key]['title'] = $value->valor_total;
				$param[$key]['url'] = '/faturamento/listarnf/filter/1/' . $value->data_vencimento;
				$param[$key]['start'] = $value->data_vencimento;
				$param[$key]['end'] = $value->data_vencimento;
				if ($value->status == 'recebido') {
					$param[$key]['color'] = "green";
					$param[$key]['textColor'] = "black";
				} else {
					if ($dt_vencimento->format('Ymd') > $this->data_hora_atual->format('Ymd')) {
						$param[$key]['color'] = "yellow";
						$param[$key]['textColor'] = "black";
					} else {
						$param[$key]['color'] = "red";
						$param[$key]['textColor'] = "black";
					}
				}
			}
			echo json_encode($param);
		}

		function index(){
			$this->listar();
		}

		function listarRps(){
			$cnpj_cm = null;
			$data_criacao = null;
			$this->empresas_cm = json_decode($this->modelo_contrato->getEmpresasCM());
			if (!empty($_POST['empresas_cm'])) {
				$cnpj_cm = $_POST['empresas_cm'];
			}

			if (!empty($_POST['data_criacao'])) {
				$data_criacao = new DateTime(convertDate($_POST['data_criacao']));
				$dt_ini = $data_criacao;
				$dt_fim = $data_criacao;
			} else {
				$data_criacao = $this->data_hora_atual;
				$dt_ini = $data_criacao;
				$dt_fim = $data_criacao;
			}
			$remessas = json_decode($this->modelo_fatura->getGrupoRemessas($dt_ini, $dt_fim, $cnpj_cm, 'check'));
			require_once ABSPATH . '/views/' . $this->module . '/rps-view.php';
		}

		function sendToNFE(){
			try {
				$retorno['codigo'] = 1;
				if (isset($_POST['ids_remessas']) && !empty($_POST['ids_remessas'])) {
					if (isset($this->parametros[1]) && $this->parametros[1] == 'enviar') {
						$parametros['action'] = 'enviar';
					} else {
						$parametros['action'] = 'validar';
					}

					foreach ($_POST['ids_remessas'] as $key => $value) {
						foreach ($value as $k1 => $v1) {
							$envio_arquivo = json_decode($this->obj_faturamento->sendRpsNfe($key, $k1, $v1, $parametros));
							if (isset($envio_arquivo->codigo) && $envio_arquivo->codigo != 0) {
								throw new Exception(json_encode($envio_arquivo), 1);
							}
						}
					}
					$retorno['codigo'] 	   = 0;
					$retorno['mensagem'][] = 'Arquivos enviados';
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['mensagem'] = 'Selecione os arquivos a serem enviados!';
				}
				throw new Exception(json_encode($retorno), 1);
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function updateStatusNFE(){
			try {
				$retorno['codigo'] = 1;
				if (isset($_POST['ids_remessas']) && !empty($_POST['ids_remessas'])) {
					foreach ($_POST['ids_remessas'] as $key => $value) {
						foreach ($value as $k1 => $v1) {
							$status_arquivo = json_decode($this->obj_faturamento->updateStatusNfe($key, $k1));
							if (!isset($status_arquivo->codigo) && $status_arquivo->codigo != 0) {
								// logar sucesso
								throw new Exception(json_encode($status_arquivo), 1);
							}
						}
					}
					$retorno['codigo'] 	 = '0';
					$retorno['mensagem'] = 'Sucesso';
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['codigo'] 	 = '1';
					$retorno['mensagem'] = 'Selecione os arquivos a serem enviados!';
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function rpsnotas(){
			$numero_remessa = null;
			$cnpj_prestador = null;

			if (!empty($this->parametros[0]) && is_numeric($this->parametros[0])) {
				$numero_remessa = $this->parametros[0];
			}

			if (!empty($this->parametros[1]) && is_numeric($this->parametros[1])) {
				$cnpj_prestador = $this->parametros[1];
			}

			if ($numero_remessa || $cnpj_prestador) {
				$dados = json_decode($this->modelo_nota->getNotasPorRemessa($numero_remessa, $cnpj_prestador));
			}
			require_once ABSPATH . '/views/' . $this->module . '/rpsnotas-view.php';
		}

		function listar(){
			if (isset($_POST['show_adm'])) {
				$show_adm = $_POST['show_adm'];
			} else {
				$show_adm = 0;
			}

			if (isset($_POST['mostrar_notas']) && !empty($_POST['mostrar_notas'])) {
				$mostrar_notas = $_POST['mostrar_notas'];
			} else {
				$mostrar_notas = 0;
			}

			if (isset($_POST['empresa_cm']) && !empty($_POST['empresa_cm'])) {
				$empresa_cm = addslashes(trim($_POST['empresa_cm']));
			} else {
				$empresa_cm = null;
			}

			if (isset($_POST['cliente']) && !empty($_POST['cliente'])) {
				$cliente = addslashes(trim($_POST['cliente']));
			} else {
				$cliente = null;
			}

			if (isset($_POST['produto']) && !empty($_POST['produto'])) {
				$produto = addslashes(trim($_POST['produto']));
			} else {
				$produto = null;
			}

			if (isset($_POST['data_corte_de']) && validaId($_POST['data_corte_de'])) {
				$dia_corte_ini = $_POST['data_corte_de'];
			} else {
				$dia_corte_ini = 1;
			}
			
			if (isset($_POST['data_corte_ate']) && validaId($_POST['data_corte_ate'])) {
				$dia_corte_fim = $_POST['data_corte_ate'];
			} else {
				$dia_corte_fim = 31;
			}

			if ($dia_corte_ini > $dia_corte_fim) {
				$dia_corte_fim = $dia_corte_ini;
			}

			if ($show_adm == 0) {
				$dados = json_decode($this->modelo_contrato->getContratosPorParamentro(null, $empresa_cm, $cliente, $produto, $dia_corte_ini, $dia_corte_fim, true));
			} else {
				$dados = json_decode($this->modelo_contrato->getContratosPorParamentro(null, $empresa_cm, $cliente, $produto, $dia_corte_ini, $dia_corte_fim, false));
			}

			$ano = $this->data_hora_atual->format('Y');
			$mes = $this->data_hora_atual->format('m');
			$ano_mes_referencia = $ano . '-' . $mes;
			$data_corte_ini = clone $this->data_hora_atual;
			$data_corte_fim = clone $this->data_hora_atual;
			$data_corte_ini->setDate($ano, $mes, '01');
			$data_corte_fim->modify('Last day of this month');
			$nfs 	 = json_decode($this->modelo_nota->getNotaByEmissao($data_corte_ini->format('Y-m-d'), $data_corte_fim->format('Y-m-d')));
			$mov_aux = json_decode($this->modelo_nota->getMovAuxiliar('pendente'));
			if($dados){
				foreach ($dados as $key => $value) {
					$i1 		 = $value->id_contrato;
					$nf_emissao  = buscarCampo($nfs, 'id_contrato', $value->id_contrato, 'ano_mes_referencia', false, true);
					$mov_aux_reg = buscarCampo($mov_aux, 'id_contrato', $value->id_contrato, 'id_contrato');
					$data_corte_contrato = clone $this->data_hora_atual;
					$data_corte_contrato->setDate($ano, $mes, $value->data_corte_faturamento);
					if($value->taxa_inatividade == 1){
						$data_inatividade = getDataAtual($value->data_assinatura);
						$data_inatividade->modify('+'.$value->prazo_inatividade.' days');
						$value->data_inicio_inatividade = $data_inatividade->format('Y-m-d');
					}else{
						$value->data_inicio_inatividade = null;
					}

					if(!$nf_emissao || $mostrar_notas == 1 || $nf_emissao[0] != $ano_mes_referencia){
						if($value->status_contrato == 'ativo'){
							if(!empty($value->data_primeiro_faturamento) && $value->data_primeiro_faturamento != '0000-00-00'){
								$data_primeiro_faturamento = new DateTime($value->data_primeiro_faturamento);
								if($data_primeiro_faturamento > $data_corte_contrato){
									continue;
								}
							}

							if(
								!empty($value->isento_de) && 
								!empty($value->isento_ate) && 
								$value->isento_de != '0000-00-00' && 
								$value->isento_ate != '0000-00-00'
							){
								$isento_de  = new DateTime($value->isento_de);
								$isento_ate = new DateTime($value->isento_ate);
								if($data_corte_contrato <= $isento_ate && $data_corte_contrato >= $isento_de){
									continue;
								}
							}

							if(!empty($value->carencia_de_uso) && $value->carencia_de_uso != '0000-00-00'){
								$carencia_de_uso = new DateTime($value->carencia_de_uso);
								if($carencia_de_uso > $data_corte_contrato){
									continue;
								}
							}
							$faturar_clientes[$i1] = $value;
						}
					}

					if($mov_aux_reg){
						if(!isset($faturar_clientes[$i1])){
							$faturar_clientes[$i1] = $value;
						}
					}
				}
			}
			require_once ABSPATH . '/views/' . $this->module . '/faturamento-view.php';
		}

		function detalhe(){
			$extras = null;
			if (!isset($_REQUEST['cobrar_multa'])) {
				$extras['cobrar_multa'] =  1;
			} else {
				$extras['cobrar_multa'] = $_REQUEST['cobrar_multa'];
			}

			if (!isset($_REQUEST['cobrar_reajuste'])) {
				$extras['cobrar_reajuste'] =  1;
			} else {
				$extras['cobrar_reajuste'] = $_REQUEST['cobrar_reajuste'];
			}

			if (isset($_REQUEST['valor_desconto'])) {
				$valor_desconto =  removeCaracteres($_REQUEST['valor_desconto'], 'moeda2');
				$tipo_desconto  = $_REQUEST['tipo_desconto'];
				if ($valor_desconto > 0) {
					$extras['tipo_desconto']  = $tipo_desconto;
					$extras['valor_desconto'] = $valor_desconto;
				}
			} else {
				$tipo_desconto  = 'percentual';
				$valor_desconto = 0;
			}

			if (isset($_REQUEST['prorrata'])) {
				$extras['prorrata']  = $_REQUEST['prorrata'];
			} else {
				$extras['prorrata'] = 0;
			}

			if (isset($_REQUEST['periodo_de']) && !empty($_REQUEST['periodo_de'])) {
				$periodo_de  = convertDate($_REQUEST['periodo_de'], 1);
			} else {
				$periodo_de = null;
			}

			if (isset($_REQUEST['periodo_ate']) && !empty($_REQUEST['periodo_ate'])) {
				$periodo_ate = convertDate($_REQUEST['periodo_ate'], 1);
			} else {
				$periodo_ate = null;
			}

			if (isset($_REQUEST['data_vencimento']) && !empty($_REQUEST['data_vencimento'])) {
				$data_vencimento  = convertDate($_REQUEST['data_vencimento']);
			} else {
				$data_vencimento = null;
			}

			if (is_numeric($this->parametros[0]) && !empty($this->parametros[0])) {
				$id_contrato = $this->parametros[0];
				$dados       = json_decode($this->obj_faturamento->getDetalheFaturamento($id_contrato, $periodo_de, $periodo_ate, $data_vencimento, $extras));
				if ($_REQUEST['id_banco'] && !empty($_REQUEST['id_banco'])) {
					$dados->contrato->id_banco = $_REQUEST['id_banco'];
				}

				if ($_REQUEST['meio_pagamento'] && !empty($_REQUEST['meio_pagamento'])) {
					$dados->contrato->meio_pagamento = $_REQUEST['meio_pagamento'];
				}
			}
			require_once ABSPATH . '/views/' . $this->module . '/detalhe-view.php';
		}

		function gerarnf(){
			$extras = null;
			if (!isset($_REQUEST['cobrar_multa'])) {
				$extras['cobrar_multa'] =  1;
			} else {
				$extras['cobrar_multa'] = $_REQUEST['cobrar_multa'];
			}

			if (!isset($_REQUEST['cobrar_reajuste'])) {
				$extras['cobrar_reajuste'] =  1;
			} else {
				$extras['cobrar_reajuste'] = $_REQUEST['cobrar_reajuste'];
			}

			if (isset($_REQUEST['valor_desconto'])) {
				$valor_desconto =  removeCaracteres($_REQUEST['valor_desconto'], 'moeda2');
				if ($valor_desconto > 0) {
					$extras['tipo_desconto']  = $_REQUEST['tipo_desconto'];
					$extras['valor_desconto'] = $valor_desconto;
				}
			}

			if (isset($_REQUEST['prorrata']) && $_REQUEST['prorrata'] == 1) {
				$extras['prorrata']  = $_REQUEST['prorrata'];
			} else {
				$extras['prorrata'] = 0;
			}

			if (isset($_REQUEST['data_vencimento']) && !empty($_REQUEST['data_vencimento'])) {
				$data_vencimento  = convertDate($_REQUEST['data_vencimento']);
			} else {
				$data_vencimento = null;
			}

			if (isset($_REQUEST['periodo_de']) && !empty($_REQUEST['periodo_de'])) {
				$periodo_de  = convertDate($_REQUEST['periodo_de']);
			} else {
				$periodo_de = null;
			}

			if (isset($_REQUEST['periodo_ate']) && !empty($_REQUEST['periodo_ate'])) {
				$periodo_ate = convertDate($_REQUEST['periodo_ate']);
			} else {
				$periodo_ate = null;
			}

			if (is_numeric($this->parametros[0]) && !empty($this->parametros[0])) {
				$id_contrato = $this->parametros[0];
				$dados = json_decode($this->obj_faturamento->getDetalheFaturamento($id_contrato, $periodo_de, $periodo_ate, $data_vencimento, $extras));
				if ($dados){
					if ($_REQUEST['id_banco'] && !empty($_REQUEST['id_banco'])) {
						$dados->contrato->id_banco = $_REQUEST['id_banco'];
					}

					if ($_REQUEST['meio_pagamento'] && !empty($_REQUEST['meio_pagamento'])) {
						$dados->contrato->meio_pagamento = $_REQUEST['meio_pagamento'];
					}

					$nf_save = $this->obj_faturamento->gerarnf($dados);
					if ($nf_save) {
						header('Location: /faturamento/listar/ ');
					} else {
						echo 'Erro ao gerar a nota';
					}
				}
			}
		}

		function detalhenf(){
			$nota = json_decode($this->modelo_nota->getNota($this->parametros[1]));
			if ($nota) {
				require_once ABSPATH . '/views/' . $this->module . '/nf-detalhe-view.php';
			}
		}

		function editarnf(){
			$nota       = json_decode($this->modelo_nota->getNota($this->parametros[1]));
			$empresa_cm = json_decode($this->modelo_usuario->getEmpresasCm());
			if ($nota) {
				if ($nota[0]->status == 'receber') {
					require_once ABSPATH . '/views/' . $this->module . '/nf-edit-view.php';
				} else {
					echo 'Nota sem permissão para alteração';
				}
			}
		}

		function saveNf(){
			$descricao = str_replace("\n", "|", trim($_POST['descricao_nota']));
			$descricao = trim($descricao);
			$descricao = ltrim($descricao);
			$descricao = rtrim($descricao);
			$descricao = nl2br($descricao);
			$descricao = strip_tags($descricao);
			$descricao = str_replace("\n", ' ', $descricao);
			$descricao = str_replace("\r", ' ', $descricao);
			$descricao = mb_convert_encoding($descricao, "UTF-8", "auto");

			$descricao_servico = str_replace("\n", "|", trim($_POST['descricao_servico']));
			$descricao_servico = trim($descricao_servico);
			$descricao_servico = ltrim($descricao_servico);
			$descricao_servico = rtrim($descricao_servico);
			$descricao_servico = nl2br($descricao_servico);
			$descricao_servico = strip_tags($descricao_servico);
			$descricao_servico = str_replace("\n", ' ', $descricao_servico);
			$descricao_servico = str_replace("\r", ' ', $descricao_servico);
			$descricao_servico = mb_convert_encoding($descricao_servico, "UTF-8", "auto");

			$_POST['cnpj_cpf_cliente']       = removeCaracteres($_POST['cnpj_cpf_cliente'], 'char');
			$_POST['data_vencimento']        = convertDate($_POST['data_vencimento']);
			$_POST['cep_cliente'] 		     = removeCaracteres($_POST['cep_cliente'], true);
			$_POST['valor_fatura'] 		     = removeCaracteres($_POST['valor_fatura'], 'moeda2');
			$_POST['valor_total'] 		     = removeCaracteres($_POST['valor_total'], 'moeda2');
			$_POST['valor_impostos'] 		 = removeCaracteres($_POST['valor_impostos'], 'moeda2');
			$_POST['valor_impostos_retidos'] = removeCaracteres($_POST['valor_impostos_retidos'], 'moeda2');
			$_POST['descricao_servico']      = removeCaracteres(substr($descricao_servico, 0, 999), 'char_especiais');
			$_POST['descricao_nota']         = removeCaracteres(substr($descricao, 0, 999), 'char_especiais');
			if (isset($_POST["data_emissao"]) && !empty($_POST["data_emissao"])) {
				$_POST["data_emissao"] = convertDate($_POST["data_emissao"]);
			}

			if (isset($_POST['id_empresa']) && !empty($_POST['id_empresa'])) {
				$id_empresa = $_POST['id_empresa'];
				unset($_POST['id_empresa']);
				$empresa_cm = json_decode($this->modelo_usuario->getEmpresasCm($id_empresa));
				if (isset($empresa_cm) && !empty($empresa_cm)) {
					foreach ($empresa_cm as $key => $value) {
						$_POST['prestador_servico']  		    = $value->razao_social;
						$_POST['cnpj_cpf_prestador'] 		    = $value->cnpj;
						$_POST['inscricao_estadual_prestador']  = $value->inscricao_estadual;
						$_POST['inscricao_municipal_prestador'] = $value->inscricao_municipal;
						$_POST['endereco_prestador']			= $value->endereco;
						$_POST['numero_prestador']				= $value->numero;
						$_POST['complemento_prestador']			= $value->complemento;
						$_POST['cep_prestador']					= $value->cep;
						$_POST['bairro_prestador']				= $value->bairro;
						$_POST['municipio_prestador']			= $value->cidade;
						$_POST['uf_prestador']					= $value->estado;
					}
				}
			}

			if (!empty($_POST['id']) && is_numeric($_POST['id'])) {
				$dados_nf = json_decode($this->modelo_nota->getNota($_POST['id']));
				$id = $_POST['id'];
				unset($_POST['id']);
				if ($dados_nf) {
					$is_save = $this->modelo_nota->save($_POST, $id);
					if (!$is_save) {
						//echo '<pre>';
						//var_dump( $id, $is_save, $this->modelo_nota );
						//echo '</pre>';
						echo 'Erro ao salvar a nota!';
						exit;
					}
				} else {
					echo 'Erro ao tentar atualizar nota fiscal inexistente';
					exit;
				}
			} else {
				echo 'Error!';
				exit;
			}
			header('location: /faturamento/editarnf/id/' . $id);
		}

		function nfmanual(){
			$clientes          = json_decode($this->modelo_contrato->clientesAtivos());
			$this->empresas_cm = json_decode($this->modelo_contrato->getEmpresasCM());
			require_once ABSPATH . '/views/' . $this->module . '/nf-manual-view.php';
		}

		function previanfmanual(){
			try {
				global $VAR_SYSTEM;
				$codigo_servico       = null;
				$descricao_lancamento = null;
				$descricao_nota       = null;
				if (isset($_POST['periodo_de']) && !empty($_POST['periodo_de'])) {
					$nf['periodo']['de'] = new DateTime(convertDate($_POST['periodo_de']));
					$descricao_nota = "Periodo de " . $_POST['periodo_de'];
				} else {
					$nf['periodo']['de'] = $this->data_hora_atual;
				}

				if (isset($_POST['periodo_ate']) && !empty($_POST['periodo_ate'])) {
					$nf['periodo']['ate'] = new DateTime(convertDate($_POST['periodo_ate']));
					$descricao_nota .= " ate " . $_POST['periodo_ate'] . "\n";
				} else {
					$nf['periodo']['ate'] = $this->data_hora_atual;
				}

				if (isset($_POST['cliente']) && !empty($_POST['cliente'])) {
					$cliente = json_decode($this->modelo_contrato->clientesPorCodigo($_POST['cliente'], $_POST['produto'][0]['codigo']));
					$nf['cliente']['id_contrato']                 = $cliente[0]->id;
					$nf['cliente']['cnpj_cpf_cliente']            = $cliente[0]->cnpj;
					$nf['cliente']['cliente']                     = $cliente[0]->razao_social;
					$nf['cliente']['cliente']                     = str_replace("'", "", $cliente[0]->razao_social);
					$nf['cliente']['nome_fantasia_cliente']       = str_replace("'", "", $cliente[0]->nome_fantasia);
					$nf['cliente']['inscricao_estadual_cliente']  = $cliente[0]->inscricao_estadual;
					$nf['cliente']['inscricao_municipal_cliente']  = $cliente[0]->inscricao_municipal;
					$nf['cliente']['endereco_cliente']            = $cliente[0]->endereco;
					$nf['cliente']['numero_cliente']              = $cliente[0]->numero;
					$nf['cliente']['complemento_cliente']         = $cliente[0]->complemento;
					$nf['cliente']['bairro_cliente']              = $cliente[0]->bairro;
					$nf['cliente']['cep_cliente']                 = $cliente[0]->cep;
					$nf['cliente']['municipio_cliente']           = $cliente[0]->cidade;
					$nf['cliente']['uf_cliente']                  = $cliente[0]->estado;
					$nf['cliente']['email_nf']                  = $cliente[0]->email_nf;
				} else {
					throw new Exception("Cliente não informado!", 1);
				}

				if (isset($_POST['empresa_cm']) && is_numeric($_POST['empresa_cm'])) {
					$empresa_cm = json_decode($this->modelo_contrato->getEmpresasCM($_POST['empresa_cm']));
					$nf['cliente']['id_empresa']                    = $empresa_cm[0]->id;
					$nf['cliente']['cnpj_prestador']                = $empresa_cm[0]->cnpj;
					$nf['cliente']['razao_social_prestador']        = str_replace("'", "", $empresa_cm[0]->razao_social);
					$nf['cliente']['nome_fantasia_prestador']       = str_replace("'", "", $empresa_cm[0]->nome_fantasia);
					$nf['cliente']['inscricao_estadual_prestador']  = $empresa_cm[0]->inscricao_estadual;
					$nf['cliente']['inscricao_municipal_prestador'] = $empresa_cm[0]->inscricao_municipal;
					$nf['cliente']['endereco_prestador']            = $empresa_cm[0]->endereco;
					$nf['cliente']['numero_prestador']              = $empresa_cm[0]->numero;
					$nf['cliente']['complemento_prestador']         = $empresa_cm[0]->complemento;
					$nf['cliente']['bairro_prestador']              = $empresa_cm[0]->bairro;
					$nf['cliente']['cep_prestador']                 = $empresa_cm[0]->cep;
					$nf['cliente']['municipio_prestador']           = $empresa_cm[0]->cidade;
					$nf['cliente']['uf_prestador']                  = $empresa_cm[0]->estado;
				} else {
					throw new Exception("Empresa C&M não informada!", 1);
				}

				if (isset($_POST['data_vencimento']) && !empty($_POST['data_vencimento']) && DateValidation($_POST['data_vencimento'])) {
					$nf['data_vencimento'] = convertDate($_POST['data_vencimento']);
					$obj_dt_vencimento =  new DateTime($nf['data_vencimento']);
					if ($obj_dt_vencimento <= $this->data_hora_atual) {
						throw new Exception("Data de vencimento incorreta!", 1);
					}
				} else {
					throw new Exception("Data de vencimento não informada!", 1);
				}

				if (isset($_POST['id_conta_bancaria']) && is_numeric($_POST['id_conta_bancaria'])) {
					foreach ($this->meios_recebimento as $key => $value) {
						if ($value->id == $_POST['id_conta_bancaria']) {
							$dados_banco = $value;
						}
					}
				} else {
					throw new Exception("informe o banco!", 1);
				}

				if (isset($_POST['meio_pagamento']) && !empty($_POST['meio_pagamento'])) {
					$nf['meio_pagamento'] = $_POST['meio_pagamento'];
				} else {
					throw new Exception("informe o meio de pagamento!", 1);
				}

				if (isset($_POST['produto']) && is_array($_POST['produto'])) {

					$produto   = null;
					$vr_lanc   = null;
					$tp_lanc   = null;
					$desc_1    = null;

					$nf['cliente']['codigo_produto'] = $cliente[0]->codigo_produto;
					$produto['id_produto']     		 = $_POST['produto'][0]['id'];
					$produto['codigo_produto'] 		 = $_POST['produto'][0]['codigo'];
					$produto['nome_produto']   		 = $_POST['produto'][0]['nome'];

					if ($nf['cliente']['cnpj_prestador'] == '14289105000117') {
						if ($nf['cliente']['cnpj_cpf_cliente'] == '74014747000135') {
							$descricao_inicial = 'Suporte tecnico em informatica ' . "\n";
							$codigo_servico    = '010701217';
							$comretencao       = true;
						} elseif ($_POST['produto'][0]['codigo'] == 'GCK0001') {
							$descricao_inicial = 'Intermediacao de negocio' . "\n";
							$codigo_servico    = '100503216';
							$comretencao       = true;
						} elseif ($_POST['produto'][0]['codigo'] == 'ECS0001') {
							$descricao_inicial = 'Processamento de dados' . "\n";
							$codigo_servico    = '010301211';
						} else {
							$descricao_inicial = 'Consultoria em informatica' . "\n";
							$codigo_servico    = '010602217';
							$comretencao       = true;
						}
					} else {
						if ($_POST['produto'][0]['codigo'] == 'GCK0001') {
							$descricao_inicial = 'Intermediacao de negocio' . "\n";
							$codigo_servico    = '100503216';
						} elseif ($_POST['produto'][0]['codigo'] == 'ADM0001') {
							$descricao_inicial = 'Licenca de uso' . "\n";
							$codigo_servico    = '010501219';
						} elseif ($_POST['produto'][0]['codigo'] == 'ECS0001') {
							$descricao_inicial = 'Hospedagem' . "\n";
							$codigo_servico    = '010301211';
						} else {
							$descricao_inicial = 'Licenca de uso' . "\n";
							$codigo_servico    = '010501219';
						}
					}

					$nf['codigo_servico']    = $codigo_servico;
					$nf['descricao_servico'] = $VAR_SYSTEM['CODIGO_SERVICO'][$empresa_cm[0]->cnpj][$codigo_servico];
					foreach ($_POST['modulo'] as $key => $value) {
						$impostos = null;
						$vr_lanc  = removeCaracteres($_POST['valor'][$key], 'moeda2');
						$quant    = $_POST['quantidade'][$key];
						$tp_lanc  = $_POST['tipo_lancamento'][$key];

						$nf['modulo'][$key]                    = $value;
						$nf['modulo'][$key]['codigo_produto']  = $produto['codigo_produto'];
						$nf['modulo'][$key]['nome_modulo']     = $value['nome'];
						$nf['modulo'][$key]['tipo_lancamento'] = $tp_lanc;
						$nf['modulo'][$key]['qtd_transacoes']  = $quant;
						$nf['modulo'][$key]['valor_liquido']   = $vr_lanc;
						$nf['modulo'][$key]['valor_desconto']  = 0;

						$nf['impostos'][$key] = json_decode($this->obj_faturamento->calcImposto($nf['cliente'], $nf['modulo'][$key], $comretencao));

						$impostos = $nf['impostos'][$key];

						$nf['modulo'][$key]['impostos']    = $impostos->totalizadores;
						$nf['modulo'][$key]['valor_total'] = ($impostos->totalizadores->semretencao->total + $vr_lanc);
						$nf['valor_liquido']     	       += $vr_lanc;

						if (isset($impostos->totalizadores->comretencao->total)) {
							$nf['valor_fatura'] += (($impostos->totalizadores->semretencao->total + $vr_lanc) - $impostos->totalizadores->comretencao->total);
						} else {
							$nf['valor_fatura'] += (($impostos->totalizadores->semretencao->total + $vr_lanc));
						}

						$nf['valor_impostos']   	       += $impostos->totalizadores->semretencao->total;
						$nf['valor_total']   	           += ($impostos->totalizadores->semretencao->total + $vr_lanc);

						if (isset($impostos->totalizadores->comretencao->total)) {
							$nf['valor_impostos_retidos'] += $impostos->totalizadores->comretencao->total;
						} else {
							$nf['valor_impostos_retidos'] += 0;
						}

						$nf['valor_impostos_municipal']    += $impostos->totalizadores->naoincidente->Municipal1;
						$nf['valor_impostos_federal']      += $impostos->totalizadores->naoincidente->Federal1;
					}
					$nf['faturamento_relacionado'] = $nf['modulo'];
				} else {
					throw new Exception("Nenhum produto lançado!", 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
			$nf = convertToObject($nf);
			$descricao_pagamento  .= "Pagamento via " . strtoupper($nf->meio_pagamento);
			$descricao_pagamento  .= " Banco $dados_banco->nome_reduzido Agencia $dados_banco->numero_agencia C/C $dados_banco->numero_conta - $dados_banco->digito_conta";
			$descricao_pagamento  .= " vencimento em " . $_POST['data_vencimento'] . "\n";
			$descricao_imposto    .= "Valor aproximado dos tributos conf. Lei 12.741/2012 Federal R$ " . number_format($nf->valor_impostos_federal, '2', ',', '.') . ' Municipal R$ ' . number_format($nf->valor_impostos_municipal, '2', ',', '.');
			require_once ABSPATH . '/views/' . $this->module . '/previa-nf-view.php';
		}

		function gerarNfManual(){
			try {
				if (isset($_POST) && !empty($_POST)) {
					$dados = json_decode($_POST['dados']);
					if ($dados->data_vencimento) {
						$obj_dt_vencimento = new DateTime($dados->data_vencimento);
						if ($obj_dt_vencimento <= $this->data_hora_atual) {
							$retorno['code']    = 3;
							$retorno['type']    = 'danger';
							$retorno['message'] = 'Data de vencimento incorreta!';
							$retorno['dados']   = $_POST;
							throw new Exception(json_encode($retorno), 1);
						}
					} else {
						$retorno['code']    = 4;
						$retorno['type']    = 'danger';
						$retorno['message'] = 'É obrigatório informar a data de vencimento!';
						$retorno['dados']   = $_POST;
						throw new Exception(json_encode($retorno), 1);
					}

					$descricao = str_replace("\n", "|", trim($_POST['descricao_nota']));
					$descricao = trim($descricao);
					$descricao = ltrim($descricao);
					$descricao = rtrim($descricao);
					$descricao = nl2br($descricao);
					$descricao = strip_tags($descricao);
					$descricao = str_replace("\n", ' ', $descricao);
					$descricao = str_replace("\r", ' ', $descricao);

					if ($dados->cliente) {
						$param_nf['cnpj_cpf_prestador']            = $dados->cliente->cnpj_prestador;
						$param_nf['prestador_servico']             = $dados->cliente->razao_social_prestador;
						$param_nf['inscricao_estadual_prestador']  = $dados->cliente->inscricao_estadual_prestador;
						$param_nf['inscricao_municipal_prestador'] = $dados->cliente->inscricao_municipal_prestador;
						$param_nf['endereco_prestador']            = $dados->cliente->endereco_prestador;
						$param_nf['numero_prestador']              = $dados->cliente->numero_prestador;
						$param_nf['complemento_prestador']         = $dados->cliente->complemento_prestador;
						$param_nf['cep_prestador']                 = $dados->cliente->cep_prestador;
						$param_nf['bairro_prestador']              = $dados->cliente->bairro_prestador;
						$param_nf['municipio_prestador']           = $dados->cliente->municipio_prestador;
						$param_nf['uf_prestador']                  = $dados->cliente->uf_prestador;
					} else {
						$retorno['code']    = 1;
						$retorno['type']    = 'danger';
						$retorno['message'] = 'Dados da empresa prestadora não informados!';
						$retorno['dados']   = $_POST;
						throw new Exception(json_encode($retorno), 1);
					}

					if ($dados->cliente) {
						$param_nf['id_contrato']                 = $dados->cliente->id_contrato;
						$param_nf['cnpj_cpf_cliente']            = $dados->cliente->cnpj_cpf_cliente;
						$param_nf['cliente']           			 = $dados->cliente->cliente;
						$param_nf['email_nf']                    = str_replace(';', '|', $dados->cliente->email_nf);
						$param_nf['codigo_produto']              = $dados->cliente->codigo_produto;
						$param_nf['codigo_cliente']              = $dados->cliente->codigo_cliente;
						$param_nf['inscricao_estadual_cliente']  = $dados->cliente->inscricao_estadual_cliente;
						$param_nf['inscricao_municipal_cliente'] = $dados->cliente->inscricao_municipal_cliente;
						$param_nf['endereco_cliente']            = $dados->cliente->endereco_cliente;
						$param_nf['numero_cliente']              = $dados->cliente->numero_cliente;
						$param_nf['complemento_cliente']         = $dados->cliente->complemento_cliente;
						$param_nf['cep_cliente']                 = removeCaracteres($dados->cliente->cep_cliente, 'char_especiais');
						$param_nf['bairro_cliente']              = $dados->cliente->bairro_cliente;
						$param_nf['municipio_cliente']           = $dados->cliente->municipio_cliente;
						$param_nf['uf_cliente']                  = $dados->cliente->uf_cliente;
					} else {
						$retorno['code']    = 2;
						$retorno['type']    = 'danger';
						$retorno['message'] = 'Dados do cliente não informados!';
						$retorno['dados']   = $_POST;
						throw new Exception(json_encode($retorno), 1);
					}

					$dados_remessa = json_decode($this->modelo_fatura->getLastRemessa($dados->cliente->cnpj_prestador, $this->data_hora_atual->format('Y-m-d')));

					if (!empty($dados_remessa[0]->numero_remessa)) {
						$numero_remessa = ($dados_remessa[0]->numero_remessa + 1);
					} else {
						$numero_remessa = $this->data_hora_atual->format('Ymd') . '001';
					}

					$ultima_fatura = json_decode($this->modelo_nota->getLastNota(null, null, null, $dados->cliente->cnpj_prestador));

					if (!empty($ultima_fatura)) {
						$ultimo_numero_nota   = ($ultima_fatura[0]->numero + 1);
						$ultimo_numero_fatura = ($ultima_fatura[0]->numero_fatura + 1);
					} else {
						$ultimo_numero_nota   = 1;
						$ultimo_numero_fatura = 1;
					}

					$param_nf['numero']            		 = $ultimo_numero_nota;
					$param_nf['tipo']            		 = 'M';
					$param_nf['numero_fatura']     		 = $ultimo_numero_fatura;
					$param_nf['data_emissao']      		 = $this->data_hora_atual->format('Y-m-d');
					$param_nf['data_faturamento']  		 = $this->data_hora_atual->format('Y-m-d');
					$param_nf['data_vencimento']   		 = $dados->data_vencimento;
					$param_nf['hora_emissao']      		 = $this->data_hora_atual->format('H:i:s');
					$param_nf['data_vencimento']   		 = $dados->data_vencimento;
					$param_nf['periodo_de']  	   		 = $dados->periodo->de->date;
					$param_nf['periodo_ate']  	   		 = $dados->periodo->ate->date;
					$param_nf['impostos']  	       		 = json_encode($dados->impostos);
					$param_nf['faturamento_relacionado'] = json_encode($dados->faturamento_relacionado);
					$param_nf['status']           		 = 'receber';
					$param_nf['ano_mes_referencia'] 	 = $this->data_hora_atual->format('Y-m');
					$param_nf['descricao_nota']   		 = $descricao;
					$param_nf['valor_liquido']     		 = $dados->valor_liquido;
					$param_nf['valor_fatura']     		 = $dados->valor_fatura;
					$param_nf['valor_impostos']   		 = $dados->valor_impostos;
					$param_nf['valor_impostos_retidos']	 = $dados->valor_impostos_retidos;
					$param_nf['valor_total']	 		 = $dados->valor_total;
					$param_nf['observacoes']      		 = 'nf manual';
					$param_nf['instrucao_pagamento_nome'] = $dados->meio_pagamento;
					$param_nf['codigo_acesso']           = generateRandomString(8); //$this->data_hora_atual->format('YmdHis').rand(100, 999);//md5(uniqid(rand(), true));
					$param_nf['codigo_servico']          = $dados->codigo_servico;
					$param_nf['gerar_rps']        		 = 1;
					$param_nf['deleted']          		 = 0;

					$save_nota = $this->modelo_nota->save($param_nf);

					if ($save_nota) {
						$retorno['code']    = 0;
						$retorno['type']    = 'success';
						$retorno['message'] = 'Nota gerada com sucesso!';
						$retorno['dados']   = $save_nota;
					} else {
						$retorno['code']    = 3;
						$retorno['type']    = 'danger';
						$retorno['message'] = 'Erro ao gerar a nota fiscal!';
						$retorno['dados']   = $param_nf;
					}
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function visualizarInvoice(){
			if (isset($_GET['nf'])) {
				$ids = explode(',', $_GET['nf']);
				foreach ($ids as $key => $value) {
					if ($key == 4) {
						break;
					}
					$nota = null;
					$resultado = null;
					$nota = json_decode($this->modelo_nota->getNota($value));
					$resultado = CurlExec(URL_SISTEMA . '/utils/viewTemplate', ['id_nf' => $value]);
					$tamplates[] = ['nota' => $nota[0], 'tamplate' => str_replace('<link rel="stylesheet" href="/libs/bootstrap-3.3.7/css/bootstrap.css">', '', $resultado)];
				};
			}
			if ($tamplates) {
				require_once ABSPATH . '/views/invoice/preview-view.php';
			}
		}

		function gerarInvoice(){
			try {
				require_once "libs/mpdf/vendor/autoload.php";
				error_reporting(E_ERROR);
				error_reporting(1);
				ini_set("display_errors", 1);
				$retorno['codigo'] = 1;
				if (isset($_POST['nf']) && is_array($_POST['nf'])) {
					foreach ($_POST['nf'] as $key => $value) {
						if (isset($value['id_nf']) && is_numeric($value['id_nf'])) {
							$nota 	  			= json_decode($this->modelo_nota->getNota($value['id_nf']));
							// $parametros['para'] = explode('|', $nota[0]->email_nf);
							$parametros['para'] = 'julio.gomes@cmsw.com';
							$url  	  			= URL_SISTEMA . 'utils/viewTemplate';
							if ($nota) {
								$path 	   = ABSPATH . DS . 'temp' . DS . 'usa' . DS . $nota[0]->cnpj_cpf_cliente . DS;
								$file_name = $nota[0]->cnpj_cpf_cliente . '_' . $this->data_hora_atual->format('YmdHis') . '.pdf';
								if (!file_exists($path)) {
									mkdir($path, 0777, true);
								}
								// $retorno['codigo']   = 0;
								// $retorno['mensagem'] = 'Invoice enviada para os emails: ';
								$nf_template = CurlExec(URL_SISTEMA . '/utils/viewTemplate', $value);
								$res = json_decode($nf_template);
								if ($res !== false && $res->codigo == 1) {
									throw new Exception(json_encode($res), 1);
								}
								$mpdf = new \Mpdf\Mpdf();
								$mpdf->simpleTables = true;
								$mpdf->SetDisplayMode('fullpage');
								$mpdf->img_dpi = 96;
								$mpdf->SetTitle('INVOICE');
								$mpdf->use_kwt = true;
								$mpdf->allow_charset_conversion = true;
								$mpdf->WriteHTML($nf_template);
								$mpdf->Output($path . $file_name, 'F');
								echo $path . $file_name;
								exit;
								//$parametros['copia_oculta']   = 'orli.machado@cmsw.com';
								$parametros['remetente'] 	  = SMTP_EMAIL_FROM;
								// $parametros['remetente'] 	  = 'admusa@cmsw.com';
								$parametros['remetente_nome'] = 'C&M USA';
								$parametros['assunto'] 		  = 'Invoice C&M';
								$parametros['mensagem'] 	  = "<p>Dear</p> 
											<p>C&M Software is pleased to have you as our customer. We are sending your invoice for verification and payment, if it has already been done, please ignore this email.</p>
											<p>Yours sincerely.</p>
											<p>C&M USA</p>
										";
								$parametros['anexo'] = $path . $file_name;
								if (file_exists($path . $file_name)) {
									// $is_send = json_decode($this->obj_notificacao->enviar('email', $parametros));
									if (1 == 1 || isset($is_send->codigo) && $is_send->codigo == 0) {

										$nf_model = $this->load_model('notas-fiscais/notas-fiscais', true);
										$nf_editada = $nf_model->save(['ultimo_envio_invoice' => date('Y-m-d H:i:s')], $nota[0]->id_contrato);

										if ($nf_editada == false) {
											$retorno['codigo']   = 0;
											$retorno['mensagem'] = 'Invoice enviada para os emails: ';
											throw new Exception(json_encode($retorno), 1);
										}
										$retorno['codigo']   = 1;
										$retorno['mensagem'] = 'Erro ao enviar a invoice';
										foreach ($parametros['para'] as $pk => $pv) {
											$retorno['mensagem'] .= $pk . ' - ' . $pv . ', ';
										}
										throw new Exception(json_encode($retorno), 1);
									} else {
										$retorno['mensagem'] = 'Erro ao enviar a invoice';
										throw new Exception(json_encode($retorno), 1);
									}
								} else {
									$retorno['mensagem'] = 'Erro ao gerar o documento';
									throw new Exception(json_encode($retorno), 1);
								}
							} else {
								$retorno['mensagem'] = 'Não foi possivel recuperar os dados da nota';
								throw new Exception(json_encode($retorno), 1);
							}
						}
					}
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function lancamentosExtras(){
			// var_dump($_SESSION);
			$lista_clientes = json_decode($this->modelo_contrato->clientesAtivos());
			$lista_produtos = json_decode($this->modelo_produto->getAllProdutosAtivos());
			if (isset($_POST['status_lancamento']) && !empty($_POST['status_lancamento'])) {
				$status_lancamento = $_POST['status_lancamento'];
			} elseif (isset($_POST['status_lancamento']) && empty($_POST['status_lancamento'])) {
				$status_lancamento = null;
			} else {
				$status_lancamento = 'lançar';
			}

			if (isset($_POST['indice_reajuste']) && !empty($_POST['indice_reajuste'])) {
				$indice_reajuste = $_POST['indice_reajuste'];
			} else {
				$indice_reajuste = 'IGPM';
			}

			if (isset($_POST['periodo_de']) && !empty($_POST['periodo_de'])) {
				$dt_ini = getDataAtual(convertDate($_POST['periodo_de']));
			} else {
				$dt_ini = clone $this->data_hora_atual;
				$dt_ini->modify('-30 days');
			}

			if (isset($_POST['periodo_ate']) && !empty($_POST['periodo_ate'])) {
				$dt_fim = getDataAtual(convertDate($_POST['periodo_ate']));
			} else {
				$dt_fim = clone $this->data_hora_atual;
			}

			if (isset($_POST['codigo_cliente']) && !empty($_POST['codigo_cliente'])) {
				$codigo_cliente = $_POST['codigo_cliente'];
			} else {
				$codigo_cliente = null;
			}

			if (isset($_POST['codigo_produto']) && !empty($_POST['codigo_produto'])) {
				$codigo_produto = $_POST['codigo_produto'];
			} else {
				$codigo_produto = null;
			}

			if (isset($_POST['tipo_periodo']) && !empty($_POST['tipo_periodo'])) {
				$tipo_periodo = $_POST['tipo_periodo'];
			} else {
				$tipo_periodo = 'vencimento';
			}

			if (isset($_POST['tipo_lancamento']) && !empty($_POST['tipo_lancamento'])) {
				$tipo_lancamento = $_POST['tipo_lancamento'];
			} else {
				$tipo_lancamento = 'multa_juros';
			}
			
			$registros = json_decode($this->modelo_nota->getNfMovAux($dt_ini->format('Y-m-d'), $dt_fim->format('Y-m-d'), $tipo_periodo, $codigo_cliente, $codigo_produto));
			switch ($tipo_lancamento) {
				default:
					if ($registros) {
						$lancamentos = null;
						foreach ($registros as $key => $value) {
							$dt_vencimento = getDataAtual($value->data_vencimento);
							$dt_pagamento  = getDataAtual($value->recebido_em);
							if ($value->dias_atraso > 0) {
								if (!$value->mva_id) {
									if ($value->dias_atraso > $this->tolerancia_atraso) {
										$juros_multa = json_decode($this->obj_faturamento->calcMultaJuros($value->id_contrato, $dt_vencimento, $dt_pagamento, $value->valor_liquido, true, $this->tolerancia_atraso));
										if ($juros_multa->codigo == 0) {
											$value->valor_calculado   = ($juros_multa->dados->valor_multa + $juros_multa->dados->valor_juros);
											$value->status_lancamento = 'lançar';
										} else {
											$value->status_lancamento = 'Erro calculo';
										}
									} else {
										$value->status_lancamento = 'isento';
										$value->valor_calculado   = 0;
									}
								}
							} else {
								unset($registros[$key]);
							}
						}
					}
					break;
			}
			require_once ABSPATH . "/views/$this->module/extras-view.php";
		}

		function efetuarLancamentoExtra(){
			try {
				if (!isset($_POST['action']) || empty($_POST['action'])) {
					$retorno['codigo'] = 1;
					$retorno['input']  = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = 'Ação não informada';
					throw new Exception(json_encode($retorno), 1);
				}

				if (!isset($_POST['lancamentos']) || empty($_POST['lancamentos']) || count($_POST['lancamentos']) < 1) {
					$retorno['codigo'] = 1;
					$retorno['input']  = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = 'Informe os lancamentos a serem isentados';
					throw new Exception(json_encode($retorno), 1);
				}
				$retorno = json_decode($this->obj_faturamento->insertMovAux($_POST['action'], $_POST['lancamentos']));
				throw new Exception(json_encode($retorno), 1);
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function getInfoRps(){
			try {
				if (!isset($this->parametros[0]) || !isset($this->parametros[1])) {
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Empresa ou remessa invalida - vazia';
					throw new Exception(json_encode($retorno), 1);
				}

				if (!is_numeric($this->parametros[0]) || !is_numeric($this->parametros[1])) {
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Empresa ou remessa invalida - nao numerico';
					throw new Exception(json_encode($retorno), 1);
				}
				$registros = json_decode($this->modelo_fatura->infoEnvios($this->parametros[0], $this->parametros[1]));
				require_once ABSPATH . '/views/' . $this->module . '/rps_info-view.php';
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function simularfaturamento(){
			$ano = $this->data_hora_atual->format('Y');
			$mes = $this->data_hora_atual->format('m');
			if (isset($_POST['empresa_cm']) && !empty($_POST['empresa_cm'])) {
				$empresa_cm = addslashes(trim($_POST['empresa_cm']));
			} else {
				$empresa_cm = null;
			}

			if (isset($_POST['cliente']) && !empty($_POST['cliente'])) {
				$cliente = addslashes(trim($_POST['cliente']));
			} else {
				$cliente = null;
			}

			if (isset($_POST['produto']) && !empty($_POST['produto'])) {
				$produto = addslashes(trim($_POST['produto']));
			} else {
				$produto = null;
			}

			if (isset($_POST['data_corte_de']) && validaId($_POST['data_corte_de'])) {
				$dia_corte_ini = $_POST['data_corte_de'];
			} else {
				$dia_corte_ini = 1;
			}
			
			if (isset($_POST['data_corte_ate']) && validaId($_POST['data_corte_ate'])) {
				$dia_corte_fim = $_POST['data_corte_ate'];
			} else {
				$dia_corte_fim = 31;
			}

			if ($dia_corte_ini > $dia_corte_fim) {
				$dia_corte_fim = $dia_corte_ini;
			}

			$nf_periodo_de	= getDataAtual($ano.'-'.$mes.'-01');
			$nf_periodo_ate = clone $nf_periodo_de;
			$nf_periodo_ate->modify('last day of this month');
			$dados = json_decode($this->modelo_contrato->getContratosPorParamentro(null, $empresa_cm, $cliente, $produto, $dia_corte_ini, $dia_corte_fim, true));
			foreach ($dados as $key => $value) {
				$data_faturamento_ini = getDataAtual($ano.'-'.$mes.'-'.$value->data_corte_faturamento);
				$data_faturamento_fim = clone $data_faturamento_ini;
				$data_faturamento_ini->modify('-1 month');
				$data_faturamento_fim->modify('-1 day');
				$data_vencimento = null;
				$extras = true;
				$fat = json_decode(
					$this->obj_faturamento->getDetalheFaturamento(
						$value->id_contrato, 
						$data_faturamento_ini->format('Y-m-d'),
						$data_faturamento_fim->format('Y-m-d'),
						$data_vencimento, $extras
					)
				);

				if(isset($fat->receita->detalhe)){
					if(isset($fat->receita->detalhe->faturamento)){
						foreach ($fat->receita->detalhe->faturamento as $fk => $fv) {
							$value->total_receita    += $fv->valor_total;
							$value->total_transacoes += $fv->transacoes;
						}
					}
					$value->total_receita    += 0;
					$value->total_transacoes += 0;
				}else{
					$value->total_receita    = 0;
					$value->total_transacoes = 0;
				}
				
			}
			require_once ABSPATH . '/views/' . $this->module . '/simular-faturamento-view.php';
		}
	}
