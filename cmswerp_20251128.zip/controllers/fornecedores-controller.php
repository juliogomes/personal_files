<?php
class FornecedoresController extends MainController{
	protected $module = 'fornecedores';
	protected $orcamento, $conta_banco_model, $class_conta_bancaria;

	function __construct($parametros = null){
		$this->nome_modulo = 'fornecedores';
		parent::__construct($parametros);
		$controller = new MainController(null, null, false);
		$this->orcamento   = $controller->load_model('orcamento/orcamento', true);
		$this->class_conta_bancaria = new ContaBancaria($this);
	}

	function index(){
		$this->lista();
	}

	function lista(){
		$this->modelo->setTable('fornecedores');
		$records  = json_decode($this->modelo->getFornecedores());
		require_once ABSPATH . '/views/'.$this->module.'/fornecedores-view.php';
	}

	function detalhe(){
		if($this->parametros[1] != 0 && is_numeric($this->parametros[1] )){
			$records             = json_decode($this->modelo->getFornecedores($this->parametros[1]));
			$bancos				 = json_decode($this->class_conta_bancaria->getBanco());
			$contas_bancarias    = json_decode($this->class_conta_bancaria->getContaByFornecedor($this->parametros[1]));
			$contas_relacionadas = json_decode($this->modelo->getRelationShip($this->parametros[1]));
		}
        // var_dump($contas_bancarias);
        // $contas = json_decode($this->orcamento->getConta());
		require_once ABSPATH . '/views/'.$this->module.'/fornecedores-detalhe-view.php';
	}

	function getSubConta(){
		if(isset($_GET['id_conta']) && is_numeric($_GET['id_conta'])){
			$id_conta = $_GET['id_conta'];
		}else{
			$id_conta = null;
		}
		$sub_contas = $this->orcamento->getContaBySubContas($id_conta);
		echo $sub_contas;
	}

	function addRelationShip($param){
		$table = 'fornecedores_contas';
		$post = json_encode($_POST);
		if(isset($_POST['id_fornecedor']) && is_numeric($_POST['id_fornecedor'])){
			$param['id_fornecedor'] = $_POST['id_fornecedor'];
			$param['id_conta'] = $_POST['id_conta'];
			$param['id_subconta'] = $_POST['id_subconta'];
			$chk_conta_existe = json_decode($this->modelo->chkRelationShip($param['id_fornecedor'], $param['id_conta'], $param['id_subconta']));
			if(!$chk_conta_existe){
				$this->modelo->table = 'fornecedores_contas';
				$is_save = $this->modelo->save($param);
				$this->modelo->table = 'fornecedores';
			}
		}
	}

	function deletarrelationship(){
		if(isset($this->parametros[2]) && is_numeric($this->parametros[2])){
			$param['deleted'] = 1;
			$this->modelo->table = 'fornecedores_contas';
			$this->modelo->save($param, $this->parametros[2]);
			$this->modelo->table = 'fornecedores';
		}
		header('location: /fornecedores/detalhe/id/'.$this->parametros[1].'/');
	}

	function save(){
		
		unset($_POST['id_conta']);
		unset($_POST['id_subconta']);
		unset($_POST ['subconta']);
		
		if(empty($_POST['nome_fantasia'])){
			$_POST['nome_fantasia'] = $_POST['razao_social'];
		}

		if(isset($_POST['cnpj_cpf'])){
			$_POST['cnpj_cpf'] = removeCaracteres($_POST['cnpj_cpf'], true);
		}

		if(isset($_POST['banco_nome'])){
			$_POST['banco_nome'] = strtolower(removeCaracteres($_POST['banco_nome'], true, null));
		}
		
		$_POST['inscricao_estadual'] = removeCaracteres($_POST['inscricao_estadual'], true, null);
		$_POST['cep']                = removeCaracteres($_POST['cep'], true, null);

		$return                      = $this->modelo->save($_POST, $this->parametros[1]);

		if($return){
			//header('location: /fornecedores/detalhe/id/'.$return);
			header('location: /fornecedores/index/');
		}
	}

	function deletar(){
		if(isset($this->parametros[1]) && is_numeric($this->parametros[1])){
			$id = $this->parametros[1];
			$param['deleted'] = 1;
			$this->modelo->save($param, $id);
		}
		header('location: /fornecedores/index/');
	}
}
?>
