<?php
	class GedController extends MainController{
		
		protected $module = 'ged';
		protected $obj_ged;
		protected $contratos_model;
		protected $produtos_model;
		protected $cobranca_model;
		protected $upload;
		public $config;
		
		function __construct($parametros = null){
			require_once ABSPATH . '/classes/class-Upload.php';
			$this->nome_modulo = 'ged';
			parent::__construct($parametros);
			$this->upload 		   = new Upload($this);
			$this->obj_ged		   = new Ged($this, null, true); 
			$this->contratos_model = $this->load_model('contratos/contratos', true);
			$this->produtos_model  = $this->load_model('produtos/produtos', true);
			$this->cobranca_model  = $this->load_model('cobranca/cobranca', true);
		}

		function index(){
			$this->listar();
		}

		function listar(){
			$this->modelo->setTable('contratos');
			$records  = json_decode($this->contratos_model->clientes(null, false));
			require_once ABSPATH . '/views/'.$this->module.'/ged-view.php';
		}

		function listDoc(){
			if(isset($this->parametros[1]) && !empty($this->parametros[1])){
				$records = json_decode($this->contratos_model->clientesAtivos($this->parametros[1], false));
				if($records){
					$documentos = json_decode( $this->modelo->getDocumentByCliente( $records[0]->codigo_cliente ) ); 
				}
			}
			require_once ABSPATH . '/views/'.$this->module.'/ged-lista-view.php';
		}

		function detalhe(){
			if($this->parametros[1] && is_numeric($this->parametros[1]))	{
				$records   = json_decode($this->contratos_model->clientesAtivos($this->parametros[1]));
				$documento = json_decode($this->modelo->getDocument($this->parametros[1]));
				$produtos  = json_decode($this->produtos_model->getProdutosPorCliente($records[0]->codigo_cliente));
				// if($records){
				// 	$documentos = json_decode($this->modelo->getDocument($records[0]->codigo_cliente, $records[0]->nome_fantasia)); 
				// }
			}
			require_once ABSPATH . '/views/'.$this->module.'/ged-detalhe-view.php';
		}

		function edit(){
			if($this->parametros[1] && is_numeric($this->parametros[1]))	{
				$records   = json_decode($this->contratos_model->clientesAtivos($this->parametros[1]));
				$documento = json_decode($this->modelo->getDocument($this->parametros[2]));
				$produtos  = json_decode($this->produtos_model->getProdutosPorCliente($records[0]->codigo_cliente));
			}
			require_once ABSPATH . '/views/'.$this->module.'/ged-edit-view.php';
		}

		function saveFile(){
			try {
				if(isset($this->parametros[1]) && is_numeric($this->parametros[1])){
					$nome_arquivo = null;
					$ext_arquivo  = null;
			
					$cliente = json_decode($this->contratos_model->clientesAtivos($this->parametros[1], false));
					
					if($cliente){
						
						$dados_arquivo['codigo_cliente'] = $cliente[0]->codigo_cliente;
						$dados_arquivo['path_root'] 	 = UP_GED.DS.str_replace(" ","_", trim(strtolower($cliente[0]->nome_fantasia))).DS;
						$dados_arquivo['status'] 		 = 'ativo';
						$dados_arquivo['data_criacao']   = $this->data_hora_atual->format('Y-m-d');

						if(isset($_POST['nome_arquivo']) && !empty($_POST['nome_arquivo'])){
							$dados_arquivo['nome_arquivo'] = $_POST['nome_arquivo'];
						}

						if(isset($_POST['nome_amigavel']) && !empty($_POST['nome_amigavel'])){
							$dados_arquivo['nome_amigavel'] = $_POST['nome_amigavel'];
						}

						if(isset($_POST['assunto']) && !empty($_POST['assunto'])){
							$dados_arquivo['assunto'] = $_POST['assunto'];
						}

						if(isset($_POST['tipo_documento']) && !empty($_POST['tipo_documento'])){
							$dados_arquivo['tipo_documento'] = $_POST['tipo_documento'];
							$nome_arquivo = str_replace(" ","_", trim(strtolower($dados_arquivo['tipo_documento'])));
						}

						if(isset($_POST['classificacao']) && !empty($_POST['classificacao'])){
							$dados_arquivo['tipo_contrato'] = $_POST['classificacao'];
							$nome_arquivo .= '_'.str_replace(" ","_", trim(strtolower($dados_arquivo['tipo_contrato'])));
						}

						if(isset($_POST['data_emissao']) && !empty($_POST['data_emissao'])){
							$dados_arquivo['dt_em_ass'] = $_POST['data_emissao'];
							$nome_arquivo .= '_'.str_replace(" ","_", trim(strtolower($dados_arquivo['dt_em_ass'])));
						}

						if(isset($_POST['dt_em_ass']) && !empty($_POST['dt_em_ass'])){
							$dados_arquivo['dt_em_ass'] = $_POST['dt_em_ass'];
							$nome_arquivo .= '_'.str_replace(" ","_", trim(strtolower($dados_arquivo['dt_em_ass'])));
						}

						if(isset($_POST['num_nota']) && !empty($_POST['num_nota'])){
							$dados_arquivo['num_nota'] = $_POST['num_nota'];
							$nome_arquivo .= '_'.str_replace(" ","_", trim(strtolower($dados_arquivo['num_nota'])));
						}

						if(isset($_POST['num_fatura']) && !empty($_POST['num_fatura'])){
							$dados_arquivo['num_fatura'] = $_POST['num_fatura'];
							$nome_arquivo .= '_'.str_replace(" ","_", trim(strtolower($dados_arquivo['num_fatura'])));
						}

						if(isset($_POST['id_produto']) && !empty($_POST['id_produto'])){
							$dados_arquivo['id_produto'] = $_POST['id_produto'];
							$nome_arquivo .= '_'.str_replace(" ","_", trim(strtolower($dados_arquivo['id_produto'])));
						}

						if(isset($_POST['codigo_produto']) && !empty($_POST['codigo_produto'])){
							$dados_arquivo['codigo_produto'] = $_POST['codigo_produto'];
							$nome_arquivo .= '_'.str_replace(" ","_", trim(strtolower($dados_arquivo['codigo_produto'])));
						}

						if(isset($_POST['data_assinatura']) && !empty($_POST['data_assinatura'])){
							$dados_arquivo['dt_em_ass'] = $_POST['data_assinatura'];
							$nome_arquivo .= '_'.str_replace(" ","_", trim(strtolower($dados_arquivo['dt_em_ass'])));
						}

						if(isset($_POST['tipificacao']) && !empty($_POST['tipificacao'])){
							$dados_arquivo['observacoes'] = $_POST['tipificacao'];
						}
						
						$nome_arquivo .= '_'.$this->data_hora_atual->format('YmdHis');
					}else{
						$retorno['codigo']   = 2;
						$retorno['tipo']     = "erro";
						$retorno['mensagem'] = 'Cliente nao encontrado';
						$retorno['dados']    = $this->parametros;
						throw new Exception(json_encode($retorno), 1);
					}
				}else{
					$retorno['codigo']   = 2;
					$retorno['tipo']     = "erro";
					$retorno['mensagem'] = 'Codigo cliente invalido';
					$retorno['dados']    = $this->parametros;
					throw new Exception(json_encode($retorno), 1);
				}

				if(isset($_FILES['arquivo']['name']) && !empty($_FILES['arquivo']['name'])){
					$ext_arquivo = pathinfo($_FILES['arquivo']['name'], PATHINFO_EXTENSION);
					if(!isset($dados_arquivo['nome_arquivo']) || empty($dados_arquivo['nome_arquivo'])){
						$dados_arquivo['nome_arquivo'] = $nome_arquivo.'.'.$ext_arquivo;
						$_FILES['arquivo']['name']	   = $nome_arquivo.'.'.$ext_arquivo;
					}
					$dados_arquivo['post_file'] = $_FILES['arquivo'];
				}else{
					$retorno['codigo']   = 2;
					$retorno['tipo']     = "erro";
					$retorno['mensagem'] = 'Arquivo vazio';
					$retorno['dados']    = $this->parametros;
					throw new Exception(json_encode($retorno), 1);
				}
				
				throw new Exception( $this->obj_ged->saveDoc( $dados_arquivo ), 1 );
			} catch (Exception $e) { 
				echo $e->getMessage();
			}
		}

		function saveDoc(){
			if(isset($this->parametros[2]) && is_numeric($this->parametros[2])){
				if(isset($_POST['dt_em_ass']) && !empty($_POST['dt_em_ass'])){
					$_POST['dt_em_ass'] = convertDate($_POST['dt_em_ass']);
				}

				if( isset( $_POST['id_produto'] ) && validaId( $_POST['id_produto'] ) ){
					$dados_produto = json_decode( $this->produtos_model->getProduto( $_POST['id_produto'] ) );
					if( $dados_produto ){
						$_POST['codigo_produto'] = $dados_produto[0]->codigo;
					}else{
						echo 'Produto não encontrado';
						exit;
					}
				}else{
					echo 'Informe o produto';
					exit;
				}
				$is_save = $this->modelo->save( $_POST, $this->parametros[2] );
				header('Location: /ged/edit/id/'.$this->parametros[1].'/'.$this->parametros[2]);
			}
		}

		function deleteDoc(){
			if(isset($this->parametros[1]) && is_numeric($this->parametros[1])){
				$codigo_cliente   = $this->parametros[1];
				$id_doc      	  = $this->parametros[2];
				$param['deleted'] = 1;
				$is_save = $this->modelo->save($param, $id_doc);
				if($is_save){
					header('Location: /ged/listdoc/id/'.$codigo_cliente);    
				}else{
					echo 'Erro ao apagar o arquivo';
				}
			}
		}

		function webservice(){
			if($this->parametros[0] == 'action'){
				if($this->parametros[1] == 'getprodutos'){
					$produtos  = json_decode($this->produtos_model->getAllProdutosAtivos());
				}
			}
		}

		function gerarContrato(){
			try {
				if(!isset($this->parametros['0']) || empty($this->parametros['0'])){
					$retorno['codigo']   = 2;
					$retorno['tipo']     = 'danger';
					$retorno['mensagem'] = 'Produto nao informado';
					$retorno['dados']    = null;
					throw new Exception(json_encode($retorno), 1);
				}

				if(!isset($this->parametros['1']) || empty($this->parametros['1'])){
					$retorno['codigo']   = 2;
					$retorno['tipo']     = 'danger';
					$retorno['mensagem'] = 'Tipo de contrato não informado';
					$retorno['dados']    = null;
					throw new Exception(json_encode($retorno), 1);
				}

				switch ($this->parametros[0]) {
					case 'RTL0001':
						switch ($this->parametros[1]) {
							case 'prepago':
								if(!isset($_GET) || empty($_GET)){
									$retorno['codigo']   = 2;
									$retorno['tipo']     = 'danger';
									$retorno['mensagem'] = 'Dados do contrato nao informados';
									$retorno['dados']    = null;
									throw new Exception(json_encode($retorno), 1);
								}
								$lista_preco = json_decode($this->cobranca_model->getListaPrecoPadraoByCodigo(null, 'RLT0011'));
								require UP_ABSPATH.'arquivos/html/contrato_rocket_max_v2.php';
							break;
							case 'termo_recisao':
								if(!isset($_GET) || empty($_GET)){
									$retorno['codigo']   = 2;
									$retorno['tipo']     = 'danger';
									$retorno['mensagem'] = 'Dados do contrato nao informados';
									$retorno['dados']    = null;
									throw new Exception(json_encode($retorno), 1);
								}
								require UP_ABSPATH.'arquivos/html/termo_recisao_rocketmax.php';
							break;
							default:
								$retorno['codigo']   = 2;
								$retorno['tipo']     = 'danger';
								$retorno['mensagem'] = 'Tipo de contrato desconhecido';
								$retorno['dados']    = $this->parametros;
							break;
						}
					break;
					default:
						$retorno['codigo']   = 2;
						$retorno['tipo']     = 'danger';
						$retorno['mensagem'] = 'produto nao desconhecido';
						$retorno['dados']    = $this->parametros;
					break;
				}
				if(isset($retorno) && !empty(termo_recisao_rocketmax.php)){
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}
	}