<?php

class GruposSistemaController extends MainController
{
    function __construct($parametros = null, $nome_modulo = 'ponto', $do_login = true)
    {
        $this->setModulo('grupossistema');
        $this->setView('grupossistema');
        parent::__construct($parametros, $nome_modulo, $do_login);
    }

    function index()
    {
        $grupos_sistema = json_decode($this->modelo->obtemGruposSistema());
        require_once ABSPATH . '/views/' . $this->nome_view . '/grupos_sistema-view.php';
    }

    function novoGrupo()
    {
        try {
            $nome = $_POST['nome'];
            $tipo = $_POST['tipo'];

            if (!$nome || !$tipo) {
                $retorno['codigo'] = 1;
                $retorno['tipo'] = 'error';
                $retorno['input'] = $_POST;
                $retorno['output'] = $this->modelo->info;
                $retorno['mensagem'] = 'Informe o nome e o tipo';
                throw new Exception(json_encode($retorno), 1);
            } else {
                $grupo_sistema = [
                    'nome' => $nome,
                    'descricao' => $nome,
                    'tipo_grupo' => $tipo,
                    'controller' => 'grupossistema',
                    'ativo' => 1,
                    'alterado_por' => $_SESSION['cmswerp']['userdata']->id,
                    'deleted' => 0
                ];

                $id = $this->modelo->salvaGrupoSistema($grupo_sistema, null, 'grupo_sistema');

                if ($id) {

                    $nome_entidade = $_POST['nome_entidade'];
                    $alias_entidade = $_POST['alias_entidade'];

                    $grupo_entidade = [
                        'id_grupo' => $id,
                        'alias_entidade' => $alias_entidade,
                        'nome_entidade' => $nome_entidade,
                        'alterado_por' => $_SESSION['cmswerp']['userdata']->id,
                        'deleted' => 0
                    ];

                    $id_ = $this->modelo->salvaGrupoSistema($grupo_entidade, null, 'grupo_entidades');

                    if ($id_) {
                        $retorno['codigo'] = 0;
                        $retorno['input'] = $this->parametros;
                        $retorno['output'] = $id;
                        $retorno['mensagem'] = 'Grupo de sistema salvo com sucesso</br><a href="grupossistema/detalhescombo/' . $id . '" target="_blank">Acessar detalhes do grupo</a>';
                        throw new Exception(json_encode($retorno), 1);
                    } else {
                        $retorno['codigo'] = 1;
                        $retorno['input'] = $this->parametros;
                        $retorno['output'] = null;
                        $retorno['mensagem'] = 'Erro ao salvar grupo de sistema';
                        throw new Exception(json_encode($retorno), 1);
                    }
                } else {
                    $retorno['codigo'] = 1;
                    $retorno['input'] = $this->parametros;
                    $retorno['output'] = null;
                    $retorno['mensagem'] = 'Erro ao salvar grupo de sistema';
                    throw new Exception(json_encode($retorno), 1);
                }
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function excluirGrupo()
    {
        try {
            $id_grupos = explode(',', $this->parametros[0]);
            if (!$id_grupos || empty($id_grupos)) {
                $retorno['codigo'] = 1;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = null;
                $retorno['mensagem'] = 'Nenhum grupo selecionado';
                throw new Exception(json_encode($retorno), 1);
            } else {
                $this->modelo->excluirGruposSistema($id_grupos);
                $retorno['codigo'] = 0;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = null;
                $retorno['mensagem'] = 'Grupo(s) excluido(s) com sucesso';
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function editarCombo()
    {
        $id = $_POST['id'];
        try {
            if (!$id) {
                $retorno['codigo'] = 1;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = null;
                $retorno['mensagem'] = 'Itendificador do grupo não informado';
                throw new Exception(json_encode($retorno), 1);
            } else {
                $dados = [
                    'nome' => $_POST['nome'],
                    'descricao' => $_POST['nome'],
                    'tipo_grupo' => $_POST['tipo'],
                    'alterado_por' => $_SESSION['cmswerp']['userdata']->id,
                    'alterado_em' => date('Y-m-d H:i:s'),
                ];

                $id = $this->modelo->salvaGrupoSistema($dados, $id);
                if ($id) {
                    $retorno['codigo'] = 0;
                    $retorno['input'] = $this->parametros;
                    $retorno['output'] = $id;
                    $retorno['mensagem'] = 'Grupo alterado com sucesso!';
                    throw new Exception(json_encode($retorno), 1);
                } else {
                    $retorno['codigo'] = 1;
                    $retorno['input'] = $this->parametros;
                    $retorno['output'] = null;
                    $retorno['mensagem'] = 'Erro ao alterar grupo';
                    throw new Exception(json_encode($retorno), 1);
                }
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function excluirModulos()
    {
        $errors = '';
        $success = '';
        try {
            $ids_modulos = explode(',', $this->parametros[1]);
            if (!$ids_modulos || empty($ids_modulos)) {
                $retorno['codigo'] = 1;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = null;
                $retorno['mensagem'] = 'Nenhum modulo selecionado';
                throw new Exception(json_encode($retorno), 1);
            }

            foreach ($ids_modulos as $key => $id_objeto) {
                if ($this->modelo->excluirModulosSistema($id_objeto)) {
                    $success .= 'Modulo ' . $id_objeto . ' removido com sucesso</br>';
                } else {
                    $errors .= 'Erro ao remover modulo ' . $id_objeto . '</br>';
                }
            }

            if ($errors && !$success) {
                $retorno['codigo'] = 1;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = null;
                $retorno['mensagem'] = $errors;
                throw new Exception(json_encode($retorno), 1);
            } else if (!$errors && $success) {
                $retorno['codigo'] = 0;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = null;
                $retorno['mensagem'] = 'Todos os modulos foram removidos com sucesso</br>';
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo'] = 0;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = null;
                $retorno['mensagem'] = 'Sucesso parcial: </br>' . $success . '</br>' . $errors;
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function detalhescombo()
    {
        $id = $this->parametros[0];
        $grupo = json_decode($this->modelo->obtemGrupoSistemaById($id));
        $dadosGrupo = json_decode($this->modelo->obtemDadosGrupoSistema_combo($id));
        $modulos = json_decode($this->modelo->obtemModulosTarifaveis());
        $regras = json_decode($this->modelo->obtemRegras($id));
        require_once ABSPATH . '/views/' . $this->nome_view . '/grupos_sistema-combo-detalhe-view.php';
    }

    function adicionarModulo()
    {
        $errors = '';
        $success = '';
        $id_entidade = $this->parametros[0];
        try {
            $ids_modulos = explode(',', $this->parametros[1]);
            if (!$ids_modulos || empty($ids_modulos)) {
                $retorno['codigo'] = 1;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = null;
                $retorno['mensagem'] = 'Nenhum modulo selecionado';
                throw new Exception(json_encode($retorno), 1);
            }

            foreach ($ids_modulos as $key => $id_objeto) {
                $data = [
                    'id_entidade' => $id_entidade,
                    'id_objeto' => $id_objeto,
                    'obrigatorio' => 1,
                    'todos' => 1,
                    'alterado_por' => $_SESSION['cmswerp']['userdata']->idd,
                    'deleted' => 0
                ];

                if ($this->modelo->adicionarModuloGrupoSistema($data)) {
                    $success .= 'Modulo ' . $id_objeto . ' adicionado com sucesso</br>';
                } else {
                    $errors .= 'Erro ao adicionar modulo ' . $id_objeto . '</br>';
                }
            }

            if ($errors && !$success) {
                $retorno['codigo'] = 1;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = null;
                $retorno['mensagem'] = $errors;
                throw new Exception(json_encode($retorno), 1);
            } else if (!$errors && $success) {
                $retorno['codigo'] = 0;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = null;
                $retorno['mensagem'] = 'Todos os modulos foram adicionados com sucesso</br>';
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo'] = 0;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = null;
                $retorno['mensagem'] = 'Sucesso parcial: </br>' . $success . '</br>' . $errors;
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
    function salvarregra()
    {
        try {
            $grupo_id = $_POST['id'];
            $tipo_regra = $_POST['tipo_regra'];
            $base_tipo = $_POST['base_tipo'];
            $base_regra = $_POST['base_regra'];
            $base_valor = $_POST['base_valor'];
            $base_valor = trim(str_replace('R$', '', $base_valor));
            $regra_tipo = $_POST['regra_tipo'];
            $regra_valor = $_POST['regra_valor'];
            $regra_valor = trim(str_replace('R$', '', str_replace('%', '', $regra_valor)));

            $nova_regra = [
                'id_grupo' => $grupo_id,
                'tipo_regra' => $tipo_regra,
                'base_tipo' => $base_tipo,
                'base_regra' => $base_regra,
                'base_valor' => $base_valor,
                'regra_tipo' => $regra_tipo,
                'regra_valor' => $regra_valor,
                'alterado_por' => $_SESSION['cmswerp']['userdata']->id,
                'deleted' => 0
            ];

            if ($this->modelo->salvaRegra($nova_regra, null, 'grupo_sistema')) {
                $retorno['codigo'] = 0;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = null;
                $retorno['mensagem'] = 'Regra criada com sucesso!';
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo'] = 1;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = null;
                $retorno['mensagem'] = 'Erro ao salvar regra';
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function deletarRegra()
    {
        try {
            $id = $this->parametros[0];
            $dados = ['deleted' => 1, 'alterado_por' => $_SESSION['cmswerp']['userdata']->id];
            if ($this->modelo->deletarRegra($dados, $id)) {
                $retorno['codigo'] = 0;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = null;
                $retorno['mensagem'] = 'Regra deletada com sucesso!';
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo'] = 1;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = null;
                $retorno['mensagem'] = 'Erro ao deletar regra';
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function historicoRegra()
    {
        try {
            $id = $this->parametros[0];
            $historico = $this->modelo->obtemHistoricoRegras($id);
            if ($historico) {
                $retorno['codigo'] = 0;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = $historico;
                $retorno['mensagem'] = 'Sucesso';
                echo json_encode($retorno);
            } else {
                $retorno['codigo'] = 1;
                $retorno['input'] = $this->parametros;
                $retorno['output'] = null;
                $retorno['mensagem'] = 'Nenhum registro encontrado';
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
}
