<?php

// require_once('classes/class-Validacao.php');
class HomeController extends MainController{

	function __construct($parametros = null){
		$this->setModulo('home');
		$this->setView('home');
		parent::__construct($parametros);
	}

	function index(){
		require_once ABSPATH . '/views/'.$this->nome_view.'/index.php';
	}
}
?>
