<?php
class ImportController extends MainController
{
	protected $module = 'import';
	protected $valores;
	protected $obj_contrato;
	protected $obj_movimento;
	protected $obj_indice;

	function __construct($parametros){
		$this->nome_modulo = 'import';
		parent::__construct($parametros);

	}
	
	function index()
	{
		$this->importrecords('Planilha IPCA.csv', 'indices', false);
	}

	function importrecords($file_name, $tipo, $import = false)
	{
		$lines = file (UP_ABSPATH.'/'.$file_name);
		// Percorre o array, mostrando o fonte HTML com numeração de linhas.
		foreach ($lines as $line_num => $line) {
		    $row[] = explode(';', $line);
		}

		if($import){
			if($tipo == 'indices'){
				
				$controller = new MainController(null, false, false);
				$controller->load_model('cadastros/indices-reajuste');
				$this->obj_indice = $controller->getModel();

				foreach ($row as $key => $value){
					$percentual = trim(str_replace(",", ".", $value[1]));
					$percentual =  number_format($percentual, '2', ',', '.');
					$ex = explode('-',$value[0]);
					$indices[$key]['indice'] = 'ipca';
					$indices[$key]['mes'] = $ex[1];
					$indices[$key]['ano'] = $ex[0];
					$indices[$key]['percentual'] = $percentual;
				}

				foreach ($indices as $key => $value) {
					$this->obj_indice->save($value);
				}
			}
		}else{
			//implementar
		}
	}
}
?>
