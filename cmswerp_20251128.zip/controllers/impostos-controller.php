<?php
	class ImpostosController extends MainController{
		protected $module = 'impostos';
		protected $empresa_cm;

		function __construct($parametros = null)	{
			$this->nome_modulo = 'impostos';
			parent::__construct( $parametros );
			$contratos_model  = $this->load_model( 'contratos/contratos', true ); 
			$this->empresa_cm = json_decode( $contratos_model->getEmpresasCM() );
		}

		function index(){
			$this->listar();
		}

		function listar(){
			$records  = json_decode( $this->modelo->getImpostos() );
			require_once ABSPATH . '/views/'.$this->module.'/impostos-view.php';
		}

		function detalhe(){
			if( $this->parametros[1] ){
				$records = json_decode($this->modelo->getImpostos($this->parametros[1]) );
			}
			require_once ABSPATH . '/views/'.$this->module.'/impostos-detalhe-view.php';
		}

		function save(){
			if(isset($this->parametros[1]) && is_numeric($this->parametros[1]) && !empty($this->parametros[1])){
				$id = $this->parametros[1];
			}else{
				$id = null;
			}
			$_POST['aliquota']   = removeCaracteres( $_POST['aliquota'], 'moeda2', null );
			$is_save = $this->modelo->save( $_POST, $id );
			header('location: /impostos/listar/');
		}
	}
