 <?php
	ini_set( 'memory_limit', -1 );
    ini_set('max_input_vars', 30000);
	ob_start();
    ob_implicit_flush( true );
	
	class IndicesController extends MainController{
		private
			$cl_indice;
		function __construct( $parametros = null, $login = true ){
			$this->setModulo( 'indices' );
			$this->setView( 'indices' );
			if( isset( $_GET ) && isset( $_GET['reajuste'] ) ){
				$login = false;
			}		
			parent::__construct( $parametros, 'indices', $login );
			$this->cl_indice = new Indices( $this );
		}

		function index(){
			$this->listar();
		}

		function listar(){
			$records = json_decode( $this->modelo->getRecords() );
			if( isset( $records ) && !empty( $records ) ){
				foreach ($records as $key => $value) {
					$ged[$value->id]['lp'] 	   = json_decode($this->modelo->getGedDocumento($value->id, null, 'lp'));
					$ged[$value->id]['pacote'] = json_decode($this->modelo->getGedDocumento($value->id, null, 'pacote'));
				}
			}		
			require_once ABSPATH . '/views/'.$this->nome_view.'/indices-view.php';
		}

		function detalhe(){
			$meses = returMes(2);
			$anos  = returAnos();
			if(!empty($this->parametros[1]) && is_numeric($this->parametros[1])){
				$records = json_decode($this->modelo->getRecords($this->parametros[1]));
			}
			require_once ABSPATH . '/views/'.$this->nome_view.'/indices-cad.php';
		}

		function ajustarLps(){
			$retorno = null;
			try{
				if(!isset($this->parametros[1]) || empty($this->parametros[1]) || !is_numeric($this->parametros[1])){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Reajuste informado invalido';
					throw new Exception(json_encode($retorno), 1);
				}		
			
				$chk_reajuste = json_decode($this->modelo->getRecords($this->parametros[1]));
				if($chk_reajuste){
					$dados_reajuste['indice']     = $chk_reajuste[0]->indice;
					$dados_reajuste['ano']        = $chk_reajuste[0]->ano;
					$dados_reajuste['mes']        = $chk_reajuste[0]->mes;
					$dados_reajuste['percentual'] = number_format($chk_reajuste[0]->percentual,'4',',','.');		
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $chk_reajuste;
					$retorno['mensagem'] = 'Reajuste não encontrado';
					throw new Exception(json_encode($retorno), 1);
				}

				$contratos = json_decode($this->cl_indice->getContatosToReajuste($dados_reajuste));			
				if($contratos->codigo == 0){
					foreach ($contratos->output as $key => $value) {
						$dados_contrato[$key] = $value->id_contrato;
					}
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $contratos;
					$retorno['mensagem'] = 'Nenhum contrato a ser reajustado';
					throw new Exception(json_encode($retorno), 1);
				}	
				$lps = json_decode( $this->cl_indice->calcReajusteLp( $dados_contrato, $dados_reajuste ) );
				if( !$lps ){
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Nenhuma lista encontrada para ser reajustada';
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				$retorno = json_decode( $e->getMessage() );
			}
			require_once ABSPATH . '/views/'.$this->nome_view.'/simulacao_reajuste_lp-view.php';
		}

		function ajustarPacotes(){
			try{
				$retorno = null;
				$pacotes = null;
				if(!isset($this->parametros[1]) || empty($this->parametros[1]) || !is_numeric($this->parametros[1])){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Reajuste informado invalido';
					throw new Exception(json_encode($retorno), 1);
				}		
			
				$chk_reajuste = json_decode( $this->modelo->getRecords( $this->parametros[1] ) );
				if( $chk_reajuste ){
					$dados_reajuste['indice']     = $chk_reajuste[0]->indice;
					$dados_reajuste['ano']        = $chk_reajuste[0]->ano;
					$dados_reajuste['mes']        = $chk_reajuste[0]->mes;
					$dados_reajuste['percentual'] = number_format($chk_reajuste[0]->percentual,'4',',','.');		
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $chk_reajuste;
					$retorno['mensagem'] = 'Reajuste não encontrado';
					throw new Exception(json_encode($retorno), 1);
				}

				$contratos = json_decode( $this->cl_indice->getContatosToReajuste( $dados_reajuste ) );
				if( $contratos->codigo == 0 ){
					foreach ($contratos->output as $key => $value) {
						$dados_contrato[$key] = $value->id_contrato;
					}
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $contratos;
					$retorno['mensagem'] = 'Nenhum contrato a ser reajustado';
					throw new Exception(json_encode($retorno), 1);
				}
				$pacotes = json_decode( $this->cl_indice->calcReajustePct( $dados_contrato, $dados_reajuste ) );
				if( !$pacotes ){
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Nenhum pacote encontrado para ser reajustado';
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				$retorno = json_decode( $e->getMessage() );
			}
			require_once ABSPATH . '/views/'.$this->nome_view.'/simulacao_reajuste_pct-view.php';
		}

		function executarReajustelP(){
			
			if( !isset($_POST['id_indice']) || empty($_POST['id_indice']) ){
				$retorno['codigo']   = 1;
				$retorno['input']    = $_POST;
				$retorno['output']   = null;
				$retorno['mensagem'] = 'Indice não informado';
				require_once ABSPATH . '/views/'.$this->nome_view.'/processa_reajuste_lp-view.php';
			}
							
			$reajuste = json_decode($this->modelo->getRecords($_POST['id_indice']));		
			if( !$reajuste ){
				$retorno['codigo']   = 1;
				$retorno['input']    = $_POST;
				$retorno['output']   = null;
				$retorno['mensagem'] = 'Reajuste não encontrado';
				require_once ABSPATH . '/views/'.$this->nome_view.'/processa_reajuste_lp-view.php';
			}

			if($reajuste[0]->lp_processado == 1){
				$retorno['codigo']   = 1;
				$retorno['input']    = $_POST;
				$retorno['output']   = null;
				$retorno['mensagem'] = 'Reajuste já processado';
				require_once ABSPATH . '/views/'.$this->nome_view.'/processa_reajuste_lp-view.php';
			}
			
			$ged = json_decode($this->insertGed($reajuste, "lp"));	
			if(isset($ged) && !empty($ged)){
				$url 	       = URL_SISTEMA.'indices/indiceHTML/?reajuste='.json_encode($_POST);				
				$param_curl[CURLOPT_FOLLOWLOCATION] = true;
				$dados         = CurlExec($url,null,$param_curl);										
				if(isset($dados) && !empty($dados)){				
					$this->gerarPDF($dados,$ged->input);
				}
				
				require_once ABSPATH . '/views/'.$this->nome_view.'/processa_reajuste_lp-view.php';
			}else{
				echo json_encode($ged);
			}				
			
		}

		function verificaReajuste(){
			try{
			
				if( !isset($_POST['id_indice']) || empty($_POST['id_indice']) ){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Indice não informado';		
					throw new Exception(json_encode($retorno), 1);		
				}
								
				$reajuste = json_decode($this->modelo->getRecords($_POST['id_indice']));		
				if( !$reajuste ){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Reajuste não encontrado';	
					throw new Exception(json_encode($retorno), 1);			
				}
		
				if($reajuste[0]->lp_processado == 1){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Reajuste já processado';	
					throw new Exception(json_encode($retorno), 1);			
				}

				$retorno['codigo']   = 0;
				$retorno['input']    = $_POST;
				$retorno['output']   = null;
				$retorno['mensagem'] = 'Sucesso';	
				throw new Exception(json_encode($retorno), 1);	
			}catch(Exception $e){
				echo $e->getMessage();
			}
		}

		function executarReajustePct(){
			if( !isset($_POST['id_indice']) || empty($_POST['id_indice']) ){
				$retorno['codigo']   = 1;
				$retorno['input']    = $_POST;
				$retorno['output']   = null;
				$retorno['mensagem'] = 'Indice não informado';
				throw new Exception(json_encode($retorno), 1);	
			}

			$reajuste = json_decode($this->modelo->getRecords($_POST['id_indice']));		
			if( !$reajuste ){
				$retorno['codigo']   = 1;
				$retorno['input']    = $_POST;
				$retorno['output']   = null;
				$retorno['mensagem'] = 'Indice não encontrado';
				throw new Exception(json_encode($retorno), 1);	
			}


			$ged    = json_decode($this->insertGed($reajuste, "pacote"));			
			if(isset($ged) && !empty($ged)){
				$url 	       = URL_SISTEMA.'indices/pacoteHTML/?reajuste='.json_encode($_POST);			
				$dados         = CurlExec($url);
													
				if(isset($dados) && !empty($dados)){				
					$this->gerarPDF($dados,$ged->input);
				}
				
				require_once ABSPATH . '/views/'.$this->nome_view.'/processa_reajuste_pct-view.php';
			}else{
				echo json_encode($ged);
			}

			
			// $result = json_decode($this->cl_indice->executarReajustePct($_POST));
			// require_once ABSPATH . '/views/'.$this->nome_view.'/processa_reajuste_pct-view.php';
		}

		function ListarReversao(){
			if( isset( $this->parametros[1] ) && is_numeric( $this->parametros[1] ) ){
				$dados_indice = $this->cl_indice->listarContratosReversao( $this->parametros[1] );
			}
			require_once ABSPATH . '/views/'.$this->nome_view.'/listar-reversao-view.php';
		}

		function ProcessarReversao(){
			if( isset( $this->parametros[1] ) && is_numeric( $this->parametros[1] ) ){
				if( isset( $_POST['clientes'] ) && count( $_POST['clientes'] ) > 0 ){
					$contratos = $_POST['clientes'];
				}else{
					$contratos = null;
				}
				$dados_indice = $this->cl_indice->checarReversao( $this->parametros[1], $contratos );
			}
			require_once ABSPATH . '/views/'.$this->nome_view.'/processar-reversao-view.php';
		}

		function ReverterIndice(){
			try {
				if( !isset( $_POST ) || !is_array( $_POST) || empty( $_POST ) ){
					$retorno['codigo'] 	 = 1;
					$retorno['mensagem'] = 'Selecione a os itens a serem revertidos';
					throw new Exception( json_encode( $retorno ), 1);
				}

				if( isset( $_POST['pacote'] ) && is_array( $_POST['pacote'] ) && !empty( $_POST['pacote'] ) ){
					$pacotes = json_decode( $this->cl_indice->ReverterPacote( $_POST['pacote'] ) );
				}

				if( isset( $_POST['lista'] ) && is_array( $_POST['lista'] ) && !empty( $_POST['lista'] ) ){
					$listas = json_decode( $this->cl_indice->ReverterLista( $_POST['lista'] ) );
				}

				if( $pacotes->codigo == 1 ){
					throw new Exception( json_encode( $pacotes ), 1);
				}elseif( $listas->codigo == 1 ){
					throw new Exception( json_encode( $listas ), 1);
				}else{
					$retorno['codigo'] 	 = 0;
					$retorno['mensagem'] = $listas->mensagem.' / '.$pacotes->mensagem;
					throw new Exception( json_encode( $retorno ), 1);
				}
			} catch ( Exception $e ) {
				echo $e->getMessage();
			}
		}

		function checkReajusteNotas(){
			try {
				if(!isset($this->parametros[1]) || empty($this->parametros[1]) || !is_numeric($this->parametros[1])){
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Reajuste informado invalido';
					throw new Exception(json_encode($retorno), 1);
				}		
			
				$chk_reajuste = json_decode($this->modelo->getRecords($this->parametros[1]));

				if($chk_reajuste){
					$dados_reajuste['indice']     = $chk_reajuste[0]->indice;
					$dados_reajuste['ano']        = $chk_reajuste[0]->ano;
					$dados_reajuste['mes']        = $chk_reajuste[0]->mes;
					$dados_reajuste['percentual'] = number_format($chk_reajuste[0]->percentual,'4',',','.');		
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $chk_reajuste;
					$retorno['mensagem'] = 'Reajuste não encontrado';
					throw new Exception(json_encode($retorno), 1);
				}
					
				if($chk_reajuste){
					$param['ano'] = $chk_reajuste[0]->ano;
					$param['mes'] = $chk_reajuste[0]->mes; 
					$param['indice'] = $chk_reajuste[0]->indice;
					$param['percentual'] = $chk_reajuste[0]->percentual;
					$nfs = json_decode($this->cl_indice->checkNotasEmitidas($param));
					if($nfs->codigo == 0){
						$retorno['codigo']   = 0;
						$retorno['input']    = $_POST;
						$retorno['output']   = $nfs->output;
						$retorno['mensagem'] = 'sucesso';
						throw new Exception(json_encode($retorno), 1);
					}else{
						$retorno['codigo']   = 1;
						$retorno['input']    = $_POST;
						$retorno['output']   = $nfs;
						$retorno['mensagem'] = 'Nenhuma nota a ser lançada';
						throw new Exception(json_encode($retorno), 1);
					}
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = $chk_reajuste;
					$retorno['mensagem'] = 'Nenhum reajuste encontrado';
					throw new Exception(json_encode($retorno), 1);
				}
				
			} catch (Exception $e) {
				$result = json_decode($e->getMessage());
			}
			require_once ABSPATH . '/views/'.$this->nome_view.'/nf-list.php';
		}

		function lancarDiferenca(){
			try {
				
				if(!isset($_POST['id_indice']) || count($_POST['id_indice']) < 1 || !is_numeric($_POST['id_indice'])){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Indice reajuste não informados';
					throw new Exception(json_encode($retorno), 1);
				}

				if(!isset($_POST['lancamentos']) || count($_POST['lancamentos']) < 1){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Nenhuma nota fiscal informada';
					throw new Exception(json_encode($retorno), 1);
				}
				
				$dados_reajuste = json_decode($this->modelo->getRecords($_POST['id_indice']));
				
				$is_save = json_decode($this->cl_indice->saveMovAux($_POST['lancamentos'], $dados_reajuste));
				
				if($is_save->codigo == 0){
					$retorno['codigo']   = 0;
					$retorno['input']    = $_POST;
					$retorno['output']   = $is_save;
					$retorno['mensagem'] = $is_save->mensagem;
					throw new Exception(json_encode($retorno), 1);
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = $is_save;
					$retorno['mensagem'] = $is_save->mensagem;
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function gerarPDF($dados,$path){
			try{
				if(isset($dados)){							
					require_once "libs/mpdf/vendor/autoload.php";               
					$mpdf = new \Mpdf\Mpdf();    
					$style_documento = file_get_contents('assets/css/css_indice.css');				
					$mpdf->WriteHTML($style_documento,\Mpdf\HTMLParserMode::HEADER_CSS);		
					
					$str           = strlen($dados);
					$intval        = intval($str/100000);				
					for($i = 0; $i<=$intval; $i++){							
						$temp_html = substr($dados,($i*100000),99999);			
								
						$mpdf->WriteHTML($temp_html);					
					}					
													
					$mpdf->Output($path,'F');				
					$retorno['codigo']   = 0;
					$retorno['input']    = $dados;
					$retorno['output']   = null;
					$retorno['mensagem'] = $dados->mensagem;
					throw new Exception(json_encode($retorno), 1); 
					
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $dados;
					$retorno['output']   = null;
					$retorno['mensagem'] = $dados->mensagem;
					throw new Exception(json_encode($retorno), 1); 
				}
			}catch(Exception $e){
				return $e->getMessage();
			}		      
		}	
		
		function indiceHTML(){
			try{	
						
				$param			    = get_object_vars(json_decode($_GET['reajuste']));
				$param['contratos'] = get_object_vars($param['contratos']);		
				
				if(isset($param) && !empty($param)){				
					$result = json_decode($this->cl_indice->executarReajustelP($param));				
				}
							
				if(isset($result) && $result->codigo == 1){
					$retorno['codigo']   = 1;
					$retorno['input']    = $result;
					$retorno['output']   = $result->output;
					$retorno['mensagem'] = $result->mensagem;
					throw new Exception(json_encode($retorno), 1);	
				}else{
					require_once ABSPATH.'/template/reajuste/template-reajuste.php';				
				}
			}catch(Exception $e){
				return $e->getMessage();
			}
		}

		function pacoteHTML(){
			try{	
						
				$param			    = get_object_vars(json_decode($_GET['reajuste']));
				$param['contratos'] = get_object_vars($param['contratos']);		
				
				if(isset($param) && !empty($param)){				
					$result = json_decode($this->cl_indice->executarReajustePct($param));				
				}
								
				if(isset($result) && $result->codigo == 1){
					$retorno['codigo']   = 1;
					$retorno['input']    = $result;
					$retorno['output']   = $result->output;
					$retorno['mensagem'] = $result->mensagem;
					throw new Exception(json_encode($retorno), 1);	
				}else{				
					require_once ABSPATH.'/template/reajuste/template-reajuste-pacote.php';		
				}
			}catch(Exception $e){
				return $e->getMessage();
			}
		}

		function insertGed($indice, $subtipo = null){
			try{
				if(!is_dir(UP_GED.DS.'indice')){
					mkdir(UP_GED.DS.'indice');
				} 
				
				if(!is_dir(UP_GED.DS.'indice'.DS.$indice[0]->ano)){
					mkdir(UP_GED.DS.'indice'.DS.$indice[0]->ano);
				} 
				if(!is_dir(UP_GED.DS.'indice'.DS.$indice[0]->ano.DS.strtoupper(nomeMes($indice[0]->mes)))){
					mkdir(UP_GED.DS.'indice'.DS.$indice[0]->ano.DS.strtoupper(nomeMes($indice[0]->mes)));
				} 

				$path = UP_GED.DS.'indice'.DS.$indice[0]->ano.DS.strtoupper(nomeMes($indice[0]->mes));
				$data_hash 		= date('YmdHms');		
				$nome_hash      = strtolower($indice[0]->indice)."_".$indice[0]->ano."_".strtoupper(nomeMes($indice[0]->mes))."_".$data_hash.".pdf"; 
				$insert_ged_documento = [ 
					'nome_documento' => $nome_hash,
					'data_documento' => $this->data_hora_atual->format('Y-m-d'),
					'doc_origem'     => 'indice',
					'id_origem' 	 => $indice[0]->id, 
					'produto' 		 => null,
					'tipo' 			 => 'indice',
					'subtipo' 		 => $subtipo,
					'descricao' 	 => 'relatório indice de reajuste',
					'owner' 		 => $indice[0]->alterado_por,
					'data_criacao'   => $this->data_hora_atual->format('Y-m-d H:i:s'),
				];	

				$ged = json_decode($this->modelo->getGedDocumento($indice[0]->id, null, $subtipo));
				if(isset($ged) && !empty($ged)){
					$id_ged 	  = $ged[0]->id;
					$id_ged_anexo = $ged[0]->id_ged_anexo;
					
				}
				
				
				$this->modelo->setTable('ged_documento');
				$save_ged_documento = $this->modelo->save($insert_ged_documento,$id_ged);
							
				if(!$save_ged_documento){
					$retorno["codigo"]   = 1;
					$retorno["input"]    = $_POST;
					$retorno["output"]   = $this->modelo->info;
					$retorno["mensagem"] = "Erro em salvar na tabela ged_documento.";
					throw new Exception(json_encode($retorno),1);
				}else{		
					$hash_arquivo 	= md5($path);		
				}
							
				$insert_ged_anexo = [
					'id_documento'  => $save_ged_documento,
					'nome_amigavel' => strtolower($indice[0]->indice)."_".$indice[0]->ano."_".strtoupper(nomeMes($indice[0]->mes)),
					'path_root' 	=> 'ged_temp'.DS.'indice',
					'path_objeto' 	=> DS.$indice[0]->ano.DS.strtoupper(nomeMes($indice[0]->mes)),
					'nome_hash' 	=> $nome_hash,
					'hash_arquivo'  => $hash_arquivo,
					'data_criacao'  => $this->data_hora_atual->format('Y-m-d H:i:s'),
				];
									
				$this->modelo->setTable('ged_anexo');
				$save_ged_anexo = $this->modelo->save($insert_ged_anexo,$id_ged_anexo);			
				if(!$save_ged_anexo){
					$retorno['codigo']   = 1;
					$retorno['input']    = $insert_ged_anexo;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = 'Erro ao salvar no ged_anexo';
					throw new Exception (json_encode($retorno));
				}

				$doc_path = $path.DS.$nome_hash;

				$retorno['codigo']   = 0;
				$retorno['input']    = $doc_path;
				$retorno['output']   = $insert_ged_anexo;
				$retorno['mensagem'] = 'Sucesso';
				throw new Exception (json_encode($retorno));

			}catch(Exception $e){
				return $e->getMessage();
			}
		}

		function historicoPdf(){
			try{
				if(isset($this->parametros[0]) && !empty($this->parametros[0])){
					$id   = $this->parametros[0];
					$tipo = $this->parametros[1];
					$ged  = json_decode($this->modelo->getGedDocumento($id,null,$tipo));
					$path = UP_GED.DS."indice".$ged[0]->path_objeto.DS.$ged[0]->nome_hash;		
					
					if(isset($path) && !empty($path)){
						$link =  "/download_file.php?file=".base64_encode($path)."&download=true";	
						$retorno["codigo"]   = 0;
						$retorno["input"]    = $this->parametros;
						$retorno["output"]   = $link;
						$retorno["mensagem"] = "Sucesso";
						throw new Exception(json_encode($retorno),1);
					}else{
						$retorno["codigo"]   = 1;
						$retorno["input"]    = $this->parametros;
						$retorno["output"]   = null;
						$retorno["mensagem"] = "Error em montar path";
						throw new Exception(json_encode($retorno),1);
					}			
				}else{
					$retorno["codigo"]   = 1;
					$retorno["input"]    = $this->parametros;
					$retorno["output"]   = null;
					$retorno["mensagem"] = "Error em encontrar diretório";
					throw new Exception(json_encode($retorno),1);
				}		
			}catch(Exception $e){
				echo $e->getMessage();
			}
		}

		function save(){
			try {
				if(
					!isset($_POST) || 
					empty($_POST['indice']) ||
					empty($_POST['mes']) ||
					empty($_POST['ano']) ||
					empty($_POST['percentual'])
				){
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = null;
					$retorno['mensagem'] = 'Dados do indice não informados';
					throw new Exception(json_encode($retorno), 1);
				}else{
					$ano = $_POST['ano'];
					$mes = $_POST['mes'];
					$indice = $_POST['indice'];
				
				}
				$_POST['percentual'] = removeCaracteres($_POST['percentual'], 'moeda2');
				if(!empty($this->parametros[1]) && is_numeric($this->parametros[1])){
					$chk_reajuste = json_decode($this->modelo->getRecords($this->parametros[1]));
					if($chk_reajuste && $chk_reajuste[0]->lp_processado == 1){
						$retorno['codigo']   = 1;
						$retorno['input']    = $_POST;
						$retorno['output']   = $chk_reajuste;
						$retorno['mensagem'] = 'Indice já processado';
						throw new Exception(json_encode($retorno), 1);	
					}
				}else{
					$chk_reajuste = json_decode($this->modelo->getIndicesPorAnoMes($ano, $mes, $indice));
					if($chk_reajuste){
						$retorno['codigo']   = 1;
						$retorno['input']    = $_POST;
						$retorno['output']   = $chk_reajuste;
						$retorno['mensagem'] = 'Indice já processado';
						throw new Exception(json_encode($retorno), 1);	
					}
				}

				if(!isset($this->parametros[1]) || empty($this->parametros[1])){
					$_POST['criado_em'] = $this->data_hora_atual->format('Y-m-d');
				}

				$_POST['alterado_por'] = $this->userdata->id;
				$_POST['alterado_em']  = $this->data_hora_atual->format('Y-m-d');

				$is_save = $this->modelo->save($_POST, $this->parametros[1]);
				
				if($is_save){
					$retorno['codigo']   = 0;
					$retorno['input']    = $_POST;
					$retorno['output']   = $is_save;
					$retorno['mensagem'] = 'Sucesso';
					throw new Exception(json_encode($retorno), 1);
				}else{
					$retorno['codigo']   = 1;
					$retorno['input']    = $_POST;
					$retorno['output']   = $is_save;
					$retorno['mensagem'] = 'Erro ao gravar indice';
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function apagarIndice(){
			try {
				if( isset( $_POST['id'] ) && !empty( $_POST['id'] ) && is_numeric( $_POST['id'] ) ){
					$param['deleted'] = 1;
					$is_save = $this->modelo->save( $param, $_POST['id'] );
					if( $is_save ){
						$retorno['codigo']   = 0;
						$retorno['mensagem'] = 'Sucesso';
					}else{
						$retorno['codigo']   = 1;
						$retorno['mensagem'] = 'Erro ao apagar indice';
					}
				}else{
					$retorno['codigo']   = 1;
					$retorno['mensagem'] = 'Informe o indice';
				}
				throw new Exception( json_encode( $retorno ), 1);
			} catch ( Exception $e ) {
				echo $e->getMessage();
			}
		}

		function checkRelacionamentosHistoricos(){
			$this->cl_indice->checkRelacionamentosHistoricos();
		}
	}