<?php
    // require_once('classes/class-Validacao.php');
    class IntegracoesController extends MainController{
        function __construct( $parametros = null, $nome_modulo = 'integracoes', $do_login = false ){
            $this->setModulo('integracoes');
            $this->setView('integracoes');
            parent::__construct($parametros, $this->nome_modulo, $do_login );
        }

        function index(){
            $integracoes = json_decode($this->modelo->getAllIntegracao());
            require_once ABSPATH . '/views/'.$this->nome_view.'/index.php';
        }

        function extrato(){
            if( isset( $this->parametros[1] ) || !empty($this->parametros[1] ) ){
                $obj_integracao = new Integracoes( $this, $this->parametros[1] );
                $lancamentos = json_decode( $obj_integracao->Exec('transacao', 'extrato' ) );
                if($lancamentos->codigo == 0){
                    $extrato = $lancamentos->dados->rows;
                }else{
                    $extrato = null;
                }
            }
            require_once ABSPATH . '/views/'.$this->nome_view.'/extrato.php';
        }
    }
