<?php

class LogAcessoController extends MainController{

	function __construct ($parametros = null, $nome_modulo = false, $login = true){
		$this->setModulo('logacesso');
		$this->setView('logacesso');       
		parent::__construct($parametros, $nome_modulo, $login);
        $this->data_hora_atual;             			
	}	

    function index(){	

        include "config_extras.php";
                     
        if( isset($_POST['empresa']) && !empty($_POST['empresa']) ){
            $nome_empresa = $_POST['empresa'];
        }else{
            $nome_empresa = null;
        }

        if( isset($_POST['ip']) && !empty($_POST['ip']) ){
            $ip = $_POST['ip'];
        }else{
            $ip = null;
        }
        
        if( isset($_POST['vertical']) && !empty($_POST['vertical']) ){
            $vertical = $_POST['vertical'];
        }else{
            $vertical = null;
        }

        if( isset($_POST['site']) && !empty($_POST['site']) ){
            $site = $_POST['site'];
        }else{
            $site = null;
        } 
        $log = json_decode($this->modelo->getLogIpEmpresa($this->data_hora_atual->format('Y-m-d'),$site, $nome_empresa, $vertical, $ip));
        // echo "<pre>";
        //     var_dump( $this->data_hora_atual->format('Y-m-d'),$site, $nome_empresa, $vertical, $ip );
        // echo "</pre>";
        //  echo "<pre>";
        //     var_dump($log,$this->db);
        // echo "</pre>";
        
		require_once ABSPATH.'/views/'.$this->nome_view.'/diario-view.php';
	}	

    function getEmpresasJson(){
        $dados = null;
        if( isset($_POST['columns'][4]['search']['value']) && !empty($_POST['columns'][4]['search']['value']) ){
            $nome_empresa = $_POST['columns'][4]['search']['value'];
        }else{
            $nome_empresa = null;
        }

        if( isset($_POST['columns'][2]['search']['value']) && !empty($_POST['columns'][2]['search']['value']) ){
            $ip = $_POST['columns'][2]['search']['value'];
        }else{
            $ip = null;
        }
        
        if( isset($_POST['columns'][3]['search']['value']) && !empty($_POST['columns'][3]['search']['value']) ){
            $vertical = $_POST['columns'][3]['search']['value'];
        }else{
            $vertical = null;
        }

        if( isset($_POST['columns'][7]['search']['value']) && !empty($_POST['columns'][7]['search']['value']) ){
            $site = $_POST['columns'][7]['search']['value'];
        }else{
            $site = null;
        }
        
        if(isset($_POST['start']) && !empty($_POST['start'])){
            $start = $_POST['start'];
        }else{
            $start = 0;
        }
        
        if(isset($_POST['length']) && !empty($_POST['length'])){
            $length = $_POST['length'];
        }else{
            $length = null;
        }
        
        if(isset($_POST['draw']) && !empty($_POST['draw'])){
            $draw = $_POST['draw'];
        }else{
            $draw = 1;
        }
        // echo '<pre>';
        //     var_dump($vertical, $_POST['columns'][0]['search']['value']);
        // echo '</pre>';
        // exit;
        $total_registros   = json_decode($this->modelo->getLogIpEmpresa($this->data_hora_atual->format('Y-m-d'),$site, $nome_empresa, $vertical, $ip));
        $parcial_registros = json_decode($this->modelo->getLogIpEmpresa($this->data_hora_atual->format('Y-m-d'),$site, $nome_empresa, $vertical, $ip, $start, $length));
        $dados['draw']         = $draw;
        $dados['recordsTotal'] = count($total_registros);
        $dados['data']         = $parcial_registros; 
        echo json_encode($dados);
    }

    function bloqueado(){

        include "config_extras.php";        
        // $empresa = json_decode($this->modelo->getEmpresa(null,null,null,true));

        if(isset($_POST['empresa']) && !empty($_POST['empresa'])){
            $nome_empresa = $_POST['empresa'];
        }

        if(isset($_POST['vertical']) && !empty($_POST['vertical'])){
           $vertical = $_POST['vertical'];
        }

        if(isset($_POST['limite']) && !empty($_POST['limite'])){
            $limite = $_POST['limite'];
        }else{
            $limite = 100;
        }

        if( isset($_POST['bloqueado']) ){
            if( empty($_POST['bloqueado']) && $_POST['bloqueado'] != "0"){
                $bloqueado = null;
            }else{
                $bloqueado = $_POST['bloqueado'];
            }
        }else{
            $bloqueado = 1;
        }
         
        $empresa_block = json_decode($this->modelo->getEmpresa($bloqueado,null,$vertical,$limite,false,$nome_empresa));
                                
		require_once ABSPATH.'/views/'.$this->nome_view.'/bloqueado-view.php';

    }

    function contadorAcesso(){

        include "config_extras.php"; 

        try{

            $hoje = getDataAtual();			
            if(isset($_POST['data']) && !empty($_POST['data'])){               
                $data = getDataAtual($_POST['data']);				
            }else{
                $data = getDataAtual();               				
            }
                    
            if( isset($_POST['site']) && !empty($_POST['site']) ){
                $site = $_POST['site'];
            }else{
                $site = null;
            }
            $get_acesso = json_decode($this->modelo->getLogCount($data->format('Y-m-d'), $site));          
        }catch(Exception $e){
            echo $e->getMessage();
        }
		
		require_once ABSPATH.'/views/'.$this->nome_view.'/contador_acesso-view.php';

    }

    function identificadorIp(){

        include "config_extras.php"; 
       
        if( isset($_POST['empresa']) && !empty($_POST['empresa']) ){
            $nome_empresa = $_POST['empresa'];
        }
        
        if( isset($_POST['vertical']) && !empty($_POST['vertical']) ){
            $vertical = $_POST['vertical'];
        } 

        if( isset($_POST['limite']) && empty($_POST['limite']) ){
            $limite = $_POST['limite'];
        }else{
            $limite = 100;
        }

        $empresa = json_decode($this->modelo->getEmpresa(null,null,$vertical,$limite,null,$nome_empresa));

        require_once ABSPATH.'/views/'.$this->nome_view.'/identificador_ip-view.php';
    }

    function vertical(){
        include "config_extras.php";
        $lista_verifcal = json_decode($this->modelo->groupVertical());
        if(isset($_POST['empresa'])){
            $nome_empresa = $_POST['empresa'];
        }
        
        if(isset($_POST['vertical'])){
            $vertical = $_POST['vertical'];
        }else{
            $vertical = 'NAO_DEFINIDO';
        }
        $empresas = json_decode($this->modelo->getEmpresaPorVertical($vertical, $nome_empresa));
		require_once ABSPATH.'/views/'.$this->nome_view.'/vertical-view.php';
    }
    
    function logDetalhe(){
        try{
            if(!$this->parametros[0]){
                $retorno["codigo"] = 1;
                $retorno["input"] = $this->parametros[0];
                $retorno["output"] = $this->modelo->info;
                $retorno["mensagem"] = "Erro ID";
                throw new Exception(json_encode($retorno),1);
            }else{
                $id = $this->parametros[0];
            }
            switch ($this->parametros[1]) {
               case 'referer':
                    $log = json_decode($this->modelo->getLog($id));
                    if( isset($log) && !empty($log) ){
                        $str = array("https://","http://","https:/", "http:/");
                        $referer = str_replace($str, "", $log[0]->referer);
                        $referer = explode("/",$referer);
                        foreach ($referer as $key => $value) {
                            if(!empty($value)){
                                $output['dados'][] = $value;
                            }
                        }
                        if(isset($output['dados']) && !empty($output['dados'])){
                            $output['codigo'] = 0;
                        }else{
                            $output['codigo'] = 1;
                            $output['mensagem'] = "Sem referer";
                        }
                        $output['texto'] = "Referer";
                    }else{
                        $output['codigo'] = 1;
                        $output['mensagem'] = "Sem referer";
                    }
                   break;
                case 'others':
                    $log = json_decode($this->modelo->getIp(null,$id));
                    if( isset($log) && !empty($log) ){
                        foreach ($log  as $key => $value) {
                            $output['dados'][] = $value->ipv4;
                        }
                        $output['texto'] = "Others IPs";
                        $output['codigo'] = 0;
                    }else{
                        $output['codigo'] = 1;
                        $output['mensagem'] = "Sem others ips";
                    }
                   break;
                case 'ips':
                    $ips = json_decode($this->modelo->getIp(null,$id));
                    if( isset($ips) && !empty($ips) ){
                        foreach ($ips as $key => $value) {
                            $output['dados'][] = $value->ipv4;
                        }
                        $output['texto'] = "IPs";
                        $output['codigo'] = 0;
                    }else{
                        $output['codigo'] = 1;
                        $output['mensagem'] = "Sem IPs";
                    }
                   break;
               default:
                $retorno["codigo"] = 1;
                $retorno["input"] = $this->parametros[0];
                $retorno["output"] = null;
                $retorno["mensagem"] = "Parâmetro desconhecido.";
                throw new Exception(json_encode($retorno),1);
                   break;
            }
            if($output['codigo'] == 0){
                $retorno["codigo"] = 0;
                $retorno["input"] = $this->parametros[0];
                $retorno["output"] = $output;
                $retorno["mensagem"] = "Sucesso";
                throw new Exception(json_encode($retorno),1);
            }else{
                $retorno["codigo"] = 1;
                $retorno["input"] = $this->parametros;
                $retorno["output"] = "Sem IP";
                $retorno["mensagem"] = $output['mensagem'];
                throw new Exception(json_encode($retorno),1);
            }
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }
    
    function bloquear(){
        try{            

            if(!isset($this->parametros[0]) || empty($this->parametros[0])){
                $retorno["codigo"] = 1;
                $retorno["input"] = $this->parametros;
                $retorno["output"] = null;
                $retorno["mensagem"] = "Erro parâmetros";
                throw new Exception(json_encode($retorno),1);
            }else{
                if($this->parametros[0] === "true"){
                    $update['blocked'] = 1;
                }else{
                    $update['blocked'] = 0;
                }
            }

            if(!isset($this->parametros[1]) || empty($this->parametros[1])){
                $retorno["codigo"] = 1;
                $retorno["input"] = $this->parametros;
                $retorno["output"] = null;
                $retorno["mensagem"] = "Erro parâmetros";
                throw new Exception(json_encode($retorno),1);
            }else{
                $id_update = $this->parametros[1];
            }
                               
            $this->modelo->setTable('empresa');
            $update_blocked = $this->modelo->save($update,$id_update);

            if($update_blocked){
                $retorno["codigo"] = 0;
                $retorno["input"] = $this->parametros;
                $retorno["output"] =  $update_blocked;
                $retorno["mensagem"] = "Sucesso";
                throw new Exception(json_encode($retorno),1);
            }else{
                $retorno["codigo"] = 1;
                $retorno["input"] = $this->parametros;
                $retorno["output"] = $this->modelo->info;
                $retorno["mensagem"] = "Erro ao salvar no banco.";
                throw new Exception(json_encode($retorno),1);
            }

        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    function definirVertical(){
        try {
           
            if( !isset($this->parametros[0]) || empty($this->parametros[0]) ){
                $retorno["codigo"] = 1;
                $retorno["input"] = $this->parametros;
                $retorno["output"] = null;
                $retorno["mensagem"] = "Erro parâmetros";
                throw new Exception(json_encode($retorno),1);
            }else{
                $id_empresa = $this->parametros[0];
            }

            if( !isset($_POST['vertical']) || empty($_POST['vertical']) ){
                $retorno["codigo"] = 1;
                $retorno["input"] = $this->parametros;
                $retorno["output"] = $_POST;
                $retorno["mensagem"] = "Informe a vertical.";
                throw new Exception(json_encode($retorno),1);
            }else{
                $update['vertical'] = $_POST['vertical'];
            }

            $this->modelo->setTable('empresa');
            $save_vertical = $this->modelo->save($update,$id_empresa);

            if($save_vertical){
                $retorno["codigo"] = 0;
                $retorno["input"] = $this->parametros;
                $retorno["output"] = null;
                $retorno["mensagem"] = "Sucesso";
                throw new Exception(json_encode($retorno),1);
            }else{
                $retorno["codigo"] = 1;
                $retorno["input"] = $this->parametros;
                $retorno["output"] = $this->modelo->info;
                $retorno["mensagem"] = "Erro BD.";
                throw new Exception(json_encode($retorno),1);
            }

        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function lerMais(){
        try{
            if( !isset($this->parametros[0]) || empty($this->parametros[0]) ){
                $retorno["codigo"] = 1;
                $retorno["input"] = $this->parametros;
                $retorno["output"] = null;
                $retorno["mensagem"] = "Erro parâmetros.";
                throw new Exception(json_encode($retorno),1);
            }
            if( !isset($this->parametros[1]) || empty($this->parametros[1]) ){
                $retorno["codigo"] = 1;
                $retorno["input"] = $this->parametros;
                $retorno["output"] = null;
                $retorno["mensagem"] = "Erro parâmetros.";
                throw new Exception(json_encode($retorno),1);
            }else{
                $id_log = $this->parametros[1];
                $log = json_decode($this->modelo->getLog($id_log));
                if(!isset($log) || empty($log)){
                    $retorno["codigo"] = 1;
                    $retorno["input"] = $this->parametros;
                    $retorno["output"] = null;
                    $retorno["mensagem"] = "Erro em obter texto do log.";
                    throw new Exception(json_encode($retorno),1);
                }else{
                    $retorno["codigo"] = 0;
                    $retorno["input"] = $this->parametros;
                    $retorno["output"] = $log;
                    $retorno["mensagem"] = "Sucesso";
                    throw new Exception(json_encode($retorno),1);
                }
            }                       
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }
						
	
}


