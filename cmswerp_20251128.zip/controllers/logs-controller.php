<?php
class LogController extends MainController{
	protected $module = 'log';
	function __construct($parametros = false)	{
		// require_once('classes/class-WebService.php');
		$this->nome_modulo = 'log';
		parent::__construct($parametros);
	}
}
?>
