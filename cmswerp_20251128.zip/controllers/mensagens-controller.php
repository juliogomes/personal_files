<?php
class MensagensController extends MainController{
	protected $module = 'mensagens';
	protected $obj_contrato;
	protected $obj_nota;
	function __construct($parametros){
		$this->nome_modulo = 'mensagens';
		parent::__construct($parametros);
		$controller = new MainController(null, 'tarifador');
		$this->obj_nota = $controller->load_model('notas-fiscais/notas-fiscais', true);
		$this->obj_contrato = $this->load_model('contratos/contratos', true);
	}

	function index(){
		$this->listar();
	}

	function listar(){
		$mensagens = json_decode($this->modelo->getAllMessages());
		require_once ABSPATH . '/views/'.$this->module.'/mensagens-view.php';
	}

	function detalhe(){
		if(isset($this->parametros[1]) && is_numeric($this->parametros[1]) && !empty($this->parametros[1])){
			$id = $this->parametros[1];
			$contratos = json_decode($this->obj_contrato->contratosAtivos());
			$records = json_decode($this->modelo->getMessageAtivas($id));
		}else{
			$id = null;
		}
		require_once ABSPATH . '/views/'.$this->module.'/mensagem-detalhe-view.php';
	}


	function save(){
		if(isset($_POST)  && !empty($_POST)){
			if(isset($this->parametros[1]) && is_numeric($this->parametros[1])){
				$id = $this->parametros[1];
			}else{
				$id = null;
			}
			$_POST['ativo_de'] = convertDate($_POST['ativo_de']);
			$_POST['ativo_ate'] = convertDate($_POST['ativo_ate']);
			$this->modelo->save($_POST, $id);
			header('location: /mensagens/');
		}
	}

	function deletar(){
		if(isset($this->parametros[1]) && is_numeric($this->parametros[1])){
			$id = $this->parametros[1];
			$param['deleted'] = 1;
			$this->modelo->save($param, $id);
		}
		header('location: /mensagens/');
	}
}
?>
