<?php

use function PHPSTORM_META\type;

class ModeloController extends MainController
{
	protected
		$produtos_model,
		$obj_minuta,
		$minuta,
		$dicionario;
	private $gedModel;

	function __construct($parametros, $do_login = true)
	{
		$this->setModulo('modelo');
		$this->setView('modelo');
		parent::__construct($parametros, 'modelo', $do_login);
		$this->produtos_model = $this->load_model('produtos/produtos', true);
		$this->gedModel = $this->load_model('ged/ged', true);

		$this->minuta = new Minuta($this);
		include "config_extras.php";
		$this->dicionario = $VAR_SYSTEM['DICIONARIO_TAG'];
	}

	function index()
	{
		$produtos  = json_decode($this->produtos_model->getProduto(null, false, true));
		if (isset($produtos) && is_array($produtos)) {
			foreach ($produtos as $key => $value) {
				switch ($value->modelo_contrato == 1) {
					case 'ADM0001':
						$value->nome = "Customização de Software";
						$records[] 	 = $value;
						break;
					default:
						$records[] = $value;
						break;
				}
			}
		}
		require_once ABSPATH . '/views/' . $this->nome_view . '/index-view.php';
	}

	public function downloadModemoContrato()
	{
		$cod_produto = $this->parametros[0];
		$tipo = $this->parametros[1];
		$nome = $this->parametros[2];

		//luciano - apagar
		// $path = 'C:' . DS . 'Users' . DS . 'LucianoEricDamasceno' . DS . 'Documents' . DS . 'projetos' . DS . 'tarifador_php5' . DS . "/usr/doc/ged/modelos_contrato" . DS . $cod_produto . DS . ($nome  ? $nome  : 'modelo_contrato.' . $tipo);

		$path = "/usr/doc/ged/modelos_contrato" . DS . $cod_produto . DS . ($nome  ? $nome  : 'modelo_contrato.'. $tipo);

		if (!file_exists($path)) {
			die("Arquivo não encontrado");
		}

		if (ob_get_level()) {
			ob_end_clean();
		}

		header("Content-Description: File Transfer");
		if ($tipo == 'docm') {
			header("Content-Type: application/vnd.ms-word.document.macroEnabled.12");
		} else if ($tipo == 'docx') {
			header("Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document");
		}
		header('Content-Disposition: attachment; filename="' . ($nome  ? $nome  : 'modelo_contrato.' . $tipo) . '"');
		header("Content-Transfer-Encoding: binary");
		header("Expires: 0");
		header("Cache-Control: must-revalidate");
		header("Pragma: public");
		header("Content-Length: " . filesize($path));

		readfile($path);
		exit;
	}

	function contrato()
	{
		$cod_produto = $this->parametros[0];
		$this->gedModel->setTable('ged_documento');
		$docs = $this->gedModel->obtemModeloContratoAtivo($cod_produto, null);
		if ($docs) {
			$docs    = json_decode($docs);
			$produto = json_decode($this->produtos_model->getProduto(null, $cod_produto));

		}
		require_once ABSPATH . '/views/' . $this->nome_view . '/modelov2-view.php';
	}

	public function uploadModelo()
	{

		try {
			$produto = $_GET['produto'];
			$files = $_FILES;
			$hasDoc = false;
			foreach ($files as $key => $value) {
				if ($value['size'] > 0) {
					$hasDoc = true;
				}
			}

			if (!$hasDoc) {
				$retorno['codigo']   = 0;
				$retorno['input']    = null;
				$retorno['output']   = null;
				$retorno['mensagem'] = 'Nenhum arquivo enviado';
				throw new Exception(json_encode($retorno), 1);
			}

			foreach ($_FILES as $file) {
				if ($file['size'] == 0) {
					continue;
				}
				$pathinfo = pathinfo($file['name']);
				$extension = $pathinfo['extension'];

				$res = json_decode($this->uploadAnexo($produto, 'modelo_contrato.' . $extension, $file['tmp_name']));
				if (!$res || $res->codigo == 0) {
					$retorno['codigo'] = 0;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = $res->mensagem;
					throw new Exception(json_encode($retorno), 1);
				}

				$this->gedModel->setTable('ged_documento');
				$lastAnexo = $this->gedModel->obtemModeloContratoAtivo($produto, 'modelo_contrato.' . $extension);
				if ($lastAnexo) {
					$lastAnexo = json_decode($lastAnexo);

					$newName = strtotime('now') . "_modelo_contrato" . '.' . $extension;
					$newPath = str_replace('modelo_contrato' . '.' . $extension, $newName, $lastAnexo[0]->path_objeto);
					$save_anexo = $this->gedModel->save(['nome_documento' => $newName], $lastAnexo[0]->gd_id);
					if ($save_anexo) {
						$this->gedModel->setTable('ged_anexo');
						$save_anexo = $this->gedModel->save(['path_objeto' => $newPath], $lastAnexo[0]->ga_id);

						copy($lastAnexo[0]->path_root . $lastAnexo[0]->path_objeto, $lastAnexo[0]->path_root . $newPath);
						// unlink($lastAnexo[0]->path_root . $lastAnexo[0]->path_objeto);
					}
				}
				$this->gedModel->setTable('ged_documento');

				$output = (object) $res->output;
				$ged['nome_documento'] = 'modelo_contrato.' . $extension;
				$ged['data_documento'] = $this->data_hora_atual->format('Y-m-d');
				$ged['valido_ate'] = '';
				$ged['id_origem'] = null;
				$ged['doc_origem'] = $produto;
				$ged['tipo'] = 'contrato';
				$ged['subtipo'] = 'modelo de contrato';
				$ged['classificacao'] = null;
				$ged['descricao'] = 'Documento de Modelo de Contrato';
				$ged['versao'] = '';
				$ged['owner'] = $_SESSION['cmswerp']['userdata']->id;
				$ged['data_criacao'] = $this->data_hora_atual->format('Y-m-d');
				$ged['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
				$ged['alterado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
				$ged['deleted'] = '0';

				$save_ged_documento = $this->gedModel->save($ged);
				if ($save_ged_documento) {
					$ged_anexo['id_documento'] = $save_ged_documento;
					$ged_anexo['nome_amigavel'] = 'modelo_contrato.' . $extension;
					$ged_anexo['path_root'] = $output->pathRoot;
					$ged_anexo['path_objeto'] = DS . $produto . $output->path_objeto;
					$ged_anexo['nome_hash'] = md5($output->name);
					$ged_anexo['hash_arquivo'] = md5(file_get_contents($output->pathRoot . $output->path_objeto . DS . 'modelo_contrato.' . $extension));
					$ged_anexo['data_criacao'] = $this->data_hora_atual->format('Y-m-d H:i:s');
					$ged_anexo['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
					$ged_anexo['alterado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
					$ged_anexo['deleted'] = 0;
					$this->gedModel->setTable('ged_anexo');
					$save_anexo = $this->gedModel->save($ged_anexo);
					if (!$save_anexo) {
						$retorno['codigo'] = 0;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Erro ao salvar o anexo.";
						throw new Exception(json_encode($retorno), 1);
					}

					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Arquivo enviado com sucesso.";
					throw new Exception(json_encode($retorno), 1);
				}
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function uploadAnexo($produto, $docName, $tmpName)
	{
		try {

			$path = UP_GED . DS . 'modelos_contrato';

			if (!is_dir($path)) {
				mkdir($path);
			}

			$path_produto = $path . DS . strtoupper($produto);

			if (!is_dir($path_produto)) {
				mkdir($path_produto);
			}

			$file['name'] = strtolower($docName);
			$file['tmp_name'] = $tmpName;
			$config['pasta'] = $path_produto;
			$config['allow_size'] = 164000000000;


			$class_upload = new Upload($this, $file, $config);
			$class_upload->checkArquivo();
			$load = $class_upload->loadFile($file, $config);
			$retorno_json = json_decode($load);

			if ($retorno_json->codigo != 0) {
				$retorno["codigo"] = 0;
				$retorno["input"] = $file;
				$retorno["output"] = null;
				$retorno["mensagem"] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno_json->dados->path = $path_produto;
				$retorno["codigo"] = 1;
				$retorno["input"] = $file;
				$retorno["output"] = ['path_objeto' => DS . $file['name'], 'pathRoot' => $path];
				$retorno["mensagem"] = "Arquivo enviado com sucesso.";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	function salvarModelo()
	{
		try {
			if (!is_array($_POST['modelo_contrato'])) {
				$texto_modelo[0] = $_POST['modelo_contrato'];
			}
			$cod_produto  = $this->parametros[0];
			$contador_tag = $this->minuta->checkTag($cod_produto);
			if (isset($texto_modelo) && !empty($texto_modelo)) {
				//ESSA FUNCTION VERIFICA ESSE TAGs PADRÃO FORAM ALTERADAS OU EDITADAS
				$verifica_tag = json_decode($this->minuta->verificaTag($cod_produto, $texto_modelo, $contador_tag));
				if ($verifica_tag->codigo == 1) {
					$retorno['codigo']   = 1;
					$retorno['input']    = $verifica_tag->input;
					$retorno['output']   = $verifica_tag->output;
					$retorno['mensagem'] = $verifica_tag->mensagem;
					throw new Exception(json_encode($retorno), 1);
				}
			} else {
				$retorno['codigo']   = 1;
				$retorno['input']    = $_POST;
				$retorno['output']   = null;
				$retorno['mensagem'] = "Erro requisição";
				throw new Exception(json_encode($retorno), 1);
			}

			$get_modelo = json_decode($this->modelo->getModelo($cod_produto));
			$insert['codigo_produto'] = $cod_produto;
			$this->modelo->setTable("modelo_contrato_default");
			foreach ($texto_modelo as $key => $value) {
				$insert['pagina'] = $key + 1;
				$insert['texto']  = $value;
				$save_modelo 	  = $this->modelo->save($insert, $get_modelo[$key]->id);
				if (!$save_modelo) {
					$retorno['codigo']   = 1;
					$retorno['input']    = null;
					$retorno['output']   = $this->modelo->info;
					$retorno['mensagem'] = "Erro ao salvar modelo no banco de dados";
					throw new Exception(json_encode($retorno), 1);
				}
			}

			if ($save_modelo) {
				$retorno['codigo']   = 0;
				$retorno['input']    = $insert;
				$retorno['output']   = $cod_produto;
				$retorno['mensagem'] = "Sucesso";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function getDicionario()
	{
		try {
			if (isset($this->parametros[0]) && !empty($this->parametros[0])) {
				$produto = $this->parametros[0];
				if ($produto == "TESTEMUNHAS") {
					$dicionario =  $this->dicionario['REPRESENTANTE'];
				} else if ($produto == "SPB") {
					$dicionario =  $this->dicionario['VALORES']['SPB/X OBE'];
				} else {
					$dicionario = $this->dicionario['VALORES'][$produto];
				}
			}
			if (isset($dicionario) && !empty($dicionario)) {

				foreach ($dicionario as $key => $value) {
					$html .= "<tr class='tag_produto' style='text-align:center'>";
					$html .= "<td>" . $key . "</td>";
					$html .= "<td>" . $value . "</td>";
					$html .= "</tr>";
				}

				if (isset($html) && !empty($html)) {
					$retorno['codigo']   = 0;
					$retorno['input']    = $this->parametros;
					$retorno['output']   = $html;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno), 1);
				}
			} else {
				$retorno['codigo']   = 1;
				$retorno['input']    = $this->parametros;
				$retorno['output']   = null;
				$retorno['mensagem'] = "Erro produtos";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function viewExample()
	{
		require_once "libs/mpdf/vendor/autoload.php";
		$example   = json_decode($this->minuta->gerarMinuta($this->parametros[1]));
		$style_documento = file_get_contents('assets/css/css_pdf.css');
		// $style_table = file_get_contents('assets/css/css_pdf_table.css');
		$style_table = file_get_contents('assets/css/css_table_crystal_bmc.css');
		$corpo_table = '
				<br /><br /><br /><br /><br /><br /><br /><br /><br />
				<!DOCTYPE html>
				<html lang="en">
				<head>
					<meta charset="UTF-8">
					<meta name="viewport" content="width=device-width, initial-scale=1.0">
					<style>
                	    ' . $style_table . '
                	</style>
					<title>Document</title>
				</head>
				<body>
					' . $example->output[0] . '		
				</body>
				</html>
			';

		$mpdf = new \Mpdf\Mpdf([
			'debug' => true,
			'allow_output_buffering' => true
		]);
		$mpdf->SetHeader();
		// $mpdf->AddPage();
		$mpdf->SetHTMLHeader('<div style="text-align:right;"><img height="45px" src="assets/images/c_m_software_logo_since_1999.png"></img></div>', null, true);
		$mpdf->WriteHTML($style_table, \Mpdf\HTMLParserMode::HEADER_CSS);
		$mpdf->WriteHTML($example->output[0], \Mpdf\HTMLParserMode::HTML_BODY);
		$mpdf->Output();
	}

	function viewEmBrowser()
	{
		// $example   = json_decode( $this->minuta->gerarMinuta( $this->parametros[1] ) );
		// echo $corpo_table = '
		// 	<!DOCTYPE html>
		// 	<html lang="en">
		// 	<head>
		// 		<meta charset="UTF-8">
		// 		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		// 		<link rel="stylesheet" type="text/css" href="assets/css/css_table_crystal_bmc.css">
		// 		<title>Document</title>
		// 	</head>
		// 	<body>
		// 		'.$example->output[0].'		
		// 	</body>
		// 	</html>
		// ';
		// require_once "libs/mpdf/vendor/autoload.php";
		// require_once('assets/css/css_table_crystal_bmc.css');
		// echo file_get_contents('assets/css/css_table_crystal_bmc.css');
		// echo $example->output[0];
	}
}
