<?php
class OrcamentoController extends MainController
{
	protected
		$obj_orcamento, $obj_despesas;
	function __construct($parametros = null)
	{
		$this->setModulo('orcamento');
		$this->setView('orcamento');
		parent::__construct($parametros);
		//Class Orcamento na pasta class
		$this->obj_orcamento = new Orcamento($this, $parametros);
		$this->obj_despesas = $this->load_model('despesas/despesas', true);
		$this->obj_nf  		 = $this->load_model('notas-fiscais/notas-fiscais', true);
		$this->obj_contratos = $this->load_model('contratos/contratos', true);
	}

	function index()
	{
		$this->listar();
	}

	function listar()
	{

		if (isset($_POST['centro_custo'])) {
			$centro_custo = $_POST['centro_custo'];
		} else {
			$centro_custo = null;
		}

		if (isset($_POST['grupo'])) {
			$grupo = $_POST['grupo'];
		} else {
			$grupo = null;
		}

		if (isset($_POST['conta'])) {
			$conta = $_POST['conta'];
		} else {
			$conta = null;
		}

		if (isset($_POST['subconta'])) {
			$subconta = $_POST['subconta'];
		} else {
			$subconta = null;
		}

		if (isset($_POST['ano'])) {
			$ano = $_POST['ano'];
		} else {
			$ano = $this->data_hora_atual->format('Y');
		}

		$lancamentos = json_decode($this->modelo->getLancamentosAgrupado($ano, $centro_custo, $grupo, $conta, $subconta));
		require_once ABSPATH . '/views/' . $this->nome_view . '/orcamento-view.php';
	}

	function orcamentoComercial()
	{
		if (isset($_POST['ano_comercial']) && !empty($_POST['ano_comercial']) && is_numeric($_POST['ano_comercial'])) {
			$ano_comercial = $_POST['ano_comercial'];
		} else {
			$ano_comercial = $this->data_hora_atual->format('Y');
		}
		$contratos = json_decode($this->obj_contratos->getContratosPorAnoAssinatura($ano_comercial));
		if ($contratos) {
			$ano_ini = $ano_comercial . '-01-01';
			$ano_fim = $ano_comercial . '-12-31';
			foreach ($contratos as $key => $value) {
				$id_contratos[] = $value->id_contrato;
			}
			$nfs = json_decode($this->obj_nf->getSomaNotaByPeriodoEcontrato($ano_ini, $ano_fim, $id_contratos));
		} else {
			echo false;
		}
		require_once ABSPATH . '/views/' . $this->nome_view . '/orcamento-comercial-view.php';
	}

	function transferencia()
	{
		// $config_orcamento = json_decode($this->config[0]->controle_orcamento);
		$periodo_controle = $config_orcamento->periodo_controle;
		$organizar_por    = 'centro_custo';

		if (isset($_POST['ano']) && !empty($ano)) {
			$ano = $_POST['ano'];
		} else {
			$ano = $this->data_hora_atual->format('Y');
		}

		$meses = returMes();
		$lista_centro_custo = json_decode($this->modelo->getCentroCusto());
		$lista_grupo        = json_decode($this->modelo->getGrupo());
		$lista_conta        = json_decode($this->modelo->getConta());

		$dados_orcamento = json_decode($this->obj_orcamento->getDadosOrcamento($param));
		require_once ABSPATH . '/views/' . $this->nome_view . '/transferencia-view.php';
	}



	function detalhe()
	{

		if (isset($this->parametros[3]) &&  !empty($this->parametros[3])) {
			$id_subconta = $this->parametros[3];
		} else {
			$id_subconta = null;
		}

		$centro_custo = json_decode($this->modelo->getCentroCusto($this->parametros[0]));
		$grupo_custo  = json_decode($this->modelo->getGrupo($this->parametros[1]));
		$contas       = json_decode($this->modelo->getConta());
		$sub_contas   = json_decode($this->modelo->getSubConta());
		$lancamentos  = json_decode($this->modelo->getLancamentoByParam(
			$this->parametros[0],
			$this->parametros[1],
			$this->parametros[2]
		));

		require_once ABSPATH . '/views/' . $this->nome_view . '/lancamento-view.php';
	}

	function newLancamento()
	{
		$centro_custo = json_decode($this->modelo->getCentroCusto());
		$grupo_custo  = json_decode($this->modelo->getGrupo());
		$contas       = json_decode($this->modelo->getConta());
		$sub_contas   = json_decode($this->modelo->getSubConta());
		require_once ABSPATH . '/views/' . $this->nome_view . '/lancamento-view.php';
	}

	function getSubConta()
	{
		if (isset($_GET['id_conta']) && is_numeric($_GET['id_conta'])) {
			$id_conta = $_GET['id_conta'];
		} else {
			$id_conta = null;
		}
		$sub_contas = $this->modelo->getSubContaByConta($id_conta);
		echo $sub_contas;
	}

	function savelancamento()
	{

		if ($_POST['id_cc']) {
			$param['id_cc'] = $_POST['id_cc'];
		} else {
			$param['id_cc'] = $this->parametros[0];
		}

		if ($_POST['id_grupo']) {
			$param['id_grupo'] = $_POST['id_grupo'];
		} else {
			$param['id_grupo'] = $this->parametros[1];
		}

		if ($_POST['id_conta']) {
			$param['id_conta'] = $_POST['id_conta'];
		} else {
			$param['id_conta'] = $this->parametros[2];
		}

		if ($_POST['id_subconta']) {
			$param['id_subconta'] = $_POST['id_subconta'];
		} else {
			$param['id_subconta'] = $this->parametros[3];
		}

		if ($_POST['ano']) {
			$param['ano'] = $_POST['ano'];
		} else {
			$param['ano'] = $this->parametros[4];
		}

		if ($_POST['tipo']) {
			$param['tipo'] = $_POST['tipo'];
		} else {
			$param['tipo'] = $this->parametros[5];
		}

		$param['valor'] = removeCaracteres($_POST['valor'], 'moeda2');
		$param['mes'] = $_POST['mes'];
		$this->modelo->save($param);
		header('Location: /orcamento/detalhe/' . $param['id_cc'] . '/' . $param['id_grupo'] . '/' . $param['ano']);
	}

	function transferenciaAjax()
	{
		$retorno              = null;
		$ano	              = null;
		$config_orcamento     = null;
		$valor_mensal 		  = null;
		try {
			$param_origem['origem'] = $_POST['sel_origem'];
			$param_origem['ano']    = $_POST['ano'];
			$param_origem['tipo']   = $_POST['tipo'];
			$param_origem['meses']  = $_POST['meses_origem'];
			$param_origem['destino'] = $_POST['sel_destino'];
			$param_destino['ano']   = $_POST['ano'];
			$param_destino['tipo']  = $_POST['tipo'];
			$param_destino['meses'] = $_POST['meses_destino'];

			$_POST['valor'] = removeCaracteres($_POST['valor'], 'moeda2');
			$this->config_model = $this->load_model('configuracoes/configuracoes', true);
			$this->config_list  = json_decode($this->config_model->getConfiguracoes());
			$config_orcamento = json_decode($this->config_list[0]->controle_orcamento);
			$param_origem['agrupar_por']     = $config_orcamento->nivel_controle;
			$param_origem['periodo']         = $config_orcamento->periodo_controle;
			$param_origem['valor']           = $_POST['valor'];
			if ('centro_custo' == $_POST['sel_origem']) {
				if (isset($_POST['centro_custo_origem']) && !empty($_POST['centro_custo_origem'])) {
					$param_origem['id_centro_custo'] = $_POST['centro_custo_origem'];
				}
			} elseif ('grupo' == $_POST['sel_origem']) {
				if (isset($_POST['grupo_origem']) && !empty($_POST['grupo_origem'])) {
					$param_origem['id_centro_custo'] = $_POST['centro_custo_origem'];
					$param_origem['id_grupo']        = $_POST['grupo_origem'];
				}
			} elseif ('conta' == $_POST['sel_origem']) {
				if (isset($_POST['conta_origem']) && !empty($_POST['conta_origem'])) {
					$param_origem['id_centro_custo'] = $_POST['centro_custo_origem'];
					$param_origem['id_grupo'] = $_POST['grupo_origem'];
					$param_origem['id_conta'] = $_POST['conta_origem'];
				}
			};

			$dados['origem'] = $this->obj_orcamento->getSaldo($param_origem);
			$param_destino['agrupar_por']     = $config_orcamento->nivel_controle;
			$param_destino['periodo']         = $config_orcamento->periodo_controle;
			$param_destino['valor']           = $_POST['valor'];

			if ('centro_custo' == $_POST['sel_destino']) {
				if (isset($_POST['centro_custo_destino']) && !empty($_POST['centro_custo_destino'])) {
					$param_destino['id_centro_custo'] = $_POST['centro_custo_destino'];
				}
			} elseif ('grupo' == $_POST['sel_destino']) {
				if (isset($_POST['grupo_destino']) && !empty($_POST['grupo_destino'])) {
					$param_destino['id_centro_custo'] = $_POST['centro_custo_destino'];
					$param_destino['id_grupo']        = $_POST['grupo_destino'];
				}
			} elseif ('conta' == $_POST['sel_destino']) {
				if (isset($_POST['conta_destino']) && !empty($_POST['conta_destino'])) {
					$param_destino['id_centro_custo'] = $_POST['centro_custo_destino'];
					$param_destino['id_grupo']        = $_POST['grupo_destino'];
					$param_destino['id_conta']        = $_POST['conta_destino'];
				}
			}

			$dados['destino']          = $this->obj_orcamento->getSaldo($param_destino);
			$dados['destino_original'] = $this->obj_orcamento->getSaldo($param_destino);

			if ('transferir' == $_POST['action']) {
				$mo = $param_origem['origem'];

				if (isset($dados['origem']) && !empty($dados['origem'])) {
					foreach ($dados['origem'] as $key => $value) {
						if (!$value['dados']['auth_transf'] || $value['dados']['saldo_final'] < 0) {
							$retorno['status']      = 'error';
							$retorno['codigo']      = 2;
							$retorno['tipo']        = 'danger';
							$retorno['post']        = $_POST;
							$retorno['dados']       = $value['dados'];
							$retorno['mensagem']    = 'Valor da transferencia acima do saldo disponivel';
							throw new Exception(json_encode($retorno), 1);
						}
					}
				} else {
					$retorno['status']      = 'error';
					$retorno['codigo']      = 2;
					$retorno['tipo']        = 'danger';
					$retorno['post']        = $_POST;
					$retorno['dados']       = null;
					$retorno['mensagem']    = 'Erro ao recuperar dados de origem';
					throw new Exception(json_encode($retorno), 1);
				}

				$arr_email = explode('@', $_POST['email_aprovacao']);

				if (isset($arr_email[1]) && !empty($arr_email[1])) {
					$email = trim($_POST['email_aprovacao']);
				} else {
					$email = trim($arr_email[0]) . DOMINIO_EMAIL;
				}

				if (!$config_orcamento && !$config_orcamento->aprovadores) {
					$retorno['status']                  = 'error';
					$retorno['codigo']      = 2;
					$retorno['tipo']        = 'danger';
					$retorno['post']        = $_POST;
					$retorno['dados']       = null;
					$retorno['mensagem']    = 'Erro ao carregar configuraÃ§Ãµes de controle de aprovaÃ§ao';
					throw new Exception(json_encode($retorno), 1);
				}
				if (!isset($_POST['email_aprovacao']) || empty($_POST['email_aprovacao'])) {
					$retorno['status']                  = 'required_auth';
					$retorno['codigo']      = 3;
					$retorno['tipo']        = 'danger';
					$retorno['post']        = $_POST;
					$retorno['dados']       = null;
					$retorno['mensagem']    = 'Informe um usuario com permissÃ£o para essa aÃ§Ã£o';
					throw new Exception(json_encode($retorno), 1);
				}

				if (!filter_var($email, FILTER_SANITIZE_EMAIL)) {
					$retorno['status']                  = 'error';
					$retorno['codigo']      = 2;
					$retorno['tipo']        = 'danger';
					$retorno['post']        = $_POST;
					$retorno['dados']       = null;
					$retorno['mensagem']    = 'Email invalido';
					throw new Exception(json_encode($retorno), 1);
				} else {
					$usuario = json_decode($this->user_model->getUserByEmail($email));
					$_POST['senha_aprovacao'] = md5($_POST['senha_aprovacao']);
				}

				if (!$usuario) {
					$retorno['status']                  = 'error';
					$retorno['codigo']      = 2;
					$retorno['tipo']        = 'danger';
					$retorno['post']        = $_POST;
					$retorno['dados']       = null;
					$retorno['mensagem']    = 'Usuario nÃ£o encontrado';
					throw new Exception(json_encode($retorno), 1);
				}
				if ($usuario->senha != $_POST['senha_aprovacao']) {
					$retorno['status']                  = 'error';
					$retorno['codigo']      = 2;
					$retorno['tipo']        = 'danger';
					$retorno['post']        = $_POST;
					$retorno['dados']       = null;
					$retorno['mensagem']    = 'Senha invalida';
					throw new Exception(json_encode($retorno), 1);
				}

				$param_origem['origem']   = $_POST['sel_origem'];
				$param_origem['valor']    = $_POST['valor'];
				$param_destino['destino'] = $_POST['sel_destino'];
				$param_destino['valor']   = $_POST['valor'];

				$transfer = json_decode($this->obj_orcamento->transferirSaldo($param_origem, $param_destino));

				if ($transfer->codigo == 0) {

					$dados['origem']     = $this->obj_orcamento->getSaldo($param_origem);
					$dados['destino']    = $this->obj_orcamento->getSaldo($param_destino);

					$retorno['codigo']   = $transfer->codigo;
					$retorno['status']   = $transfer->status;
					$retorno['tipo']     = $transfer->tipo;
					$retorno['post']     = $_POST;
					$retorno['dados']    = $dados;
					$retorno['mensagem'] = $transfer->mensagem;
				} else {
					$retorno['codigo']   = $transfer->codigo;
					$retorno['status']   = $transfer->status;
					$retorno['tipo']     = $transfer->tipo;
					$retorno['post']     = $_POST;
					$retorno['dados']    = $dados;
					$retorno['mensagem'] = $transfer->mensagem;
				}
			}

			foreach ($dados['origem'] as $key => $value) {
				$value->valor_total = number_format($value->valor_total, '2', ',', '.');
			}

			foreach ($dados['destino'] as $key => $value) {
				$value->valor_total = number_format($value->valor_total, '2', ',', '.');
			}

			$retorno['status']   = 'sucesso';
			$retorno['codigo']   = 0;
			$retorno['tipo']     = 'success';
			$retorno['post']     = $_POST;
			$retorno['dados']    = $dados;

			throw new Exception(json_encode($retorno), 1);
		} catch (Exception $e) {
			echo $e->getMessage();
			//throw $th;
		}
	}

	function deleteLancamento()
	{
		$id = $this->parametros[1];
		if (!empty($id) && is_numeric($id)) {
			$param['deleted'] = 1;
			$lancamentos = json_decode($this->modelo->getLancamento($id));
			$id_occ = $lancamentos[0]->id_occ;
			$id_ocg = $lancamentos[0]->id_ocg;
			$id_oco = $lancamentos[0]->id_oco;
			$id_ocs = $lancamentos[0]->id_ocs;
			$ano = $lancamentos[0]->ano;
			$this->modelo->save($param, $id);
			header('Location: /orcamento/detalhe/' . $id_occ . '/' . $id_ocg . '/' . $id_oco . '/' . $id_ocs . '/' . $ano . '/');
		}
	}
}
