<?php
    class PerfisController extends MainController{
        function __construct($parametros = null){
            $this->setModulo('perfis');
            $this->setView('perfis');
            parent::__construct($parametros);
        }
        /**
         * Carrega a página "/views/login/index.php"
        */
        public function index(){
            $this->listar();
        } // index

        function listar(){
            $records = json_decode($this->modelo->getPerfis());
            require_once ABSPATH . '/views/'.$this->nome_view.'/perfis-view.php';
        }

        function detalhe(){
            $menu = null;
            $modulos_sistema  = json_decode($this->modelo->getModulos());
            if(isset($this->parametros[1]) && is_numeric($this->parametros[1]) && $this->parametros[1] > 0){
                $records = json_decode($this->modelo->getPerfis($this->parametros[1]));
                if(isset($records[0]->permissoes)){
                    $permissoes_json = json_decode($records[0]->permissoes);
                }else{
                    $permissoes_json = null;
                }
            }else{
                $records = null;
            }

            if($modulos_sistema){
                foreach ($modulos_sistema as $key => $value) {
                    if(isset($value->grupo) && !empty($value->grupo)){
                        $i1             = $value->grupo;
                        $i2             = $value->id;
                        $i3             = $value->id_mestre;
                        if($value->tipo == 'submodulo'){
                            $menu[$i1][$i3]->submodulos[$i2] = $value;
                        }else{
                            $menu[$i1][$i2] = $value;
                        }
                    }
                }
            }
            // var_dump($menu);
            // exit;
            require_once ABSPATH . '/views/'.$this->nome_view.'/perfis-detalhe.php';
            // $this->viewPage('perfis-detalhe.php');
        }

        function save(){
            try {
                if(!isset($_POST['perfis']['nome']) || empty($_POST['perfis']['nome'])){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $_POST;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Informe um nome para esse perfil";
                    throw new Exception(json_encode($retorno), 1);   
                }

                if(!isset($_POST['modulos']) || count($_POST['modulos']) < 1){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $_POST;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "É necessario informar os modulos a serem permitidos";
                    throw new Exception(json_encode($retorno), 1);   
                }

                foreach ($_POST['perfis']['permissoes'] as $key => $value) {
                    $modulos['modulos'][$key]['permissao'] = $value;
                    $modulos['modulos'][$key]['alcada']    = $_POST['perfis']['alcadas'][$key];
                }
                
                $permissoes['nome']    = $_POST['perfis']['nome'];
                $permissoes['modulos'] = $_POST['modulos'];

                $permissoes_json = json_encode($permissoes);

                if($permissoes_json){
                    $param['nome']       = $_POST['perfis']['nome'];
                    $param['permissoes'] = $permissoes_json;
                    $param['owner']      = $this->userdata->id;
                    $param['status']     = 'a';
                    
                    $is_save = $this->modelo->save($param, $this->parametros[1]);
                    
                    if($is_save){
                        $retorno['codigo']   = 0;
                        $retorno['input']    = $_POST;
                        $retorno['output']   = $is_save;
                        $retorno['mensagem'] = "Sucesso";
                        throw new Exception(json_encode($retorno), 1); 
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $_POST;
                        $retorno['output']   = $this->modelo->info;
                        $retorno['mensagem'] = $this->modelo->info->mensagem;
                        throw new Exception(json_encode($retorno), 1); 
                    }
                }
            } catch (Exception $e) {
                echo $e->getMessage();
            }
        }
    } // class PerfisController