<?php
set_time_limit('3600');
class PipedriveController extends MainController{
	protected 
	    $module = 'pipedrive',
	    $obj_notificacao;
	function __construct($parametros){
		$this->nome_modulo = 'pipedrive';
		parent::__construct($parametros, 'pipedrive', false);
		$this->obj_api = new Api($this);
		$this->obj_api->connect('pipedrive', TOKEN_PIPEDRIVE);
		$this->obj_notificacao = new Notificacoes($this);
	}

	function pipedrive($nome_pipe){
		#global	$VAR_SYSTEM;  				
		#Chamando variaveis_sistema.php:: variáveis globais
		#chamada da URL :: pipedrive
		$interval =  null;
		$amount   = null;
		
		if($nome_pipe == 'mmr'){
			$parametros['pipeline_id'] = 10;
		}elseif($nome_pipe == 'closers'){
			$parametros['pipeline_id'] = 11;
		}

		$data_ini_pipedrive = new DateTime('2019-01-01'); 
		$parametros['data_ini'] = $data_ini_pipedrive->format('Y-m-d');
		$parametros['interval'] = 'quarter';
		$parametros['amount'] = 240;
		$parametros['field_key'] = 'add_time';  
       
		$registros  = json_decode($this->obj_api->action('pipedrive', 'pipelines', $nome_pipe, $parametros)); # Chamada da API
		$dados_bd   = json_decode($this->modelo->getPipeLineRecords($parametros['pipeline_id']));             # Chamada do banco de Dados
		
		if($registros->codigo != 0){
			echo 'Nenhum registro encontrado!';
			exit;
		}

		if($dados_bd){
		   	$update_record = false;
			if($registros->dados){
				foreach ($registros->dados as $key => $value){
					if($value->totals->count > 0){
					   	foreach ($value->deals as $k1 => $v1){
							foreach ($dados_bd as $k2 => $v2){
								if($v1->id == $v2->id_pipedrive){
									if($v1->status != $v2->pipedrive_status){
										$update_record = true;
									}

									if($v1->stage_id != $v2->stage_id){
										$update_record = true;
									}

									if($v1->active != $v2->active){
										$update_record = true;
									}

									if($v1->deleted != $v2->deleted){
										$update_record = true;
									}

									if($v1->update_time != $v2->update_time){
										$update_record = true;
									}

									if($update_record){
									    $save_pipedrive = $this->saveDados($v1, $v2->id);
							           	if($v1->stage_id != $v2->stage_id){
											$reLpipe['id_pipeline']      = $parametros['pipeline_id'];
											$reLpipe['id_pipedrive']     = $v1->id;
											$reLpipe['data_atualizacao'] = $v1->update_time;
											$reLpipe['estagio_anterior'] = $v2->stage_id;  //$VAR_SYSTEM['STAGE_PIPEDRIVE'][69]
											$reLpipe['estagio_atual']    = $v1->stage_id;
											$this->modelo->setTable("rel_pipedrive");
											$is_save_rel = $this->modelo->save($reLpipe);

											if($v1->stage_id == 68 ){
												$param = null;
												$param['msg'] = "CLIENTE PEDIU PROPOSTA Pipeline: ".$nome_pipe." Pipeline: ".$v1->owner_name." Cliente: ".$v1->org_name." pediu uma proposta no pipedrive na oportunidade ".$v1->title." por: ".$v1->owner_name." \n \n";
												$this->alertas($param);
											}
										}
										$this->modelo->setTable("pipedrive");
									}
									$registros->dados[$key]->totals->count = 0;
									unset($registros->dados[$key]->deals[$k1]);
								}
							}
						}
					}
				}
			}

			if($registros->dados){
				foreach ($registros->dados as $key => $value) {
					if(count($value->deals) > 0){
						foreach ($value->deals as $k1 => $v1) {
							$this->modelo->setTable("pipedrive");
							$this->saveDados($v1);
							$reLpipe['id_pipeline']      = $parametros['pipeline_id'];
							$reLpipe['id_pipedrive']     = $v1->id;
							$reLpipe['data_atualizacao'] = $v1->update_time;
							$reLpipe['estagio_anterior'] = $v2->stage_id;  //$VAR_SYSTEM['STAGE_PIPEDRIVE'][69]
							$reLpipe['estagio_atual']    = $v1->stage_id;
							$this->modelo->setTable("rel_pipedrive");
							$is_save_rel = $this->modelo->save($reLpipe);
						}
					}
				}
			}

		}else{
			if($registros->dados){
				foreach ($registros->dados as $key => $value) {
					if($value->totals->count > 0){
						foreach ($value->deals as $k1 => $v1) {
							$this->modelo->setTable("pipedrive");
							$this->saveDados($v1);
							$reLpipe['id_pipeline']      = $parametros['pipeline_id'];
							$reLpipe['id_pipedrive']     = $v1->id;
							$reLpipe['data_atualizacao'] = $v1->update_time;
							$reLpipe['estagio_anterior'] = $v1->stage_id;  //$VAR_SYSTEM['STAGE_PIPEDRIVE'][69]
							$reLpipe['estagio_atual']    = $v1->stage_id;
							$this->modelo->setTable("rel_pipedrive");
							$is_save_rel = $this->modelo->save($reLpipe);
						}
					}
				}
			}
		}
	}

	function exec(){
		$this->pipedrive('mmr');
		$this->pipedrive('closers');
		$this->AlertaMovidasouApagadas('closers');
	}

	//testar função
	function dealLost(){
		$registros  = json_decode($this->obj_api->action('pipedrive', 'deals', 'lost', null)); # Chamada da API
		if($registros->dados){
			foreach ($registros->dados as $key => $value) {
				if($value->pipeline_id == 10 || $value->pipeline_id == 11){
					$registro_bd = $this->modelo->getPipedrive($value->id);
					if($registro_bd){
						$this->saveDados($value, $registro_bd[0]->id);
					}
				}
			}
		}
	}

	function graficos(){
		global $VAR_SYSTEM;
		if(isset($_GET['nome_grafico']) && !empty($_GET['nome_grafico'])){
			$nome_grafico = $_GET['nome_grafico'];
		}else{
			$nome_grafico = 'soma_opo_estagio_venda_closers';
		}
		
		$this->obj_api = new Api($this);
		$this->obj_api->connect('pipedrive', TOKEN_PIPEDRIVE);
		
		$data_ini_pipedrive = new DateTime('2019-01-01'); 
		
		$parametros['data_ini'] = $data_ini_pipedrive->format('Y-m-d');
		$parametros['interval'] = 'quarter';
		$parametros['amount'] = 240;
		$parametros['field_key'] = 'add_time';  
		// $records  = json_decode($this->modelo->getPipeLineRecords(11, 'open'));
		
		switch ($nome_grafico) {
			case 'soma_opo_estagio_venda_closers':
			case 'qtde_opo_estagio_venda_closers':
				$parametros['pipeline_id'] = 11;
				$dados_pipedrive  = json_decode($this->obj_api->action('pipedrive', 'pipelines', 'closers', $parametros)); # Chamada da API
			break;
			default:
				$parametros['pipeline_id'] = 10;
				$dados_pipedrive  = json_decode($this->obj_api->action('pipedrive', 'pipelines', 'mmr', $parametros)); # Chamada da API
			break;
		}
		
		if($dados_pipedrive->codigo == 0){
			foreach ($dados_pipedrive->dados as $key => $value) {
				if($value->totals > 0){
					foreach ($value->deals as $k1 => $v1) {
						if($v1->status == 'open'){
							$records[] = $v1;
						}
					}
				}
			}
		}

		if($nome_grafico == 'soma_opo_estagio_venda_closers'){
			$titulo_grafico = 'Oportunidades - CLOSERS - R$';
			// trazer registros do pipedrive
			// criar um array com id do owner como chave e nome no valor 
			// usar o id do owner no index do combobox de usuarios
			// filtrar oportunidades por comercial
			if($records){
				foreach ($records as $key => $value){
					$i = $value->stage_id;
					$grafico[$i] += $value->value;
				}
				if($grafico){
					$dados_grafico = null;
					ksort($grafico, false);
					foreach ($grafico as $k1 => $v1) {
						$v1 = number_format($v1, 0, ',', '');
						$dados_grafico .= "{ y: ".$v1.", label: '".$VAR_SYSTEM['STAGE_PIPEDRIVE'][$k1]."'},";
					}
				}
			}
		}elseif($nome_grafico == 'qtde_opo_estagio_venda_closers'){
			$titulo_grafico = 'Oportunidades - CLOSERS - #';
			if($records){
				foreach ($records as $key => $value){
					$i = $value->stage_id;
					$grafico[$i] += 1;
 				}
				if($grafico){
					$dados_grafico = null;
					ksort($grafico, false);
					foreach ($grafico as $k1 => $v1) {
						$dados_grafico .= "{ y: $v1, label: '".$VAR_SYSTEM['STAGE_PIPEDRIVE'][$k1]."'},";
					}
				}
			}
		}elseif($nome_grafico == 'soma_opo_estagio_venda_comercial_mmr'){
			
			$titulo_grafico = 'Oportunidades - MMR/SDR - R$';
			
			if(isset($_GET['id_comercial']) && !empty($_GET['id_comercial'])){
				$id_comercial = $_GET['id_comercial'];
			}else{
				$id_comercial = null;
			}
			
			$comerciais =  null;
			
			foreach ($records as $key => $value){
				$i = $value->user_id;
				$comerciais[$i] = $value->owner_name;
			}

			if($records){
				foreach ($records as $key => $value){
					$i = $value->stage_id;
					if($id_comercial && $value->user_id == $id_comercial){
						$grafico[$i] += $value->value;
					}elseif(!$id_comercial){
						$grafico[$i] += $value->value;
					}
				}
				
				if($grafico){
					$dados_grafico = null;
					ksort($grafico, false);
					foreach ($grafico as $k1 => $v1) {
						if($v1 > 0){
							$dados_grafico .= "{ y: $v1, label: '".utf8_encode($VAR_SYSTEM['STAGE_PIPEDRIVE'][$k1])."'},";
						}
					}
				}
			}

		}elseif($nome_grafico == 'qtde_opo_estagio_venda_comercial_mmr'){
			$titulo_grafico = 'Oportunidades - MMR/SDR - #';
			if(isset($_GET['id_comercial']) && !empty($_GET['id_comercial'])){
				$id_comercial = $_GET['id_comercial'];
			}else{
				$id_comercial = null;
			}
			$comerciais =  null;
			foreach ($records as $key => $value){
				$i = $value->user_id;
				$comerciais[$i] = $value->owner_name;
			}

			if($records){
				foreach ($records as $key => $value){
					$i = $value->stage_id;
					if($id_comercial && $value->user_id == $id_comercial){
						$grafico[$i] += 1;
					}elseif(!$id_comercial){
						$grafico[$i] += 1;
					}
				}
				if($grafico){
					$dados_grafico = null;
					ksort($grafico, false);
					foreach ($grafico as $k1 => $v1) {
						if($v1 > 0){
							$dados_grafico .= "{ y: $v1, label: '".utf8_encode($VAR_SYSTEM['STAGE_PIPEDRIVE'][$k1])."'},";
						}
					}
				}
			}
		}
		if($_GET['view'] == 'table'){
			require_once ABSPATH . '/views/'.$this->module.'/table-view.php';
		}else{
			require_once ABSPATH . '/views/'.$this->module.'/grafico-view.php';
		}
	}

	function execGrafico($nome){
		switch ($nome) {
			case 'perdidas':
				$url = URL_SISTEMA.'/pipedrive/graficos/nome/perdidas';	
			break;
			default:
				$url = URL_SISTEMA.'/pipedrive/graficos/nome/oportunidades';
			break;
		}
		$param['msg'] = " Veja os graficos da performance comercial atualizado em $url \n ";
		$this->alertas($param);
	}

	function getImage(){
		$image     = $_POST['imagem'];
		$imageInfo = explode(";base64,", $image);
		$imgExt    = str_replace('data:image/', '', $imageInfo[0]);      
		$image     = str_replace(' ', '+', $imageInfo[1]);
		$imageName = "post-".time().".".$imgExt;
		file_put_contents($imageName, base64_decode($image));
	}
	
	function alertas($param){
		if('producao' == TIPO_AMBIENTE){
			$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/06b48f3c-0684-46b4-ad04-63494a706bc7@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/55c37effbda7418f9bd248032ff3a0ca/c8c7ff53-e294-4a3a-bcad-c9f04857e469';
		}else{
			$parametros['webhook'] = 'https://cmsw1.webhook.office.com/webhookb2/6481764e-f982-42db-b9b4-04235da91ec8@07c74f1b-9c61-4995-807a-c7942b88271b/IncomingWebhook/9f2e2cc655bf4e76bfdb0531dd3a83d7/c328c206-070a-4beb-bbed-da82e018abec';
		}
        $parametros['tipo_destinatario'] = 'webhook';
		$parametros['mensagem']          = $param['msg'];
        $send = $this->obj_notificacao->enviar('teams', $parametros);
	}

	//pipedrive-detalhe-view.php
	function saveDados($dados, $id = null){

		$nome_pipe = $dados->pipeline_id == 10 ? "MMR" : "CLOSERS";
		$parametros['id_pipedrive'] = $dados->id;
		$parametros['pipeline_id'] = $dados->pipeline_id;
		$parametros['person_name'] = $dados->person_name;
		$parametros['name_organiz'] = $dados->org_name;
		$parametros['prop_owner_name'] = $dados->owner_name;
		$parametros['title'] = $dados->title;
		$parametros['cc_email'] = $dados->cc_email;
		$parametros['valor'] = $dados->value;
		$parametros['currency'] = $dados->currency;
		$parametros['next_activity_subject'] = $dados->next_activity_subject;
		$parametros['next_activity_note'] = $dados->next_activity_note;
		$parametros['active'] = $dados->active;
		$parametros['add_time'] = $dados->add_time;
		$parametros['stage_change_time'] = $dados->stage_change_time;
		$parametros['stage_id'] = $dados->stage_id;
		$parametros['update_time'] = $dados->update_time;
		$parametros['pipedrive_status'] = $dados->status;
		$parametros['active'] = $dados->active;
		$parametros['deleted'] = $dados->deleted;
		$parametros['lost_reason'] = $dados->lost_reason;
		$parametros['lost_time'] = $dados->lost_time;
		$parametros['won_time'] = $dados->won_time;
		$parametros['first_won_time'] = $dados->first_won_time;
		$parametros['close_time'] = $dados->close_time;
		$parametros['next_activity_date'] = $dados->next_activity_date;
		// $parametros['formatted_dados'] = $dados->formatted_dados;
		$parametros['next_activity_type'] = $dados->next_activity_type;
		$is_save = $this->modelo->save($parametros, $id);
		if($is_save && !$id){
			$param['msg'] = " OPORTUNIDADE CRIADA Pipeline: $nome_pipe  Cliente: $dados->org_name oportunidade: $dados->title responsavel: $dados->owner_name \n \n ";
			$this->alertas($param);
		}
		return $is_save;
	}

	function AlertaPorPeriodo($dias){
		$param['msg'] = null;
		$dias = 45;
		switch ($dias) {
			case 30:
				$limite = 45;
			break;
			case 45:
				$limite = 60;
			break;
			default:
				$limite = 10000;
			break;
		}

		$this->obj_api = new Api($this);
		$this->obj_api->connect('pipedrive', TOKEN_PIPEDRIVE);
		
		$registros = json_decode($this->modelo->getOppsByStage(69)); //2020-11-12
		
		foreach ($registros as $key => $value){
			$data_atualizacao = new DateTime($value->stage_change_time);
			$diff_update = $data_atualizacao->diff($this->data_hora_atual);
			if($diff_update->days >= $dias && $diff_update->days < $limite ){
				if($value->pipeline_id == 11){
					$param['msg'] .= " Pipeline $value->id: CLOSERS Oportunidade $value->title com $dias dias: $value->name_organiz Comercial Responsavel: $value->prop_owner_name \n \n";
				}
			}
		}

		if($param['msg']){
			$this->alertas($param);
		}
	}

	//Proposta Movida ou Deletada
	function AlertaMovidasouApagadas($nome_pipe){		
		#global	$VAR_SYSTEM;  				
		#Chamando variaveis_sistema.php:: variáveis globais
		$this->obj_api = new Api($this);
		$this->obj_api->connect('pipedrive', TOKEN_PIPEDRIVE);
		#chamada da URL :: pipedrive
		$interval =  null;
		$amount = null;
		if($nome_pipe == 'mmr'){
			$parametros['pipeline_id'] = 10;
		}elseif($nome_pipe == 'closers'){
			$parametros['pipeline_id'] = 11;
		}
		
		$data_ini_pipedrive      = new DateTime('2019-01-01'); 
		$parametros['data_ini']  = $data_ini_pipedrive->format('Y-m-d');
		$parametros['interval']  = 'quarter';
		$parametros['amount']    = 240;
		$parametros['field_key'] = 'add_time';  //vendo com Julio

		$dados_pipedrive = json_decode($this->obj_api->action('pipedrive', 'pipelines', $nome_pipe, $parametros)); # Chamada da API
		$dados_bd        = json_decode($this->modelo->getPipeLineRecords($parametros['pipeline_id']));
		
		if($dados_bd){
			foreach ($dados_bd as $key => $value) {
				if($dados_pipedrive){
					foreach ($dados_pipedrive->dados as $k1 => $v1) {
						if($v1->totals->count > 0){
                            foreach ($v1->deals as $k2 => $v2) {
								if($value->id_pipedrive == $v2->id){
									unset($dados_bd[$key]);
								}
							}
						}
					}
				}
			}
		}

		if($dados_bd){
			$param['msg'] = null;
			foreach ($dados_bd as $key => $value) {
				$nome_pipe = $value->pipeline_id == 10 ? "MMR" : "CLOSERS";  # If ternário
				$param['msg'] .= " ID: $value->id Oportunidade excluida ou movida Pipeline: $nome_pipe Oportunidade: $value->title cliente: $value->name_organiz Responsavel: $value->prop_owner_name \n \n";
				$deleted['deleted'] = 1;
				$is_save = $this->modelo->save($deleted, $value->id);
			}
			$this->alertas($param);
		} 
	}

	//Todas Proposta Valor for Zero
	function AlertaValorIgualZero($nome_pipe){
		#global	$VAR_SYSTEM;  				
		#Chamando variaveis_sistema.php:: variáveis globais
		$this->obj_api = new Api($this);
		$this->obj_api->connect('pipedrive', TOKEN_PIPEDRIVE);
		#chamada da URL :: pipedrive
		$interval =  null;
		$amount = null;
		if($nome_pipe == 'mmr'){
			$parametros['pipeline_id'] = 10;
		}elseif($nome_pipe == 'closers'){
			$parametros['pipeline_id'] = 11;
		}
		
		$data_ini_pipedrive      = new DateTime('2019-01-01'); 
		$parametros['data_ini']  = $data_ini_pipedrive->format('Y-m-d');
		$parametros['interval']  = 'quarter';
		$parametros['amount']    = 240;
		$parametros['field_key'] = 'add_time';  //vendo com Julio
		
		$dados_pipedrive = json_decode($this->obj_api->action('pipedrive', 'pipelines', $nome_pipe, $parametros)); # Chamada da API

		if($dados_pipedrive){
			foreach ($dados_pipedrive->dados as $k1 => $v1){
				if($v1->totals->count > 0){
					$param['msg'] = null;
					foreach ($v1->deals as $k2 => $v2) {
						if(empty($v2->value)){ #Comparação de Valor
							if($v2->status == 'open'){
								$nome_pipe = $v2->pipeline_id == 10 ? "MMR" : "CLOSERS";  # If ternário
								$param['msg'] .= " Oportunidade com valor 0 Pipeline: $nome_pipe Oportunidade: $v2->title cliente: $v2->org_name Responsavel: $v2->owner_name"." \n \n ";
							}
						}
					}
				}
			}
		}
	}

	// Soma todas as propostas
	function SomaTodosValores($nome_pipe){		
		global $VAR_SYSTEM;
		$this->obj_api = new Api($this);
		$this->obj_api->connect('pipedrive', TOKEN_PIPEDRIVE);
		#Parametros
		#chamada da URL :: pipedrive MMR e Closers
		$interval =  null;
		$amount = null;
		
		if($nome_pipe == 'mmr'){
			$parametros['pipeline_id'] = 10;
		}elseif($nome_pipe == 'closers'){
			$parametros['pipeline_id'] = 11;
		}
		
		$data_ini_pipedrive = new DateTime('2019-01-01'); 
		$parametros['data_ini']  = $data_ini_pipedrive->format('Y-m-d');
		$parametros['interval']  = 'quarter';
		$parametros['amount']    = 240;
		$parametros['field_key'] = 'add_time'; 
		#Parametros
		#chamada da URL :: dos  produtos
		$dados_pipedrive = json_decode($this->obj_api->action('pipedrive', 'pipelines', $nome_pipe, $parametros)); # Chamada da API
		if($dados_pipedrive->codigo == 0){
			$total_soma = null;
			$param_soma = null;
			$param  = null;
			$param2 = null;
			foreach ($dados_pipedrive->dados as $k1 => $v1){
				if($v1->totals->count > 0){ 
					foreach ($v1->deals as $k2 => $deals){
						if($deals->products_count > 0){
							if($deals->status == 'open'){
								$acao = 'produto';
								$parametros['products'] = 0;
								$parametros['deal_id']  = $deals->id;  ///$deals->id
								$dados_produtos = json_decode($this->obj_api->action('pipedrive', 'pipelines', $acao, $parametros)); # Chamada da API
								if($dados_produtos->codigo == 0){
									if(count($dados_produtos->dados) > 0){
										foreach ($dados_produtos->dados as $k3 => $v3) {
											$i = $v3->product_id;
											$param_soma[$i]['produto'] = $VAR_SYSTEM['PRODUTO'][$i];
											$param_soma[$i]['qtd']     += 1;
											$param_soma[$i]['soma']    += $v3->sum;
											$param_soma[$i]['deals'][] = $deals;
										}
									}
								}
							}
						}else{
							$param2['msg'] .= " Oportunidade sem produto associado Pipeline: ".strtoupper($nome_pipe)." Oportunidade: $deals->title cliente: $deals->org_name Responsavel: $deals->owner_name"." \n \n ";
						}
					}
				}
			}
			if($param_soma){
				foreach($param_soma as $key => $value){
					if(empty($value['qtd'])){
						$value['qtd'] = 1;
					}
					if(count($value['deals']) > 0){
						foreach( $value['deals'] as $k1 => $v1){
							$media    = null;
							$procento = null; 
							$media    = (($value['soma'] - $v1->value) / ($value['qtd'] - 1));
							$media_dz = ($media / 12);
							$porcento = (($media_dz / 100) * 20);
							$nivel    = ( $media_dz - $porcento );
							$mes_corrente = $this->data_hora_atual->format('m');
							$fator = (12 - $mes_corrente);
							$nivel = ($nivel * $fator);
							if($v1->value < $nivel){
								$param['msg'] .= " Oportunidade com valor abaixo da media valor esperado: ".number_format($nivel, '2', ',', '.')." valor da proposta: ".number_format($v1->value, '2', ',', '.')." Pipeline: ".strtoupper($nome_pipe)." Oportunidade: $v1->title cliente: $v1->org_name Responsavel: $v1->owner_name"." \n \n ";
							}
						}

					}
				}
			}
			$this->alertas($param);
			$this->alertas($param2);
		}
	}

	function execValorZero(){
		// rodar apenas no pipedrive closers
		$this->AlertaValorIgualZero('closers');
	}

	function AcadaDuasHoras(){
		$this->SomaTodosValores('closers');
	}

	function Estagnados(){
		global $VAR_SYSTEM;
		$this->obj_api = new Api($this);
		$this->obj_api->connect('pipedrive', TOKEN_PIPEDRIVE);
		$parametros['data_ini'] = '2019-01-01';
		$parametros['interval'] = 'quarter';
		$parametros['amount'] = 240;
		$parametros['field_key'] = 'add_time';

		if(isset($this->parametros[0]) && $this->parametros[0] == 'mmr'){
			$parametros['pipeline_id'] = 10;
			$pipeline        = 'mmr';
		}else{
			$parametros['pipeline_id'] = 11;
			$pipeline        = 'closers';
		}

		// $registros  = json_decode($this->obj_api->action('pipedrive', 'deals', 'estagnados')); # Chamada da API
		
		$dados_pipedrive  = json_decode($this->obj_api->action('pipedrive', 'pipelines', $pipeline, $parametros)); # Chamada da API
		$param['msg'] = null;
		if($dados_pipedrive->codigo == 0){
			foreach ($dados_pipedrive->dados as $k1 => $v1) {
				foreach ($v1->deals as $k2 => $v2) {
					$si = $v2->stage_id;
					$stage_update_limit = $VAR_SYSTEM['ESTAGNADOS'][$si]['STATUS_TIME'];
					$next_activity_limit = $VAR_SYSTEM['ESTAGNADOS'][$si]['NEXT_ACTION']; 
					if(
						$v2->active &&
						!$v2->deleted &&
						$v2->status == 'open'
					){
						$stage_update = new DateTime($v2->stage_change_time);
						$diff_stage = getDiasUteis($stage_update->format('Y-m-d'), $this->data_hora_atual->format('Y-m-d')); //$stage_update->diff($this->data_hora_atual);
						
						if($v2->next_activity_date){
							$next_activiy = new DateTime($v2->next_activity_date);
							// $diff_actiity = $next_activiy->diff($this->data_hora_atual);
							$diff_actiity = getDiasUteis($this->data_hora_atual->format('Y-m-d'), $next_activiy->format('Y-m-d'));
						}else{
							$next_activiy = null;
						}
						
						if($diff_stage >= $stage_update_limit && (!$next_activiy || $diff_actiity >= $next_activity_limit )){
							$param['msg'] .= "A oportunidade: $v2->title no funil ".strtoupper($pipeline)." que esta sob a responsabilidade de ".$v2->owner_name." esta sem a performance esperada para a oportunidade \n \n";
						}
					}
				}
			}
			
			if($param['msg']){
				$this->alertas($param);
			}
			
			}else{
				$retorno['codigo']   = 1;
				$retorno['tipo']     = 'error';
				$retorno['input']    = $parametros;
				$retorno['output']   = $dados_pipedrive;
				$retorno['mensagem'] = $dados_pipedrive;
			}
		
		// if($registros->codigo == 0){
		// 	$opp          = null;
		// 	$param['msg'] = null;
		// 	foreach ($registros->dados as $key => $value) {
		// 		switch ($value->pipeline_id){
		// 			case 10:
		// 			case 11:
		// 				$opp[] = $value;
		// 				if($value->pipeline_id == 10){
		// 					$pipeline = 'MRR/SDR';
		// 				}else{
		// 					$pipeline = 'CLOSERS';
		// 				}
		// 				//A oportunidade XXXXX no funil xxxxx que esta sob a responsabilidade de XXXX esta sem a atuação esperada para a oportunidade
		// 				$param['msg'] .= " A oportunidade: $value->title no funil $pipeline que esta sob a responsabilidade de ".$opp[0]->user_id->name." esta sem a atuação esperada para a oportunidade \n \n";
		// 			break;
		// 		}
		// 	}
		// 	if($param['msg']){
		// 		$this->alertas($param);
		// 	}
		// }
	}

	function ExecAlerta(){//chamando Browser 
		$this->execGrafico('oportunidades');
		$this->AlertaPorPeriodo(30);
		$this->AlertaPorPeriodo(45);
		$this->AlertaPorPeriodo(60);
	}
}
?>