<?php
	set_time_limit(0);
	class PontoController extends MainController{
		protected
			$marcacao,
			$obj_assinatura,
			$class_upload,
			$dados_permissao,
			$obj_ponto,
			$obj_email;
		public
			$cl_permissoes,
			$obj_notificacao,
			$nome_plataforma = 'd4sign';
		function __construct($parametros = null, $nome_modulo = 'ponto', $do_login = true){
			$this->setModulo('ponto');
			$this->setView('ponto');
			parent::__construct($parametros, $nome_modulo, $do_login);
			$data_hora_atual = clone $this->data_hora_atual;
			$this->obj_email = new Email();
			$this->obj_assinatura = new D4Sign($this);
			$this->obj_assinatura->setIntegracao('D4S001');
			$this->obj_notificacao = new Notificacoes($this);
		}

		function index(){
			$obj_hoje = clone $this->data_hora_atual;
			// para apagar
			// $obj_hoje = getDataAtual('2025-08-27');
			// $obj_hoje->setTime(16, 00);
			$dia_hoje = $obj_hoje->format('Y-m-d');
			$dia_semana = $obj_hoje->format('w');
			$dt_ini = clone $obj_hoje;
			$dt_fim = clone $obj_hoje;
			$dt_ini->setTime(00, 00, 00);
			$dt_fim->setTime(23, 59, 59);
			$this->obj_ponto = new RhPonto($this, $_SESSION['cmswerp']['userdata']->id);
			$this->obj_ponto->gerarEspelho($dt_ini, $dt_fim);
			$last_marcacao = $this->obj_ponto->getUltimaMarcacao($_SESSION['cmswerp']['userdata']->id);
			if($last_marcacao){
				$diff_marcacao = calculaPeriodoEmMinutos($this->data_hora_atual, $last_marcacao->obj_date);
				if($diff_marcacao >= 600){
					$nova_jornada = true;
				}else{
					$nova_jornada = false;
				}
			}else{
				$nova_jornada = true;
			}

			// $total_pausa = '00:00';
			if (isset($this->obj_ponto->user->marcar_ponto) && $this->obj_ponto->user->marcar_ponto == 1) {
				$obj_marcacao = new Custom();
				$obj_marcacao->dias_jornada = $this->obj_ponto->dias_jornada;
				$obj_marcacao->totais = $this->obj_ponto->calendario['total'];

				if (isset($this->obj_ponto->calendario['diario'][$dia_hoje]['marcacoes'][0])) {
					$dados = $this->obj_ponto->calendario['diario'][$dia_hoje]['marcacoes'][0];
					$horas_previstas = $this->obj_ponto->calendario['diario'][$dia_hoje]['horas_previstas'];
					$horas_trabalhadas = $this->obj_ponto->calendario['diario'][$dia_hoje]['horas_trabalhadas'][0];
					$pausas = $this->obj_ponto->calendario['diario'][$dia_hoje]['minutos_pausa'];
					$arr_pausas = $this->obj_ponto->calendario['diario'][$dia_hoje]['arr_pausas'];
					$saldo = $this->obj_ponto->calendario['diario'][$dia_hoje]['saldo'][0];
					$total = $this->obj_ponto->calendario['total'];
				} else {
					$dados = null;
					$horas_trabalhadas = 0;
					$horas_previstas = $this->obj_ponto->calendario['diario'][$dia_hoje]['horas_previstas'];
					$saldo = $this->obj_ponto->calendario['diario'][$dia_hoje]['saldo'][0];
					$total = $this->obj_ponto->calendario['total'];
				}

				if ($total['saldo'] > 480) {
					$dias_jornada = count($obj_marcacao->dias_jornada);
					$jornada_dia = null;
					$entrada_minima = null;
					$proxima_entrada = null;
					$amanha = clone $obj_hoje;
					$amanha->modify('+1 day');
					$ds_amanha = $amanha->format('w');
					if ($dias_jornada > 0) {
						$compensa_semana = 0;
						foreach ($obj_marcacao->dias_jornada as $key => $value) {
							$compensa_semana += $value['dados']['extra_maximo'];
						}

						if ($compensa_semana <= $total['saldo']) {
							$horas_compensacao = ($compensa_semana / $dias_jornada);
						} else {


							$horas_compensacao = ($total['saldo'] / $dias_jornada);
						}

						if ($horas_compensacao) {
						} else {
						}

						for ($i = 0; $i < 7; $i++) {
							$amanha->modify('+1 day');
							$ds_amanha = $amanha->format('w');
							if (isset($obj_marcacao->dias_jornada[$ds_amanha])) {
								$jornada_dia = $obj_marcacao->dias_jornada[$ds_amanha];
								$entrada_jornada = explode(':', $jornada_dia['dados']['entrada']);
								$entrada_minima = $horas_compensacao;
								$proxima_entrada = clone $amanha;
								$proxima_entrada->setTime($entrada_jornada[0], $entrada_jornada[1]);
								$proxima_entrada->modify("+$entrada_minima minutes");
								break;
							}
						}

						if ($obj_hoje->format('w') == 5) { // verificar se é sexta-feira
							$alerta['saldo'] = $total['saldo'];
							$alerta['horas_compensacao'] = $horas_compensacao;
							$alerta['dias_semana'] = $dias_jornada;
							$alerta['mensagem'] = 'Seu saldo está em ' . convertHorasMinutos($alerta['saldo'], 'decimal>horas', true) . ' horas, você deve começar a compensar na proxima semana';
							$alerta['sugestao'] = 'Sugestao de compensação ' . convertHorasMinutos($horas_compensacao, 'decimal>horas', true) . ' horas por dia';
							$alerta['aviso'] = 'A partir ' . $amanha->format('d/m/Y') . ' voce deve marcar a entrada a partir de ' . $proxima_entrada->format('H:i') . ' horas';
						}
					}
				}

				if (isset($obj_marcacao->dias_jornada) && !empty($obj_marcacao->dias_jornada)) {
					if (isset($this->obj_ponto->calendario['diario'][$dia_hoje]['jornada']['ini_prev'])) {
						$inicio = $this->obj_ponto->calendario['diario'][$dia_hoje]['jornada']['ini_prev'];
						$final = $this->obj_ponto->calendario['diario'][$dia_hoje]['jornada']['fim_prev'];
						foreach ($obj_marcacao->dias_jornada as $key => $value) {
							$entrada_min = clone $inicio;
							$entrada_min->modify("- " . $value['dados']['entrada_min'] . " minutes");
							$entrada_max = clone $inicio;
							$entrada_max->modify("+ " . $value['dados']['entrada_max'] . " minutes");
							$saida_min = clone $final;
							$saida_min->modify("- " . $value['dados']['saida_min'] . " minutes");
							$saida_max = clone $final;
							$saida_max->modify("+ " . $value['dados']['saida_max'] . " minutes");
						}
					}
				} else {
					$entrada_min = null;
					$entrada_max = null;
					$saida_min = null;
					$saida_max = null;
				}
			}

			if (isset($obj_marcacao->dias_jornada[$dia_semana]['dados'])) {
				$minutos_almoco = $obj_marcacao->dias_jornada[$dia_semana]['dados']['tempo_almoco_min'];
			} else {
				$minutos_almoco = 60;
			}

			$marcacoes_hoje = end($this->obj_ponto->calendario['diario'][$dia_hoje]['marcacoes']);
			$modal_almoco = false;
			if (
				isset($marcacoes_hoje[1]->hora_marcacao) && !empty($marcacoes_hoje[1]->hora_marcacao)
			) {
				$data_almoco = $marcacoes_hoje[1]->data_marcacao;
				$hora_almoço = $marcacoes_hoje[1]->hora_marcacao;
				$status_almoco = $marcacoes_hoje[1]->status;
				if (!isset($marcacoes_hoje[2]->hora_marcacao) || empty($marcacoes_hoje[2]->hora_marcacao)) {
					$modal_almoco = true;
					$saida_almoço = getDateTime($marcacoes_hoje[1]->data_marcacao . ' ' . $marcacoes_hoje[1]->hora_marcacao);
					$retorno_almoco = clone $saida_almoço;
					if ($minutos_almoco > 0) {
						$retorno_almoco->add(new DateInterval('PT' . $minutos_almoco . 'M'));
					}
				}
			} else {
				$data_almoco = null;
				$hora_almoço = null;
				$status_almoco = null;
			}
			require_once ABSPATH . '/views/' . $this->nome_view . '/ponto-view.php';
		}

		function espelhoView(){
			$this->obj_ponto = new RhPonto($this, $_SESSION['cmswerp']['userdata']->id);
			$this->gerarEspelho();
		}

		function gerarEspelho(){
			include 'config_extras.php';
			try {
				$hoje = getDataAtual();
				$session = json_decode($_SESSION['cmswerp']['userdata']->permissoes);
				$permissoes = json_decode($this->cl_permissoes->checkPermissoes('gerarEspelho', 'metodo'));
				if (!$permissoes){
					$retorno['codigo'] = 1;
					$retorno['input'] = 'espelhoView';
					$retorno['output'] = $permissoes;
					$retorno['mensagem'] = "Permissoes não encontradas para esta ação!";
					throw new Exception(json_encode($retorno), 1);
				} elseif ($permissoes->codigo != 0) {
					$retorno['codigo'] = 1;
					$retorno['input'] = 'espelhoView';
					$retorno['output'] = $permissoes;
					$retorno['mensagem'] = $permissoes->mensagem;
					throw new Exception(json_encode($retorno), 1);
				} elseif (isset($permissoes->output->permissoes) && $permissoes->output->permissoes < 1) {
					$retorno['codigo'] = 1;
					$retorno['input'] = 'espelhoView';
					$retorno['output'] = $permissoes;
					$retorno['mensagem'] = 'Você não tem acesso a este recurso!';
					throw new Exception(json_encode($retorno), 1);
				}

				// definindo permissoes do listview
				if ($permissoes->output == "master") {
					$lista_usuarios = json_decode($this->modelo->getUsuarios());
				} else {
					switch ($permissoes->output->alcadas) {
						case '2':
							$lista_usuarios = json_decode($this->modelo->getUsuarios(null, $_SESSION['cmswerp']['userdata']->id));
							$alcada = $permissoes->output->alcadas;
							break;
						case '4':
							$lista_usuarios = json_decode($this->modelo->getUsuarios());
							$alcada = $permissoes->output->alcadas;
							break;
						default:
							$lista_usuarios = json_decode($this->modelo->getUsuarios($_SESSION['cmswerp']['userdata']->id));
							$alcada = $permissoes->output->alcadas;
							break;
					}
				}

				// Id utilizado na pesquisa, caso não informado o id padrão é o do proprio usuario logado.
				if (isset($_POST['id_funcionario']) && !empty($_POST['id_funcionario'])) {
					$id_usuario = $_POST['id_funcionario'];
				} else {
					if (isset($this->parametros[0]) && !empty($this->parametros[0])) {
						$id_usuario = $this->parametros[0];
					} else {
						$id_usuario = $_SESSION['cmswerp']['userdata']->id;
					}
				}

				if (isset($_POST['data_de']) && !empty($_POST['data_de'])) {
					if (!validaData($_POST['data_de'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Data invalida";
						throw new Exception(json_encode($retorno), 1);
					}
					$dt_ini = getDataAtual($_POST['data_de']);
				} else {
					$dt_ini = getDataAtual();
					$dt_ini->modify('first day of this month');
				}

				if (isset($_POST['data_ate']) && !empty($_POST['data_ate'])) {
					if (!validaData($_POST['data_ate'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Data invalida";
						throw new Exception(json_encode($retorno), 1);
					}
					$dt_fim = getDataAtual($_POST['data_ate']);
				} else {
					$dt_fim = getDataAtual();
					$dt_fim->modify('-1 day');
				}

				// Id utilizado na pesquisa, caso não informado o id padrão é o do proprio usuario logado.
				if (isset($_POST['id_funcionario']) && !empty($_POST['id_funcionario']) && is_numeric($_POST['id_funcionario'])) {
					$userId = $_POST['id_funcionario'];
				} else {
					$userId = $_SESSION['cmswerp']['userdata']->id;
				}

				if (isset($_POST['tipo_consulta']) && !empty($_POST['tipo_consulta'])) {
					$tipo_espelho = $_POST['tipo_consulta'];
				} else {
					$tipo_espelho = 'espelho';
				}

				$this->obj_ponto = new RhPonto($this, $userId); //jornada noturna
				$this->obj_ponto->gerarEspelho($dt_ini, $dt_fim, $tipo_espelho);
				// $pausas = $this->obj_ponto->calendario['diario'][$dia_hoje]['horas_pausas'][0];
				$user = $this->obj_ponto->user;
				$dados = $this->obj_ponto->calendario['diario'];
				$pausas = $this->obj_ponto->matriz_calendario['diario']['pausa'];
				$extras = $this->obj_ponto->matriz_calendario['diario']['extra'];
				$pontos = $this->obj_ponto->matriz_calendario['diario']['marcacoes'];
				$totais = $this->obj_ponto->calendario['total'];
				if (isset($this->obj_ponto->data_inicio) && !empty($this->obj_ponto->data_inicio)) {
					$dt_ini = clone $this->obj_ponto->data_inicio;
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
			require_once ABSPATH . '/views/' . $this->nome_view . '/espelho-v2-view.php';
		}

		function jornadaView(){
			if (isset($_POST['status_jornada']) && !empty($_POST['status_jornada'])) {
				switch ($_POST['status_jornada']) {
					case 'inativo':
						$status_jornada = 'inativo';
						break;
					case 'todos':
						$status_jornada = 'todos';
						break;
					default:
						$status_jornada = 'ativo';
						break;
				}
			} else {
				$status_jornada = 'ativo';
			}

			if ($this->nivel_acesso < 4) {
				$retorno['codigo'] = 1;
				$retorno['mensagem'] = "Sem permissão";
			}

			$permissoes = json_decode($this->cl_permissoes->checkPermissoes('jornadaView', 'metodo'));
			if (!$permissoes) {
				$retorno['codigo'] = 1;
				$retorno['input'] = 'JornadaView';
				$retorno['output'] = $permissoes;
				$retorno['mensagem'] = "Permissoes não encontradas para esta ação!";
				throw new Exception(json_encode($retorno), 1);
			} elseif ($permissoes->codigo != 0) {
				$retorno['codigo'] = 1;
				$retorno['input'] = 'JornadaView';
				$retorno['output'] = $permissoes;
				$retorno['mensagem'] = $permissoes->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} elseif (isset($permissoes->output->permissoes) && $permissoes->output->permissoes < 1) {
				$retorno['codigo'] = 1;
				$retorno['input'] = 'JornadaView';
				$retorno['output'] = $permissoes;
				$retorno['mensagem'] = 'Você não tem acesso a este recurso!';
				throw new Exception(json_encode($retorno), 1);
			}

			if (isset($_POST['funcionario']) && !empty($_POST['funcionario'])) {
				$id_funcionario = $_POST['funcionario'];
				$jornada = json_decode($this->modelo->getJornadaByUsuarioArray($id_funcionario));
			} else {
				$jornada = json_decode($this->modelo->getJornadaDias());
			}

			$funcionarios = json_decode($this->modelo->getUsuarios());
			if (is_array($jornada)) {
				$obj_jornada = new Custom();
				foreach ($jornada as $key => $value) {
					$i1 = $value->id_jornada;
					$obj_jornada->{$i1}->id_jornada = $value->id_jornada;
					$obj_jornada->{$i1}->nome = $value->nome;
					$obj_jornada->{$i1}->dia_semana .= nomeSemana($value->dia_semana) . ',';
					$obj_jornada->{$i1}->entrada = $value->entrada;
					$obj_jornada->{$i1}->saida = $value->saida;
					$obj_jornada->{$i1}->almoco_min = $value->almoco_min;
					$obj_jornada->{$i1}->almoco_max = $value->almoco_max;
					$obj_jornada->{$i1}->almoco_min = $value->almoco_min;
					$obj_jornada->{$i1}->nucleo_ini = $value->nucleo_in;
					$obj_jornada->{$i1}->nucleo_fim = $value->nucleo_fim;
					$obj_jornada->{$i1}->status_jornada = $value->status_jornada;
					$obj_jornada->{$i1}->aderir_feriado = $value->aderir_feriado;
					$obj_jornada->{$i1}->aderir_jornada = $value->aderir_jornada;
					$obj_jornada->{$i1}->aderir_add_noturno = $value->aderir_add_noturno;
					$temp = $value;
				}
			} else {
				$obj_jornada = null;
			}
			require_once ABSPATH . '/views/' . $this->nome_view . '/jornada-view.php';
		}

		function ocorrenciaView(){
			$id_funcionario = null;
			$id_ocorrencia = null;
			if (isset($_POST["periodo_ini"]) && !empty($_POST["periodo_ini"])) {
				$periodo_ini = getdataAtual($_POST["periodo_ini"]);
			} elseif (isset($this->parametros[1]) && !empty($this->parametros[1])) {
				$periodo_ini = getdataAtual($this->parametros[1]);
			} else {
				$periodo_ini = clone $this->data_hora_atual;
				$periodo_ini->modify('first day of this month');
			}

			if (isset($_POST["periodo_fim"]) && !empty($_POST["periodo_fim"])) {
				$periodo_fim = getdataAtual($_POST["periodo_fim"]);
			} elseif (isset($this->parametros[1]) && !empty($this->parametros[1])) {
				$periodo_fim = getdataAtual($this->parametros[1]);
			} else {
				$periodo_fim = clone $this->data_hora_atual;
				$periodo_fim->modify('last day of this month');
			}

			if (isset($_POST["classe"]) && !empty($_POST["classe"])) {
				$classe = $this->obj_ponto->returnClasse($_POST["classe"]);
			} else {
				$classe = null;
			}

			if (isset($_POST["funcionario"]) && !empty($_POST["funcionario"]) && is_numeric($_POST["funcionario"])) {
				$id_funcionario = $_POST["funcionario"];
			} elseif (isset($this->parametros[0]) && !empty($this->parametros[0]) && is_numeric($this->parametros[0])) {
				$id_funcionario = $this->parametros[0];
			}

			switch ($this->cl_permissoes->alcada_acesso) {
				case '4':
					$lista_usuarios = json_decode($this->modelo->getUsuarios());
					$ocorrencias = json_decode($this->modelo->getOcorrenciaIntervaloByUser($periodo_ini->format('Y-m-d'), $periodo_fim->format('Y-m-d'), $id_funcionario, $classe));
					break;
				case '3':
				case '2':
					$lista_usuarios = json_decode($this->modelo->getUsuarios(null, $_SESSION['cmswerp']['userdata']->id));
					$alcada = $permissoes->output->alcadas;
					$id_boss = $_SESSION['cmswerp']['userdata']->id;
					$ocorrencias = json_decode($this->modelo->getOcorrenciaByBoss($_SESSION['cmswerp']['userdata']->id, $periodo_ini->format('Y-m-d'), $periodo_fim->format('Y-m-d')));
					break;
				default:
					$lista_usuarios = json_decode($this->modelo->getUsuarios($_SESSION['cmswerp']['userdata']->id));
					$ocorrencias = json_decode($this->modelo->getOcorrenciaIntervaloByUser($periodo_ini->format('Y-m-d'), $periodo_fim->format('Y-m-d'), $_SESSION['cmswerp']['userdata']->id, $classe));
					break;
			}
			require_once ABSPATH . '/views/' . $this->nome_view . '/ocorrencia-view.php';
		}

		function lancamentoView(){
			include 'config_extras.php';
			if ($this->nivel_acesso < 4) {
				$retorno['codigo'] = 1;
				$retorno['mensagem'] = "Sem permissão";
			}

			$permissoes = json_decode($this->cl_permissoes->checkPermissoes('lancamentoView', 'metodo'));
			if (!$permissoes) {
				$retorno['codigo'] = 1;
				$retorno['input'] = 'lancamentoView';
				$retorno['output'] = $permissoes;
				$retorno['mensagem'] = "Permissoes não encontradas para esta ação!";
				throw new Exception(json_encode($retorno), 1);
			} elseif ($permissoes->codigo != 0) {
				$retorno['codigo'] = 1;
				$retorno['input'] = 'lancamentoView';
				$retorno['output'] = $permissoes;
				$retorno['mensagem'] = $permissoes->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} elseif (isset($permissoes->output->permissoes) && $permissoes->output->permissoes < 1) {
				$retorno['codigo'] = 1;
				$retorno['input'] = 'lancamentoView';
				$retorno['output'] = $permissoes;
				$retorno['mensagem'] = 'Você não tem acesso a este recurso!';
				throw new Exception(json_encode($retorno), 1);
			}

			if ($permissoes->output == "master") {
				$lista_usuarios = json_decode($this->modelo->getUsuarios());
			} else {
				switch ($permissoes->output->alcadas) {
					case '2':
						$lista_usuarios = json_decode($this->modelo->getUsuarios(null, $_SESSION['cmswerp']['userdata']->id));
						break;
					case '4':
						$lista_usuarios = json_decode($this->modelo->getUsuarios());
						break;
					default:
						$lista_usuarios = json_decode($this->modelo->getUsuarios($_SESSION['cmswerp']['userdata']->id));
						break;
				}
			}

			$departamento = json_decode($this->modelo->getUsuarios(null, null, null, true));
			$data_final = $this->data_hora_atual->format('d/m/Y');
			$data_inicial = $this->data_hora_atual->modify('first day of this month');
			$data_inicial = $this->data_hora_atual->format('d/m/Y');

			if (isset($_POST["funcionario"]) && !empty($_POST["funcionario"])) {
				$id_funcionario = $_POST["funcionario"];
			} else {
				$id_funcionario = null;
			}

			if (isset($_POST["periodo_ini"]) && !empty($_POST["periodo_ini"])) {
				$obj_data = getDataAtual($_POST["periodo_ini"]);
				$data_ini = $obj_data->format('Y-m-d');
				$data_inicial = $obj_data->format('d/m/Y');
			} else {
				$data_ini = $this->data_hora_atual->format('Y-m-d');
			}

			if (isset($_POST["periodo_fim"]) && !empty($_POST["periodo_fim"])) {
				$obj_data = getDataAtual($_POST["periodo_fim"]);
				$data_fim = $obj_data->format('Y-m-d');
				$data_final = $obj_data->format('d/m/Y');
			} else {
				$obj_data = clone $this->data_hora_atual;
				$data_fim = $obj_data->format('Y-m-d');
			}

			if (isset($_POST["classe"]) && !empty($_POST["classe"])) {
				$classe = $_POST["classe"];
			} else {
				$classe = null;
			}

			$ocorrencias = json_decode($this->modelo->getOcorrenciaIntervalo($data_ini, $data_fim, $classe, $id_funcionario, null, 'AL'));
			$lancamentos = json_decode($this->modelo->getLancamentos($id_funcionario));
			foreach ($ocorrencias as $key => $value) {
				$value->origem = 'ocorrencias';
				if ($value->data == "0000-00-00") {
					$value->data = "-";
				} else {
					$value->data = convertDate($value->data);
				}

				if ($value->fonte == "AL") {
					if ($value->periodo_ini == null || $value->periodo_fim == null) {
						$value->periodo_ini = $value->data;
						$value->periodo_fim = $value->data;
					} else {
						$obj_data_ini = new DateTime($value->periodo_ini);
						$obj_data_fim = new DateTime($value->periodo_fim);
						$value->periodo_ini = $obj_data_ini->format('d/m/Y');
						$value->periodo_fim = $obj_data_fim->format('d/m/Y');
					}

					if ($value->classe == "AL1") {
						$value->tipo = "FÉRIAS";
						$value->classe = "FÉRIAS";
					} elseif ($value->classe == "AL4") {
						$value->nome_usuario = "FERIADO";
						$value->tipo = "FERIADO";
						$value->classe = "FERIADO";
					}
				}
			}
			require_once ABSPATH . '/views/' . $this->nome_view . '/lancamento-view.php';
		}

		function pontodiaView(){
			include 'config_extras.php';
			try {
				$session = json_decode($_SESSION['cmswerp']['userdata']->permissoes);
				$permissoes = json_decode($this->cl_permissoes->checkPermissoes('espelhoView', 'metodo'));
				if (!$permissoes) {
					$retorno['codigo'] = 1;
					$retorno['input'] = 'espelhoView';
					$retorno['output'] = $permissoes;
					$retorno['mensagem'] = "Permissoes não encontradas para esta ação!";
					throw new Exception(json_encode($retorno), 1);
				} elseif ($permissoes->codigo != 0) {
					$retorno['codigo'] = 1;
					$retorno['input'] = 'espelhoView';
					$retorno['output'] = $permissoes;
					$retorno['mensagem'] = $permissoes->mensagem;
					throw new Exception(json_encode($retorno), 1);
				} elseif (isset($permissoes->output->permissoes) && $permissoes->output->permissoes < 1) {
					$retorno['codigo'] = 1;
					$retorno['input'] = 'espelhoView';
					$retorno['output'] = $permissoes;
					$retorno['mensagem'] = 'Você não tem acesso a este recurso!';
					throw new Exception(json_encode($retorno), 1);
				}

				// definindo permissoes do listview
				if ($permissoes->output == "master") {
					$lista_usuarios = json_decode($this->modelo->getUsuarios());
				} else {
					switch ($permissoes->output->alcadas) {
						case '2':
							$lista_usuarios = json_decode($this->modelo->getUsuarios(null, $_SESSION['cmswerp']['userdata']->id));
							break;
						case '4':
							$lista_usuarios = json_decode($this->modelo->getUsuarios());
							break;
						default:
							$lista_usuarios = json_decode($this->modelo->getUsuarios($_SESSION['cmswerp']['userdata']->id));
							break;
					}
				}

				// Id utilizado na pesquisa, caso não informado o id padrão é o do proprio usuario logado.
				if (isset($_POST['id_funcionario']) && !empty($_POST['id_funcionario'])) {
					$id_usuario = $_POST['id_funcionario'];
				} else {
					$id_usuario = $_SESSION['cmswerp']['userdata']->id;
				}

				$hoje = clone $this->data_hora_atual;
				if ($id_usuario != null && !empty($id_usuario)) {
					if (isset($_POST['id_funcionario']) && !empty($_POST['id_funcionario'])) {
						$registro_dia = json_decode($this->modelo->getRegistroPonto($hoje->format('Y-m-d'), $_POST['id_funcionario']));
					} else {
						$registro_dia = json_decode($this->modelo->getRegistroPonto($hoje->format('Y-m-d'), $lista_usuarios));
					}
					$dados_usuario = json_decode($this->modelo->getUsuarios($id_usuario));
					$get_jornada_usuario = json_decode($this->modelo->getRhJornadaUsuario($id_usuario, null, 'ativo'));
				} else {
					// colocar retorno de mensagem funcionario nao encontrado
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = $id_usuario;
					$retorno['mensagem'] = "ID Funcionario (null)";
					throw new Exception(json_encode($retorno), 1);
				}

				$matriz_ponto_dia = $this->obj_ponto->orderPontoDia($registro_dia);
				require_once ABSPATH . '/views/' . $this->nome_view . '/ponto-dia-view.php';
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function singView(){
			try {
				$session = json_decode($_SESSION['cmswerp']['userdata']->permissoes);
				$permissoes = json_decode($this->cl_permissoes->checkPermissoes('espelhoView', 'metodo'));
				if (!$permissoes) {
					$retorno['codigo'] = 1;
					$retorno['input'] = 'espelhoView';
					$retorno['output'] = $permissoes;
					$retorno['mensagem'] = "Permissoes não encontradas para esta ação!";
					throw new Exception(json_encode($retorno), 1);
				} elseif ($permissoes->codigo != 0) {
					$retorno['codigo'] = 1;
					$retorno['input'] = 'espelhoView';
					$retorno['output'] = $permissoes;
					$retorno['mensagem'] = $permissoes->mensagem;
					throw new Exception(json_encode($retorno), 1);
				} elseif (isset($permissoes->output->permissoes) && $permissoes->output->permissoes < 1) {
					$retorno['codigo'] = 1;
					$retorno['input'] = 'espelhoView';
					$retorno['output'] = $permissoes;
					$retorno['mensagem'] = 'Você não tem acesso a este recurso!';
					throw new Exception(json_encode($retorno), 1);
				}

				// definindo permissoes do listview
				if ($permissoes->output == "master") {
					$lista_usuarios = json_decode($this->modelo->getUsuarios());
				} else {
					switch ($permissoes->output->alcadas) {
						case '2':
							$lista_usuarios = json_decode($this->modelo->getUsuarios(null, $_SESSION['cmswerp']['userdata']->id));
							break;
						case '4':
							$lista_usuarios = json_decode($this->modelo->getUsuarios());
							break;
						default:
							$lista_usuarios = json_decode($this->modelo->getUsuarios($_SESSION['cmswerp']['userdata']->id));
							break;
					}
				}

				if (isset($_POST['funcionario']) && !empty($_POST['funcionario'])) {
					$id_owner = $_POST['funcionario'];
				} else {
					$id_owner = null;
				}

				if (isset($_POST['periodo_ini']) && !empty($_POST['periodo_ini'])) {
					$data_ini = convertDate($_POST['periodo_ini']);
					$data_ini_view = $_POST['periodo_ini'];
				} else {
					$data_ini = null;
					$data_ini_view = $this->data_hora_atual->format('01/m/Y');
				}

				if (isset($_POST['periodo_fim']) && !empty($_POST['periodo_fim'])) {
					$data_fim = convertDate($_POST['periodo_fim']);
					$data_fim_view = $_POST['periodo_fim'];
				} else {
					$data_fim = null;
					$data_fim_view = $this->data_hora_atual->format('d/m/Y');
				}

				if (isset($_POST['search_tipo_doc']) && !empty($_POST['search_tipo_doc'])) {
					if ($_POST['search_tipo_doc'] == 'todos') {
						$search_tipo_doc = null;
					} else {
						$search_tipo_doc = $_POST['search_tipo_doc'];
					}
				} else {
					$search_tipo_doc = 'demonstrativo';
				}
				$ged_documento = json_decode($this->modelo->gedFullView('pessoal', $search_tipo_doc, $id_owner, $data_ini, $data_fim, null));
				if ($ged_documento) {
					foreach ($ged_documento as $key => $value) {
						if (isset($value->id_ged_anexo) && !empty($value->id_ged_anexo)) {
							$ged_ass[$value->id_ged_documento] = json_decode($this->modelo->gedFull($value->id_ged_documento));
							if (isset($ged_ass[$value->id_ged_documento]) && !empty($ged_ass[$value->id_ged_documento][0]->id_usuario)) {
								$signatario[$value->id_ged_documento] = $ged_ass[$value->id_ged_documento][0]->id_ged_anexo;
							}
							$path_arquivo[$value->id_ged_documento] = $value->path_root . $value->path_objeto . DS . $value->nome_hash;
							$path_arquivo[$value->id_ged_documento] = base64_encode($path_arquivo[$value->id_ged_documento]);
						}
					}
				}
				require_once ABSPATH . '/views/' . $this->nome_view . '/sign-view.php';
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function addJornada(){
			require_once ABSPATH . '/views/' . $this->nome_view . '/add_jornada-view.php';
		}

		function detalhejornada(){
			if (isset($this->parametros[0]) && validaId($this->parametros[0])) {
				$dados_jornada = json_decode($this->modelo->getJornadaDias($this->parametros[0]));
				require_once ABSPATH . '/views/' . $this->nome_view . '/jornada-detalhe-view.php';
			} else {
				$this->retorno('erro', 'Informe o ID');
			}
		}
		
		function alterarJornada(){
			if (isset($_POST['acao'])) {
				switch ($_POST['acao']) {
					case 'inativar':
						if (isset($_POST['id']) && validaId($_POST['id'])) {
							$param['status'] = 'inativo';
							$this->modelo->setTable('rh_jornada_trabalho');
							$is_save = $this->modelo->save($param, $_POST['id']);
							if ($is_save) {
								$this->retorno('ok', 'sucesso');
							} else {
								$this->retorno('erro', 'Erro ao inativar jornada');
							}
						} else {
							$this->retorno('erro', 'ID da jornada não informado');
						}
						break;
					default:
						$this->retorno('erro', 'Ação não informada');
						break;
				}
			} else {
				$this->retorno('erro', 'Ação não informada');
			}
		}

		function registrar(){
			// $alerta['email_boss'] = 'julio.gomes@cmsw.com|julio.gomes@cmsw.com';
			// $alerta['mensagem'] = 'teste';
			// include 'config_extras.php';
			$obj_marcacao = new Custom();
			try {
				$hoje = clone $this->data_hora_atual;
				// apagar
				//$hoje = getDataAtual('2025-10-17');
				//$hoje->setTime('13', '46', '00');
				// $hoje->setDate(2025, 08, 27);
				// apagar
				$diah = $hoje->format('Y-m-d');
				$ontem = clone $this->data_hora_atual;
				$ontem->modify('-1 day');
				$dt_ini = clone $this->data_hora_atual;
				$dt_ini->setTime(00, 00, 00);
				$dt_ini->modify('-1 day');
				$dt_fim = clone $this->data_hora_atual;
				$dt_fim->setTime(23, 59, 59);
				if (!isset($_SESSION['cmswerp']['userdata']->id) || empty($_SESSION['cmswerp']['userdata']->id)) {
					$this->retorno('erro', 'Erro nos parametros do usuario.');
				} else {
					$usuario = json_decode($this->modelo->getUsuarios($_SESSION['cmswerp']['userdata']->id));
					if ($usuario) {
						$dia_semana = ($hoje->format('w'));
						if ($dia_semana == 0) {
							$dia_semana = 7;
						}

						$ultima_marcacao = json_decode($this->modelo->ultima_marcacao($usuario[0]->id));
						$data_ultima = getDateTime($ultima_marcacao[0]->data_marcacao . ' ' . $ultima_marcacao[0]->hora_marcacao);
						$jornada = json_decode($this->modelo->getRhJornadaUsuario($_SESSION['cmswerp']['userdata']->id, null, 'ativo'));
						if (!isset($jornada) || empty($jornada)) {
							$retorno['codigo'] = 1;
							$retorno['mensagem'] = "Usuário sem jornada, entre em contato com a Administração.";
							throw new Exception(json_encode($retorno), 1);
						}

						if (is_array($jornada)) {
							foreach ($jornada as $key => $value) {
								if (strtotime($hoje->format('Y-m-d')) >= strtotime($value->data_inicio)) {
									$id_jornada = $value->id_jornada;
								}
							}
						}

						$jornada_dias = json_decode($this->modelo->getJornadaDias($id_jornada));
						if (isset($jornada_dias) && !empty($jornada_dias)) {
							foreach ($jornada_dias as $key => $value) {
								$i1 = $value->dia_semana;
								$dias_jornada[$i1] = $value;
							}
							$jornada_hoje = $dias_jornada[$dia_semana];
						} else {
							$retorno['codigo'] = 1;
							$retorno['mensagem'] = "Erro na jornada dias COD 590";
							throw new Exception(json_encode($retorno), 1);
						}

						if (!isset($jornada_hoje) || empty($jornada_hoje)) {
							$retorno['codigo'] = 1;
							$retorno['mensagem'] = "Erro na jornada de hoje.";
							throw new Exception(json_encode($retorno), 1);
						}
					} else {
						$this->retorno('erro', 'Usuario não encontrado');
					}
				}

				if (!isset($this->parametros[0]) || empty($this->parametros[0])) {
					$retorno['codigo'] = 1;
					$retorno['mensagem'] = "Erro nos parametros da marcacao.";
					throw new Exception(json_encode($retorno), 1);
				}

				if (isset($this->marcacao['gerar_token']) && $this->marcacao['gerar_token'] == true) {
					$this->marcacao['status'] = 'pendente';
				}

				$this->marcacao['id_usuario'] = $_SESSION['cmswerp']['userdata']->id;
				$this->marcacao['tipo_marcacao'] = $this->parametros[0];
				$this->marcacao['data_marcacao'] = $hoje->format('Y-m-d');
				$this->marcacao['hora_marcacao'] = $hoje->format('H:i:s');
				$this->marcacao['permitir'] = true;
				$this->marcacao['status'] = 'aprovado';
				$array_entrada = explode(':', $jornada_hoje->entrada);
				$array_saida = explode(':', $jornada_hoje->saida);
				$array_retorno_almoco = explode(':', $jornada_hoje->retorno_almoco);

				if ($jornada_hoje->saida_almoco) {
					$array_saida_almoco = explode(':', $jornada_hoje->saida_almoco);
					$obj_marcacao->saida_almoco = clone $hoje;
					$obj_marcacao->saida_almoco->setTime($array_saida_almoco[0], $array_saida_almoco[1]);
				} else {
					$array_saida_almoco = null;
				}

				if ($jornada_hoje->retorno_almoco) {
					$array_retorno_almoco = explode(':', $jornada_hoje->retorno_almoco);
					$obj_marcacao->retorno_almoco = clone $hoje;
					$obj_marcacao->retorno_almoco->setTime($array_retorno_almoco[0], $array_retorno_almoco[1]);
				} else {
					$array_retorno_almoco = null;
				}

				$time_entrada = $array_entrada[0] . $array_entrada[1];
				$time_saida = $array_saida[0] . $array_saida[1];
				$time_saida_almoco = $array_saida_almoco[0] . $array_saida_almoco[1];
				$time_retorno_almoco = $array_retorno_almoco[0] . $array_retorno_almoco[1];

				$obj_marcacao->entrada = clone $hoje;
				$obj_marcacao->entrada->setTime($array_entrada[0], $array_entrada[1]);
				$obj_marcacao->saida = clone $hoje;
				$obj_marcacao->saida->setTime($array_saida[0], $array_saida[1]);

				if ($jornada_hoje->entrada_min) {
					$obj_marcacao->entrada_min = clone $obj_marcacao->entrada;
					$obj_marcacao->entrada_min->modify("-$jornada_hoje->entrada_min minutes");
				} else {
					$obj_marcacao->entrada_min = null;
				}

				if ($jornada_hoje->entrada_max) {
					$obj_marcacao->entrada_max = clone $obj_marcacao->entrada;
					$obj_marcacao->entrada_max->modify("+$jornada_hoje->entrada_max minutes");
				} else {
					$obj_marcacao->entrada_max = null;
				}

				$this->obj_ponto = new RhPonto($this, $_SESSION['cmswerp']['userdata']->id); //jornada noturna
				// REVISAR TODO O CODIGO, CORREÇÃO TEMPORARIA
				// VERIFICANDO ULTIMA MARCAÇÃO E OCORRENCIA
				// Nova forma de pegar a ultima marcacao por usuario
				$last_marcacao = $this->obj_ponto->getUltimaMarcacao($_SESSION['cmswerp']['userdata']->id);
				if ($last_marcacao) {
					if ($last_marcacao->obj_date <= $hoje) {
						if (
							$last_marcacao->data_marcacao == $hoje->format('Y-m-d') &&
							$last_marcacao->tipo_marcacao == $this->parametros[0]
						) {
							$this->retorno('erro', 'Já existe esse tipo de marcação para o dia de hoje.');
						} else {
							$dif_last = $last_marcacao->obj_date->diff($hoje);
							if ($dif_last->days < 1 && $dif_last->h < 11) {
								if ($last_marcacao->tipo_marcacao == $this->parametros[0]) {
									$dateTime = date('d/m/Y H:i:s', strtotime($last_marcacao->data_marcacao . ',' . $last_marcacao->hora_marcacao));
									$this->retorno('erro', 'Tempo mínimo de descanso (11 horas) não atingido.<br>Ultima marcação: ' . $dateTime);
								}
							}
						}
					} else {
						$this->retorno('erro', 'Existe uma ocorrencia para data futura causando conflito, ID ' . $last_marcacao->id . ' DATA: ' . $last_marcacao->obj_date->format('d/m/Y H:i:s'));
						exit;
					}
				}

				$this->obj_ponto->gerarEspelho($dt_ini, $dt_fim);
				$jornada_noturna = $this->obj_ponto->verificaJornadaNoturna($jornada_dias);
				if ($jornada_noturna) {
					$obj_marcacao->saida->modify('+1 day');
				}

				if ($jornada_hoje->saida_min) {
					$obj_marcacao->saida_min = clone $obj_marcacao->saida;
					$obj_marcacao->saida_min->modify("-$jornada_hoje->saida_min minutes");
				} else {
					$obj_marcacao->saida_min = null;
				}

				if ($jornada_hoje->saida_max) {
					$obj_marcacao->saida_max = clone $obj_marcacao->saida;
					$obj_marcacao->saida_max->modify("+$jornada_hoje->saida_max minutes");
				} else {
					$obj_marcacao->saida_max = null;
				}

				$obj_marcacao->tempo_almoco_min = ($jornada_hoje->tempo_almoco_min) ? $jornada_hoje->tempo_almoco_min : null;
				$obj_marcacao->tempo_almoco_max = ($jornada_hoje->tempo_almoco_max) ? $jornada_hoje->tempo_almoco_max : null;
				$obj_marcacao->extra_minimo = ($jornada_hoje->extra_minimo) ? $jornada_hoje->extra_minimo : null;
				$obj_marcacao->extra_maximo = ($jornada_hoje->extra_maximo) ? $jornada_hoje->extra_maximo : null;

				switch ($this->parametros[0]) {
					case 'B01':
						$totais_horas = $this->obj_ponto->calendario['total'];
						if (isset($totais_horas['saldo']) && $totais_horas['saldo'] > 0) {
							if (isset($obj_marcacao->entrada_min) && !empty($obj_marcacao->entrada_min)) {
								if ($obj_marcacao->extra_maximo > 0) {
									$div_compensa = ($obj_marcacao->extra_maximo / 2);
									$previsao_entrada = clone $obj_marcacao->entrada;
									$previsao_entrada->modify("+$div_compensa minutes");
								}

								if ($hoje < $obj_marcacao->entrada) {
									$this->marcacao['permitir'] = false;
									$this->marcacao['mensagem'] = "Você tem um total de horas positivas de " . convertHorasMinutos($totais_horas['saldo'], 'decimal>horas', true) . " aguarde até " . $previsao_entrada->format('H:i') . " da sua jornada para efetuar marcação";
									$this->retorno('erro', $this->marcacao['mensagem']);
								}
							} else {
								$this->marcacao['permitir'] = false;
								$this->marcacao['mensagem'] = "Erro na configuração do horario de entrada";
								$this->retorno('erro', $this->marcacao['mensagem']);
							}
						}

						// ativar depois de enviar email para geral
						// if ($this->obj_ponto->calendario['pendencias']['status'] == true) {
						// 	$this->marcacao['permitir']     = false;
						// 	$this->marcacao['mensagem'] 	= "Existem ocorrencias pendentes, regularize antes de registrar seu ponto, vá em menu ocorrencias para reenviar o token de validação.";
						// 	$this->retorno('erro', $this->marcacao['mensagem']);
						// }

						if (isset($obj_marcacao->entrada_min) && !empty($obj_marcacao->entrada_min)) {
							if ($hoje < $obj_marcacao->entrada_min) {
								$this->marcacao['permitir'] = false;
								$this->marcacao['mensagem'] = "Horario de entrada antes do permitido, aguarde até as " . $obj_marcacao->entrada_min->format('H:i') . " para marcar entrada";
								$this->retorno('erro', $this->marcacao['mensagem']);
							}
						}

						if (isset($obj_marcacao->entrada_max) && !empty($obj_marcacao->entrada_max)) {
							if ($hoje > $obj_marcacao->entrada_max) {
								// ----------- Regra de desconto em folha desativada - 30/09/2025
								// $this->marcacao['permitir'] = true;
								// $this->marcacao['gerar_token'] = false;
								// //desativado para colocar regra nova com desconto em folha de pagamento
								// // $this->marcacao['ocorrencia'] = 'TB01';
								// $this->marcacao['ocorrencia'] = 'D1';
								// $this->marcacao['status'] = "aprovado";
								// $this->marcacao['alerta'] = "Entrada após horario nucleo (" . $obj_marcacao->entrada_max->format('H:i') . ").";
								// $this->marcacao['mensagem'] = $this->marcacao['alerta'] . " Gestor será notificado.";
								// $this->marcacao['minutos'] = $this->calculoDifHoraIniFim($hoje->format('Y-m-d H:i'), $obj_marcacao->entrada_max->format('Y-m-d H:i'));
								// $this->marcacao['ocorrenciaDifMaracao'] = $this->marcacao['ocorrencia'];

								// ----------- versão antes da regra de desconto em folha
								$this->marcacao['permitir'] = true;
								$this->marcacao['gerar_token'] = true;
								$this->marcacao['ocorrencia'] = 'TB01';
								$this->marcacao['status'] = "pendente 2";
								$this->marcacao['alerta'] = "Entrada após horario nucleo as " . $hoje->format('H:i');
								$this->marcacao['mensagem'] = $this->marcacao['alerta'] . " será necessario aprovação do gestor";
							}
						}

						if (isset($ultima_marcacao) && !empty($ultima_marcacao)) {
							switch ($ultima_marcacao[0]->tipo_marcacao) {
								case 'B01':
									$diff = $data_ultima->diff($hoje);
									if ($diff->days < 1 && $diff->h < 8) {
										$this->marcacao['permitir'] = false;
										$this->marcacao['mensagem'] = 'Já existe marcação de entrada para esta data';
										$this->retorno('erro', $this->marcacao['mensagem']);
									}
									break;
								case 'B02':
								case 'B03':
								case 'B04':
								case 'B05':
								case 'B06':
									$tempo_ultima = $this->obj_ponto->calcMinutosDiff($data_ultima->diff($hoje));
									if ($tempo_ultima < 480) {
										$this->marcacao['permitir'] = false;
										$this->marcacao['mensagem'] = 'Parece haver inconsistencias em sua ultima marcação. Verifique!!!';
										$this->retorno('erro', $this->marcacao['mensagem']);
									}
									break;
							}
						}
						break;
					case 'B02':
						// verificar B01
						$b1 = $this->obj_ponto->calendario['diario'][$diah]['marcacoes'][0][0];
						if (!isset($b1->hora_marcacao) || empty($b1->hora_marcacao)) {
							$this->marcacao['permitir'] = false;
							$this->marcacao['mensagem'] = 'Marcação de entrada não encontrada, justifique antes de registar a saida para almoço';
							$this->retorno('erro', $this->marcacao['mensagem']);
						}

						if ($obj_marcacao->saida_almoco > $obj_marcacao->retorno_almoco) {
							$obj_marcacao->retorno_almoco->modify('+1 day');
						}


						if (isset($obj_marcacao->saida_almoco) && !empty($obj_marcacao->saida_almoco)) {
							if ($hoje < $obj_marcacao->saida_almoco) {
								$this->marcacao['permitir'] = false;
								$this->marcacao['mensagem'] = "Horario de saida para almoço antes do permitido, aguarde até as " . $obj_marcacao->saida_almoco->format('H:i') . " para marcar";
								$this->retorno('erro', $this->marcacao['mensagem']);
							}
						}

						if (isset($obj_marcacao->retorno_almoco) && !empty($obj_marcacao->retorno_almoco)) {
							if ($hoje > $obj_marcacao->retorno_almoco) {
								$this->marcacao['permitir'] = true;
								$this->marcacao['gerar_token'] = true;
								$this->marcacao['ocorrencia'] = 'TB02';
								$this->marcacao['status'] = "pendente";
								$this->marcacao['alerta'] = "Saida para o almoço após o horario permitido(" . $hoje->format('H:i') . ").";
								$this->marcacao['mensagem'] = $this->marcacao['alerta'] . " Será necessario aprovação do gestor";
							}
						}
						break;
					case 'B03':
						// verificar B02
						if (isset($last_marcacao->hora_marcacao) && !empty($last_marcacao->hora_marcacao)) {
							$saida_almoço = getDateTime($last_marcacao->data_marcacao . ' ' . $last_marcacao->hora_marcacao);
							$tempo_almoço = $this->obj_ponto->calcMinutosDiff($saida_almoço->diff($hoje));
							if ($tempo_almoço < $obj_marcacao->tempo_almoco_min) {
								$this->marcacao['permitir'] = false;
								$this->marcacao['mensagem'] = "Tempo de intervalo abaixo do minimo obrigatorio, " . $obj_marcacao->tempo_almoco_min . " minutos";
								$this->retorno('erro', $this->marcacao['mensagem']);
							} elseif ($tempo_almoço > $obj_marcacao->tempo_almoco_max) {

								// ----------- Regra de desconto em folha desativada - 30/09/2025

								// $this->marcacao['permitir'] = true;
								// $this->marcacao['gerar_token'] = false;
								// //desativado para colocar regra nova com desconto em folha de pagamento
								// // $this->marcacao['ocorrencia'] = 'TB03';
								// $this->marcacao['ocorrencia'] = 'D1';
								// $this->marcacao['status'] = "aprovado";
								// $this->marcacao['alerta'] = "Intervalo de almoço acima do permitido(" . $obj_marcacao->tempo_almoco_max . ") minutos ";
								// $this->marcacao['mensagem'] = $this->marcacao['alerta'] . " Gestor será notificado.";
								// // $this->marcacao['minutos'] = $this->calculoDifHoraIniFim($hoje->format('Y-m-d H:i'), $obj_marcacao->tempo_almoco_max->format('Y-m-d H:i'));
								// $this->marcacao['minutos'] = $tempo_almoço - $obj_marcacao->tempo_almoco_max;
								// $this->marcacao['ocorrenciaDifMaracao'] = $this->marcacao['ocorrencia'];
								// $this->marcacao['notificacao'] = true;

								// ----------- versão antes da regra de desconto em folha
								$this->marcacao['permitir'] = true;
								$this->marcacao['gerar_token'] = true;
								$this->marcacao['ocorrencia'] = 'TB03';
								$this->marcacao['status'] = "pendente 5";
								$this->marcacao['alerta'] = "Intervalo de almoço acima do permitido " . $obj_marcacao->tempo_almoco_max . " minutos ";
								$this->marcacao['mensagem'] = $this->marcacao['alerta'] . " será necessario aprovação do gestor";
							}
						} else {
							$this->marcacao['permitir'] = false;
							$this->marcacao['mensagem'] = 'Marcação de saida para almoço não encontrada, justifique antes de registar o retorno';
							$this->retorno('erro', $this->marcacao['mensagem']);
						}

						if ($obj_marcacao->saida_almoco > $obj_marcacao->retorno_almoco) {
							$obj_marcacao->retorno_almoco->modify('+1 day');
						}

						if (isset($obj_marcacao->saida_almoco) && !empty($obj_marcacao->saida_almoco)) {
							if ($hoje < $obj_marcacao->saida_almoco) {
								$this->marcacao['permitir'] = false;
								$this->marcacao['mensagem'] = "Horario de retorno do almoço antes do permitido, aguarde até as " . $obj_marcacao->saida_almoco->format('H:i') . " para marcar";
								$this->retorno('erro', $this->marcacao['mensagem']);
							}
						}

						if (isset($obj_marcacao->retorno_almoco) && !empty($obj_marcacao->retorno_almoco)) {
							if ($hoje > $obj_marcacao->retorno_almoco) {

								// ----------- Regra de desconto em folha desativada - 30/09/2025

								// $this->marcacao['permitir'] = true;
								// $this->marcacao['alerta'] = "Retorno do almoço após o horario permitido (" . $hoje->format('H:i') . ").";

								// $difMinSaida = $this->calculoDifHoraIniFim($hoje->format('Y-m-d H:i'), $last_marcacao->hora_marcacao) - $obj_marcacao->tempo_almoco_min;
								// // $EhsaidaAposNucleo = $this->calculoDifHoraIniFim($hoje->format('Y-m-d H:i'), $obj_marcacao->retorno_almoco->format('Y-m-d H:i')) > (int) $obj_marcacao->tempo_almoco_min;
								// $this->marcacao['alerta'] = "Retorno do almoço após o horario permitido (" . $hoje->format('H:i') . ").";
								// if ($difMinSaida > 0) {
								// 	$this->marcacao['mensagem'] = $this->marcacao['alerta'] . "Gestor sera notificado";
								// 	$this->marcacao['ocorrencia'] = 'D1';
								// 	$this->marcacao['status'] = "aprovado";
								// 	$this->marcacao['minutos'] = $difMinSaida;
								// 	$this->marcacao['ocorrenciaDifMaracao'] = $this->marcacao['ocorrencia'];
								// 	$this->marcacao['gerar_token'] = false;
								// 	$this->marcacao['notificacao'] = true;
								// } else {
								// 	$this->marcacao['mensagem'] = $this->marcacao['alerta'] . " Será necessario aprovação do gestor";
								// 	$this->marcacao['gerar_token'] = false;
								// 	$this->marcacao['ocorrencia'] = 'TB02';
								// 	$this->marcacao['status'] = "pendente";
								// 	$this->marcacao['mensagem'] = $this->marcacao['alerta'] . " Gestor será notificado";
								// 	$this->marcacao['gerar_token'] = true;
								// 	$this->marcacao['notificacao'] = true;
								// }

								// ----------- versão antes da regra de desconto em folha
								$this->marcacao['permitir'] = true;
								$this->marcacao['gerar_token'] = true;
								$this->marcacao['ocorrencia'] = 'TB02';
								$this->marcacao['status'] = "pendente 4";
								$this->marcacao['alerta'] = "Retorno do almoço após o horario permitido " . $hoje->format('H:i');
								$this->marcacao['mensagem'] = $this->marcacao['alerta'] . " será necessario aprovação do gestor";

							}
						}
						break;
					case 'B04':
						$tempo_diario = 0;
						$b1 = $this->obj_ponto->calendario['diario'][$diah]['marcacoes'][0][0];
						$b2 = $this->obj_ponto->calendario['diario'][$diah]['marcacoes'][0][1];
						$b3 = $this->obj_ponto->calendario['diario'][$diah]['marcacoes'][0][2];
						if (!empty($b1->hora_marcacao)) {
							$entrada_dia = getDateTime($b1->data_marcacao . ' ' . $b1->hora_marcacao);
						} else {
							$entrada_dia = null;
						}

						if (!empty($b2->hora_marcacao)) {
							$saida_almoco = getDateTime($b2->data_marcacao . ' ' . $b2->hora_marcacao);
						} else {
							$saida_almoco = null;
						}

						if (!empty($b3->hora_marcacao)) {
							$retorno_almoco = getDateTime($b3->data_marcacao . ' ' . $b3->hora_marcacao);
						} else {
							$retorno_almoco = null;
						}

						if ($entrada_dia && $saida_almoco && $retorno_almoco) {
							$tempo_diario += $this->obj_ponto->calcMinutosDiff($entrada_dia->diff($saida_almoco));
							$tempo_diario += $this->obj_ponto->calcMinutosDiff($retorno_almoco->diff($hoje));
						} elseif ($entrada_dia && $saida_almoco) {
							$tempo_diario += $this->obj_ponto->calcMinutosDiff($entrada_dia->diff($saida_almoco));
						} elseif ($retorno_almoco) {
							$tempo_diario += $this->obj_ponto->calcMinutosDiff($retorno_almoco->diff($hoje));
						} elseif ($entrada_dia) {
							$tempo_diario += $this->obj_ponto->calcMinutosDiff($entrada_dia->diff($hoje));
						}

						if ($obj_marcacao->saida_min) {
							if ($hoje < $obj_marcacao->saida_min) {
								$this->marcacao['permitir'] = true;
								$this->marcacao['gerar_token'] = false;
								$this->marcacao['ocorrencia'] = 'TB04';
								$this->marcacao['status'] = "aprovado";
								$this->marcacao['periodo_ini'] = $hoje->format('Y-m-d H:i:s');
								$this->marcacao['periodo_fim'] = $hoje->format('Y-m-d H:i:s');
								$this->marcacao['alerta'] = "Marcação de saida antes do horario nucleo " . $obj_marcacao->saida_min->format('H:i') . ' horas';
								$this->marcacao['mensagem'] = $this->marcacao['alerta'] . " será necessario aprovação do gestor";
								continue;
							}
						}

						if ($obj_marcacao->saida_max) {
							if ($hoje > $obj_marcacao->saida_max) {
								$this->marcacao['permitir'] = true;
								$this->marcacao['gerar_token'] = false;
								$this->marcacao['ocorrencia'] = 'TB04';
								$this->marcacao['status'] = "aprovado";
								$this->marcacao['alerta'] = "Marcação de saida após o maximo permitido " . $obj_marcacao->saida_max->format('H:i') . ' horas';
								$this->marcacao['mensagem'] = $this->marcacao['alerta'] . " será necessario aprovação do gestor";
								continue;
							}
						}
						break;
					case 'B05':
						if (isset($last_marcacao) && !empty($last_marcacao)) {
							$marcacoes = [
								'B01' => 'ENTRADA INÍCIO',
								'B02' => 'SAIDA ALMOÇO',
								'B03' => 'RETORNO ALMOÇO',
								'B04' => 'SAIDA FINAL',
								'B05' => 'PAUSA INÍCIO',
								'B06' => 'PAUSA TÉRMINO'
							];

							if ($last_marcacao->tipo_marcacao == 'B02' || $last_marcacao->tipo_marcacao == 'B04' || $last_marcacao->tipo_marcacao == 'B05') {
								$this->marcacao['mensagem'] = "Há uma marcação (" . $marcacoes[$last_marcacao->tipo_marcacao] . ") em aberto. Ajuste para a nova marcação";
								$this->retorno('erro', $this->marcacao['mensagem']);
							}
						}
				}

				if ($jornada_noturna) {
					$inicio_dia = clone $hoje;
					$inicio_dia->modify('-1 day');
				} else {
					$inicio_dia = clone $hoje;
				}

				$intervalo = $this->obj_ponto->calcMinutosDiff($data_ultima->diff($hoje));
				$total_hoje = $this->obj_ponto->calculahorasDia($inicio_dia->format('Y-m-d'), $this->marcacao);
				$diff_jornada = $this->obj_ponto->checkHorasDiff($obj_marcacao->entrada, $obj_marcacao->saida, true);
				$horas_jornada = ($this->obj_ponto->calcMinutosDiff($diff_jornada) - $obj_marcacao->tempo_almoco_min);
				$totais_horas = $this->obj_ponto->calendario['total'];
				if (isset($totais_horas['saldo']) && $totais_horas['saldo'] > 0) {
					if ($hoje > $obj_marcacao->saida) {
						$this->marcacao['permitir'] = true;
						$this->marcacao['gerar_token'] = true;
						$this->marcacao['alerta'] = 'Você está com ' . convertHorasMinutos($totais_horas['saldo'], 'decimal>horas', true) . ' horas positivas, deveria sair antes das ' . $obj_marcacao->saida->format('H:i');
						$this->marcacao['mensagem'] = $this->marcacao['alerta'] . ' será necessario aprovação do gestor';
					}
				} elseif ($obj_marcacao->extra_maximo) {
					if ($total_hoje > ($obj_marcacao->extra_maximo + $horas_jornada)) {
						$this->marcacao['permitir'] = true;
						$this->marcacao['gerar_token'] = true;
						$this->marcacao['alerta'] = 'Limite de horas extras diaria ' . $jornada_hoje->extra_maximo . ' minutos maximo excedido';
						$this->marcacao['mensagem'] = $this->marcacao['alerta'] . ' será necessario aprovação do gestor';
					}
				} else {
					if ($total_hoje > ('90' + $horas_jornada)) {
						$this->marcacao['permitir'] = true;
						$this->marcacao['gerar_token'] = true;
						$this->marcacao['alerta'] = 'Limite de horas extras diaria 90 minutos maximo excedido';
						$this->marcacao['mensagem'] = $this->marcacao['alerta'] . ' será necessario aprovação do gestor';
					}
				}

				if (isset($this->marcacao['permitir']) && $this->marcacao['permitir'] == true) {
					if (isset($this->marcacao['gerar_token']) && $this->marcacao['gerar_token'] == true) {
						$this->marcacao['status'] = 'pendente';
					}

					$param_marcacao['id_usuario'] = $this->marcacao['id_usuario'];
					$param_marcacao['tipo_marcacao'] = $this->marcacao['tipo_marcacao'];
					$param_marcacao['data_marcacao'] = $this->marcacao['data_marcacao'];
					$param_marcacao['hora_marcacao'] = $this->marcacao['hora_marcacao'];
					$param_marcacao['ocorrencia'] = $this->marcacao['ocorrencia'];
					$param_marcacao['status'] = $this->marcacao['status'];
					$param_marcacao['alterado_em'] = $hoje->format('Y-m-d H:i:s');
					$param_marcacao['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
					$param_marcacao['deleted'] = 0;
					$save_marcacao = $this->modelo->save($param_marcacao);
					if ($save_marcacao) {
						if (isset($this->marcacao['gerar_token']) || $this->marcacao['gerar_token'] == true || isset($this->marcacao['notificacao']) || $this->marcacao['notificacao'] == true) {
							$id_boss = $usuario[0]->boss;
							$boss = json_decode($this->modelo->getUsuarios($id_boss));
							$param_ocorrencia['id_registro'] = $save_marcacao;
							$param_ocorrencia['id_usuario'] = $_SESSION['cmswerp']['userdata']->id;

							// ----------- Regrea de desconto em folha desativada - 30/09/2025
							// $param_ocorrencia['fonte'] = 'D';
							// $param_ocorrencia['classe'] = isset($this->marcacao['ocorrenciaDifMaracao']) ? $this->marcacao['ocorrenciaDifMaracao'] : $param_marcacao['tipo_marcacao'];
							// $param_ocorrencia['minutos'] = isset($this->marcacao['minutos']) ? $this->marcacao['minutos'] : '0';

							$param_ocorrencia['fonte'] = 'T';
							$param_ocorrencia['tipo'] = '1';
							$param_ocorrencia['classe'] = $param_marcacao['tipo_marcacao'];
							$param_ocorrencia['texto'] = $this->marcacao['mensagem'];
							$param_ocorrencia['data'] = $hoje->format('Y-m-d');
							$param_ocorrencia['periodo_ini'] = $hoje->format('Y-m-d H:i:s');
							$param_ocorrencia['periodo_fim'] = $hoje->format('Y-m-d H:i:s');
							$param_ocorrencia['data_lancamento'] = $hoje->format('Y-m-d H:i:s');
							$param_ocorrencia['hora'] = $param_marcacao['hora_marcacao'];
							$param_ocorrencia['status'] = 'pendente';
							$this->modelo->setTable('rh_jornada_ocorrencia');
							$save_ocorrencia = $this->modelo->save($param_ocorrencia);
							if ($save_ocorrencia) {
								if (isset($this->marcacao['gerar_token']) && $this->marcacao['gerar_token'] == true) {
									$dados_token = $this->obj_ponto->dadosToken($save_ocorrencia, $usuario[0]);
									$this->modelo->setTable('rh_token');
									$save_token = $this->modelo->save($dados_token);
									if ($save_token) {
										$alerta['email_boss'] = $boss[0]->email;
										$alerta['mensagem'] = 'Foi gerado uma ocorrencia para o colaborador ' . $usuario[0]->nome . ' ' . $this->marcacao['alerta'] . ' ID da ocorrencia ' . $save_ocorrencia . ' token para regularização: ' . $dados_token['token'];
										$this->obj_ponto->enviarNotificacao('geral', $usuario, $alerta);
										$alerta['mensagem'] = 'Foi gerado uma ocorrencia para o colaborador ' . $usuario[0]->nome . ' ' . $this->marcacao['alerta'] . ' ID da ocorrencia ' . $save_ocorrencia;
										$this->obj_ponto->enviarNotificacao('geral', $usuario, $alerta);
										if (!isset($this->marcacao['notificacao']) || $this->marcacao['notificacao'] == false) {
											$this->retorno('ok', $this->marcacao['mensagem']);
										}
									} else {
										if (!isset($this->marcacao['notificacao']) || $this->marcacao['notificacao'] == false) {
											$this->retorno('erro', 'Erro ao gerar token');
										}
									}
								}
								if (isset($this->marcacao['notificacao']) && $this->marcacao['notificacao'] == true) {
									$alerta['mensagem'] = 'Foi gerado uma ocorrencia para o colaborador ' . $usuario[0]->nome . ' ' . $this->marcacao['alerta'] . ' ID da ocorrencia ' . $save_ocorrencia;
									$alerta['email_boss'] = $boss[0]->email;
									$this->obj_ponto->enviarNotificacao('geral', $usuario, $alerta);
									// $alerta['email_boss'] = 'patrick.nascimento@cmsw.com';
									$this->obj_ponto->enviarNotificacao('geral', $usuario, $alerta);
									$this->retorno('ok', $this->marcacao['mensagem']);
								}
							} else {
								$this->retorno('erro', 'Erro ao salvar ocorrencia');
							}
						} else {
							$this->retorno('ok', 'Sucesso');
						}
					} else {
						$this->retorno('erro', 'Erro ao salvar marcação');
					}
				} else {
					$this->retorno('erro', $this->marcacao['mensagem']);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function pendencia(){
			include 'config_extras.php';
			try {
				$obj_data = new DateTime($this->parametros[0]);
				if (isset($this->parametros[2]) && $this->parametros[2] == "valida_token") {
					$id_usuario = $this->parametros[1];
					$token_pendente = json_decode($this->modelo->getUsuarioOcorrencia($id_usuario, null, null, 'pendente', $obj_data->format('Y-m-d'), 1, "T"));
					if (!isset($token_pendente)) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = $pendencia;
						$retorno['mensagem'] = "Erro ao buscar pendências";
						throw new Exception(json_encode($retorno), 1);
					} else {
						foreach ($token_pendente as $key => $value) {
							$codigo_classe = $value->fonte . $value->tipo;
							$get_token = json_decode($this->modelo->getToken(null, $value->id));
							if (!isset($get_token)) {
								$retorno['codigo'] = 1;
								$retorno['input'] = $this->parametros;
								$retorno['output'] = $pendencia;
								$retorno['mensagem'] = "Erro ao buscar token";
								throw new Exception(json_encode($retorno), 1);
							} else {
								$pendencia['codigo'][] = $codigo_classe;
								$value->data = convertDate($value->data);
								$pendencia['id'][] = $value->id_registro;
								$pendencia['data'][] = $obj_data->format('d/m/Y');
								$pendencia['tipo_marcacao'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['TIPO_REGISTRO']["$value->classe"] . "</b>";
								$pendencia['hora_marcacao'][] = (!empty($value->hora)) ? retirarSegundos($value->hora) : returnPeriodo($value->periodo_ini, "hora");
								$pendencia['pendencia'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['CODIGO_OCORRENCIA'][$codigo_classe] . "</b>";
								$pendencia['status'][] = strtoupper($value->status);
								$pendencia['justificativa'][] = "<text style='font-size:11px'>" . $VAR_SYSTEM['CODIGO_OCORRENCIA_TOKEN'][$value->texto] . "</text/>";
								$pendencia['token'] = true;
								$pendencia['dados_token'] = $value;
								$pendencia['id_token'] = $get_token[0]->id;
							}
						}

						$feriado = json_decode($this->modelo->getOcorrencia(null, 'AL4', $obj_data->format('Y-m-d'), null, null, '3000013'));
						$new_ocorrencia = $this->obj_ponto->organizaOcorrencia($feriado);

						if ($new_ocorrencia[$obj_data->format('Y-m-d')]['A']) {
							foreach ($new_ocorrencia[$obj_data->format('Y-m-d')]['A'] as $key => $value) {
								$codigo_classe = $value->fonte . $value->tipo;
								$pendencia['codigo'][] = $codigo_classe;
								$pendencia['id'][] = $value->id;
								$pendencia['data'][] = $obj_data->format('d/m/Y');
								$pendencia['tipo_marcacao'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['CODIGO_OCORRENCIA'][$codigo_classe] . "</b>";
								$pendencia['hora_marcacao'][] = "";
								$pendencia['pendencia'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['CODIGO_OCORRENCIA'][$codigo_classe] . "</b>";
								$pendencia['status'][] = strtoupper($value->status);
								$pendencia['justificativa'][] = "<text style='font-size:11px'>" . $value->texto . "</text>";
							}
						}

						$retorno['codigo'] = 0;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = $pendencia;
						$retorno['mensagem'] = "Sucesso ao buscar pendências";
						throw new Exception(json_encode($retorno), 1);
					}
				} else {

					$data_ini = $this->parametros[1];
					$data_fim = $this->parametros[2];
					$id_usuario = $this->parametros[3];

					$pendencia['token'] = false;
					$registro = json_decode($this->modelo->getRegistro(null, $obj_data->format('Y-m-d'), null, $id_usuario));

					$new_ocorrencia = json_decode($this->modelo->getOcorrenciaIntervalo($data_ini, $data_fim, null, $id_usuario));
					$new_ocorrencia = $this->obj_ponto->organizaOcorrencia($new_ocorrencia);
					if ($new_ocorrencia[$obj_data->format('Y-m-d')]['A']) {
						foreach ($new_ocorrencia[$obj_data->format('Y-m-d')]['A'] as $key => $value) {
							$codigo_classe = $value->fonte . $value->tipo;
							$pendencia['codigo'][] = $codigo_classe;
							$pendencia['id'][] = $value->id;
							$pendencia['data'][] = $obj_data->format('d/m/Y');
							$pendencia['tipo_marcacao'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['CODIGO_OCORRENCIA'][$codigo_classe] . "</b>";
							$pendencia['hora_marcacao'][] = "";
							$pendencia['pendencia'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['CODIGO_OCORRENCIA'][$codigo_classe] . "</b>";
							$pendencia['status'][] = strtoupper($value->status);
							$pendencia['justificativa'][] = "<text style='font-size:11px'>" . $value->texto . "</text>";
						}
					}

					if ($new_ocorrencia[$obj_data->format('Y-m-d')]) {
						foreach ($new_ocorrencia[$obj_data->format('Y-m-d')] as $key => $value) {
							$codigo_classe = $value->fonte . $value->tipo;
							// MARCAÇÃO INCORRETA / MARCAÇÃO AUSENTE 
							if ($codigo_classe == "R1" || $codigo_classe == "R2") {
								$pendencia['codigo'][] = $codigo_classe;
								$pendencia['id'][] = $value->id;
								$pendencia['data'][] = $obj_data->format('d/m/Y');
								$pendencia['tipo_marcacao'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['TIPO_REGISTRO'][$value->classe] . "</b>";
								if ($codigo_classe == "R1") {
									$pendencia['hora_marcacao'][] = "<b>De:</b> " . returnPeriodo($value->periodo_ini, "hora") . " <b>Para:</b> " . retirarSegundos($value->hora);
								} else {
									$pendencia['hora_marcacao'][] = retirarSegundos($value->hora);
								}
								$pendencia['pendencia'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['CODIGO_OCORRENCIA'][$codigo_classe] . "</b>";
								$pendencia['status'][] = strtoupper($value->status);
								$pendencia['justificativa'][] = "<text style='font-size:11px'>" . $value->texto . "</text/>";
								$pendencia['token'] = true;
								$pendencia['dados_token'] = $value;
								$pendencia['id_token'] = $get_token[0]->id;
							}
						}
					}

					$token = json_decode($this->modelo->getUsuarioOcorrencia($id_usuario, null, null, null, $obj_data->format('Y-m-d'), '1', 'T'));
					if (isset($token)) {
						foreach ($token as $key => $value) {
							$obj_hora = new DateTime($value->periodo_ini);
							$codigo_classe = $value->fonte . $value->tipo;
							$pendencia['codigo'][] = $codigo_classe;
							$pendencia['id'][] = $value->id;
							$pendencia['data'][] = $obj_data->format('d/m/Y');
							$pendencia['tipo_marcacao'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['TIPO_REGISTRO']["$value->classe"] . "</b>";
							$pendencia['hora_marcacao'][] = $obj_hora->format('H:i');
							$pendencia['pendencia'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['CODIGO_OCORRENCIA'][$codigo_classe] . "</b>";
							$pendencia['status'][] = strtoupper($value->status);
							$pendencia['justificativa'][] = "<text style='font-size:11px'>" . $VAR_SYSTEM['CODIGO_OCORRENCIA_TOKEN'][$value->texto] . "</text/>";
							$pendencia['token'] = true;
							$pendencia['dados_token'] = $value;
							$pendencia['id_token'] = $get_token[0]->id;
						}
					}

					if (is_array($registro)) {
						foreach ($registro as $key => $value) {
							if ($value->tipo_marcacao == 'B01') {
								$entrada_ini = $value->tipo_marcacao;
							}
							if ($value->tipo_marcacao == "B02") {
								$saida_alm = $value->tipo_marcacao;
							}
							if ($value->tipo_marcacao == "B03") {
								$retorno_alm = $value->tipo_marcacao;
							}
							if ($value->tipo_marcacao == "B04") {
								$saida_final = $value->tipo_marcacao;
							}
							if ($value->tipo_marcacao == "B05") {
								$saida[] = $value->tipo_marcacao;
							}
							if ($value->tipo_marcacao == "B06") {
								$registro_retorno[] = $value->tipo_marcacao;
							}
							if ($value->tipo_marcacao == "B07") {
								$entrada_extra[] = $value->tipo_marcacao;
							}
							if ($value->tipo_marcacao == "B08") {
								$saida_extra[] = $value->tipo_marcacao;
							}
						}
					}

					if (
						!isset($entrada_ini) && !isset($entrada_alm) &&
						!isset($retorno_almoco) && !isset($saida_final)
					) {
						if (!isset($new_ocorrencia[$obj_data->format('Y-m-d')])) {
							$pendencia['codigo'][] = "F1";
							$pendencia['id'][] = null;
							$pendencia['data'][] = $obj_data->format('d/m/Y');
							$pendencia['tipo_marcacao'][] = "";
							$pendencia['hora_marcacao'][] = "";
							if ($this->data_hora_atual->format('Y-m-d') == $obj_data->format('Y-m-d')) {
								$pendencia['pendencia'][] = "";
								$pendencia['status'][] = "";
							} else {
								$pendencia['pendencia'][] = "FALTA";
								$pendencia['status'][] = "FALTA";
							}
							$pendencia['justificativa'][] = "";
						}
					} else {
						if (
							$obj_data->format('Y-m-d') < $this->data_hora_atual->format('Y-m-d')
							&& isset($entrada_ini)
						) {
							if (!isset($saida_alm)) {
								$pendencia['codigo'][] = "R2";
								$ocorrencia_b2 = json_decode($this->modelo->getOcorrencia(null, 'B02', $obj_data->format('Y-m-d'), '2', null, $id_usuario));
								if (!isset($ocorrencia_b2)) {
									$pendencia['id'][] = null;
									$pendencia['data'][] = $obj_data->format('d/m/Y');
									$pendencia['tipo_marcacao'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['TIPO_REGISTRO']['B02'] . "</b>";
									$pendencia['hora_marcacao'][] = "";
									$pendencia['pendencia'][] = "<b style='font-size:11px'>Ausência de batida: " . $VAR_SYSTEM['TIPO_REGISTRO']['B02'] . "</b>";
									$pendencia['status'][] = (isset($ocorrencia)) ? strtoupper($ocorrencia[0]->status) : "PENDENTE";
									$pendencia['justificativa'][] = "<text style='font-size:11px'>" . $ocorrencia[0]->texto . "</text>";
								}
							}
							if (!isset($retorno_alm)) {
								$pendencia['codigo'][] = "R2";
								$ocorrencia_b3 = json_decode($this->modelo->getOcorrencia(null, 'B03', $obj_data->format('Y-m-d'), '2', null, $id_usuario));
								if (!isset($ocorrencia_b3)) {
									$pendencia['id'][] = null;
									$pendencia['data'][] = $obj_data->format('d/m/Y');
									$pendencia['tipo_marcacao'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['TIPO_REGISTRO']['B03'] . "</b>";
									$pendencia['hora_marcacao'][] = "";
									$pendencia['pendencia'][] = "<b style='font-size:11px'>Ausência de batida: " . $VAR_SYSTEM['TIPO_REGISTRO']['B03'] . "</b>";
									$pendencia['status'][] = (isset($ocorrencia)) ? strtoupper($ocorrencia[0]->status) : "PENDENTE";
									$pendencia['justificativa'][] = "<text style='font-size:11px'>" . $ocorrencia[0]->texto . "</text>";
								}
							}
							if (!isset($saida_final)) {
								$pendencia['codigo'][] = "R2";
								$ocorrencia_b4 = json_decode($this->modelo->getOcorrencia(null, 'B04', $obj_data->format('Y-m-d'), '2', null, $id_usuario));
								if (!isset($ocorrencia_b4)) {
									$pendencia['id'][] = null;
									$pendencia['data'][] = $obj_data->format('d/m/Y');
									$pendencia['tipo_marcacao'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['TIPO_REGISTRO']['B04'] . "</b>";
									$pendencia['hora_marcacao'][] = "";
									$pendencia['pendencia'][] = "<b style='font-size:11px'>Ausência de batida: " . $VAR_SYSTEM['TIPO_REGISTRO']['B04'] . "</b>";
									$pendencia['status'][] = (isset($ocorrencia)) ? strtoupper($ocorrencia[0]->status) : "PENDENTE";
									$pendencia['justificativa'][] = "<text style='font-size:11px'>" . $ocorrencia[0]->texto . "</text>";
								}
							}
							if (isset($saida) && count($saida) > count($registro_retorno)) {
								$pendencia['codigo'][] = "R2";
								$ocorrencia_b6 = json_decode($this->modelo->getOcorrencia(null, 'B06', $obj_data->format('Y-m-d'), '2', null, $id_usuario));
								if (!isset($ocorrencia_b6)) {
									$pendencia['id'][] = null;
									$pendencia['data'][] = $obj_data->format('d/m/Y');
									$pendencia['tipo_marcacao'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['TIPO_REGISTRO']['B06'] . "</b>";
									$pendencia['hora_marcacao'][] = "";
									$pendencia['pendencia'][] = "<b style='font-size:11px'>Ausência de batida: " . $VAR_SYSTEM['TIPO_REGISTRO']['B06'] . "</b>";
									$pendencia['status'][] = (isset($ocorrencia)) ? strtoupper($ocorrencia[0]->status) : "PENDENTE";
									$pendencia['justificativa'][] = "<text style='font-size:11px'>" . $ocorrencia[0]->texto . "</text>";
								}
							}
							if (isset($entrada_extra) && count($entrada_extra) > count($saida_extra)) {
								$ocorrencia_b8 = json_decode($this->modelo->getOcorrencia(null, 'B08', $obj_data->format('Y-m-d'), '2', null, $id_usuario));
								if (!isset($ocorrencia_b8)) {
									//PROCURO SE O REGISTRO DE SAIDA EXTRA NÃO FOI NO DIA POSTERIOR
									$data2 = $obj_data->modify('+1 day');
									$ocorrencia_b8_2 = json_decode($this->modelo->getOcorrencia(null, 'B08', $data2->format('Y-m-d'), '2', null, $id_usuario));
									if (isset($ocorrencia_b8_2) && !empty($ocorrencia_b8_2)) {
										$pendencia['codigo'][] = "R2";
										$pendencia['id'][] = null;
										$pendencia['data'][] = $obj_data->format('d/m/Y');
										$pendencia['tipo_marcacao'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['TIPO_REGISTRO']['B08'] . "</b>";
										$pendencia['hora_marcacao'][] = "";
										$pendencia['pendencia'][] = "<b style='font-size:11px'>Ausência de batida: " . $VAR_SYSTEM['TIPO_REGISTRO']['B08'] . "</b>";
										$pendencia['status'][] = (isset($ocorrencia)) ? strtoupper($ocorrencia[0]->status) : "PENDENTE";
										$pendencia['justificativa'][] = "<text style='font-size:11px'>" . $ocorrencia[0]->texto . "</text>";
									}
								}
							}
						}

						$ocorrencia_comprovante = json_decode($this->modelo->getOcorrencia(null, 'AA3', $obj_data->format('Y-m-d'), null, null, $id_usuario));
						if (isset($ocorrencia_comprovante)) {
							foreach ($ocorrencia_comprovante as $key => $value) {
								$codigo_classe = $value->fonte . $value->tipo;
								$pendencia['codigo'][] = $codigo_classe;
								$explode_periodo_ini = explode(" ", $value->periodo_ini);
								$explode_hora_ini = explode(":", $explode_periodo_ini[1]);
								$hora_ini = $explode_hora_ini[0] . ":" . $explode_hora_ini[1];
								$explode_periodo_fim = explode(" ", $value->periodo_fim);
								$explode_hora_fim = explode(":", $explode_periodo_fim[1]);
								$hora_fim = $explode_hora_fim[0] . ":" . $explode_hora_fim[1];
								$pendencia['id'][] = $value->id;
								$pendencia['data'][] = $obj_data->format('d/m/Y');
								$pendencia['tipo_marcacao'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['CODIGO_OCORRENCIA'][$codigo_classe] . "</b>";
								$pendencia['hora_marcacao'][] = $hora_ini . " às " . $hora_fim;
								$pendencia['pendencia'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['CODIGO_OCORRENCIA'][$codigo_classe] . "</b>";
								$pendencia['status'][] = strtoupper($value->status);
								$pendencia['justificativa'][] = "<text style='font-size:11px'>" . $value->texto . "</text>";
							}
						}
					}

					$ocorrencia = json_decode($this->modelo->getOcorrencia(null, null, $obj_data->format('Y-m-d'), null, null, $id_usuario));
					if (isset($ocorrencia) && is_array($ocorrencia)) {
						foreach ($ocorrencia as $key => $value) {
							$codigo_classe = $value->fonte . $value->tipo;
							if ($codigo_classe == "A10" || $codigo_classe == "A9") {
								if ($codigo_classe == "A9") {
									$explode_periodo_ini = explode(" ", $value->periodo_ini);
									$explode_periodo_fim = explode(" ", $value->periodo_fim);
									$pendencia['hora_marcacao'][] = retirarSegundos($explode_periodo_ini[1]) . " às " . retirarSegundos($explode_periodo_fim[1]);
								} else {
									$pendencia['hora_marcacao'][] = "";
								}
								$pendencia['codigo'][] = $codigo_classe;
								$pendencia['id'][] = $value->id;
								$pendencia['data'][] = $obj_data->format('d/m/Y');
								$pendencia['tipo_marcacao'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['CODIGO_OCORRENCIA']["$codigo_classe"] . "</b>";

								$pendencia['pendencia'][] = "<b style='font-size:11px'>" . $VAR_SYSTEM['CODIGO_OCORRENCIA']["$codigo_classe"] . "</b>";
								$pendencia['status'][] = strtoupper($value->status);
								$pendencia['justificativa'][] = "<text style='font-size:11px'>" . $value->texto . "</text>";
							}
						}
					}
					if (!isset($pendencia['data'])) {
						$pendencia['codigo'][] = null;
						$pendencia['id'][] = null;
						$pendencia['data'][] = $obj_data->format('d/m/Y');
						$pendencia['tipo_marcacao'][] = "";
						$pendencia['hora_marcacao'][] = "";
						$pendencia['pendencia'][] = 'SEM PENDÊNCIA';
						$pendencia['status'][] = '';
						$pendencia['justificativa'][] = "";
					}
					if ($pendencia) {
						$retorno['codigo'] = 0;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = $pendencia;
						$retorno['mensagem'] = "Sucesso ao buscar pendências";
						throw new Exception(json_encode($retorno), 1);
					}
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function justificar(){
			include 'config_extras.php';
			error_reporting(E_ALL);
			ini_set("display_errors", 1);
			try {
				if (isset($_POST['tipo_lancamento']) && !empty($_POST['tipo_lancamento'])) {
					$this->modelo->setTable('rh_lancamentos');
					switch ($_POST['tipo_lancamento']) {
						case 'F01':
							if (!isset($_POST['valido_ate']) || empty($_POST['valido_ate'])) {
								$param['valido_ate'] = '2050-01-01';
							}
							if (
								!isset($_POST['tipo_lancamento']) ||
								!isset($_POST['titulo_feriado']) ||
								!isset($_POST['dia_feriado']) ||
								!isset($_POST['mes_feriado']) ||
								!isset($_POST['frequencia_feriado']) ||
								empty($_POST['tipo_lancamento']) ||
								empty($_POST['titulo_feriado']) ||
								empty($_POST['dia_feriado']) ||
								empty($_POST['mes_feriado']) ||
								empty($_POST['frequencia_feriado'])
							) {
								$retorno["codigo"] = 1;
								$retorno["input"] = $_POST;
								$retorno["output"] = null;
								$retorno["mensagem"] = "Preencha todos os campos";
								throw new Exception(json_encode($retorno), 1);
							}

							$param['tipo'] = $_POST['tipo_lancamento'];
							$param['titulo'] = $_POST['titulo_feriado'];
							$param['dia'] = $_POST['dia_feriado'];
							$param['mes'] = $_POST['mes_feriado'];
							$param['frequencia'] = $_POST['frequencia_feriado'];
							$param['status'] = 'a';
							$save = $this->modelo->save($param);
							if ($save) {
								$retorno["codigo"] = 0;
								$retorno["input"] = $_POST;
								$retorno["output"] = $save;
								$retorno["mensagem"] = "Sucesso";
								throw new Exception(json_encode($retorno), 1);
							} else {
								$retorno["codigo"] = 1;
								$retorno["input"] = $_POST;
								$retorno["output"] = $this->modelo->info;
								$retorno["mensagem"] = "Erro ao salvar feriado";
								throw new Exception(json_encode($retorno), 1);
							}
							break;
						case 'S01':
							if (
								!isset($_POST['tipo_lancamento']) ||
								!isset($_POST['operacao']) ||
								!isset($_POST['horas_saldo']) ||
								!isset($_POST['funcionario']) ||
								!isset($_POST['frequencia_feriado']) ||
								empty($_POST['tipo_lancamento']) ||
								empty($_POST['operacao']) ||
								empty($_POST['horas_saldo']) ||
								empty($_POST['funcionario']) ||
								empty($_POST['frequencia_feriado'])
							) {
								$retorno["codigo"] = 1;
								$retorno["input"] = $_POST;
								$retorno["output"] = null;
								$retorno["mensagem"] = "Preencha todos os campos";
								throw new Exception(json_encode($retorno), 1);
							}

							$param['tipo'] = $_POST['tipo_lancamento'];
							$param['operacao'] = $_POST['operacao'];
							$param['valor'] = convertHorasMinutos($_POST['horas_saldo'], 'hora>decimal', false);
							$param['id_usuario'] = $_POST['funcionario'];
							$param['status'] = 'a';
							$save = $this->modelo->save($param);
							if ($save) {
								$retorno["codigo"] = 0;
								$retorno["input"] = $_POST;
								$retorno["output"] = $save;
								$retorno["mensagem"] = "Sucesso";
								throw new Exception(json_encode($retorno), 1);
							} else {
								$retorno["codigo"] = 1;
								$retorno["input"] = $_POST;
								$retorno["output"] = $this->modelo->info;
								$retorno["mensagem"] = "Erro ao salvar feriado";
								throw new Exception(json_encode($retorno), 1);
							}

							break;
						default:
							# code...
							break;
					}
				} else {
					if (isset($_POST['funcionario']) && !empty($_POST['funcionario'])) {
						$id_usuario = $_POST['funcionario'];
					} elseif (isset($this->parametros[0]) && !empty($this->parametros[0])) {
						$id_usuario = $this->parametros[0];
					} else {
						if ($_POST['tipo_ocorrencia'] != "AL4") {
							$retorno["codigo"] = 1;
							$retorno["input"] = $_POST;
							$retorno["output"] = $this->modelo->info;
							$retorno["mensagem"] = "Usuario nao informado.";
							throw new Exception(json_encode($retorno), 1);
						}
					}

					$usuario = json_decode($this->modelo->getUsuarios($id_usuario));
					if (!isset($usuario[0]->cpf) || empty($usuario[0]->cpf)) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $_POST;
						$retorno["output"] = $this->modelo->info;
						$retorno["mensagem"] = "Usuário não cadatrado, entre em contato com a Administração.";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$boss = json_decode($this->modelo->getUsuarios($usuario[0]->boss));
						if (!isset($boss) || empty($boss)) {
							$retorno["codigo"] = 1;
							$retorno["input"] = $_POST;
							$retorno["output"] = $this->modelo->info;
							$retorno["mensagem"] = "Boss do usuário não encontrado.";
							throw new Exception(json_encode($retorno), 1);
						}
					}

					if ((!isset($_POST['tipo_ocorrencia']) || empty($_POST['tipo_ocorrencia']))) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $_POST;
						$retorno["output"] = $this->modelo->info;
						$retorno["mensagem"] = "Selecione um tipo de justificativa.";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$tipo_ocorrencia = $_POST['tipo_ocorrencia'];
					}

					$this->obj_ponto = new RhPonto($this, $id_usuario);
					$this->obj_ponto->verificacoes($tipo_ocorrencia, $_POST, $_FILES, $id_usuario);
					$insert = $this->obj_ponto->justificar($tipo_ocorrencia, $_POST, $id_usuario);
					switch ($tipo_ocorrencia) {
						// ATESTADO / COMPROVANTE / COMPARECIMENTO JUDICIAL / DOACAO DE SANGUE / TROCA DE FOLGA / PERCURSO
						case 'AA2':
						case 'AA3':
						case 'AA15':
						case 'AA18':
						case 'D3':
						case 'AA4':
							$this->modelo->setTable('rh_jornada_ocorrencia');
							$save = $this->modelo->save($insert);
							if (!$save) {
								$retorno["codigo"] = 1;
								$retorno["input"] = $_POST;
								$retorno["output"] = $this->modelo->info;
								$retorno["mensagem"] = "Erro ao salvar justificativa!";
								throw new Exception(json_encode($retorno), 1);
							}


							if (isset($_FILES) && !empty($_FILES['name_upload_arquivo']['name']) && $_FILES['name_upload_arquivo']['size'] > 0) {
								$retorno_ged = json_decode($this->insertUploadGed($_FILES, $tipo_ocorrencia, $usuario, $insert, $save));
								if ($retorno_ged->codigo != 0) {
									$retorno["codigo"] = 1;
									$retorno["input"] = $retorno_ged->input;
									$retorno["output"] = $retorno_ged->output;
									$retorno["mensagem"] = $retorno_ged->mensagem;
									throw new Exception(json_encode($retorno), 1);
								}
							}

							$ocorrencia = [
								'id' => $save,
								'tipo' => $VAR_SYSTEM['CODIGO_OCORRENCIA'][$tipo_ocorrencia],
								'data' => ($tipo_ocorrencia == "AA2") ? convertDate(returnPeriodo($insert['periodo_ini'])) . " até: " . convertDate(returnPeriodo($insert['periodo_fim'])) : convertDate($insert['data']),
							];

							if (TIPO_AMBIENTE == 'producao') {
								$tipo = 'copia_adm';
							}
							$retorno_token = $this->obj_ponto->enviarNotificacao($tipo, $usuario, $ocorrencia);
							if ($retorno_token->codigo == 1) {
								$retorno['codigo'] = 1;
								$retorno['input'] = $ocorrencia;
								$retorno['output'] = $retorno_token;
								$retorno['mensagem'] = $retorno_token->mensagem;
								throw new Exception(json_encode($retorno));
							} else {
								$retorno['codigo'] = 0;
								$retorno['input'] = $ocorrencia;
								$retorno['output'] = $insert;
								$retorno['mensagem'] = $retorno_token->mensagem;
								throw new Exception(json_encode($retorno));
							}

							break;
						// LICENÇAS: MATERNIDADE / OBITO / NASCIMENTO / CASAMENTO / PATERNIDADE / AMAMENTAÇÃO // AFASTAMENTO INSS // FESTA FIM DE ANO // JOGO DA COPA// ELEIÇÃO
						case 'AA7':
						case 'AA8':
						case 'AA9':
						case 'AA10':
						case 'AA11':
						case 'AA12':
						case 'AA13':
						case 'AA14':
						case 'AA16':
						case 'AA17':
							$this->modelo->setTable('rh_jornada_ocorrencia');
							$save = $this->modelo->save($insert);
							if (!$save) {
								$retorno["codigo"] = 1;
								$retorno["input"] = $_POST;
								$retorno["output"] = $this->modelo->info;
								$retorno["mensagem"] = "Erro ao salvar justificativa!";
								throw new Exception(json_encode($retorno), 1);
							}



							if (isset($_FILES) && !empty($_FILES['name_upload_arquivo']['name']) && $_FILES['name_upload_arquivo']['size'] > 0) {
								$retorno_ged = json_decode($this->insertUploadGed($_FILES, $tipo_ocorrencia, $usuario, $insert, $save));
								if ($retorno_ged->codigo != 0) {
									$retorno["codigo"] = 1;
									$retorno["input"] = $retorno_ged->input;
									$retorno["output"] = $retorno_ged->output;
									$retorno["mensagem"] = $retorno_ged->mensagem;
									throw new Exception(json_encode($retorno), 1);
								}
							}

							$ocorrencia = [
								'id' => $save,
								'tipo' => $VAR_SYSTEM['CODIGO_OCORRENCIA'][$tipo_ocorrencia],
								'data' => ($tipo_ocorrencia == "AA2") ? convertDate(returnPeriodo($insert['periodo_ini'])) . " até: " . convertDate(returnPeriodo($insert['periodo_fim'])) : convertDate($insert['data']),
							];

							if (TIPO_AMBIENTE == 'producao') {
								$tipo = 'copia_adm';
							}
							$retorno_token = $this->obj_ponto->enviarNotificacao($tipo, $usuario, $ocorrencia);
							if ($retorno_token->codigo == 1) {
								$retorno['codigo'] = 1;
								$retorno['input'] = $ocorrencia;
								$retorno['output'] = $retorno_token;
								$retorno['mensagem'] = $retorno_token->mensagem;
								throw new Exception(json_encode($retorno));
							} else {
								$retorno['codigo'] = 0;
								$retorno['input'] = $ocorrencia;
								$retorno['output'] = $insert;
								$retorno['mensagem'] = $retorno_token->mensagem;
								throw new Exception(json_encode($retorno));
							}

							break;
						// REUNIÃO EXTERNA / VIAGEM / AUSENCIA JUSTIFICADA / FOLGA / CURSO			
						case 'A10':
						case 'A7':
						case 'A5':
						case 'AA5':
						case 'AA6':
						case 'AA19':

							$this->modelo->setTable('rh_jornada_ocorrencia');
							$save = $this->modelo->save($insert);
							if (!$save) {
								$retorno["codigo"] = 1;
								$retorno["input"] = $_POST;
								$retorno["output"] = $this->modelo->info;
								$retorno["mensagem"] = "Erro ao salvar justificativa!";
								throw new Exception(json_encode($retorno), 1);
							}

							if (isset($_FILES) && !empty($_FILES['name_upload_arquivo']['name']) && $_FILES['name_upload_arquivo']['size'] > 0) {
								$retorno_ged = json_decode($this->insertUploadGed($_FILES, $tipo_ocorrencia, $usuario, $insert, $save));
								if ($retorno_ged->codigo != 0) {
									$retorno["codigo"] = 1;
									$retorno["input"] = $retorno_ged->input;
									$retorno["output"] = $retorno_ged->output;
									$retorno["mensagem"] = $retorno_ged->mensagem;
									throw new Exception(json_encode($retorno), 1);
								}
							}

							$insert_token = $this->obj_ponto->dadosToken($save, $usuario[0]);
							$this->modelo->setTable('rh_token');
							$save_token = $this->modelo->save($insert_token);

							if (!$save_token) {
								$retorno["codigo"] = 1;
								$retorno["input"] = $_POST;
								$retorno["output"] = $this->modelo->info;
								$retorno["mensagem"] = "Erro ao salvar token!";
								throw new Exception(json_encode($retorno), 1);
							}

							$ocorrencia = [
								'id' => $save,
								'tipo' => $VAR_SYSTEM['CODIGO_OCORRENCIA'][$tipo_ocorrencia],
								'data' => convertDate(returnPeriodo($insert['periodo_ini'])) . " até: " . convertDate(returnPeriodo($insert['periodo_fim'])),
								'email_boss' => $boss[0]->email,
								'id_slack' => $boss[0]->id_slack,
								'token' => $insert_token['token'],
							];

							$retorno_token = $this->obj_ponto->enviarNotificacao(null, $usuario, $ocorrencia);
							if ($retorno_token->codigo == 1) {
								$retorno['codigo'] = 1;
								$retorno['input'] = $ocorrencia;
								$retorno['output'] = $retorno_token;
								$retorno['mensagem'] = $retorno_token->mensagem;
								throw new Exception(json_encode($retorno));
							} else {
								$retorno['codigo'] = 0;
								$retorno['input'] = $ocorrencia;
								$retorno['output'] = $insert;
								$retorno['mensagem'] = $retorno_token->mensagem;
								throw new Exception(json_encode($retorno));
							}
							break;
						//MARCAÇÃO EXTRA	
						case 'A9':
							$this->modelo->setTable('rh_jornada_ocorrencia');
							$save = $this->modelo->save($insert);
							if (!$save) {
								$retorno["codigo"] = 1;
								$retorno["input"] = $_POST;
								$retorno["output"] = $this->modelo->info;
								$retorno["mensagem"] = "Erro ao salvar justificativa!";
								throw new Exception(json_encode($retorno), 1);
							}

							$insert_token = $this->obj_ponto->dadosToken($save, $usuario[0]);

							$this->modelo->setTable('rh_token');
							$save_token = $this->modelo->save($insert_token);

							if (!$save_token) {
								$retorno["codigo"] = 1;
								$retorno["input"] = $_POST;
								$retorno["output"] = $this->modelo->info;
								$retorno["mensagem"] = "Erro ao salvar token!";
								throw new Exception(json_encode($retorno), 1);
							}

							$ocorrencia = [
								'id' => $save,
								'tipo' => $VAR_SYSTEM['CODIGO_OCORRENCIA'][$tipo_ocorrencia],
								'data' => convertDate(returnPeriodo($insert['periodo_ini'])),
								'email_boss' => $boss[0]->email,
								'id_slack' => $boss[0]->id_slack,
								'token' => $insert_token['token'],
							];

							$retorno_token = $this->obj_ponto->enviarNotificacao(null, $usuario, $ocorrencia);

							if ($retorno_token->codigo == 1) {
								$retorno['codigo'] = 1;
								$retorno['input'] = $ocorrencia;
								$retorno['output'] = $retorno_token;
								$retorno['mensagem'] = $retorno_token->mensagem;
								throw new Exception(json_encode($retorno));
							} else {
								$retorno['codigo'] = 0;
								$retorno['input'] = $ocorrencia;
								$retorno['output'] = $insert;
								$retorno['mensagem'] = $retorno_token->mensagem;
								throw new Exception(json_encode($retorno));
							}

							break;
						// FERIAS / FERIADO
						case 'AL1':
						case 'AL4':
							$this->modelo->setTable('rh_jornada_ocorrencia');
							$save = $this->modelo->save($insert);
							if (!$save) {
								$retorno["codigo"] = 1;
								$retorno["input"] = $_POST;
								$retorno["output"] = $this->modelo->info;
								$retorno["mensagem"] = "Erro ao salvar justificativa!";
								throw new Exception(json_encode($retorno), 1);
							} else {
								$retorno["codigo"] = 0;
								$retorno["input"] = $_POST;
								$retorno["output"] = $insert;
								$retorno["mensagem"] = "Sucesso salvar justificativa!";
								throw new Exception(json_encode($retorno), 1);
							}
							break;
						//ERRO SISTEMA.
						case 'A8':
							$this->modelo->setTable('rh_jornada_ocorrencia');
							$save = $this->modelo->save($insert);
							if (!$save) {
								$retorno["codigo"] = 1;
								$retorno["input"] = $_POST;
								$retorno["output"] = $this->modelo->info;
								$retorno["mensagem"] = "Erro ao salvar justificativa!";
								throw new Exception(json_encode($retorno), 1);
							} else {

								$ocorrencia = [
									'id' => $save,
									'tipo' => $VAR_SYSTEM['CODIGO_OCORRENCIA'][$tipo_ocorrencia],
									'data' => convertDate(returnPeriodo($insert['periodo_ini'])),
								];

								$retorno_token = $this->obj_ponto->enviarNotificacao('alerta', $usuario, $ocorrencia);

								$retorno["codigo"] = 0;
								$retorno["input"] = $_POST;
								$retorno["output"] = $insert;
								$retorno["mensagem"] = "Sucesso salvar justificativa!";
								throw new Exception(json_encode($retorno), 1);
							}
							break;
						case 'A11':
							$this->modelo->setTable('rh_jornada_ocorrencia');
							$save = $this->modelo->save($insert);
							if (!$save) {
								$retorno["codigo"] = 1;
								$retorno["input"] = $_POST;
								$retorno["output"] = $this->modelo->info;
								$retorno["mensagem"] = "Erro ao salvar justificativa!";
								throw new Exception(json_encode($retorno), 1);
							} else {
								$retorno["codigo"] = 0;
								$retorno["input"] = $_POST;
								$retorno["output"] = $insert;
								$retorno["mensagem"] = "Sucesso!";
								throw new Exception(json_encode($retorno), 1);
							}
							break;
						default:
							$retorno["codigo"] = 1;
							$retorno["input"] = $_POST;
							$retorno["output"] = null;
							$retorno["mensagem"] = "Ocorrência invalida 1";
							throw new Exception(json_encode($retorno), 1);
							break;
					}
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function espelhoMarcacaoDoDia(){
			include "config_extras.php";
			$dicionario_alerta = $VAR_SYSTEM['ALERTAS'];
			$lista_usuarios = json_decode($this->modelo->getUsuarios());
			$get_departamento = json_decode($this->modelo->getUsuariosAtivos(null, null, true));
			$boss = json_decode($this->modelo->getBoss());
			if (isset($_POST['data'])) {
				$data = getDataAtual($_POST['data']);
			} else {
				$data = getDataAtual();
				$data->modify('-1 day');
			}

			if (isset($_POST['id_usuario']) && !empty($_POST['id_usuario'])) {
				$id_usuario = $_POST['id_usuario'];
				$id_usuario_alerta = $_POST['id_usuario'];
				$get_user = json_decode($this->modelo->getUser($id_usuario));
			} else {
				$id_usuario = null;
				$id_usuario_alerta = 0;
			}

			if (isset($_POST['id_boss']) && !empty($_POST['id_boss'])) {
				$id_boss = $_POST['id_boss'];
				$id_boss_alerta = $_POST['id_boss'];
				$get_boss = json_decode($this->modelo->getUser($id_boss));
			} else {
				$id_boss = null;
				$id_boss_alerta = 0;
			}

			if (isset($_POST['departamento']) && !empty($_POST['departamento'])) {
				$departamento = strtolower($_POST['departamento']);
				$departamento_alerta = strtolower($_POST['departamento']);
			} else {
				$departamento = null;
				$departamento_alerta = null;
			}

			$dt = $data->format('Y-m-d');
			$week = primeiroUltimoDiaSemana($dt);
			$week_ini = $week['first_week'];
			$week_fim = $week['last_week'];


			//BANCO	
			$banco = $this->bancoHoras($dt, $id_usuario, $id_boss, $departamento);
			//END BANCO

			if (isset($id_usuario_alerta) && $id_usuario_alerta != 0) {
				$alerta = json_decode($this->modelo->getAlertas("ponto", null, $data->format('Y-m-d'), $id_usuario_alerta));
			} else {
				$alerta = json_decode($this->modelo->getAlertas("ponto", null, $data->format('Y-m-d'), $id_usuario_alerta, $id_boss_alerta, $departamento_alerta));
			}

			if (isset($alerta) && !empty($alerta)) {
				foreach ($alerta as $key => $value) {
					$data_ex = explode(" ", $value->data_hora);
					$alertas[$value->grupo] = convertDate($data_ex[0]) . " " . $data_ex[1];
				}
			}

			require_once ABSPATH . '/views/' . $this->nome_view . '/marcacao-dia-view.php';
		}

		//BY CAIO FREITAS - 18/01/2022
		function insertUploadGed($files, $tipo_ocorrencia, $usuario, $insert, $id_origem){
			try {
				include 'config_extras.php';
				$upload_ged = $this->obj_ponto->uploadGed($files, strtolower($VAR_SYSTEM['CODIGO_OCORRENCIA'][$tipo_ocorrencia]), $usuario);
				if ($upload_ged['codigo'] == 1) {
					$retorno["codigo"] = 1;
					$retorno["input"] = $_POST;
					$retorno["output"] = $upload_ged;
					$retorno["mensagem"] = $upload_ged['mensagem'];
					throw new Exception(json_encode($retorno), 1);
				}

				$insert_ged_documento = [
					'nome_documento' => $upload_ged['output'],
					'data_documento' => $insert['data_lancamento'],
					'doc_origem' => 'pessoal',
					'id_origem' => $id_origem,
					'produto' => null,
					'tipo' => 'ponto',
					'subtipo' => 'ocorrencia',
					'descricao' => $insert['texto'],
					'owner' => $id_usuario,
					'data_criacao' => $this->data_hora_atual->format('Y-m-d H:i:s'),
				];

				$this->modelo->setTable('ged_documento');
				$save_ged_documento = $this->modelo->save($insert_ged_documento);
				if (!$save_ged_documento) {
					$retorno["codigo"] = 1;
					$retorno["input"] = $_POST;
					$retorno["output"] = $this->modelo->info;
					$retorno["mensagem"] = "Erro em salvar na tabela ged_documento.";
					throw new Exception(json_encode($retorno), 1);
				} else {

					$ged_documento = json_decode($this->modelo->gedDocumento($save, 'ponto'));
					$path_documento = GED_PONTO . $usuario[0]->cpf . DS . $upload_ged['output'];
					$hash_arquivo = hash_file('md5', $path_documento);

					$insert_ged_anexo = [
						'id_documento' => $save_ged_documento,
						'nome_amigavel' => $upload_ged['output'],
						'path_root' => GED_PONTO,
						'path_objeto' => DS . $usuario[0]->cpf . DS,
						'nome_hash' => $upload_ged['output'],
						'hash_arquivo' => $hash_arquivo,
						'data_criacao' => $this->data_hora_atual->format('Y-m-d H:i:s'),
					];

					$this->modelo->setTable('ged_anexo');
					$save_ged_anexo = $this->modelo->save($insert_ged_anexo);
					if (!$save_ged_anexo) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $insert_ged_anexo;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = 'Erro ao salvar no ged_anexo';
						throw new Exception(json_encode($retorno));
					}
				}
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function demaisbatidas(){
			try {
				include "config_extras.php";

				if (isset($_POST['id_funcionario']) && !empty($_POST['id_funcionario'])) {
					$id_usuario = $_POST['id_funcionario'];
				} else {
					$retorno["codigo"] = 1;
					$retorno["input"] = null;
					$retorno["output"] = $regua;
					$retorno["mensagem"] = "Selecione o colaborador!";
					throw new Exception(json_encode($retorno), 1);
				}

				if (
					(!isset($this->parametros[0]) || empty($this->parametros[0])) &&
					(!isset($this->parametros[1]) || empty($this->parametros[1])) &&
					(!isset($this->parametros[2]) || empty($this->parametros[2]))
				) {
					$retorno["codigo"] = 1;
					$retorno["input"] = $demais_registros;
					$retorno["output"] = $regua;
					$retorno["mensagem"] = "Erro, sem parametros!";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$data = $this->parametros[2] . "-" . $this->parametros[1] . "-" . $this->parametros[0];
				}


				$get_demais_batidas = json_decode($this->modelo->getRegistro(null, $data, null, $id_usuario));
				if (!isset($get_demais_batidas)) {
					$retorno["codigo"] = 1;
					$retorno["input"] = $demais_registros;
					$retorno["output"] = $regua;
					$retorno["mensagem"] = "Erro em demais batidas.";
					throw new Exception(json_encode($retorno), 1);
				}

				$ocorrencia_demais_batidas = json_decode($this->modelo->getOcorrencia(null, null, $data, null, 'aprovado', $id_usuario));

				$demais_registros = $this->obj_ponto->organizaDemaisBatidas($data, $id_usuario, $ocorrencia_demais_batidas, $get_demais_batidas);

				if (isset($demais_registros)) {
					$retorno["codigo"] = 0;
					$retorno["input"] = $demais_registros;
					$retorno["output"] = $regua;
					$retorno["mensagem"] = "Sucesso!";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno["codigo"] = 1;
					$retorno["input"] = $demais_registros;
					$retorno["output"] = $regua;
					$retorno["mensagem"] = "Erro!";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function getComprovante(){
			try {
				$data = $this->parametros[2] . '-' . $this->parametros[1] . '-' . $this->parametros[0];
				$tipo = strtolower($this->parametros[3]);
				$comprovante = json_decode($this->modelo->getOcorrencia(null, 'AA3', $data));

				if (is_array($comprovante)) {
					foreach ($comprovante as $key => $value) {
						$periodo_ini[$value->id] = explode(" ", $value->periodo_ini);
						$periodo_fim[$value->id] = explode(" ", $value->periodo_fim);

						$dados['data'][] = $value->data;
						$dados['saida'][] = $periodo_ini[$value->id][1];
						$dados['retorno'][] = $periodo_fim[$value->id][1];
						$dados['status'][] = strtoupper($value->status);

						$obj_periodo_inicio = new DateTime($periodo_ini[$value->id][1]);
						$obj_periodo_fim = new DateTime($periodo_fim[$value->id][1]);
						$periodo = $obj_periodo_inicio->diff($obj_periodo_fim);

						if ($periodo->h < 10) {
							$hora = "0" . $periodo->h;
						} else {
							$hora = $periodo->h;
						}

						if ($periodo->i < 10) {
							$minuto = "0" . $periodo->i;
						} else {
							$minuto = $periodo->i;
						}

						if ($periodo->s < 10) {
							$segundo = "0" . $periodo->s;
						} else {
							$segundo = $periodo->s;
						}

						$dados['periodo'][] = $hora . ":" . $minuto . ":" . $segundo;
					}
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $data;
					$retorno['output'] = $dados;
					$retorno['mensagem'] = "Erro";
					throw new Exception(json_encode($retorno), 1);
				}

				if ($comprovante) {
					$retorno['codigo'] = 0;
					$retorno['input'] = $data;
					$retorno['output'] = $dados;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $data;
					$retorno['output'] = $dados;
					$retorno['mensagem'] = "Erro";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function correcaoView()
		{
			include 'config_extras.php';
			try {
				$session = json_decode($_SESSION['cmswerp']['userdata']->permissoes);
				$permissoes = json_decode($this->cl_permissoes->checkPermissoes('correcaoView', 'metodo'));
				if (!$permissoes) {
					$retorno['codigo'] = 1;
					$retorno['input'] = 'espelhoView';
					$retorno['output'] = $permissoes;
					$retorno['mensagem'] = "Permissoes não encontradas para esta ação!";
					throw new Exception(json_encode($retorno), 1);
				} elseif ($permissoes->codigo != 0) {
					$retorno['codigo'] = 1;
					$retorno['input'] = 'espelhoView';
					$retorno['output'] = $permissoes;
					$retorno['mensagem'] = $permissoes->mensagem;
					throw new Exception(json_encode($retorno), 1);
				} elseif (isset($permissoes->output->permissoes) && $permissoes->output->permissoes < 1) {
					$retorno['codigo'] = 1;
					$retorno['input'] = 'espelhoView';
					$retorno['output'] = $permissoes;
					$retorno['mensagem'] = 'Você não tem acesso a este recurso!';
					throw new Exception(json_encode($retorno), 1);
				}

				// definindo permissoes do listview
				if ($permissoes->output == "master") {
					$lista_usuarios = json_decode($this->modelo->getUsuarios());
				} else {
					switch ($permissoes->output->alcadas) {
						case '2':
							$lista_usuarios = json_decode($this->modelo->getUsuarios(null, $_SESSION['cmswerp']['userdata']->id));
							$alcada = $permissoes->output->alcadas;
							break;
						case '4':
							$lista_usuarios = json_decode($this->modelo->getUsuarios());
							$alcada = $permissoes->output->alcadas;
							break;
						default:
							$lista_usuarios = json_decode($this->modelo->getUsuarios($_SESSION['cmswerp']['userdata']->id));
							$alcada = $permissoes->output->alcadas;
							break;
					}
				}

				$hoje = getDataAtual();
				$hoje = getDataAtual();
				if (isset($_POST['data_de']) && !empty($_POST['data_de'])) {
					if (!validaData($_POST['data_de'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Data invalida";
						throw new Exception(json_encode($retorno), 1);
					}
					$dt_ini = getDataAtual($_POST['data_de']);
					$dt_ini = getDataAtual($_POST['data_de']);
				} else {
					$dt_ini = getDataAtual();
				}

				if (isset($_POST['data_ate']) && !empty($_POST['data_ate'])) {
					if (!validaData($_POST['data_ate'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Data invalida";
						throw new Exception(json_encode($retorno), 1);
					}
					$dt_fim = getDataAtual($_POST['data_ate']);
				} else {
					$dt_fim = getDataAtual();
				}

				// Id utilizado na pesquisa, caso não informado o id padrão é o do proprio usuario logado.
				if (isset($_POST['id_funcionario']) && !empty($_POST['id_funcionario']) && is_numeric($_POST['id_funcionario'])) {
					$userId = $_POST['id_funcionario'];
				} else {
					$userId = $_SESSION['cmswerp']['userdata']->id;
				}

				$this->obj_ponto = new RhPonto($this, $userId); //jornada noturna
				$this->obj_ponto->gerarEspelho($dt_ini, $dt_fim, 'periodo');
				$user = $this->obj_ponto->user;
				$dados = $this->obj_ponto->calendario['diario'];
				$dicionario = $this->obj_ponto->mapa_ocorrencias;

			} catch (Exception $e) {
				echo $e->getMessage();
			}
			require_once ABSPATH . '/views/' . $this->nome_view . '/correcao-view.php';
		}

		function corrigirMarcacao()
		{
			try {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				switch ($this->parametros[0]) {
					case 'correcao':
						if (isset($_POST['correcoes']) && !empty($_POST['correcoes'])) {

							foreach ($_POST['correcoes'] as $key => $value) {
								foreach ($value as $k1 => $v1) {
									foreach ($v1 as $k2 => $v2) {
										if (isset($v2['hora']) && !empty($v2['hora'])) {
											$marcacao = true;
											if (!isset($v2['status']) || empty($v2['status'])) {
												$this->obj_ponto = new RhPonto($this, $v2['user']);
												$data_marcacao = convertDate($v2['data']);
												$param_ocorrencia['id_usuario'] = $v2['user'];
												$param_ocorrencia['fonte'] = 'R';
												$param_ocorrencia['classe'] = $v2['tipo'];
												$param_ocorrencia['data'] = $data_marcacao;
												$param_ocorrencia['status'] = 'pendente';
												$param_ocorrencia['data_lancamento'] = $this->data_hora_atual->format('Y-m-d H:i');
												$param_ocorrencia['periodo_ini'] = $data_marcacao . ' ' . $v2['hora'];
												$param_ocorrencia['periodo_fim'] = $data_marcacao . ' ' . $v2['hora'];
												$param_ocorrencia['permissivo'] = 0;
												$param_ocorrencia['deleted'] = 0;
												$explode = explode(':', $v2['hora']);
												if (!$v2['user']) {
													$retorno['mensagem'] = "Usuario não informado";
													throw new Exception(json_encode($retorno), 1);
												}

												if (count($explode) == 2) {
													$param_ocorrencia['hora'] = $v2['hora'];
													$tipo = $v2['tipo'];
													$dicionario = $this->obj_ponto->mapa_ocorrencias[$tipo]['texto'];

													if (empty($v2['texto'])) {
														$retorno['mensagem'] = "Preencha a justificativa!";
														throw new Exception(json_encode($retorno), 1);
													}

													if (isset($v2['id_registro']) && !empty($v2['id_registro'])) {
														$ocorrencias = json_decode($this->modelo->getOcorrenciaByIdRegsitro($v2['id_registro']));
														if ($ocorrencias && $ocorrencias[0]->fonte != 'T') {
															$retorno['mensagem'] = "Já existe uma ocorrencia " . $dicionario . " para essa data " . convertDate($data_marcacao) . " as " . $v2['hora'];
															throw new Exception(json_encode($retorno), 1);
														}
														$param_ocorrencia['id_registro'] = $v2['id_registro'];
														$param_ocorrencia['tipo'] = '1';
														$param_ocorrencia['texto'] = 'CORREÇÃO DE MARCAÇÃO';
													} else {
														$ocorrencias = json_decode($this->modelo->getOcorrenciaIntervalo($data_marcacao, $data_marcacao, $v2['tipo'], $v2['user'], null, 'R'));
														if ($ocorrencias) {
															$retorno['mensagem'] = "Já existe uma ocorrencia " . $dicionario . " para essa data " . convertDate($data_marcacao) . " as " . $v2['hora'];
															throw new Exception(json_encode($retorno), 1);
														}
														$param_ocorrencia['id_registro'] = null;
														$param_ocorrencia['tipo'] = '2';
														$param_ocorrencia['texto'] = 'CORREÇÃO DE AUSENCIA';
													}
													$param_ocorrencia['texto'] = $v2['texto'];
													$this->modelo->setTable('rh_jornada_ocorrencia');
													$save_ocorrencia = $this->modelo->save($param_ocorrencia);
													if ($save_ocorrencia) {
														$this->modelo->setTable('rh_token');
														$dados_token = $this->obj_ponto->dadosToken($save_ocorrencia, $this->obj_ponto->user);
														$save_token = $this->modelo->save($dados_token);
														$mensagem = "
																Uma correção de marcação $dicionario para o funcionario " . $this->obj_ponto->user->nome . " com ID " . $save_ocorrencia . " acesse o tarifador e acesso o menu 
																ponto / ocorrencias para aprova-la ou envie o token de liberação para o funcionario.
																TOKEN AUTORIZAÇÃO: " . $dados_token['token'];
														$parametros['tipo_destinatario'] = 'user';
														$parametros['email_to'] = $this->obj_ponto->user->email_chefe;
														$parametros['mensagem'] = $mensagem;
														$this->obj_notificacao->enviar('teams', $parametros);
													} else {
														$retorno['mensagem'] = "Erro ao corrigir a marcacao $k1 as $v1 ";
														throw new Exception(json_encode($retorno), 1);
													}
												} else {
													$retorno['mensagem'] = "A hora informada parece invalida " . $v2['hora_marcacao'];
													throw new Exception(json_encode($retorno), 1);
												}
											}
										}
									}
								}
							}
						} else {
							$retorno['mensagem'] = "Nenhuma correção informada!";
							throw new Exception(json_encode($retorno), 1);
						}
						$retorno['codigo'] = 0;
						$retorno['mensagem'] = 'Correções efetuadas com sucesso';
						break;
				}
				throw new Exception(json_encode($retorno), 1);
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function reenviarToken()
		{
			include 'config_extras.php';
			try {
				if (!isset($this->parametros[0]) || empty($this->parametros[0])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $id_token;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro em reenviar token";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$id_ocorrencia = $this->parametros[0];
				}

				$token = json_decode($this->modelo->getOcorrenciaToken($id_ocorrencia));
				if (!isset($token) || empty($token)) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $id_ocorrencia;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro em reenviar token";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$validade_token = new DateTime($token[0]->validade);
				}

				$get_usuario = json_decode($this->modelo->getUsuarios($token[0]->id_usuario));
				if (!isset($get_usuario) || empty($get_usuario)) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $token[0]->id_token;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro ao obter usuário do token.";
					throw new Exception(json_encode($retorno), 1);
				}

				$get_boss = json_decode($this->modelo->getUsuarios($get_usuario[0]->boss));
				if (!isset($get_boss) || empty($get_boss)) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $token[0]->id_token;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro ao obter boss dp usuário token";
					throw new Exception(json_encode($retorno), 1);
				}

				if ($validade_token->format('Ymd') >= $this->data_hora_atual->format('Ymd')) {
					if ($validade_token->format('Ymd') == $this->data_hora_atual->format('Ymd')) {
						if ($this->data_hora_atual->format('His') > $validade_token->format('His')) {
							$validade_token->modify('+1 day');
							$insert_token['validade'] = $validade_token->format('Y-m-d H:i:s');
						}
					}
				} else {
					$insert_token['validade'] = $validade_token->modify('+1 day');
					$insert_token['validade'] = $validade_token->format('Y-m-d H:i:s');
				}

				$digito = mt_rand(1000, 9999);
				$insert_token['token'] = $digito;
				$this->modelo->setTable("rh_token");
				$update_token = $this->modelo->save($insert_token, $token[0]->id_token);
				if (!isset($update_token)) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $token[0]->id;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro ao atualizar token";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$ocorrencia = [
						'id' => $token[0]->id,
						'tipo' => $VAR_SYSTEM['TIPO_REGISTRO'][$token[0]->classe],
						'data' => convertDate($token[0]->data),
						'email_boss' => $get_boss[0]->email,
						'id_slack' => $get_boss[0]->id_slack,
						'token' => $insert_token['token'],
						'hora' => retirarSegundos($token[0]->hora),
						'ocorrencia' => $token[0]->texto
					];

					if ($token[0]->texto == "TB04") {
						$ocorrencia['saida_max'] = retirarSegundos($token[0]->hora);
					}

					$retorno_token = $this->obj_ponto->enviarNotificacao('horario_nucleo', $get_usuario, $ocorrencia);
					if ($retorno_token->codigo == 1) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $ocorrencia;
						$retorno['output'] = $retorno_token;
						$retorno['mensagem'] = $retorno_token->mensagem;
						throw new Exception(json_encode($retorno));
					} else {
						$retorno['codigo'] = 0;
						$retorno['input'] = $ocorrencia;
						$retorno['output'] = null;
						$retorno['mensagem'] = $retorno_token->mensagem;
						throw new Exception(json_encode($retorno));
					}
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function marcacaoExtra()
		{
			//EXPLICAÇÃO: Optei por informar entrada extra e saída extra de uma vez na justificativa porque os funcionarios que trabalham em escala noturna, podem ter a entrada extra
			// em um dia e a saída extra após as 24:00 hrs, então para evitar conflitos no espelho, preferi obrigar o usuário a informa entrada e saida extra no POST de uma vez só.		
			try {
				include 'config_extras.php';
				$id_user = $_SESSION['cmswerp']['userdata']->id;
				$now = clone $this->data_hora_atual;
				if (isset($id_user) && !empty($id_user)) {
					$insert['id_usuario'] = $id_user;
				} else {
					$retorno["codigo"] = 1;
					$retorno["input"] = null;
					$retorno["output"] = null;
					$retorno["mensagem"] = "Erro id user.";
					throw new Exception(json_encode($retorno), 1);
				}

				if (!isset($_POST['data']) || empty($_POST['data'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $insert;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Informe a data.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					if (validaData($_POST['data']) == false) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $insert;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe uma data valida.";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['data'] = convertDate($_POST['data']);
					}
					if ($insert['data'] >= $this->data_hora_atual->format('Y-m-d')) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $insert;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Justificativa valida apenas para datas posterioes a hoje.";
						throw new Exception(json_encode($retorno), 1);
					}
					$ocorrencia_extra = json_decode($this->modelo->getOcorrencia(null, "A9", $insert['data'], null, NULL, $id_user));
					if (isset($ocorrencia_extra) && !empty($ocorrencia_extra)) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $insert;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Ocorrência de marcação extra já feita nesta data.";
						throw new Exception(json_encode($retorno), 1);
					}
				}

				if (!isset($_POST['entrada_extra']) || empty($_POST['entrada_extra'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $insert;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Informe a entrada extra.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					if (validate_hour($_POST['entrada_extra']) == false) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $insert;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe um horário de entrada extra valido.";
						throw new Exception(json_encode($retorno), 1);
					}
					$insert['periodo_ini'] = $insert['data'] . " " . $_POST['entrada_extra'];
				}

				if (!isset($_POST['saida_extra']) || empty($_POST['saida_extra'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $insert;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Informe a saida extra.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					if (validate_hour($_POST['saida_extra']) == false) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $insert;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe um horário de saida extra valido.";
						throw new Exception(json_encode($retorno), 1);
					}
					$insert['periodo_fim'] = $insert['data'] . " " . $_POST['saida_extra'];
				}

				if ($_POST['entrada_extra'] >= $_POST['saida_extra']) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $insert;
					$retorno['output'] = null;
					$retorno['mensagem'] = "ENTRADA EXTRA não pode ser maior ou igual que SAIDA EXTRA.";
					throw new Exception(json_encode($retorno), 1);
				}

				$b04 = json_decode($this->modelo->getRegistro("B04", $insert['data'], null, $id_user));
				if (isset($b04) && !empty($b04)) {
					if ($_POST['entrada_extra'] <= retirarSegundos($b04[0]->hora_marcacao)) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $insert;
						$retorno['output'] = null;
						$retorno['mensagem'] = "ENTRADA EXTRA não pode ser menor que saída final do dia " . convertDate($insert['data']);
						throw new Exception(json_encode($retorno), 1);
					}
				}

				$b07 = json_decode($this->modelo->getRegistro("B07", $insert['data'], null, $id_user));
				if (isset($b07) && !empty($b07)) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $insert;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Registro extra encontrado para essa data, entre em contato com a ADM.";
					throw new Exception(json_encode($retorno), 1);
				}

				$insert['status'] = 'pendente';
				$insert['permissivo'] = 0;
				$insert['fonte'] = 'A';
				$insert['tipo'] = '9';
				$insert['classe'] = 'A9';
				$insert['texto'] = "Ocorrência de marcação extra.";
				$insert['data_lancamento'] = $this->data_hora_atual->format('Y-m-d H:i:s');
				$this->modelo->setTable('rh_jornada_ocorrencia');
				$save_ocorrencia = $this->modelo->save($insert);

				if (isset($save_ocorrencia) && !empty($save_ocorrencia)) {

					$usuario = json_decode($this->modelo->getUsuarios($id_user));
					if (!isset($usuario) || empty($usuario)) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $insert;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Erro ao obter usuário.";
						throw new Exception(json_encode($retorno), 1);
					}
					$boss = json_decode($this->modelo->getUsuarios($usuario[0]->boss));
					if (!isset($boss) || empty($boss)) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $insert;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Erro ao obter boss.";
						throw new Exception(json_encode($retorno), 1);
					}
					$email_usuario = $boss[0]->email;
					if (URL_SISTEMA == "http://projetos1.local/") {
						$id_token = 'U025PU0DNP5';
					} else {
						$id_token = $boss[0]->id_slack;
					}

					$digito1 = mt_rand(0, 9);
					$digito2 = mt_rand(0, 9);
					$digito3 = mt_rand(0, 9);
					$digito4 = mt_rand(0, 9);
					$insert_token['token'] = $digito1 . $digito2 . $digito3 . $digito4;
					$insert_token['id_registro'] = $save_ocorrencia;
					$insert_token['id_usuario'] = $id_user;
					$insert_token['id_responsavel'] = $boss[0]->id;
					$validade = $now->add(new DateInterval('P1D'));
					$insert_token['validade'] = $validade->format('Y-m-d H:i:s');
					$insert_token['status'] = 'pendente';

					$this->modelo->setTable('rh_token');
					$save_token = $this->modelo->save($insert_token);
					if (isset($save_token) && !empty($save_token)) {
						$mensagem_token = "O funcionário " . $usuario[0]->nome . " registrou marcações extra no dia " . convertDate($insert['data']) . ". Token de validação: " . $insert_token['token'];
						$enviar_token = $this->enviarToken($email_usuario, $mensagem_token, $id_token);
						if ($enviar_token == true) {
							$retorno['codigo'] = 0;
							$retorno['input'] = $save_token;
							$retorno['output'] = $tipo_registro;
							$retorno['mensagem'] = "Sucesso. Necessário validar ocorrência via token.";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $save_token;
							$retorno['output'] = $tipo_registro;
							$retorno['mensagem'] = "Erro ao enviar token de validação.";
							throw new Exception(json_encode($retorno), 1);
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $insert_token;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Erro ao inserir na tabela rh_token.";
						throw new Exception(json_encode($retorno), 1);
					}
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $insert_ocorrencia;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro ao inserir na tabela rh_ocorrência.";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function getRegistro()
		{
			try {
				if (!isset($_POST['data']) || !empty($_POST['data'])) {
					$data = $_POST['data'];
					$data = convertDate($data);
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Informe a data.";
					throw new Exception(json_encode($retorno), 1);
				}

				if (!isset($_POST['funcionario']) || !empty($_POST['funcionario'])) {
					$id_usuario = $_POST['funcionario'];
				} else {
					$id_usuario = $_SESSION['cmswerp']['userdata']->id;
				}

				$registro = json_decode($this->modelo->getRegistro(null, $data, null, $id_usuario, null));
				$ocorrencia = json_decode($this->modelo->getOcorrencia(null, null, $data, "2", "aprovado", $id_usuario, null, "R"));
				if ($_POST['tipo_ocorrencia'] == "R2") {
					$registro_ausente = $this->obj_ponto->orderBatidaAusente($registro, $ocorrencia);
				} else {
					$registro = $this->obj_ponto->orderRegistro($registro, $ocorrencia);
				}

				if (strtotime($data) >= strtotime($this->data_hora_atual->format('Y-m-d')) && $_POST['tipo_ocorrencia'] == "R2") {
					$registro_retorno["mensagem"] = "JUSTIFICATIVA PARA DATAS POSTERIORES A HOJE";
					$registro_retorno["null"] = 0;
					$retorno['codigo'] = 0;
					$retorno['input'] = $_POST;
					$retorno['output'] = $registro_retorno;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno), 1);
				} else if (!isset($registro) || empty($registro)) {
					$registro_retorno["mensagem"] = "SEM REGISTRO APROVADO PARA ESSA DATA";
					$registro_retorno["null"] = 0;
					$retorno['codigo'] = 0;
					$retorno['input'] = $_POST;
					$retorno['output'] = $registro_retorno;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['codigo'] = 0;
					$retorno['input'] = $_POST;
					if ($_POST['tipo_ocorrencia'] == "R2") {
						if ($registro_ausente == null) {
							$registro_retorno["mensagem"] = "SEM REGISTRO AUSÊNTE PARA ESSA DATA";
							$registro_retorno["null"] = 0;
							$retorno['output'] = $registro_retorno;
						} else {
							$retorno['output'] = $registro_ausente;
						}
					} else {
						$retorno['output'] = $registro;
					}
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function validaTokenOcorrencia()
		{
			try {
				include 'config_extras.php';
				if (isset($this->parametros[0])) {
					$this->obj_ponto = new RhPonto($this, $_SESSION['cmswerp']['userdata']->id);
					//REENVIO DE TOKEN
					$id_ocorrencia = $_POST['id_ocorrencia'];
					if (empty($id_ocorrencia) || !isset($id_ocorrencia)) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "ID da ocorrencia não informado";
						throw new Exception(json_encode($retorno), 1);
					}

					$ocorrencia_token = json_decode($this->modelo->getOcorrenciaToken($id_ocorrencia));
					if($ocorrencia_token){
						$get_usuario = json_decode($this->modelo->getUsuarios($ocorrencia_token[0]->id_usuario));
						if (!isset($get_usuario) || empty($get_usuario)) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $_POST;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Erro pesquisar usuário";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$get_boss = json_decode($this->modelo->getUsuarios($get_usuario[0]->boss));
							if (!isset($get_boss) || empty($get_boss)) {
								$retorno['codigo'] = 1;
								$retorno['input'] = $_POST;
								$retorno['output'] = null;
								$retorno['mensagem'] = "Erro usuario sem boss";
								throw new Exception(json_encode($retorno), 1);
							}
						}

						$data_val_token = clone $this->data_hora_atual;
						$validade_token = $data_val_token->modify('+1 day');
						$digito = mt_rand(1000, 9999);
						$insert_token['token'] 	  = $digito;
						$insert_token['validade'] = $validade_token->format('Y-m-d H:i:s');

						$this->modelo->setTable("rh_token");
						$update_token = $this->modelo->save($insert_token, $ocorrencia_token[0]->id_token);
						if (!$update_token) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $ocorrencia_token;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Erro ao atualizar token";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$classe = $ocorrencia_token[0]->fonte . $ocorrencia_token[0]->tipo;
							if ($classe == "T1") {
								$codigo_ocorrencia = $VAR_SYSTEM['TIPO_REGISTRO'][$ocorrencia_token[0]->classe];
							} else {
								$codigo_ocorrencia = $VAR_SYSTEM['CODIGO_OCORRENCIA'][$classe];
							}

							$ocorrencia = [
								'email_boss' => $get_boss[0]->email,
								'id_slack' => $get_boss[0]->id_slack,
								'tipo' => $codigo_ocorrencia,
								'data' => ($classe == "A7" || $classe == "AA2") ? convertDate(returnPeriodo($ocorrencia_token[0]->periodo_ini)) . " até: " . convertDate(returnPeriodo($ocorrencia_token[0]->periodo_fim)) : convertDate($ocorrencia_token[0]->data),
								'token' => $insert_token['token'],
								'id' => $ocorrencia_token[0]->id,
								'ocorrencia' => $ocorrencia_token[0]->texto,
								'hora' => retirarSegundos($ocorrencia_token[0]->hora)
							];

							if ($ocorrencia_token[0]->texto == "TB04") {
								$ocorrencia['saida_max'] = retirarSegundos($ocorrencia_token[0]->hora);
							}
							$send = $this->obj_ponto->enviarNotificacao(null, $get_usuario, $ocorrencia);
							throw new Exception(json_encode($send));
						}
					}else{
						$dados_ocorrencia = json_decode($this->modelo->getOcorrenciaById($id_ocorrencia));
						$usuario 		  = json_decode($this->modelo->getUsuarios($dados_ocorrencia[0]->id_usuario));
						$boss 		  	  = json_decode($this->modelo->getUsuarios($usuario[0]->boss));
						if(!$dados_ocorrencia){
							$retorno['codigo'] = 1;
							$retorno['input'] = $_POST;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Erro ao tentar localizar ocorrencia COD: 3034";
							throw new Exception(json_encode($retorno), 1);
						}
						
						if(!$usuario){
							$retorno['codigo'] = 1;
							$retorno['input'] = $_POST;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Erro ao tentar localizar dados do usuario COD: 3042";
							throw new Exception(json_encode($retorno), 1);
						}

						if(!$boss){
							$retorno['codigo'] = 1;
							$retorno['input'] = $_POST;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Erro ao tentar localizar do usuario BOSS COD: 3047";
							throw new Exception(json_encode($retorno), 1);
						}

						$digito 			   	  		= mt_rand(1000, 9999);
						$validade_token 	   	  		= clone $this->data_hora_atual;
						$validade_token 	   	  		= $validade_token->modify('+1 day');
						$insert_token['token'] 	  		= (isset($digito))?$digito:null;
						$insert_token['validade'] 		= (isset($validade_token))?$validade_token->format('Y-m-d H:i:s'):null;
						$insert_token['id_registro'] 	= $dados_ocorrencia[0]->id;
						$insert_token['id_usuario'] 	= $dados_ocorrencia[0]->id_usuario;
						$insert_token['id_responsavel'] = $usuario[0]->boss;
						$insert_token['alterado_por'] 	= $this->userdata->id;
						$insert_token['alterado_em'] 	= $this->data_hora_atual->format('Y-m-d H:i:s');
						$insert_token['deleted'] = 0;
						$this->modelo->setTable("rh_token");
						$create_token = $this->modelo->save($insert_token);
						if($create_token){
							$ocorrencia = [
								'email_boss' => $boss[0]->email,
								'tipo' => $codigo_ocorrencia,
								'data' => convertDate($dados_ocorrencia[0]->data).' '.$dados_ocorrencia[0]->texto,
								'token' => $insert_token['token'],
								'id' => $dados_ocorrencia[0]->id,
								'ocorrencia' => $dados_ocorrencia[0]->texto,
								'hora' => retirarSegundos($dados_ocorrencia[0]->hora)
							];
							$send = $this->obj_ponto->enviarNotificacao(null, $usuario, $ocorrencia);
							if($send->codigo == 0){
								$retorno['codigo'] 	 = 0;
								$retorno['input']	 = null;
								$retorno['output']   = null;
								$retorno['mensagem'] = "Token reenviado com sucesso";
								throw new Exception(json_encode($retorno), 1);
							}else{
								$retorno['codigo'] 	 = 1;
								$retorno['input']	 = $_POST;
								$retorno['output']   = null;
								$retorno['mensagem'] = "Erro ao tentar reenviar o token";
								throw new Exception(json_encode($retorno), 1);
							}
						}else{
							$retorno['codigo'] 	 = 1;
							$retorno['input']	 = $_POST;
							$retorno['output']   = null;
							$retorno['mensagem'] = "Erro ao tentar recirar token COD: 3068";
							throw new Exception(json_encode($retorno), 1);
						}
					}
				} else {
					if (
						!isset($_POST['token_1']) || $_POST['token_1'] == "" || !isset($_POST['token_2']) || $_POST['token_2'] == "" ||
						!isset($_POST['token_3']) || $_POST['token_3'] == "" || $_POST['token_4'] == "" || !isset($_POST['token_4'])
					) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Preencha todos os digítos";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$valida_token = $_POST['token_1'] . $_POST['token_2'] . $_POST['token_3'] . $_POST['token_4'];
					}

					$id_ocorrencia = $_POST['id_ocorrencia'];
					if (empty($id_ocorrencia) || !isset($id_ocorrencia)) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "ID Token null";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$ocorrencia_token = json_decode($this->modelo->getOcorrenciaToken($id_ocorrencia, null, null, 'pendente'));
						if (!isset($ocorrencia_token)) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $_POST;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Erro em obter ocorrência. L3384";
							throw new Exception(json_encode($retorno), 1);
						}
					}

					$obj_validade = new DateTime($ocorrencia_token[0]->validade);
					if ($this->data_hora_atual->format('Y-m-d') <= $obj_validade->format('Y-m-d')) {
						if (
							($this->data_hora_atual->format('Y-m-d') < $obj_validade->format('Y-m-d')) ||
							($this->data_hora_atual->format('Y-m-d') == $obj_validade->format('Y-m-d') &&
								$this->data_hora_atual->format('His') <= $obj_validade->format('His'))
						) {
							if ($ocorrencia_token[0]->token == $valida_token) {
								$update_token['status'] = "validado";
								$this->modelo->setTable('rh_token');
								$update_token = $this->modelo->save($update_token, $ocorrencia_token[0]->id_token);
								if (!isset($update_token)) {
									$retorno['codigo'] = 1;
									$retorno['input'] = $_POST;
									$retorno['output'] = null;
									$retorno['mensagem'] = "Erro em validar token";
									throw new Exception(json_encode($retorno), 1);
								} else {
									$update_ocorrencia['status'] = 'aprovado';
									$update_ocorrencia['id_autorizado'] = $ocorrencia_token[0]->id_responsavel;
									$this->modelo->setTable('rh_jornada_ocorrencia');
									$update_ocorrencia = $this->modelo->save($update_ocorrencia, $ocorrencia_token[0]->id);
									if ($update_ocorrencia) {
										if ($ocorrencia_token[0]->fonte == "T" && $ocorrencia_token[0]->tipo == "1") {
											$update_registro['status'] = "aprovado";
											$this->modelo->setTable('rh_registro_ponto');
											$save_registro = $this->modelo->save($update_registro, $ocorrencia_token[0]->id_registro);
											if ($save_registro) {
												$retorno['codigo'] = 0;
												$retorno['input'] = $_POST;
												$retorno['output'] = $update_ocorrencia;
												$retorno['mensagem'] = "Sucesso em aprovar justificativa";
												throw new Exception(json_encode($retorno), 1);
											} else {
												$retorno['codigo'] = 1;
												$retorno['input'] = $_POST;
												$retorno['output'] = null;
												$retorno['mensagem'] = "Erro em atualizar ocorrência";
												throw new Exception(json_encode($retorno), 1);
											}
										} else {
											$retorno['codigo'] = 0;
											$retorno['input'] = $_POST;
											$retorno['output'] = $update_ocorrencia;
											$retorno['mensagem'] = "Sucesso em aprovar justificativa.";
											throw new Exception(json_encode($retorno), 1);
										}
									} else {
										$retorno['codigo'] = 1;
										$retorno['input'] = $_POST;
										$retorno['output'] = null;
										$retorno['mensagem'] = "Erro em atualizar ocorrência.";
										throw new Exception(json_encode($retorno), 1);
									}
								}
							} else {
								$retorno['codigo'] = 1;
								$retorno['input'] = $_POST;
								$retorno['output'] = null;
								$retorno['mensagem'] = "Token invalido.";
								throw new Exception(json_encode($retorno), 1);
							}
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $_POST;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Token expirado, por favor renviar token.";
							throw new Exception(json_encode($retorno), 1);
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Token expirado, por favor renviar token.";
						throw new Exception(json_encode($retorno), 1);
					}
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function validaTokenDepois()
		{
			try {
				$id_user = $_SESSION['cmswerp']['userdata']->id;
				$this->obj_ponto = new RhPonto($this, $_SESSION['cmswerp']['userdata']->id);
				if (!$_POST["tipo_marcacao"] || empty($_POST["tipo_marcacao"]) || $_POST["tipo_marcacao"] == "null") {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Informe o tipo de registro.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$tipo_marcacao = $_POST["tipo_marcacao"];
				}

				if (!$_POST['data_token'] || empty($_POST['data_token'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Informe a data do token";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$obj_data = getDataAtual($_POST['data_token']);
					$data_marcacao = $obj_data->format('Y-m-d');
				}

				if (
					!isset($_POST['token_1']) || $_POST['token_1'] == "" || !isset($_POST['token_2']) || $_POST['token_2'] == "" ||
					!isset($_POST['token_3']) || $_POST['token_3'] == "" || $_POST['token_4'] == "" || !isset($_POST['token_4'])
				) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Preencha todos os digítos";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$valida_token = $_POST['token_1'] . $_POST['token_2'] . $_POST['token_3'] . $_POST['token_4'];
				}

				if ($tipo_marcacao == "B04") {
					$get_B01 = json_decode($this->modelo->getRegistro('B01', $data_marcacao, null, $id_user, null, 'pendente'));
					if (isset($get_B01)) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Necessario validar primeiro ENTRADA INICIO.";
						throw new Exception(json_encode($retorno), 1);
					}
				}


				if ($tipo_marcacao == "B07") {
					$get_B04 = json_decode($this->modelo->getRegistro('B04', $data_marcacao, null, $id_user, null, 'pendente'));
					if (isset($get_B04)) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Necessario validar primeiro SAIDA FINAL.";
						throw new Exception(json_encode($retorno), 1);
					}
				}

				if ($tipo_marcacao == "B08") {
					$get_entrada_extra = json_decode($this->modelo->getRegistro('B07', $data_marcacao, null, $id_user, null, 'pendente'));
					if (isset($get_entrada_extra)) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Necessario validar primeiro ENTRADA EXTRA.";
						throw new Exception(json_encode($retorno), 1);
					}
				}

				$get_registro = json_decode($this->modelo->getRegistro($tipo_marcacao, $data_marcacao, null, $id_user, null, 'pendente'));

				if (!$get_registro) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = $get_registro;
					$retorno['mensagem'] = "Não existe registro do tipo de marcação: " . strtoupper(str_replace("_", " ", $tipo_marcacao)) . " na data: " . convertDate($data_marcacao) . " para validar.";
					throw new Exception(json_encode($retorno), 1);
				} else {

					$id_registro = $get_registro[0]->id;

					$token_ocorrencia = json_decode($this->modelo->getOcorrenciaToken(null, $id_registro));

					if (!$token_ocorrencia) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = $get_registro;
						$retorno['mensagem'] = "Erro em obter token para validar.";
						throw new Exception(json_encode($retorno), 1);
					}

					if ($valida_token == $token_ocorrencia[0]->token) {

						$update_token['status'] = "validado";
						$this->modelo->setTable('rh_token');
						$update_token = $this->modelo->save($update_token, $token_ocorrencia[0]->id_token);

						if (!isset($update_token)) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $_POST;
							$retorno['output'] = $get_registro;
							$retorno['mensagem'] = "Erro ao atualizar token.";
							throw new Exception(json_encode($retorno), 1);
						} else {

							$update_ocorrencia['status'] = 'aprovado';
							$update_ocorrencia['id_autorizado'] = $token_ocorrencia[0]->id_responsavel;
							$this->modelo->setTable('rh_jornada_ocorrencia');
							$save_ocorrencia = $this->modelo->save($update_ocorrencia, $token_ocorrencia[0]->id);

							if (!$save_ocorrencia) {
								$retorno['codigo'] = 1;
								$retorno['input'] = $_POST;
								$retorno['output'] = $this->modelo->info;
								$retorno['mensagem'] = "Erro ao atualizar ocorrência do token.";
								throw new Exception(json_encode($retorno), 1);
							} else {
								$update['status'] = "aprovado";
								$this->modelo->setTable('rh_registro_ponto');
								$update_registro = $this->modelo->save($update, $token_ocorrencia[0]->id_registro);

								if (!$update_registro) {
									$retorno['codigo'] = 1;
									$retorno['input'] = $_POST;
									$retorno['output'] = $this->modelo->info;
									$retorno['mensagem'] = "Erro ao atualizar status do registro.";
									throw new Exception(json_encode($retorno), 1);
								} else {
									$retorno['codigo'] = 0;
									$retorno['input'] = $_POST;
									$retorno['output'] = $get_registro;
									$retorno['mensagem'] = "Sucesso em validar token.";
									throw new Exception(json_encode($retorno), 1);
								}
							}
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = $get_registro;
						$retorno['mensagem'] = "Token invalido.";
						throw new Exception(json_encode($retorno), 1);
					}
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		// Calculo para obter os minutos de diferenca com base nas regras como entreada maxima, almoço maximo, etc.
		private function calculoDifHoraIniFim($de, $ate)
		{
			$tsAtual = strtotime($de);
			$tsFuturo = strtotime($ate);
			$diffSegundos = $tsAtual - $tsFuturo;
			return floor($diffSegundos / 60);
		}

		function addOcorrencia(){
			if (isset($_POST['qtd_horas']) && !empty($_POST['qtd_horas'])) {
				$_POST['minutos'] = convertHorasMinutos($_POST['qtd_horas'], 'hora>decimal');
			}
			$dados['ocorrencia'] = $_POST;
			$dados['arquivo'] = $_FILES;
			$retorno['codigo'] = 1;
			$retorno['input'] = $dados;
			try {
				$obj_ponto = new RhPonto($this, $_POST['funcionario']);
				// caso tenha erro
				if (!$obj_ponto->addOcorrencia($dados)->getError()) {
					$retorno['codigo'] = 0;
					$retorno['mensagem'] = 'Sucesso';
				} else {
					$retorno['mensagem'] = $obj_ponto->addOcorrencia($dados)->getRetorno();
				}
				$retorno['output'] = null;
				throw new Exception(json_encode($retorno), 1);
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function processarJustificativa(){
			try {
				$id_user = $_SESSION['cmswerp']['userdata']->id;
				if ($this->parametros[1] == "aprovar_ocorrencia" || $this->parametros[1] == "reprovar_ocorrencia") {
					$value_button = $this->parametros[1];
					if (empty($this->parametros[0]) || $this->parametros[0] == "null") {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Selecione uma ocorrência.";
						throw new Exception(json_encode($retorno), 1);
					} else {

						if ($this->parametros[1] == "aprovar_ocorrencia") {
							$insert['status'] = "aprovado";
							$texto_status = "aprovar";
						} elseif ($this->parametros[1] == "reprovar_ocorrencia") {
							$insert['status'] = "reprovado";
							$texto_status = "reprovar";
						}

						$id_explode = explode(",", $this->parametros[0]);
						if (is_array($id_explode)) {
							$this->modelo->setTable('rh_jornada_ocorrencia');
							foreach ($id_explode as $key => $value) {
								$get_ocorrencia[$value] = json_decode($this->modelo->getOcorrencia(null, null, null, null, null, null, $value));
								if (!isset($get_ocorrencia[$value])) {
									$retorno['codigo'] = 1;
									$retorno['input'] = $this->parametros;
									$retorno['output'] = $this->modelo->info;
									$retorno['mensagem'] = "Erro em obter ocorrência. L1876";
									throw new Exception(json_encode($retorno), 1);
								} else {
									if ($id_user == $get_ocorrencia[$value][0]->id_usuario) {
										$retorno['codigo'] = 1;
										$retorno['input'] = $this->parametros;
										$retorno['output'] = $this->modelo->info;
										$retorno['mensagem'] = "Usuario não pode " . $texto_status . " a própria ocorrência.";
										throw new Exception(json_encode($retorno), 1);
									}
								}

								$insert['id_autorizado'] = $id_user;
								$this->modelo->setTable('rh_jornada_ocorrencia');
								$update_ocorrencia = $this->modelo->save($insert, $value);
							}
							if ($update_ocorrencia) {
								$retorno['codigo'] = 0;
								$retorno['input'] = $this->parametros;
								$retorno['output'] = $this->modelo->info;
								$retorno['mensagem'] = "Sucesso em processar ocorrência.";
								throw new Exception(json_encode($retorno), 1);
							} else {
								$retorno['codigo'] = 1;
								$retorno['input'] = $this->parametros;
								$retorno['output'] = $this->modelo->info;
								$retorno['mensagem'] = "Erro em processar ocorrência.";
								throw new Exception(json_encode($retorno), 1);
							}
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro em processar ocorrência, não é um array!";
							throw new Exception(json_encode($retorno), 1);
						}
					}
				} else {

					$value_button = $this->parametros[0];
					$id_usuario = $this->parametros[1];
					$id_ocorrencia = $this->parametros[2];
					$data = $this->parametros[5] . "-" . $this->parametros[4] . "-" . $this->parametros[3];
					if (!isset($this->parametros[0])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Erro value button.";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($this->parametros[1])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Erro id usuario.";
						throw new Exception(json_encode($retorno), 1);
					}

					if (empty($this->parametros[2])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Selecione uma justificativa.";
						throw new Exception(json_encode($retorno), 1);
					}

					if (!isset($this->parametros[5]) || !isset($this->parametros[4]) || !isset($this->parametros[3])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = $this->modelo->info;
						$retorno['mensagem'] = "Erro nos parametros.";
						throw new Exception(json_encode($retorno), 1);
					}
					$insert['id_autorizado'] = $id_user;
				}
				$get_ocorrencia = json_decode($this->modelo->getOcorrencia(null, null, $data, null, null, $id_usuario, $id_ocorrencia));

				if (!$get_ocorrencia) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro ao obter ocorrência!";
					throw new Exception(json_encode($retorno), 1);
				}

				if ($value_button == "aprovar") {
					$insert['status'] = "aprovado";
					if ($get_ocorrencia[0]->tipo == "batida_ausente") {
						$insert_registro['deleted'] = 0;
						$insert_registro['status'] = 'aprovado';
						$get_registro = json_decode($this->modelo->getRegistro(null, null, null, $id_usuario, null, null, $get_ocorrencia[0]->id_registro));

						if (!$get_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao obter registro de batida ausente!";
							throw new Exception(json_encode($retorno), 1);
						}
						$this->modelo->setTable('rh_registro_ponto');
						$update_registro = $this->modelo->save($insert_registro, $get_registro[0]->id);
						if (!$update_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao atualizar registro!";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "atestado") {
						$this->modelo->setTable('rh_jornada_ocorrencia');
						$obj_ini = new DateTime($get_ocorrencia[0]->periodo_ini);
						$obj_fim = new DateTime($get_ocorrencia[0]->periodo_fim);
						$diff_atestado = $obj_ini->diff($obj_fim);
						clone $data_aux = $obj_ini;
						for ($x = 0; $x < $diff_atestado->days + 1; $x++) {
							$key_data = $data_aux->format('Y-m-d');
							$data_aux->add(new DateInterval('P1D'));
							$get_ocorrencia_atestado[$key_data] = json_decode($this->modelo->getOcorrencia(null, null, $key_data, null, null, $id_usuario, $id_ocorrencia));
							$update_atestado = $this->modelo->save($insert, $get_ocorrencia_atestado[$key_data][0]->id);
						}
						if ($update_atestado) {
							$retorno['codigo'] = 0;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $get_ocorrencia;
							$retorno['mensagem'] = "Sucesso em aprovar atestado.";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao processar justificativa de atestado";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "ferias") {
						$this->modelo->setTable('rh_jornada_ocorrencia');
						$obj_ini = new DateTime($get_ocorrencia[0]->periodo_ini);
						$obj_fim = new DateTime($get_ocorrencia[0]->periodo_fim);
						$diff_ferias = $obj_ini->diff($obj_fim);
						clone $data_aux = $obj_ini;
						for ($x = 0; $x < $diff_ferias->days + 1; $x++) {
							$key_data = $data_aux->format('Y-m-d');
							$data_aux->add(new DateInterval('P1D'));
							$get_ocorrencia_ferias[$key_data] = json_decode($this->modelo->getOcorrencia(null, null, $key_data, null, null, $id_usuario, $id_ocorrencia));
							$update_ferias = $this->modelo->save($insert, $get_ocorrencia_ferias[$key_data][0]->id);
						}
						if ($update_ferias) {
							$retorno['codigo'] = 0;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $get_ocorrencia;
							$retorno['mensagem'] = "Sucesso em aprovar férias.";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao processar justificativa de férias";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "batida_incorreta") {
						$insert_registro['deleted'] = 0;
						$insert_registro['status'] = 'aprovado';
						$explode_registro_antigo = explode(" ", $get_ocorrencia[0]->periodo_fim);
						$explode_registro_antigo_2 = explode(":", $explode_registro_antigo[1]);
						$hora_marcacao = $explode_registro_antigo_2[0] . ":" . $explode_registro_antigo_2[1];
						$insert_registro['hora_marcacao'] = $hora_marcacao;
						$get_registro = json_decode($this->modelo->getRegistro($get_ocorrencia[0]->classe, $data, 'Justificativa de batida incorreta'));
						if (!$get_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO OBTER REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
						$update_registro = $this->modelo->save($insert_registro, $get_registro[0]->id);
						if (!$update_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO ATUALIZAR REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
					}
				} elseif ($value_button == "reprovar") {
					$insert['status'] = "reprovado";
					if ($get_ocorrencia[0]->tipo == "batida_ausente") {
						$insert_registro['deleted'] = 0;
						$insert_registro['status'] = 'reprovado';
						$get_registro = json_decode($this->modelo->getRegistro($get_ocorrencia[0]->classe, $data));
						if (!$get_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO OBTER REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
						$update_registro = $this->modelo->save($insert_registro, $get_registro[0]->id);
						if (!$update_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO ATUALIZAR REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "atestado") {
						$this->modelo->setTable('rh_jornada_ocorrencia');
						$obj_ini = new DateTime($get_ocorrencia[0]->periodo_ini);
						$obj_fim = new DateTime($get_ocorrencia[0]->periodo_fim);
						$diff_atestado = $obj_ini->diff($obj_fim);
						clone $data_aux = $obj_ini;
						for ($x = 0; $x < $diff_atestado->days + 1; $x++) {
							$key_data = $data_aux->format('Y-m-d');
							$data_aux->add(new DateInterval('P1D'));
							$get_ocorrencia_atestado[$key_data] = json_decode($this->modelo->getOcorrencia(null, null, $key_data, null, null, $id_usuario, $id_ocorrencia));
							$update_atestado = $this->modelo->save($insert, $get_ocorrencia_atestado[$key_data][0]->id);
						}
						if ($update_atestado) {
							$retorno['codigo'] = 0;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $get_ocorrencia;
							$retorno['mensagem'] = "Sucesso em reprovar atestado.";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao processar justificativa de atestado";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "ferias") {
						$this->modelo->setTable('rh_jornada_ocorrencia');
						$obj_ini = new DateTime($get_ocorrencia[0]->periodo_ini);
						$obj_fim = new DateTime($get_ocorrencia[0]->periodo_fim);
						$diff_ferias = $obj_ini->diff($obj_fim);
						clone $data_aux = $obj_ini;
						for ($x = 0; $x < $diff_ferias->days + 1; $x++) {
							$key_data = $data_aux->format('Y-m-d');
							$data_aux->add(new DateInterval('P1D'));
							$get_ocorrencia_ferias[$key_data] = json_decode($this->modelo->getOcorrencia(null, null, $key_data, null, null, $id_usuario, $id_ocorrencia));
							$update_ferias = $this->modelo->save($insert, $get_ocorrencia_ferias[$key_data][0]->id);
						}
						if ($update_ferias) {
							$retorno['codigo'] = 0;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $get_ocorrencia;
							$retorno['mensagem'] = "Sucesso em reprovar férias.";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao processar justificativa de férias";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "batida_incorreta") {
						$insert_registro['deleted'] = 0;
						$insert_registro['status'] = 'aprovado';
						$explode_registro_antigo = explode(" ", $get_ocorrencia[0]->periodo_ini);
						$explode_registro_antigo_2 = explode(":", $explode_registro_antigo[1]);
						$hora_marcacao = $explode_registro_antigo_2[0] . ":" . $explode_registro_antigo_2[1];
						$insert_registro['hora_marcacao'] = $hora_marcacao;
						$get_registro = json_decode($this->modelo->getRegistro($get_ocorrencia[0]->classe, $data, 'Justificativa de batida incorreta'));
						if (!$get_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO OBTER REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
						$update_registro = $this->modelo->save($insert_registro, $get_registro[0]->id);
						if (!$update_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO ATUALIZAR REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
					}
				} elseif ($value_button == "apagar") {
					$insert['deleted'] = 1;
					unset($insert['id_autorizado']);
					if ($get_ocorrencia[0]->tipo == "batida_ausente") {
						$rh_ocorrencia = "batida ausente";
						$get_registro = json_decode($this->modelo->getRegistro($get_ocorrencia[0]->classe, $data, $rh_ocorrencia));
						if (!$get_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO OBTER REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
						$update_registro = $this->modelo->save($insert, $get_registro[0]->id);
						if (!$update_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO ATUALIZAR REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "atestado") {
						$this->modelo->setTable('rh_jornada_ocorrencia');
						$obj_ini = new DateTime($get_ocorrencia[0]->periodo_ini);
						$obj_fim = new DateTime($get_ocorrencia[0]->periodo_fim);
						$diff_atestado = $obj_ini->diff($obj_fim);
						clone $data_aux = $obj_ini;
						for ($x = 0; $x < $diff_atestado->days + 1; $x++) {
							$key_data = $data_aux->format('Y-m-d');
							$data_aux->add(new DateInterval('P1D'));
							$get_ocorrencia_atestado[$key_data] = json_decode($this->modelo->getOcorrencia(null, null, $key_data, null, null, $id_usuario, $id_ocorrencia));
							$update_atestado = $this->modelo->save($insert, $get_ocorrencia_atestado[$key_data][0]->id);
						}
						if ($update_atestado) {
							$retorno['codigo'] = 0;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $get_ocorrencia;
							$retorno['mensagem'] = "Sucesso em apagar atestado.";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao processar justificativa de atestado";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "ferias") {
						$this->modelo->setTable('rh_jornada_ocorrencia');
						$obj_ini = new DateTime($get_ocorrencia[0]->periodo_ini);
						$obj_fim = new DateTime($get_ocorrencia[0]->periodo_fim);
						$diff_ferias = $obj_ini->diff($obj_fim);
						clone $data_aux = $obj_ini;
						for ($x = 0; $x < $diff_ferias->days + 1; $x++) {
							$key_data = $data_aux->format('Y-m-d');
							$data_aux->add(new DateInterval('P1D'));
							$get_ocorrencia_ferias[$key_data] = json_decode($this->modelo->getOcorrencia(null, null, $key_data, null, null, $id_usuario, $id_ocorrencia));
							$update_ferias = $this->modelo->save($insert, $get_ocorrencia_ferias[$key_data][0]->id);
						}
						if ($update_ferias) {
							$retorno['codigo'] = 0;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $get_ocorrencia;
							$retorno['mensagem'] = "Sucesso em apagar férias.";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao processar justificativa de férias";
							throw new Exception(json_encode($retorno), 1);
						}
					} elseif ($get_ocorrencia[0]->tipo == "batida_incorreta") {
						$explode_registro_antigo = explode(" ", $get_ocorrencia[0]->periodo_ini);
						$explode_registro_antigo_2 = explode(":", $explode_registro_antigo[1]);
						$hora_marcacao = $explode_registro_antigo_2[0] . ":" . $explode_registro_antigo_2[1];
						$insert_registro['hora_marcacao'] = $hora_marcacao;
						$insert_registro['status'] = 'aprovado';
						$get_registro = json_decode($this->modelo->getRegistro($get_ocorrencia[0]->classe, $data, 'Justificativa de batida incorreta'));

						if (!$get_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO OBTER REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
						$update_registro = $this->modelo->save($insert_registro, $get_registro[0]->id);
						if (!$update_registro) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "*ERRO AO ATUALIZAR REGISTRO";
							throw new Exception(json_encode($retorno), 1);
						}
					}
				}
				$this->modelo->setTable('rh_jornada_ocorrencia');
				$update = $this->modelo->save($insert, $get_ocorrencia[0]->id);
				if ($update) {
					$retorno['codigo'] = 0;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = $get_ocorrencia;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro ao processar justificativa";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function processarFalta(){
			try {
				$id_user = $_SESSION['cmswerp']['userdata']->id;
				if (empty($this->parametros[0]) || !isset($this->parametros[0])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro nos parametros!";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$value_button = $this->parametros[0];
				}

				if (empty($this->parametros[1]) || !isset($this->parametros[1])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro id_usuario!";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$id_usuario = $this->parametros[1];
				}

				if (empty($this->parametros[2]) || !isset($this->parametros[2])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Selecione uma data!";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$data_explode = explode(",", $this->parametros[2]);
				}

				if ($value_button == "abonada") {
					$insert['tipo'] = 5;
					$insert['fonte'] = "A";
					$insert['classe'] = "A5";
				} elseif ($value_button == "desconto_banco") {
					$insert['tipo'] = 2;
					$insert['fonte'] = "D";
					$insert['classe'] = "D2";
				} elseif ($value_button == "desconto_folha") {
					$insert['tipo'] = 1;
					$insert['fonte'] = "D";
					$insert['classe'] = "D1";
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro no value button!";
					throw new Exception(json_encode($retorno), 1);
				}

				$insert['id_usuario'] = $id_usuario;
				$insert['status'] = "aprovado";
				$insert['id_autorizado'] = $id_user;

				$this->modelo->setTable('rh_jornada_ocorrencia');
				if (is_array($data_explode)) {
					foreach ($data_explode as $key => $value) {
						$insert['data'] = $value;
						$insert['periodo_ini'] = $value;
						$insert['periodo_fim'] = $value;
						$get_ocorrencia = json_decode($this->modelo->getOcorrencia(null, "ocorrencia_tipo", $value, null, null, $id_usuario));
						if ($get_ocorrencia) {
							$update_desconto = $this->modelo->save($insert, $get_ocorrencia[0]->id);
						} else {
							$save_desconto = $this->modelo->save($insert);
						}
					}
				}
				if ($save_desconto || $update_desconto) {
					if ($value_button == "desconto_banco") {
						$retorno['mensagem'] = "Sucesso, desconto banco de horas.";
					} elseif ($value_button == "desconto_folha") {
						$retorno['mensagem'] = "Sucesso, desconto folha de pagamento.";
					} elseif ($value_button == "abonada") {
						$retorno['mensagem'] = "Sucesso em abonar dia.";
					} else {
						$retorno['mensagem'] = "Sucesso";
					}
					$retorno['codigo'] = 0;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro ao salvar ocorrência";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function inserirJornada(){
			try {
				unset($_POST['select_dias_semana']);
				unset($_POST['add_entrada']);
				unset($_POST['add_saida']);
				unset($_POST['add_nucleo_ini']);
				unset($_POST['add_nucleo_fim']);
				unset($_POST['add_entrada_min']);
				unset($_POST['add_saida_max']);
				unset($_POST['add_almoco_min']);
				unset($_POST['add_almoco_max']);

				if (!isset($_POST['nome']) || empty($_POST['nome'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $insert;
					$retorno['mensagem'] = "Insira um nome da jornada.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$insert['nome'] = $_POST['nome'];
				}

				if (!isset($_POST['acesso_externo']) || $_POST['acesso_externo'] == "") {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $insert;
					$retorno['mensagem'] = "Informe o acesso externo.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$insert['acesso_externo'] = $_POST['acesso_externo'];
				}

				if (!isset($_POST['desconto']) || empty($_POST['desconto'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $insert;
					$retorno['mensagem'] = "Selecione um desconto padrão.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$insert['desconto'] = $_POST['desconto'];
				}

				if (!isset($_POST['aderir_feriado']) || $_POST['aderir_feriado'] == "") {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $insert;
					$retorno['mensagem'] = "Informe o campo aderir feriado.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$insert['aderir_feriado'] = $_POST['aderir_feriado'];
				}

				if (!isset($_POST['registro_fora_jornada']) || $_POST['registro_fora_jornada'] == "") {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $insert;
					$retorno['mensagem'] = "Informe o campo aderir jornada.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$insert['aderir_jornada'] = $_POST['registro_fora_jornada'];
				}

				if (!isset($_POST['horas_almoco']) || empty($_POST['horas_almoco'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $insert;
					$retorno['mensagem'] = "Informe horas almoço.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$insert['horas_almoco'] = convertHorasMinutos($_POST['horas_almoco']);
				}

				if (!isset($_POST['horas_maxima']) || empty($_POST['horas_maxima'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $insert;
					$retorno['mensagem'] = "Informe horas máxima do banco de horas por dia.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$insert['horas_maxima'] = convertHorasMinutos($_POST['horas_maxima']);
				}

				if (!isset($_POST['hr_noturno_ini']) || empty($_POST['hr_noturno_ini'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $insert;
					$retorno['mensagem'] = "Informe o início do horário noturno.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$insert['hr_noturno_ini'] = $_POST['hr_noturno_ini'];
				}

				if (!isset($_POST['hr_noturno_fim']) || empty($_POST['hr_noturno_fim'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $insert;
					$retorno['mensagem'] = "Informe o final do horário noturno.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$insert['hr_noturno_fim'] = $_POST['hr_noturno_fim'];
				}

				if (!isset($_POST['dias_semana']) || empty($_POST['dias_semana'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $insert;
					$retorno['mensagem'] = "Adicione os dias da semana trabalhados.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					if (is_array($_POST['dias_semana'])) {
						foreach ($_POST['dias_semana'] as $key => $value) {
							$value = strtolower($value);
							if ($value == "segunda") {
								$dia = "1";
							} elseif ($value == "terca") {
								$dia = "2";
							} elseif ($value == "quarta") {
								$dia = "3";
							} elseif ($value == "quinta") {
								$dia = "4";
							} elseif ($value == "sexta") {
								$dia = "5";
							} elseif ($value == "sabado") {
								$dia = "6";
							} elseif ($value == "domingo") {
								$dia = "7";
							}
							$dias_semana['dias_semana'][] = $dia;
						}
						asort($dias_semana['dias_semana']);
						$contador = 0;
						foreach ($dias_semana['dias_semana'] as $key => $value) {
							if ($contador == 0) {
								$insert['dias_semana'] = $value;
							} else {
								$insert['dias_semana'] .= "," . $value;
							}
							$contador++;
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['ouput'] = $insert;
						$retorno['mensagem'] = "Erro array dias da semana.";
						throw new Exception(json_encode($retorno), 1);
					}
				}

				if (!isset($_POST['entrada']) || empty($_POST['entrada'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $insert;
					$retorno['mensagem'] = "Informe a entrada.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					if (is_array($_POST['entrada'])) {
						$contador = 0;
						foreach ($_POST['entrada'] as $key => $value) {
							$insert_dias_jornada[$contador]['entrada'] = $value;
							$contador++;
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['ouput'] = $insert;
						$retorno['mensagem'] = "Erro array entrada.";
						throw new Exception(json_encode($retorno), 1);
					}
				}

				if (!isset($_POST['saida']) || empty($_POST['saida'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $insert;
					$retorno['mensagem'] = "Informe o horário de saida.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					if (is_array($_POST['saida'])) {
						$contador = 0;
						foreach ($_POST['saida'] as $key => $value) {
							$insert_dias_jornada[$contador]['saida'] = $value;
							$contador++;
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['ouput'] = $insert;
						$retorno['mensagem'] = "Erro array entrada.";
						throw new Exception(json_encode($retorno), 1);
					}
				}

				if (!isset($_POST['nucleo_ini']) || empty($_POST['nucleo_ini'])) {
					$insert_dias_jornada['nucleo_ini'][] = null;
				} else {
					if (is_array($_POST['nucleo_ini'])) {
						$contador = 0;
						foreach ($_POST['nucleo_ini'] as $key => $value) {
							if (empty($value)) {
								$value = null;
							}
							$insert_dias_jornada[$contador]['nucleo_ini'] = $value;
							$contador++;
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['ouput'] = $insert;
						$retorno['mensagem'] = "Erro array entrada.";
						throw new Exception(json_encode($retorno), 1);
					}
				}

				if (!isset($_POST['nucleo_fim']) || empty($_POST['nucleo_fim'])) {
					$insert_dias_jornada[]['nucleo_fim'] = null;
				} else {
					if (is_array($_POST['nucleo_fim'])) {
						$contador = 0;
						foreach ($_POST['nucleo_fim'] as $key => $value) {
							if (empty($value)) {
								$value = null;
							}
							$insert_dias_jornada[$contador]['nucleo_fim'] = $value;
							$contador++;
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['ouput'] = $insert;
						$retorno['mensagem'] = "Erro array entrada.";
						throw new Exception(json_encode($retorno), 1);
					}
				}

				if (!isset($_POST['almoco_min']) || empty($_POST['almoco_min'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $insert;
					$retorno['mensagem'] = "Informe o horário de almoço mínimo.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					if (is_array($_POST['almoco_min'])) {
						$contador = 0;
						foreach ($_POST['almoco_min'] as $key => $value) {
							$insert_dias_jornada[$contador]['almoco_min'] = $value;
							$contador++;
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['ouput'] = $insert;
						$retorno['mensagem'] = "Erro array almoço mínimo.";
						throw new Exception(json_encode($retorno), 1);
					}
				}

				if (!isset($_POST['almoco_max']) || empty($_POST['almoco_max'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $insert;
					$retorno['mensagem'] = "Informe o horário de almoço máxino.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					if (is_array($_POST['almoco_max'])) {
						$contador = 0;
						foreach ($_POST['almoco_max'] as $key => $value) {
							$insert_dias_jornada[$contador]['almoco_max'] = $value;
							$contador++;
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['ouput'] = $insert;
						$retorno['mensagem'] = "Erro array almoço máximo.";
						throw new Exception(json_encode($retorno), 1);
					}
				}

				if (!isset($_POST['entrada_min']) || empty($_POST['entrada_min'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $insert;
					$retorno['mensagem'] = "Informe o horário de entrada mínimo.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					if (is_array($_POST['entrada_min'])) {
						$contador = 0;
						foreach ($_POST['entrada_min'] as $key => $value) {
							$insert_dias_jornada[$contador]['entrada_min'] = $value;
							$contador++;
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['ouput'] = $insert;
						$retorno['mensagem'] = "Erro array entrada mínimo.";
						throw new Exception(json_encode($retorno), 1);
					}
				}

				if (!isset($_POST['saida_max']) || empty($_POST['saida_max'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $insert;
					$retorno['mensagem'] = "Informe o horário de entrada máximo.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					if (is_array($_POST['saida_max'])) {
						$contador = 0;
						foreach ($_POST['saida_max'] as $key => $value) {
							$insert_dias_jornada[$contador]['saida_max'] = $value;
							$contador++;
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['ouput'] = $insert;
						$retorno['mensagem'] = "Erro array entrada máximo.";
						throw new Exception(json_encode($retorno), 1);
					}
				}

				$insert['status'] = 'ativo';
				$this->modelo->setTable('rh_jornada_trabalho');
				$save_jornada = $this->modelo->save($insert);

				if ($save_jornada) {

					if (!isset($dias_semana['dias_semana']) || empty($dias_semana['dias_semana'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['ouput'] = $insert_dias_jornada;
						$retorno['mensagem'] = "Informe os dias da semana.";
						throw new Exception(json_encode($retorno), 1);
					} else {
						if (is_array($dias_semana['dias_semana'])) {
							$contador = 0;
							foreach ($dias_semana['dias_semana'] as $key => $value) {
								$insert_dias_jornada[$contador]['dias_semana'] = $value;
								$insert_dias_jornada[$contador]['id_jornada'] = $save_jornada;
								$contador++;
							}
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $_POST;
							$retorno['ouput'] = $insert_dias_jornada;
							$retorno['mensagem'] = "Erro array entrada.";
							throw new Exception(json_encode($retorno), 1);
						}
					}

					$this->modelo->setTable('rh_jornada_dias');
					foreach ($insert_dias_jornada as $key => $value) {
						$save_jornada_dias = $this->modelo->save($value);
						if (!$save_jornada_dias) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $_POST;
							$retorno['ouput'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao salvar jornada dias.";
							throw new Exception(json_encode($retorno), 1);
						}
					}
					if ($save_jornada_dias) {
						$retorno['codigo'] = 0;
						$retorno['input'] = $_POST;
						$retorno['ouput'] = $insert_dias_jornada;
						$retorno['mensagem'] = "Sucesso";
						throw new Exception(json_encode($retorno), 1);
					}
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['ouput'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro ao salvar jornada no banco de dados.";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function jornadaDias(){
			try {
				if (!isset($this->parametros[0]) && empty($this->parametros[0])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro ao pesquisar dias da semana";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$id_jornada = $this->parametros[0];
				}

				$jornada_dias = json_decode($this->modelo->getJornadaDias($id_jornada));
				if (!isset($jornada_dias) || empty($jornada_dias)) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $id_jornada;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro ao pesquisar dias da semana";
					throw new Exception(json_encode($retorno), 1);
				} else {
					foreach ($jornada_dias as $key => $value) {
						if ($value->dias_semana == "1") {
							$value->dias_semana = "<b>SEGUNDA</b>";
						} else if ($value->dias_semana == "2") {
							$value->dias_semana = "<b>TERÇA</b>";
						} else if ($value->dias_semana == "3") {
							$value->dias_semana = "<b>QUARTA</b>";
						} else if ($value->dias_semana == "4") {
							$value->dias_semana = "<b>QUINTA</b>";
						} else if ($value->dias_semana == "5") {
							$value->dias_semana = "<b>SEXTA</b>";
						} else if ($value->dias_semana == "6") {
							$value->dias_semana = "<b>SÁBADO</b>";
						} else if ($value->dias_semana == "7") {
							$value->dias_semana = "<b>DOMINGO</b>";
						}

						if ($value->nucleo_ini == null || empty($value->nucleo_ini)) {
							$value->nucleo_ini = "<a type='button' class='btn btn-danger btn-xs'><i class='fa fa-ban'></i></a>";
						}
						if ($value->nucleo_fim == null || empty($value->nucleo_fim)) {
							$value->nucleo_fim = "<a type='button' class='btn btn-danger btn-xs'><i class='fa fa-ban'></i></a>";
						}
						if ($value->entrada_min == null || empty($value->entrada_min)) {
							$value->entrada_min = "<a type='button' class='btn btn-danger btn-xs'><i class='fa fa-ban'></i></a>";
						} else {
							$value->entrada_min = retirarSegundos($value->entrada_min);
						}
						if ($value->saida_max == null || empty($value->saida_max)) {
							$value->saida_max = "<a type='button' class='btn btn-danger btn-xs'><i class='fa fa-ban'></i></a>";
						} else {
							$value->saida_max = retirarSegundos($value->saida_max);
						}
						if (($value->almoco_min == null || empty($value->almoco_min)) || ($value->almoco_max == null || empty($value->almoco_max))) {
							$value->almoco_min = false;
							$value->almoco_max = false;
						}
					}

					$retorno['codigo'] = 0;
					$retorno['input'] = $id_jornada;
					$retorno['output'] = $jornada_dias;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function getUsuariosJornada(){
			try {
				$all_usuarios = json_decode($this->modelo->getUsuarios());
				if (isset($this->parametros[0])) {
					$usuarios_escala = json_decode($this->modelo->getRhJornadaUsuario(null, $this->parametros[0], 'ativo'));
					foreach ($usuarios_escala as $key => $value) {
						$value->nome = strtoupper($value->nome);
						$value->data_inicio = convertDate($value->data_inicio);
					}
					foreach ($all_usuarios as $key => $value) {
						$value->nome = strtoupper($value->nome);
					}

					if ($usuarios_escala) {
						$retorno['codigo'] = 0;
						$retorno['input'] = $all_usuarios;
						$retorno['output'] = $usuarios_escala;
						$retorno['mensagem'] = "Sucesso pesquisa.";
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $all_usuarios;
						$retorno['output'] = $this->parametros[1];
						$retorno['mensagem'] = "Sucesso, pesquisa vazia.";
					}
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function addUsuarioJornada(){
			try {
				if (!isset($this->parametros[0]) || empty($this->parametros[0])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Selecione um funcionário!";
					throw new Exception(json_encode($retorno), 1);
				} elseif ($this->parametros[0] == "Selecione") {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Selecione um funcionário!";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$id_usuario = $this->parametros[0];
				}

				if (!isset($this->parametros[1]) || empty($this->parametros[1])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro ao adicionar funcinário na escala.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$id_jornada = $this->parametros[1];
				}

				if (!isset($this->parametros[3]) || empty($this->parametros[3])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Selecione uma data.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$data = $this->parametros[4] . "-" . $this->parametros[3] . "-" . $this->parametros[2];
					$data_check = checkdate($this->parametros[3], $this->parametros[2], $this->parametros[4]);
					if ($data_check == false) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Data invalida.";
						throw new Exception(json_encode($retorno), 1);
					}
				}

				if (strtotime($data) < strtotime($this->data_hora_atual->format('Y-m-d'))) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Data não pode ser menor que " . $this->data_hora_atual->format('d/m/Y') . ".";
					throw new Exception(json_encode($retorno), 1);
				}

				$usuario_outra_jornada = json_decode($this->modelo->getRhJornadaUsuario($id_usuario, null, 'ativo'));
				$ultima_jornada = end($usuario_outra_jornada);
				if ($usuario_outra_jornada) {
					$fim = null;
					$id_anterior = null;
					$this->modelo->setTable('rh_jornada_usuario');
					foreach ($usuario_outra_jornada as $key => $value) {
						if ($id_anterior && $value->data_inicio != $ultima_jornada->data_inicio) {
							$data_fim = getDataAtual($value->data_inicio);
							$data_fim = $data_fim->modify('-1 day');
							$param['data_fim'] = $data_fim->format('Y-m-d');
							$this->modelo->save($param, $id_anterior);
							$id_anterior = null;
						}

						if (empty($value->data_fim) || $value->data_fim == '0000-00-00') {
							$id_anterior = $value->id;
						}
					}
				}

				$insert_jornada['id_jornada'] = $id_jornada;
				$insert_jornada['id_usuario'] = $id_usuario;
				$insert_jornada['data_inicio'] = $data;
				$insert_jornada['status'] = 'ativo';
				$this->modelo->setTable('rh_jornada_usuario');
				$set_jornada_usuario = $this->modelo->save($insert_jornada);
				if ($set_jornada_usuario) {
					$data_ultimo = getDataAtual($data);
					$data_ultimo = $data_ultimo->modify('-1 day');
					$param_ultimo['data_fim'] = $data_ultimo->format('Y-m-d');
					$ultimo_id = $ultima_jornada->id;
					$this->modelo->save($param_ultimo, $ultimo_id);
					$retorno['codigo'] = 0;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = $id_jornada;
					$retorno['mensagem'] = "Sucesso.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro!";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function excluirUsuarioJornada(){
			try {
				if (!isset($this->parametros[0]) || empty($this->parametros[0])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro parametros[0] vazio!";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$id_usuario = $this->parametros[0];
					$insert['id_jornada'] = null;
				}
				if (!isset($this->parametros[1]) || empty($this->parametros[1])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro parametros[1] vazio!";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$id_jornada = $this->parametros[1];
				}

				$jornada_usuario = json_decode($this->modelo->getRhJornadaUsuario($id_usuario, $id_jornada, 'ativo'));
				if (!$jornada_usuario) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro ao deletar usuário da jornada!";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$insert_jornada['status'] = 'inativo';
					$this->modelo->setTable('rh_jornada_usuario');
					$update_jornada_usuario = $this->modelo->save($insert_jornada, $jornada_usuario[0]->id);
					if (!$update_jornada_usuario) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Erro ao deletar usuário da rh_jornada_usuario!";
						throw new Exception(json_encode($retorno), 1);
					}
				}

				if ($update_jornada_usuario) {
					$retorno['codigo'] = 0;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = $id_jornada;
					$retorno['mensagem'] = "Sucesso em deletar usuário da jornada.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro!";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function excluirJornada(){
			try {
				$id_jornada = $this->parametros[0];
				$get_jornada_usuario = json_decode($this->modelo->getRhJornadaUsuario(null, $id_jornada, 'ativo'));
				if ($get_jornada_usuario) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $id_jornada;
					$retorno['output'] = $get_jornada_usuario;
					$retorno['mensagem'] = "Jornada com usuários ativos, necessário excluir todos os usuários.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$insert['deleted'] = 1;
					$insert['status'] = 'inativo';
				}
				$this->modelo->setTable('rh_jornada_trabalho');
				$delete_jornada = $this->modelo->save($insert, $id_jornada);
				if ($delete_jornada) {
					$retorno['codigo'] = 0;
					$retorno['input'] = $id_jornada;
					$retorno['output'] = $get_jornada_usuario;
					$retorno['mensagem'] = "Sucesso em deletar jornada.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $id_jornada;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro em deletar jornada.";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function pathIframeAjax(){
			try {
				if (isset($this->parametros[1])) {
					$id_ged = $this->parametros[1];
					$get_anexo = json_decode($this->modelo->gedFull($id_ged, 'clicksing'));
					if (!isset($get_anexo) || empty($get_anexo)) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Erro ao obter documento.";
						throw new Exception(json_encode($retorno), 1);
					}

					$path_arquivo = $get_anexo[0]->path_root . $get_anexo[0]->path_objeto . DS . $get_anexo[0]->nome_hash;
					$path_arquivo = base64_encode($path_arquivo);
				} else {
					$id_ocorrencia = $this->parametros[0];
					$get_ocorrencia = json_decode($this->modelo->getOcorrencia(null, null, null, null, null, null, $id_ocorrencia));
					$usuario_cpf = json_decode($this->modelo->getUsuarios($get_ocorrencia[0]->id_usuario));
					$get_anexo = json_decode($this->modelo->gedDocumentoAnexo($id_ocorrencia, 'pessoal'));
				}

				$tipo_ocorrencia = str_replace('_', " ", $get_ocorrencia[0]->tipo);
				$tipo_ocorrencia = strtoupper($tipo_ocorrencia);
				$path_arquivo = $get_anexo[0]->path_root . $get_anexo[0]->path_objeto . DS . $get_anexo[0]->nome_hash;
				$path_arquivo = base64_encode($path_arquivo);
				if (($get_ocorrencia && $get_anexo) || ($get_anexo && $this->parametros[1])) {
					$retorno['codigo'] = 0;
					$retorno['input'] = $path_arquivo;
					$retorno['output'] = $get_anexo;
					$retorno['output2'] = $tipo_ocorrencia;
					$retorno['mensagem'] = "Sucesso em encontrar path do documento";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $usuario_cpf;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Sem documento anexado na ocorrência.";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function enviarToken($email_user, $mensagem_token, $id_token){
			// $controller_tarifa = new MainController(null, 'tarifador', false);
			// $api 			   = new Api($controller_tarifa);
			$parametros['tipo_destinatario'] = 'user';
			$parametros['email_to'] = $email_user;
			$parametros['mensagem'] = $mensagem_token;
			return $this->notificacoes->enviar('teams', $parametros);
		}

		function validaToken(){
			try {
				if (
					!isset($_POST['token_1']) || $_POST['token_1'] == "" || !isset($_POST['token_2']) || $_POST['token_2'] == "" ||
					!isset($_POST['token_3']) || $_POST['token_3'] == "" || $_POST['token_4'] == "" || !isset($_POST['token_4'])
				) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Preencha todos os digítos";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$valida_token = $_POST['token_1'] . $_POST['token_2'] . $_POST['token_3'] . $_POST['token_4'];
				}
				$id_token = $this->parametros[0];
				if (empty($id_token) || !isset($id_token)) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "ID Token null";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$token = json_decode($this->modelo->getToken($id_token));
					if (!isset($token) || empty($token)) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Erro ao obter token";
						throw new Exception(json_encode($retorno), 1);
					}
					$get_ocorrencia = json_decode($this->modelo->getOcorrencia(null, null, null, null, null, null, $token[0]->id_registro));
					if (!isset($get_ocorrencia) || empty($get_ocorrencia)) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Erro ao obter token";
						throw new Exception(json_encode($retorno), 1);
					}
				}

				if ($token[0]->token == $valida_token) {

					$update_token['status'] = "validado";
					$this->modelo->setTable('rh_token');
					$update_token = $this->modelo->save($update_token, $token[0]->id);

					if (!isset($update_token)) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Erro em validar token";
						throw new Exception(json_encode($retorno), 1);
					} else {

						$update_ocorrencia['status'] = 'aprovado';
						$update_ocorrencia['id_autorizado'] = $token[0]->id_responsavel;

						$this->modelo->setTable('rh_jornada_ocorrencia');
						$save_ocorrencia = $this->modelo->save($update_ocorrencia, $get_ocorrencia[0]->id);

						if (!$save_ocorrencia) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $_POST;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Erro em update ocorrência";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$update['status'] = "aprovado";
							$this->modelo->setTable('rh_registro_ponto');
							$update_registro = $this->modelo->save($update, $get_ocorrencia[0]->id_registro);

							if (!$update_registro) {
								$retorno['codigo'] = 1;
								$retorno['input'] = $_POST;
								$retorno['output'] = null;
								$retorno['mensagem'] = "Erro em update registro";
								throw new Exception(json_encode($retorno), 1);
							} else {
								$retorno['codigo'] = 0;
								$retorno['input'] = $valida_token;
								$retorno['output'] = $token;
								$retorno['mensagem'] = "Sucesso em validar registro!";
								throw new Exception(json_encode($retorno), 1);
							}
						}
					}
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Token invalido!";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function newJustificar(){
			include 'config_extras.php';
			try {
				$now = clone $this->data_hora_atual;
				if (!isset($_POST['tipo_ocorrencia']) || empty($_POST['tipo_ocorrencia'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro no tipo de ocorencia.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$tipo_ocorrencia = $_POST['tipo_ocorrencia'];
				}

				$this->obj_ponto->verificacoes($tipo_ocorrencia, $_POST);
				$insert = $this->obj_ponto->justificar($tipo_ocorrencia, $_POST, $_POST['funcionario']);
				$usuario = json_decode($this->modelo->getUsuarios($insert['id_usuario']));
				if (!isset($usuario)) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $insert;
					$retorno['output'] = null;
					$retorno['mensagem'] = 'Erro, usuário não encontrado.';
				}

				if ($insert['id_registro'] != null) {
					$ocorrencia = json_decode($this->modelo->getOcorrencia($insert['id_registro'], null, null, null, null, null, null, "R"));
				} else {
					$ocorrencia = json_decode($this->modelo->getOcorrencia(null, $insert['classe'], $insert['data'], '2', null, $insert['id_usuario']));
				}

				$this->modelo->setTable("rh_jornada_ocorrencia");
				if (isset($ocorrencia)) {
					$save = $this->modelo->save($insert, $ocorrencia[0]->id);
				} else {
					$save = $this->modelo->save($insert);
				}

				if (!$save) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $insert;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = 'Erro ao salvar ocorrência!';
					throw new Exception(json_encode($retorno), 1);
				} else {
					$boss = json_decode($this->modelo->getUsuarios($usuario[0]->boss));
					$digito = mt_rand(1000, 9999);
					$insert_token['token'] = $digito;
					$insert_token['id_registro'] = $save;
					$insert_token['id_usuario'] = $usuario[0]->id;
					$insert_token['id_responsavel'] = $usuario[0]->boss;
					$validade = $now->add(new DateInterval('P1D'));
					$insert_token['validade'] = $validade->format('Y-m-d H:i:s');
					$insert_token['status'] = 'pendente';
					$ocorrencia_token = json_decode($this->modelo->getOcorrenciaToken($save));
					$this->modelo->setTable('rh_token');
					if (isset($ocorrencia_token)) {
						$save_token = $this->modelo->save($insert_token, $ocorrencia_token[0]->id_token);
					} else {
						$save_token = $this->modelo->save($insert_token);
					}

					if ($save_token) {
						$ocorrencia = [
							'id' => $save,
							'tipo' => $VAR_SYSTEM['CODIGO_OCORRENCIA'][$insert['fonte'] . $insert['tipo']],
							'token' => $insert_token['token'],
							'data' => $this->data_hora_atual->format('d/m/Y'),
							'email_boss' => $boss[0]->email,
							'id_slack' => $boss[0]->id_slack,
						];
						$retorno_token = $this->obj_ponto->enviarNotificacao(null, $usuario, $ocorrencia);
						if ($retorno_token->codigo == 1) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $ocorrencia;
							$retorno['output'] = $retorno_token;
							$retorno['mensagem'] = $retorno_token->mensagem;
							throw new Exception(json_encode($retorno));
						} else {
							$retorno['codigo'] = 0;
							$retorno['input'] = $ocorrencia;
							$retorno['output'] = null;
							$retorno['mensagem'] = $retorno_token->mensagem;
							throw new Exception(json_encode($retorno));
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $insert;
						$retorno['output'] = $this->modelo->save;
						$retorno['mensagem'] = 'Erro ao gravar token na validação na tabela rh_token';
						throw new Exception(json_encode($retorno));
					}
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		// ASSINATURA DIGITAL
		function uploadToGed(){
			if (!is_dir(GED_PESSOAL)) {
				$retorno["codigo"] = 1;
				$retorno["input"] = GED_PESSOAL;
				$retorno["output"] = null;
				$retorno["mensagem"] = "Diretorio do GED não encontrado!";
				throw new Exception(json_encode($retorno), 1);
			}

			if (isset($_POST['data_documento']) && !empty($_POST['data_documento'])) {
				$data_documento = convertDate($_POST['data_documento']);
			} else {
				$retorno["codigo"] = 1;
				$retorno["input"] = $_POST;
				$retorno["output"] = null;
				$retorno["mensagem"] = "Informe a data do documento";
				throw new Exception(json_encode($retorno), 1);
			}

			if (isset($_POST['tipo_doc']) && !empty($_POST['tipo_doc'])) {
				$tipo_doc = $_POST['tipo_doc'];
			} else {
				$retorno["codigo"] = 1;
				$retorno["input"] = $_POST;
				$retorno["output"] = null;
				$retorno["mensagem"] = "Informe o tipo do documento";
				throw new Exception(json_encode($retorno), 1);
			}

			if (isset($_POST['subtipo_doc']) && !empty($_POST['subtipo_doc'])) {
				$subtipo_doc = $_POST['subtipo_doc'];
			} else {
				$retorno["codigo"] = 1;
				$retorno["input"] = $_POST;
				$retorno["output"] = null;
				$retorno["mensagem"] = "Informe o sub-tipo do documento";
				throw new Exception(json_encode($retorno), 1);
			}

			if (isset($_POST['obervacoes']) && !empty($_POST['obervacoes'])) {
				$obervacoes = $_POST['obervacoes'];
			} else {
				$obervacoes = null;
			}

			if (isset($_POST['funcionario']) && !empty($_POST['funcionario']) && is_numeric($_POST['funcionario'])) {
				$usuario = json_decode($this->modelo->getUsuarios($_POST['funcionario']));
				if (isset($usuario[0]->cpf) && !empty($usuario[0]->cpf)) {
					$config['pasta'] = GED_PESSOAL . $usuario[0]->cpf . DS . $tipo_doc;
				} else {
					$retorno["codigo"] = 1;
					$retorno["input"] = $_POST;
					$retorno["output"] = $this->modelo->info;
					$retorno["mensagem"] = "Usuário informado sem cpf, atualizar cpf do usuário!";
					throw new Exception(json_encode($retorno), 1);
				}
			} else {
				$retorno["codigo"] = 1;
				$retorno["input"] = $_POST;
				$retorno["output"] = $this->modelo->info;
				$retorno["mensagem"] = "Selecione um funcionario!";
				throw new Exception(json_encode($retorno), 1);
			}

			if (!isset($_FILES['name_upload_arquivo']['name']) || empty($_FILES['name_upload_arquivo']['name'])) {
				$retorno["codigo"] = 1;
				$retorno["input"] = $_POST;
				$retorno["output"] = $this->modelo->info;
				$retorno["mensagem"] = "Anexe o arquivo!";
				throw new Exception(json_encode($retorno), 1);
			}

			if (!is_dir(GED_PESSOAL . $usuario[0]->cpf)) {
				$mkdir = mkdir(GED_PESSOAL . $usuario[0]->cpf);
				if (!$mkdir) {
					$retorno["codigo"] = 1;
					$retorno["input"] = $_POST;
					$retorno["output"] = $this->modelo->info;
					$retorno["mensagem"] = "Não foi possivel criar um diretorio para este colaborador";
					throw new Exception(json_encode($retorno), 1);
				}
			}

			if (is_dir(GED_PESSOAL . $usuario[0]->cpf)) {
				$allow_files = array(
					'txt',
					'pdf',
					'png',
					'jpeg',
					'jpg',
					'xls',
					'xlsx',
					'doc',
					'docx',
					'gif',
					'csv',
					'vcard',
					'zip',
					'rar',
				);
				$tipo = explode("/", $_FILES['name_upload_arquivo']['type']);
				if (array_search($tipo[1], $allow_files)) {
					$data_hash = $this->data_hora_atual->format('YmdHis');
					$nome_hash = $tipo_doc . '_' . $subtipo_doc . '_' . $data_hash . '.' . $tipo[1];
					$nome_amigavel = $_FILES['name_upload_arquivo']['name'];
				} else {
					$retorno["codigo"] = 1;
					$retorno["input"] = $tipo[1];
					$retorno["output"] = $allow_files;
					$retorno["mensagem"] = "Tipo de arquivo não permitido";
					throw new Exception(json_encode($retorno), 1);
				}
			}

			$_FILES['name_upload_arquivo']['name'] = $nome_hash;
			$this->class_upload = new Upload($this, $_FILES['name_upload_arquivo'], $config);
			$this->class_upload->checkArquivo();

			$load = $this->class_upload->loadFile($_FILES['name_upload_arquivo'], $config);
			$retorno_json = json_decode($load);

			if ($retorno_json->codigo != 0) {
				$retorno["codigo"] = 1;
				$retorno["input"] = $retorno_json;
				$retorno["output"] = $retorno_json;
				$retorno["mensagem"] = "Erro em realizar upload.";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$insert_ged_documento = [
					'nome_documento' => $nome_hash,
					'data_documento' => $data_documento,
					'doc_origem' => 'pessoal',
					'id_origem' => null,
					'produto' => null,
					'tipo' => $tipo_doc,
					'subtipo' => $subtipo_doc,
					'descricao' => $obervacoes,
					'owner' => $usuario[0]->id,
					'data_criacao' => $this->data_hora_atual->format('Y-m-d H:i:s'),
				];

				$this->modelo->setTable('ged_documento');
				$save_ged_documento = $this->modelo->save($insert_ged_documento);
				if (!$save_ged_documento) {
					$retorno["codigo"] = 1;
					$retorno["input"] = $_POST;
					$retorno["output"] = $this->modelo->info;
					$retorno["mensagem"] = "Erro em salvar na tabela ged_documento.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$ged_documento = json_decode($this->modelo->gedDocumentoById($save_ged_documento));
					$path_documento = $config['pasta'] . DS . $nome_hash;
					$hash_arquivo = hash_file('md5', $path_documento);
					$insert_ged_anexo = [
						'id_documento' => $ged_documento[0]->id,
						'nome_amigavel' => $nome_amigavel,
						'path_root' => GED_PESSOAL,
						'path_objeto' => DS . $usuario[0]->cpf . DS . $tipo_doc . DS,
						'nome_hash' => $nome_hash,
						'hash_arquivo' => $hash_arquivo,
						'data_criacao' => $this->data_hora_atual->format('Y-m-d H:i:s'),
					];

					$this->modelo->setTable('ged_anexo');
					$save_ged_anexo = $this->modelo->save($insert_ged_anexo);
					if (!$save_ged_anexo) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $insert_ged_anexo;
						$retorno['output'] = $this->modelo->save;
						$retorno['mensagem'] = 'Erro ao salvar no ged_anexo';
						throw new Exception(json_encode($retorno));
					} else {
						$retorno['codigo'] = 0;
						$retorno['input'] = $insert_ged_anexo;
						$retorno['output'] = null;
						$retorno['mensagem'] = 'Sucesso.';
						throw new Exception(json_encode($retorno));
					}
				}
			}
		}

		function listarSignatarios(){
			try {
				if (isset($this->parametros[0]) && !empty($this->parametros[0])) {
					$document_key = $this->parametros[0];
				} elseif (isset($_POST['document_key']) && !empty($_POST['document_key'])) {
					$document_key = $this->parametros[0];
				} else {
					$retorno["codigo"] = 1;
					$retorno["input"] = $document_key;
					$retorno["output"] = null;
					$retorno["mensagem"] = 'Document key não informado';
					throw new Exception(json_encode($retorno), 1);
				}

				$chk_doc = json_decode($this->modelo->gedAnexosToAssinatura($document_key));

				if (!isset($chk_doc[0]->document_key) || empty($chk_doc[0]->document_key)) {
					$retorno["codigo"] = 1;
					$retorno["input"] = $document_key;
					$retorno["output"] = null;
					$retorno["mensagem"] = 'Documento não encontrado na base';
					throw new Exception(json_encode($retorno), 1);
				}

				if ($this->obj_assinatura->listarSignatarios($chk_doc[0]->document_key)) {
					$signatarios = $this->obj_assinatura->getOutPut();
					$retorno["codigo"] = 0;
					$retorno["input"] = $document_key;
					$retorno["output"] = $signatarios[0]->list;
					$retorno["mensagem"] = 'Sucesso';
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno["codigo"] = 1;
					$retorno["input"] = $document_key;
					$retorno["output"] = $this->obj_assinatura->getOutPut();
					$retorno["mensagem"] = 'Signatarios não encontrados';
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function downloadAssinado(){
			if (!isset($this->parametros[1]) || empty($this->parametros[1]) || !is_numeric($this->parametros[1])) {
				echo 'ID Documento invalido';
				exit;
			}

			$dados_documento = json_decode($this->modelo->gedAnexosToAssinatura($this->parametros[1]));
			if (isset($dados_documento[0]->document_key) && !empty($dados_documento[0]->document_key)) {
				$chk_plataforma = $this->obj_assinatura->download($dados_documento[0]->document_key);
				$chk_plataforma = $this->obj_assinatura->getOutput();
			} else {
				$chk_plataforma = null;
			}

			if ($chk_plataforma) {
				$link = $chk_plataforma->url;
			} elseif (isset($dados_documento[0]->nome_hash) && !empty($dados_documento[0]->nome_hash)) {
				$link = "/download_file.php?file=" . base64_encode($dados_documento[0]->path_root . $dados_documento[0]->path_objeto . '/' . $dados_documento[0]->nome_hash);
			} else {
				$link = null;
			}

			if ($link) {
				header('Location: ' . $link);
			} else {
				echo 'documento não encontrado';
			}
		}

		function enviarParaAssinatura($id_documento){
			try {
				if (isset($_POST['ids_doc']) && !empty($_POST['ids_doc'])) {
					$id_documento = $_POST['ids_doc'];
				} elseif (isset($this->parametros[1]) && !empty($this->parametros[1])) {
					$id_documento = $this->parametros[1];
				}

				if (is_array($id_documento)) {
					foreach ($id_documento as $key => $value) {
						$ged_documento = json_decode($this->modelo->gedAnexosToAssinatura($value));
						if (!$ged_documento) {
							$retorno["codigo"] = 1;
							$retorno["input"] = $id_documento;
							$retorno["output"] = $ged_documento;
							$retorno["mensagem"] = 'Documento ' . $value . ' não encontrado para enviar para assinatura';
							throw new Exception(json_encode($retorno), 1);
						}

						if (!$this->obj_assinatura->enviarParaAssinatura($ged_documento[0])) {
							$retorno["codigo"] = 1;
							$retorno["input"] = $id_documento;
							$retorno["output"] = $this->obj_assinatura->info;
							$retorno["mensagem"] = $this->obj_assinatura->erro;
							throw new Exception(json_encode($retorno), 1);
						}
					}
					$retorno["codigo"] = 0;
					$retorno["input"] = $id_documento;
					$retorno["output"] = null;
					$retorno["mensagem"] = 'Sucesso';
					throw new Exception(json_encode($retorno), 1);
				} else {
					$ged_documento = json_decode($this->modelo->gedAnexosToAssinatura($id_documento));

					if (!$ged_documento) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $id_documento;
						$retorno["output"] = $ged_documento;
						$retorno["mensagem"] = 'Documento ' . $id_documento . ' não encontrado';
						throw new Exception(json_encode($retorno), 1);
					}
					if ($this->obj_assinatura->enviarParaAssinatura($ged_documento[0])) {
						$retorno["codigo"] = 0;
						$retorno["input"] = $id_documento;
						$retorno["output"] = null;
						$retorno["mensagem"] = 'Sucesso';
						throw new Exception(json_encode($retorno), 1);
					} else {
						$retorno["codigo"] = 1;
						$retorno["input"] = $id_documento;
						$retorno["output"] = $this->obj_assinatura->info;
						$retorno["mensagem"] = $this->obj_assinatura->erro;
						throw new Exception(json_encode($retorno), 1);
					}
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function atualizaStatusAssinatura($document_key, $status){
			$status = $this->obj_assinatura->getNomeStatus($status);
			if (isset($document_key) && !is_array($document_key) && $status) {
				$update_documento['status'] = $status;
				$this->modelo->setTable('ged_clicksign_documento');
				$deleted_documento = $this->modelo->save($update_documento, $document_key, 'document_key');
				if (!$deleted_documento) {
					return false;
				}
				return true;
			} else {
				return false;
			}
		}

		function checkDocsAssinados(){
			$retorno_api = json_decode($this->obj_assinatura->checkDocsAssinados());
			if (isset($retorno_api->output) && is_array($retorno_api->output)) {
				foreach ($retorno_api->output as $key => $value) {
					if (isset($value->uuidDoc)) {
						$this->atualizaStatusAssinatura($value->uuidDoc, $value->statusId);
					}
				}
			}
		}

		/*
			Falta Implementar
			1 - inserir webhook em documento
			2 - tratar retorno do webhook
			3 - rotina de finalização dos documentos assinados
			4 - cancelar documentos ao serem apagaros do tarifador
			5 - Colocar versão assinada no GED documento
			*/

		function deleteDocs($id_documento){
			try {
				if (isset($_POST['ids_doc']) && !empty($_POST['ids_doc'])) {
					$id_documento = $_POST['ids_doc'];
				} elseif (isset($this->parametros[1]) && !empty($this->parametros[1])) {
					$id_documento = $this->parametros[1];
				}
				if (!isset($id_documento) || empty($id_documento)) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = 'IDs do documento não informado';
					throw new Exception(json_encode($retorno), 1);
				}

				if (isset($id_documento) && is_array($id_documento) && count($id_documento) < 1) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = 'O array com IDS não pode ser vazio!';
					throw new Exception(json_encode($retorno), 1);
				}

				if (is_array($id_documento)) {
					foreach ($id_documento as $key => $value) {
						if (is_numeric($value)) {
							$deleteAnexo = json_decode($this->deleteAnexo($value));
							if ($deleteAnexo->codigo == 1) {
								throw new Exception(json_encode($deleteAnexo), 1);
							}
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $value;
							$retorno['output'] = null;
							$retorno['mensagem'] = 'ID: ' . $value . ' do documento parece ser invalido';
							throw new Exception(json_encode($retorno), 1);
						}
					}
					$retorno['codigo'] = 0;
					$retorno['input'] = $value;
					$retorno['output'] = null;
					$retorno['mensagem'] = 'Sucesso';
					throw new Exception(json_encode($retorno), 1);
				} else {
					if (!is_numeric($id_documento)) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $id_documento;
						$retorno['output'] = null;
						$retorno['mensagem'] = 'ID: ' . $value . ' do documento parece ser invalido';
						throw new Exception(json_encode($retorno), 1);
					}
					$deleteAnexo = $this->deleteAnexo($id_documento);
					throw new Exception($deleteAnexo, 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function deleteAnexo($id_documento){
			try {
				if (isset($id_documento) && !is_array($id_documento) && is_numeric($id_documento)) {
					$dados_documento = json_decode($this->modelo->gedAnexoByIdDocumento($id_documento));
					// verificar se precisa cancelar na plataforma de assinatura, só permite apagar documento após cancelar na plataforma de assinatura
					if (!$dados_documento) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $id_documento;
						$retorno["output"] = $this->modelo->info;
						$retorno["mensagem"] = 'Dados do documento não encontrado';
						throw new Exception(json_encode($retorno), 1);
					}

					if (isset($dados_documento[0]->document_key) && !empty(($dados_documento[0]->document_key))) {
						if ($this->obj_assinatura->cancelarDocumento($dados_documento[0]->key_documento)) {

							$update_doc_ass['deleted'] = 1;
							$update_doc_ass['finalizado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');

							$update_anexo_ass['deleted'] = 1;
							$update_anexo_ass['finalizado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
							$update_anexo_ass['email_cancelamento'] = strtolower($this->obj_assinatura->info[0]->whoCanceled);

							if (isset($this->obj_assinatura->info[0]->statusName) && !empty($this->obj_assinatura->info[0]->statusName)) {
								$update_doc_ass['status'] = strtolower($this->obj_assinatura->info[0]->statusName);
								$update_anexo_ass['status'] = strtolower($this->obj_assinatura->info[0]->statusName);
							} else {
								$update_doc_ass['status'] = 'cancelado';
								$update_anexo_ass['status'] = 'cancelado';
							}

							$this->modelo->setTable('ged_clicksign_documento');
							$save_doc_ass = $this->modelo->save($update_doc_ass, $dados_documento[0]->key_documento, 'document_key');

							$this->modelo->setTable('ged_clicksign_assinatura');
							$save_anexo_ass = $this->modelo->save($update_anexo_ass, $dados_documento[0]->key_documento, 'key_documento');

							if (!$save_doc_ass || !$save_anexo_ass) {
								$retorno['codigo'] = 1;
								$retorno['input'] = $id_documento;
								$retorno["output"] = $this->modelo->info;
								$retorno["mensagem"] = 'Erro ao remover assinatura do documento da base de dados';
								throw new Exception(json_encode($retorno), 1);
							}
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $id_documento;
							$retorno["output"] = $this->obj_assinatura->info;
							$retorno["mensagem"] = $this->obj_assinatura->erro;
							throw new Exception(json_encode($retorno), 1);
						}
					}

					// cancelando anexo na base de dados
					$update_documento['alterado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
					$update_documento['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
					$update_documento['deleted'] = 1;

					$this->modelo->setTable('ged_anexo');
					$deleted_anexo = $this->modelo->save($update_documento, $id_documento, 'id_documento');

					$this->modelo->setTable('ged_documento');
					$deleted_documento = $this->modelo->save($update_documento, $id_documento);

					if ($deleted_anexo && $deleted_documento) {
						$retorno['codigo'] = 0;
						$retorno['input'] = $id_documento;
						$retorno["output"] = $this->modelo->info;
						$retorno["mensagem"] = 'Sucesso';
						throw new Exception(json_encode($retorno), 1);
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $id_documento;
						$retorno["output"] = $this->modelo->info;
						$retorno["mensagem"] = 'Erro ao remover documento da base de dados';
						throw new Exception(json_encode($retorno), 1);
					}
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = $dados_documento[0];
					$retorno['mensagem'] = 'ID do documento invalido!';
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function signView(){
			try {
				$session = json_decode($_SESSION['cmswerp']['userdata']->permissoes);
				$permissoes = json_decode($this->cl_permissoes->checkPermissoes('signView', 'metodo'));
				if (!$permissoes) {
					$retorno['codigo'] = 1;
					$retorno['input'] = 'espelhoView';
					$retorno['output'] = $permissoes;
					$retorno['mensagem'] = "Permissoes não encontradas para esta ação!";
					throw new Exception(json_encode($retorno), 1);
				} elseif ($permissoes->codigo != 0) {
					$retorno['codigo'] = 1;
					$retorno['input'] = 'espelhoView';
					$retorno['output'] = $permissoes;
					$retorno['mensagem'] = $permissoes->mensagem;
					throw new Exception(json_encode($retorno), 1);
				} elseif (isset($permissoes->output->permissoes) && $permissoes->output->permissoes < 1) {
					$retorno['codigo'] = 1;
					$retorno['input'] = 'espelhoView';
					$retorno['output'] = $permissoes;
					$retorno['mensagem'] = 'Você não tem acesso a este recurso!';
					throw new Exception(json_encode($retorno), 1);
				}

				// definindo permissoes do listview
				if ($permissoes->output == "master") {
					$lista_usuarios = json_decode($this->modelo->getUsuarios());
				} else {
					switch ($permissoes->output->alcadas) {
						case '2':
							$lista_usuarios = json_decode($this->modelo->getUsuarios(null, $_SESSION['cmswerp']['userdata']->id));
							break;
						case '4':
							$lista_usuarios = json_decode($this->modelo->getUsuarios());
							break;
						default:
							$lista_usuarios = json_decode($this->modelo->getUsuarios($_SESSION['cmswerp']['userdata']->id));
							break;
					}
				}

				if (isset($_POST['funcionario']) && !empty($_POST['funcionario'])) {
					$id_owner = $_POST['funcionario'];
				} else {
					$id_owner = null;
				}

				if (isset($_POST['periodo_ini']) && !empty($_POST['periodo_ini'])) {
					$data_ini = convertDate($_POST['periodo_ini']);
					$data_ini_view = $_POST['periodo_ini'];
				} else {
					$data_ini = null;
					$data_ini_view = $this->data_hora_atual->format('01/m/Y');
				}

				if (isset($_POST['periodo_fim']) && !empty($_POST['periodo_fim'])) {
					$data_fim = convertDate($_POST['periodo_fim']);
					$data_fim_view = $_POST['periodo_fim'];
				} else {
					$data_fim = null;
					$data_fim_view = $this->data_hora_atual->format('d/m/Y');
				}

				if (isset($_POST['search_tipo_doc']) && !empty($_POST['search_tipo_doc'])) {
					if ($_POST['search_tipo_doc'] == 'todos') {
						$search_tipo_doc = null;
					} else {
						$search_tipo_doc = $_POST['search_tipo_doc'];
					}
				} else {
					$search_tipo_doc = 'demonstrativo';
				}
				$ged_documento = json_decode($this->modelo->gedFullView('pessoal', $search_tipo_doc, $id_owner, $data_ini, $data_fim, null));
				if ($ged_documento) {
					foreach ($ged_documento as $key => $value) {
						if (isset($value->id_ged_anexo) && !empty($value->id_ged_anexo)) {
							$ged_ass[$value->id_ged_documento] = json_decode($this->modelo->gedFull($value->id_ged_documento));
							if (isset($ged_ass[$value->id_ged_documento]) && !empty($ged_ass[$value->id_ged_documento][0]->id_usuario)) {
								$signatario[$value->id_ged_documento] = $ged_ass[$value->id_ged_documento][0]->id_ged_anexo;
							}
							$path_arquivo[$value->id_ged_documento] = $value->path_root . $value->path_objeto . DS . $value->nome_hash;
							$path_arquivo[$value->id_ged_documento] = base64_encode($path_arquivo[$value->id_ged_documento]);
						}
					}
				}
				require_once ABSPATH . '/views/' . $this->nome_view . '/sign-view.php';
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function ListarCrofres(){
			$cofres = $this->obj_assinatura->listarCofres();
			require_once ABSPATH . '/views/' . $this->nome_view . '/cofres-view.php';
		}

		function listarDocumentosCofre(){
			if (isset($_POST['id_pasta']) && !empty($_POST['id_pasta'])) {
				$pasta_selecionada = $_POST['id_pasta'];
			} else {
				$pasta_selecionada = null;
			}

			if (isset($_POST['status_assinatura']) && !empty($_POST['status_assinatura'])) {
				$status_selecionado = $_POST['status_assinatura'];
			} else {
				$status_selecionado = null;
			}

			if (isset($this->parametros[1]) && !empty($this->parametros[1])) {
				$lista_pastas = json_decode($this->obj_assinatura->listarPastasCofre($this->parametros[1]));
				$documentos = json_decode($this->obj_assinatura->listarDocumentosCofre($this->parametros[1], $pasta_selecionada));
			}
			require_once ABSPATH . '/views/' . $this->nome_view . '/documentos-cofres-view.php';
		}

		function viewDocumentoCofre(){
			if (isset($this->parametros[1]) && !empty($this->parametros[1])) {
				$documento = json_decode($this->obj_assinatura->viewDocumento($this->parametros[1], $pasta_selecionada));
				if (isset($documento->output->url) && !empty($documento->output->url)) {
					header("location: " . $documento->output->url);
				} else {
					echo 'Erro na plataforma de assinatura!';
				}
			}
		}

		function localizarDocumentos(){
			if (isset($_POST['tipo_busca']) && !empty($_POST['tipo_busca'])) {
				$tipo_busca = $_POST['tipo_busca'];
			} else {
				$tipo_busca = null;
			}

			if (isset($_POST['id_busca']) && !empty($_POST['id_busca'])) {
				$id_busca = $_POST['id_busca'];
			} else {
				$id_busca = null;
			}

			switch ($tipo_busca) {
				case 'id_doc':
					$documentos = json_decode($this->obj_assinatura->viewDocumento($_POST['id_busca']));
					break;
				case 'status_assinatura':
					$documentos = json_decode($this->obj_assinatura->viewDocumentoPorStatus($_POST['id_busca']));
					break;
			}
			require_once ABSPATH . '/views/' . $this->nome_view . '/localizar-documento-view.php';
		}

		function listarAssinaturas(){
			try {
				if (isset($_POST['id_doc']) && !empty($_POST['id_doc'])) {
					if ($this->obj_assinatura->listarSignatarios($_POST['id_doc'])) {
						if (isset($this->obj_assinatura->output[0]->list) && count($this->obj_assinatura->output[0]->list) > 0) {
							$retorno['codigo'] = 0;
							$retorno['input'] = $_POST;
							$retorno['output'] = $this->obj_assinatura->output[0]->list;
							$retorno['mensagem'] = 'Sucesso';
							throw new Exception(json_encode($retorno), 1);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $_POST;
							$retorno['output'] = null;
							$retorno['mensagem'] = 'Nenhum signatario adicionado a esse documento';
							throw new Exception(json_encode($retorno), 1);
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = $this->obj_assinatura->info;
						$retorno['mensagem'] = $this->obj_assinatura->erro;
						throw new Exception(json_encode($retorno), 1);
					}
					$assinaturas = json_decode($this->obj_assinatura->listarSignatarios($this->parametros[1]));
					if ($documento->codigo == 0) {
						var_dump($_POST, $assinaturas);
					} else {
						throw new Exception(json_encode($assinaturas), 1);
					}
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "ID Documento não informado";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function insertGedRelatorio($dt_ini, $dt_fim, $departamento, $id_user, $diretorio){
			try {
				if (!is_object($dt_ini)) {
					$dt_ini = getDataAtual($dt_ini);
				}

				if (!is_object($dt_fim)) {
					$dt_fim = getDataAtual($dt_fim);
				}

				if (isset($id_user)) {
					$user = json_decode($this->modelo->getUsuarios($id_user));
					$sub_tipo = $user[0]->cpf;
					$tipo = "funcionario";
					$departamento = "INDIVIDUAL";
				} else {
					$sub_tipo = $departamento;
					$tipo = 'departamento';
				}

				$insert_db = [
					'periodo_ini' => $dt_ini->format('Y-m-d'),
					'periodo_fim' => $dt_fim->format('Y-m-d'),
					'id_usuario' => $id_user,
					'departamento' => $departamento,
					'data_criacao' => $this->data_hora_atual->format('Y-m-d h:i:s'),
				];

				$this->modelo->setTable('relatorio_ponto');
				$save_relatorio = $this->modelo->save($insert_db);
				if (!$save_relatorio) {
					$retorno["codigo"] = 1;
					$retorno["input"] = $mes_ano;
					$retorno["output"] = $this->modelo->info;
					$retorno["mensagem"] = "Erro em salvar na tabela relatorio de ponto.";
					throw new Exception(json_encode($retorno), 1);
				}
				$insert_ged_documento = [
					'nome_documento' => "relatorio_ponto_" . strtolower($tipo) . "_" . strtolower($sub_tipo) . "_" . $dt_ini->format('Y-m-d') . '-' . $dt_fim->format('Y-m-d'),
					'data_documento' => $this->data_hora_atual->format('Y-m-d'),
					'doc_origem' => 'relatorio_pessoal',
					'id_origem' => $save_relatorio,
					'produto' => null,
					'tipo' => 'relatorio_ponto',
					'subtipo' => $tipo,
					'descricao' => 'relatório de ponto - tipo: ' . $tipo . ' - periodo: ' . $dt_ini->format('Y-m-d') . ' - ' . $dt_fim->format('Y-m-d'),
					'owner' => $id_user,
					'data_criacao' => $this->data_hora_atual->format('Y-m-d H:i:s'),
				];
				$this->modelo->setTable('ged_documento');
				$save_ged_documento = $this->modelo->save($insert_ged_documento);
				if (!$save_ged_documento) {
					$retorno["codigo"] = 1;
					$retorno["input"] = $_POST;
					$retorno["output"] = $this->modelo->info;
					$retorno["mensagem"] = "Erro em salvar na tabela ged_documento.";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$path_documento = UP_GED . DS . 'relatorio_ponto' . DS . $tipo . DS . $sub_tipo . DS . $diretorio['nome_hash'];
					$hash_arquivo = hash_file('md5', $path_documento);
				}

				$insert_ged_anexo = [
					'id_documento' => $save_ged_documento,
					'nome_amigavel' => "relatorio_ponto_" . strtolower($tipo) . "_" . strtolower($sub_tipo) . "_" . $dt_ini->format('Y-m-d') . '-' . $dt_fim->format('Y-m-d'),
					'path_root' => UP_GED . DS . 'relatorio_ponto' . DS . strtolower($tipo),
					'path_objeto' => DS . strtolower($sub_tipo),
					'nome_hash' => $diretorio['nome_hash'],
					'hash_arquivo' => $hash_arquivo,
					'data_criacao' => $this->data_hora_atual->format('Y-m-d H:i:s'),
				];

				$this->modelo->setTable('ged_anexo');
				$save_ged_anexo = $this->modelo->save($insert_ged_anexo);
				if (!$save_ged_anexo) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $insert_ged_anexo;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = 'Erro ao salvar no ged_anexo';
					throw new Exception(json_encode($retorno));
				}

				$retorno['codigo'] = 0;
				$retorno['input'] = $diretorio['nome_hash'];
				$retorno['output'] = $diretorio['path'];
				$retorno['mensagem'] = 'Sucesso';
				throw new Exception(json_encode($retorno));
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function calculoSaldoHoras($total_carga_diaria, $saldo_anterior, $total_horas_pausas, $total_horas_extras, $total_abonos, $total_horas_diarias){
			$saldo_total = ($total_carga_diaria - $saldo_anterior + $total_horas_pausas - $total_horas_extras - $total_abonos - $total_horas_diarias);
			if ($saldo_total > 0) {
				if ($saldo_total < $saldo_anterior) {
					$debito = ($saldo_anterior - $saldo_total);
				} else if ($saldo_total > $saldo_anterior) {
					$debito = ($saldo_total + $saldo_anterior);
				} else {
					$debito = "00:00";
				}
			} else {
				$debito = ($saldo_anterior + $saldo_total);
			}

			if ($saldo_total == $saldo_anterior) {
				$retorno['debito'] = convertHorasMinutos($debito, 'decimal>horas', true);
			} elseif ($saldo_total > 0) {
				$retorno['debito'] = '- ' . convertHorasMinutos($debito, 'decimal>horas', true);
			} else {
				if ($saldo_total < 0) {
					if ($saldo_anterior > abs($saldo_total)) {
						$retorno['debito'] = '- ' . convertHorasMinutos($debito, 'decimal>horas', true);
					} else {
						$retorno['debito'] = '+ ' . convertHorasMinutos($debito, 'decimal>horas', true);
					}
				} else {
					$retorno['debito'] = '- ' . convertHorasMinutos($debito, 'decimal>horas', true);
				}
			}

			if ($saldo_total == 0) {
				$retorno['saldo_total'] = convertHorasMinutos($saldo_total, 'decimal>horas', true);
			} elseif ($saldo_total > 0) {
				$retorno['saldo_total'] = '- ' . convertHorasMinutos($saldo_total, 'decimal>horas', true);
			} else {
				$retorno['saldo_total'] = '+ ' . convertHorasMinutos($saldo_total, 'decimal>horas', true);
			}

			if ($saldo_anterior < 0) {
				$retorno['credito'] = "-" . convertHorasMinutos($saldo_anterior, 'decimal>horas', true);
			} else {
				$retorno['credito'] = "+" . convertHorasMinutos($saldo_anterior, 'decimal>horas', true);
			}
			return $retorno;
		}

		//By: Caio Freitas - 24/01/2023	
		function deletarOcorrencia(){
			try {
				if (!isset($this->parametros[0]) || empty($this->parametros[0])) {
					$retorno["codigo"] = 1;
					$retorno["input"] = $this->parametros;
					$retorno["output"] = null;
					$retorno["mensagem"] = "Erro id_ocorrência null";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$id_ocorrencia = $this->parametros[0];
				}

				$ocorrencia = json_decode($this->modelo->getOcorrenciaById($id_ocorrencia));

				if (!isset($ocorrencia) || empty($ocorrencia)) {
					$retorno["codigo"] = 1;
					$retorno["input"] = $this->parametros;
					$retorno["output"] = $id_ocorrencia;
					$retorno["mensagem"] = "Erro em obter ocorrência";
					throw new Exception(json_encode($retorno), 1);
				}

				$param['deleted'] = 1;
				$this->modelo->setTable('rh_jornada_ocorrencia');
				$save = $this->modelo->save($param, $id_ocorrencia);

				if (!$save) {
					$retorno["codigo"] = 1;
					$retorno["input"] = $this->parametros;
					$retorno["output"] = $id_ocorrencia;
					$retorno["output"] = $this->modelo->info;
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno["codigo"] = 0;
					$retorno["input"] = $this->parametros;
					$retorno["output"] = $id_ocorrencia;
					$retorno["mensagem"] = "Sucesso";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exceprion $e) {
				echo $e->getMessage();
			}
		}

		function relatorios(){
			$parametros['agrupar'] = null;
			$dt_ini = getDataAtual();
			if (isset($_POST['tipo_relatorio']) && !empty($_POST['tipo_relatorio'])) {
				$parametros['tipo_relatorio'] = $_POST['tipo_relatorio'];
			} else {
				$parametros['tipo_relatorio'] = 'fechamento';
			}

			if (isset($_POST['data_ini']) && !empty($_POST['data_ini'])) {
				$data_ini = getDataAtual(convertDate($_POST['data_ini']));
			} else {
				$data_ini = getDataAtual();
				$data_ini->sub(new DateInterval('P1D'));
			}

			if (isset($_POST['data_fim']) && !empty($_POST['data_fim'])) {
				$data_fim = getDataAtual(convertDate($_POST['data_fim']));
			} else {
				$data_fim = getDataAtual();
				$data_fim->sub(new DateInterval('P1D'));
			}

			if (isset($_POST['agrupar']) && !empty($_POST['agrupar'])) {
				$parametros['agrupar'] = $_POST['agrupar'];
			}

			if (isset($_POST['funcionario']) && !empty($_POST['funcionario']) && is_numeric($_POST['funcionario'])) {
				$parametros['funcionario'] = $_POST['funcionario'];
			} else {
				$parametros['funcionario'] = $_SESSION['cmswerp']['userdata']->id;
			}

			if (isset($_POST['departamento']) && !empty($_POST['departamento'])) {
				$parametros['departamento'] = $_POST['departamento'];
			}

			$lista_usuarios = json_decode($this->modelo->getUsuarios());
			$departamento = json_decode($this->modelo->getUsuarios(null, null, null, true));
			if (isset($parametros['tipo_relatorio']) && !empty($parametros['tipo_relatorio'])) {
				switch ($parametros['tipo_relatorio']) {
					case 'fechamento':
						if (isset($_POST['agrupar']) && !empty($_POST['agrupar'])) {
							$this->obj_ponto = new RhPonto($this, $parametros['funcionario']);
							$this->obj_ponto->checkUltimoFechamento();
							$this->obj_ponto->gerarEspelho($data_ini, $data_fim, $parametros['tipo_relatorio']);
							if ($this->obj_ponto->ultimo_fechamento) {
								$data_ini = getDataAtual($this->obj_ponto->ultimo_fechamento['periodo_fim']);
								$data_ini->setTime(00, 00, 00);
								$data_ini->modify('+1 day');
							}
						}
						break;
				}
			}
			$parametros['relatorio_ini'] = $data_ini->format('Y-m-d');
			$parametros['relatorio_fim'] = $data_fim->format('Y-m-d');
			$url_report = URL_SISTEMA . 'report/viewPonto/?' . http_build_query($parametros);
			$dados = CurlExec($url_report);
			require_once ABSPATH . '/views/' . $this->nome_view . '/relatorio-view.php';
		}

		function gerarpdf(){
			try {
				ini_set('max_execution_time', '300');
				ini_set("pcre.backtrack_limit", "500000000");
				switch ($_SERVER['REQUEST_METHOD']) {
					case 'GET':
						$request = filter_input_array(INPUT_GET, FILTER_DEFAULT);
						break;
					case 'POST':
						$request = filter_input_array(INPUT_POST, FILTER_DEFAULT);
						break;
				}

				$parametros['agrupar'] = null;
				$dt_ini = getDataAtual();
				if (isset($request['data_ini']) && !empty($request['data_ini'])) {
					$data_ini = $request['data_ini'];
				} else {
					$data_ini = $dt_ini->format('d/m/Y');
				}

				if (isset($request['data_fim']) && !empty($request['data_fim'])) {
					$data_fim = $request['data_fim'];
				} else {
					$data_fim = $dt_ini->format('d/m/Y');
				}

				if (isset($request['agrupar']) && !empty($request['agrupar'])) {
					$parametros['agrupar'] = $request['agrupar'];
				}

				if (isset($request['agrupar']) && !empty($request['agrupar'])) {
					$parametros['agrupar'] = $request['agrupar'];
				}

				if (isset($request['funcionario']) && !empty($request['funcionario'])) {
					$parametros['funcionario'] = $request['funcionario'];
				}

				if (isset($request['departamento']) && !empty($request['departamento'])) {
					$parametros['departamento'] = $request['departamento'];
				}

				$parametros['relatorio_ini'] = convertDate($data_ini);
				$parametros['relatorio_fim'] = convertDate($data_fim);
				$url_report = URL_SISTEMA . 'report/viewPonto/?' . http_build_query($parametros);
				$dados = CurlExec($url_report);
				if ($dados) {
					$dados_usuario = json_decode($this->modelo->getUsuarios($parametros['funcionario']));
					$path1 = ABSPATH . DS . 'temp_files' . DS . 'pessoal' . DS;
					if ($parametros['agrupar'] == 'departamento') {
						if (!file_exists($path1 . DS . 'departamento')) {
							if (!mkdir($path1 . DS . 'departamento')) {
								echo 'Erro ao criar diretorio COD: 5671 ';
								return;
							}
						}
						;
						$path2 = DS . 'departamento' . DS . strtolower(str_replace(' ', '_', $parametros['departamento'])) . DS;
						$file_name = 'espelho_' . strtolower(str_replace(' ', '_', $parametros['departamento'])) . '_' . $this->data_hora_atual->format('YmdHis') . '.pdf';
					} else {
						$path2 = $dados_usuario[0]->cpf . DS;
						$file_name = 'espelho_' . $dados_usuario[0]->cpf . '_' . $this->data_hora_atual->format('YmdHis') . '.pdf';
					}

					if (!file_exists($path1)) {
						if (!mkdir($path1)) {
							echo 'Erro ao criar diretorio COD: 5684 ';
							return;
						}
					}

					if (!file_exists($path1 . $path2)) {
						if (!mkdir($path1 . $path2)) {
							echo 'Erro ao criar diretorio COD: 5691 ';
							return;
						}
					}

					require_once "libs/mpdf/vendor/autoload.php";
					$mpdf = new \Mpdf\Mpdf();
					$style_documento = file_get_contents('assets/css/css_relatorio.css');
					set_time_limit(300);
					$mpdf->SetHeader();
					$mpdf->WriteHTML($style_documento, \Mpdf\HTMLParserMode::HEADER_CSS);
					$mpdf->WriteHTML($dados);
					$mpdf->Output($path1 . $path2 . $file_name, 'F');
					$mpdf->Output($file_name . '.pdf', 'D');
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function viewRelatorioFechamento(){
			$parametros['tipo_relatorio'] = null;
			$usuarios = null;
			$dt_ini = getDataAtual();
			$lista_usuarios = json_decode($this->modelo->getUsuarios());
			if (isset($_POST) && !empty($_POST)) {
				if (isset($_POST['tipo_relatorio']) && !empty($_POST['tipo_relatorio'])) {
					$parametros['tipo_relatorio'] = $_POST['tipo_relatorio'];
				}

				if (isset($_POST['funcionario']) && !empty($_POST['funcionario'])) {
					$parametros['funcionario'] = $_POST['funcionario'];
				}

				if (isset($_POST['departamento']) && !empty($_POST['departamento'])) {
					$parametros['departamento'] = $_POST['departamento'];
				}

				if (isset($parametros['funcionario']) && !empty($parametros['funcionario']) && is_numeric($parametros['funcionario'])) {
					$usuarios = json_decode($this->modelo->getJornadaUsuarioById($parametros['funcionario']));
				}
			}

			if ($usuarios) {
				foreach ($usuarios as $key => $value) {
					$fechamento = json_decode($this->modelo->getFechamentoByUsuario($value->id_usuario));
					if ($fechamento) {
						foreach ($fechamento as $key => $value) {
							$dados[] = $value;
						}
					}
				}
			}
			require_once ABSPATH . '/views/' . $this->nome_view . '/fechamento-relatorio-view.php';
		}

		function viewFechamento(){
			$parametros['tipo_relatorio'] = null;
			$dt_ini = getDataAtual();
			$lista_usuarios = json_decode($this->modelo->getUsuarios());
			if (isset($_POST) && !empty($_POST)) {

				if (isset($_POST['tipo_relatorio']) && !empty($_POST['tipo_relatorio'])) {
					$parametros['tipo_relatorio'] = $_POST['tipo_relatorio'];
				}

				if (isset($_POST['funcionario']) && !empty($_POST['funcionario']) && is_numeric($_POST['funcionario'])) {
					$usuarios = json_decode($this->modelo->getJornadaUsuarioById($_POST['funcionario']));
				}

				if (isset($_POST['departamento']) && !empty($_POST['departamento'])) {
					$parametros['departamento'] = $_POST['departamento'];
				}

				if ($usuarios) {
					foreach ($usuarios as $key => $value) {
						$id_usuario = $value->id_usuario;
						$fechamento = json_decode($this->modelo->getUltimoFechamento($value->id_usuario));
						$dados[$id_usuario]['nome'] = $value->nome;
						$dados[$id_usuario]['departamento'] = $value->departamento;
						$dados[$id_usuario]['status'] = $value->status;
						if ($fechamento) {
							$dados[$id_usuario]['id_usuario'] = $fechamento[0]->id_usuario;
							$dados[$id_usuario]['ultima_data'] = $fechamento[0]->periodo_fim;
							$dados[$id_usuario]['id_anexo'] = $fechamento[0]->id_anexo;
							$dados[$id_usuario]['saldo'] = $fechamento[0]->saldo_fechamento;
						} else {
							$jornada = json_decode($this->modelo->getPrimeiraJornadaByUsuario($value->id_usuario));
							$dados[$id_usuario]['id_usuario'] = $jornada[0]->id_usuario;
							$dados[$id_usuario]['ultima_data'] = $jornada[0]->data_inicio;
							$dados[$id_usuario]['id_anexo'] = null;
						}
					}
				}
			}
			require_once ABSPATH . '/views/' . $this->nome_view . '/fechamento-view.php';
		}

		function processarFechamento(){
			try {
				$sucesso = false;
				$retorno['codigo'] = 1;
				$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);
				if (!$dados) {
					$dados = filter_input_array(INPUT_GET, FILTER_DEFAULT);
				}

				if (isset($dados['data_fechamento']) && !empty($dados['data_fechamento'])) {
					$data_fechamento = getDataAtual($dados['data_fechamento']);
				} else {
					$retorno['mensagem'] = 'INFORME A DATA PARA O FECHAMENTO';
					throw new Exception(json_encode($retorno), 1);
				}

				if (isset($dados['ids_usuario']) && count($dados['ids_usuario']) > 0) {
					foreach ($dados['ids_usuario'] as $key => $value) {
						$fechamento = json_decode($this->modelo->getFechamentoByUsuario($value));
						if ($fechamento) {
							$ultima_data = $fechamento[0]->periodo_fim;
							$ultima_data = getdataAtual($ultima_data);
							$ultima_data->modify('+1 day');
							$nome_colaborador = $fechamento[0]->nome_usuario;
						} else {
							$jornada = json_decode($this->modelo->getPrimeiraJornadaByUsuario($value));
							$ultima_data = $jornada[0]->data_inicio;
							$ultima_data = getdataAtual($ultima_data);
							$nome_colaborador = $jornada[0]->nome_usuario;
						}

						if ($data_fechamento <= $ultima_data) {
							$retorno['mensagem'] = 'DATA DE FECHAMENTO EM CONFLITO COM ULTIMO FECHAMENTO PARA ' . $nome_colaborador . ' PROXIMO PERIODO A PARTIR DE ' . $ultima_data->format('Y-m-d');
							throw new Exception(json_encode($retorno), 1);
						}

						$data_fechamento = getdataAtual($dados['data_fechamento']);
						$this->obj_ponto = new RhPonto($this, $value);
						$this->obj_ponto->gerarEspelho($ultima_data->format('Y-m-d'), $data_fechamento->format('Y-m-d'));
						$param['id_usuario'] = $value;
						$param['periodo_ini'] = $ultima_data->format('Y-m-d');
						$param['periodo_fim'] = $data_fechamento->format('Y-m-d');
						$param['saldo_fechamento'] = $this->obj_ponto->calendario['total']['saldo'];
						$param['json_fechamento'] = base64_encode(json_encode($this->obj_ponto->calendario));
						$param['status'] = 'a';
						$param['alterado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
						$param['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
						$param['deleted'] = 0;
						$is_save = $this->obj_ponto->saveFechamento($param);
						if ($is_save) {
							$param['id_fechamento'] = $is_save;
							$param['dados_usuario'] = json_encode($this->obj_ponto->user);
							$param['resumo_jornada'] = json_encode($this->obj_ponto->resumo_jornada);
							$is_save = json_decode($this->obj_ponto->savePdfEspelho($param));
							unset($param['id_fechamento']);
							unset($param['dados_usuario']);
							unset($param['resumo_jornada']);
							if ($is_save->codigo == 0) {
								$sucesso = true;
							} else {
								$retorno['mensagem'] = $is_save->mensagem;
								throw new Exception(json_encode($retorno), 1);
							}
						} else {
							$retorno['mensagem'] = 'ERRO AO SALVAR NO BD PARA USUARIO ' . strtoupper($nome_colaborador);
							throw new Exception(json_encode($retorno), 1);
						}
					}
				} else {
					$retorno['mensagem'] = 'SELECIONE AO MENOS UM USUARIO PARA O FECHAMENTO';
					throw new Exception(json_encode($retorno), 1);
				}

				if ($sucesso) {
					$retorno['codigo'] = 0;
					$retorno['mensagem'] = 'Sucesso';
				} else {
					$retorno['mensagem'] = 'Erro desconhecido';
				}
				throw new Exception(json_encode($retorno), 1);
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function apagarFechamento(){
			try {
				$retorno['codigo'] = 0;
				$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);
				if (!$dados) {
					$dados = filter_input_array(INPUT_GET, FILTER_DEFAULT);
				}

				if (isset($dados['ids_fechamento']) && !empty($dados['ids_fechamento'])) {
					foreach ($dados['ids_fechamento'] as $key => $value) {
						if (is_numeric($value)) {
							$param['deleted'] = 1;
							$this->modelo->setTable('rh_fechamento_ponto');
							$is_delete = $this->modelo->save($param, $value);
							if (!$is_delete) {
								$retorno['codigo'] = 1;
								$retorno['mensagem'] = 'Erro ao deletar o fechamento de ID numero ' . $value;
								throw new Exception(json_encode($retorno), 1);
							}
						} else {
							$retorno['codigo'] = 1;
							$retorno['mensagem'] = 'ID numero ' . $value . ' invalido ';
							throw new Exception(json_encode($retorno), 1);
						}
					}
				} else {
					$retorno['codigo'] = 1;
					$retorno['mensagem'] = 'Informe os fechamentos a serem apagados';
					throw new Exception(json_encode($retorno), 1);
				}
				$retorno['codigo'] = 0;
				$retorno['mensagem'] = 'Sucesso';
				throw new Exception(json_encode($retorno), 1);
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		//By - Caio Freitas - 11/08/2023
		function bancoHoras($data, $id_usuario = null, $id_boss = null, $departamento = null){
			$week = primeiroUltimoDiaSemana($data);
			$data_ini = $week['first_week'];
			$data_fim = $week['last_week'];
			$dados_geral = $this->saldoDia($data_ini, $data_fim, $id_usuario, $id_boss, $departamento);
			$horas = $dados_geral->user[3000000]["ponto"]["horas_previstas"] - $dados_geral->user[3000000]["ponto"]["saldo_parcial"];

			if (isset($dados_geral->user) && !empty($dados_geral->user)) {
				foreach ($dados_geral->user as $key => $value) {
					if (isset($key) && !empty($key)) {
						if ($value['diario'][$data]['jornada']['entrada'] <= "12:00") {
							if (isset($value['diario'][$data]['marcacoes']) && !empty($value['diario'][$data]['marcacoes'])) {
								foreach ($value['diario'][$data]['marcacoes'] as $k1 => $v1) {
									foreach ($v1 as $k2 => $v2) {
										if ($v2->tipo_marcacao == "B04") {
											if ($v2->hora_marcacao > "22:00") {
												$return['apos_horario_nucleo'][$key]->noturno = true;
												$return['apos_horario_nucleo'][$key]->registro = $v2->hora_marcacao;
												$return['apos_horario_nucleo'][$key]->nome = $value["dados"]->nome;
												$return['apos_horario_nucleo'][$key]->departamento = $value["dados"]->departamento;
												$return['apos_horario_nucleo'][$key]->chefe = $value["dados"]->nome_chefe;
											}
										}
									}
								}
							}
						}

						if (isset($value["diario"]) && !empty($value['diario'])) {
							if (isset($value["diario"][$data]) && !empty($value["diario"][$data])) {
								if ($value['diario'][$data]['dia_util'] == true) {
									if ($value["diario"][$data]['saldo'][0] > 60) {
										$return['diario'][$key]->id = $key;
										$return['diario'][$key]->nome = $value["dados"]->nome;
										$return['diario'][$key]->departamento = $value["dados"]->departamento;
										$return['diario'][$key]->chefe = $value["dados"]->nome_chefe;
										$return['diario'][$key]->saldo = convertHorasMinutos($value["diario"][$data]['saldo'][0], 'decimal>horas', true);
									}
								}
							}
						}

						if (isset($value["ponto"]["saldo_parcial"])) {
							if (isset($value["diario"][$data]["jornada"]) && !empty($value["diario"][$data]["jornada"])) {
								$return['semanal'][$key]->id = $key;
								$return['semanal'][$key]->nome = $value["dados"]->nome;
								$return['semanal'][$key]->departamento = $value["dados"]->departamento;
								$return['semanal'][$key]->chefe = $value["dados"]->nome_chefe;
								$return['semanal'][$key]->periodo = convertDate($data_ini) . " - " . convertDate($data_fim);
								$return['semanal'][$key]->saldo = convertHorasMinutos($value["ponto"]["saldo_parcial"], 'decimal>horas', true);
							}
						}

						if (isset($value["diario"]) && !empty($value['diario'])) {
							if (isset($value["diario"][$data]) && !empty($value["diario"][$data])) {
								if ($value['diario'][$data]['dia_util'] == true) {
									if (!isset($value['diario'][$data]['marcacoes']) || empty($value['diario'][$data]['marcacoes'])) {
										$return['falta'][$key]->falta = true;
										$return['falta'][$key]->id = $key;
										$return['falta'][$key]->nome = $value["dados"]->nome;
										$return['falta'][$key]->departamento = $value["dados"]->departamento;
										$return['falta'][$key]->chefe = $value["dados"]->nome_chefe;
										$return['falta'][$key]->jornada = $value["diario"][$data]["jornada"]["nome_jornada"];
									}
								}
							}
						}
					}
				}
			}
			return $return;
		}

		//By - Caio Freitas - 11/08/2023
		function saldoDia($data_ini, $data_fim, $id_usuario = null, $id_boss = null, $departamento = null){
			$usuario = json_decode($this->modelo->getUser($id_usuario, $id_boss, $departamento));
			if (isset($usuario) && !empty($usuario)) {
				foreach ($usuario as $key => $value) {
					$this->obj_ponto = new RhPonto($this, $value->id); //jornada noturna				
					$this->obj_ponto->gerarEspelho($data_ini, $data_fim, "diario");
					if (isset($this->obj_ponto->user) && !empty($this->obj_ponto->user)) {
						$user = $this->obj_ponto->user;
						$i1 = $user->id;
						$resumo->user[$i1]['dados'] = $user;
						$resumo->user[$i1]['ponto'] = $this->obj_ponto->calendario['total'];
						$resumo->user[$i1]['diario'] = $this->obj_ponto->calendario['diario'];
					}
				}
			}
			return $resumo;
		}

		function ajaxAlerta(){
			try {
				include "config_extras.php";
				$dicionario_alerta = $VAR_SYSTEM['ALERTAS'];

				if (isset($_POST['tipo']) && !empty($_POST['tipo'])) {
					$tipo = $_POST['tipo'];
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro parâmetros tipo";
					throw new Exception(json_encode($retorno), 1);
				}

				if (isset($_POST['data']) && !empty($_POST['data'])) {
					$data = $_POST['data'];
					$obj_data = getDataAtual($data);
					if ($obj_data->format('Y-m-d') >= $this->data_hora_atual->format('Y-m-d')) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Data deve ser menor que a data atual (" . convertDate($this->data_hora_atual->format('Y-m-d')) . ") para dispara alertas.";
						throw new Exception(json_encode($retorno), 1);
					}
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro parâmetros de data";
					throw new Exception(json_encode($retorno), 1);
				}

				if (isset($_POST['id_usuario']) && !empty($_POST['id_usuario'])) {
					$id_usuario = $_POST['id_usuario'];
				} else {
					$id_usuario = null;
				}

				if (isset($_POST['id_boss']) && !empty($_POST['id_boss'])) {
					$id_boss = $_POST['id_boss'];
				} else {
					$id_boss = null;
				}

				if (isset($_POST['departamento']) && !empty($_POST['departamento'])) {
					$departamento = strtolower($_POST['departamento']);
				} else {
					$departamento = null;
				}

				$banco = $this->bancoHoras($data, $id_usuario, $id_boss, $departamento);
				if (isset($banco) && !empty($banco)) {
					if (isset($banco[$tipo]) && !empty($banco[$tipo])) {
						$retorno_alerta = json_decode($this->dispararAlerta($banco[$tipo], $obj_data->format('Y-m-d'), $tipo));
						if ($retorno_alerta->codigo == 0) {
							$retorno = $this->insertAlerta("ponto", $tipo, $obj_data->format('Y-m-d'), $id_usuario, $id_boss, $departamento);
							throw new Exception($retorno, 1);
						} else {
							throw new Exception(json_encode($retorno_alerta), 1);
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Alerta de " . $dicionario_alerta[$tipo] . " não existe para essa data " . convertDate($data);
						throw new Exception(json_encode($retorno), 1);
					}
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Dados para disparo de alerta não encontrado";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				echo $e->getMessage();
			}
		}

		function dispararAlerta($dados, $data, $tipo){
			try {
				if (isset($dados) && !empty($dados)) {
					foreach ($dados as $key => $value) {
						$boss = json_decode($this->modelo->getBoss(null, $key));
						if (isset($boss) && !empty($boss)) {
							switch ($tipo) {
								case 'falta':
									$parametros['user'] = $boss[0]->email_chefe;
									$parametros['mensagem'] = "O funcionário " . strtoupper($boss[0]->nome) . " não registrou ponto no dia " . convertDate($data) . " dentro da sua escala de trabalho.";
									break;
								case 'diario':
									$parametros['user'] = $boss[0]->email_chefe;
									$parametros['mensagem'] = "O funcionário " . strtoupper($boss[0]->nome) . " fez " . $value->saldo . " de banco de horas no dia " . convertDate($data);
									break;
								case 'apos_horario_nucleo':
									$parametros['user'] = $boss[0]->email_chefe;
									$parametros['mensagem'] = "O funcionário " . strtoupper($boss[0]->nome) . " registrou após às 22:00 no horário de " . $value->registro . " no dia " . convertDate($data);
									break;
								case 'semanal':
									$parametros['user'] = $boss[0]->email_chefe;
									$parametros['mensagem'] = "O funcionário " . strtoupper($boss[0]->nome) . " acumulou o total de " . $value->saldo . " na semana de " . $value->periodo;
									break;
								default:
									$retorno['codigo'] = 1;
									$retorno['input'] = $dados;
									$retorno['output'] = $boss;
									$retorno['mensagem'] = "Error encontrar tipo de disparo de alerta";
									throw new Exception(json_encode($retorno), 1);
									break;
							}

							$this->obj_notificacao->alertaTeams("ponto_marcacao", $parametros);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $dados;
							$retorno['output'] = $user;
							$retorno['mensagem'] = "Error ao encontrar BOSS";
							throw new Exception(json_encode($retorno), 1);
						}
					}

					$retorno['codigo'] = 0;
					$retorno['input'] = $dados;
					$retorno['output'] = $parametros;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $dados;
					$retorno['output'] = $user;
					$retorno['mensagem'] = "Error em marcação ausente";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function insertAlerta($objeto, $tipo, $data, $id_usuario = null, $id_boss = null, $departamento = null, $rotina = false){
			try {
				$alerta = json_decode($this->modelo->getAlertas($objeto, $tipo, $data, $id_usuario, $id_boss, $departamento));
				if (isset($alerta) && !empty($alerta)) {
					$id_alerta = $alerta[0]->id;
				} else {
					$id_alerta = null;
				}

				if (isset($id_usuario) && !empty($id_usuario)) {
					$insert['id_usuario'] = $id_usuario;
				} else {
					$insert['id_usuario'] = 0;
				}

				if (isset($id_boss) && !empty($id_boss)) {
					$insert['id_boss'] = $id_boss;
				} else {
					$insert['id_boss'] = 0;
				}

				if (isset($departamento) && !empty($departamento)) {
					$insert['tipo'] = $departamento;
				}
				$insert['objeto'] = $objeto;
				$insert['grupo'] = $tipo;
				$insert['data'] = $data;
				$insert['data_hora'] = $this->data_hora_atual->format("Y-m-d H:i:s");
				if ($rotina == true) {
					$insert['alterado_por'] = 0;
				}

				$this->modelo->setTable("alertas");
				$save = $this->modelo->save($insert, $id_alerta);
				if ($save) {
					$retorno['codigo'] = 0;
					$retorno['input'] = $insert;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $insert;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro em salvar info na tabela alertas";
					throw new Exception(json_encode($retorno), 1);
				}
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function rotinaAlerta($dados, $data, $tipo = null){
			try {
				if (isset($dados) && !empty($dados)) {
					$tipo_alerta = "ponto_marcacao";
					if (isset($tipo) && !empty($tipo)) {
						$parametros['user'] = "caio.freitas@cmsw.com";
						switch ($tipo) {
							case 'falta':
								$parametros['mensagem'] = "**** ROTINA DE FALTA  - " . convertDate($data) . " ****";
								break;
							case 'diario':
								$parametros['mensagem'] = "**** ROTINA DE BANCO DIARIO  - " . convertDate($data) . " ****";
								break;
							case 'apos_horario_nucleo':
								$parametros['mensagem'] = "**** ROTINA REGISTRO APÓS ÀS 22H00  - " . convertDate($data) . " ****";
								break;
							case 'semanal':
								$parametros['mensagem'] = "**** ROTINA BANCO SEMANAL  - " . convertDate($data) . " ****";
								break;
							default:
								$parametros['mensagem'] = "**** ERROR - ROTINA SEM TIPO  - " . convertDate($data) . " ****";
								break;
						}
						$this->obj_notificacao->alertaTeams("rotina_alerta", $parametros);


						if (isset($dados[$tipo]) && !empty($dados[$tipo])) {
							foreach ($dados[$tipo] as $key => $value) {
								$boss = json_decode($this->modelo->getBoss(null, $key));
								switch ($tipo) {
									case 'falta':
										$parametros['user'] = $boss[0]->email_chefe;
										$parametros['mensagem'] = "O funcionário (a) " . strtoupper($boss[0]->nome) . " não registrou ponto no dia " . convertDate($data) . " dentro da sua escala de trabalho.";
										break;
									case 'diario':
										$parametros['user'] = $boss[0]->email_chefe;
										$parametros['mensagem'] = "O funcionário (a) " . strtoupper($boss[0]->nome) . " fez " . $value->saldo . " de banco de horas no dia " . convertDate($data);
										break;
									case 'apos_horario_nucleo':
										$parametros['user'] = $boss[0]->email_chefe;
										$parametros['mensagem'] = "O funcionário (a) " . strtoupper($boss[0]->nome) . " registrou após às 22:00 no horário de " . $value->registro . " no dia " . convertDate($data);
										break;
									case 'semanal':
										$parametros['user'] = $boss[0]->email_chefe;
										$parametros['mensagem'] = "O funcionário (a) " . strtoupper($boss[0]->nome) . " acumulou o total de " . $value->saldo . " na semana de " . $value->periodo;
										break;
									default:
										$tipo_alerta = "rotina_alerta";
										$parametros['user'] = "caio.freitas@cmsw.com";
										$parametros['mensagem'] = "Error encontrar tipo de disparo de alerta";
										break;
								}
								$this->obj_notificacao->alertaTeams($tipo_alerta, $parametros);
							}
						} else {
							$parametros['user'] = "caio.freitas@cmsw.com";
							switch ($tipo) {
								case 'falta':
									$parametros['mensagem'] = "Nenhum funcionário (a) faltou na data de " . convertDate($data);
									break;
								case 'diario':
									$parametros['mensagem'] = "Nenhum funcionário (a) fez mais de 1 hora de banco de horas na data de " . convertDate($data);
									break;
								case 'apos_horario_nucleo':
									$parametros['mensagem'] = "Nenhum funcionário (a) registrou após as 20:00 horas na data de " . convertDate($data);
									break;
								case 'semanal':
									$week = primeiroUltimoDiaSemana($data);
									$data_ini = $week['first_week'];
									$data_fim = $week['last_week'];
									$parametros['mensagem'] = "Nenhuma informação de acumulo de banco de horas semanal na semana de " . convertDate($data_ini) . " até " . convertDate($data_fim);
									break;
								default:
									$tipo_alerta = "rotina_alerta";
									$parametros['mensagem'] = "Sem informação para disparo de alertas ponto " . convertDate($data);
									break;
							}
							$this->obj_notificacao->alertaTeams($tipo_alerta, $parametros);
						}
						$retorno_alerta = json_decode($this->insertAlerta("ponto", $tipo, $data, null, null, null, true));
						if (isset($retorno_alerta) && $retorno_alerta->codigo == 1) {
							$tipo_alerta = "rotina_alerta";
							$parametros['user'] = "caio.freitas@cmsw.com";
							$parametros['mensagem'] = "Error insert alerta";
							$this->obj_notificacao->alertaTeams($tipo_alerta, $parametros);
						}
					} else {
						foreach ($dados as $key => $value) {
							foreach ($value as $k1 => $v1) {
								$boss = json_decode($this->modelo->getBoss(null, $k1));
								if (isset($boss) && !empty($boss)) {
									switch ($key) {
										case 'falta':
											$parametros['user'] = $boss[0]->email_chefe;
											$parametros['mensagem'] = "O funcionário (a) " . strtoupper($boss[0]->nome) . " não registrou ponto no dia " . convertDate($data) . " dentro da sua escala de trabalho.";
											break;
										case 'diario':
											$parametros['user'] = $boss[0]->email_chefe;
											$parametros['mensagem'] = "O funcionário (a) " . strtoupper($boss[0]->nome) . " fez " . $v1->saldo . " de banco de horas no dia " . convertDate($data);
											break;
										case 'apos_horario_nucleo':
											$parametros['user'] = $boss[0]->email_chefe;
											$parametros['mensagem'] = "O funcionário (a) " . strtoupper($boss[0]->nome) . " registrou após às 22:00 no horário de " . $v1->registro . " no dia " . convertDate($data);
											break;
										case 'semanal':
											$parametros['user'] = $boss[0]->email_chefe;
											$parametros['mensagem'] = "O funcionário (a) " . strtoupper($boss[0]->nome) . " acumulou o total de " . $v1->saldo . " na semana de " . $v1->periodo;
											break;
										default:
											$tipo_alerta = "rotina_alerta";
											$parametros['user'] = "caio.freitas@cmsw.com";
											$parametros['mensagem'] = "Error encontrar tipo de disparo de alerta " . convertDate($data);
											break;
									}

									$this->obj_notificacao->alertaTeams($tipo_alerta, $parametros);
								} else {
									$tipo_alerta = "rotina_alerta";
									$parametros['user'] = "caio.freitas@cmsw.com";
									$parametros['mensagem'] = "Error ao encontrar BOSS " . $k1;
									$this->obj_notificacao->alertaTeams($tipo_alerta, $parametros);
								}
							}

							$retorno_alerta = json_decode($this->insertAlerta("ponto", $key, $data, null, null, null, true));
							if (isset($retorno_alerta) && $retorno_alerta->codigo == 1) {
								$tipo_alerta = "rotina_alerta";
								$parametros['user'] = "caio.freitas@cmsw.com";
								$parametros['mensagem'] = "Error insert alerta";
								$this->obj_notificacao->alertaTeams($tipo_alerta, $parametros);
							}
						}
					}

					$parametros['user'] = "caio.freitas@cmsw.com";
					$parametros['mensagem'] = "Rotina disparada com sucesso " . convertDate($data);
					;
					$this->obj_notificacao->alertaTeams($tipo_alerta, $parametros);
				} else {
					$tipo_alerta = "rotina_alerta";
					$parametros['user'] = "caio.freitas@cmsw.com";
					$parametros['mensagem'] = "Erro disparar rotina " . convertDate($data);
					;
					$this->obj_notificacao->alertaTeams($tipo_alerta, $parametros);
				}
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function calculadora(){
			require_once ABSPATH . '/views/' . $this->nome_view . '/calculadora-view.php';
		}

		function Manual(){
			if(isset($_POST['periodo_inicial']) && !empty($_POST['periodo_inicial'])){
				$periodo_inicial = $_POST['periodo_inicial'];
			} else {
				$periodo_inicial = $this->data_hora_atual->format('Y-m-d');
			}

			if(isset($_POST['periodo_final']) && !empty($_POST['periodo_final'])){
				$periodo_final = $_POST['periodo_final'];
			} else {
				$periodo_final = $this->data_hora_atual->format('Y-m-d');
			}

			$permissoes = json_decode($this->cl_permissoes->checkPermissoes('gerarEspelho', 'metodo'));
			// definindo permissoes do listview
			if ($permissoes->output == "master") {
				$lista_usuarios = json_decode($this->modelo->getUsuarios());
			} else {
				switch ($permissoes->output->alcadas) {
					case '2':
						$lista_usuarios = json_decode($this->modelo->getUsuarios(null, $_SESSION['cmswerp']['userdata']->id));
						$alcada = $permissoes->output->alcadas;
						break;
					case '4':
						$lista_usuarios = json_decode($this->modelo->getUsuarios());
						$alcada = $permissoes->output->alcadas;
						break;
					default:
						$lista_usuarios = json_decode($this->modelo->getUsuarios($_SESSION['cmswerp']['userdata']->id));
						$alcada = $permissoes->output->alcadas;
						break;
				}
			}
			// Id utilizado na pesquisa, caso não informado o id padrão é o do proprio usuario logado.
			if (isset($_POST['id_funcionario']) && !empty($_POST['id_funcionario']) && is_numeric($_POST['id_funcionario'])) {
				$userId = $_POST['id_funcionario'];
			} else {
				$userId = $_SESSION['cmswerp']['userdata']->id;
			}
			
			$periodo_ini = getDataAtual($periodo_inicial);
			$periodo_fim = getDataAtual($periodo_final);
			$diff 		 = $periodo_ini->diff($periodo_fim);
			$dias 		 = [];
			if($diff->days >= 0){
				for ($i=0; $i <= $diff->days ; $i++) { 
					$i1 = $periodo_ini->format('Ymd');
					$dias['marcacoes'][$i1]['data'] = $periodo_ini->format('Y-m-d');
					$dias['marcacoes'][$i1]['B01']  = null;
					$dias['marcacoes'][$i1]['B02']  = null;
					$dias['marcacoes'][$i1]['B03']  = null;
					$dias['marcacoes'][$i1]['B04']  = null;
					$periodo_ini->modify('+1 day');
				}
			}

			$marcacaoes = json_decode($this->modelo->getPonto($periodo_inicial, $periodo_final, $userId));
			if($marcacaoes){
				foreach ($marcacaoes as $key => $value) {
					$d1 = str_replace('-', '', $value->data_marcacao);
					$i1 = $value->tipo_marcacao;
					$dias['marcacoes'][$d1]['data'] = $value->data_marcacao;
					// Normaliza hora e remove segundos se existirem
					$hora_original = trim($value->hora_marcacao);
					if (preg_match('/^\d{2}:\d{2}:\d{2}$/', $hora_original)) {
						// formato HH:MM:SS → corta os segundos
						$hora_sem_segundos = substr($hora_original, 0, 5);
					} elseif (preg_match('/^\d{2}:\d{2}$/', $hora_original)) {
						// formato já está correto (HH:MM)
						$hora_sem_segundos = $hora_original;
					} else {
						// formato inesperado → tenta normalizar via strtotime
						$hora_sem_segundos = date('H:i', strtotime($hora_original));
					}
					$dias['marcacoes'][$d1][$i1] = $hora_sem_segundos;
				}
			}
			require_once ABSPATH . '/views/' . $this->nome_view . '/ponto-manual-view.php';
		}

		public function pontoManualProcessar(){
			if (empty($_POST)) {
				return $this->retorno('erro', 'Nenhum dado recebido.');
			}
			$erros = [];
			// // ---------------------------
			// // Validar ID do funcionário
			// // ---------------------------
			$idFuncionario = isset($_POST['id_funcionario']) && is_numeric($_POST['id_funcionario']) ? $_POST['id_funcionario'] : null;
			if (!$idFuncionario) {
				return $this->retorno('erro', 'Informe o usuário!');
			}

			unset($_POST['id_funcionario'], $_POST['submit']);
			foreach ($_POST as $data => $horarios) {
				// ---------------------------
				// 1. VALIDAR DATA
				// ---------------------------
				$objData = getDataAtual($data, 'd/m/Y');
				if (!($objData instanceof DateTime)) {
					$erros[] = "Data inválida: $data";
					continue;
				}

				// ---------------------------
				// 2. VALIDAR E SALVAR HORÁRIOS
				// ---------------------------
				$tipos = [
					'entrada'         => 'B01',
					'saida_almoco'    => 'B02',
					'retorno_almoco'  => 'B03',
					'saida'           => 'B04'
				];
				foreach ($tipos as $campo => $codigo) {
					// ⚠ SE O HORÁRIO NÃO EXISTE → GERAR AVISO, MAS CONTINUAR
					if (empty($horarios[$campo])) {
						$erros[] = "Horário '$campo' ausente na data ".convertDate($data);
						continue;
					}

					// ⚠ SE O HORÁRIO É INVÁLIDO → GERAR AVISO, MAS NÃO SALVAR AQUELE
					if (!validate_hour($horarios[$campo])) {
						$erros[] = "Horário inválido para '$campo' na data ".convertDate($data)." ({$horarios[$campo]}).";
						continue;
					}

					// ---------------------------
					// SALVAR O HORÁRIO VÁLIDO
					// ---------------------------
					$this->salvarBatida(
						$idFuncionario,
						$data,
						$horarios[$campo],
						$codigo,
						$erros
					);
				}
			}

			// ---------------------------
			// 3. RETORNO FINAL
			// ---------------------------
			if (!empty($erros)) {
				return $this->retorno('erro', 'Alguns horários foram registrados com avisos.', $erros);
			}

			return $this->retorno('ok', 'Pontos processados com sucesso!');
		}

		private function salvarBatida($idUsuario, $data, $hora, $codigo, &$erros){
			try {
				$param = [
					'id_usuario'    => $idUsuario,
					'data_marcacao' => $data,
					'hora_marcacao' => $hora,
					'tipo_marcacao' => $codigo,
					'status'        => 'aprovado',
					'ocorrencia'    => 'lançamento_manual',
					'alterado_em'   => $this->data_hora_atual->format('Y-m-d H:i:s'),
					'alterado_por'  => $this->userdata->id,
					'deleted'       => 0
				];

				// Verifica se já existe a mesma batida
				$chk = json_decode(
					$this->verificarPontoManual($idUsuario, $data, $hora)
				);

				$idMarcacao = $chk ? $chk[0]->id : null;
				$this->modelo->setTable('rh_registro_ponto');
				if (!$this->modelo->save($param, $idMarcacao)) {
					$erros[] = "Erro ao registrar batida ($codigo) em $data ($hora).";
				}
			} catch (Exception $e) {
				$erros[] = "Erro interno ao registrar $codigo em $data: " . $e->getMessage();
			}
		}

		function verificarPontoManual($id_usuario, $data_marcacao, $hora_marcacao){
			return $this->modelo->getDataHora($id_usuario, $data_marcacao, $hora_marcacao);
		}

		function pontoManualExcluir(){
			// Id utilizado na pesquisa, caso não informado o id padrão é o do proprio usuario logado.
			if (isset($_POST['id_funcionario']) && !empty($_POST['id_funcionario']) && is_numeric($_POST['id_funcionario'])) {
				$userId = $_POST['id_funcionario'];
			} else {
				$this->retorno('erro', 'Informe o usuario!!');
				exit;
			}

			if (isset($_POST['data_marcacao']) && !empty($_POST['data_marcacao'])) {
				$data_marcacao = $_POST['data_marcacao'];
			} else {
				$this->retorno('erro', 'Informe a data da marcação!!');
				exit;
			}

			$marcacoes = json_decode($this->modelo->getPonto($data_marcacao, $data_marcacao, $userId));
			if($marcacoes){
				foreach ($marcacoes as $key => $value) {
					$param['deleted'] 		= 1;
					$param['ocorrencia']    = 'exclusao_lancamento_manual';
					$param['alterado_em'] 	= $this->data_hora_atual->format('Y-m-d H:i:s');
					$param['alterado_por'] 	= $this->userdata->id;
					if(isset($value->id) && !empty($value->id)){
						$this->modelo->setTable('rh_registro_ponto');
						$save = $this->modelo->save($param, $value->id);
						if(!$save){
							$this->retorno('erro', 'Erro ao tentar excluir a marcação de ponto!!');
							exit;
						}
					}
				}
				$this->retorno('ok', 'Marcações excluídas com sucesso!!');
			}else{
				$this->retorno('erro', 'Registros não encontrados para a data!!');
			}
		}

		function getDateTimeServer(){
				header('Content-Type: application/json');
				date_default_timezone_set(TIME_ZONE); // ajuste conforme necessário
				echo json_encode([
					'timestamp' => round(microtime(true) * 1000) // milissegundos para o JS
				]);
		}
	}