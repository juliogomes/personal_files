<?php
    class PrecosController extends MainController{
        protected $module = 'precos';
        protected $contrato;
        protected $produto;
        protected $cobranca;

        function __construct($parametros = null){
            $this->nome_modulo = 'precos';
            parent::__construct($parametros);
            $this->contrato = $this->load_model('contratos/contratos', true);
            $this->produto  = $this->load_model('produtos/produtos', true);
            $this->cobranca = $this->load_model('cobranca/cobranca', true);
            $this->model_lp = $this->load_model('lista-precos/lista-precos', true);
        }
        /**
         * Carrega a página "/views/login/index.php"
        */
        public function index(){
            $this->produtos();
        } // index

        function produtos(){
            $records  = json_decode($this->produto->getProduto());
            require_once ABSPATH . '/views/'.$this->module.'/produtos-view.php';
        }
        
        function getPacoteDefaultHistorico(){
            try{
                if(isset($_POST['id_registro']) && !empty($_POST['id_registro']) && is_numeric($_POST['id_registro'])){
                    $pacote_historico = json_decode($this->modelo->getPacoteDefaultHistorico($_POST['id_registro']));
                    if($pacote_historico){
                        $retorno['codigo']  = 0;
                        $retorno['input']   = $_POST;
                        $retorno['output']  = $pacote_historico;
                        $retorno['mensgem'] = 'Sucesso';
                        throw new Exception(json_encode($retorno), 1);
                    }else{
                        $retorno['codigo']  = 1;
                        $retorno['input']   = $_POST;
                        $retorno['output']  = null;
                        $retorno['mensgem'] = 'Historico não encontrado';
                        throw new Exception(json_encode($retorno), 1);
                    }
                }else{
                    $retorno['codigo']  = 1;
                    $retorno['input']   = $_POST;
                    $retorno['output']  = null;
                    $retorno['mensgem'] = 'ID Pacote invalido';
                    throw new Exception(json_encode($retorno), 1);
                }
            }catch(Exception $e){
                echo $e->getMessage();
            }
        }
        
        function getLpDefaultHistorico(){
            try{
                if(isset($_POST['id_registro']) && !empty($_POST['id_registro']) && is_numeric($_POST['id_registro'])){
                    $lp_historico = json_decode($this->modelo->getLpDefaultHistorico($_POST['id_registro']));
                    if($lp_historico){
                        $retorno['codigo']  = 0;
                        $retorno['input']   = $_POST;
                        $retorno['output']  = $lp_historico;
                        $retorno['mensgem'] = 'Sucesso';
                        throw new Exception(json_encode($retorno), 1);
                    }else{
                        $retorno['codigo']  = 1;
                        $retorno['input']   = $_POST;
                        $retorno['output']  = null;
                        $retorno['mensgem'] = 'Historico não encontrado';
                        throw new Exception(json_encode($retorno), 1);
                    }
                }else{
                    $retorno['codigo']  = 1;
                    $retorno['input']   = $_POST;
                    $retorno['output']  = null;
                    $retorno['mensgem'] = 'ID Lista de preço invalido';
                    throw new Exception(json_encode($retorno), 1);
                }
            }catch(Exception $e){
                echo $e->getMessage();
            }
        }

        function viewParaReajustar(){
            if(isset($this->parametros['1']) && !empty($this->parametros['1']) && is_numeric($this->parametros['1'])){
                $id_produto = $this->parametros['1'];
                $dados_produto = json_decode($this->produto->getProduto($id_produto));
                if(isset($_POST['percentual_reajuste']) && !empty($_POST['percentual_reajuste'])){
                    $percentual_reajuste = removeCaracteres($_POST['percentual_reajuste'], 'moeda2');
                }else{
                    $percentual_reajuste = 0;
                }
                $percentual_reajuste = (double) $percentual_reajuste;
                if($dados_produto){
                    $nome_produto = $dados_produto[0]->nome;
                    $lista_precos   = json_decode($this->modelo->getLpdefaultByProduto($id_produto));
                    $pacote_default = json_decode($this->modelo->getPacoteDefaultByProduto($id_produto));
                    $processado = true;
                    $mensagem   =  null;
                    if($pacote_default){
                        foreach ($pacote_default as $key => $value){
                            $pacote_array[$key]['pacote_id']             = $value->id;
                            $pacote_array[$key]['id_produto']            = $value->id_produto;
                            $pacote_array[$key]['id_modulo']             = $value->id_modulos_tarifaveis;
                            $pacote_array[$key]['codigo_modulo']         = $value->codigo_modulo;
                            $pacote_array[$key]['nome_modulo']           = $value->nome_modulo;
                            $pacote_array[$key]['qdt_garantido']         = $value->qdt_garantido;
                            $pacote_array[$key]['valor_garantido']       = $value->valor_garantido;
                            $pacote_array[$key]['preco_pkt']             = $value->preco_pkt;
                            $pacote_array[$key]['percentual']            = $value->percentual;
                            $pacote_array[$key]['frenquencia ']          = $value->frenquencia;
                            $pacote_array[$key]['flag ']                 = $value->flag;
                            if($percentual_reajuste){
                                $pacote_array[$key]['preco_pkt_reajuste'] = (($value->preco_pkt/100) * $percentual_reajuste);
                                $pacote_array[$key]['preco_reajustado']   = ($pacote_array[$key]['preco_pkt'] + $pacote_array[$key]['preco_pkt_reajuste']);
                            }else{
                                $pacote_array[$key]['preco_pkt_reajuste'] = 0;
                                $pacote_array[$key]['preco_reajustado']   = $value->preco_pkt;
                            }
                        }
                    }

                    if($lista_precos){
                        foreach ($lista_precos as $key => $value){
                            $i = $value->id_modulo;
                            $lp_array[$i][$key]['lp_id']          = $value->id;
                            $lp_array[$i][$key]['codigo_modulo']  = $value->codigo_modulo;
                            $lp_array[$i][$key]['id_produto']     = $value->id_produto;
                            $lp_array[$i][$key]['id_modulo']      = $value->id_modulo;
                            $lp_array[$i][$key]['nome_modulo']    = $value->nome_modulo;
                            $lp_array[$i][$key]['tipo_cobranca']  = $value->tipo_cobranca;
                            $lp_array[$i][$key]['qtd_de']         = $value->qtd_de;
                            $lp_array[$i][$key]['qtd_ate']        = $value->qtd_ate;
                            $lp_array[$i][$key]['idade_de']       = $value->idade_de;
                            $lp_array[$i][$key]['idade_ate']      = $value->idade_ate;
                            $lp_array[$i][$key]['valor_real']     = $value->valor_real;
                            $lp_array[$i][$key]['valor_relativo'] = $value->valor_relativo;
                            $lp_array[$i][$key]['percentual'] = $value->percentual;
                            $lp_array[$i][$key]['valor_relativo'] = $value->valor_relativo;
                            $lp_array[$i][$key]['qtd_licencas'] = $value->qtd_licencas;
                            $lp_array[$i][$key]['valor_de']       = $value->valor_de;
                            $lp_array[$i][$key]['valor_ate']      = $value->valor_ate;
                            $lp_array[$i][$key]['valor_total']    = $value->valor_total;
                            
                            if($percentual_reajuste){
                                $lp_array[$i][$key]['valor_real_reajuste']   = (($value->valor_real/100)*$percentual_reajuste);
                                $lp_array[$i][$key]['valor_real_reajustado'] = ($lp_array[$i][$key]['valor_real'] + $lp_array[$i][$key]['valor_real_reajuste']);

                                $lp_array[$i][$key]['valor_relativo_reajuste']   = (($value->valor_relativo/100)*$percentual_reajuste);
                                $lp_array[$i][$key]['valor_relativo_reajustado'] = ($lp_array[$i][$key]['valor_relativo'] + $lp_array[$i][$key]['valor_relativo_reajuste']);

                                $lp_array[$i][$key]['valor_de_reajuste']   = (($value->valor_de / 100)*$percentual_reajuste);
                                $lp_array[$i][$key]['valor_de_reajustado'] = ($lp_array[$i][$key]['valor_de'] + $lp_array[$i][$key]['valor_de_reajuste']);

                                $lp_array[$i][$key]['valor_ate_reajuste']   = (($value->valor_ate/100)*$percentual_reajuste);
                                $lp_array[$i][$key]['valor_ate_reajustado'] = ($lp_array[$i][$key]['valor_ate'] + $lp_array[$i][$key]['valor_ate_reajuste']);

                                $lp_array[$i][$key]['valor_total_reajuste']   = (($value->valor_total / 100)*$percentual_reajuste);
                                $lp_array[$i][$key]['valor_total_reajustado'] = ($lp_array[$i][$key]['valor_total'] + $lp_array[$i][$key]['valor_total_reajuste']);

                            }else{
                                $lp_array[$i][$key]['valor_real_reajuste']   = 0;
                                $lp_array[$i][$key]['valor_real_reajustado'] = ($lp_array[$i][$key]['valor_real'] + $lp_array[$i][$key]['valor_real_reajuste']);

                                $lp_array[$i][$key]['valor_relativo_reajuste']   = 0;
                                $lp_array[$i][$key]['valor_relativo_reajustado'] = ($lp_array[$i][$key]['valor_relativo'] + $lp_array[$i][$key]['valor_relativo_reajuste']);

                                $lp_array[$i][$key]['valor_de_reajuste']   = 0;
                                $lp_array[$i][$key]['valor_de_reajustado'] = ($lp_array[$i][$key]['valor_de'] + $lp_array[$i][$key]['valor_de_reajuste']);

                                $lp_array[$i][$key]['valor_ate_reajuste']   = 0;
                                $lp_array[$i][$key]['valor_ate_reajustado'] = ($lp_array[$i][$key]['valor_ate'] + $lp_array[$i][$key]['valor_ate_reajuste']);

                                $lp_array[$i][$key]['valor_total_reajuste']   = 0;
                                $lp_array[$i][$key]['valor_total_reajustado'] = ($lp_array[$i][$key]['valor_total'] + $lp_array[$i][$key]['valor_total_reajuste']);
                            }
                        }
                    }
                }
            }        
            require_once ABSPATH . '/views/'.$this->module.'/produtos-reajuste-view.php';
        }

        function modulos(){
            if(is_numeric($this->parametros[1]) && !empty($this->parametros[1])){
                $records  = json_decode($this->produto->getAllCodigoModulosAtivos($this->parametros[1]));
                require_once ABSPATH . '/views/'.$this->module.'/modulos-view.php';
            }        
        }

        function detalhe(){
            if( is_numeric( $this->parametros[2] ) && !empty( $this->parametros[2] ) ){
                $records        = json_decode( $this->produto->getAllCodigoModulosAtivos( null, $this->parametros[2] ) );
                $lista_precos   = json_decode( $this->cobranca->getListaPrecoPadraoIdProduto( $this->parametros[1], $this->parametros[2] ) );
                $pacote_default = json_decode( $this->modelo->getPacoteDefaultByModulo( $this->parametros[1], $this->parametros[2] ) );
                require_once ABSPATH . '/views/'.$this->module.'/modulos-detalhe-view.php';
            }        
        }

        function editar(){
            $lista_preco = json_decode($this->cobranca->getFaixaPadrao($this->parametros[1], null));
            $lp['id']         = $lista_preco[0]->id;
            $lp['modalidade'] = $lista_preco[0]->modalidade;
            $lp['qtd_de']     = number_format($lista_preco[0]->qtd_de, '0', '', '.');
            $lp['qtd_ate']    = number_format($lista_preco[0]->qtd_ate, '0', '', '.');
            $lp['valor_real'] = number_format($lista_preco[0]->valor_real, '6', ',', '.');
            $lp['editavel']   = $lista_preco[0]->editavel;
            echo "sucesso#".json_encode($lp);
        }

        function savefaixa(){
            if(isset($_POST['id']) && is_numeric($_POST['id'])){
                $id_faixa  = $_POST['id'];
                $chk_faixa = json_decode($this->cobranca->getFaixaPadrao($id_faixa));
            }else{
                $id_faixa  = null;
                $chk_faixa = null;
            }

            $param['id_produto']    = $_POST['id_produto'];
            $param['id_modulo']     = $_POST['id_modulo'];
            $param['qtd_de']        = removeCaracteres($_POST['qtd_de'], 'moeda2');
            $param['qtd_ate']       = removeCaracteres($_POST['qtd_ate'], 'moeda2');            
            $param['modalidade']    = $_POST['modalidade'];
            $param['tipo_cobranca'] = $_POST['tipo_cobranca'];
            $param['valor_real']    = removeCaracteres($_POST['valor_real'], 'moeda2');
            $param['editavel']      = $_POST['editavel'];
            $param['status']        = 'ativo';
            $param['deleted']       = 0;
            $is_save = $this->model_lp->saveLPDefault($param, $id_faixa);
            if($is_save){
                $chk_faixa = json_decode($this->cobranca->getFaixaPadrao($id_faixa));
                $param_historico['indice']           = 'manual';
                $param_historico['tipo_cobranca']    = $_POST['tipo_cobranca'];
                $param_historico['valor_atualizado'] = removeCaracteres($_POST['valor_real'], 'moeda2');
                $param_historico['tipo_atualizacao'] = 'manual';
                $param_historico['deleted']          = 0;
                $param_historico['alterado_em']      = $this->data_hora_atual->format('Y-m-d H:s:i');
                $param_historico['alterado_por']     = $_SESSION['cmswerp']['userdata']->id;
                if($chk_faixa){
                    $param_historico['tipo_lista']       = 'default';
                    $param_historico['id_lp']            = $chk_faixa[0]->id;
                    $param_historico['id_produto']       = $chk_faixa[0]->id_produto;
                    $param_historico['id_modulo']        = $chk_faixa[0]->id_modulo;
                    $param_historico['qtd_de']           = $chk_faixa[0]->qtd_de;
                    $param_historico['qtd_ate']          = $chk_faixa[0]->qtd_ate;
                    $param_historico['valor_real']       = $chk_faixa[0]->valor_real;
                    $param_historico['valor_antigo']     = $chk_faixa[0]->valor_real;
                }else{
                    $param_historico['tipo_lista']       = 'default';
                    $param_historico['id_lp']            = $is_save;
                    $param_historico['id_produto']       = $param['id_produto'];
                    $param_historico['id_modulo']        = $_POST['id_modulo'];;
                    $param_historico['qtd_de']           = removeCaracteres($_POST['qtd_de'], 'moeda2');
                    $param_historico['qtd_ate']          = removeCaracteres($_POST['qtd_ate'], 'moeda2');
                    $param_historico['valor_real']       = removeCaracteres($_POST['valor_real'], 'moeda2');
                    $param_historico['valor_antigo']     = removeCaracteres($_POST['valor_real'], 'moeda2');
                }
                $save_historico = $this->model_lp->saveLPHistorico($param_historico);
                if($save_historico){
                    echo 'sucesso#Faixa cadastrada com sucesso!';
                }else{
                    echo 'sucesso#Faixa cadastrada com sucesso, porem não foi possivel salvar historico';        
                }
            }else{
                echo 'error#Erro ao cadastrar valores!';
            }
        }

        function deletar(){
            if(is_numeric($this->parametros[1]) && !empty($this->parametros[1])){
                $param['deleted'] = 1;
                $is_save = $this->modelo->save($param, $this->parametros[1]);
                if($is_save){
                    echo 'sucesso#Faixa excluida com sucesso!';        
                }else{
                    echo 'error#Erro ao excluir valores!';
                }
            }
        }

        function savePacote(){
            $this->modelo->setTable('pacote_default');
            $_POST["id_produto"]            = $this->parametros[0];
            $_POST["id_modulos_tarifaveis"] = $this->parametros[1];
            $_POST["qtd_transacoes"]        = removeCaracteres($_POST["qtd_transacoes"], true);
            $_POST['valor_pacote']          = removeCaracteres($_POST['valor_pacote'], 'moeda2');
        
            try {
                if(!isset($_POST['id_produto']) || !is_numeric($_POST['id_produto'])){
                    $retorno['codigo']   = 1;
                    $retorno['tipo']     = 'danger';
                    $retorno['mensagem'] = 'Produto invalido';
                    $retorno['dados']    = $_POST;
                    throw new Exception(json_encode($retorno), 1);
                }
                
                if(!isset($_POST['id_modulos_tarifaveis']) || !is_numeric($_POST['id_modulos_tarifaveis'])){
                    $retorno['codigo']   = 1;
                    $retorno['tipo']     = 'danger';
                    $retorno['mensagem'] = 'Modulo invalido';
                    $retorno['dados']    = $_POST;
                    throw new Exception(json_encode($retorno), 1);
                }
                
                if(isset($_POST['qtd_transacoes'])){
                    $qdt_garantido = removeCaracteres($_POST['qtd_transacoes'],'moeda2');
                    if(!is_numeric($qdt_garantido) || empty($qdt_garantido)){
                        $retorno['codigo']   = 1;
                        $retorno['tipo']     = 'danger';
                        $retorno['mensagem'] = 'Informe a quantidade de transações para o pacote';
                        $retorno['dados']    = $_POST;
                        throw new Exception(json_encode($retorno), 1);
                    }
                }
            
                if(isset($_POST['valor_pacote'])){
                    $preco_pkt = removeCaracteres($_POST['valor_pacote'],'moeda2');
                    if(!is_numeric($preco_pkt)){
                        $retorno['codigo']   = 1;
                        $retorno['tipo']     = 'danger';
                        $retorno['mensagem'] = 'Informe o preço do pacote';
                        $retorno['dados']    = $_POST;
                        throw new Exception(json_encode($retorno), 1);
                    }
                }

                // verificando informações do pacote antes de salvar as novas
                if(isset($_POST['id_pacote']) && !empty($_POST['id_pacote']) && is_numeric($_POST['id_pacote'])){
                    $id_pacote = $_POST['id_pacote'];                
                    $pacote_anterior = json_decode($this->modelo->getPacoteDefaultById($id_pacote));
                    if(!$pacote_anterior){
                        $retorno['codigo']   = 1;
                        $retorno['tipo']     = 'erro';
                        $retorno['mensagem'] = 'Erro ao recuperar informações do pacote!';
                        $retorno['dados']    = $_POST;
                        throw new Exception(json_encode($retorno), 1);
                    }
                }else{
                    $id_pacote       = null;
                    $pacote_anterior = null;
                }

                $param['id_produto']            = $_POST["id_produto"];
                $param['id_modulos_tarifaveis'] = $_POST['id_modulos_tarifaveis'];
                $param['preco_pkt']             = $_POST['valor_pacote'];
                $param['qdt_garantido']         = $_POST["qtd_transacoes"];
                $param['status']                = $_POST['status'];
                $param['deleted']               = 0;

                // montando parametros para registro na tabela de historico de alteração de pacote
                $is_save_pacote = $this->modelo->save($param, $id_pacote);
                if($is_save_pacote){
                    // checando informações do pacote antes de salvar.
                    $hparam['tipo_pacote']      = "default";
                    $hparam['id_contrato']      = '0';
                    $hparam['tipo_atualizacao'] = 'manual';
                    $hparam['flag']        		= 'SD';
                    if($pacote_anterior){
                        $hparam['id_pacote']             = $pacote_anterior[0]->id;
                        $hparam['id_modulos_tarifaveis'] = $pacote_anterior[0]->id_modulos_tarifaveis;
                        $hparam['qdt_atual'] 		     = $pacote_anterior[0]->qdt_garantido;
                        $hparam['preco_atual'] 		     = $pacote_anterior[0]->preco_pkt;
                    }else{
                        $hparam['id_pacote'] = $is_save_pacote;
                        $hparam['qdt_atual']             = $_POST['qtd_transacoes']; 
                    }    
                    $hparam['qdt_atualizada'] 		 = $_POST['qtd_transacoes'];
                    $hparam['preco_atualizado']      = $_POST['valor_pacote'];
                    $hparam['id_modulos_tarifaveis'] = $_POST['id_modulos_tarifaveis'];                 
                    $hparam['preco_atual']           = $preco_pkt;
                    $this->modelo->setTable('pacote_historico');
                    $is_save_historico = $this->modelo->save($hparam);
                    if($is_save_historico){
                        $retorno['codigo']   = 0;
                        $retorno['tipo']     = 'Sucesso';
                        $retorno['mensagem'] = 'Pacote inserido com sucesso!';
                        $retorno['dados']    = $_POST;
                        throw new Exception(json_encode($retorno), 1); 
                    }else{
                        $retorno['codigo']   = 1;
                        $retorno['tipo']     = $this->modelo->info;
                        $retorno['mensagem'] = 'Erro ao salvar informações no historico!';
                        $retorno['dados']    = $_POST;
                        throw new Exception(json_encode($retorno), 1);    
                    }
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['tipo']     = 'erro';
                    $retorno['mensagem'] = 'Erro ao salvar informações do pacote!';
                    $retorno['dados']    = $_POST;
                    throw new Exception(json_encode($retorno), 1);
                }
            } catch (Exception $e) {
                echo $e->getMessage();
            }
        }
        
        function processarReajusteLpDefault(){
            try {
                if(isset($_POST['percentual_reajuste']) && !empty($_POST['percentual_reajuste'])){
                    $percentual_reajuste = removeCaracteres($_POST['percentual_reajuste'], 'moeda2');
                    $percentual_reajuste = (double) $percentual_reajuste;
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $_POST;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Informe o percentual de reajuste';
                    throw new Exception(json_encode($retorno), 1);
                }

                if(!isset($percentual_reajuste) || empty($percentual_reajuste)){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $_POST;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'Informe o percentual de reajuste';
                    throw new Exception(json_encode($retorno), 1);
                }
                
                if(isset($this->parametros['1']) && !empty($this->parametros['1']) && is_numeric($this->parametros['1'])){
                    $id_produto = $this->parametros['1'];
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $_POST;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = 'ID do produto não informado';
                    throw new Exception(json_encode($retorno), 1);
                }
                
                $dados_produto = json_decode($this->produto->getProduto($id_produto));
                if(!$dados_produto){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $_POST;
                    $retorno['output']   = $add_historico;
                    $retorno['mensagem'] = 'Dados do produto não encontrados';
                    throw new Exception(json_encode($retorno), 1);
                }

                $nome_produto = $dados_produto[0]->nome;
                $lista_precos   = json_decode($this->modelo->getLpdefaultByProduto($id_produto));
                $pacote_default = json_decode($this->modelo->getPacoteDefaultByProduto($id_produto));
                
                if($pacote_default){
                    foreach ($pacote_default as $key => $value){
                        $pacote_array[$key]['preco_pkt_reajuste'] = (($value->preco_pkt/100) * $percentual_reajuste);
                        $pacote_array[$key]['preco_reajustado']   = ($value->preco_pkt + $pacote_array[$key]['preco_pkt_reajuste']);
                        $update_pacote['preco_pkt']   = $pacote_array[$key]['preco_reajustado'];
                    

                        $this->modelo->setTable('pacote_default');
                        $update_pacote = $this->modelo->save($update_pacote, $value->id);
                        if($update_pacote){
                            $add_historico['tipo_pacote']           = 'default';
                            $add_historico['id_pacote']             = $value->id;
                            $add_historico['id_contrato']           = 0;
                            $add_historico['id_modulos_tarifaveis'] = $value->id_modulos_tarifaveis;
                            $add_historico['qdt_atual']             = $value->qdt_garantido;
                            $add_historico['qdt_atualizada']        = $value->qdt_garantido;
                            $add_historico['preco_atual']           = $value->preco_pkt;
                            $add_historico['preco_atualizado']      = $pacote_array[$key]['preco_reajustado'];
                            $add_historico['percentual']            = $percentual_reajuste;
                            $add_historico['flag']                  = $value->flag;
                            $add_historico['tipo_atualizacao']      = 'manual';
                            $add_historico['alterado_por']          = $_SESSION['cmswerp']['userdata']->id;
                            $add_historico['alterado_em']           = $this->data_hora_atual->format('Y-m-d H:i:s');
                            $add_historico['deleted']               = 0;
                            $this->modelo->setTable('pacote_historico');
                            $add_historico = $this->modelo->save($add_historico);
                            if(!$add_historico){
                                $retorno['codigo']   = 1;
                                $retorno['input']    = $_POST;
                                $retorno['output']   = $add_historico;
                                $retorno['mensagem'] = 'Erro ao gravar alteração do pacote no historico';
                                throw new Exception(json_encode($retorno), 1);
                            }
                        }else{
                            $retorno['codigo']   = 1;
                            $retorno['input']    = $_POST;
                            $retorno['output']   = $add_historico;
                            $retorno['mensagem'] = 'Erro atualizar pacote';
                            throw new Exception(json_encode($retorno), 1);
                        }
                    }
                }else{
                    // $retorno['codigo']   = 1;
                    // $retorno['input']    = $_POST;
                    // $retorno['output']   = $pacote_default;
                    // $retorno['mensagem'] = 'Pacote não encontrado';
                    // throw new Exception(json_encode($retorno), 1);
                }
                
                if($lista_precos){
                    foreach ($lista_precos as $key => $value){
                        $i = $value->id_modulo;
                        $lp_array[$i][$key]['lp_id']          = $value->id;
                        $lp_array[$i][$key]['codigo_modulo']  = $value->codigo_modulo;
                        $lp_array[$i][$key]['id_produto']     = $value->id_produto;
                        $lp_array[$i][$key]['id_modulo']      = $value->id_modulo;
                        $lp_array[$i][$key]['nome_modulo']    = $value->nome_modulo;
                        $lp_array[$i][$key]['tipo_cobranca']  = $value->tipo_cobranca;
                        $lp_array[$i][$key]['qtd_de']         = $value->qtd_de;
                        $lp_array[$i][$key]['qtd_ate']        = $value->qtd_ate;
                        $lp_array[$i][$key]['idade_de']       = $value->idade_de;
                        $lp_array[$i][$key]['idade_ate']      = $value->idade_ate;
                        $lp_array[$i][$key]['valor_real']     = $value->valor_real;
                        $lp_array[$i][$key]['valor_relativo'] = $value->valor_relativo;
                        $lp_array[$i][$key]['percentual'] = $value->percentual;
                        $lp_array[$i][$key]['valor_relativo'] = $value->valor_relativo;
                        $lp_array[$i][$key]['qtd_licencas'] = $value->qtd_licencas;
                        $lp_array[$i][$key]['valor_de']       = $value->valor_de;
                        $lp_array[$i][$key]['valor_ate']      = $value->valor_ate;
                        $lp_array[$i][$key]['valor_total']    = $value->valor_total;
                        
                        $lp_array[$i][$key]['valor_real_reajuste']   = (($value->valor_real/100)*$percentual_reajuste);
                        $lp_array[$i][$key]['valor_real_reajustado'] = ($lp_array[$i][$key]['valor_real'] + $lp_array[$i][$key]['valor_real_reajuste']);

                        $lp_array[$i][$key]['valor_relativo_reajuste']   = (($value->valor_relativo/100)*$percentual_reajuste);
                        $lp_array[$i][$key]['valor_relativo_reajustado'] = ($lp_array[$i][$key]['valor_relativo'] + $lp_array[$i][$key]['valor_relativo_reajuste']);

                        $lp_array[$i][$key]['valor_de_reajuste']   = (($value->valor_de / 100)*$percentual_reajuste);
                        $lp_array[$i][$key]['valor_de_reajustado'] = ($lp_array[$i][$key]['valor_de'] + $lp_array[$i][$key]['valor_de_reajuste']);

                        $lp_array[$i][$key]['valor_ate_reajuste']   = (($value->valor_ate/100)*$percentual_reajuste);
                        $lp_array[$i][$key]['valor_ate_reajustado'] = ($lp_array[$i][$key]['valor_ate'] + $lp_array[$i][$key]['valor_ate_reajuste']);

                        $lp_array[$i][$key]['valor_total_reajuste']   = (($value->valor_total / 100)*$percentual_reajuste);
                        $lp_array[$i][$key]['valor_total_reajustado'] = ($lp_array[$i][$key]['valor_total'] + $lp_array[$i][$key]['valor_total_reajuste']);

                        $param_update['valor_real']     = $lp_array[$i][$key]['valor_real_reajustado'];
                        $param_update['valor_relativo'] = $lp_array[$i][$key]['valor_relativo_reajustado'];
                        $param_update['valor_de']       = $lp_array[$i][$key]['valor_de_reajustado'];
                        $param_update['valor_ate']      = $lp_array[$i][$key]['valor_ate_reajustado'];
                        $param_update['valor_total']    = $lp_array[$i][$key]['valor_total_reajustado'];

                        $this->modelo->setTable('lp_default');
                        $save_faixa = $this->modelo->save($param_update, $value->id);
                        if($save_faixa){
                            $param_historico['tipo_lista']       = 'default';
                            $param_historico['tipo_atualizacao'] = 'manual';
                            $param_historico['id_lp']            = $value->id;
                            $param_historico['id_produto']       = $value->id_produto;
                            $param_historico['id_modulo']        = $value->id_modulo;
                            $param_historico['qtd_de']           = $value->qtd_de;
                            $param_historico['qtd_ate']          = $value->qtd_ate;
                            $param_historico['idade_de']         = $value->idade_de;
                            $param_historico['idade_ate']        = $value->idade_ate;
                            $param_historico['percentual']       = $percentual_reajuste;
                            $param_historico['tipo_cobranca']    = $value->tipo_cobranca;
                            $param_historico['valor_relativo']   = $value->valor_relativo;
                            $param_historico['tipo_cobranca']    = $value->tipo_cobranca;
                            $param_historico['valor_antigo']     = $lp_array[$i][$key]['valor_real'];
                            $param_historico['valor_reajuste']   = $lp_array[$i][$key]['valor_real_reajuste'];
                            $param_historico['valor_atualizado'] = $lp_array[$i][$key]['valor_real_reajustado'];
                            $param_historico['alterado_por']     = $_SESSION['cmswerp']['userdata']->id;
                            $param_historico['alterado_em']      = $this->data_hora_atual->format('Y-m-d H:i:s');
                            $param_historico['deleted']          = 0;
                            $save_historico_lp = $this->modelo->setTable('lp_historico');
                            $save_historico_lp = $this->modelo->save($param_historico);
                            if(!$save_historico_lp){
                                $retorno['codigo']   = 1;
                                $retorno['input']    = $_POST;
                                $retorno['output']   = $add_historico;
                                $retorno['mensagem'] = 'Erro ao salvar alteração de lista de preço no historico';
                                throw new Exception(json_encode($retorno), 1);
                            }
                        }else{
                            $retorno['codigo']   = 1;
                            $retorno['input']    = $_POST;
                            $retorno['output']   = $add_historico;
                            $retorno['mensagem'] = 'Erro ao atualizar lista de preço';
                            throw new Exception(json_encode($retorno), 1);
                        }
                    }
                }else{
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $_POST;
                    $retorno['output']   = $lista_precos;
                    $retorno['mensagem'] = 'Lista de preço não encontrada';
                    throw new Exception(json_encode($retorno), 1);
                }

                $retorno['codigo']   = 0;
                $retorno['input']    = $_POST;
                $retorno['output']   = null;
                $retorno['mensagem'] = 'Sucesso';
                throw new Exception(json_encode($retorno), 1);
            } catch (Exception $e) {
                echo $e->getMessage();
            }
        }
    }