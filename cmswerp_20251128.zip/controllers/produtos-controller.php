<?php

class ProdutosController extends MainController{
	function __construct($parametros = null){
		$this->setModulo('produtos');
		$this->setView('produtos');
		parent::__construct($parametros);
    }

	function setObjectEmail(){
		$this->obj_email = new Email();	
	}

	function index(){
		$this->lista();
	}

	function lista(){
		$records  = json_decode($this->modelo->getProduto(null, false, true));
		require_once ABSPATH . '/views/'.$this->nome_view.'/produtos-list.php';
	}

	function detalhe(){
		if(isset($this->parametros[1]) && !empty($this->parametros[1])){
			$records  = json_decode($this->modelo->getProduto($this->parametros[1]));
            $modules  = json_decode($this->modelo->getModulosByProduto($this->parametros[1]));
		}
		require_once ABSPATH . '/views/'.$this->nome_view.'/produto-detalhe.php';
	}

	function moduloDetalhe(){
		$this->modelo->setTable('produtos');
		$produto  = json_decode($this->modelo->getById($this->parametros[0]));
		$this->modelo->setTable('modulos_tarifaveis');
		$modulo  = json_decode($this->modelo->getById($this->parametros[1]));
		require_once ABSPATH . '/views/'.$this->nome_view.'/modulo-cadastro.php';
	}

	function produtoCadastro(){
		if(isset($this->parametros[1]) && is_numeric($this->parametros[1]) && !empty($this->parametros[1])){
			$records  = json_decode($this->modelo->getProduto($this->parametros[1]));
		}
		require_once ABSPATH . '/views/'.$this->nome_view.'/produto-cadastro.php';
	}

	function saveProduto(){
		$check = validaForm($_POST, $required = 'all');
		if($check){
			$this->modelo->setTable('produtos');
			$id = $this->modelo->save($_POST, $this->parametros[1]);
			header('location: /produtos/produtoCadastro/id/'.$id);
		}else{
			$this->modelo->error = 'Campos obrigatorios não preenchido';
		}
		require_once ABSPATH . '/views/'.$this->module.'/produtos/produto-cadastro.php';
	}

	function cadastrarModulo(){
        // $check = validaForm( $_POST, $required = 'all' );
		$check = true;
		if( $check ){
			$this->modelo->setTable('modulos_tarifaveis');
			$is_save = $this->modelo->save($_POST, $this->parametros[1]);
			if($is_save){
				header('location: /produtos/moduloDetalhe/'.$this->parametros[0].'/'.$is_save);
			}else{
				$this->modelo->error = 'Erro ao salvar modulo';
			}
		}else{
			$this->modelo->error = 'Campos obrigatorios não preenchido';
		}
	}
}
?>
