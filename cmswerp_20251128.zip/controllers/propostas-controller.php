<?php
class PropostasController extends MainController
{
	public
		$proposta_taridor,
		$empresas_cm,
		$obj_pptx,
		$api;
	protected
		$obj_documento,
		$obj_notificacao,
		$aprovacao,
		$minuta,
		$minutaV2,
		$id_user,
		$sing,
		$obj_assinatura,
		$obj_faturamento,
		$model_comissao,
		$model_conta_bancaria;

	function __construct($parametros = null, $nome_modulo = 'proposta', $do_login = true)
	{
		require ABSPATH . "/config_extras.php";
		$this->setModulo('propostas');
		$this->setView('propostas');
		parent::__construct($parametros, $nome_modulo, $do_login);

		$this->obj_documento = new PdfDocumento($this);
		$this->obj_pptx = new PptxDocumento($this, $this->data_hora_atual->format('Y-m-d'));
		$this->obj_notificacao = new Notificacoes($this);
		$this->api = new Api($this);
		$this->minuta = new Minuta($this);
		$this->minutaV2 = new MinutaV2($this);
		$this->obj_sign = new D4Sign($this, "D4S002");
		$this->obj_assinatura = new Assinatura($this);
		$this->obj_faturamento = new InstrucaoFaturamento($this, $this->parametros);
		// $this->aprovacao = new Aprovacao($this,'COR0001');
		$this->obj_faturamento_nota_fiscal = new Faturamento($this, $this->parametros);

		$this->empresas_cm = $this->load_model('empresas/empresas', true);
		$this->id_user = $_SESSION['cmswerp']['userdata']->id;
		$this->dicionario = $VAR_SYSTEM['DICIONARIO_TAG'];
		$this->model_comissao = $this->load_model('comissao/comissao', true);
		$this->model_conta_bancaria = $this->load_model('contabancaria/contabancaria', true);
	}

	function index()
	{
		// $this->rotinaWebD4sign();
		$this->listar();
	}

	function pptx()
	{
		$this->obj_pptx->readPptx();
	}

	function presentation()
	{
		$this->obj_pptx->phpPresentation();
		require_once ABSPATH . '/views/' . $this->nome_view . '/slide-view.php';
	}

	function salvarpdf()
	{
		$this->obj_pptx->salvarPDF();
	}

	function listar()
	{
		include "config_extras.php";
		$session = json_decode($_SESSION['cmswerp']['userdata']->permissoes);
		$id_user = $_SESSION['cmswerp']['userdata']->id;
		$id_boss = $_SESSION['cmswerp']['userdata']->boss;
		$data = getDataAtual();

		if (!$this->cl_permissoes->verificarPermissao('propostas')) {
			echo 'Você não tem acesso, consulte o suporte';
			exit;
		} else {
			$this->nivel_acesso = $this->cl_permissoes->permissao_acesso;
		}

		if (isset($_POST["id_proposta"]) && !empty($_POST["id_proposta"]) && is_numeric($_POST["id_proposta"])) {
			$id_proposta = $_POST["id_proposta"];
		} else {
			$id_proposta = null;
		}

		if (isset($_POST["id_owner"]) && !empty($_POST["id_owner"]) && is_numeric($_POST["id_owner"])) {
			$owner_proposta = $_POST["id_owner"];
		} else {
			$owner_proposta = null;
		}

		if (isset($_POST["status"]) && !empty($_POST["status"])) {
			$status = $_POST["status"];
		} else {
			$status = $_POST["status"] = null;
		}

		if (isset($_POST['vencimento_de']) & !empty($_POST['vencimento_de'])) {
			$data_ini = getDataAtual($_POST['vencimento_de']);
		} else {
			$data_ini = $data->modify('first day of this month');
		}

		if (isset($_POST['vencimento_ate']) & !empty($_POST['vencimento_ate'])) {
			$data_fim = getDataAtual($_POST['vencimento_ate']);
		} else {
			$data_fim = getDataAtual();
		}

		if (!$this->cl_permissoes->verificarPermissao($this->nome_modulo)) {
			echo 'Sem permissao COD:102';
			exit;
		}

		if ($this->cl_permissoes->is_master) {
			$records = json_decode($this->modelo->getPropostas($id_proposta, $data_ini->format('Y-m-d'), $data_fim->format('Y-m-d'), $owner_proposta, $status));
			$this->list_user = json_decode($this->user_model->getUserByNomeDepartamento('COMERCIAL'));
		} else {
			switch ($this->cl_permissoes->alcada_acesso) {
				case '1': // apenas o owner
					$owner_proposta = $id_user;
					$records = json_decode($this->modelo->getPropostas($id_proposta, $data_ini->format('Y-m-d'), $data_fim->format('Y-m-d'), $owner_proposta, $status));
					$this->list_user = json_decode($this->user_model->getUserByNomeDepartamento('COMERCIAL', $id_user));
					break;
				case '2': // owner e subordinados
					$records = json_decode($this->modelo->getPropostasByBoss($data_ini->format('Y-m-d'), $data_fim->format('Y-m-d'), $id_user, $owner_proposta));
					$this->list_user = json_decode($this->user_model->getUserByBoss($id_user));
					break;
				case '3': // owner e subordinados e outros perfis
					# code...
					break;
				case '4': // todos
					$records = json_decode($this->modelo->getPropostas($id_proposta, $data_ini->format('Y-m-d'), $data_fim->format('Y-m-d'), $owner_proposta, $status));
					$this->list_user = json_decode($this->user_model->getUserByNomeDepartamento('COMERCIAL'));
					break;
			}
		}

		if ($this->parametros['acao'] == "AOPaprovada" || $this->parametros['acao'] == "AOPpendente" || $this->parametros['acao'] == "AOPfora_padrao") {
			if ($this->parametros['acao'] == "AOPaprovada") {
				$status = "fechada";
			} else if ($this->parametros['acao'] == "AOPpendente") {
				$status = "pendente";
			}

			if ($session->modulos->Sales->{68}->alcadas <= 1) {
				if ($this->parametros['acao'] == "AOPfora_padrao") {
					$records = json_decode($this->modelo->getPropostasTexto(null, true, true));
				} else {
					$records = json_decode($this->modelo->getPropostas(null, null, null, null, $status));
				}
			} else {
				if ($this->parametros['acao'] == "AOPfora_padrao") {
					$records = json_decode($this->modelo->getPropostasTexto(null, true, true, $id_user));
				} else {
					$records = json_decode($this->modelo->getPropostas(null, null, null, $id_user, $status));
				}
			}
		}

		$user_fluxo_aprovacao = json_decode($this->modelo->fluxoOrdemAprovacao($this->id_user, 'minuta'));
		$status_minuta = $this->statusMinuta($records);
		require_once ABSPATH . '/views/' . $this->nome_view . '/propostas-view.php';
	}

	function detalhe()
	{
		if (!$this->cl_permissoes->verificarPermissao('propostas')) {
			echo 'Você não tem acesso, consulte o suporte';
			exit;
		} else {
			$this->nivel_acesso = $this->cl_permissoes->permissao_acesso;
		}

		$records = null;
		$session = json_decode($_SESSION['cmswerp']['userdata']->permissoes);
		$id_user = $_SESSION['cmswerp']['userdata']->id;
		$this->list_empresa = json_decode($this->modelo->getEmpresaVendedora());
		$this->lista_produtos = json_decode($this->obj_documento->produtos_model->getAllProdutosAtivos());
		foreach ($this->list_empresa as $key => $value) {
			switch ($this->userdata->cnpj) {
				case '43561343000138':
					switch ($value->cnpj) {
						case '43561343000138':
						case '03215009000108':
							$empresa_vendedora[] = $value;
							break;
					}
					break;
				default:
					if ($value->cnpj != '43561343000138') {
						$empresa_vendedora[] = $value;
					}
					break;
			}
		}

		foreach ($this->lista_produtos as $key => $value) {
			switch ($this->userdata->cnpj) {
				case '43561343000138':
					switch ($value->codigo) {
						case 'YLW0001':
						case 'CRY0003':
							$lista_produtos[] = $value;
							break;
					}
					break;
				default:
					//if( $value->codigo != 'YLW0001' && $value->codigo != 'CRY0003' ){
					//	$lista_produtos[] = $value;
					//}
					$lista_produtos[] = $value;
					break;
			}
		}

		if ($this->cl_permissoes->is_master) {
			if (isset($this->parametros[1]) && !empty($this->parametros[1]) && is_numeric($this->parametros[1])) {
				$records = json_decode($this->modelo->getPropostas($this->parametros[1]));
			}
			$this->list_user = json_decode($this->user_model->getUserByNomeDepartamento('COMERCIAL'));
		} else {
			switch ($this->cl_permissoes->alcada_acesso) {
				case '1': // apenas o owner
					if (isset($this->parametros[1]) && !empty($this->parametros[1]) && is_numeric($this->parametros[1])) {
						$records = json_decode($this->modelo->getPropostas($this->parametros[1], null, null, $id_user));
					}
					$this->list_user = json_decode($this->user_model->getUserByNomeDepartamento('COMERCIAL', $id_user));
					break;
				case '2': // owner e subordinados
					if (isset($this->parametros[1]) && !empty($this->parametros[1]) && is_numeric($this->parametros[1])) {
						$records = json_decode($this->modelo->getPropostas($this->parametros[1]));
					}
					$this->list_user = json_decode($this->user_model->getUserByBoss($id_user));
					break;
				case '3': // owner e subordinados e outros perfis
					# code...
					break;
				case '4': // todos
					if (isset($this->parametros[1]) && !empty($this->parametros[1]) && is_numeric($this->parametros[1])) {
						$records = json_decode($this->modelo->getPropostas($this->parametros[1]));
					}
					$this->list_user = json_decode($this->user_model->getUserByNomeDepartamento('COMERCIAL'));
					break;
			}
		}

		if (isset($records[0]->valor_implantacao) && !empty($records[0]->valor_implantacao)) {
			$valor_implantacao = $records[0]->valor_implantacao;
		} else {
			$valor_implantacao = 0;
		}
		require_once ABSPATH . '/views/' . $this->nome_view . '/propostas-detalhe-view.php';
	}

	function statusFaturamento()
	{
		include "config_extras.php";
		if (isset($this->parametros[0]) && !empty($this->parametros[0])) {
			if (strtolower($this->parametros[0]) != "cry") {
				$id_proposta = $this->parametros[0];
				$proposta = json_decode($this->modelo->getPropostas($id_proposta));
				$contrato = json_decode($this->modelo->getIfContrato(null, $id_proposta));
			} else {
				$id_proposta = $this->parametros[1];
				$id = $this->parametros[1];
				$contrato = json_decode($this->modelo->getIfContrato($id));
				$proposta = $contrato;
				$proposta[0]->cnpj_cpf = $contrato[0]->cnpj;
				$proposta[0]->cliente = $contrato[0]->razao_social;
				$proposta[0]->nome_usuario = "<i class='fa fa-ban'></i>";
				$proposta[0]->status = "fechada";
			}

			if (isset($contrato) && !empty($contrato)) {
				$ged = json_decode($this->modelo->gedDocumentoAnexo2($contrato[0]->id, 'minuta'));
				$href = "/" . $this->nome_modulo . "/faturamento/1/" . $contrato[0]->id;
				$id_contrato = $contrato[0]->id;
				$status_minuta = $contrato[0]->finalizado;
				if ($status_minuta == 1) {
					$path = PATH_MINUTA_R . $ged[0]->path_objeto . $ged[0]->nome_hash;
					if ($proposta[0]->codigo == "RCK0001") {
						/*
						$ged_customizacao = json_decode( $this->modelo->gedDocumentoAnexo2( $contrato[0]->id, 'customizacao') );
						if( isset( $ged_customizacao ) && !empty( $ged_customizacao ) ){
							$path_customizacao = PATH_MINUTA_R.$ged_customizacao[0]->path_objeto.$ged_customizacao[0]->nome_hash;
						}*/
					}
				}
			} else {
				$href = "/" . $this->nome_modulo . "/faturamento/1/id_proposta/" . $id_proposta;
			}

			if (isset($id_contrato) && !empty($id_contrato)) {
				$ged_clicksign = json_decode($this->modelo->gedClicksign(null, $id_contrato));
				if (isset($ged_clicksign) && !empty($ged_clicksign)) {
					if (isset($ordem_aprovacao) && $ordem_aprovacao == 2) {
						$ged_clicksign = json_decode($this->modelo->gedClicksign(null, $id_contrato));
					}
					$ged_assinatura = json_decode($this->modelo->gedClicksignAssinatura("d4sign", null, $ged_clicksign[0]->id_ged_anexo));
					$ordem_assinatura = json_decode($this->modelo->getOrdemAssinaturaClicksign($ged_clicksign[0]->id_ged_anexo, $contrato['0']->id_empresa));
				} else {
					$ordem_assinatura = $this->obj_assinatura->ordemAssinatura($id_contrato, $contrato['0']->id_empresa);
				}
			}

			$user_fluxo_aprovacao = json_decode($this->modelo->fluxoOrdemAprovacao(null, 'minuta', $proposta[0]->id_cm));
			$ordem_aprovacao = $this->aprovacao->ordemFluxoAprovacao($contrato[0]->id);
			if (isset($id_contrato) && !empty($id_contrato)) {
				$get_user_comissao = json_decode($this->model_comissao->getComissoesByObjeto($id_contrato));
			}

			$user_comercial = $this->obj_faturamento->getUsersComercial($proposta[0]->id_owner, $proposta[0]->id_cm, $proposta);
			if (isset($contrato[0]->id)) {
				$full = json_decode($this->modelo->getFullMinuta($contrato[0]->id));
			}
			$get_ass = $this->obj_assinatura->getAssinatura($ordem_assinatura, $ged_assinatura);
		}
		require_once ABSPATH . '/views/' . $this->nome_view . '/faturamento-default-view.php';
	}

	//By: Caio Freitas - 15/07/2022
	function faturamento()
	{
		include "config_extras.php";
		$user_fluxo_aprovacao = json_decode($this->modelo->fluxoOrdemAprovacao($this->id_user, 'minuta'));
		if ($this->parametros[1] == "id_proposta") {
			$id_proposta = $this->parametros[2];
		} else {
			$id_contrato = $this->parametros[1];
			$contrato = json_decode($this->modelo->getIfContrato($id_contrato));
			$id_proposta = $contrato[0]->id_proposta;
			$ordem = $this->aprovacao->ordemFluxoAprovacao($id_contrato);
		}

		if (isset($this->parametros[0]) && !empty($this->parametros[0])) {
			$etapa = $this->parametros[0];
		}
		switch ($etapa) {
			case 1:
				if (isset($this->parametros[1]) && !empty($this->parametros[1])) {
					if ($this->parametros[1] == "id_proposta") {
						$id_proposta = $this->parametros[2];
						$proposta = json_decode($this->modelo->getPropostas($id_proposta));
						$contrato = json_decode($this->modelo->getIfContrato(null, $id_proposta));
						if (!isset($contrato) || empty($contrato)) {
							if (isset($proposta) && is_array($proposta)) {
								foreach ($proposta as $key => $value) {
									$contrato[0]->codigo_cliente = substr($value->cnpj_cpf, 0, -6);
									$contrato[0]->cnpj = $value->cnpj_cpf;
									$contrato[0]->nome_fantasia = $value->cliente;
									$contrato[0]->id_produto = $value->id_produto;
								}
							}
						} else {
							$id_contrato = $contrato[0]->id;
						}
					} else {
						$id_contrato = $this->parametros[1];
						$contrato = json_decode($this->modelo->getIfContrato($id_contrato));
					}
				}
				break;
			case 2:
				if (isset($this->parametros[1]) && !empty($this->parametros[1])) {
					$id_contrato = $this->parametros[1];
					$endereco = json_decode($this->modelo->getIfEndereco($id_contrato));
					if (!isset($endereco) || empty($endereco)) {
						$contrato = json_decode($this->modelo->getIfContrato($id_contrato));
						if (isset($contrato) && !empty($contrato)) {
							$id_proposta = $contrato[0]->id_proposta;
							$proposta = json_decode($this->modelo->getPropostas($id_proposta));
						}
					}
				}
				break;
			case 3:
				if (isset($this->parametros[1]) && !empty($this->parametros[1])) {
					$id_contrato = $this->parametros[1];
					$contato = json_decode($this->modelo->getIfContato($id_contrato, "minuta"));
					if (!isset($contato) || empty($contato)) {
						$contrato = json_decode($this->modelo->getIfContrato($id_contrato));
						if (isset($contrato) && !empty($contrato)) {
							$id_proposta = $contrato[0]->id_proposta;
							$proposta = json_decode($this->modelo->getPropostas($id_proposta));
						}
					}
				}
				break;
			case 4:
				if (isset($this->parametros[1]) && !empty($this->parametros[1])) {
					$id_contrato = $this->parametros[1];
					$id_proposta = $this->parametros[2];
					$proposta = json_decode($this->modelo->getPropostas($id_proposta));
					$faturamento = json_decode($this->modelo->getInstrucaofaturamento($id_contrato));
					if (!isset($faturamento) || empty($faturamento)) {
						$contrato = json_decode($this->modelo->getIfContrato($id_contrato));
						if (isset($contrato) && !empty($contrato)) {
							$id_proposta = $contrato[0]->id_proposta;
							$proposta = json_decode($this->modelo->getPropostas(7));
							$pacote_propostas = json_decode($this->modelo->getPacotePropostas($id_proposta));
							if (isset($pacote_propostas) && !empty($pacote_propostas) && count($pacote_propostas) == 1) {
								$faturamento[0]->hospedagem = $pacote_propostas[0]->preco_pkt;
							}

							if (isset($proposta) && !empty($proposta)) {
								$empresa_vendedora = json_decode($this->modelo->empresaVendedora(null, true));
								foreach ($proposta as $key => $value) {
									$faturamento[0]->empresa_vendedora = strtoupper($empresa_vendedora[0]->razao_social);
									$faturamento[0]->implantacao = $value->valor_implantacao;
									$faturamento[0]->parcelas = $value->numero_parcelas;
									if (isset($value->data_pagamento) && !empty($value->data_pagamento)) {
										$faturamento[0]->primeira_parcela = $value->data_pagamento;
									}

									if ($value->codigo == "RCK0001") {
										$faturamento[0]->duracao_contrato = "36 meses";
									} else {
										$faturamento[0]->duracao_contrato = "12 meses";
									}
								}
							}
						}
					} else {
						$duracao_contrato = $faturamento[0]->duracao_contrato;
					}
				}
				break;
			case 5:
				if (isset($user_fluxo_aprovacao) && $user_fluxo_aprovacao[0]->nome_perfil == "JURIDICO") {
					echo 'gerar minuta';
					//apagar
					// if(1==2){
					// 	if (isset($this->parametros[1]) && !empty($this->parametros[1])) {
					// 		$id_contrato = $this->parametros[1];
					// 		$contrato = json_decode($this->modelo->getIfContrato($id_contrato));
					// 		$id_proposta = $contrato[0]->id_proposta;
					// 		$preview_minuta = json_decode($this->modelo->getTextoMinuta($id_contrato));
					// 		if (!isset($preview_minuta) || empty($preview_minuta)) {
					// 			$proposta = json_decode($this->modelo->getPropostas($id_proposta));
					// 			$minuta = json_decode($this->minutaV2->gerarMinuta($proposta[0]->codigo));
					// 			$preview_minuta = $minuta->output;
					// 		}
					// 	}
					// }else{
					if (isset($this->parametros[1]) && !empty($this->parametros[1])) {
						$id_contrato = $this->parametros[1];
						$contrato = json_decode($this->modelo->getIfContrato($id_contrato));
						$id_proposta = $contrato[0]->id_proposta;
						$preview_minuta = json_decode($this->modelo->getTextoMinuta($id_contrato));
						if (!isset($preview_minuta) || empty($preview_minuta)) {
							$proposta = json_decode($this->modelo->getPropostas($id_proposta));
							$minuta = json_decode($this->minuta->gerarMinuta($proposta[0]->codigo));
							$preview_minuta = $minuta->output;
						}
					}
					// }

				} else {
					if (isset($this->parametros[1]) && !empty($this->parametros[1]) && is_numeric($this->parametros[1])) {
						$id_contrato = $this->parametros[1];
						$contrato = json_decode($this->modelo->getIfContrato($id_contrato));
						$ged = json_decode($this->modelo->gedDocumentoAnexo2($id_contrato, 'minuta'));
						$ged_proposta = json_decode($this->modelo->gedDocumentoAnexo2($contrato[0]->id_proposta, 'proposta'));
						$path = $ged ? (DS . PATH_MINUTA . $ged[0]->path_objeto . $ged[0]->nome_hash) : null;
						$path_proposta = $ged_proposta ? (PATH_PROPOSTA_R . $contrato[0]->cnpj . DS . 'proposta_finalizada' . DS . $ged_proposta[0]->nome_hash) : null;
					}
				}
				break;
			case 6:
				if (isset($this->parametros[1]) && !empty($this->parametros[1])) {
					$id_contrato = $this->parametros[1];
					$contrato = json_decode($this->modelo->getIfContrato($id_contrato));
					$id_proposta = $contrato[0]->id_proposta;

					$ged_proposta = json_decode($this->modelo->gedDocumentoAnexo2($id_proposta, 'proposta'));
					$ged = json_decode($this->modelo->gedDocumentoAnexo2($id_contrato, 'minuta'));
					$path = PATH_MINUTA_R . $ged[0]->path_objeto . $ged[0]->nome_hash;
					$path_proposta = PATH_PROPOSTA . $contrato[0]->cnpj . DS . 'proposta_finalizada' . DS . $ged_proposta[0]->nome_hash;
				}
				break;
			default:
				break;
		}

		//VERIFICO SE JÁ EXISTE NO BANCO DADOS DE CONTRATO, ENDEREÇO ... PARA LIBERAR A BARRA DE PROGRESSO 
		//E USAR OS DADOS DA INSTRUÇÃO DE FATURAMENTO AO INVÉS DE USAR OS DADOS DA PROPOSTA.
		if (isset($id_contrato)) {
			$if_contrato = json_decode($this->modelo->getIfContrato($id_contrato));
			$if_endereco = json_decode($this->modelo->getIfEndereco($id_contrato));
			$if_contato = json_decode($this->modelo->getIfContato($id_contrato, "minuta"));
			$if_faturamento = json_decode($this->modelo->getInstrucaofaturamento($id_contrato));
			$proposta = json_decode($this->modelo->getPropostas($if_contrato[0]->id_proposta));
			$minuta = json_decode($this->modelo->getTextoMinuta($id_contrato));
		}
		$produtos = json_decode($this->modelo->getProduto($proposta[0]->id_produto));
		if (isset($faturamento[0]->parcelas)) {
			$numero_parcelas = $faturamento[0]->parcelas;
		} elseif (isset($proposta[0]->numero_parcelas)) {
			$numero_parcelas = $proposta[0]->numero_parcelas;
		} else {
			$numero_parcelas = 0;
		}
		require_once ABSPATH . '/views/' . $this->nome_view . '/faturamento-detalhe-view.php';
	}
	function minutacrystal()
	{
		$get_minuta = json_decode($this->modelo->getMinuta(null, 'CRY0002'));
		require_once ABSPATH . '/views/' . $this->nome_view . '/minuta-crystal.php';
	}

	function save()
	{
		try {
			if (!isset($_POST['id_produto']) || empty($_POST['id_produto']) || !is_numeric($_POST['id_produto'])) {
				$retorno['codigo'] = 1;
				$retorno['mensagem'] = 'Informe o produto';
				throw new Exception(json_encode($retorno), 1);
			}

			$produto = json_decode($this->obj_documento->produtos_model->getProduto($_POST['id_produto']));
			switch ($produto[0]->codigo) {
				case 'CRY0003':
					$_POST['valor_implantacao'] = '1500';
					break;
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}

		$session = json_decode($_SESSION['cmswerp']['userdata']->permissoes);
		$retorno_save = $this->obj_documento->save($_POST, $this->parametros);
		if (isset($_POST['id_cm']) && !empty($_POST['id_cm']) && is_numeric($_POST['id_cm'])) {
			$empresa_cm = json_decode($this->empresas_cm->getEmpresa($_POST['id_cm']));
			$_POST['empresa'] = $empresa_cm[0]->razao_social;
		} else {
			echo 'erro';
			exit;
		}

		$retorno_json = json_decode($retorno_save);
		try {
			if ($session->modulos->Sales->{68}->permissoes <= 1 && $_SESSION['cmswerp']['userdata']->id != 42) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $session->modulos->Sales->{68}->permissoes;
				$retorno['output'] = $this->modelo->info;
				$retorno['mensagem'] = "Sem permissão para criar/editar proposta";
				throw new Exception(json_encode($retorno), 1);
			}

			if ($retorno_json->codigo == 1) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 0;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function pacote()
	{
		$session = json_decode($_SESSION['cmswerp']['userdata']->permissoes);
		$id_user = $_SESSION['cmswerp']['userdata']->id;
		$id_produto = $this->parametros[1];
		$id_proposta = $this->parametros[2];

		$pacote_padrao = json_decode($this->modelo->getPacotePropostas($id_proposta, $id_produto));
		$pacote_default = json_decode($this->modelo->getPacoteDefault(null, $id_produto));
		$proposta_tarifador = json_decode($this->modelo->getPropostasID($id_proposta));
		$records_produto = json_decode($this->modelo->getProdutosProposta($id_proposta));

		//VERIFICANDO ALÇADA DO USUÁRIO
		if ($session->modulos->Sales->{68}->alcadas <= 1) {
			$records_alcada = json_decode($this->modelo->getPropostas($$id_proposta, null, null, $id_user));
		}
		$produto = json_decode($this->obj_documento->produtos_model->getProduto($id_produto));

		if ($proposta_tarifador[0]->id_produto == 13) {
			$records = json_decode($this->obj_documento->produtos_model->getModulosEmpacotavel($id_produto, true, 8));
		} else {
			$records = json_decode($this->obj_documento->produtos_model->getModulosEmpacotavel($this->parametros[1], true));
		}

		$pacote_proposta = json_decode($this->modelo->getPacotePropostas($proposta_tarifador[0]->id));
		// insiro os pacotes padrão na proposta apenas em novas propostas
		if (!$pacote_proposta) {
			$this->obj_documento->insertPacote($this->parametros);
		}
		$records_status = json_decode($this->modelo->getPropostas($this->parametros[2]));
		$pacote = json_decode($this->modelo->getPacotePropostas($id_proposta, null, null, null, "ASC"));
		require_once ABSPATH . '/views/' . $this->nome_view . '/propostas-modulos-empacotavel.php';
	}

	function atualizarPacoteProposta()
	{
		$retorno_atualizar_pacote = $this->obj_documento->atualizarPacoteProposta($_POST, $this->parametros);
		$retorno_json = json_decode($retorno_atualizar_pacote);
		try {
			if ($retorno_json->codigo == 1) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 0;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function addPacote()
	{
		$retorno_add_pacote = $this->obj_documento->addPacote($_POST, $this->parametros);
		$retorno_json = json_decode($retorno_add_pacote);
		try {
			if ($retorno_json->codigo == 1) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 0;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function excluirPacoteProposta()
	{
		$retorno_excluir_pacote = $this->obj_documento->excluirPacoteProposta($this->parametros);
		$retorno_json = json_decode($retorno_excluir_pacote);
		try {
			if ($retorno_json->codigo == 1) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 0;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function produtos()
	{
		$session = json_decode($_SESSION['cmswerp']['userdata']->permissoes);
		$id_user = $_SESSION['cmswerp']['userdata']->id;
		set_time_limit(1800);
		if (is_numeric($this->parametros[1]) && !empty($this->parametros[1])) {
			$this->ultima_propostas = json_decode($this->modelo->getPropostasID($this->parametros[2]));
			$lp_proposta = json_decode($this->modelo->getLpPropostasId($this->ultima_propostas[0]->id));
			$records_produto = json_decode($this->modelo->getProdutosProposta($this->parametros[2]));

			if ($session->modulos->Sales->{68}->alcadas <= 1) {
				$records_alcada = json_decode($this->modelo->getPropostas($this->parametros[2], null, null, $id_user));
			}

			if (!$lp_proposta) {
				$this->obj_documento->insertTable($this->parametros);
			}

			if ($this->parametros[0] == "id_propostas") {
				$proposta = json_decode($this->modelo->getPropostasID($this->parametros[2]));
				$modulos_ativos = json_decode($this->obj_documento->produtos_model->getAllCodigoModulosAtivos($proposta[0]->id_produto));
				$records_status = json_decode($this->obj_documento->modelo->getPropostas($this->parametros[2]));
				if ($session->modulos->Sales->{68}->alcadas <= 1) {
					$records_alcada = json_decode($this->modelo->getPropostas($this->parametros[2], null, null, $id_user));
				}
			} else {
				$modulos_ativos = json_decode($this->obj_documento->produtos_model->getAllCodigoModulosAtivos($this->ultima_propostas[0]->id_produto));
				if ($session->modulos->Sales->{68}->alcadas <= 1) {
					$records_alcada = json_decode($this->modelo->getPropostasAlçada($this->parametros[2], $id_user));
				}
			}

			$produto = json_decode($this->obj_documento->produtos_model->getProduto($this->parametros[1]));
			$pacote = json_decode($this->modelo->getPacotePropostas($this->ultima_propostas[0]->id));
			$get_modulos_propostas = json_decode($this->modelo->getPropostasModuloByIdProposta($this->ultima_propostas[0]->id));

			if (isset($get_modulos_propostas) && is_array($get_modulos_propostas)) {
				foreach ($get_modulos_propostas as $key => $value) {
					if ($value->cod_modulo == "ASSTR001" && $value->deleted == 0) {
						$modulos_propostas['assessoria_str'] = $value->cod_modulo;
					}

					if ($value->cod_modulo == "ASPIX001" && $value->deleted == 0) {
						$modulos_propostas['assessoria_pix'] = $value->cod_modulo;
					}

					if ($value->cod_modulo == "BOHIB001" && $value->deleted == 0) {
						$modulos_propostas['boleto'] = $value->cod_modulo;
					}

					if ($value->cod_modulo == "PIXSI001" && $value->deleted == 0) {
						$modulos_propostas['pix_sinacor'] = $value->cod_modulo;
					}

					if ($value->cod_modulo == "ECS00021" && $value->deleted == 0) {
						$modulos_propostas['ecs'] = $value->cod_modulo;
					}

					if ($value->cod_modulo == "PIX00001" && $value->deleted == 0) {
						$modulos_propostas['pix'] = $value->cod_modulo;
					}

					if ($value->cod_modulo == "RCKEW001" && $value->deleted == 0) {
						$modulos_propostas['engine_workflow'] = $value->cod_modulo;
					}

					if ($value->cod_modulo == "RCKCO001" && $value->deleted == 0) {
						$modulos_propostas['cvc_onboarding'] = $value->cod_modulo;
					}

					if ($value->cod_modulo == "RCKCLC01" && $value->deleted == 0) {
						$modulos_propostas['clc'] = $value->cod_modulo;
					}

					if ($value->cod_modulo == "RCKOB001" && $value->deleted == 0) {
						$modulos_propostas['open_banking'] = $value->cod_modulo;
					}
				}
			}
			require_once ABSPATH . '/views/' . $this->nome_view . '/propostas-modulos-view.php';
		}
	}

	function listapreco()
	{
		$session = json_decode($_SESSION['cmswerp']['userdata']->permissoes);
		$id_user = $_SESSION['cmswerp']['userdata']->id;
		$this->ultima_propostas = json_decode($this->modelo->getPropostasID($this->parametros[3]));
		$produto_proposta = json_decode($this->modelo->getProdutosProposta($this->parametros[3]));
		$records = json_decode($this->obj_documento->produtos_model->getAllCodigoModulosAtivos(null, $this->parametros[2]));
		if ($this->parametros[0] === "default") {
			$lista_precos = json_decode($this->modelo->getLpPropostasDefault($this->ultima_propostas[0]->id, $this->parametros[1], $this->parametros[2]));
		} else if ($this->parametros[0] === "id_propostas") {
			$lista_precos = json_decode($this->modelo->getPropostasProdutoModulo($this->parametros[3], $this->parametros[1], $this->parametros[2]));
			$records_status = json_decode($this->modelo->getPropostas($this->parametros[3]));
		} else {
			$lista_precos = json_decode($this->modelo->getPropostasProdutoModulo($this->ultima_propostas[0]->id, $this->parametros[1], $this->parametros[2]));
		}
		//USO ESSA VARIAVEL PARA VERIFICAR O BOTAO DE ADD FAIXA
		if ($this->parametros[0] == "id_propostas") {
			$lp_modulo_editavel = json_decode($this->modelo->getPropostasProdutoModulo($this->parametros[3], $this->parametros[1], $this->parametros[2]));
			//VERIFICANDO PERMISSÃO DE ALÇADA
			if ($session->modulos->Sales->{68}->alcadas <= 1) {
				$records_alcada = json_decode($this->modelo->getPropostas($this->parametros[3], null, null, $id_user));
			}
		} else {
			$lp_modulo_editavel = json_decode($this->modelo->getPropostasProdutoModulo($this->ultima_propostas[0]->id, $this->parametros[1], $this->parametros[2]));
			//VERIFICANDO PERMISSÃO DE ALÇADA
			if ($session->modulos->Sales->{68}->alcadas <= 1) {
				$records_alcada = json_decode($this->modelo->getPropostasAlçada($this->parametros[3], $id_user));
			}
		}
		require_once ABSPATH . '/views/' . $this->nome_view . '/propostas-modulos-detalhe-view.php';
	}

	function saveFaixa()
	{
		$save_faixa = $this->obj_documento->saveFaixa($_POST, $this->parametros);
		$retorno_json = json_decode($save_faixa);
		try {
			if ($retorno_json->codigo == 1) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 0;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function atualizarFaixa()
	{
		$session = json_decode($_SESSION['cmswerp']['userdata']->permissoes);
		$atualizar_faixa = $this->obj_documento->atualizarFaixa($_POST, $this->parametros);
		$retorno_json = json_decode($atualizar_faixa);
		try {
			if ($session->modulos->Sales->{68}->permissoes <= 1) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $session->modulos->Sales->{68}->permissoes;
				$retorno['output'] = $this->modelo->info;
				$retorno['mensagem'] = "Sem permissão para criar/editar proposta";
				throw new Exception(json_encode($retorno), 1);
			}
			if ($retorno_json->codigo == 1) {
				$retorno['codigo'] = 1;
				$retorno['modal'] = "atualizar";
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 0;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function deletar()
	{
		$deletar = $this->obj_documento->deletar($this->parametros);
		$retorno_json = json_decode($deletar);
		try {
			if ($retorno_json->codigo == 1) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 0;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function lpDefault()
	{

		$lp_default = $this->obj_documento->lpDefault($this->parametros);
		$retorno_json = json_decode($lp_default);

		try {
			if ($retorno_json->codigo == 1) {

				$retorno['codigo'] = 1;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 0;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function saveModulosTexto()
	{

		$save_modulos_texto = $this->obj_documento->saveModulosTexto($this->parametros);
		$retorno_json = json_decode($save_modulos_texto);

		try {
			if ($retorno_json->codigo == 1) {

				$retorno['codigo'] = 1;
				$retorno['input'] = $post;
				$retorno['output'] = $this->modelo->info;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 0;
				$retorno['input'] = $post;
				$retorno['output'] = $this->modelo->info;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function enviarProposta()
	{
		$email = explode(";", $_POST['email_enviado']);
		if (!empty($_POST['email_enviado'])) {
			foreach ($email as $key => $value) {
				$value = str_replace(" ", "", $value);
				$email_replace[] = str_replace(" ", "", $value);
				if (filter_var($value, FILTER_VALIDATE_EMAIL) == false) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $post;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "* E-mail $value invalido";
					throw new Exception(json_encode($retorno), 1);
				}
			}
		} else {
			$retorno['codigo'] = 1;
			$retorno['input'] = $post;
			$retorno['output'] = $this->modelo->info;
			$retorno['mensagem'] = '* Informe o e-mail';
			throw new Exception(json_encode($retorno), 1);
		}

		if (empty($_POST['descricao']) || strlen($_POST['descricao']) <= 2) {
			$retorno['codigo'] = 1;
			$retorno['input'] = $post;
			$retorno['output'] = $this->modelo->info;
			$retorno['mensagem'] = '* Texto vazio';
			throw new Exception(json_encode($retorno), 1);
		}

		$records = json_decode($this->modelo->getPropostasTexto($this->parametros[1]));
		$enviar_proposta['to'] = $email_replace;
		$enviar_proposta['texto'] = $_POST['descricao'];

		if (!empty($records[0]->email_enviado)) {
			$_POST['email_enviado'] .= " ; " . $records[0]->email_enviado;
		}

		$this->modelo->setTable('propostas');
		$save = $this->modelo->save($_POST, $records[0]->id);
		if (!$save) {
			$retorno['codigo'] = 1;
			$retorno['input'] = $_POST;
			$retorno['output'] = $this->modelo->info;
			$retorno['mensagem'] = "Erro ao registrar envio de e-mail";
			throw new Exception(json_encode($retorno), 1);
		}

		$ged = json_decode($this->modelo->gedDocumentoAnexo($records[0]->id));
		$enviar_proposta = $this->obj_notificacao->sendNotificacao('proposta', $enviar_proposta, $records, $ged[0]->nome_hash);
		$retorno_json = json_decode($enviar_proposta);

		try {
			if ($retorno_json->codigo == 1) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 0;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function texto()
	{
		set_time_limit(1800);
		$session = json_decode($_SESSION['cmswerp']['userdata']->permissoes);
		$id_user = $_SESSION['cmswerp']['userdata']->id;
		if ($session->modulos->Sales->{68}->permissoes == 0) {
			$permissao = "sem_permissao";
		} else if ($session->modulos->Sales->{68}->permissoes == 1) {
			$permissao = "visualizar";
		} else if ($session->modulos->Sales->{68}->permissoes == 2) {
			$permissao = "editar";
		} else if ($session->modulos->Sales->{68}->permissoes == 4) {
			$permissao = "aprovar";
		}

		if (isset($this->parametros[1]) && !empty($this->parametros[1])) {
			//setando id da proposta para buscar o arquivo com slide na view
			if (isset($this->parametros[2])) {
				$id_proposta = $this->parametros[2];
			}

			$records = json_decode($this->modelo->getPropostasTexto($id_proposta));
			$proposta_modulo = json_decode($this->modelo->getPropostaProduto($id_proposta));
			$Aprovacao = new Aprovacao($this, $proposta_modulo[0]->codigo, $proposta_modulo[0]->id);
			$etapasAprovacao = $Aprovacao->getGrupos();
			$aprovadoresAtuais = $Aprovacao->getAprovadores();
			$lp_fora_padrao = json_decode($this->modelo->getLpForaPadrao($records[0]->id));
			$pacote_fora_padrao = json_decode($this->modelo->getPacotePropostasEditada($records[0]->id));
			$pacote_default = json_decode($this->modelo->getPacoteDefault($records[0]->id));
			$lp_padrao_excluida = json_decode($this->modelo->getLpPadraoExcluida($records[0]->id));
			$cod_produto = $proposta_modulo[0]->codigo;

			$implantacao = funcValor($records[0]->valor_implantacao, 'C', 2);

			if ($proposta_modulo[0]->codigo == 'FSP0001') {
				//FULL / 15.000,00 / 2000000
				$codigo = "STR0000";
			} elseif ($proposta_modulo[0]->codigo == 'SPI0001') {
				// SPI/x / 10.000,00 / 1000000
				$codigo = "SPI0023";
			} elseif ($proposta_modulo[0]->codigo == 'ATF0001') {
				//CornerPIX / 10.000,00 / 3000000
				$codigo = "ATF0013";
			} elseif ($proposta_modulo[0]->codigo == 'SOE0001') {
				// SPB/x OBE / 30.000,00 / 22
				$codigo = "SOE0012";
			} elseif ($proposta_modulo[0]->codigo == 'CRY0001') {
				// Crystal AMC / 20.000,00 / 4000001
				$codigo = "CRY0010";
			} elseif ($proposta_modulo[0]->codigo == 'ECS0001') {
				//Exclusive Collocation Service / 35.000,00 / 21
				$codigo = "ECS0010";
			} else if ($proposta_modulo[0]->codigo == 'RCK0001') {
				//ROCKET IMPLANTAÇÃO: / 47.190,00 / 13
				$codigo = "RCK0033";
				// IMPLANTAÇÃO CLC 5.000,00	// RCK0068
				$modulo = json_decode($this->modelo->getPropostasModuloByIdProposta($id_proposta));
				foreach ($modulo as $key => $value) {
					if ($value->cod_modulo == "RCKCLC01" && $value->deleted == 0) {
						$codigo = "RCK0068";
					}
				}
			} else if ($proposta_modulo[0]->codigo == 'YLW0001') {
				$codigo = 'YLW0001';
			} else if ($proposta_modulo[0]->codigo == "TPX0001") {
				$codigo = "TPX0010";
			} else if ($proposta_modulo[0]->codigo == 'CRY0002') {
				$codigo = "CRY0001";
			} else {
				$implantacao_fora_padrao = null;
				$implantacao_padrao = $implantacao;
			}

			$get_implantacao = json_decode($this->modelo->getLpByCodigo(null, $codigo));
			if (isset($get_implantacao) && !empty($get_implantacao)) {
				$implantacao_padrao = funcValor($get_implantacao[0]->valor_real, 'C', 2);
			}

			if (isset($implantacao) && isset($implantacao_padrao)) {
				if ($implantacao != $implantacao_padrao) {
					$implantacao_fora_padrao = $implantacao;
				} else {
					$implantacao_fora_padrao = null;
				}
			} else {
				$implantacao_fora_padrao = null;
			}

			if ($this->parametros[0] == "id_propostas" || $this->parametros[0] == "editar") {
				if ($session->modulos->Sales->{68}->alcadas > 1) {
					$records_alcada = json_decode($this->modelo->getPropostas($id_proposta, null, null, $id_user));
				} else {
					//VERIFICANDO PERMISSÃO DE ALÇADA
					$records_alcada = json_decode($this->modelo->getPropostasAlçada($id_proposta, $id_user));
				}
			}
			$ged = json_decode($this->modelo->gedDocumentoAnexo($id_proposta));
		}
		$get_user_perfil = json_decode($this->modelo->getUsuariosPerfil($this->id_user));
		require_once ABSPATH . '/views/' . $this->nome_view . '/propostas-editar-view.php';
	}

	function foraPadrao()
	{
		include 'config_extras.php';
		$records = json_decode($this->modelo->getPropostasTexto($this->parametros[1]));
		$proposta_modulo = json_decode($this->modelo->getPropostaProduto($records[0]->id));
		$pacote_fora_padrao = json_decode($this->modelo->getPacotePropostasEditada($records[0]->id));
		$lp_fora_padrao = json_decode($this->modelo->getLpForaPadrao($records[0]->id));
		$pacote_default = json_decode($this->modelo->getPacoteDefault($records[0]->id_produto));
		$pacote = json_decode($this->modelo->getPacotePropostas($records[0]->id));


		if (isset($lp_fora_padrao)) {
			foreach ($lp_fora_padrao as $key => $value) {
				$lp = json_decode($this->modelo->getLpProposta($records[0]->id, $value->id_modulo));
			}
		}

		$implantacao = funcValor($records[0]->valor_implantacao, 'C', 2);

		if ($proposta_modulo[0]->codigo == 'ATF0001') {
			$codigo = "ATF0013";
		} elseif ($proposta_modulo[0]->codigo == 'SPI0001') {
			$codigo = "SPI0023";
		} elseif ($proposta_modulo[0]->codigo == 'FSP0001') {
			$codigo = "STR0000";
		} elseif ($proposta_modulo[0]->codigo == 'SOE0001') {
			$codigo = "SOE0012";
			$pacote_default[0]->descricao = $VAR_SYSTEM['TEXTO_SLIDE']['SPB/X OBE']['DESCRICAO'];
			$pacote_default[0]->qdt_garantido = $VAR_SYSTEM['TEXTO_SLIDE']['SPB/X OBE']['QUANTIDADE_GARANTIDA'];
			$pacote_default[0]->preco_pkt = $VAR_SYSTEM['TEXTO_SLIDE']['SPB/X OBE']['FATURAMENTO_MINIMO'];
		} elseif ($proposta_modulo[0]->codigo == 'CRY0001') {
			$codigo = "CRY0010";
		} else if ($proposta_modulo[0]->codigo == 'CRY0002') {
			$codigo = "CRY0001";
		} elseif ($proposta_modulo[0]->codigo == 'ECS0001') {
			$codigo = "ECS0010";
			$pacote_default = json_decode($this->modelo->getLpByCodigo(null, 'ECS0011'));
			$pacote_default[0]->preco_pkt = $pacote_default[0]->valor_real;
		} else if ($proposta_modulo[0]->codigo == 'RCK0001') {
			$codigo = "RCK0033";
			$get_implantacao = json_decode($this->modelo->getLpByCodigo(null, $codigo));
			$implantacao_padrao = funcValor($get_implantacao[0]->valor_real, 'C', 2);
			if ($implantacao == $implantacao_padrao) {
				$implantacao_fora_padrao = null;
			} else {
				$implantacao_fora_padrao = $implantacao;
			}
			$modulo_clc = json_decode($this->modelo->getPropostasModuloByIdProposta($records[0]->id, "RCKCLC01"));
			if (isset($modulo_clc) && $modulo_clc[0]->deleted == 0) {
				$codigo = "RCK0068";
				$get_implantacao = json_decode($this->modelo->getLpByCodigo(null, $codigo));
				$implantacao_padrao = funcValor($get_implantacao[0]->valor_real, 'C', 2);

				if ($implantacao == $implantacao_padrao) {
					$implantacao_fora_padrao = null;
				} else {
					$implantacao_fora_padrao = $implantacao;
				}

				$pacote_clc = json_decode($this->modelo->getPacoteDefault($records[0]->id_produto, 83));
				if (isset($pacote_clc) && !empty($pacote_clc) && isset($pacote) && !empty($pacote)) {
					if ($pacote[0]->quantidade_garantido != $pacote_clc[0]->qdt_garantido || $pacote[0]->preco_pkt != $pacote_clc[0]->preco_pkt) {
						$pacote_fora_padrao = json_decode($this->modelo->getPacotePropostas($records[0]->id));
					} else {
						$pacote_fora_padrao = null;
					}
				}
				$records[0]->nome_produto = "Rocket (CLC)";
				$pacote_default[0]->descricao = "Rocket Engine (CLC)";
				$pacote_default[0]->qdt_garantido = $pacote_clc[0]->qdt_garantido;
				$pacote_default[0]->preco_pkt = $pacote_clc[0]->preco_pkt;
			} else {
				$pacote_default = json_decode($this->modelo->getPacoteDefault($records[0]->id_produto, 8));
				if (
					funcValor($pacote_fora_padrao[0]->preco_pkt, 'C', 0) == funcValor($pacote_default[0]->preco_pkt, 'C', 0) &&
					funcValor($pacote_fora_padrao[0]->quantidade_garantido, 'C', 0) == funcValor($pacote_default[0]->qdt_garantido, 'C', 0)
				) {
					$pacote_fora_padrao = null;
				}
				if ($implantacao == $implantacao_padrao) {
					$implantacao_fora_padrao = null;
				} else {
					$implantacao_fora_padrao = $implantacao;
				}
			}
		} else if ($proposta_modulo[0]->codigo == 'TPX0001') {
			$codigo = "TPX0010";
		} else if ($proposta_modulo[0]->codigo == 'YLW0001') {
			$codigo = "YLW0010";
		} else {
			$implantacao_fora_padrao = null;
			$implantacao_padrao = $implantacao;
		}


		$get_implantacao = json_decode($this->modelo->getLpByCodigo(null, $codigo));
		$implantacao_padrao = funcValor($get_implantacao[0]->valor_real, 'C', 2);

		if ($proposta_modulo[0]->codigo == "FSP0001") {
			$pacote_default = $VAR_SYSTEM['TEXTO_SLIDE']['PACOTE_FULL'];
		}
		if (!isset($modulo_clc)) {
			if ($implantacao != $implantacao_padrao) {
				$implantacao_fora_padrao = $implantacao;
			} else {
				$implantacao_fora_padrao = null;
			}
		}

		require_once ABSPATH . '/views/' . $this->nome_view . '/propostas-fora-padrao-view.php';
	}

	function finalizar()
	{

		$finalizar = $this->obj_documento->finalizar($this->parametros);
		$retorno_json = json_decode($finalizar);
		try {
			if ($retorno_json->codigo == 1) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 0;
				$retorno['input'] = $retorno_json->input;
				$retorno['output'] = $retorno_json->output;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function alterarStatus()
	{
		$alterar_status = $this->obj_documento->alterarStatus($_POST, $this->parametros);
		$retorno_json = json_decode($alterar_status);
		try {
			if ($retorno_json->codigo == 2) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['output'] = $this->modelo->info;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} else {

				$proposta = json_decode($this->modelo->getPropostas($this->parametros[1]));
				$Aprovacao = new Aprovacao($this, $proposta[0]->codigo, $proposta[0]->id);
				$res =  $Aprovacao->criaProximaAprovacao(['id' => $proposta[0]->id]);

				// $retorno['codigo'] = 0;
				// $retorno['input'] = $_POST;
				// $retorno['output'] = $this->modelo->info;
				// $retorno['mensagem'] = $retorno_json->mensagem;
				// throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function alterarStatusProposta()
	{
		$alterar_status = $this->obj_documento->alterarStatusProposta($this->parametros);
		$retorno_json = json_decode($alterar_status);
		try {
			if ($retorno_json->codigo == 1) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $post;
				$retorno['output'] = $this->modelo->info;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 0;
				$retorno['input'] = $post;
				$retorno['output'] = $this->modelo->info;
				$retorno['mensagem'] = $retorno_json->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function pdf()
	{
		$gerar_pdf = $this->obj_documento->pdf($this->parametros);
	}

	function abrirPDF()
	{

		$records = json_decode($this->modelo->getPropostasTexto($this->parametros[2]));
		$abrir_pdf = $this->obj_pptx->abrirArquivo($this->parametros[2], $records[0]->cnpj_cpf);
	}

	function atualizarSlide($exception = null)
	{
		try {
			$modulo_array = null;
			if (
				$this->parametros[2] == "AOPdetalhe" ||
				$this->parametros[2] == "AOPpacote" ||
				$this->parametros[2] == "AOPlistapreco"
			) {
				$modulo = json_decode($this->modelo->getPropostasModuloByIdProposta($this->parametros[1]));
				if (isset($modulo) && is_array($modulo)) {
					foreach ($modulo as $key => $value) {
						if ($value->cod_modulo == "ASSTR001" && $value->deleted == 0) {
							$modulo_array['assessoria_str'] = $value->cod_modulo;
						}
						if ($value->cod_modulo == "ASPIX001" && $value->deleted == 0) {
							$modulo_array['assessoria_pix'] = $value->cod_modulo;
						}
						if ($value->cod_modulo == "BOHIB001" && $value->deleted == 0) {
							$modulo_array['boleto'] = $value->cod_modulo;
						}
						if ($value->cod_modulo == "PIXSI001" && $value->deleted == 0) {
							$modulo_array['pix_sinacor'] = $value->cod_modulo;
						}
						if ($value->cod_modulo == "ECS00021" && $value->deleted == 0) {
							$modulo_array['ecs'] = $value->cod_modulo;
						}
						if ($value->cod_modulo == "PIX00001" && $value->deleted == 0) {
							$modulo_array['pix'] = $value->cod_modulo;
						}
						if ($value->cod_modulo == "RCKEW001" && $value->deleted == 0) {
							$modulo_array['engine_workflow'] = $value->cod_modulo;
						}
						if ($value->cod_modulo == "RCKCO001" && $value->deleted == 0) {
							$modulo_array['cvc_onboarding'] = $value->cod_modulo;
						}
						if ($value->cod_modulo == "RCKCLC01" && $value->deleted == 0) {
							$modulo_array['clc'] = $value->cod_modulo;
						}
						if ($value->cod_modulo == "RCKOB001" && $value->deleted == 0) {
							$modulo_array['open_banking'] = $value->cod_modulo;
						}
					}
				}
			} else {
				$modulo = $this->parametros[2];
				$modulo = explode(",", $modulo);
				if (isset($modulo) && is_array($modulo)) {
					foreach ($modulo as $key => $value) {
						if ($value == "assessoria_str") {
							$modulo_array['assessoria_str'] = "ASSTR001";
						}
						if ($value == "assessoria_pix") {
							$modulo_array['assessoria_pix'] = "ASPIX001";
						}

						if ($value == "boleto_hibrido") {
							$modulo_array['boleto'] = "BOHIB001";
						}

						if ($value == "pix_sinacor") {
							$modulo_array['pix_sinacor'] = "PIXSI001";
						}

						if ($value == "ecs") {
							$modulo_array['ecs'] = "ESC00001";
						}

						if ($value == "pix") {
							$modulo_array["pix"] = "PIX00001";
						}

						if ($value == "engine_workflow") {
							$modulo_array["engine_workflow"] = "RCKEW001";
						}

						if ($value == "cvc_onboarding") {
							$modulo_array["cvc_onboarding"] = "RCKCO001";
						}

						if ($value == "clc") {
							$modulo_array["clc"] = "RCKCLC01";
						}

						if ($value == "open_banking") {
							$modulo_array['open_banking'] = "RCKOB001";
						}
					}
				}
			}


			$this->parametros[2] = $this->parametros[1];
			$records = json_decode($this->modelo->getPropostasTexto($this->parametros[2]));
			$id_proposta = $records[0]->id;
			switch ($records[0]->codigo) {
				case "COR0001":
					$result = json_decode($this->slidePDF($modulo_array));
					if ($result->codigo == 0) {
						throw new Exception(json_encode($result));
						// $retorno_merger = $this->obj_documento->mergerPDF($id_proposta, $records, $records[0]->cnpj_cpf, $modulo_array);
					} else {
						$retorno['codigo'] = 1;
						if (isset($result->mensagem)) {
							$retorno['mensagem'] = $result->mensagem;
						} else {
							$retorno['mensagem'] = "Erro ao gerar pptx COD: 1385";
						}
						throw new Exception(json_encode($retorno));
					}
					break;
				case 'RCK0001':
				case 'CRY0001':
				case 'CRY0002':
				case 'CRY0003':
				case 'CPA0001':
				case 'YLW0001':
					$slide = $this->slidePDF($modulo_array);
					if ($slide == "sucesso_condicoes_comerciais") {
						$retorno_merger = $this->obj_documento->mergerPDF($id_proposta, $records, $records[0]->cnpj_cpf, $modulo_array);
					} else {
						$retorno['codigo'] = 1;
						if (isset($slide['mensagem'])) {
							$retorno['mensagem'] = $slide['mensagem'];
						} else {
							$retorno['mensagem'] = "Erro ao gerar pptx COD: 1385";
						}
						throw new Exception(json_encode($retorno));
					}
					break;
				default:
					//ESSA VARIÁVEL RECEBE O MODULO ARRAY RETORNADO PELA FUNÇÃO slideIntroducao
					$slide_introducao = $this->obj_pptx->slideIntroducao($id_proposta, $records, $modulo_array);
					if ($slide_introducao == "sucesso_introducao") {
						$slide = $this->slidePDF($modulo_array);
						if ($slide == "sucesso_condicoes_comerciais") {
							$retorno_merger = $this->obj_documento->mergerPDF($id_proposta, $records, $records[0]->cnpj_cpf, $modulo_array);
						} else {
							$retorno['codigo'] = 1;
							if (isset($slide['mensagem'])) {
								$retorno['mensagem'] = $slide['mensagem'];
							} else {
								$retorno['mensagem'] = "Erro ao gerar pptx COD: 1250";
							}
							throw new Exception(json_encode($retorno));
						}
					} else {
						throw new Exception(json_encode($slide_introducao));
					}
					break;
			}
		} catch (Excpetion $e) {
			echo $e->getMessage();
		}
	}

	function slidePDF($modulo_array = null)
	{
		$records = json_decode($this->modelo->getPropostasTexto($this->parametros[2]));
		if ($records[0]->numero_parcelas == "1") {
			$records[0]->texto_parcelamento = "ocorrerá em 10 dias após a assinatura do contrato.";
		} else if ($records[0]->numero_parcelas == "2") {
			$records[0]->texto_parcelamento = "Pagamento em 2 (duas) parcelas, com a primeira parcela em 10 dias após a assinatura do contrato e as demais parcelas a cada 30 dias consecutivamente.";
		} else if ($records[0]->numero_parcelas == "3") {
			$records[0]->texto_parcelamento = "Pagamento em 3 (três) parcelas, com a primeira parcela em 10 dias após a assinatura do contrato e as demais parcelas a cada 30 dias consecutivamente.";
		} else {
			$records[0]->texto_parcelamento = "Pagamento em " . $records[0]->numero_parcelas . " parcelas, com a primeira parcela em 10 dias após a assinatura do contrato e as demais parcelas a cada 30 dias consecutivamente.";
		}

		if ($records[0]->codigo === "FSP0001") {
			$lp_produto = json_decode($this->modelo->getLpPropostasId($records[0]->id, $records[0]->codigo));
			foreach ($lp_produto as $key => $value) {
				if ($value->codigo_modulo == 'STR0001') {
					$lp['full_str_web'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'PIX0010') {
					$lp['credito1'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'PIX0011') {
					$lp['credito2'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'PIX0012') {
					$lp['credito3'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'PIX0013') {
					$lp['credito4'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'PIX0014') {
					$lp['debito1'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'PIX0015') {
					$lp['debito2'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'PIX0016') {
					$lp['debito3'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'PIX0017') {
					$lp['debito4'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'PIX0019') {
					$lp['hora_homem'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'STR0002') {
					$lp['implantacao_pix'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'STR0003') {
					$lp['implantacao_str'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'STR0004') {
					$lp['pix_sinacor'] = $value->valor_real;
				}
			}
			$pacote = json_decode($this->modelo->getPacotePropostas($records[0]->id, null, null, null, "ASC"));
			$pacote_opcional = json_decode($this->modelo->getPacoteOpcional($records[0]->codigo));
			if ($modulo_array['boleto'] == "BOHIB001") {
				foreach ($lp_produto as $key => $value) {
					if ($value->codigo_modulo == 'PIX0027') {
						$lp['baixa_pix'] = $value->valor_real;
					}
					if ($value->codigo_modulo == 'PIX0028') {
						$lp['geracao_boleto_pdf'] = $value->valor_real;
					}
					if ($value->codigo_modulo == 'PIX0029') {
						$lp['geracao_fatura_pdf'] = $value->valor_real;
					}
					if ($value->codigo_modulo == 'PIX0030') {
						$lp['envio_email'] = $value->valor_real;
					}
					if ($value->codigo_modulo == 'PIX0031') {
						$lp['envio_sms'] = $value->valor_real;
					}
				}
			}

			if (isset($pacote)) {
				return $slide_pdf = $this->obj_pptx->slideFullSTR($this->parametros[2], $records, $pacote, $lp, $modulo_array);
			} else {
				return $slide_pdf = $this->obj_pptx->slideFullSTR($this->parametros[2], $records, $pacote_opcional, $lp, $modulo_array);
			}
		} elseif ($records[0]->codigo === "SOE0001") {
			//ESSA VARIÁVEL RECEBE O PACOTE SPB/X OPEN BANKING EDITION TRANSAÇÕES DOMINIO 01 E 02
			$pacote = json_decode($this->modelo->getPacotePropostas($records[0]->id));
			//ESSA VARIÁVEL RECEBE A LISTA DE PREÇO  OPEN BANKING EDITION TRANSAÇÕES DOMINIO 01 E 02
			$lp_modulo = json_decode($this->modelo->getLpByCodigo(null, 'SOE0010'));
			//MODULOS DO OBE			
			$lp = json_decode($this->modelo->getLpByCodigo('SOE0001'));
			foreach ($lp as $key => $value) {
				if ($value->codigo_modulo == 'SOE0016') {
					$array_lp['web_service'] = $value;
				}
				if ($value->codigo_modulo == 'SOE0017') {
					$array_lp['conversao_batch'] = $value;
				}
				if ($value->codigo_modulo == 'SOE0011') {
					$array_lp['boletos_compensados'] = $value;
				}
				if ($value->codigo_modulo == 'SOE0015') {
					$array_lp['tratamento_inconsistencia'] = $value;
				}
			}
			if ($modulo_array['boleto'] == "BOHIB001" || $modulo_array['assessoria_str'] == "ASSTR001") {
				// UTILIZEI DA LISTA DE PREÇO DO FULL, PARA PEGAR A LISTA DE PREÇO DOS MODULOS DO BOLETO HIBRIDO.
				$lp_full = json_decode($this->modelo->getLpByCodigo('FSP0001'));
			}
			//MODULOS BOLETO HIBIDRO 							
			if ($modulo_array['boleto'] == "BOHIB001") {
				foreach ($lp_full as $key => $value) {
					if ($value->codigo_modulo == 'PIX0027') {
						$array_lp['baixa_pix'] = $value;
					}
					if ($value->codigo_modulo == 'PIX0028') {
						$array_lp['geracao_boleto_pdf'] = $value;
					}
					if ($value->codigo_modulo == 'PIX0029') {
						$array_lp['geracao_fatura_pdf'] = $value;
					}
					if ($value->codigo_modulo == 'PIX0030') {
						$array_lp['envio_email'] = $value;
					}
					if ($value->codigo_modulo == 'PIX0031') {
						$array_lp['envio_sms'] = $value;
					}
				}
			}
			// ASSESSORIA STR
			if ($modulo_array['assessoria_str'] == "ASSTR001") {
				foreach ($lp_full as $key => $value) {
					if ($value->codigo_modulo == 'STR0003') {
						$array_lp['assessoria_str'] = $value;
					}
				}
			}
			if ($pacote) {
				return $slide_pdf = $this->obj_pptx->slideSPBxObe($this->parametros[2], $records, $pacote, $lp_modulo, $array_lp, $modulo_array);
			} else {
				return $slide_pdf = $this->obj_pptx->slideSPBxObe($this->parametros[2], $records, null, $lp_modulo, $array_lp, $modulo_array);
			}
		} elseif ($records[0]->codigo === "ATF0001") {
			$pacote_proposta = json_decode($this->modelo->getPacotePropostas($records[0]->id));
			if (isset($pacote_proposta) && !empty($pacote_proposta)) {
				$pacote = $pacote_proposta;
			} else {
				$pacote = json_decode($this->modelo->getPacoteDefault($records[0]->id_produto));
			}
			$lp = json_decode($this->modelo->getLpByCodigo($records[0]->codigo));

			foreach ($lp as $key => $value) {
				if ($value->codigo_modulo == "ATF0010") {
					$array_lp['transacao_aprovada'] = $value;
				}
				if ($value->codigo_modulo == "ATF0011") {
					$array_lp['transacao_recusada'] = $value;
				}
				if ($value->codigo_modulo == "ATF0012") {
					$array_lp['transacao_detalhada'] = $value;
				}
				if ($value->codigo_modulo == "ATF0015") {
					$array_lp['licenciamento_mensal'] = $value;
				}
			}

			if ($pacote) {
				return $slide_pdf = $this->obj_pptx->slideCornerPixAntifraude($this->parametros[2], $records, $pacote, $array_lp);
			} else {
				return $slide_pdf = $this->obj_pptx->slideCornerPixAntifraude($this->parametros[2], $records, null, $array_lp);
			}
		} elseif ($records[0]->codigo === "SPI0001") {
			$lp_produto = json_decode($this->modelo->getLpByCodigo($records[0]->codigo));
			foreach ($lp_produto as $key => $value) {
				if ($value->codigo_modulo == 'SPI0010') {
					$lp['credito1'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'SPI0011') {
					$lp['credito2'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'SPI0012') {
					$lp['credito3'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'SPI0013') {
					$lp['credito4'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'SPI0014') {
					$lp['debito1'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'SPI0015') {
					$lp['debito2'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'SPI0016') {
					$lp['debito3'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'SPI0017') {
					$lp['debito4'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'SPI0024') {
					$lp['implantacao_pix'] = $value->valor_real;
				}
				if ($value->codigo_modulo == 'SPI0018') {
					$lp['pix_sinacor'] = $value->valor_real;
				}
				if ($value->codigo_modulo == "SPI0020") {
					$lp['hora_homem'] = $value->valor_real;
				}
			}

			if ($pacote) {
				return $slide_pdf = $this->obj_pptx->slideSPIx($this->parametros[2], $records, $pacote, $lp, $modulo_array);
			} else {
				return $slide_pdf = $this->obj_pptx->slideSPIx($this->parametros[2], $records, null, $lp, $modulo_array);
			}
		} elseif ($records[0]->codigo === "ECS0001") {
			$pacote = json_decode($this->modelo->getPacotePropostas($records[0]->id));
			if (!isset($pacote) && empty($pacote)) {
				$pacote_default = json_decode($this->modelo->getLpByCodigo(null, 'ECS0011'));
			}

			if (isset($pacote)) {
				return $slide_pdf = $this->obj_pptx->slideExclusiveCollocationService($this->parametros[2], $records, $pacote);
			} else {
				return $slide_pdf = $this->obj_pptx->slideExclusiveCollocationService($this->parametros[2], $records, null, $pacote_default);
			}
		} elseif ($records[0]->codigo === "CRY0001") {
			$lp_crystal = json_decode($this->modelo->getLpByCodigo($records[0]->codigo));
			foreach ($lp_crystal as $key => $value) {
				if ($value->codigo_modulo == 'CRY0011') {
					$lp_crystal['response_api'] = $value;
				}

				if ($value->codigo_modulo == 'CRY0012') {
					$lp_crystal['request_api'] = $value;
				}
			}
			return $slide_pdf = $this->obj_pptx->slideCrystal($this->parametros[2], $records, $lp_crystal);
		} elseif ($records[0]->codigo === "CRY0002") {
			$lp_crystal = json_decode($this->modelo->getLpByCodigo($records[0]->codigo));
			foreach ($lp_crystal as $key => $value) {
				if ($value->codigo_modulo == 'CRY0002') {
					$lp_crystal['response_api'] = $value;
				}

				if ($value->codigo_modulo == 'CRY0003') {
					$lp_crystal['request_api'] = $value;
				}
			}
			$hora_homem = json_decode($this->modelo->getLpByCodigo("CRY0002", "CRY0004"));
			$pacote_crystal = json_decode($this->modelo->newPacoteDefault($records[0]->codigo));
			$lp_crystal['hora_homem'] = $hora_homem[0];
			$lp_crystal['pacote_crystal'] = $pacote_crystal[0];
			return $slide_pdf = $this->obj_pptx->slideCrystal($this->parametros[2], $records, $lp_crystal, "CRY2");
		} elseif ($records[0]->codigo === "CRY0003") {
			$lista_crystal = json_decode($this->modelo->getLpByCodigo($records[0]->codigo));
			$pacote_crystal = json_decode($this->modelo->newPacoteDefault($records[0]->codigo));
			$lp_crystal['lista_crystal'] = $lista_crystal;
			$lp_crystal['pacote_crystal'] = $pacote_crystal;
			return $slide_pdf = $this->obj_pptx->SlideCrystalBMC($this->parametros[2], $records, $lp_crystal);
		} elseif ($records[0]->codigo === "RCK0001") {
			$lp_rocket = json_decode($this->modelo->getLpProposta($records[0]->id));
			$lista_produtos = json_decode($this->obj_documento->produtos_model->getAllCodigoModulosAtivos($records[0]->id_produto));
			foreach ($lp_rocket as $key => $value) {
				switch ($value->codigo) {
					case 'RCK0016':
					case 'RCK0019':
					case 'RCK0025':
					case 'RCK0038':
					case 'RCK0048':
						$i1 = $value->codigo;
						$i2 = $value->cod_modulo;
						$faixa = $value->qtd_de . '-' . $value->qtd_ate;
						$conjunto_slide['modulos_rocket']['nome'][$i2] = $value->descricao . " ($i2)";
						$conjunto_slide['modulos_rocket']['faixa'][$faixa][$i2] = $value->valor_real;
						ksort($conjunto_slide['modulos_rocket']['nome']);
						// ksort($conjunto_slide['modulos_rocket']['faixa']);
						ksort($conjunto_slide['modulos_rocket']['faixa'][$faixa]);
						break;
					case 'RCK0012':
					case 'RCK0013':
					case 'RCK0021':
					case 'RCK0022':
					case 'RCK0026':
						$i1 = $value->codigo;
						$i2 = $value->cod_modulo;
						$faixa = $value->qtd_de . '-' . $value->qtd_ate;
						$conjunto_slide['modulos_validacao_cadastral']['nome'][$i2] = $value->descricao . " ($i2)";
						$conjunto_slide['modulos_validacao_cadastral']['faixa'][$faixa][$i2] = $value->valor_real;
						ksort($conjunto_slide['modulos_validacao_cadastral']['nome']);
						// ksort($conjunto_slide['modulos_validacao_cadastral']['faixa']);
						ksort($conjunto_slide['modulos_validacao_cadastral']['faixa'][$faixa]);
						break;
					case 'RCK0029':
					case 'RCK0032':
					case 'RCK0042':
					case 'RCK0044':
						$i1 = $value->codigo;
						$i2 = $value->cod_modulo;
						$faixa = $value->qtd_de . '-' . $value->qtd_ate;
						$conjunto_slide['camara_liquidacao']['nome'][$i2] = $value->descricao . " ($i2)";
						$conjunto_slide['camara_liquidacao']['faixa'][$faixa][$i2] = $value->valor_real;
						ksort($conjunto_slide['camara_liquidacao']['nome']);
						// ksort($conjunto_slide['camara_liquidacao']['faixa']);
						ksort($conjunto_slide['camara_liquidacao']['faixa'][$faixa]);
						break;
					case 'RCK0060':
					case 'RCK0061':
					case 'RCK0062':
					case 'RCK0063':
					case 'RCK0064':
					case 'RCK0065':
					case 'RCK0065':
					case 'RCK0067':
						$i1 = $value->codigo;
						$i2 = $value->cod_modulo;
						$faixa = $value->qtd_de . '-' . $value->qtd_ate;
						$conjunto_slide['open_banking']['nome'][$i2] = $value->descricao . " ($i2) ";
						$conjunto_slide['open_banking']['modulos'][$i2][$faixa] = $value->valor_real;
						$conjunto_slide['open_banking']['faixa'][$faixa][$i2] = $value->valor_real;
						ksort($conjunto_slide['open_banking']['nome']);
						// ksort($conjunto_slide['open_banking']['faixa']);
						ksort($conjunto_slide['open_banking']['faixa'][$faixa]);
						break;
				}
			}

			$nome_modulos['1de'] = "De";
			$nome_modulos['2ate'] = "Até";
			$nome_modulos2['1de'] = "De";
			$nome_modulos2['2ate'] = "Até";
			$nome_modulos3['1de'] = "De";
			$nome_modulos3['2ate'] = "Até";
			$nome_modulos4['1de'] = "De";
			$nome_modulos4['2ate'] = "Até";
			$nome_modulos5['1de'] = "De";
			$nome_modulos5['2ate'] = "Até";

			$excecao = array('RCK0048', 'RCK0011', 'RCK0024', 'RCK0025', 'RCK0028', 'RCK0015', 'RCK0016', 'RCK0017', 'RCK0018', 'RCK0020', 'RCK0030', 'RCK0019', 'RCK0038');
			$excecao2 = array('RCK0026', 'RCK0012', 'RCK0013', 'RCK0014');
			$excecao3 = array('RCK0021', 'RCK0022');
			$excecao4 = array('RCK0032', 'RCK0044', 'RCK0029', 'RCK0042');
			$excecao5 = array('RCK0060', 'RCK0061', 'RCK0062', 'RCK0063', 'RCK0064', 'RCK0065', 'RCK0066', 'RCK0067');
			$excecao_all = array('RCK0048', 'RCK0011', 'RCK0024', 'RCK0025', 'RCK0028', 'RCK0015', 'RCK0016', 'RCK0017', 'RCK0018', 'RCK0020', 'RCK0030', 'RCK0019', 'RCK0038', 'RCK0026', 'RCK0012', 'RCK0013', 'RCK0014', 'RCK0021', 'RCK0022', 'RCK0032', 'RCK0044', 'RCK0029', 'RCK0042', 'RCK0036', 'RCK0037', 'RCK0023');

			foreach ($lista_produtos as $key => $value) {
				if (in_array($value->codigo_modulo, $excecao)) {
					$i1 = $value->id_modulo;
					$nome_modulos[$i1] = $value->nome_modulo . " ($value->codigo_modulo)";
				}
				if (in_array($value->codigo_modulo, $excecao2)) {
					$i1 = $value->id_modulo;
					$nome_modulos2[$i1] = $value->nome_modulo . " ($value->codigo_modulo)";
				}
				if (in_array($value->codigo_modulo, $excecao3)) {
					$i1 = $value->id_modulo;
					$nome_modulos3[$i1] = $value->nome_modulo . " ($value->codigo_modulo)";
				}
				if (in_array($value->codigo_modulo, $excecao4)) {
					$i1 = $value->id_modulo;
					$nome_modulos4[$i1] = $value->nome_modulo . " ($value->codigo_modulo)";
				}
				if (in_array($value->codigo_modulo, $excecao5)) {
					$i1 = $value->id_modulo;
					$nome_modulos5[$i1] = $value->nome_modulo . " ($value->codigo_modulo)";
				}
				if (in_array($value->codigo_modulo, $excecao_all)) {
					$i1 = $value->id_modulo;
					$legenda[$i1]['nome_modulo'] = $value->nome_modulo;
					$legenda[$i1]['codigo_modulo'] = $value->codigo_modulo;
				}
			}

			foreach ($lp_rocket as $key => $value) {
				if (in_array($value->codigo, $excecao)) {
					$i1 = $value->id_modulo;
					$tabela['header'] = $nome_modulos;
					$tabela['faixa'][$i1][] = $value->valor_real;
				}
				if (in_array($value->codigo, $excecao2)) {
					$i1 = $value->id_modulo;
					$tabela['header2'] = $nome_modulos2; //deveria ser nome 
					$tabela['faixa2'][$i1][] = $value->valor_real;
				}
				if (in_array($value->codigo, $excecao3)) {
					$i1 = $value->id_modulo;
					$tabela['header3'] = $nome_modulos3; //deveria ser nome 
					$tabela['faixa3'][$i1][] = $value->valor_real;
				}
				if (in_array($value->codigo, $excecao4)) {
					$i1 = $value->id_modulo;
					$tabela['header4'] = $nome_modulos4; //deveria ser nome 
					$tabela['faixa4'][$i1][] = $value->valor_real;
				}
				if (in_array($value->codigo, $excecao5)) {
					$i1 = $value->id_modulo;
					$tabela['header5'] = $nome_modulos5; //deveria ser nome 
					$tabela['faixa5'][$i1][] = $value->valor_real;
				}
			}

			ksort($tabela['header']);
			ksort($tabela['faixa']);
			rsort($tabela['faixa'][22]);

			ksort($tabela['header2']);
			ksort($tabela['faixa2']);

			ksort($tabela['header3']);
			ksort($tabela['faixa3']);

			ksort($tabela['header4']);
			ksort($tabela['faixa4']);

			ksort($tabela['header5']);
			ksort($tabela['faixa5']);

			ksort($legenda);

			$contador = 0;
			$valor_de = 0;
			$valor_ate = 10000;

			foreach ($tabela['faixa'][22] as $key => $value) {
				if ($key > 22) {
					unset($tabela['faixa'][22][$key]);
				}
				if ($contador < 22) {
					if ($contador == 21) {
						$array_faixa[$contador]['de'] = 'Acima de:';
						$array_faixa[$contador]['ate'] = 10000000;
					} else {
						$array_faixa[$contador]['de'] = $valor_de;
						$array_faixa[$contador]['ate'] = $valor_ate;
					}
					if ($contador == 0 || $contador == 9 || $contador >= 18) {
						$valor_de = 1;
					}
					if ($contador >= 9) {
						if ($contador >= 18) {
							if ($contador == 18) {
								$valor_de = $valor_de + 1000000;
								$valor_ate = $valor_ate + 4000000;
							} else {
								$valor_de = $valor_de + 5000000;
								$valor_ate = $valor_ate + 5000000;
							}
						} else {
							$valor_de = $valor_de + 100000;
							$valor_ate = $valor_ate + 100000;
						}
					} else {
						$valor_de = $valor_de + 10000;
						$valor_ate = $valor_ate + 10000;
					}
				}
				$contador++;
			}

			foreach ($lp_rocket as $key => $value) {
				$i = $value->id_modulo;
				$lp[$i][] = $value;
			}

			$tabela['pdv-carta'] = json_decode($this->modelo->getLpByCodigo(null, 'RCK0023'));
			$tabela['serpro'] = json_decode($this->modelo->getLpByCodigo(null, 'RCK0036'));
			$tabela['legenda'] = $legenda;

			$tabela['face_id'] = json_decode($this->modelo->getLpByCodigo(null, 'RCK0070'));
			$tabela['token_pix'] = json_decode($this->modelo->getLpByCodigo(null, 'RCK0069'));

			$pacote_default['pacote_serpro'] = json_decode($this->modelo->getPacoteDefault(null, null, null, null, 'RCK0036'));
			$pacote = json_decode($this->modelo->getPacotePropostas($records[0]->id));
			return $slide_pdf = $this->obj_pptx->slideRocket($this->parametros[2], $records, $lp, $pacote, $tabela, $array_faixa, $modulo_array, $pacote_default, $conjunto_slide);
		} elseif ($records[0]->codigo === "TPX0001") {
			$lp = json_decode($this->modelo->getLpByCodigo(null, 'TPX0011'));
			if (isset($lp)) {
				return $slide_pdf = $this->obj_pptx->slideTriploPix($this->parametros[2], $records, $lp);
			} else {
				return $slide_pdf = $this->obj_pptx->slideTriploPix($this->parametros[2], $records);
			}
		} elseif ($records[0]->codigo === "YLW0001") {
			$lista_preco['rocket_mcm'] = json_decode($this->modelo->getLpByCodigo(null, 'RCK0019'));
			$lp_yellow = json_decode($this->modelo->getLpPropostaByCodigo('YLW0001', null, $records[0]->id));
			if (isset($lp_yellow) && is_array($lp_yellow)) {
				foreach ($lp_yellow as $key => $value) {
					$lista_preco[$value->codigo_modulo][] = $value;
				}
			}
			return $this->obj_pptx->slideYellow($this->parametros[2], $records, $lista_preco);
		} elseif ($records[0]->codigo === "CPA0001") {
			$precos = json_decode($this->modelo->getLpByCodigo($records[0]->codigo));
			$pacotes = json_decode($this->modelo->newPacoteDefault($records[0]->codigo));
			$lista_precos['listas'] = $precos;
			$lista_precos['pacotes'] = $pacotes;
			return $slide_pdf = $this->obj_pptx->SlideCornerInvoice($this->parametros[2], $records, $lista_precos);
		} else if ($records[0]->codigo == "COR0001") {
			$lp_cornerFull = json_decode($this->modelo->getLpPropostaByCodigo('COR0001', null, $records[0]->id));
			// $lp_produto = json_decode($this->modelo->getLpPropostasId($records[0]->id, $records[0]->codigo));
			$pacotes = json_decode($this->modelo->getPacotePropostas($records[0]->id));
			$lista_precos['listas'] = $lp_cornerFull;
			$lista_precos['pacotes'] = $pacotes;

			foreach ($lista_precos['listas'] as $lp) {
				// $listaPreco[$lp->qtd_de . '.' . $lp->qtd_ate][] = $lp;
				$listaPreco[$lp->id_modulo][] = $lp;
			}

			$moduloDestacado = [];

			foreach ($listaPreco as $key => $value) {
				// CORNER FULL ( CORNER FULL BH (GERAÇÃO BOLETO PDF COM DADOS VARIÁVEIS) )
				if ($key == 8000147) {
					$moduloDestacado[$key] = $value;
				} else {
					if (count($value) == 1) {
						$arrValorUnico[$key] = $value;
					} else {
						$arrFaixa[$key] = $value;
					}
				}
			}
			asort($arrValorUnico);
			$arrValorUnico = array_values($arrValorUnico);

			$data = [
				'proposta' => $records[0],
				'arrValorUnico' => $arrValorUnico,
				'arrFaixa' => $arrFaixa,
				'moduloDestacado' => $moduloDestacado
			];

			return $this->obj_pptx->slideCornerFull($data);
		} else {
			$slide_pdf = $this->obj_pptx->phpPresentation($this->parametros[2]);
		}
	}

	function dashBoard()
	{
		$session = json_decode($_SESSION['cmswerp']['userdata']->permissoes);
		$id_user = $_SESSION['cmswerp']['userdata']->id;
		if ($session->modulos->Sales->{68}->permissoes == 4) {
			$records = json_decode($this->modelo->getPropostas());
			$propostas_pendente = json_decode($this->modelo->getPropostasPendentesAprovadas('pendente'));
			$propostas_fechada = json_decode($this->modelo->getPropostasPendentesAprovadas());

			$proposta_fora_padrao = json_decode($this->modelo->getPropostasTexto(null, true, true));
			$proposta_ultimo_seis_meses = json_decode($this->modelo->getPropostasByMesesAnteriores('fechada'));
		} else {
			$records = json_decode($this->modelo->getPropostas(null, null, null, $id_user));
			$propostas_pendente = json_decode($this->modelo->getPropostasPendentesAprovadas('pendente', $id_user));
			$propostas_fechada = json_decode($this->modelo->getPropostasPendentesAprovadas(null, $id_user));
			$proposta_fora_padrao = json_decode($this->modelo->getPropostasTexto(null, true, true, $id_user));
			$proposta_ultimo_seis_meses = json_decode($this->modelo->getPropostasByMesesAnteriores('fechada', $id_user));
		}

		if (is_array($proposta_ultimo_seis_meses)) {
			foreach ($proposta_ultimo_seis_meses as $key => $value) {
				$data_criacao = getDataAtual($value->data_criacao);
				$i1 = $value->id_owner;
				$i2 = $data_criacao->format('Y-m');
				$pro_aprov_mes[$i2] += 1;
				if ($data_criacao->format('m') == $this->data_hora_atual->format('m')) {
					$pro_aprov_owner[$i1]['nome'] = $value->nome_usuario;
					$pro_aprov_owner[$i1]['count'][$i2] += 1;
				}
			}
			ksort($pro_aprov_mes);
		}

		if ($pro_aprov_mes) {
			foreach ($pro_aprov_mes as $key => $value) {
				$string_mes .= "{year: " . "'" . $key . "'" . ", propostas:" . $value . "},";
			}
		} else {
			$string_mes .= "{year: " . "'" . $this->data_hora_atual->format('Y-m') . "'" . ", propostas:0},";
		}

		if ($pro_aprov_owner) {
			foreach ($pro_aprov_owner as $key => $value) {
				$string_owner_mes .= "{ y: " . "'" . $value['nome'] . "'" . ", a: " . count($value['count']) . ",},";
			}
		} else {
			$string_owner_mes .= "{ y: " . "'Nenhuma proposta aprovada'" . ", a: 0},";
		}
		require_once ABSPATH . '/views/' . $this->nome_view . '/dashboard-view.php';
	}

	function mediaValor($valor_implantacao, $valor_pacote, $data)
	{
		// A data informada, neste caso data da proposta.
		$data_atual = getDataAtual($data);
		$mes_proposta = $data_atual->format('m');
		$fatorMes = (12 - $mes_proposta);

		$media = ($valor_implantacao + ($valor_pacote * $fatorMes));
		return $media;
	}

	//By: Caio Freitas - 01/07/2022
	function verificaFaturamento()
	{
		try {
			if (isset($this->parametros[0]) && !empty($this->parametros[0])) {
				$codigo_requisicao = $this->parametros[0];
			} else {
				$codigo_requisicao = 1;
			}

			switch (isset($_POST['tipo_data_faturamento']) && !empty($_POST['tipo_data_faturamento'])) {
				case 'dias_apos_faturamento':
					switch ($_POST['codigo_produto']) {
						case 'CRY0003':
						case 'YLW0001':
							if (!isset($_POST['dias_apos_faturamento']) || empty($_POST['dias_apos_faturamento'])) {
								$_POST['dias_apos_faturamento'] = 30;
							}

							if ($_POST['dias_apos_faturamento'] > 30) {
								$retorno['codigo'] = 1;
								$retorno['input'] = $_POST;
								$retorno['output'] = null;
								$retorno['mensagem'] = "O maximo de dias para esse produto é de 30 dias";
								throw new Exception(json_encode($retorno), 1);
							}
							break;
						default:
							if (!isset($_POST['dias_apos_faturamento']) || empty($_POST['dias_apos_faturamento'])) {
								$_POST['dias_apos_faturamento'] = 10;
							}

							if ($_POST['dias_apos_faturamento'] > 10) {
								$retorno['codigo'] = 1;
								$retorno['input'] = $_POST;
								$retorno['output'] = null;
								$retorno['mensagem'] = "O maximo de dias para esse produto é de 10 dias";
								throw new Exception(json_encode($retorno), 1);
							}
							break;
					}
					break;
			}

			switch ($codigo_requisicao) {
				case '1':
					if (!isset($_POST['cnpj_cpf']) || empty($_POST['cnpj_cpf'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe o CNPJ/CPF";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['cnpj'] = removeCaracteres($_POST['cnpj_cpf'], 'all');
						$insert['codigo_cliente'] = substr($insert['cnpj'], 0, -6);
					}

					if (!isset($_POST['razao_social']) || empty($_POST['razao_social'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe a razão social";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['razao_social'] = $_POST['razao_social'];
					}

					if (!isset($_POST['nome_fantasia']) || empty($_POST['nome_fantasia'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe a razão social";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['nome_fantasia'] = $_POST['nome_fantasia'];
					}

					if (!isset($_POST['produto']) || empty($_POST['produto'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe o produto";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['id_produto'] = $_POST['produto'];
					}

					if (!isset($_POST['segmento']) || empty($_POST['segmento'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe o segmento";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['segmento'] = $_POST['segmento'];
					}

					if (isset($_POST['site'])) {
						$insert['site'] = $_POST['site'];
					}

					if (!isset($_POST['status']) || empty($_POST['status'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe o status";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['status'] = $_POST['status'];
					}

					if (isset($_POST['obs_contrato']) || !empty($_POST['obs_contrato'])) {
						$insert['obs_contrato'] = $_POST['obs_contrato'];
					}

					$retorno_save = $this->obj_faturamento->save('contrato', $insert);
					if (isset($retorno_save) && $retorno_save['codigo'] == 0) {
						throw new Exception(json_encode($retorno_save), 1);
					} else {
						throw new Exception(json_encode($retorno_save), 1);
					}
					break;
				case '2':
					$retorno_save = $this->obj_faturamento->save('endereco');
					if (isset($retorno_save) && $retorno_save['codigo'] == 0) {
						throw new Exception(json_encode($retorno_save), 1);
					} else {
						throw new Exception(json_encode($retorno_save), 1);
					}
					break;
				case '3':
					$retorno_save = $this->obj_faturamento->save('contato');
					if (isset($retorno_save) && $retorno_save['codigo'] == 0) {
						throw new Exception(json_encode($retorno_save), 1);
					} else {
						throw new Exception(json_encode($retorno_save), 1);
					}
					break;
				case '4':
					if (!isset($_POST['empresa_vendedora']) || empty($_POST['empresa_vendedora'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe a empresa vendedora";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['empresa_vendedora'] = $_POST['empresa_vendedora'];
					}

					if (isset($_POST['duracao_contrato']) && !empty($_POST['duracao_contrato'])) {
						$insert['duracao_contrato'] = $_POST['duracao_contrato'];
					} else {
						$insert['duracao_contrato'] = "";
					}

					if (!isset($_POST['renovacao_automatica']) || $_POST['renovacao_automatica'] == "") {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe a renovação automática";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['renovacao_automatica'] = $_POST['renovacao_automatica'];
					}

					if (!isset($_POST['indeterminado']) || $_POST['indeterminado'] == "") {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe o campo indeterminado";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['indeterminado'] = $_POST['indeterminado'];
					}

					if (!isset($_POST['indice_reajuste']) || empty($_POST['indice_reajuste'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe o índice de reajuste";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['reajuste'] = $_POST['indice_reajuste'];
					}

					if (!isset($_POST['moeda']) || empty($_POST['moeda'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe a moeda";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['moeda'] = $_POST['moeda'];
					}

					if (!isset($_POST['imposto']) || $_POST['imposto'] == "") {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe o preço com imposto";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['preco_imposto'] = $_POST['imposto'];
					}

					if (!isset($_POST['valor_implantacao']) || empty($_POST['valor_implantacao'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe o valor de implantacao";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['implantacao'] = removeCaracteres($_POST['valor_implantacao'], 'moeda2');
					}

					if (!isset($_POST['parcelas']) || empty($_POST['parcelas'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe a parcela";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['parcelas'] = $_POST['parcelas'];
					}

					if (!isset($_POST['faturamento_todo_dia']) || $_POST['faturamento_todo_dia'] == "") {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe o campo dia do faturamento";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['faturamento_todo_dia'] = $_POST['faturamento_todo_dia'];
					}

					if (!isset($_POST['tipo_data_faturamento']) || $_POST['tipo_data_faturamento'] == "") {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe o tipo de faturamento";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['tipo_data_faturamento'] = $_POST['tipo_data_faturamento'];
					}

					if (isset($insert['tipo_data_faturamento']) && $insert['tipo_data_faturamento'] == "vencimento_todo_dia") {
						if (!isset($_POST['vencimento_todo_dia']) || $_POST['vencimento_todo_dia'] == "") {
							$retorno['codigo'] = 1;
							$retorno['input'] = $_POST;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Informe o campo vencimento todo dia";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$insert['vencimento_todo_dia'] = $_POST['vencimento_todo_dia'];
							$insert['dias_apos_faturamento'] = null;
						}

						if ($insert['faturamento_todo_dia'] == $insert['vencimento_todo_dia']) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $_POST;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Dia do faturamento não pode ser igual a data de vencimento";
							throw new Exception(json_encode($retorno), 1);
						}
					} else if (isset($insert['tipo_data_faturamento']) && $insert['tipo_data_faturamento'] == "dias_apos_faturamento") {
						if (!isset($_POST['dias_apos_faturamento']) || $_POST['dias_apos_faturamento'] == "") {
							$retorno['codigo'] = 1;
							$retorno['input'] = $_POST;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Informe o campo dias após o faturamento";
							throw new Exception(json_encode($retorno), 1);
						} else {
							switch ($_POST['codigo_produto']) {
								case 'CRY0003':
								case 'YLW0001':
									$limite_dias = 30;
									break;
								default:
									$limite_dias = 10;
									break;
							}

							if ($_POST['dias_apos_faturamento'] > $limite_dias) {
								$retorno['codigo'] = 1;
								$retorno['input'] = $_POST;
								$retorno['output'] = null;
								$retorno['mensagem'] = "Máximo " . $limite_dias . " dias após o faturamento";
								throw new Exception(json_encode($retorno), 1);
							} else {
								$insert['dias_apos_faturamento'] = $limite_dias;
								$insert['vencimento_todo_dia'] = null;
							}
						}
					}

					if (isset($_POST['hospedagem']) && !empty($_POST['hospedagem'])) {
						$insert['hospedagem'] = removeCaracteres($_POST['hospedagem'], "moeda2");
					}

					if (!isset($_POST['percentual_multa']) || empty($_POST['percentual_multa'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe o campo percentual de multa";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['percentual_multa'] = str_replace("%", "", $_POST['percentual_multa']);
						if (empty($insert['percentual_multa'])) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $_POST;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Informe o campo percentual da multa";
							throw new Exception(json_encode($retorno), 1);
						}
					}

					if (!isset($_POST['percentual_juros']) || empty($_POST['percentual_juros'])) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Informe o campo percentual de juros";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['percentual_juros'] = str_replace("%", "", $_POST['percentual_juros']);
						if (empty($insert['percentual_juros'])) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $_POST;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Informe o campo percentual de juros";
							throw new Exception(json_encode($retorno), 1);
						}
					}

					$retorno_save = $this->obj_faturamento->save('faturamento', $insert);
					if (isset($retorno_save) && $retorno_save['codigo'] == 0) {
						throw new Exception(json_encode($retorno_save), 1);
					} else {
						throw new Exception(json_encode($retorno_save), 1);
					}
					break;
				case '5':
					$user_fluxo_aprovacao = json_decode($this->modelo->fluxoOrdemAprovacao($this->id_user, 'minuta'));
					if (isset($user_fluxo_aprovacao) && $user_fluxo_aprovacao[0]->nome_perfil == "JURIDICO") {
						$etapa = "minuta";
					} else {
						$etapa = "preview";
					}
					$retorno_save = $this->obj_faturamento->save($etapa, $_POST);
					if (isset($retorno_save) && $retorno_save['codigo'] == 0) {
						throw new Exception(json_encode($retorno_save), 1);
					} else {
						throw new Exception(json_encode($retorno_save), 1);
					}
					break;
				case '6':
					$retorno_save = $this->obj_faturamento->save('preview', $_POST);
					if (isset($retorno_save) && $retorno_save['codigo'] == 0) {
						if ($retorno_save['input'][0]->codigo == "RCK0001") {
							$retorno['etapa'] = 'x';
							$retorno['codigo'] = 0;
							$retorno['input'] = $pdf_customizacao['input'];
							$retorno['output'] = $pdf_customizacao['output'];
							$retorno['mensagem'] = "Sucesso";
							/*
							$pdf_customizacao = $this->obj_faturamento->insertGedCustomizacao( $this->parametros[1] );			
							if( $pdf_customizacao['codigo'] == 0 ){
								$retorno['etapa']	 = 'x';
								$retorno['codigo']   = 0;		
								$retorno['input']    = $pdf_customizacao['input'];
								$retorno['output']   = $pdf_customizacao['output'];
								$retorno['mensagem'] = "Sucesso";
							}else{
								$retorno['etapa']	 = 'x';
								$retorno['codigo']   = 1;		
								$retorno['input']    = $pdf_customizacao['input'];
								$retorno['output']   = $pdf_customizacao['output'];
								$retorno['mensagem'] = "Erro ao gerar contrato de customização";
							}*/
							throw new Exception(json_encode($retorno), 1);
						} else {
							throw new Exception(json_encode($retorno_save), 1);
						}
					} else {
						throw new Exception(json_encode($retorno_save), 1);
					}
					break;
				default:
					break;
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 01/07/2022
	function excluirContato()
	{
		try {
			if (!isset($this->parametros[0]) || empty($this->parametros[0])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao parâmetros";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$id_contato = $this->parametros[0];
				$deleted['deleted'] = '1';
			}

			$this->modelo->setTable('if_contato');
			$update = $this->modelo->save($deleted, $id_contato);

			if ($update) {
				$retorno['codigo'] = 0;
				$retorno['input'] = $update;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Sucesso em excluir contato";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $save;
				$retorno['output'] = $this->modelo->info;
				$retorno['mensagem'] = "Erro ao excluir";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 01/07/2022
	function detalheContato()
	{
		try {
			if (!isset($this->parametros[0]) || empty($this->parametros[0])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao parâmetros";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$id_contato = $this->parametros[0];
			}

			$contato = json_decode($this->modelo->getContato($id_contato));
			if ($contato) {
				$retorno['codigo'] = 0;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = $contato;
				$retorno['mensagem'] = "Sucesso";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $contato;
				$retorno['output'] = $this->modelo->info;
				$retorno['mensagem'] = "Erro ao obter detalhe de contato";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 01/07/2022
	function addContato()
	{
		try {
			if (isset($this->parametros[0]) && !empty($this->parametros[0])) {
				$id_contrato = $this->parametros[0];
				$insert['id_contrato'] = $this->parametros[0];
				$insert['origem'] = "minuta";
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro parâmetros";
				throw new Exception(json_encode($retorno), 1);
			}

			if (!isset($_POST['nome']) || empty($_POST['nome'])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Informe o nome";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$insert['nome'] = $_POST['nome'];
			}

			if (!isset($_POST['email']) || empty($_POST['email'])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Informe o email";
				throw new Exception(json_encode($retorno), 1);
			} else {
				if (validar(trim($_POST['email']), 'email') == false) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "E-mail inválido";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$insert['email'] = trim($_POST['email']);
				}
			}

			if (!isset($_POST['telefone']) || empty($_POST['telefone'])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Informe o telefone";
				throw new Exception(json_encode($retorno), 1);
			} else {
				if (validar($_POST['telefone'], 'telefone') == false) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Telefone inválido";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$insert['telefone'] = removeCaracteres($_POST['telefone'], 'all');
				}
			}

			if (!isset($_POST['tipo_contato']) || empty($_POST['tipo_contato'])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Informe o tipo de contato";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$insert['tipo_contato'] = $_POST['tipo_contato'];
			}

			if (isset($insert['tipo_contato']) && ($insert['tipo_contato'] == "responsavel_legal" || $insert['tipo_contato'] == "tecnico")) {
				if (!isset($_POST['cargo_setor']) || empty($_POST['cargo_setor'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Informe o cargo/setor";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$insert['cargo_setor'] = $_POST['cargo_setor'];
				}
			}

			if (
				isset($insert['tipo_contato']) &&
				($insert['tipo_contato'] == "responsavel_legal" || $insert['tipo_contato'] == "testemunha" || $insert['tipo_contato'] == "juridico")
			) {
				if (!isset($_POST['cpf']) || empty($_POST['cpf'])) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $_POST;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Informe o CPF do contato";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$_POST['cpf'] = str_replace(".", "", $_POST['cpf']);
					$_POST['cpf'] = str_replace("-", "", $_POST['cpf']);
					if (validar($_POST['cpf'], 'cpf') != true) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $_POST;
						$retorno['output'] = null;
						$retorno['mensagem'] = "CPF inválido";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert['cpf'] = preg_replace('/[^0-9]/is', '', $_POST['cpf']);
					}
				}
			}

			$retorno_save = $this->obj_faturamento->addContato($id_contrato, $insert);
			if (isset($retorno_save) && $retorno_save['codigo'] == 0) {
				throw new Exception(json_encode($retorno_save), 1);
			} else {
				throw new Exception(json_encode($retorno_save), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 12/07/2022
	function detalheComissao()
	{
		try {
			if (!isset($this->parametros[0]) || empty($this->parametros[0])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao parâmetros";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$id_comissao = $this->parametros[0];
			}

			$comissao = json_decode($this->modelo->getIfComissao(null, $id_comissao));
			if ($comissao) {
				$retorno['codigo'] = 0;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = $comissao;
				$retorno['mensagem'] = "Sucesso";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = $this->modelo->info;
				$retorno['mensagem'] = "Erro ao obter detalhe de comissão";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 12/07/2022
	function excluirComissao()
	{
		try {
			if (!isset($this->parametros[0]) || empty($this->parametros[0])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao parâmetros";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$id_comissao = $this->parametros[0];
				$deleted['deleted'] = '1';
			}

			$comissao = json_decode($this->modelo->getIfComissao(null, $id_comissao));
			if (!isset($comissao) || empty($comissao)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao obter comissão";
				throw new Exception(json_encode($retorno), 1);
			}

			$this->modelo->setTable('comissoes_perfil_usuario');
			$update_perfil = $this->modelo->save($deleted, $comissao[0]->id_perfil_usuario);
			if (!$update_perfil) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = $this->modelo->info;
				$retorno['mensagem'] = "Erro ao excluir comercial";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 0;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = $update_perfil;
				$retorno['mensagem'] = "Sucesso em excluir comercial";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 08/08/2022
	function addEndereco()
	{
		try {
			if (isset($this->parametros[0]) && !empty($this->parametros[0])) {
				$insert['id_contrato'] = $this->parametros[0];
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro parâmetros";
				throw new Exception(json_encode($retorno), 1);
			}

			if (!isset($_POST['cep']) || empty($_POST['cep'])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Informe o CEP";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$insert['cep'] = removeCaracteres($_POST['cep'], 'all');
			}

			if (!isset($_POST['endereco']) || empty($_POST['endereco'])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Informe o endereco";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$insert['endereco'] = $_POST['endereco'];
			}

			if (!isset($_POST['numero']) || empty($_POST['numero'])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Informe o número";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$insert['numero'] = $_POST['numero'];
			}

			if (!isset($_POST['bairro']) || empty($_POST['bairro'])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Informe o bairro";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$insert['bairro'] = $_POST['bairro'];
			}

			if (isset($_POST['complemento']) && !empty($_POST['complemento'])) {
				$insert['complemento'] = $_POST['complemento'];
			}

			if (!isset($_POST['estado']) || empty($_POST['estado'])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Informe o estado";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$insert['estado'] = $_POST['estado'];
			}
			if (!isset($_POST['cidade']) || empty($_POST['cidade'])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Informe a cidade";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$insert['cidade'] = $_POST['cidade'];
			}

			if (!isset($_POST['tipo_endereco']) || empty($_POST['tipo_endereco'])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Informe o tipo de endereco";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$insert['tipo_endereco'] = $_POST['tipo_endereco'];
			}

			$retorno_save = $this->obj_faturamento->addEndereco($insert);
			if (isset($retorno_save) && $retorno_save['codigo'] == 0) {
				throw new Exception(json_encode($retorno_save), 1);
			} else {
				throw new Exception(json_encode($retorno_save), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 01/07/2022
	function detalheEndereco()
	{
		try {
			$retorno_save = $this->obj_faturamento->detalheEndereco();
			if (isset($retorno_save) && $retorno_save['codigo'] == 0) {
				throw new Exception(json_encode($retorno_save), 1);
			} else {
				throw new Exception(json_encode($retorno_save), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 08/08/2022
	function excluirEndereco()
	{
		try {
			$retorno_save = $this->obj_faturamento->excluirEndereco();
			if (isset($retorno_save) && $retorno_save['codigo'] == 0) {
				throw new Exception(json_encode($retorno_save), 1);
			} else {
				throw new Exception(json_encode($retorno_save), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 18/07/2022
	function statusAprovacao()
	{
		try {
			$id_user = $_SESSION['cmswerp']['userdata']->id;
			if (!isset($id_user)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ID USER";
				throw new Exception(json_encode($retorno), 1);
			}

			//CLASSE PARA VERIFICAR PERMISSÕES
			$class_permissao = json_decode($this->aprovacao->checkPermissoes('propostas', 'controller'));
			if (isset($class_permissao) && $class_permissao->codigo == 1) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = $class_permissao->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}

			if (!isset($this->parametros[0]) || empty($this->parametros[0])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro parâmetros";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$id_proposta = $this->parametros[0];
			}

			if (!isset($this->parametros[1]) || empty($this->parametros[1])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro parâmetros";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$acao = $this->parametros[1];
				if ($acao == "aprovar") {
					$insert['status'] = '1';
				} else {
					$insert['status'] = '0';
				}
			}

			$contrato = json_decode($this->modelo->getContratoProposta(null, $id_proposta));
			if (!isset($contrato) || empty($contrato)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Necessário preencher a instrução de faturamento";
				throw new Exception(json_encode($retorno), 1);
			} else {
				if ($contrato[0]->finalizado == 0) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Necessário finalizar a instrução de faturamento";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$insert['objeto'] = "minuta";
					$insert['id_objeto'] = $contrato[0]->id;
				}
			}

			//CLASSE PARA VERIFICAR FLUXO DE APROVAÇÃO
			$class_aprovacao = json_decode($this->aprovacao->statusAprovacao('minuta', $contrato[0]->id, $acao));
			if (isset($class_aprovacao) && $class_aprovacao->codigo == 1) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = $class_aprovacao->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}

			$user_fluxo_aprovacao = json_decode($this->modelo->fluxoOrdemAprovacao($id_user, 'minuta', $contrato[0]->id_cm));
			if (!isset($user_fluxo_aprovacao) || empty($user_fluxo_aprovacao)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->controller->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Usuário sem fluxo de aprovação cadastrado COD:2720";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$insert['id_ordem_aprovacao'] = $user_fluxo_aprovacao[0]->id;
				$user_status_aprovacao = json_decode($this->modelo->allFluxoAprovacao('minuta', $contrato[0]->id, null, null, $user_fluxo_aprovacao[0]->ordem));
			}

			if ($user_fluxo_aprovacao[0]->ordem == 1 && $acao == "aprovar") {
				$retorno_obj = $this->aprovacao->aprovacaoComercial('minuta', $contrato[0]->id);
				if (isset($retorno_obj) && $retorno_obj['codigo'] == 1) {
					throw new Exception(json_encode($retorno_obj), 1);
				}
			}

			$this->modelo->setTable("fluxo_status_aprovacao");
			$save = $this->modelo->save($insert, $user_status_aprovacao[0]->id);
			if ($save) {
				if (strtoupper($user_fluxo_aprovacao[0]->nome_perfil) != "JURIDICO" && $acao == "aprovar") {
					$parametros["user_comercial"] = $contrato[0]->email_owner;
					$parametros["id"] = $contrato[0]->id_proposta;
					$this->obj_notificacao->alertaTeams('aprovado_comercial', $parametros);
				} else {
					if ($acao == "aprovar") {
						$parametros["user_comercial"] = $contrato[0]->email_owner;
						$parametros["id"] = $contrato[0]->id_proposta;
						$this->obj_notificacao->alertaTeams('aprovado_juridico', $parametros);
					}
				}
				$retorno['codigo'] = 0;
				$retorno['input'] = $insert;
				$retorno['output'] = $contrato[0]->id_proposta;
				$retorno['mensagem'] = "Sucesso";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $insert;
				$retorno['output'] = $this->modelo->info;
				$retorno['mensagem'] = "Erro em alterar status do faturamento";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Excepton $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 24/08/2022
	function uploadSing()
	{
		try {
			if (!isset($this->parametros[0]) || empty($this->parametros)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro parâmetros";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$id_contrato = $this->parametros[0];
			}

			$get_documento = json_decode($this->modelo->gedDocumentoAnexoIf($id_contrato, "minuta"));
			if (!isset($get_documento)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro em obter ged documento";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$documento = $get_documento[0];
			}

			$proposta = json_decode($this->modelo->getContratoProposta($id_contrato));
			if (!isset($proposta)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro em obter as informações da proposta";
				throw new Exception(json_encode($retorno), 1);
			}

			$if_contato = json_decode($this->modelo->getIfContato($id_contrato, "minuta"));
			$add_sing = json_decode($this->addSing($id_contrato, $proposta[0]->id_cm));
			$retorno_sing = $this->obj_sign->upload($documento);
			if (isset($retorno_sing) && $retorno_sing->codigo === 0) {
				$insert['id_ged_anexo'] = $get_documento[0]->id_ged_anexo;
				$insert['document_key'] = $retorno_sing->output->uuid;
				$insert['data_upload'] = $this->data_hora_atual->format('Y-m-d H:i:s');
				$insert['plataforma'] = "d4sign";
				$this->modelo->setTable('ged_clicksign_documento');
				$save_sign = $this->modelo->save($insert);
				if ($save_sign) {
					$retorno_anexo = json_decode($this->anexarDocumentosUpload($id_contrato, $get_documento[0]->id_ged_anexo));
					if (isset($retorno_anexo) && $retorno_anexo->codigo == 0) {
						$add_sing = json_decode($this->addSing($id_contrato));
						if (isset($add_sing) && $add_sing->codigo == 0) {
							$doc_webhook = json_decode($this->cadastrarWebhook($id_contrato));
							if (isset($doc_webhook) && $doc_webhook->codigo == 0) {
								$retorno['codigo'] = 0;
								$retorno['input'] = $this->parametros;
								$retorno['output'] = null;
								$retorno['mensagem'] = "Sucesso";
								throw new Exception(json_encode($retorno), 1);
							} else {
								throw new Exception(json_encode($doc_webhook), 1);
							}
						} else {
							throw new Exception(json_encode($add_sing), 1);
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $retorno_anexo->input;
						$retorno['output'] = $retorno_anexo->output;
						$retorno['mensagem'] = $retorno_anexo->mensagem;
						throw new Exception(json_encode($retorno), 1);
					}
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro ao salvar no GED";
					throw new Exception(json_encode($retorno), 1);
				}
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $retorno_sing->input;
				$retorno['output'] = $retorno_sing->output;
				$retorno['mensagem'] = $retorno_sing->mensagem;
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function anexarDocumentosUpload($id_objeto = null, $id_origem = null)
	{
		try {
			$if_contrato = json_decode($this->modelo->getIfContrato($id_objeto));
			if (isset($if_contrato) && !empty($if_contrato)) {
				$proposta = json_decode($this->modelo->getPropostas($if_contrato[0]->id_proposta));
				if (isset($proposta) && !empty($proposta)) {
					if ($proposta[0]->codigo == "RCK0001") {
						$doc = json_decode($this->modelo->gedDocumentoAnexo2($id_objeto));
						if (isset($doc) && !empty($doc)) {
							foreach ($doc as $key => $value) {
								/*
								if($value->doc_origem == "customizacao"){
									$doc_customizacao = $value;
								}
								*/
							}
						}
					}
					$doc_proposta = json_decode($this->modelo->gedDocumentoAnexo2($if_contrato[0]->id_proposta, "proposta"));
					if (isset($doc_proposta) && !empty($doc_proposta)) {
						$doc_proposta = $doc_proposta[0];
					}
					$path_politica = PATH_POLITICA_CM;
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $id_objeto;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro ao obter proposta";
					throw new Exception(json_encode($retorno), 1);
				}
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $id_objeto;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao obter contrato";
				throw new Exception(json_encode($retorno), 1);
			}

			$documento_click = json_decode($this->modelo->gedClicksign($id_origem));
			if (!isset($documento_click) || empty($documento_click)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $id_objeto;
				$retorno['output'] = $id_origem;
				$retorno['mensagem'] = "Erro ao obter key documento";
				throw new Exception(json_encode($retorno), 1);
			}

			/*if(isset($doc_customizacao) && !empty($doc_customizacao)){
				$retorno_sing = $this->obj_sign->anexarDocumento($doc_customizacao,$documento_click[0]->document_key);
				if(isset($retorno_sing) && $retorno_sing['codigo'] == 1){
					throw new Exception (json_encode($retorno_sing), 1);
				}
			}*/

			if (isset($doc_proposta) && !empty($doc_proposta)) {
				$retorno_sing = $this->obj_sign->anexarDocumento($doc_proposta, $documento_click[0]->document_key, null, "proposta");

				if (isset($retorno_sing) && $retorno_sing['codigo'] == 1) {
					throw new Exception(json_encode($retorno_sing), 1);
				}
			}

			/*
			if(isset($path_politica) && !empty($path_politica)){
				$retorno_sing =$this->obj_sign->anexarDocumento(null,$documento_click[0]->document_key,$path_politica);
				if(isset($retorno_sing) && $retorno_sing['codigo'] == 1){
					throw new Exception (json_encode($retorno_sing), 1);
				}
			}*/

			$retorno['codigo'] = 0;
			$retorno['input'] = $id_objeto;
			$retorno['output'] = $id_origem;
			$retorno['mensagem'] = "Sucesso";
			throw new Exception(json_encode($retorno), 1);
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	//By: Caio Freitas - 25/08/2022
	function addSing($id_doc = null, $id_empresa = null)
	{
		try {
			$documento = json_decode($this->modelo->gedClicksign(null, $id_doc));
			if (!isset($documento) || empty($documento)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro documento key";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$documento_key = $documento[0];
			}

			$ordem_assinatura = $this->obj_assinatura->ordemAssinatura($id_doc, $id_empresa);
			if (!isset($ordem_assinatura) || empty($ordem_assinatura)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro em obter contato do assinante";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$contador = 1;
				$this->modelo->setTable("ged_clicksign_assinatura");
				$data_prazo = $this->data_hora_atual->modify('+90 days');
				foreach ($ordem_assinatura as $key => $value) {
					$insert['email_assinatura'] = trim($value->email);
					if (strtoupper($value->tipo_contato) == "TESTEMUNHA" || strtoupper($value->tipo_contato) == "TESTEMUNHA_2") {
						$insert['metodo_assinatura'] = "email";
						$insert['tipo_assinatura'] = 5;
						$insert['ordem_assinatura'] = 1;
						$insert['enviar_assinatura'] = "sim";
					} else if (strtoupper($value->tipo_contato) == "JURIDICO" && strtoupper($value->origem) == "SIGN_CM") {
						$insert['metodo_assinatura'] = "email";
						$insert['tipo_assinatura'] = 5;
						$insert['ordem_assinatura'] = 1;
						$insert['enviar_assinatura'] = "sim";
					} else if (strtoupper($value->tipo_contato) == "JURIDICO" && (!isset($value->origem) || $value->origem == "minuta")) {
						$insert['metodo_assinatura'] = "email";
						$insert['tipo_assinatura'] = 2;
						$insert['ordem_assinatura'] = 1;
						$insert['enviar_assinatura'] = "sim";
					} else if (strtoupper($value->tipo_contato) == "RESPONSAVEL LEGAL" && strtoupper($value->origem) == "SIGN_CM") {
						$insert['metodo_assinatura'] = "icp_brasil";
						$insert['tipo_assinatura'] = 1;
						$insert['ordem_assinatura'] = 1;
						$insert['enviar_assinatura'] = "sim";
					} else {
						$insert['metodo_assinatura'] = "email";
						$insert['tipo_assinatura'] = 1;
						$insert['ordem_assinatura'] = 1;
						$insert['enviar_assinatura'] = "sim";
					}

					$set_param = $this->obj_sign->setParam($insert);
					if ($set_param === false) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = null;
						$retorno['mensagem'] = "Erro ao setar parâmetros";
						throw new Exception(json_encode($retorno), 1);
					}

					$add_sing = $this->obj_sign->addSignatario($documento_key->document_key);
					if (!$add_sing) {
						$retorno['codigo'] = 1;
						$retorno['input'] = $this->parametros;
						$retorno['output'] = $add_sing;
						$retorno['mensagem'] = "Erro API";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$insert_ged['id_ged_anexo'] = $documento[0]->id_ged_anexo;
						$insert_ged['id_usuario'] = $value->id;
						$insert_ged['plataforma'] = "d4sign";
						$insert_ged['key_usuario'] = $add_sing->output->message[0]->key_signer;
						$insert_ged['key_documento'] = $documento[0]->document_key;
						$insert_ged['assinar_como'] = "email";
						$insert_ged['metodo_assinatura'] = "email";
						$insert_ged['ordem_assinatura'] = $contador;
						$insert_ged['status'] = 'pendente';
						$insert_ged['prazo_assinatura'] = $data_prazo->format("Y-m-d");
						$insert_ged['request_signature_key'] = 0;

						$save_assinatura = $this->modelo->save($insert_ged);
						if (!$save_assinatura) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro ao salvar informação no BD ged_clicksign_assinatura";
							throw new Exception(json_encode($retorno), 1);
						}
						$contador++;
					}
				}

				$dados['skip_email'] = 0;
				$dados['workflow'] = 1;
				$dados['message'] = "Segue documento para assinatura.";
				$enviar_ass = $this->obj_sign->enviarParaAssinatura($documento_key, $dados);
				if (isset($enviar_ass) && !empty($enviar_ass)) {
					$retorno['codigo'] = 0;
					$retorno['input'] = $dados;
					$retorno['output'] = $enviar_ass;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro em enviar para assinatura";
					throw new Exception(json_encode($retorno), 1);
				}
				return true;
			}
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	//By Caio Freitas Feat. Julio Gomes - 23/12/2022
	function atualizaStatusAssinatura($retorno_list, $all_minuta, $proposta)
	{
		try {
			if (isset($retorno_list) && !empty($retorno_list) && isset($retorno_list->output[0]->list) && is_array($retorno_list->output[0]->list)) {
				$this->modelo->setTable('ged_clicksign_assinatura');
				foreach ($retorno_list->output[0]->list as $key => $value_list) {
					if ($value_list->signed == 1) {
						$insert['status'] = "assinado";
						$ged_assinatura = json_decode($this->modelo->gedUserClicksignAssinatura("d4sign", $value_list->key_signer));
						if (!isset($ged_assinatura) || empty($ged_assinatura)) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $this->parametros;
							$retorno['output'] = null;
							$retorno['mensagem'] = "Erro ao obter informações para atualizar assinatura do signário";
							throw new Exception(json_encode($retorno), 1);
						} else {
							if ($ged_assinatura[0]->status != "assinado") {
								$save_ass = $this->modelo->save($insert, $ged_assinatura[0]->id);
								if (!$save_ass) {
									$retorno['codigo'] = 1;
									$retorno['input'] = $this->parametros;
									$retorno['output'] = $this->modelo->info;
									$retorno['mensagem'] = "Erro ao atualizar status da assinatura do signatário";
									throw new Exception(json_encode($retorno), 1);
								} else {
									$parametros["nome_ass"] = $ged_assinatura[0]->nome;
									$parametros["tipo_contato"] = $ged_assinatura[0]->tipo_contato;
									$parametros["id"] = $all_minuta[0]->id_proposta;
									$parametros["user_comercial"] = $proposta[0]->email_usuario;
									$this->obj_notificacao->alertaTeams('assinatura', $parametros);
								}
							}
						}
					}
				}
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 13/09/2022 - Update - 29/05/2023
	function addComissao()
	{
		try {
			if (isset($this->parametros[0]) && !empty($this->parametros[0])) {
				$insert['id_objeto'] = $this->parametros[0];
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro parâmetros id";
				throw new Exception(json_encode($retorno), 1);
			}

			if (isset($this->parametros[1]) && !empty($this->parametros[1])) {
				$insert['perfil'] = $this->parametros[1];
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro parâmetros ação";
				throw new Exception(json_encode($retorno), 1);
			}

			if (!isset($_POST["perfil"]) || empty($_POST["perfil"])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Informer o " . strtoupper(str_replace("_", " ", $insert['perfil']));
				throw new Exception(json_encode($retorno), 1);
			} else {
				$insert['id_usuario'] = $_POST["perfil"];
			}

			if (!isset($_POST["validade"]) || empty($_POST["validade"])) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $_POST;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Informer a validade da comissão do Owner";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$insert['meses_validade'] = $_POST['validade'];
			}

			$retorno_save = $this->obj_faturamento->addComissao($insert);
			if (isset($retorno_save) && $retorno_save['codigo'] == 0) {
				throw new Exception(json_encode($retorno_save), 1);
			} else {
				throw new Exception(json_encode($retorno_save), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 13/09/2022
	function getUserComissao()
	{
		try {
			if (isset($this->parametros[0]) && !empty($this->parametros[0])) {
				$id_contrato = $this->parametros[0];
				$minuta = json_decode($this->modelo->getIfContrato($id_contrato));
			} else {
				$retorno['codigo'] = 0;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro procesamento dos dados";
				throw new Exception(json_encode($retorno), 1);
			}

			if (isset($this->parametros[1]) && !empty($this->parametros[1])) {
				$modelo = $this->parametros[1];
			}

			if (!isset($modelo) || $modelo != "visualizar") {
				$class_aprovacao = json_decode($this->aprovacao->statusAprovacao('minuta', $id_contrato, "aprovar"));
				if (isset($class_aprovacao) && $class_aprovacao->codigo == 1) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = null;
					$retorno['mensagem'] = $class_aprovacao->mensagem;
					throw new Exception(json_encode($retorno), 1);
				}
			}

			/*
			echo '<pre>';
			var_dump($id_contrato);
			echo '</pre>';
			*/
			$retorno_obj = $this->obj_faturamento->getUserComissao($id_contrato, 'minuta');
			if (isset($retorno_obj) && $retorno_obj['codigo'] == 0) {
				throw new Exception(json_encode($retorno_obj), 1);
			} else {
				throw new Exception(json_encode($retorno_obj), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 14/09/2022
	function deletarUserComissao()
	{
		try {
			if (isset($this->parametros[0]) && !empty($this->parametros[0])) {
				$id_comissao = $this->parametros[0];
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro id parâmetros";
				throw new Exception(json_encode($retorno), 1);
			}

			$retorno_obj = $this->obj_faturamento->deletarUserComissao($id_comissao);
			if (isset($retorno_obj) && $retorno_obj['codigo'] == 0) {
				throw new Exception(json_encode($retorno_obj), 1);
			} else {
				throw new Exception(json_encode($retorno_obj), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 16/09/2022
	function removeHtmlComissao()
	{
		try {
			if (isset($this->parametros[0]) && !empty($this->parametros[0])) {
				$id_objeto = $this->parametros[0];
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro id parâmetros";
				throw new Exception(json_encode($retorno), 1);
			}

			$retorno_obj = $this->obj_faturamento->removeHtmlComissao($id_objeto);
			if (isset($retorno_obj) && $retorno_obj['codigo'] == 0) {
				throw new Exception(json_encode($retorno_obj), 1);
			} else {
				throw new Exception(json_encode($retorno_obj), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	function gerarDadosNota($param = null, $empresa = null, $proposta = null, $id_contrato = null, $parcelas = null)
	{
		$param_nf["cliente"] = $param["codigo_cliente"];
		$param_nf['produto'][0]['codigo'] = $proposta[0]->codigo;
		$param_nf['produto'][0]['id'] = $proposta[0]->id_produto;
		$param_nf['produto'][0]['nome'] = $proposta[0]->nome_produto;
		$param_nf['empresa_cm'] = $empresa[0]->id;
		$param_nf['conta_bancaria'] = json_decode($this->modelo->getContaBancaria($empresa[0]->id));
		$param_nf['meio_pagamento'] = $param['meio_pagamento'];
		if (isset($proposta[0]->parcelas)) {
			if ($proposta[0]->parcelas == "3") {
				$implantacao = $proposta[0]->implantacao / 3;
			} else if ($proposta[0]->parcelas == "2") {
				$implantacao = $proposta[0]->implantacao / 2;
			} else {
				$implantacao = $proposta[0]->implantacao;
			}
			$dados->numero_parcelas = $proposta[0]->parcelas;
		} else {
			$implantacao = $proposta[0]->implantacao;
		}

		$param_nf['valor'][] = funcValor($implantacao, "C", 2);
		$param_nf['modulo'][0]['nome'] = 'implantacao';
		$param_nf['quantidade'][] = 1;
		$param_nf['tipo_lancamento'][] = "A";
		$param_nf['id_contrato'] = $id_contrato;

		$dados->receita->detalhe = $this->obj_faturamento_nota_fiscal->gerarNfManual($param_nf);

		$dados->receita->resumo->total_desconto = $dados->receita->detalhe->modulo[0]->valor_desconto;
		$dados->receita->resumo->total_liquido = str_replace(".", "", funcValor($dados->receita->detalhe->impostos[0]->totalizadores->valor_base, 'C', 2));
		$dados->receita->resumo->total_imposto = $dados->receita->detalhe->valor_impostos;
		$dados->receita->resumo->codigo_modulo = null;
		$dados->receita->resumo->transacoes = 1;
		$dados->receita->resumo->nome_modulo = "Implantação";
		$dados->receita->detalhe->faturamento = $dados->receita->resumo;

		$dados->contrato->cnpj_cm = $empresa[0]->cnpj;
		$dados->contrato->codigo_produto = $proposta[0]->codigo;
		$dados->contrato->meio_pagamento = $param['meio_pagamento'];
		$dados->contrato->meio_pagamento = $param['meio_pagamento'];

		$data_faturamento = getDataAtual();
		if (isset($parcelas) && !empty($parcelas)) {
			$dados->data_faturamento = $data_faturamento->format('Y-m-d');
			$dados->hora_emissao = $this->data_hora_atual->format('H:i:s');
			if ($parcelas == "1") {
				$dados->data_emissao = $data_faturamento->format('Y-m-d');
				$dados->data_vencimento = $data_faturamento->modify('+10 day');
				$dados->data_vencimento = $dados->data_vencimento->format('Y-m-d');
			} else if ($parcelas == "2") {
				$dados->data_emissao = $data_faturamento->modify('+10 day');
				$dados->data_emissao = $data_faturamento->format('Y-m-d');
				$dados->data_vencimento = $data_faturamento->modify('+30 day');
				$dados->data_vencimento = $data_faturamento->format('Y-m-d');
			} else {
				$dados->data_emissao = $data_faturamento->modify('+40 day');
				$dados->data_emissao = $data_faturamento->format('Y-m-d');
				$dados->data_vencimento = $data_faturamento->modify('+30 day');
				$dados->data_vencimento = $data_faturamento->format('Y-m-d');
			}
		} else {
			$dados->data_emissao = $data_faturamento->format('Y-m-d');
			$dados->data_faturamento = $this->data_hora_atual->format('Y-m-d');
			$dados->data_vencimento = $data_faturamento->modify('+10 day');
			$dados->data_vencimento = $data_faturamento->format('Y-m-d');
			$dados->hora_emissao = $this->data_hora_atual->format('H:i:s');
		}

		$dados->contrato->razao_social_cm = $empresa[0]->razao_social;
		$dados->contrato->cnpj_cm = $empresa[0]->cnpj;
		$dados->contrato->inscricao_estadual_cm = $empresa[0]->inscricao_estadual;
		$dados->contrato->inscricao_municipal_cm = $empresa[0]->inscricao_municipal;
		$dados->contrato->endereco_cm = $empresa[0]->endereco;
		$dados->contrato->numero_cm = $empresa[0]->numero;
		$dados->contrato->complemento_cm = $empresa[0]->complemento;
		$dados->contrato->cep_cm = $empresa[0]->cep;
		$dados->contrato->bairro_cm = $empresa[0]->bairro;
		$dados->contrato->cidade_cm = $empresa[0]->cidade;
		$dados->contrato->estado_cm = $empresa[0]->estado;
		$dados->contrato->id_empresa = $empresa[0]->id;
		$dados->contrato->id_contrato = $id_contrato;
		$dados->contrato->razao_social = $param['razao_social'];
		$dados->contrato->cnpj = $param['cnpj'];
		$dados->contrato->codigo_cliente = $param['codigo_cliente'];
		$dados->contrato->inscricao_estadual = $param['inscricao_estadual'];
		$dados->contrato->endereco = $param['endereco'];
		$dados->contrato->numero = $param['numero'];
		$dados->contrato->complemento = $param['complemento'];
		$dados->contrato->cep = $param['cep'];
		$dados->contrato->bairro = $param['bairro'];
		$dados->contrato->cidade = $param['cidade'] .
			$dados->contrato->estado = $param['estado'];
		$dados->contrato->tipo_indice = $param['indice_reajuste'];
		$dados->contrato->codigo_produto = $proposta[0]->codigo;
		$dados->contrato->nome_produto = $proposta[0]->nome_produto;
		$dados->contrato->email_nf = $param['email_nf'];
		$dados->receita->impostos = $dados->receita->detalhe->impostos[0];
		$dados->tipo = "I";
		if (isset($parcelas) && !empty($parcelas)) {
			$dados->parcelas = $parcelas;
		} else {
			$dados->parcelas = 1;
		}
		$dados->status_envio = "pendente";
		return $dados;
	}

	function fileDownload($dados = null, $cpf = null)
	{
		$url = $dados_doc->dados->document->downloads->signed_file_url;
		$file_name = $dados['file'];
		$fp = fopen($file_name, 'wb');

		$curl_options[CURLOPT_URL] = $url;
		$curl_options[CURLOPT_CUSTOMREQUEST] = 'GET';
		$curl_options[CURLOPT_POSTFIELDS] = 'FALSE';
		$curl_options[CURLOPT_FILE] = $fp;
		$curl_options[CURLOPT_HEADER] = '0';

		$upload = CurlExec($url, null, $curl_options);
		fclose($fp);
		if ($upload) {
			if (!file_exists(ABSPATH . DS . GED_PONTO . $cpf . DS)) {
				mkdir(ABSPATH . DS . GED_PONTO . $cpf);
			}
			rename($file_name, ABSPATH . DS . GED_PONTO . $cpf . DS . $file_name);
			if (file_exists(ABSPATH . DS . GED_PONTO . $cpf . DS . $file_name)) {
				$retorno['status'] = 'ok';
				$retorno['output'] = null;
				$retorno['mensagem'] = null;
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['status'] = 'error';
				$retorno['output'] = null;
				$retorno['mensagem'] = 'Erro ao fazer upload do arquivo';
				throw new Exception(json_encode($retorno), 1);
			}
		}
	}

	function getDicionario()
	{
		try {
			if (isset($this->parametros[0]) && !empty($this->parametros[0])) {
				$produto = $this->parametros[0];
				if ($produto == "TESTEMUNHAS") {
					$dicionario = $this->dicionario['REPRESENTANTE'];
				} else if ($produto == "SPB") {
					$dicionario = $this->dicionario['VALORES']['SPB/X OBE'];
				} else {
					$dicionario = $this->dicionario['VALORES'][$produto];
				}
			}
			if (isset($dicionario) && !empty($dicionario)) {

				foreach ($dicionario as $key => $value) {
					$html .= "<tr class='tag_produto' style='text-align:center'>";
					$html .= "<td>" . $key . "</td>";
					$html .= "<td>" . $value . "</td>";
					$html .= "</tr>";
				}

				if (isset($html) && !empty($html)) {
					$retorno['codigo'] = 0;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = $html;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno), 1);
				}
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro produtos";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 22/11/2022
	function gerarContrato($all_minuta)
	{
		try {
			$data_faturamento = getDataAtual();
			$data_faturamento = $data_faturamento->modify("+10 day");

			if (!isset($all_minuta) || empty($all_minuta)) {
				$retorno["codigo"] = 1;
				$retorno["input"] = null;
				$retorno["output"] = null;
				$retorno["mensagem"] = "All minuta não informado";
				throw new Exception(json_encode($retorno), 1);
			}

			$numero_contrato = substr($all_minuta[0]->codigo, 0, 3) . $this->data_hora_atual->format('YmdHis');
			$param['numero_contrato'] = $numero_contrato;
			$param['status'] = "ativo";
			$param['razao_social'] = $all_minuta[0]->razao_social;
			$param['nome_fantasia'] = $all_minuta[0]->nome_fantasia;
			$param['cnpj'] = $all_minuta[0]->cnpj;
			$param['cnpj_fantasia'] = $all_minuta[0]->cnpj;
			$param['segmento'] = $all_minuta[0]->segmento;
			$param['endereco'] = $all_minuta[0]->endereco;
			$param['numero'] = $all_minuta[0]->numero;
			if (isset($all_minuta[0]->complemento)) {
				$param['complemento'] = $all_minuta[0]->complemento;
			}
			$param['cep'] = $all_minuta[0]->cep;
			$param['bairro'] = $all_minuta[0]->bairro;
			$param['cidade'] = $all_minuta[0]->cidade;
			$param['estado'] = $all_minuta[0]->estado;
			if (isset($all_minuta[0]->site)) {
				$param['url'] = $all_minuta[0]->site;
			}
			$param['data_assinatura'] = $this->data_hora_atual->format('Y-m-d');
			$param['data_reajuste'] = $all_minuta[0]->data_reajuste;
			$param['duracao_contrato'] = str_replace("meses", "", $all_minuta[0]->duracao_contrato);
			$param['indice_reajuste'] = $all_minuta[0]->reajuste;
			$param['moeda'] = $all_minuta[0]->moeda;
			$param['tipo_tarifacao'] = "degrau";
			$param['renovacao_automatica'] = $all_minuta[0]->renovacao_automatica;
			$param['preco_com_imposto'] = $all_minuta[0]->preco_imposto;

			$param['data_corte_faturamento'] = $all_minuta[0]->faturamento_todo_dia + 1;
			if (isset($all_minuta[0]->tipo_data_faturamento)) {
				if ($all_minuta[0]->tipo_data_faturamento == "vencimento_todo_dia") {
					$param['vencimento_todo_dia'] = $all_minuta[0]->vencimento_todo_dia;
					$param['numero_dias_apos_corte'] = 0;
				} else {
					$param['numero_dias_apos_corte'] = $all_minuta[0]->dias_apos_faturamento;
				}
			}

			$param['multa'] = $all_minuta[0]->percentual_multa;
			$param['juros'] = $all_minuta[0]->percentual_juros;
			if (isset($all_minuta[0]->hospedagem)) {
				$param['hospedagem_mensal'] = $all_minuta[0]->hospedagem;
			}


			$param['id_produto'] = $all_minuta[0]->id_produto;
			$param['data_primeiro_faturamento'] = null;
			$param['primeira_parcela_em'] = $data_faturamento->format("Y-m-d");
			$param['valor_implantacao'] = $all_minuta[0]->implantacao;
			$param['parcelado_em'] = $all_minuta[0]->parcelas;
			$param['codigo_cliente'] = $all_minuta[0]->codigo_cliente;
			$param['obs_contrato'] = $all_minuta[0]->obs_contrato;
			$param['meio_pagamento'] = "ted";
			$param['alerta_inatividade'] = 0;
			$param['vinculado_producao'] = $all_minuta[0]->vinculado_producao;
			$param['contrato_indeterminado'] = '0';
			$param['upselling'] = '0';
			$param['enviar_email_cobranca'] = '1';
			$param['nf_automatica'] = '1';
			$param['id_meio_pagamento'] = '1';

			$contador_email = 0;
			foreach ($all_minuta as $key => $value_minuta) {
				if ($value_minuta->tipo_contato == "responsavel_legal") {
					$param['nome_representante'] = $value_minuta->nome;
					$param['cpf_representante'] = $value_minuta->cpf;
					$param['email_representante'] = $value_minuta->email;
					$param['telefone_representante'] = $value_minuta->telefone;
				} else if ($value_minuta->tipo_contato == "financeiro") {
					if ($contador_email < 2) {
						if ($contador_email == 0) {
							$email_nf = $value_minuta->email;
						} else {
							$email_nf .= "|" . $value_minuta->email;
						}
						$param['contato'] = $value_minuta->nome;
						$param['email_contato'] = $value_minuta->email;
						$param['contato_tecnico'] = $value_minuta->nome;
						$param['email_contato_tecnico'] = $value_minuta->email;
						$contador_email++;
					}
				}
			}

			if (isset($email_nf) && !empty($email_nf)) {
				$email_nf .= "|nfcmsw@cmsw.com";
				$param['email_nf'] = $email_nf;
			} else {
				$retorno["codigo"] = 1;
				$retorno["input"] = null;
				$retorno["output"] = $this->modelo->info;
				$retorno["mensagem"] = "Erro e-mail nota fiscal";
				throw new Exception(json_encode($retorno), 1);
			}

			$empresa = json_decode($this->modelo->empresaVendedora(null, true));
			if (isset($empresa) && !empty($empresa)) {
				$param['id_empresa'] = $empresa[0]->id;
				$this->modelo->setTable("contratos");
				$save = $this->modelo->save($param);
				if ($save) {
					$retorno_lp = json_decode($this->insertLpContrato($all_minuta[0]->id, $save));
					if ($retorno_lp->codigo != 0) {
						$retorno["codigo"] = 1;
						$retorno["input"] = $retorno_lp->input;
						$retorno["output"] = $retorno_lp->output;
						$retorno["mensagem"] = $retorno_lp->mensagem;
						throw new Exception(json_encode($retorno), 1);
					} else {
						$retorno["codigo"] = 0;
						$retorno["input"]["empresa"] = $empresa;
						$retorno["input"]["param"] = $param;
						$retorno["output"] = $save;
						$retorno["mensagem"] = "Sucesso";
						throw new Exception(json_encode($retorno), 1);
					}
				} else {
					$retorno["codigo"] = 1;
					$retorno["input"] = null;
					$retorno["output"] = $this->modelo->info;
					$retorno["mensagem"] = "Erro em salvar no BD (gerar contrato, (rotina))";
					throw new Exception(json_encode($retorno), 1);
				}
			} else {
				$retorno["codigo"] = 1;
				$retorno["input"] = null;
				$retorno["output"] = null;
				$retorno["mensagem"] = "Empresa CM&SOFTWARE não encontrada";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	//By Caio Freitas - 22/11/2022
	function gerarNotaFiscal($id_contrato, $all_minuta, $param, $empresa)
	{
		try {
			if (!isset($id_contrato) || empty($id_contrato)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $id_contrato;
				$retorno['output'] = null;
				$retorno['mensagem'] = "ID CONTRATO NULL";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$param_if['id_contrato'] = $id_contrato;
				$contrato = json_decode($this->modelo->getContratos(null, $id_contrato));
				if (!isset($contrato) || empty($contrato)) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $id_contrato;
					$retorno['output'] = null;
					$retorno['mensagem'] = "Erro em obter contrato (rotina)";
					throw new Exception(json_encode($retorno), 1);
				}
			}

			if (!isset($all_minuta) || empty($all_minuta)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $dados;
				$retorno['output'] = $rp;
				$retorno['mensagem'] = "Erro ALL MINUTA";
				throw new Exception(json_encode($retorno), 1);
			}

			if (!isset($param) || empty($param)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $dados;
				$retorno['output'] = $rp;
				$retorno['mensagem'] = "Paramêtros não informado";
				throw new Exception(json_encode($retorno), 1);
			}

			if (!isset($empresa) || empty($empresa)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $dados;
				$retorno['output'] = $rp;
				$retorno['mensagem'] = "Empresa não informada";
				throw new Exception(json_encode($retorno), 1);
			}


			if (isset($all_minuta[0]->parcelas)) {
				$contador = $all_minuta[0]->parcelas;
			} else {
				$contador = 1;
			}

			for ($parcelas = 1; $parcelas <= $contador; $parcelas++) {
				$dados = $this->gerarDadosNota($param, $empresa, $all_minuta, $id_contrato, $parcelas);
				if (isset($dados->receita->impostos->totalizadores->naoincidente->Federal1)) {
					$dados->receita->resumo->total_imposto_f1 = $dados->receita->impostos->totalizadores->naoincidente->Federal1;
				}

				if (isset($dados->receita->impostos->totalizadores->naoincidente->Municipal1)) {
					$dados->receita->resumo->total_imposto_m1 = $dados->receita->impostos->totalizadores->naoincidente->Municipal1;
				}

				$nf[]->id_nf = $this->obj_faturamento_nota_fiscal->gerarnf($dados);
				if (isset($nf) && $parcelas == 1) {
					$rp = json_decode($this->obj_faturamento_nota_fiscal->gerarRps($nf, true));
					if (isset($rp) && !empty($rp)) {
						$this->modelo->setTable("if_contrato");
						foreach ($rp as $key => $value_rp) {
							if ($value_rp->status != "success") {
								$retorno['codigo'] = 1;
								$retorno['input'] = $dados;
								$retorno['output'] = $rp;
								$retorno['mensagem'] = "Erro em gerar nota";
								throw new Exception(json_encode($retorno), 1);
							} else {
								$save_if = $this->modelo->save($param_if, $all_minuta[0]->id);
								if (!$save_if) {
									$retorno['codigo'] = 1;
									$retorno['input'] = $proposta;
									$retorno['output'] = $save_if;
									$retorno['mensagem'] = "Erro em atualizar if_contrato";
									throw new Exception(json_encode($retorno), 1);
								}
							}
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $dados;
						$retorno['output'] = $rp;
						$retorno['mensagem'] = "Erro em gerar RPS";
						throw new Exception(json_encode($retorno), 1);
					}
				}
			}
			$retorno['codigo'] = 0;
			$retorno['input'] = $nf[0]->id_nf;
			$retorno['output'] = $save_if;
			$retorno['mensagem'] = "Sucesso";
			throw new Exception(json_encode($retorno), 1);
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	function dispararRotina($id_contrato = null)
	{
		try {
			$id_contrato = $this->parametros[0];
			$retorno["codigo"] = 0;
			$retorno["input"] = $id_contrato;
			$retorno["output"] = null;
			$retorno["mensagem"] = "Sucesso";
			throw new Exception(json_encode($retorno), 1);
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 28/11/2022
	function statusMinuta($records)
	{
		if (isset($records) && is_array($records)) {
			foreach ($records as $key => $value) {
				$Aprovacao = new Aprovacao($this, $value->codigo, $value->id);

				//apagar
				// $value->status = 'fechada';
				if ($value->status === "fechada") {
					if (isset($value->finalizado_minuta) && $value->finalizado_minuta == 1) {
						$ordem_aprovacao[$value->id] = $Aprovacao->ordemFluxoAprovacao(null, $value->id);
						if (isset($ordem_aprovacao[$value->id]) && $ordem_aprovacao[$value->id] == 2) {
							$ged_clicksign[$value->id] = json_decode($this->modelo->gedClicksign(null, $value->id_contrato, null, "minuta"));
							if (isset($ged_clicksign[$value->id]) && !empty($ged_clicksign[$value->id])) {
								if ($ged_clicksign[$value->id][0]->status == "finalizado") {
									$status_minuta[$value->id] = "<a style='text-align:center;font-size:10px;' class='btn btn-success btn-xs' href='/propostas/statusFaturamento/$value->id'  target='_blank'> <i class='fa fa-check-square' aria-hidden='true'> </i> <b>ASSINADO</b> </a>";
								} else {
									$status_minuta[$value->id] = "<a style='text-align:center;font-size:10px;' class='btn btn-info btn-xs' href='/propostas/statusFaturamento/$value->id'  target='_blank'>	<i class='fa fa-clock-o' aria-hidden='true'> </i> <b> ASSINATURA </b></a>";
								}
							} else {
								$status_minuta[$value->id] = "<a style=	'text-align:center;font-size:10px;'	class='btn btn-primary btn-xs' href='/propostas/statusFaturamento/$value->id'  target='_blank'> <i class='fa fa-check-square' aria-hidden='true'> </i> <b> APROVADO </b> </a>";
							}
						} else {
							$status_minuta[$value->id] = "<a style='text-align:center;font-size:10px;' class='btn btn-info btn-xs' href='/propostas/statusFaturamento/$value->id'  target='_blank'> <i class='fa fa-bars' aria-hidden='true'></i> <b> PREENCHIDA </b> </a>";
						}
					} else {
						$status_minuta[$value->id] = "<a style='text-align:center;font-size:10px;' class='btn btn-warning btn-xs' href='/propostas/statusFaturamento/$value->id' target='_blank'> <i class='fa fa-warning' aria-hidden='true'> </i>	 <b> PREENCHER </b> </a>";
					}
				} else {
					$status_minuta[$value->id] = "<a style='text-align:center;font-size:10px;' class='btn btn-danger btn-xs'>	<i class='fa fa-ban' aria-hidden='true'> </i> <b> SEM MINUTA </b> </a>";
				}
			}
		}
		return $status_minuta;
	}

	function dowloadContrato($doc_ged, $all_minuta, $id_nota, $id_owner)
	{
		try {
			if (!isset($doc_ged) || empty($doc_ged)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $doc_ged;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro doc_ged";
				throw new Exception(json_encode($retorno), 1);
			}

			if (!isset($all_minuta) || empty($all_minuta)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $all_minuta;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro all minuta";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$cnpj = $all_minuta->cnpj;
				$file_name = "contrato_" . $all_minuta->codigo . "_" . $this->data_hora_atual->format('Ymdhis') . ".pdf";
			}

			if (!isset($id_nota) || empty($id_nota)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $all_minuta;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro id nota";
				throw new Exception(json_encode($retorno), 1);
			}

			$retorno_dowload = $this->obj_sign->download($doc_ged->document_key);
			if (isset($retorno_dowload) && isset($retorno_dowload->url) && isset($retorno_dowload->name)) {
				$retorno_file = json_decode($this->obj_sign->saveFile($retorno_dowload->url, $file_name, $cnpj));
				if (isset($retorno_file) && $retorno_file->codigo == 0) {
					$retorno_save = json_decode($this->saveGed($doc_ged, $all_minuta, $id_nota, $id_owner, $cnpj, $file_name));
					throw new Exception(json_encode($retorno_save), 1);
				} else {
					//ERRO					
					throw new Exception(json_encode($retorno_file), 1);
				}
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $retorno_dowload;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro em obter informações para dowload de contrato assinado";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	//By Caio Freitas - 29/11/2022
	function saveGed($doc_ged, $all_minuta, $id_nota, $id_owner, $cnpj, $file_name)
	{
		try {
			$get_nota = json_decode($this->modelo->getNotaFiscal($id_nota));
			if (isset($get_nota) && !empty($get_nota)) {
				$ged = json_decode($this->modelo->getGed($all_minuta->id));
				$insert_ged['id_contrato'] = $all_minuta->id;
				$insert_ged['codigo_cliente'] = $all_minuta->codigo_cliente;
				$insert_ged['nome_fantasia'] = $all_minuta->razao_social;
				$insert_ged['tipo_documento'] = "contrato";
				$insert_ged['tipo_contrato'] = "licenciamento";
				$insert_ged['id_produto'] = $all_minuta->id_produto;
				$insert_ged['codigo_produto'] = $all_minuta->codigo;
				$insert_ged['data_criacao'] = $doc_ged->data_criacao;
				$insert_ged['dt_em_ass'] = $doc_ged->finalizado_em;
				$insert_ged['num_nota'] = $get_nota[0]->numero;
				$insert_ged['num_fatura'] = $get_nota[0]->numero_fatura;
				$insert_ged['path_root'] = UP_GED . DS . 'clientes' . DS . $cnpj . DS;
				$insert_ged['path_file'] = $file_name;
				$insert_ged['uuid_d4sign'] = $doc_ged->document_key;
				$insert_ged['status_d4sign'] = $doc_ged->status;
				$insert_ged['owner'] = $id_owner;
				$insert_ged['status'] = "ativo";
				$insert_ged['sistema'] = "cmswerp";

				$this->modelo->setTable('ged');
				$save_ged = $this->modelo->save($insert_ged, $ged[0]->id);
				if ($save_ged) {
					$retorno['codigo'] = 0;
					$retorno['input'] = $insert_ged;
					$retorno['output'] = $save_ged;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno), 1);
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $insert_ged;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro ao salvar GED";
					throw new Exception(json_encode($retorno), 1);
				}
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $id_nota;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro em obter nota fiscal";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	//By Caio FReitas - 06/12/2022
	function cancelarDoc()
	{
		try {
			if (isset($this->parametros[0]) && !empty($this->parametros[0])) {
				$id_contrato = $this->parametros[0];
			}
			$ged_doc = json_decode($this->modelo->gedClicksign(null, $id_contrato));
			if (!isset($ged_doc) || empty($ged_doc)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $this->parametros;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao obter ged_clicksign_documento";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$ged_assinatura = json_decode($this->modelo->gedClicksignAssinatura(null, null, $ged_doc[0]->id_ged_anexo));
				if (!isset($ged_assinatura) || empty($ged_assinatura)) {
					$retorno['codigo'] = 1;
					$retorno['input'] = $this->parametros;
					$retorno['output'] = $ged_doc;
					$retorno['mensagem'] = "Erro ao obter ged_clicksign_assinatura";
					throw new Exception(json_encode($retorno), 1);
				}
			}

			$retorno_doc = json_decode($this->obj_sign->cancelarDocumento($ged_doc[0]->document_key));
			if ($retorno_doc->codigo == 0) {
				$this->modelo->setTable('ged_clicksign_documento');
				$insert['deleted'] = 1;
				$update_ged = $this->modelo->save($insert, $ged_doc[0]->id);
				if ($update_ged) {
					$this->modelo->setTable('ged_clicksign_assinatura');
					foreach ($ged_assinatura as $key => $value) {
						$update_ass = json_decode($this->modelo->save($insert, $value->id));
						if (!$update_ass) {
							$retorno['codigo'] = 1;
							$retorno['input'] = $id_contrato;
							$retorno['output'] = $this->modelo->info;
							$retorno['mensagem'] = "Erro em atualizar ged_clicksign_assinatura";
							throw new Exception(json_encode($retorno), 1);
						}
					}
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $ged_doc;
					$retorno['output'] = $this->modelo->info;
					$retorno['mensagem'] = "Erro em atualizar ged_clicksign_documento";
					throw new Exception(json_encode($retorno), 1);
				}
				$retorno['codigo'] = 0;
				$retorno['input'] = $ged_doc;
				$retorno['output'] = $retorno_doc;
				$retorno['mensagem'] = "Sucesso, documento cancelado";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $ged_doc;
				$retorno['output'] = $retorno_doc;
				$retorno['mensagem'] = "Erro em cancelar documento";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By: Caio Freitas - 15/12/2022
	function insertLpContrato($id_contrato, $id_contratos)
	{
		try {
			$if_contrato = json_decode($this->modelo->getIfContrato($id_contrato));
			if (isset($if_contrato) && !empty($if_contrato)) {
				$lp_cliente = json_decode($this->modelo->getLpCliente($id_contratos));
				if (!isset($lp_cliente)) {
					$insert['id_contrato'] = $id_contratos;
					$lp_proposta = json_decode($this->modelo->getLpId(null, $if_contrato[0]->id_proposta));
					if (isset($lp_proposta) && !empty($lp_proposta)) {
						$this->modelo->setTable("lp_clientes");
						foreach ($lp_proposta as $key => $value) {
							$insert['tipo_cobranca'] = $value->tipo_cobranca;
							$insert['modalidade'] = $value->modalidade;
							$insert['qtd_de'] = $value->qtd_de;
							$insert['qtd_ate'] = $value->qtd_ate;
							$insert['valor_real'] = $value->valor_real;
							$insert['id_modulo'] = $value->id_modulo;
							$insert['id_produto'] = $value->id_produto;
							$insert['status'] = "ativo";
							$save = $this->modelo->save($insert);
							if (!$save) {
								$retorno['codigo'] = 1;
								$retorno['input'] = $lp_proposta;
								$retorno['output'] = $this->modelo->info;
								$retorno['mensagem'] = "Erro ao inserir lp_clientes";
								throw new Exception(json_encode($retorno), 1);
							}
						}
						$retorno_pacote = json_decode($this->insertPacoteContrato($id_contrato, $id_contratos));
						if ($retorno_pacote->codigo == 0) {
							$retorno['codigo'] = 0;
							$retorno['input'] = $if_contrato;
							$retorno['output'] = $lp_proposta;
							$retorno['mensagem'] = "Sucesso";
							throw new Exception(json_encode($retorno), 1);
						} else {
							$retorno['codigo'] = 1;
							$retorno['input'] = $retorno_pacote->input;
							$retorno['output'] = $retorno_pacote->output;
							$retorno['mensagem'] = $retorno_pacote->mensagem;
							throw new Exception(json_encode($retorno), 1);
						}
					} else {
						$retorno['codigo'] = 1;
						$retorno['input'] = $if_contrato;
						$retorno['output'] = $lp_proposta;
						$retorno['mensagem'] = "Erro ao obter lista de preço da proposta";
						throw new Exception(json_encode($retorno), 1);
					}
				} else {
					$retorno['codigo'] = 1;
					$retorno['input'] = $lp_cliente;
					$retorno['output'] = $if_contrato;
					$retorno['mensagem'] = "lista de preço já inserida";
					throw new Exception(json_encode($retorno), 1);
				}
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $id_contrato;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao obter if_contrato";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	//By: Caio Freitas - 15/12/2022
	function insertPacoteContrato($id_contrato, $id_contratos)
	{
		try {
			$if_contrato = json_decode($this->modelo->getIfContrato($id_contrato));
			if (isset($if_contrato) && !empty($if_contrato)) {
				$pacote_cliente = json_decode($this->modelo->getPacoteCliente($id_contratos));
				if (!isset($pacote_cliente)) {
					$insert['id_contrato'] = $id_contratos;
					$pacote_proposta = json_decode($this->modelo->getPacotePropostas($if_contrato[0]->id_proposta));
					if (isset($pacote_proposta) && !empty($pacote_proposta)) {
						$this->modelo->setTable("pacote_contratado");
						foreach ($pacote_proposta as $key => $value) {
							$insert['id_modulos_tarifaveis'] = $value->id_modulos_tarifaveis;
							// $insert['id_produto']	 		 = $value->id_produto;
							$insert['qdt_garantido'] = $value->quantidade_garantido;
							$insert['preco_pkt'] = $value->preco_pkt;
							$insert['frenquencia'] = $value->frequencia;
							$insert['status'] = $value->status;
							$insert['flag'] = $value->flag;
							if (isset($value->percentual) && !empty($value->percentual)) {
								$insert['percentual'] = $value->percentual;
							}

							if (isset($value->valor_excedente) && !empty($value->valor_excedente)) {
								$insert['valor_garantido'] = $value->valor_excedente;
							}

							if (isset($value->ultimo_reajuste) && !empty($value->ultimo_reajuste)) {
								$insert['ultimo_reajuste'] = $value->ultimo_reajuste;
							}

							$save = $this->modelo->save($insert);
							if (!$save) {
								$retorno['codigo'] = 1;
								$retorno['input'] = $pacote_proposta;
								$retorno['output'] = $this->modelo->info;
								$retorno['mensagem'] = "Erro ao inserir pacote_contratado";
								throw new Exception(json_encode($retorno), 1);
							}
						}

						$retorno['codigo'] = 0;
						$retorno['input'] = $pacote_proposta;
						$retorno['output'] = $save;
						$retorno['mensagem'] = "Sucesso";
						throw new Exception(json_encode($retorno), 1);
					} else {
						$retorno['codigo'] = 0;
						$retorno['input'] = $id_contrato;
						$retorno['output'] = $if_contrato;
						$retorno['mensagem'] = "Sucesso";
						throw new Exception(json_encode($retorno), 1);
					}
				} else {
					$retorno['codigo'] = 0;
					$retorno['input'] = $id_contrato;
					$retorno['output'] = $if_contrato;
					$retorno['mensagem'] = "Sucesso";
					throw new Exception(json_encode($retorno), 1);
				}
			} else {
				$retorno['codigo'] = 1;
				$retorno['input'] = $id_contrato;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao obter if_contrato";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	//By: Caio Freitas - 27/12/2022
	function rotinaWebMinuta()
	{
		try {
			$this->obj_notificacao->alertaTeams('alerta_rotina');
			$all_minuta_aprovada = json_decode($this->modelo->fluxoMinutaAprovado(2));
			$this->statusAlertaMinuta($all_minuta_aprovada);
			$this->contratoGanho($all_minuta_aprovada);
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}

	//By Caio Freitas - 27/12/2022
	function contratoGanho($minuta)
	{
		if (isset($minuta) && !empty($minuta)) {
			foreach ($minuta as $key => $value) {
				if (empty($value->id_contrato) && !empty($value->finalizado_em)) {
					$all_minuta = json_decode($this->modelo->getFullMinuta($value->id));
					$retorno_func = json_decode($this->gerarContrato($all_minuta));
					if (isset($retorno_func) && $retorno_func->codigo == 0) {
						$param_if['id_contrato'] = $retorno_func->output;
						$param = get_object_vars($retorno_func->input->param);
						$empresa = $retorno_func->input->empresa;
					} else {
						$parametros["id"] = $param_if['id_contrato'];
						$parametros["cliente"] = $all_minuta[0]->nome_fantasia;
						$this->obj_notificacao->alertaTeams('erro_contrato', $parametros);
						exit;
					}

					$retorno_nf = json_decode($this->gerarNotaFiscal($param_if['id_contrato'], $all_minuta, $param, $empresa));
					if (!isset($retorno_nf) || $retorno_nf->codigo != 0) {
						$parametros["mensagem"] = "ERRO EM GERAR NOTA FISCAL, ID CONTRATO: " . $param_if['id_contrato'] . " CLIENTE: " . $all_minuta[0]->nome_fantasia;
						$this->obj_notificacao->alertaTeams('erro_contrato', $parametros);
						exit;
					} else {
						$id_nota = $retorno_nf->input;
						$retorno_dowload = json_decode($this->dowloadContrato($value, $all_minuta[0], $id_nota, $value->id_owner));
						if (isset($retorno_dowload) && $retorno_dowload->codigo == 0) {
							$parametros["id"] = $param_if['id_contrato'];
							$parametros["cliente"] = $all_minuta[0]->nome_fantasia;
							$this->obj_notificacao->alertaTeams('contrato_ganho', $parametros);
							$this->obj_notificacao->enviarEmail('contrato_ganho', $parametros);
						} else {
							$parametros["mensagem"] = "ERRO DOWLOAD CONTRATO ASSINADO, ID CONTRATO: " . $param_if['id_contrato'] . " CLIENTE: " . $all_minuta[0]->nome_fantasia;
							$this->obj_notificacao->alertaTeams('erro_contrato', $parametros);
							exit;
						}
					}
				}
			}
		}
	}

	//By Caio Freitas - 27/12/2022	
	function statusAlertaMinuta($all_minuta)
	{
		if (isset($all_minuta) && is_array($all_minuta)) {
			foreach ($all_minuta as $key => $value) {
				if (empty($value->id_contrato) && empty($value->finalizado_em)) {
					$retorno_list = $this->obj_sign->listarSignatarios($value->document_key);
					if (isset($retorno_list) && !empty($retorno_list) && isset($retorno_list->output[0]->list)) {
						$this->newAtualizaStatusAssinatura($retorno_list, $value, $value->id_ged_anexo);
						if (strtoupper($retorno_list->output[0]->statusName) == "FINALIZADO") {
							$this->newAtualizaStatusContrato($value->id_doc, $value);
						}
					} else {
						$parametros["mensagem"] = "Erro retorno lista de signatário do documento D4sign, ID: " . $value->id . " KEY DOC: " . $value->document_key;
						$this->obj_notificacao->alertaTeams('erro_contrato', $parametros);
						exit;
					}
				}
			}
		}
	}

	function newAtualizaStatusAssinatura($retorno_list, $all_minuta, $id_ged_anexo)
	{
		if (isset($retorno_list) && is_array($retorno_list->output[0]->list)) {
			$this->modelo->setTable('ged_clicksign_assinatura');
			foreach ($retorno_list->output[0]->list as $key => $value_list) {
				if ($value_list->signed == 1) {
					$insert['status'] = "assinado";
					$ged_assinatura = json_decode($this->modelo->gedUserClicksignAssinatura("d4sign", $value_list->key_signer, $id_ged_anexo));
					if (!isset($ged_assinatura) || empty($ged_assinatura)) {
						$parametros["mensagem"] = "Erro ao obter informações para atualizar assinatura do signário, ID_GED_ANEXO: " . $id_ged_anexo;
						$this->obj_notificacao->alertaTeams('erro_contrato', $parametros);
						exit;
					} else {
						if ($ged_assinatura[0]->status != "assinado") {
							$save_ass = $this->modelo->save($insert, $ged_assinatura[0]->id);
							if (!$save_ass) {
								$parametros["mensagem"] = "Erro ao atualizar status da assinatura do signatário, ID: " . $ged_assinatura[0]->id;
								$this->obj_notificacao->alertaTeams('erro_contrato', $parametros);
								exit;
							} else {
								$parametros["nome_ass"] = $ged_assinatura[0]->nome;
								$parametros["tipo_contato"] = $ged_assinatura[0]->tipo_contato;
								$parametros["id"] = $all_minuta->id_proposta;
								$parametros["user_comercial"] = $all_minuta->email;
								$this->obj_notificacao->alertaTeams('assinatura', $parametros);
							}
						}
					}
				}
			}
		}
	}

	//By Caio Freitas - 27/12/2022	
	function newAtualizaStatusContrato($id_doc, $all_minuta)
	{
		$insert_doc['status'] = "finalizado";
		$insert_doc['finalizado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
		$this->modelo->setTable('ged_clicksign_documento');
		$save_doc = $this->modelo->save($insert_doc, $id_doc);
		if (!$save_doc) {
			$parametros["mensagem"] = "Erro ao atualizar status do documento, ID: " . $id_doc . " INFO: " . $this->modelo->info;
			$this->obj_notificacao->alertaTeams('erro_contrato', $parametros);
			exit;
		} else {
			$this->modelo->setTable('if_faturamento');
			$insert_if['data_assinatura'] = $this->data_hora_atual->format('Y-m-d');
			$data_reajuste = getDataAtual($this->data_hora_atual->format('Y-m-d'));
			$data_reajuste = $data_reajuste->modify("+12 month");
			$insert_if['data_reajuste'] = $data_reajuste->format('Y-m-d');
			$save_if = $this->modelo->save($insert_if, $all_minuta->id_faturamento);
			if (!$save_if) {
				$parametros["mensagem"] = "Erro ao atualizar data assinatura em instrução de faturamento, ID_FATURAMENTO: " . $all_minuta->id_faturamento . " INFO: " . $this->modelo->info;
				$this->obj_notificacao->alertaTeams('erro_contrato', $parametros);
				exit;
			} else {
				$parametros["id"] = $all_minuta->id_proposta;
				$parametros["user_comercial"] = $all_minuta->email;
				$parametros["cliente"] = $all_minuta->nome_fantasia;
				$this->obj_notificacao->alertaTeams('contrato_finalizado', $parametros);
			}
		}
	}

	function cadastrarWebhook($id_origem)
	{
		try {
			$key_doc = json_decode($this->modelo->gedClicksign(null, $id_origem));
			if (!isset($key_doc) || empty($key_doc)) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $webhook;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro em obter documento key";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$doc_key = $key_doc[0]->document_key;
			}

			$return = $this->obj_sign->webhook($doc_key);
			if ($return === false) {
				$retorno['codigo'] = 1;
				$retorno['input'] = $doc_key;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Erro ao cadastrar webhook";
				throw new Exception(json_encode($retorno), 1);
			} else {
				$retorno['codigo'] = 0;
				$retorno['input'] = $doc_key;
				$retorno['output'] = null;
				$retorno['mensagem'] = "Sucesso cadastrar webhook";
				throw new Exception(json_encode($retorno), 1);
			}
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	function marcarGanho()
	{
		if (isset($this->parametros[1]) && is_numeric($this->parametros[1]) && !empty($this->parametros[1])) {
			$lista_minuta = json_decode($this->modelo->propostaAssinaturaById($this->parametros[1]));
			if ($lista_minuta) {
				$minuta = json_decode($this->modelo->getFullMinuta($lista_minuta[0]->id));
				if ($minuta) {
					$contrato_model = $this->load_model('contratos/contratos', true);
					$contrato = json_decode($contrato_model->getContratosAndProdutos($minuta[0]->codigo_cliente, $minuta[0]->codigo));
					if (!$contrato) {
						$retorno_func = json_decode($this->gerarContrato($minuta));
						if (isset($retorno_func) && $retorno_func->codigo == 0) {
							$param_if['id_contrato'] = $retorno_func->output;
							$param = get_object_vars($retorno_func->input->param);
							$empresa = $retorno_func->input->empresa;
						} else {
							$parametros["id"] = $param_if['id_contrato'];
							$parametros["cliente"] = $minuta[0]->nome_fantasia;
							$this->obj_notificacao->alertaTeams('erro_contrato', $parametros);
							exit;
						}

						$retorno_nf = json_decode($this->gerarNotaFiscal($param_if['id_contrato'], $minuta, $param, $empresa));
						if (!isset($retorno_nf) || $retorno_nf->codigo != 0) {
							$parametros["mensagem"] = "ERRO EM GERAR NOTA FISCAL, ID CONTRATO: " . $param_if['id_contrato'] . " CLIENTE: " . $minuta[0]->nome_fantasia;
							$this->obj_notificacao->alertaTeams('erro_contrato', $parametros);
							exit;
						} else {
							$id_nota = $retorno_nf->input;
							$retorno_dowload = json_decode($this->dowloadContrato($value, $minuta[0], $id_nota, $value->id_owner));
							if (isset($retorno_dowload) && $retorno_dowload->codigo == 0) {
								$parametros["id"] = $param_if['id_contrato'];
								$parametros["cliente"] = $minuta[0]->nome_fantasia;
								$this->obj_notificacao->alertaTeams('contrato_ganho', $parametros);
								$this->obj_notificacao->enviarEmail('contrato_ganho', $parametros);
							} else {
								$parametros["mensagem"] = "ERRO DOWLOAD CONTRATO ASSINADO, ID CONTRATO: " . $param_if['id_contrato'] . " CLIENTE: " . $minuta[0]->nome_fantasia;
								$this->obj_notificacao->alertaTeams('erro_contrato', $parametros);
								exit;
							}
						}
					}
				}
			}
		}
	}
}
