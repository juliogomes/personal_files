<?php
class QuotasController extends MainController{
	protected $module = 'quotas';

	function __construct($parametros = null){
		$this->nome_modulo = 'quotas';
		parent::__construct($parametros);
	}

	function index(){
		$this->listar();
	}

	function listar(){
		$quotas = json_decode($this->modelo->getQuotas());
		require_once ABSPATH . '/views/'.$this->module.'/quotas-view.php';
	}

	function detalhe(){
		if(isset($this->parametros[0]) && isset($this->parametros[1])){
			if(is_numeric($this->parametros[0]) && is_numeric($this->parametros[1])){
				$quo_meses = json_decode($this->modelo->getQuotasByAnoEvendedor($this->parametros[1], $this->parametros[0]));
			}else{
				echo 'Erro, os dados de pesquisa estão incorretos';
			}
		}elseif(isset($this->parametros[0]) && !isset($this->parametros[1])){
			$quo_meses = json_decode($this->modelo->getQuotasByAnoEvendedor($this->parametros[0], null, 'quota_mensal'));
		}
		require_once ABSPATH . '/views/'.$this->module.'/quotas-edit.php';
	}

	function save(){
		
		if(isset($this->parametros[1]) && is_numeric($this->parametros[1])){
			$param['ano'] = $this->parametros[1];
		}else{
			$param['ano'] = $_POST['ano'];
		}

		if(isset($_POST['atribuido_a']) && is_numeric($_POST['atribuido_a'])){
			$param['atribuido_a'] = $_POST['atribuido_a'];
			$param['tipo']        = 'vendedor';	
		}else{
			$param['atribuido_a'] = 'todos';
			$param['tipo']        = 'quota_mensal';	
		}
		
		$param['valor'] 			 = removeCaracteres($_POST['valor'],'moeda2');
		$param['faturamento_minimo'] = removeCaracteres($_POST['faturamento_minimo'],'moeda2');
		$param['mes'] 				 = $_POST['mes'];
		$param['tipo'] 				 = $_POST['tipo'];
		$param['classe'] 			 = $_POST['classe'];

		$is_save = $this->modelo->save($param);
		if($is_save){
			$id = $is_save;
		}else{
			$id = $this->parametros[0];
		}
		header('location: /quotas/detalhe/'.$param['atribuido_a'].'/'.$param['ano']);
	}

	function delete(){
		$id = $this->parametros[1];
		if(!empty($id) && is_numeric($id)){
			$param['deleted'] = 1;
			$this->modelo->save($param, $id);
			header('Location: /quotas/detalhe/'.$this->parametros[2].'/'.$this->parametros[3]);
		}
	}
}
?>

