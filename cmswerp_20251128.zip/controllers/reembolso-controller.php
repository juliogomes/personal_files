<?php
class ReembolsoController extends MainController
{
    protected
    $valor_km = 1.35,
    $quem_aprova,
    $email_adm,
    $apiClass,
    $gedClass,
    $uploadClass,
    $dados_user,
    $obj_notificacao;
    function __construct($parametros, $nome_controller = 'reembolso', $do_login = true)
    {
        $this->setModulo('reembolso');
        $this->setView('reembolso');
        parent::__construct($parametros, $nome_controller, $do_login);
        $this->gedClass = new Ged($this);
        $this->apiClass = new Api($this);
        $this->uploadClass = new Upload($this);
        $this->obj_notificacao = new Notificacoes($this);
        $this->email_adm = ('dulcineia.mata@cmsw.com');
    }

    function quemAprova()
    {
        if ($this->userdata->nome_perfil == 'SYSTEM ADMIN') {
            return true;
        } else {
            $get_lista_rh = json_decode($this->modelo->getUsersRh());
            $lista_rh = [];
            foreach ($get_lista_rh as $key => $value) {
                $lista_rh[] = $value->id_usuario;
            }
            if (in_array($this->userdata->id, $lista_rh)) {
                return true;
            } else {
                return false;
            }
        }
    }

    function index()
    {
        $this->listar();
    }

    function listar()
    {
        $listar_reembolsos = null;
        $array = null;
        $this->cl_permissoes->verificarPermissao($this->getModulo());

        if (isset($_POST['colaborador']) && !empty($_POST['colaborador']) && is_numeric($_POST['colaborador'])) {
            $colaborador = $_POST['colaborador'];
        } else {
            $colaborador = $this->userdata->id;
        }

        if (isset($_POST['periodo_de']) && !empty($_POST['periodo_de'])) {
            $periodo_de = getDataAtual(convertDate($_POST['periodo_de']));
        } else {
            $periodo_de = clone $this->data_hora_atual;
            $periodo_de->modify('-1 month');
        }

        if (isset($_POST['periodo_ate']) && !empty($_POST['periodo_ate'])) {
            $periodo_ate = getDataAtual(convertDate($_POST['periodo_ate']));
        } else {
            $periodo_ate = clone $this->data_hora_atual;
        }

        if (isset($_POST['filtro-status']) && !empty($_POST['filtro-status'])) {
            $status = $_POST['filtro-status'];
        } else {
            $status = null;
        }

        if (isset($_POST['filtro-tipo-aprovacao']) && !empty($_POST['filtro-tipo-aprovacao'])) {
            $tipo_aprovacao = $_POST['filtro-tipo-aprovacao'];
        } else {
            $tipo_aprovacao = null;
        }

        switch ($this->cl_permissoes->alcada_acesso) {
            case '1':
                $listar_reembolsos = json_decode($this->modelo->getSolicitacaoByOwner($colaborador, $periodo_de->format('Y-m-d'), $periodo_ate->format('Y-m-d')));
                $lista_usuarios = json_decode($this->user_model->getUser($colaborador));
                break;
            case '2':
                $lista_usuarios = json_decode($this->user_model->getUserByBoss($this->userdata->id));
                if (!isset($_POST['colaborador']) || empty($_POST['colaborador'])) {
                    $listar_reembolsos = json_decode($this->modelo->getSolicitacaoByBoss($_POST['colaborador'], $periodo_de->format('Y-m-d'), $periodo_ate->format('Y-m-d')));
                } else {
                    $listar_reembolsos = json_decode($this->modelo->getSolicitacaoByOwner($colaborador, $periodo_de->format('Y-m-d'), $periodo_ate->format('Y-m-d')));
                }
                break;
            case '3':
                // $listar_reembolsos = json_decode( $this->modelo->getSolicitacao() ); // funcao ainda sem funcionar
                break;
            case '4':
                if (isset($_POST['colaborador']) && !empty($_POST['colaborador']) && is_numeric($_POST['colaborador'])) {
                    $listar_reembolsos = json_decode($this->modelo->getSolicitacaoByOwner($colaborador, $periodo_de->format('Y-m-d'), $periodo_ate->format('Y-m-d')));
                } else {
                    $colaborador = null;
                    $listar_reembolsos = json_decode($this->modelo->getSolicitacao($colaborador, $periodo_de->format('Y-m-d'), $periodo_ate->format('Y-m-d')));
                }
                $lista_usuarios = json_decode($this->user_model->getUser());
                break;
            default:
                echo 'nivel de acesso não definido';
                exit;
                break;
        }

        if ($listar_reembolsos) {
            $array = null;
            foreach ($listar_reembolsos as $key => $value) {
                $i = $value->id;
                $this->arrayDinamico($array, $i, 'id');
                $this->arrayDinamico($array, $i, 'solicitante');
                $this->arrayDinamico($array, $i, 'tipo');
                $this->arrayDinamico($array, $i, 'cliente');
                $this->arrayDinamico($array, $i, 'data_ini');
                $this->arrayDinamico($array, $i, 'data_fim');
                $this->arrayDinamico($array, $i, 'alterado_em');
                $this->arrayDinamico($array, $i, 'status');
                $this->arrayDinamico($array, $i, 'aprovado_por');
                $this->arrayDinamico($array, $i, 'valor_total');
                $this->arrayDinamico($array, $i, 'valor_receber');
                $this->arrayDinamico($array, $i, 'visivel');
                $meta_info = json_decode($value->meta_info);
                if (isset($meta_info->lista_status)) {
                    foreach ($meta_info->lista_status as $vl1) {
                        if (isset($vl1->tipo_aprovacao)) {
                            if ($vl1->tipo_aprovacao == 'diretoria' || $vl1->tipo_aprovacao == 'gestor(a)') {
                                $vl1->tipo_aprovacao = 'gestor';
                            }
                            $i1 = $vl1->tipo_aprovacao;
                            $i2 = $vl1->status;
                            $array_status[$i][$i1][$i2] = $vl1->status;
                        }
                    }
                    $array[$i]['aprovacao']['gestor'] = (isset($array_status[$i]['gestor'])) ? end($array_status[$i]['gestor']) : 'pendente';
                    $array[$i]['aprovacao']['rh'] = (isset($array_status[$i]['rh'])) ? end($array_status[$i]['rh']) : 'pendente';
                    if ($array) {
                        if (isset($array[$i]['aprovacao']['rh']) && $array[$i]['aprovacao']['rh'] == 'pago') {
                            $array[$i]['status'] = 'pago';
                            $array[$i]['aprovacao']['gestor'] = 'aprovado';
                            $array[$i]['aprovacao']['rh'] = 'aprovado';
                        } elseif (
                            isset($array[$i]['aprovacao']['gestor']) &&
                            isset($array[$i]['aprovacao']['rh']) &&
                            $array[$i]['aprovacao']['gestor'] == 'aprovado' &&
                            $array[$i]['aprovacao']['rh'] == 'aprovado'
                        ) {
                            $array[$i]['status'] = 'aprovado';
                        } else {
                            $array[$i]['status'] = 'pendente';
                        }
                    }
                }

                $array[$i]['id'] = $value->id;
                $array[$i]['solicitante'] = $value->nome_owner;
                $array[$i]['tipo'] = $value->tipo;
                $array[$i]['cliente'] = $value->cliente;
                $array[$i]['data_ini'] = $value->data_ini;
                $array[$i]['data_fim'] = $value->data_fim;
                $array[$i]['alterado_em'] = $value->alterado_em;
                $array[$i]['aprovado_por'] = $value->owner;

                if (isset($meta_info->resumo->valor_solicitado) && !empty($meta_info->resumo->valor_solicitado)) {
                    $array[$i]['valor_total'] += $meta_info->resumo->valor_solicitado;
                } else {
                    $array[$i]['valor_total'] += 0;
                }

                if (isset($meta_info->resumo->recebivel) && $meta_info->resumo->recebivel == 1) {
                    $array[$i]['valor_receber'] += $meta_info->resumo->valor_recebivel;
                } else {
                    $array[$i]['valor_receber'] += 0;
                }

                $c1 = $value->meta_classificacao;
                $array[$i]['meta_info'][$c1] = json_decode($value->meta_info);
                if ($status && $tipo_aprovacao) {
                    if ($status == 'pago' && $array[$i]['status'] === $status) {
                        $array[$i]['visivel'] = true;
                    } elseif (isset($array[$i]['aprovacao'][$tipo_aprovacao])) {
                        if ($array[$i]['aprovacao'][$tipo_aprovacao] == $status) {
                            $array[$i]['visivel'] = true;
                        }
                    }
                } elseif ($tipo_aprovacao) {
                    if (isset($array[$i]['aprovacao'][$tipo_aprovacao])) {
                        $array[$i]['visivel'] = true;
                    }
                } elseif ($status) {
                    if ($status == 'pago' && $array[$i]['status'] === $status) {
                        $array[$i]['visivel'] = true;
                    } elseif (
                        (isset($array[$i]['aprovacao']['gestor']) && $array[$i]['aprovacao']['gestor'] == $status) ||
                        (isset($array[$i]['aprovacao']['rh']) && $array[$i]['aprovacao']['rh'] == $status)
                    ) {
                        $array[$i]['visivel'] = true;
                    }
                } else {
                    $array[$i]['visivel'] = true;
                }
            }
        }
        require_once ABSPATH . '/views/' . $this->nome_view . '/index.php';
    }

    function checkStatusReembolso($id_reembolso)
    {
        if (!isset($id_reembolso) || empty($id_reembolso)) {
            return false;
        } else {
            $lista_status = json_decode($this->modelo->getMetaDadosByStatusAprovado($id_reembolso));
            if (isset($lista_status) && !empty($lista_status)) {
                foreach ($lista_status as $key => $value) {
                    $meta_info = $value->meta_info;
                }
                $meta_info = json_decode($meta_info);
                $ultimo_status = end($meta_info);
                foreach ($ultimo_status as $key => $value) {
                    $status = $value->status;
                }
                if ($status == 'aprovado') {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }
    }

    function detalhe()
    {
        $this->cl_permissoes->verificarPermissao($this->getModulo());
        if (isset($this->parametros[1]) && !empty($this->parametros[1] && is_numeric($this->parametros[1]))) {
            $dados_user = json_decode($this->modelo->getSolicitacao($this->parametros[1]));
            switch ($this->cl_permissoes->alcada_acesso) {
                case '1':
                    $reembolsos = json_decode($this->modelo->getSolicitacao($this->parametros[1]));
                    if (isset($reembolsos) && !empty($reembolsos)) {
                        if ($this->userdata->id == $dados_user[0]->id_owner) {
                            $reembolsos = json_decode($this->modelo->getSolicitacao($this->parametros[1]));
                            $despesas = json_decode($this->modelo->getMetaDadosPorReembolso($this->parametros[1]));
                        } else {
                            echo 'sem permissao de acesso';
                            exit;
                        }
                    } else {
                        echo 'Não foi possível acessar essa solicitação de reembolso!';
                        exit;
                    }
                    break;
                case '2':
                    $reembolsos = json_decode($this->modelo->getSolicitacao($this->parametros[1]));
                    if (isset($reembolsos) && !empty($reembolsos)) {
                        if ($this->userdata->id == $dados_user[0]->id_owner || $this->userdata->id == $dados_user[0]->id_boss) {
                            $reembolsos = json_decode($this->modelo->getSolicitacao($this->parametros[1]));
                            $despesas = json_decode($this->modelo->getMetaDadosPorReembolso($this->parametros[1]));
                        } else {
                            echo 'sem permissao de acesso';
                            exit;
                        }
                    } else {
                        echo 'Não foi possível acessar essa solicitação de reembolso!';
                        exit;
                    }
                    break;
                case '4':
                    $reembolsos = json_decode($this->modelo->getSolicitacao($this->parametros[1]));
                    if (isset($reembolsos) && !empty($reembolsos)) {
                        $reembolsos = json_decode($this->modelo->getSolicitacao($this->parametros[1]));
                        $despesas = json_decode($this->modelo->getMetaDadosPorReembolso($this->parametros[1]));
                    } else {
                        echo 'Não foi possível acessar essa solicitação de reembolso!';
                        exit;
                    }
                    break;
            }
        }
        require_once ABSPATH . '/views/' . $this->nome_modulo . '/detalhe-view.php';
    }

    function getDetalheMetaDado()
    {
        try {
            $this->cl_permissoes->verificarPermissao($this->getModulo());
            if (isset($this->parametros[1]) && !empty($this->parametros[1]) && is_numeric($this->parametros[1])) {
                $dados_meta = json_decode($this->modelo->getMetaDados($this->parametros[1]));
                if ($dados_meta) {
                    $retorno['codigo'] = 0;
                    $retorno['output'] = $dados_meta[0];
                    $retorno['mensagem'] = 'Sucesso';
                } else {
                    $retorno['codigo'] = 1;
                    $retorno['output'] = null;
                    $retorno['mensagem'] = 'Metadado não encontrado';
                }
            } else {
                $retorno['codigo'] = 1;
                $retorno['output'] = null;
                $retorno['mensagem'] = 'Informe o metadado';
            }
            throw new Exception(json_encode($retorno), 1);
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function includeDespesa()
    {
        try {
            $parametros = null;
            if (!$this->verificaStatusPago(array($_POST['id_reembolso']))) {
                $retorno['codigo'] = 1;
                $retorno['mensagem'] = 'Não é possivel realizar alteração no reembolso após o pagamento.';
                throw new Exception(json_encode($retorno), 1);
            } else {
                switch ($this->parametros[0]) {
                    case 'cadastro':
                        if (isset($_POST['id_reembolso']) && !empty($_POST['id_reembolso']) && is_numeric($_POST['id_reembolso'])) {
                            $id_reembolso = $_POST['id_reembolso'];
                        } else {
                            $id_reembolso = null;
                        }

                        if (!isset($_POST['cliente']) || empty($_POST['cliente'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Campo Cliente não informado!';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['tipo']) || empty($_POST['tipo'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Campo tipo não informado!';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['data_ini']) || empty($_POST['data_ini'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Campo data_ini não informado!';
                            throw new Exception(json_encode($retorno), 1);
                        } else {
                            $_POST['data_ini'] = convertDate($_POST['data_ini']);
                        }

                        if (!isset($_POST['data_fim']) || empty($_POST['data_fim'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Campo data_fim não informado!';
                            throw new Exception(json_encode($retorno), 1);
                        } else {
                            $_POST['data_fim'] = convertDate($_POST['data_fim']);
                        }

                        if (!isset($_POST['descricao']) || empty($_POST['descricao'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Campo descricao não informado!';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        $param_save['cliente'] = $_POST['cliente'];
                        $param_save['tipo'] = $_POST['tipo'];
                        $param_save['data_ini'] = $_POST['data_ini'];
                        $param_save['data_fim'] = $_POST['data_fim'];
                        $param_save['descricao'] = $_POST['descricao'];
                        if (!validaid($_POST['id_reembolso'])) {
                            $param_save['owner'] = $_SESSION['cmswerp']['userdata']->id;
                        }
                        // else{
                        //     // chama funcao para criar json de historico
                        // }
                        $param_save['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
                        $param_save['alterado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
                        $param_save['deleted'] = 0;
                        if (!$id_reembolso && $this->checkStatusReembolso($id_reembolso)) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Não é possivel alterar ou incluir despesas depois de aprovado';
                            throw new Exception(json_encode($retorno), 1);
                        } else {
                            $id_cadastro = $this->modelo->save($param_save, $id_reembolso);
                            if ($id_cadastro) {
                                $this->enviarNotificacao('send_boss', 'cadastro', $id = null);
                                $retorno['codigo'] = 0;
                                $retorno['output'] = $id_cadastro;
                                $retorno['mensagem'] = 'Sucesso';
                                throw new Exception(json_encode($retorno), 1);
                            } else {
                                $retorno['codigo'] = 1;
                                $retorno['mensagem'] = 'Erro ao salvar requisicao';
                                throw new Exception(json_encode($retorno), 1);
                            }
                        }
                        break;
                    case 'km':
                        if (!isset($_POST['id_reembolso']) || empty($_POST['id_reembolso'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Cadastro reembolso não encontrado';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['cep_origem']) || empty($_POST['cep_origem'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Informe Destino e Origem do CEP';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['endereco_origem']) || empty($_POST['endereco_origem'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Informe Destino e Origem do Endereco';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['numero_origem']) || empty($_POST['numero_origem'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Informe Destino e Origem do Numero';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['cidade_origem']) || empty($_POST['cidade_origem'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Informe Destino e Origem da Cidade';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['estado_origem']) || empty($_POST['estado_origem'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Informe Destino e Origem do Estado';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['cep_destino']) || empty($_POST['cep_destino'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Informe Destino e Origem do CEP';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['endereco_destino']) || empty($_POST['endereco_destino'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Informe Destino e Origem do Endereco';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['numero_destino']) || empty($_POST['numero_destino'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Informe Destino e Origem do Numero';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['cidade_destino']) || empty($_POST['cidade_destino'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Informe Destino e Origem da Cidade';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['estado_destino']) || empty($_POST['estado_destino'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Informe Destino e Origem do Estado';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        $param_rota['origem'] = $_POST['endereco_origem'] . ' ' . $_POST['numero_origem'] . ',' . $_POST['cep_origem'] . ',' . $_POST['cidade_origem'] . '-' . $_POST['estado_origem'] . ', brasil';
                        $param_rota['destino'] = $_POST['endereco_destino'] . ' ' . $_POST['numero_destino'] . ',' . $_POST['cep_destino'] . ',' . $_POST['cidade_destino'] . '-' . $_POST['estado_destino'] . ', brasil';
                        $param_rota['origem'] = str_ireplace("'", "", $param_rota['origem']);
                        $param_rota['destino'] = str_ireplace("'", "", $param_rota['destino']);
                        $retorno_rota = $this->apiClass->Exec('BING001', 'maps', 'calcularKm', $_POST);

                        if (!$retorno_rota) {
                            throw new Exception(json_encode(['codigo' => 1, 'mensagem' => 'Erro ao calcular rota']), 1);
                        }

                        $json_rota['resumo']['unidade_medida'] = 'KM';
                        $json_rota['resumo']['distancia'] = $retorno_rota;
                        $json_rota['resumo']['valor_solicitado'] = $retorno_rota * $this->valor_km;

                        $json_rota['origem']['logradouro'] = $_POST['endereco_origem'];
                        $json_rota['origem']['numero'] = $_POST['numero_origem'];
                        $json_rota['origem']['cidade'] = $_POST['cidade_origem'];
                        $json_rota['origem']['estado'] = $_POST['estado_origem'];
                        $json_rota['origem']['cep'] = $_POST['cep_origem'];
                        $json_rota['origem']['pais'] = 'brasil';

                        $json_rota['destino']['logradouro'] = $_POST['endereco_destino'];
                        $json_rota['destino']['numero'] = $_POST['numero_destino'];
                        $json_rota['destino']['cidade'] = $_POST['cidade_destino'];
                        $json_rota['destino']['estado'] = $_POST['estado_destino'];
                        $json_rota['destino']['cep'] = $_POST['cep_destino'];
                        $json_rota['origem']['pais'] = 'brasil';

                        $param_save['id_conjunto'] = 1;
                        $param_save['meta_campo'] = 'rota';
                        $param_save['meta_tipo'] = 'reembolso';
                        $param_save['meta_classificacao'] = 'kilometragem';
                        $param_save['meta_valor'] = $json_rota['resumo']['valor_solicitado'];
                        $param_save['meta_origem'] = 'reembolso';
                        $param_save['meta_info'] = json_encode($json_rota);
                        $param_save['meta_id_origem'] = $_POST['id_reembolso'];
                        $param_save['meta_default'] = '0';
                        $param_save['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
                        $param_save['alterado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
                        $param_save['deleted'] = 0;
                        if ($this->checkStatusReembolso($_POST['id_reembolso'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Não é possivel alterar ou incluir despesas depois de aprovado';
                            throw new Exception(json_encode($retorno), 1);
                        } else {
                            $this->modelo->setTable('meta_dados');
                            $is_save = $this->modelo->save($param_save);
                            if ($is_save) {
                                if (!isset($_FILES['arquivo']) || !empty($_FILES['arquivo']) || $_FILES['arquivo']['size'] == 0) {
                                    $retorno['codigo'] = 0;
                                    $retorno['mensagem'] = 'Despesa enviada com sucesso';
                                    $retorno['output'] = $_POST['id_reembolso'];
                                    throw new Exception(json_encode($retorno), 0);
                                }
                                // $this->enviarNotificacao('send_boss', 'km', $id = null);
                                $param_ged['id_reembolso'] = $is_save;
                                $param_ged['nome_arquivo'] = $_FILES['arquivo']['name'];
                                $param_ged['tmp_name'] = $_FILES['arquivo']['tmp_name'];
                                $param_ged['error'] = $_FILES['arquivo']['error'];
                                $param_ged['size'] = $_FILES['arquivo']['size'];
                                $param_ged['doc_origem'] = 'meta_dados';
                                $param_ged['tipo'] = 'despesa';
                                $param_ged['subtipo'] = 'km';
                                $param_ged['data_pagamento'] = $this->data_hora_atual->format('Y-m-d H:i:s');
                                $this->uploadDoc($param_ged);
                            } else {
                                $retorno['codigo'] = 1;
                                $retorno['mensagem'] = 'Erro ao salvar Kilometragem';
                                throw new Exception(json_encode($retorno), 1);
                            }
                        }
                        break;
                    case 'despesa':
                        if (!isset($_POST['id_reembolso']) || empty($_POST['id_reembolso'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Cadastro reembolso não encontrado';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['tipo']) || empty($_POST['tipo'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Campo tipo não informado!';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['cnpj_prestador']) || empty($_POST['cnpj_prestador'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Campo CNPJ PRESTADOR não informado!';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['prestador_servico']) || empty($_POST['prestador_servico'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Campo Prestador de Serviço não informado!';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['quantidade']) || empty($_POST['quantidade'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Campo Quantidade não informado!';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        if (!isset($_POST['valor_solicitado']) || empty($_POST['valor_solicitado'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Informe o Valor total!';
                            throw new Exception(json_encode($retorno), 1);
                        }

                        $param_desp['resumo']['tipo'] = $_POST['tipo'];
                        $param_desp['resumo']['cnpj_prestador'] = $_POST['cnpj_prestador'];
                        $param_desp['resumo']['prestador_servico'] = $_POST['prestador_servico'];
                        $param_desp['resumo']['quantidade'] = $_POST['quantidade'];
                        $param_desp['resumo']['valor_solicitado'] = removeCaracteres($_POST['valor_solicitado'], 'moeda2');

                        $param_desp_save['id_conjunto'] = 1;
                        $param_desp_save['meta_campo'] = 'despesa';
                        $param_desp_save['meta_tipo'] = 'reembolso';
                        $param_desp_save['meta_classificacao'] = $_POST['tipo'];
                        $param_desp_save['meta_valor'] = removeCaracteres($_POST['valor_solicitado'], 'moeda2');
                        $param_desp_save['meta_origem'] = 'reembolso';
                        $param_desp_save['meta_info'] = json_encode($param_desp);
                        $param_desp_save['meta_id_origem'] = $_POST['id_reembolso'];
                        $param_desp_save['meta_default'] = '0';
                        $param_desp_save['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
                        $param_desp_save['alterado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
                        $param_desp_save['deleted'] = 0;
                        if ($this->checkStatusReembolso($_POST['id_reembolso'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Não é possivel alterar ou incluir despesas depois de aprovado';
                            throw new Exception(json_encode($retorno), 1);
                        } else {
                            $this->modelo->setTable('meta_dados');
                            $id_desp_save = $this->modelo->save($param_desp_save);
                            if ($id_desp_save) {
                                $this->enviarNotificacao('send_boss', 'despesa', $id = null);
                                $param_desp_ged['id_reembolso'] = $id_desp_save;
                                $param_desp_ged['nome_arquivo'] = $_FILES['arquivo']['name'];
                                $param_desp_ged['tmp_name'] = $_FILES['arquivo']['tmp_name'];
                                $param_desp_ged['error'] = $_FILES['arquivo']['error'];
                                $param_desp_ged['size'] = $_FILES['arquivo']['size'];
                                $param_desp_ged['doc_origem'] = 'meta_dados';
                                $param_desp_ged['tipo'] = 'despesa';
                                $param_desp_ged['subtipo'] = $_POST['tipo'];
                                $param_desp_ged['data_pagamento'] = $this->data_hora_atual->format('Y-m-d H:i:s');
                                $this->uploadDoc($param_desp_ged);
                            } else {
                                $retorno['codigo'] = 1;
                                $retorno['mensagem'] = 'Erro ao salvar despesa!';
                                throw new Exception(json_encode($retorno), 1);
                            }
                        }
                        break;
                }
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function uploadDoc($param)
    {
        try {
            $file = pathinfo($param['nome_arquivo']);
            if (isset($_SESSION['cmswerp']['userdata']->cpf) && !empty($_SESSION['cmswerp']['userdata']->cpf)) {
                $nome_documento = $_SESSION['cmswerp']['userdata']->cpf . '_';
            }
            $nome_documento .= $param['tipo'] . '_' . $param['subtipo'] . '_' . $this->data_hora_atual->format('YmdHis') . '.' . $file['extension'];
            $param_ged['nome_documento'] = $param['nome_arquivo'];
            $param_ged['data_documento'] = $this->data_hora_atual->format('Y-m-d H:i:s');
            $param_ged['doc_origem'] = $param['doc_origem'];
            $param_ged['tipo'] = $param['tipo'];
            $param_ged['subtipo'] = $param['subtipo'];
            $param_ged['id_origem'] = $param['id_reembolso'];
            $param_ged['codigo_origem'] = $param['codigo_origem'];
            $param_ged['versao'] = 'original';
            $param_ged['owner'] = $_SESSION['cmswerp']['userdata']->id;
            $param_ged['data_criacao'] = $this->data_hora_atual->format('Y-m-d H:i:s');
            $param_ged['alterado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
            $param_ged['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
            $param_ged['deleted'] = 0;
            $this->modelo->setTable('ged_documento');
            $is_save = $this->modelo->save($param_ged);
            if ($is_save) {
                $anexo['id_documento'] = $is_save;
                $anexo['nome_amigavel'] = $nome_documento;
                $anexo['path_root'] = ABSPATH . DS . 'dir_ged' . DS;
                $anexo['path_objeto'] = 'pessoal' . DS . $_SESSION['cmswerp']['userdata']->cpf . DS . 'reembolso' . DS;
                $anexo['nome_hash'] = $nome_documento;
                $anexo['hash_arquivo'] = md5($nome_documento);
                $anexo['data_criacao'] = $this->data_hora_atual->format('Y-m-d');
                $anexo['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
                $anexo['alterado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
                $anexo['deleted'] = 0;
                $this->modelo->setTable('ged_anexo');
                $save_anexo = $this->modelo->save($anexo);
                if ($save_anexo) {
                    $config['pasta'] = $anexo['path_root'] . $anexo['path_objeto'];
                    $param_upload['name'] = $nome_documento;
                    $param_upload['tmp_name'] = $param['tmp_name'];
                    $param_upload['error'] = $param['error'];
                    $param_upload['size'] = $param['size'];
                    $is_upload = $this->uploadClass->loadFile($param_upload, $config);
                    throw new Exception($is_upload);
                } else {
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] = 'Erro ao salvar anexo na tabela.';
                    throw new Exception(json_encode($retorno));
                }
            } else {
                $retorno['codigo'] = 1;
                $retorno['mensagem'] = 'Erro ao enviar arquivo! Verifique o formato e tamanho do arquivo.';
                throw new Exception(json_encode($retorno));
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function alterarStatus()
    {
        try {
            $this->cl_permissoes->verificarPermissao($this->getModulo());
            if ($this->cl_permissoes->alcada_acesso >= 3 || $this->cl_permissoes->permissao_acesso >= 3) {
                switch ($this->parametros[0]) {
                    case 'aprovar':
                        $status = 'aprovado';
                        break;
                    case 'reprovar':
                        $status = 'reprovado';
                        break;
                    case 'pago':
                        $lista_id_reembolso = [];
                        foreach ($_POST['dados_req'] as $key => $value) {
                            $lista_id_reembolso[] = $value['value'];
                        }
                        $consulta_status = json_decode($this->modelo->getReembolso($lista_id_reembolso));

                        if ($this->cl_permissoes->permissao_acesso >= 4) {
                            foreach ($consulta_status as $key => $value) {
                                if ($value->status != 'aprovado') {
                                    $retorno['codigo'] = 1;
                                    $retorno['mensagem'] = 'Alteração não permitida! Existe algum reembolso que não está com status "aprovado".';
                                    throw new Exception(json_encode($retorno), 1);
                                }
                            }
                            $status = 'pago';
                        } else {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Você não tem permissão para realizar essa alteração! COD: 597';
                            throw new Exception(json_encode($retorno), 1);
                        }
                        break;
                }
            } else {
                $retorno['codigo'] = 1;
                $retorno['mensagem'] = 'Você não tem permissão para realizar essa alteração! COD: 557';
                throw new Exception(json_encode($retorno), 1);
            }

            $dados_req = $_POST['dados_req'];
            if (!isset($dados_req) || empty($dados_req)) {
                $retorno['codigo'] = 1;
                $retorno['mensagem'] = 'Erro: Nenhum ID selecionado!';
                throw new Exception(json_encode($retorno), 1);
            } else {
                $dados_req = $_POST['dados_req'];
            }

            if (is_array($dados_req)) {
                foreach ($dados_req as $key => $value) {
                    $id = $value['value'];
                    $ids_reembolso[$id] = $value['value'];
                }
            } else {
                $ids_reembolso = [
                    "$dados_req" => "$dados_req"
                ];
            }
            // false - existe status = PAGO
            // true - NAO existe status = PAGO
            if (!$this->verificaStatusPago($ids_reembolso)) {
                $retorno['codigo'] = 1;
                $retorno['mensagem'] = 'Não é possivel realizar alteração no reembolso após o pagamento.';
                throw new Exception(json_encode($retorno), 1);
            }

            $aprovacoes = json_decode($this->modelo->getMetaDadosByStatus($ids_reembolso));
            if ($aprovacoes) {
                $this->modelo->setTable('meta_dados');
                foreach ($aprovacoes as $key => $value) {
                    $tipo_autorizacao = null;
                    if ($this->quemAprova()) {
                        $tipo_autorizacao = 'rh';
                    } else {
                        $tipo_autorizacao = 'gestor';
                    }
                    if ($tipo_autorizacao) {
                        if (empty($value->meta_id_origem)) { // reembolso novo sem historico de aprovacao
                            $json_meta_info['lista_status'][0]['id_user'] = $this->userdata->id;
                            $json_meta_info['lista_status'][0]['nome_user'] = $this->userdata->nome;
                            $json_meta_info['lista_status'][0]['data'] = $this->data_hora_atual->format('Y-m-d H:i:s');
                            $json_meta_info['lista_status'][0]['status'] = $status;
                            $json_meta_info['lista_status'][0]['tipo_aprovacao'] = $tipo_autorizacao;
                            $param_save['id_conjunto'] = 1;
                            $param_save['meta_campo'] = 'status';
                            $param_save['meta_classificacao'] = 'status';
                            $param_save['meta_valor'] = 0;
                            $param_save['meta_origem'] = 'reembolso';
                            $param_save['meta_tipo'] = 'reembolso';
                            $param_save['meta_info'] = json_encode($json_meta_info);
                            $param_save['meta_id_origem'] = $value->id;
                            $param_save['meta_default'] = 0;
                            $param_save['alterado_por'] = $this->userdata->nome;
                            $param_save['alterado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
                            $param_save['deleted'] = 0;
                            if ($status == 'pago') {
                                $retorno['codigo'] = 1;
                                $retorno['mensagem'] = 'Não é possível realizar essa ação no momento!';
                                throw new Exception(json_encode($retorno), 1);
                            } else {
                                $this->modelo->setTable('meta_dados');
                                $is_save = $this->modelo->save($param_save);
                                if (!$is_save) {
                                    $retorno['codigo'] = 1;
                                    $retorno['mensagem'] = 'Erro ao criar status';
                                    throw new Exception(json_encode($retorno), 1);
                                } else {
                                    $id_reembolso = [
                                        "$value->id" => "$value->id"
                                    ];
                                    $this->enviarNotificacao('send_user', $status, $id_reembolso);
                                    $save_status_reembolso = $this->saveStatus($status, $id_reembolso);
                                    if (!$save_status_reembolso) {
                                        $retorno['codigo'] = 1;
                                        $retorno['mensagem'] = 'Erro ao salvar status na tabela reembolso!';
                                        throw new Exception(json_encode($retorno), 1);
                                    }
                                }
                            }
                        } elseif (!empty($value->meta_id_origem) && empty($value->meta_info)) { // existe reembolso mas por algum motivo o campo meta_info está vazio
                            $param_status['lista_status'][0]['id_user'] = $this->userdata->id;
                            $param_status['lista_status'][0]['nome_user'] = $this->userdata->nome;
                            $param_status['lista_status'][0]['data'] = $this->data_hora_atual->format('Y-m-d H:i:s');
                            $param_status['lista_status'][0]['status'] = $status;
                            $param_status['lista_status'][0]['tipo_aprovacao'] = $tipo_autorizacao;
                            $param_save['meta_info'] = json_encode($param_status);
                            $verifica_recebivel = $this->verificaRecebivel($ids_reembolso, $status);
                            if ($verifica_recebivel) {
                                $this->modelo->setTable('meta_dados');
                                $is_save = $this->modelo->save($param_save, $value->id_meta_dados);
                                if (!$is_save) {
                                    $retorno['codigo'] = 1;
                                    $retorno['mensagem'] = 'Erro ao salvar status';
                                    throw new Exception(json_encode($retorno), 1);
                                } else {
                                    $id_reembolso = [
                                        "$value->id" => "$value->id"
                                    ];
                                    $this->enviarNotificacao('send_user', $status, $id_reembolso);
                                    $save_status_reembolso = $this->saveStatus($status, $id_reembolso);
                                    if (!$save_status_reembolso) {
                                        $retorno['codigo'] = 1;
                                        $retorno['mensagem'] = 'Erro ao salvar status na tabela reembolso!';
                                        throw new Exception(json_encode($retorno), 1);
                                    }
                                }
                            } else {
                                $retorno['codigo'] = 1;
                                $retorno['mensagem'] = 'Erro, uma ou mais despesas não constam valor recebivel!';
                                throw new Exception(json_encode($retorno), 1);
                            }
                        } elseif (!empty($value->meta_id_origem) && !empty($value->meta_info)) { // Atualizar historico de status ja existente ( campo meta_info preenchido )
                            $param['id_user'] = $this->userdata->id;
                            $param['nome_user'] = $this->userdata->nome;
                            $param['data'] = $this->data_hora_atual->format('Y-m-d H:i:s');
                            $param['status'] = $status;
                            $param['tipo_aprovacao'] = $tipo_autorizacao;
                            $meta_info = json_decode($value->meta_info);
                            array_push($meta_info->lista_status, $param);
                            $param_save['meta_info'] = json_encode($meta_info);
                            $verifica_recebivel = $this->verificaRecebivel($ids_reembolso, $status);
                            if ($verifica_recebivel) {
                                $this->modelo->setTable('meta_dados');
                                $is_save = $this->modelo->save($param_save, $value->id_meta_dados);
                                if (!$is_save) {
                                    $retorno['codigo'] = 1;
                                    $retorno['mensagem'] = 'Erro ao adicionar status';
                                    throw new Exception(json_encode($retorno), 1);
                                } else {
                                    $id_reembolso = [
                                        "$value->id" => "$value->id"
                                    ];
                                    $this->enviarNotificacao('send_user', $status, $id_reembolso);
                                    $save_status_reembolso = $this->saveStatus($status, $id_reembolso);
                                    if (!$save_status_reembolso) {
                                        $retorno['codigo'] = 1;
                                        $retorno['mensagem'] = 'Erro ao salvar status na tabela reembolso!';
                                        throw new Exception(json_encode($retorno), 1);
                                    }
                                }
                            } else {
                                $retorno['codigo'] = 1;
                                $retorno['mensagem'] = 'Erro, uma ou mais despesas não constam valor recebivel!';
                                throw new Exception(json_encode($retorno), 1);
                            }
                        } else {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Erro ao atualizar campo Status.';
                            throw new Exception(json_encode($retorno), 1);
                        }
                    } else {
                        $retorno['codigo'] = 1;
                        $retorno['mensagem'] = 'Erro ao tentar obter o tipo de autorização.';
                        throw new Exception(json_encode($retorno), 1);
                    }
                }
                $retorno['codigo'] = 0;
                $retorno['mensagem'] = 'Sucesso ao atualizar status!';
                throw new Exception(json_encode($retorno), 1);
            } else {
                $retorno['codigo'] = 1;
                $retorno['mensagem'] = 'Erro ao tentar criar, salvar ou adicionar novo status!';
                throw new Exception(json_encode($retorno), 1);
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function alterarRecebivel()
    {
        try {
            if (!$this->verificaStatusPago(array($this->parametros[1]))) {
                $retorno['codigo'] = 1;
                $retorno['mensagem'] = 'Não é possivel realizar alteração no reembolso após o pagamento.';
                throw new Exception(json_encode($retorno), 1);
            } else {
                $this->cl_permissoes->verificarPermissao($this->getModulo());
                if (!isset($_POST['id_registro']) || empty($_POST['id_registro']) || !is_numeric($_POST['id_registro'])) {
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] = 'Informe o ID da despesa';
                    throw new Exception(json_encode($retorno), 1);
                }

                if (!isset($_POST['dados_req']) || empty($_POST['dados_req'])) {
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] = 'Erro recebivel não encontrado!';
                    throw new Exception(json_encode($retorno), 1);
                }
                parse_str($_POST['dados_req'], $output);
                $meta_dados = json_decode($this->modelo->getMetaDados($_POST['id_registro']));
                if ($meta_dados) {
                    $meta_info = json_decode($meta_dados[0]->meta_info);
                    if ($output['acao'] == 'aprovar') {
                        $meta_info->resumo->recebivel = 1;
                        $meta_info->resumo->valor_recebivel = funcValor($output['input_recebivel'], 'L');
                        $historico['valor_recebivel'] = funcValor($output['input_recebivel'], 'L');
                        $historico['recebivel'] = 1;
                    } else {
                        $meta_info->resumo->recebivel = 0;
                        $meta_info->resumo->valor_recebivel = 0;
                        $historico['valor_recebivel'] = 0;
                        $historico['recebivel'] = 0;
                    }
                    $historico['nome_user'] = $this->userdata->nome;
                    $historico['alterado_por'] = $this->userdata->id;
                    $historico['alterado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
                    $meta_info->historico[] = (object) $historico;
                    $param_save['meta_info'] = json_encode($meta_info);

                    if ($this->cl_permissoes->alcada_acesso >= 4) {
                        if (!isset($this->parametros[1]) || empty($this->parametros[1]) || is_numeric(intval($this->parametros[1]))) {
                            if ($this->checkStatusReembolso($this->parametros[1])) {
                                if ($this->quemAprova()) {
                                    $this->modelo->setTable('meta_dados');
                                    $is_save = $this->modelo->save($param_save, $_POST['id_registro']);
                                    if ($is_save) {
                                        $retorno['codigo'] = 0;
                                        $retorno['mensagem'] = 'Sucesso ao alterar recebivel!';
                                        throw new Exception(json_encode($retorno), 1);
                                    } else {
                                        $retorno['codigo'] = 1;
                                        $retorno['mensagem'] = 'Erro ao alterar despesa!';
                                        throw new Exception(json_encode($retorno), 1);
                                    }
                                } else {
                                    $retorno['codigo'] = 1;
                                    $retorno['mensagem'] = 'Sem permissão para realizar essa alteração!';
                                    throw new Exception(json_encode($retorno), 1);
                                }
                                $retorno['codigo'] = 1;
                                $retorno['mensagem'] = 'Não é possivel alterar ou incluir despesas depois de aprovado';
                                throw new Exception(json_encode($retorno), 1);
                            } else {
                                $this->modelo->setTable('meta_dados');
                                $is_save = $this->modelo->save($param_save, $_POST['id_registro']);
                                if ($is_save) {
                                    $retorno['codigo'] = 0;
                                    $retorno['mensagem'] = 'Sucesso ao alterar recebivel!';
                                    throw new Exception(json_encode($retorno), 1);
                                } else {
                                    $retorno['codigo'] = 1;
                                    $retorno['mensagem'] = 'Erro ao alterar despesa!';
                                    throw new Exception(json_encode($retorno), 1);
                                }
                            }
                        } else {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'ID reembolso não encontrado!';
                            throw new Exception(json_encode($retorno), 1);
                        }
                    } else {
                        $retorno['codigo'] = 1;
                        $retorno['mensagem'] = 'Você não tem permissão para alterar este campo!';
                        throw new Exception(json_encode($retorno), 1);
                    }
                } else {
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] = 'Despesa não encontrada!';
                    throw new Exception(json_encode($retorno), 1);
                }
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function deletarDespesaMetaDados()
    {
        try {
            if (!$this->verificaStatusPago(array($this->parametros[1]))) {
                $retorno['codigo'] = 1;
                $retorno['mensagem'] = 'Não é possivel realizar alteração no reembolso após o pagamento.';
                throw new Exception(json_encode($retorno), 1);
            } else {
                if (!$this->verificaStatusPago(array($_POST['id_registro']))) {
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] = 'Não é possivel realizar alteração no reembolso após o pagamento.';
                    throw new Exception(json_encode($retorno), 1);
                } else {
                    $this->cl_permissoes->verificarPermissao($this->getModulo());
                    if ($_POST['id_registro']) {
                        if (!isset($_POST['id_registro']) || empty($_POST['id_registro']) || !is_numeric($_POST['id_registro'])) {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'ID da despesa não encontrado!';
                            throw new Exception(json_encode($retorno), 1);
                        } else {
                            $id_registro = $_POST['id_registro'];
                        }
                    }

                    if (!isset($_POST['dados_req']) || !is_numeric($_POST['dados_req'])) {
                        $retorno['codigo'] = 1;
                        $retorno['mensagem'] = 'Erro DELETAR não encontrado!';
                        throw new Exception(json_encode($retorno), 1);
                    }

                    if ($_POST['id_registro']) {
                        $param_save['deleted'] = $_POST['dados_req'];
                        if (!isset($this->parametros[1]) || empty($this->parametros[1]) || is_numeric(intval($this->parametros[1]))) {
                            if ($this->checkStatusReembolso($this->parametros[1])) {
                                $retorno['codigo'] = 1;
                                $retorno['mensagem'] = 'Não é possivel alterar ou incluir despesas depois de aprovado';
                                throw new Exception(json_encode($retorno), 1);
                            } else {
                                $this->modelo->setTable('meta_dados');
                                $is_save = $this->modelo->save($param_save, $id_registro);
                                if ($is_save) {
                                    $retorno['codigo'] = 0;
                                    $retorno['mensagem'] = 'Sucesso ao deletar despesa!';
                                    throw new Exception(json_encode($retorno), 1);
                                } else {
                                    $retorno['codigo'] = 1;
                                    $retorno['mensagem'] = 'Erro ao deletar despesa!';
                                    throw new Exception(json_encode($retorno), 1);
                                }
                            }
                        } else {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'ID reembolso não encontrado!';
                            throw new Exception(json_encode($retorno), 1);
                        }
                    }
                }
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function deletar()
    {
        try {
            $this->cl_permissoes->verificarPermissao($this->getModulo());
            $dados_req = $_POST['dados_req'];
            if (!isset($dados_req) || empty($dados_req)) {
                $retorno['codigo'] = 1;
                $retorno['mensagem'] = 'Erro: Nenhum ID selecionado!';
                throw new Exception(json_encode($retorno), 1);
            } else {
                $dados_req = $_POST['dados_req'];
            }

            foreach ($dados_req as $key => $value) {
                $id = $value['value'];

                if (!$this->verificaStatusPago(array($id))) {
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] = 'Não é possivel realizar alteração no reembolso após o pagamento.';
                    throw new Exception(json_encode($retorno), 1);
                }

                if (!isset($id) || empty($id) || !is_numeric($id)) {
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] = 'ID do reembolso não encontrado!';
                    throw new Exception(json_encode($retorno), 1);
                }

                switch ($this->cl_permissoes->alcada_acesso) {
                    case '4':
                        $this->cl_permissoes->alcada_acesso >= 4;
                        break;
                    default:
                        $retorno['codigo'] = 1;
                        $retorno['teste'] = $this->cl_permissoes->alcada_acesso;
                        $retorno['mensagem'] = 'Você não tem permissão para apagar o(s) reembolso(s)!';
                        throw new Exception(json_encode($retorno), 1);
                        break;
                }
                $param_save['deleted'] = 1;
                if ($this->checkStatusReembolso($id)) {
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] = 'Não é possivel alterar ou incluir despesas depois de aprovado';
                    throw new Exception(json_encode($retorno), 1);
                } else {
                    $is_save = $this->modelo->save($param_save, $id);
                    if (!$is_save) {
                        $retorno['codigo'] = 1;
                        $retorno['mensagem'] = 'Erro ao deletar o(s) reembolso(s)!';
                        throw new Exception(json_encode($retorno), 1);
                    }
                }
            }
            $retorno['codigo'] = 0;
            $retorno['mensagem'] = 'Sucesso ao deletar o(s) reembolso(s)!';
            throw new Exception(json_encode($retorno), 1);
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function enviarNotificacao($send_type, $type, $id_reembolso = null)
    {
        try {
            switch ($send_type) {
                case 'send_boss': // usuario criou -> enviar para o chefe da area
                    switch ($type) {
                        case 'cadastro':
                            $user = $this->userdata->nome;
                            $mensagem = "O funcionário $user criou um reembolso, é necessário sua aprovação.";
                            $parametros['tipo_destinatario'] = 'user';
                            $parametros['email_to'] = $this->userdata->email_chefe;
                            $parametros['mensagem'] = $mensagem;
                            $this->obj_notificacao->enviar('teams', $parametros);
                            break;
                        case 'km':
                            $user = $this->userdata->nome;
                            $mensagem = "O funcionário $user adicionou KM ao reembolso.";
                            $parametros['tipo_destinatario'] = 'user';
                            $parametros['email_to'] = $this->userdata->email_chefe;
                            $parametros['mensagem'] = $mensagem;
                            $this->obj_notificacao->enviar('teams', $parametros);
                            break;
                        case 'despesa':
                            $user = $this->userdata->nome;
                            $mensagem = "O funcionário $user adicionou DESPESA ao reembolso.";
                            $parametros['tipo_destinatario'] = 'user';
                            $parametros['email_to'] = $this->userdata->email_chefe;
                            $parametros['mensagem'] = $mensagem;
                            $this->obj_notificacao->enviar('teams', $parametros);
                            break;
                    }
                    break;
                case 'send_user':
                    switch ($type) {
                        case 'aprovado': // chefe da area alterou status -> "aprovado" -> notificar ADM e USER
                            $lista_nome_email = json_decode($this->modelo->getMetaDadosAprovacao($id_reembolso));
                            if ($lista_nome_email) {
                                foreach ($lista_nome_email as $key => $value) {
                                    $id_reembolso = $value->id;
                                    $nome_owner = $value->nome_owner;
                                    $email_owner = $value->email_owner;
                                    $nome_chefe = $value->nome_chefe;

                                    if ($this->quemAprova()) {
                                        $nome_chefe = 'ADM';
                                        $mensagem = "Olá $nome_owner, o status do seu reembolso de ID: $id_reembolso, foi alterado para APROVADO, por $nome_chefe. 
                                            Em breve você receberá a confirmação do pagamento!";
                                    } else {
                                        $nome_chefe = $value->nome_chefe;
                                        $mensagem = "Olá $nome_owner, o status do seu reembolso de ID: $id_reembolso, foi alterado para APROVADO, por $nome_chefe. 
                                            Aguarde a aprovação da ADM para receber.";
                                    }

                                    $parametros['tipo_destinatario'] = 'user';
                                    $parametros['email_to'] = $email_owner;
                                    $parametros['mensagem'] = $mensagem;
                                    $this->obj_notificacao->enviar('teams', $parametros);

                                    $parametros['tipo_destinatario'] = 'user';
                                    $parametros['email_to'] = $this->email_adm;
                                    $parametros['mensagem'] = "Olá, o $nome_chefe, APROVOU uma solicitação de reembolso de ID: $id_reembolso do funcionário $nome_owner. Necessário validação da ADM.";
                                    $this->obj_notificacao->enviar('teams', $parametros);
                                }
                            } else {
                                $retorno['codigo'] = 1;
                                $retorno['mensagem'] = 'erro ao enviar notificação ao usuário de status aprovado';
                                throw new Exception(json_encode($retorno), 1);
                            }
                            break;
                        case 'reprovado': // chefe da area ou ADM alterou status -> "reprovado" -> notificar user
                            $lista_nome_email = json_decode($this->modelo->getMetaDadosAprovacao($id_reembolso));
                            if ($lista_nome_email) {
                                foreach ($lista_nome_email as $key => $value) {
                                    $id_reembolso = $value->id;
                                    $nome_owner = $value->nome_owner;
                                    $email_owner = $value->email_owner;

                                    if ($this->quemAprova()) {
                                        $nome_chefe = 'ADM';
                                    } else {
                                        $nome_chefe = $value->nome_chefe;
                                    }

                                    $mensagem = "Olá $nome_owner, o status do seu reembolso de ID: $id_reembolso, foi alterado para REPROVADO, por $nome_chefe. Por favor, verifique os dados do reembolso e tente novamente.";
                                    $parametros['tipo_destinatario'] = 'user';
                                    $parametros['email_to'] = $email_owner;
                                    $parametros['mensagem'] = $mensagem;
                                    $this->obj_notificacao->enviar('teams', $parametros);
                                }
                            } else {
                                $retorno['codigo'] = 1;
                                $retorno['mensagem'] = 'erro ao enviar notificação ao usuário de status reprovado';
                                throw new Exception(json_encode($retorno), 1);
                            }
                            break;
                        case 'pago': // ADM realizou o pagamento -> notificar user
                            $lista_nome_email = json_decode($this->modelo->getMetaDadosAprovacao($id_reembolso));
                            if ($lista_nome_email) {
                                foreach ($lista_nome_email as $key => $value) {
                                    $id_reembolso = $value->id;
                                    $nome_owner = $value->nome_owner;
                                    $email_owner = $value->email_owner;
                                    $nome_chefe = $value->nome_chefe;

                                    if ($this->quemAprova()) {
                                        $nome_chefe = 'ADM';
                                        $mensagem = "Olá $nome_owner, o status do seu reembolso de ID: $id_reembolso, foi alterado para PAGO, por $nome_chefe.
                                            Por favor, verifique se os valores estão corretos.";
                                    } else {
                                        echo 'erro: você não tem permissão para realizar este processo!';
                                        exit;
                                    }

                                    $parametros['tipo_destinatario'] = 'user';
                                    $parametros['email_to'] = $email_owner;
                                    $parametros['mensagem'] = $mensagem;
                                    $this->obj_notificacao->enviar('teams', $parametros);
                                }
                            } else {
                                $retorno['codigo'] = 1;
                                $retorno['mensagem'] = 'erro ao enviar notificação ao usuário de status pago';
                                throw new Exception(json_encode($retorno), 1);
                            }
                            break;
                        case 'obs_recebivel': // ADM realizou alteracao do valor -> notificar user
                            $id_array = array($id_reembolso);
                            $lista_nome_email = json_decode($this->modelo->getMetaDadosAprovacao($id_array));
                            $campo_obs = json_decode($this->modelo->getObservacao($id_reembolso));

                            $observacao = $campo_obs[0]->observacao;
                            if ($lista_nome_email) {
                                foreach ($lista_nome_email as $key => $value) {
                                    $id = $value->id;
                                    $nome_owner = $value->nome_owner;
                                    $email_owner = $value->email_owner;

                                    if ($this->quemAprova()) {
                                        $mensagem = "Olá $nome_owner, o seu reembolso de ID: $id, teve o valor alterado por ADM.
                                            Motivo: $observacao";
                                    } else {
                                        echo 'erro: você não tem permissão para realizar este processo!';
                                        exit;
                                    }

                                    $parametros['tipo_destinatario'] = 'user';
                                    $parametros['email_to'] = $email_owner;
                                    $parametros['mensagem'] = $mensagem;
                                    $this->obj_notificacao->enviar('teams', $parametros);
                                }
                            } else {
                                $retorno['codigo'] = 1;
                                $retorno['mensagem'] = 'É necessário que o reembolso tenha alguma status de aprovado/reprovado';
                                throw new Exception(json_encode($retorno), 1);
                            }
                            break;
                    }
                    break;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function obsRecebivel()
    {
        try {
            if (!$this->verificaStatusPago(array($this->parametros[1]))) {
                $retorno['codigo'] = 1;
                $retorno['mensagem'] = 'Não é possivel realizar alteração no reembolso após o pagamento.';
                throw new Exception(json_encode($retorno), 1);
            } else {
                if (isset($this->parametros[1]) && is_numeric($this->parametros[1]) && !empty($this->parametros[1])) {
                    $dados_req = $_POST['dados_req'];
                    if (!isset($dados_req) || empty($dados_req)) {
                        $retorno['codigo'] = 1;
                        $retorno['mensagem'] = 'Erro, dados não encontrados: 1090';
                        throw new Exception(json_encode($retorno), 1);
                    } else {
                        $dados_req = $_POST['dados_req'];
                    }

                    if (!isset($dados_req) || empty($dados_req)) {
                        $retorno['codigo'] = 1;
                        $retorno['mensagem'] = 'Erro, campo Observação não inforamdo!';
                        throw new Exception(json_encode($retorno), 1);
                    }

                    if ($this->quemAprova()) {
                        foreach ($dados_req as $key => $value) {
                            $obsercacao = $value['value'];
                            $verifica_campo = json_decode($this->modelo->getObservacao($this->parametros[1]));
                            $id_observacao = $verifica_campo[0]->id_despesa;
                            if ($verifica_campo) {
                                $this->modelo->setTable('meta_dados');
                                $param_save['id_conjunto'] = 1;
                                $param_save['meta_campo'] = 'observacao';
                                $param_save['meta_tipo'] = 'reembolso';
                                $param_save['meta_classificacao'] = 'obs_recebivel';
                                $param_save['meta_valor'] = 0;
                                $param_save['meta_origem'] = 'reembolso';
                                $param_save['meta_info'] = json_encode($obsercacao);
                                $param_save['meta_id_origem'] = $this->parametros[1];
                                $param_save['meta_default'] = '0';
                                $param_save['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
                                $param_save['alterado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
                                $param_save['deleted'] = 0;
                                if ($this->quemAprova()) {
                                    $is_save = $this->modelo->save($param_save, $id_observacao);
                                    if (!$is_save) {
                                        $retorno['codigo'] = 1;
                                        $retorno['mensagem'] = 'Erro ao salvar observação';
                                        throw new Exception(json_encode($retorno), 1);
                                    } else {
                                        $this->enviarNotificacao('send_user', 'obs_recebivel', $this->parametros[1]);
                                        $retorno['codigo'] = 0;
                                        $retorno['mensagem'] = 'Sucesso ao inserir observação.';
                                        throw new Exception(json_encode($retorno), 1);
                                    }
                                }
                            } else {
                                $this->modelo->setTable('meta_dados');
                                $param_save['id_conjunto'] = 1;
                                $param_save['meta_campo'] = 'observacao';
                                $param_save['meta_tipo'] = 'reembolso';
                                $param_save['meta_classificacao'] = 'obs_recebivel';
                                $param_save['meta_valor'] = 0;
                                $param_save['meta_origem'] = 'reembolso';
                                $param_save['meta_info'] = json_encode($obsercacao);
                                $param_save['meta_id_origem'] = $this->parametros[1];
                                $param_save['meta_default'] = '0';
                                $param_save['alterado_por'] = $_SESSION['cmswerp']['userdata']->id;
                                $param_save['alterado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
                                $param_save['deleted'] = 0;
                                if ($this->quemAprova()) {
                                    $is_save = $this->modelo->save($param_save);
                                    if (!$is_save) {
                                        $retorno['codigo'] = 1;
                                        $retorno['mensagem'] = 'Erro ao salvar observação';
                                        throw new Exception(json_encode($retorno), 1);
                                    } else {
                                        $this->enviarNotificacao('send_user', 'obs_recebivel', $this->parametros[1]);
                                        $retorno['codigo'] = 0;
                                        $retorno['mensagem'] = 'Sucesso ao inserir observação.';
                                        throw new Exception(json_encode($retorno), 1);
                                    }
                                }
                            }
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Sem permissão para realizar essa operação!';
                            throw new Exception(json_encode($retorno), 1);
                        }
                    } else {
                        $retorno['codigo'] = 1;
                        $retorno['mensagem'] = 'Sem permissão para realizar essa operação!';
                        throw new Exception(json_encode($retorno), 1);
                    }
                }
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }

    function verificaRecebivel($id_reembolso, $status)
    {
        if ($status == 'pago') {
            $meta_dados = json_decode($this->modelo->getSolicitacaoArray($id_reembolso));
            $array = null;
            foreach ($meta_dados as $key => $value) {
                $i = $value->id_meta;
                $meta_info = json_decode($value->meta_info);
                $array[$i]['id_reembolso'] = $value->id_reembolso;
                $array[$i]['tipo'] = $value->meta_classificacao;
                $array[$i]['recebivel'] = $meta_info->resumo->recebivel;
            }
            $nullEncontrado = false;
            foreach ($array as $subArray) {
                if (array_key_exists('recebivel', $subArray) && is_null($subArray['recebivel'])) {
                    $nullEncontrado = true;
                    break;
                }
            }
            if ($nullEncontrado) {
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }

    function verificaStatusPago($id_reembolso)
    {
        $meta_dados = json_decode($this->modelo->getVerificaStatus($id_reembolso));
        $array = null;
        foreach ($meta_dados as $key => $value) {
            $i = $value->id;
            $meta_info = json_decode($value->meta_info);
            foreach ($meta_info->lista_status as $key => $v1) {
                $array[$i]['status_metadados'] = $v1->status;
            }
        }
        $nullEncontrado = false;

        foreach ($array as $subArray) {
            if (in_array('pago', $subArray)) {
                $nullEncontrado = true;
                break;
            }
        }
        if ($nullEncontrado) {
            return false;
        } else {
            return true;
        }
    }

    function saveStatus($status, $id_reembolso)
    {
        foreach ($id_reembolso as $key => $value) {
            $id_reembolso = $value;
        }
        $this->modelo->setTable('reembolso');

        $param_save_rem_status['status'] = $status;
        $param_save_rem_status['alterado_por'] = $this->userdata->id;
        $param_save_rem_status['alterado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');

        $save_status = $this->modelo->save($param_save_rem_status, $id_reembolso);
        if ($save_status) {
            return true;
        } else {
            return false;
        }
    }
}
