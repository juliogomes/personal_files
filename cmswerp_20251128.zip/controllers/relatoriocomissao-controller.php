<?php
/**
 * User: caio.freitas
 * Date: 07/11/2022
 * Time: 11:38
 */
class RelatorioComissaoController extends MainController{       
    protected 
        $id_user,
        $obj_notificacao,
        $session;
    function __construct ($parametros = null, $nome_modulo, $do_login = true){
        $this->setModulo('relatoriocomissao');
        $this->setView('relatoriocomissao');		
        parent::__construct($parametros, $nome_modulo, $do_login = true);         
        $this->id_user 	        = $_SESSION['cmswerp']['userdata']->id;
        $this->session          = json_decode($_SESSION['cmswerp']['userdata']->permissoes);
        $this->obj_notificacao  = new Notificacoes($this);	
    }

    //VIEW
    function index(){
        $user_comissao = json_decode($this->modelo->getUserComissao(null,null,null,null,'nome'));
        $periodo_ate   = $this->data_hora_atual->format('t/m/Y');       
        $periodo_de    = $this->data_hora_atual->format('01/01/Y');
        
        if(isset($_POST['periodo_de']) && !empty($_POST['periodo_de'])){
            $periodo_de = $_POST['periodo_de'];
            $dt_ini     = convertDate($_POST['periodo_de']);
        }else{
            $dt_ini     = convertDate($periodo_de);
        }
        if(isset($_POST['periodo_ate']) && !empty($_POST['periodo_ate'])){
            $periodo_ate = $_POST['periodo_ate'];
            $dt_fim      = convertDate($_POST['periodo_ate']);
        }else{
            $dt_fim     = convertDate($periodo_ate);
        }
        if(isset($_POST['comissionado']) && !empty($_POST['comissionado'])){
            $id_comissionado = $_POST['comissionado'];
        }else{
            $id_comissionado = null;
        }  
        
        if(isset($_POST['cliente']) && !empty($_POST['cliente'])){
            $id_contrato = $_POST['cliente'];
        }else{
            $id_contrato = null;
        }  

        if(isset($_POST['status_nota']) && !empty($_POST['status_nota'])){
            $status_nota = $_POST['status_nota'];
        }else{
            $status_nota = null;
        }
       
       
        $get_contratos_nota = json_decode($this->modelo->getNota($status_nota, $dt_ini, $dt_fim));               
        if(isset($get_contratos_nota) && is_array($get_contratos_nota)){           
            foreach ($get_contratos_nota as $key => $value) {      
                $explode_cliente                   = explode(" ", $value->cliente);    
                $cliente_view[$value->id_contrato] = $explode_cliente[0]." ".$explode_cliente[1];
            }           
        }  
              
        $get_notas = json_decode($this->modelo->getNota($status_nota, $dt_ini, $dt_fim, $id_comissionado, $id_contrato));               
        if(isset($get_notas) && is_array($get_notas)){           
            foreach ($get_notas as $key => $value) {                
                $explode_nome                                                 = explode(" ", $value->nome);  
                $explode_cliente                                              = explode(" ", $value->cliente);    
                $explode_produto                                              = explode(" ", $value->nome_produto);  
                $nome_comercial[$value->id_nota][$value->id_comissao_usuario] = strtoupper($explode_nome[0])." ".strtoupper($explode_nome[1]);
                $produto[$value->id_nota]                                     = $explode_produto[0];
                $cliente[$value->id_nota]                                     = $explode_cliente[0]." ".$explode_cliente[1];
               
                $periodo_corte[$value->id_nota]                               = $this->periodoCorte($value);                           
                $id_user_comissao[]                                           = $value->id_comissao_usuario;
                $numero_comissao[$value->id_nota]                             = $this->numeroComissao($value);                

                $comissao_progressiva[$value->id_nota][$value->id_comissao_usuario] = $this->calculoComissaoProgressiva($value->id_comissao_usuario,$value->if_contrato);
                if($numero_comissao[$value->id_nota] == "ENCERRADO"){
                    $comissao[$value->id_nota][$value->id_comissao]     = 0;
                }else{
                    $comissao[$value->id_nota][$value->id_comissao]     = $this->calculoComissao($value->valor_liquido,  $comissao_progressiva[$value->id_nota][$value->id_comissao_usuario]);  
                }   
                            
                $comissao[$value->id_nota][$value->id_comissao_usuario] = $this->formataComissao($value->id_nota,$value->id_comissao_usuario);   
                $notas[$value->id_nota]->id_comissao = $id_user_comissao;  
                
                if($value->tipo == "I" || $value->tipo == "M" || $value->tipo == "A"){
                    $comissao_view[$value->id_nota] = $periodo_corte[$value->id_nota];
                }else{
                    $comissao_view[$value->id_nota] = $numero_comissao[$value->id_nota];
                }                

                if($value->status == 'recebido'){
                    $value->status = "<b style='color:green'>".$value->status."</b>";
                }else if($value->status == 'receber'){
                    $value->status = "<b style='color:#DDA520'>".$value->status."</b>";
                }else{
                    $value->status = "<b>".$value->status."</b>";
                }

                if(strtoupper($value->tipo) == 'A'){
                    $value->tipo = "FATURAMENTO";
                }else if(strtoupper($value->tipo) == 'I'){
                    $value->tipo = "IMPLANTAÇÃO";
                }else if(strtoupper($value->tipo) == "M"){
                    $value->tipo = "MANUAL";
                }                    
            }              
            $status = $this->statusComissao($notas);  
        }  
        
                
        // $comissao[$value->id_nota][$value->id_comissao_usuario]['status']
                                                          
        require_once ABSPATH.'/views/'.$this->nome_view.'/index-view.php';
    }   
    //VIEW
    function comissionados(){   
        if(isset($this->parametros[0]) && !empty($this->parametros[0])){
            $id_contrato = $this->parametros[0];
        }     
        if(isset($this->parametros[1]) && !empty($this->parametros[1])){
            $id_nota = $this->parametros[1];
        }
        if(isset($this->parametros[2]) && !empty($this->parametros[2])){
            $id_comissao_usuario = $this->parametros[2];
        }

                      
        $if_contratos = json_decode($this->modelo->getContratoMinutaProdutoNota($id_contrato, $id_nota, null));          
        if(isset($if_contratos) && !empty($if_contratos)){                   
            $comissionados      = json_decode($this->modelo->allComissao($if_contratos[0]->id,null,$id_comissao_usuario));             
            $comissao_pagamento = json_decode($this->modelo->getComissoesPagamento($if_contratos[0]->id_nota));
            if(isset($comissionados) && !empty($comissionados)){
                if(isset($comissao_pagamento) && !empty($comissao_pagamento)){                    
                    $status_comissao = $this->statusComissionado($comissionados,$comissao_pagamento);                   
                }
            }                                   
        }             
      
        $mes_recebido  = strtoupper(returMesData($if_contratos[0]->recebido_em));         
        $valor_comissao = $this->calculaComissao($comissionados, $if_contratos[0]->valor_liquido);        
        require_once ABSPATH.'/views/'.$this->nome_view.'/comissionados-view.php';       
    }
    //VIEW
    function analitico(){
        $user_comissao = json_decode($this->modelo->getUserComissao());
       
        $periodo_ate   = $this->data_hora_atual->format('Y-m-d');
        $periodo_de    = $this->data_hora_atual->modify('-1 month');
        $periodo_de    = $periodo_de->format('Y-m-d');
        
        if(isset($_POST['periodo_de']) && !empty($_POST['periodo_de'])){
            $periodo_de = convertDate($_POST['periodo_de']);
        }
        if(isset($_POST['periodo_ate']) && !empty($_POST['periodo_ate'])){
            $periodo_ate = convertDate($_POST['periodo_ate']);
        }
        if(isset($_POST['comissionado']) && !empty($_POST['comissionado'])){
            $id_comissionado = $_POST['comissionado'];
        }

        $analitico_comissao   = json_decode($this->modelo->getNotaContratoComissao());
        $comissao_implantacao = $this->calculaImplantacao($analitico_comissao);
        
        require_once ABSPATH.'/views/'.$this->nome_view.'/analitico-view.php';
    }
    //VIEW
    function carteira(){
        $user_comercial = json_decode($this->modelo->getUserComissao('ativo','CLOSER'));        
        $carteira       = json_decode($this->modelo->getCarteira());      
                
        require_once ABSPATH.'/views/'.$this->nome_view.'/carteira-view.php';
    }
    //VIEW
    function detalhe(){        
        
        if(isset($this->parametros[0]) && !empty($this->parametros[0])){
            $id = $this->parametros[0];        
            $dados_carteira = json_decode($this->modelo->getCarteira($id));           
            $id_comissao_user = $dados_carteira[0]->id_comissao_usuario;          
        }

        $carteira_contrato = json_decode($this->modelo->getCarteiraContrato(null, true));             
        foreach ($carteira_contrato as $key => $value){            
            if(isset($value->contrato_carteira) && !empty($value->contrato_carteira) && isset($value->id_carteira) && $value->id_carteira == $id && $value->deleted_carteira != 1){
                $data_vencimento                 = getDataAtual($value->data_assinatura);                
                $data_vencimento->modify("+$value->duracao_contrato month"); 
                $vencimento_contrato[$value->id] = $data_vencimento->format('d/m/Y');
                $detalhe_carteira[]              = $value;                     
            }         
            if($value->codigo != "ADM0001"){               
                $cliente[$value->cnpj] = $value;
                if($value->id_carteira && $value->id_carteira == $id){
                    $contratos[] = $value->contrato_carteira;
                }
            }
        }                    

        if(isset($_POST['ano']) && !empty($_POST['ano'])){
            $ano = $_POST['ano'];
        }else{
            $obj_data = getDataAtual();
            $obj_data->modify('-1 year');
            $ano      = $obj_data->format('Y');            
        }        
        
        $dt_ini = $ano.'-01-01';
        $dt_fim = $ano.'-12-31';        
        
        if(isset($contratos) && !empty($contratos)){
            $tarifacoes = json_decode($this->modelo->getTarifacoesPorContrato($dt_ini, $dt_fim, $contratos));              
            if($tarifacoes){
                foreach ($tarifacoes as $key => $value) {
                    $totalizador['total']['total_transacoes']   += $value->total_transacoes;
                    $totalizador['contratos'][$value->id]['transacoes']         = $value->total_transacoes;
                    $totalizador['contratos'][$value->id]['cliente_transacoes'] = $value->razao_social;
                }
            }
        }    

        $media_transacoes = $this->mediaTransacoes($totalizador['total']['total_transacoes'],12);               
        $last_transacao = json_decode($this->modelo->lastTransacao($id, $ano));
        if(isset($last_transacao) && !empty($last_transacao)){
            $data = explode(" ",$last_transacao[0]->alterado_em);         
            $ultima_atualizacao  = convertDate($data[0])." ".$data[1];
        }      
                 
        require_once ABSPATH.'/views/'.$this->nome_view.'/detalhe-carteira-view.php';
    }
    //VIEW
    function dashBoardCarteira(){
            
        if($this->session->modulos->Sales->{1}->alcadas < 4){
            $carteiras = json_decode($this->modelo->getCarteira(null,$this->id_user)); 
        }else{
            $carteiras = json_decode($this->modelo->getCarteira()); 
        }  
        
        $ano_fixado = $this->data_hora_atual->format('Y') - 1;
        $fixado = json_decode($this->modelo->getHistorico(null,$ano_fixado,'fixado'));
        if(isset($fixado) && is_array($fixado)){
            foreach ($fixado as $key => $value) {
                 $carteira_fixado[$value->id_carteira] = $value;
            }
        }       
      
        $dashboard             = $this->dashboardTransacoes($carteiras, $ano, "mediaAnual");
        $totalizador           = $this->dashboardTransacoes($carteiras, $ano, "hoje");
        if($this->session->modulos->Sales->{1}->alcadas < 4){
            $totalizador_anterior  = $this->dashboardTransacoes($carteiras, $ano, "ultimo_fechado"); 
        }else{
            $totalizador_anterior  = $this->dashboardTransacoes($carteiras, $ano, "ultimo");  
        }   
      
        $style = array(
            0 => 'background-color:#2874A6;border:solid 2px;border-color:#D6EAF8;border-radius:20px 20px 20px 20px;',
            1 => 'background-color:#b46767;border:solid 2px; border-color:#D5F5E3;border-radius:20px 20px 20px 20px;',
            2 => 'background-color:#00df70;border:solid 2px;border-color:#D5F5E3;border-radius:20px 20px 20px 20px;',
            3 => 'background-color:#b564b7;border:solid 2px;border-color:#D5F5E3;border-radius:20px 20px 20px 20px;',
            4 => 'background-color:#ff8040;border:solid 2px; border-color:#D6EAF8;border-radius:20px 20px 20px 20px;',
            5 => 'background-color:#D4AC0D;border:solid 2px; border-color:#F4D03F;border-radius:20px 20px 20px 20px;',
            6 => 'background-color:#23cfb6;border:solid 2px;border-color:#D5F5E3;border-radius:20px 20px 20px 20px;',
            7 => 'background-color:#9e96a7;border:solid 2px;border-color:#D5F5E3;border-radius:20px 20px 20px 20px;',
        ); 
        $style1 = array(
            0 => 'background-color:#2874A6;border:solid 2px;border-color:#D6EAF8;border-radius:0px 0px 20px 20px;',
            1 => 'background-color:#b46767;border:solid 2px; border-color:#D5F5E3;border-radius:0px 0px 20px 20px;',
            2 => 'background-color:#00df70;border:solid 2px;border-color:#D5F5E3;border-radius:0px 0px 20px 20px;',
            3 => 'background-color:#b564b7;border:solid 2px;border-color:#D5F5E3;border-radius:0px 0px 20px 20px;',
            4 => 'background-color:#ff8040;border:solid 2px; border-color:#D6EAF8;border-radius:0px 0px 20px 20px;',
            5 => 'background-color:#D4AC0D;border:solid 2px; border-color:#F4D03F;border-radius:0px 0px 20px 20px;',
            6 => 'background-color:#23cfb6;border:solid 2px;border-color:#D5F5E3;border-radius:0px 0px 20px 20px;',
            7 => 'background-color:#9e96a7;border:solid 2px;border-color:#D5F5E3;border-radius:0px 0px 20px 20px;',
        ); 
        $style2 = array(
            0 => 'background-color:#2874A6;border:solid 2px;border-color:#D6EAF8;border-radius:20px 20px 0px 0px;',
            1 => 'background-color:#b46767;border:solid 2px; border-color:#D5F5E3;border-radius:20px 20px 0px 0px;',
            2 => 'background-color:#00df70;border:solid 2px;border-color:#D5F5E3;border-radius:20px 20px 0px 0px;',
            3 => 'background-color:#b564b7;border:solid 2px;border-color:#D5F5E3;border-radius:20px 20px 0px 0px;',
            4 => 'background-color:#ff8040;border:solid 2px; border-color:#D6EAF8;border-radius:20px 20px 0px 0px;',
            5 => 'background-color:#D4AC0D;border:solid 2px; border-color:#F4D03F;border-radius:20px 20px 0px 0px;',
            6 => 'background-color:#23cfb6;border:solid 2px;border-color:#D5F5E3;border-radius:20px 20px 0px 0px;',
            7 => 'background-color:#9e96a7;border:solid 2px;border-color:#D5F5E3;border-radius:20px 20px 0px 0px;',
        );      
      
        require_once ABSPATH.'/views/'.$this->nome_view.'/dashboard-carteira-view.php';
    }    
    //VIEW
    function carteiraDetalhada(){
        try{
             
            if($this->session->modulos->Sales->{1}->alcadas < 4){
                $carteiras = json_decode($this->modelo->getCarteira($this->parametros[0],$this->id_user));               
                if(!isset($carteiras) || empty($carteiras)){
                    $retorno['codigo']   = 1;                   
                    $retorno['mensagem'] = "Sem alçada pra acessar essa carteira";
                    throw new Exception (json_encode($retorno), 1);	
                }
            }
            
            
            
            
            if(isset($_POST['ano'])){
                $ano = $_POST['ano'];
            }else{
                $ano = $this->data_hora_atual->format('Y');
            }              
                     
            if(isset($this->parametros[0]) && !empty($this->parametros[0])){
                $id_carteira = $this->parametros[0];
                $carteira = json_decode($this->modelo->getCarteira($id_carteira));
                if(!isset($carteira) || empty($carteira)){
                    $retorno['codigo']   = 1;                   
                    $retorno['mensagem'] = "Erro ao obter carteira";
                    throw new Exception (json_encode($retorno), 1);	
                }
                
                $carteira_fixado[$id_carteira] = json_decode($this->modelo->getHistorico($id_carteira,$ano_fixado,'fixado'));      
            
                $detalhe_carteira   = json_decode($this->modelo->getCarteiraContrato(null,null,null,$id_carteira));
                $dados_carteira     = json_decode($this->modelo->getCarteira($id_carteira)); 
                $totalizador        = $this->dashboardTransacoes($dados_carteira,$ano);
                $totalizador_hoje   = $this->dashboardTransacoes($dados_carteira,$ano,"hoje");
                $totalizador_ultimo = $this->dashboardTransacoes($dados_carteira,$ano,"mediaAnual");           
                             
                $percentual[$id_carteira] = $this->percentual($totalizador_hoje[$id_carteira]['total']['total_transacoes'], $carteira_fixado[$id_carteira][0]->transacoes);                
                if(isset($detalhe_carteira) && !empty($detalhe_carteira)){
                    foreach ($detalhe_carteira as $key => $value) {
                       $detalhe_percentual[$value->id] = $this->percentual($totalizador_hoje[$id_carteira]['contratos'][$value->id]['transacoes'],str_replace(".","",$this->mediaTransacoes($totalizador_ultimo[$id_carteira]['contratos'][$value->id]['transacoes'],12)));                      
                    }
                }      

                $comissao_progressiva = json_decode($this->modelo->comissoesProgressiva($id_carteira));   
                if(isset($comissao_progressiva) && is_array($comissao_progressiva)){
                    $comissoa_default     = json_decode($this->modelo->getUserComissao(null,null,$carteira[0]->id_comissao_usuario));
                    $comissao_mes['2023'][1] = $comissoa_default[0];
                    foreach ($comissao_progressiva as $key => $value) {                        
                        $comissao_mes[$value->ano][$value->mes] = $value;
                    }
                }                 
                $mes = returMes();               
            }             
                 
            require_once ABSPATH.'/views/'.$this->nome_view.'/carteira-detalhada-view.php';
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }
    //VIEW CONSOLIDADO
    function consolidado(){
        $periodo_ate   = $this->data_hora_atual->format('t/m/Y');       
        $periodo_de    = $this->data_hora_atual->format('01/01/Y');
        $user_comissao = json_decode($this->modelo->getUserComissao(null,null,null,null,'nome'));
        $view_ano = returAnos();
        $view_mes = returMes(2);

        if(isset($_POST['periodo_de']) && !empty($_POST['periodo_de'])){
            $periodo_de = $_POST['periodo_de'];
            $dt_ini     = convertDate($_POST['periodo_de']);
        }else{
            $dt_ini     = convertDate($periodo_de);
        }
        if(isset($_POST['periodo_ate']) && !empty($_POST['periodo_ate'])){
            $periodo_ate = $_POST['periodo_ate'];
            $dt_fim      = convertDate($_POST['periodo_ate']);
        }else{
            $dt_fim     = convertDate($periodo_ate);
        }

        if(isset($_POST['comissionado']) && !empty($_POST['comissionado'])){
            $comissionado     = $_POST['comissionado'];           
        }else{
            $comissionado     = null;
        }        
        
       
        $consolidado = json_decode($this->modelo->getNota("recebido",$dt_ini, $dt_fim,$comissionado,null,"recebido"));   
        // echo '<pre>';
        //     var_dump($consolidado);
        // echo '</pre>';       
        // $consolidado = json_decode($this->modelo->notaComissaoPagamento(null, $comissionado, "recebido", $dt_ini, $dt_fim));         
        if(isset($consolidado) && !empty($consolidado)){
            foreach ($consolidado as $key => $value) { 
                $comissao_progressiva[$value->id_nota][$value->id_comissao_usuario] = $this->calculoComissaoProgressiva($value->id_comissao_usuario,$value->if_contrato);                                      
                $valor_comissao[$value->id_nota][$value->id_comissao_usuario]       = $this->calculoComissao($value->valor_liquido, $comissao_progressiva[$value->id_nota][$value->id_comissao_usuario]);                    
                $acumulado[$value->id_usuario]->nome                = $value->nome;  
                $acumulado[$value->id_usuario]->total_valor_liquido +=  $value->valor_liquido; 
                $acumulado[$value->id_usuario]->total_comissao      +=  str_replace(",",".",funcValor($valor_comissao[$value->id_nota][$value->id_comissao_usuario],"C",2));     
                $pagamento_comissao[$value->id_nota][$value->id_comissao_usuario] = json_decode($this->modelo->getComissoesPagamento($value->id_nota,$value->id_comissao_usuario));  
            }
        }    

        require_once ABSPATH.'/views/'.$this->nome_view.'/consolidado-view.php';
    }

    function getComissionados(){
        try{            
            if(isset($this->parametros[0]) && !empty($this->parametros[0])){
                $id_contrato = $this->parametros[0];
            }    
                                
            $if_contratos = json_decode($this->modelo->getContratoMinutaProdutoNota($id_contrato));  
            if(!isset($if_contratos) || empty($if_contratos)){                
                $retorno['codigo']   = 1;
				$retorno['input']    = $this->parametros;
				$retorno['output']   = null;
				$retorno['mensagem'] = "Contrato antigo, sem minuta e comissionados cadastrados";
				throw new Exception (json_encode($retorno), 1);	
            }else{
                $comissionados = json_decode($this->modelo->allComissao($if_contratos[0]->id));   
                if(!isset($comissionados) || empty($comissionados)){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $this->parametros;
                    $retorno['output']   = null;
                    $retorno['mensagem'] = "Erro ao obter comissionados";
                    throw new Exception (json_encode($retorno), 1);	
                }else{
                    $retorno['codigo']   = 0;
                    $retorno['input']    = $this->parametros;
                    $retorno['output']   = $if_contratos;
                    $retorno['mensagem'] = "Sucesso";
                    throw new Exception (json_encode($retorno), 1);
                }	
            }            
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    function calculaComissao($comissionados,$valor_liquido){
        if(isset($comissionados) && is_array($comissionados)){
            foreach ($comissionados as $key => $value) {
                $x = $valor_liquido * $value->percentual;
                $y = $x / 100;
                $comissao[$value->id] = funcValor($y,"C",2); 
            }
        }
        if(isset($comissao)){            
            return $comissao;
        }
    }

    function alterarStatus(){
        try{
            if(isset($this->parametros[0]) && !empty($this->parametros[0])){
                $insert["id_comissao"] = $this->parametros[0];
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $insert;
                $retorno['mensagem'] = "Erro id comissão";
                throw new Exception (json_encode($retorno), 1);
            }
            if(isset($this->parametros[1]) && !empty($this->parametros[1])){
                $insert["id_nota"] = $this->parametros[2];
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $insert;
                $retorno['mensagem'] = "Erro id nota";
                throw new Exception (json_encode($retorno), 1);
            }
            if(isset($this->parametros[2]) && !empty($this->parametros[2])){
                $insert["status"] = $this->parametros[1];
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $insert;
                $retorno['mensagem'] = "Erro status";
                throw new Exception (json_encode($retorno), 1);
            }
           
            if(isset($_POST["observacao"]) && !empty($_POST["observacao"])){
                $insert["observacao"] = $_POST["observacao"];
            }else{
                $insert["observacao"] = null;
            }      
           
            date_default_timezone_set('America/Bahia');
            $data_pagamento = getDataAtual(); 
            $insert['data_pagamento'] = $data_pagamento->format("Y-m-d H:i:s");          
           
            $comissao_pagamento = json_decode($this->modelo->getComissoesPagamento($insert["id_nota"],$insert["id_comissao"]));
            if(isset($comissao_pagamento) && !empty($comissao_pagamento)){
                $id_comissao_pagamento    = $comissao_pagamento[0]->id;
                if($comissao_pagamento[0]->status == "pago"){
                    $insert['data_pagamento'] = $comissao_pagamento[0]->data_pagamento;
                }                
            } 
                                             
            $this->modelo->setTable("comissoes_pagamento");
            $save = $this->modelo->save($insert,$id_comissao_pagamento);
            if($save){
                $retorno['codigo']   = 0;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $insert;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception (json_encode($retorno), 1);
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $this->modelo->info;
                $retorno['mensagem'] = "Erro em salvar comissoes pagamento";
                throw new Exception (json_encode($retorno), 1);
            } 

        }catch(Exception $e){   
            echo $e->getMessage();
        }
    }

    function getObservacao(){
        try{          
            if(isset($this->parametros[0]) && !empty($this->parametros[0])){
                $id_comissao = $this->parametros[0];
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro parametros id_comissao_pagamento";
                throw new Exception (json_encode($retorno), 1);
            }
            $get_comissao = json_decode($this->modelo->getComissoesPagamento(null,null,$id_comissao));
            if(!isset($get_comissao) && !empty($get_comissao)){
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $get_comissao;
                $retorno['mensagem'] = "Erro em obter comissão de pagamento";
                throw new Exception (json_encode($retorno), 1);
            }else{
                $retorno['codigo']   = 0;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $get_comissao;
                $retorno['mensagem'] = $get_comissao[0]->observacao;
                throw new Exception (json_encode($retorno), 1);
            }
        }catch(Exception $e){   
            echo $e->getMessage();
        }
    }

    function statusComissao($notas = null){          
        if(isset($notas) && is_array($notas)){
            foreach ($notas as $key => $value_nota) {                
                $if_contratos = json_decode($this->modelo->getContratoMinutaProdutoNota($value_nota->id));                
                if(isset($if_contratos) && !empty($if_contratos)){                       
                    $status_comissao = json_decode($this->modelo->getComissaoPagamentoFull($if_contratos[0]->id, $value_nota->id_nota));                    
                    if(isset($status_comissao) && is_array($status_comissao)){ 
                        $status[$value_nota->id] = true;                       
                        foreach ($status_comissao as $key => $value_comissao) {                           
                            if(empty($value_comissao->status) || $value_comissao->status != "pago"){
                                $status[$value_nota->id] = false;                               
                            }
                        }                       
                    }
                }                
            }            
        }
        return $status;
    }

    function statusComissionado($comissionados, $comissao_pagamento){
        if(isset($comissionados) && !empty($comissionados)){
            if(isset($comissao_pagamento) && !empty($comissao_pagamento)){             
                foreach ($comissionados as $key_comissionado => $value_comissionado) {
                    foreach ($comissao_pagamento as $key_pagamento => $value_pagamento) {
                        if($value_comissionado->id == $value_pagamento->id_comissao){
                            $value_pagamento->data_pagamento = convertDate(returnPeriodo($value_pagamento->data_pagamento))." ".returnPeriodo($value_pagamento->data_pagamento,"hora");    
                            $value_pagamento->alterado_em = convertDate(returnPeriodo($value_pagamento->alterado_em))." ".returnPeriodo($value_pagamento->alterado_em,"hora");                             
                            $status_comissao[$value_pagamento->id_comissao] = $value_pagamento;
                            if($value_pagamento->status == "pago"){
                                $status_comissao[$value_pagamento->id_comissao]->button = "<button class='btn btn-success btn-xs'><b>PAGO</b> <i class='fa fa-check'></i></button>"; 
                            }else if($value_pagamento->status == "isento"){
                                $status_comissao[$value_pagamento->id_comissao]->button = "<button class='btn btn-danger btn-xs'><b>ISENTO</b> <i class='fa fa-ban'></i></button>";
                            }else{
                                $status_comissao[$value_pagamento->id_comissao]->button = "<button class='btn btn-warning btn-xs'><b>PENDENTE</b> <i class='fa fa-warning'></i></button>";
                            }                                                          
                        }
                    }
                }
            }               
        }  
        return $status_comissao;
    }

    function calculaImplantacao($analitico_comissao){
        if(isset($analitico_comissao) && is_array($analitico_comissao)){
            foreach ($analitico_comissao as $key => $value) {
                $percentual  = str_replace("%","",$value->percentual);
                $implantacao = $value->implantacao;
                $x = $percentual * $implantacao;
                $y = $x / 100;
                $comissao[$value->id_contrato][$value->id_comissao_usuario] = funcValor($y,"C",2);
            }
        }  
        return $comissao;      
    }

    function addComercial(){
        try{
            if(isset($this->parametros[0]) && !empty($this->parametros[0])){
                $id_comercial = $this->parametros[0];
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $id_comercial;
                $retorno['mensagem'] = "Erro id comissao";
                throw new Exception (json_encode($retorno), 1);
            }

            $get_user_comissao = json_decode($this->modelo->getComissaoUser($id_comercial));
            if(!isset($get_user_comissao) || empty($get_user_comissao)){
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $id_comercial;
                $retorno['mensagem'] = "Erro ao obter comissao usuário";
                throw new Exception (json_encode($retorno), 1);
            }else{
                foreach ($get_user_comissao as $key => $value) {
                    $nome_user = explode(" ",strtoupper($value->nome_usuario));
                    $insert['nome_carteira']       = "CARTEIRA ".$nome_user[0]." ".$nome_user[1];
                    $insert['id_comissao_usuario'] = $value->id;
                    $insert['id_usuario']          = $value->id_usuario;
                    $insert['nome_usuario']        = $nome_user[0]." ".$nome_user[1];
                }                
            }

            $this->modelo->setTable("carteira_cadastro");
            $save = $this->modelo->save($insert);
            if($save){
                $retorno['codigo']   = 0;
                $retorno['input']    = $insert;
                $retorno['output']   = $save;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception (json_encode($retorno), 1);
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $insert;
                $retorno['output']   = $this->modelo->info;
                $retorno['mensagem'] = "Erro ao salvar no BD";
                throw new Exception (json_encode($retorno), 1);
            }           
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    function getContrato(){
        try{
            if(isset($this->parametros[0]) && !empty($this->parametros[0])){
                $cnpj = $this->parametros[0];
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro paramêtros";
                throw new Exception (json_encode($retorno), 1);
            }
            
            $contratos = json_decode($this->modelo->getCarteiraContrato(null, true, $cnpj));          
            if(isset($contratos) && !empty($contratos)){
                $retorno['codigo']   = 0;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $contratos;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception (json_encode($retorno), 1);
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $id_produto;
                $retorno['mensagem'] = "Nenhum contrato desse produto encontrado";
                throw new Exception (json_encode($retorno), 1);
            }
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    function addContrato(){
        try{
            if(isset($this->parametros[0]) && !empty($this->parametros[0])){
                $id_carteira           = $this->parametros[0];
                $insert['id_carteira'] = $id_carteira;
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro paramêtros[0]";
                throw new Exception (json_encode($retorno), 1);
            }
            if(isset($this->parametros[1]) && !empty($this->parametros[1])){
                $cnpj           = $this->parametros[1];  
                $insert['cnpj'] = $cnpj;              
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro paramêtros[1]";
                throw new Exception (json_encode($retorno), 1);
            }
           
            $contrato = json_decode($this->modelo->getContrato(null, $cnpj));         
            if(!isset($contrato) || empty($contrato)){
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $contrato;
                $retorno['mensagem'] = "Erro em obter contrato";
                throw new Exception (json_encode($retorno), 1);
            }
                     
            $carteira_contrato = json_decode($this->modelo->getContratoCarteira(null,$id_carteira,$cnpj));           
            if(isset($carteira_contrato) && !empty($carteira_contrato) && $carteira_contrato[0]->deleted == 0){
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $carteira_contrato;
                $retorno['mensagem'] = "Contrato já adicionado nesta carteira";
                throw new Exception (json_encode($retorno), 1);
            }           
                      
            $this->modelo->setTable("carteira_contratos");
            foreach ($contrato as $key => $value) {
                if($value->codigo != "ADM0001"){
                    $carteira_contrato_id = json_decode($this->modelo->getContratoCarteira($value->id));                            
                    $insert['id_contrato'] = $value->id;
                    $insert['deleted']     = '0';
                    $save                  = $this->modelo->save($insert,$carteira_contrato_id[0]->id);
                    if(!$save){
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $this->parametros;
                        $retorno['output']   = $this->modelo->info;
                        $retorno['mensagem'] = "Erro em salvar no banco de dados";
                        throw new Exception (json_encode($retorno), 1);
                    }
                }                
            }         
           
            $retorno['codigo']   = 0;
            $retorno['input']    = $this->parametros;
            $retorno['output']   = $contrato;
            $retorno['mensagem'] = "Sucesso";
            throw new Exception (json_encode($retorno), 1);                   
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    function deletarContratoCarteira(){
        try{
            if(isset($this->parametros[0]) && !empty($this->parametros[0])){
                $id_carteira = $this->parametros[0];
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro paramêtros[0]";
                throw new Exception (json_encode($retorno), 1);
            }
            if(isset($this->parametros[1]) && !empty($this->parametros[1])){
                $id_contrato = $this->parametros[1];               
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro paramêtros[1]";
                throw new Exception (json_encode($retorno), 1);
            }

            $carteira_contrato = json_decode($this->modelo->getContratoCarteira($id_contrato,$id_carteira));
            if(!isset($carteira_contrato) || empty($carteira_contrato)){
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $carteira_contrato;
                $retorno['mensagem'] = "Erro em obter carteira contrato para excluir";
                throw new Exception (json_encode($retorno), 1);
            }else{
                $insert['deleted'] = '1';
            }
          
            $this->modelo->setTable("carteira_contratos");
            $update = $this->modelo->save($insert,$carteira_contrato[0]->id);
            if($update){
                $retorno['codigo']   = 0;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $update;
                $retorno['mensagem'] = "Sucesso em deletar contrato da carteira";
                throw new Exception (json_encode($retorno), 1);
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $this->modelo->info;
                $retorno['mensagem'] = "Erro em excluir contrato da carteira";
                throw new Exception (json_encode($retorno), 1);
            } 
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    function salvarTransacoes(){
        try{
          
            switch ($_POST['acao']) {
                case 'fixar':
                case 'FIXAR':
                    $email       = trim($_POST['email_aprovacao']);
                    $email_array = explode('@', $email);
                    if(isset($email_array[1]) && !empty($email_array[1])){
                        $email = trim($_POST['email_aprovacao']);
                    }else{
                        $email = trim($email_array[0]).DOMINIO_EMAIL;
                    }

                    if(!isset($_POST['email_aprovacao']) || empty($_POST['email_aprovacao'])){
                        $retorno['codigo']      = 1;
                        $retorno['status']      = 'warning';
                        $retorno['input']       = $_POST;
                        $retorno['output']      = null;
                        $retorno['mensagem']    = "Informe a o email";
                        throw new Exception(json_encode($retorno));
                    }

                    if(!filter_var($email, FILTER_SANITIZE_EMAIL)){
                        $retorno['codigo']      = 1;
                        $retorno['status']      = 'warning';
                        $retorno['input']       = $_POST;
                        $retorno['output']      = null;
                        $retorno['mensagem']    = "Email informado invalido";
                        throw new Exception(json_encode($retorno));
                    }

                    if(!isset($_POST['senha_aprovacao']) || empty($_POST['senha_aprovacao'])){
                        $retorno['codigo']      = 1;
                        $retorno['status']      = 'warning';
                        $retorno['input']       = $_POST;
                        $retorno['output']      = null;
                        $retorno['mensagem']    = "Informe a senha";
                        throw new Exception(json_encode($retorno));
                    }
                    $usuario = json_decode($this->user_model->getUserByEmail($email));
                    if($usuario){
                        if(md5($_POST['senha_aprovacao']) != $usuario->senha){                        
                            $retorno['codigo']   = 1;
                            $retorno['input']    = $this->parametros;
                            $retorno['output']   = $_POST;
                            $retorno['mensagem'] = "Senha inválida";
                            throw new Exception (json_encode($retorno), 1);
                        }
                        $permissoes = json_decode($usuario->permissoes);
                        if($permissoes){
                            $permitido = false;
                            foreach ($permissoes->modulos as $key => $value) {
                                if(( $value->nome == 'Carteiras'|| $value->nome == 'Criação de carteira') && $value->permissoes == 4){
                                    $permitido = true;                                   
                                    $insert['status'] = 'fixado';
                                }
                            }
                            if($permitido != true){                              
                                $retorno['codigo']   = 1;
                                $retorno['input']    = $this->parametros;
                                $retorno['output']   = $_POST;
                                $retorno['mensagem'] = "Sem permissão para essa ação";
                                throw new Exception (json_encode($retorno), 1);
                            }                            
                        }else{                            
                            $retorno['codigo']   = 1;
                            $retorno['input']    = $this->parametros;
                            $retorno['output']   = $_POST;
                            $retorno['mensagem'] = "Permissoes não encontrada";
                            throw new Exception (json_encode($retorno), 1);
                        }
                    }else{                       
                        $retorno['codigo']   = 1;
                        $retorno['input']    = $this->parametros;
                        $retorno['output']   = $_POST;
                        $retorno['mensagem'] = "Usuário nao encontrado";
                        throw new Exception (json_encode($retorno), 1);
                    }
                break;
                case 'salvar':
                case 'SALVAR':
                    $insert['status'] = 'salvo';                    
                break;
            }   
            
                                  
            if(isset($_POST['carteira']) && !empty($_POST['carteira'])){                
                $insert['id_carteira'] = $_POST['carteira'];
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $_POST;
                $retorno['mensagem'] = "Erro parametros id_carteira";
                throw new Exception (json_encode($retorno), 1);
            }
            if(isset($_POST['transacoes']) && !empty($_POST['transacoes'])){                
                $insert['transacoes'] = str_replace(".","",$_POST['transacoes']);
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro paramêtros transacoes";
                throw new Exception (json_encode($retorno), 1);
            }
            if(isset($_POST['mes']) && !empty($_POST['ano'])){               
                $insert['ano'] = $_POST['ano'];
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro paramêtros ano";
                throw new Exception (json_encode($retorno), 1);
            }

            if(!isset($insert['status']) || empty($insert['status'])){                
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro paramêtros status";
                throw new Exception (json_encode($retorno), 1);
            }else{
                if($insert['status'] == "salvo"){
                    $last_transacao = json_decode($this->modelo->lastTransacao($insert['id_carteira'], $insert['ano']));
                    if(isset($last_transacao) && !empty($last_transacao)){
                        if(strtolower($last_transacao[0]->status) == "fixado"){
                            $retorno['codigo']   = 1;
                            $retorno['input']    = $this->parametros;
                            $retorno['output']   = null;
                            $retorno['mensagem'] = "Print status FIXADO";
                            throw new Exception (json_encode($retorno), 1);
                        }
                    }
                }
            }  
                   

            $this->modelo->setTable("carteira_historico");
            $save = $this->modelo->save($insert);
            if($save){
                $retorno['codigo']   = 0;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $insert;
                $retorno['mensagem'] = "Sucesso";
                throw new Exception (json_encode($retorno), 1);
            }else{
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $this->modelo->info;
                $retorno['mensagem'] = "Erro em salvar informação no BD";
                throw new Exception (json_encode($retorno), 1);
            }         
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    function checkPermissao(){
        try{
            if(!isset($this->id_user) || empty($this->id_user)){
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $this->id_user;
                $retorno['mensagem'] = "Erro de permissão (id_user)";
                throw new Exception (json_encode($retorno), 1);
            }
            $permissao_perfil = json_decode($this->modelo->usuarioPerfil($this->id_user));
            if(!isset($permissao_perfil) || empty($permissao_perfil)){
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $this->id_user;
                $retorno['mensagem'] = "Permissão perfil não encontrado";
                throw new Exception (json_encode($retorno), 1);
            }
          
            if($permissao_perfil[0]->nome_perfil != "CEO"){               
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = $this->id_user;
                $retorno['mensagem'] = "Sem permissão para essa ação!";
                throw new Exception (json_encode($retorno), 1);   
            }         
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    function mediaTransacoes($transacoes, $meses, $format = true){
        $media = $transacoes / $meses;    
        if($format === true){
            return funcValor($media,'C',0);
        }
    }

    function dashboardTransacoes($carteiras, $ano, $tipo){
        if(isset($tipo) && !empty($tipo)){
            switch ($tipo) {
                case 'hoje':
                    if(isset($ano)){
                        $dia     = $this->data_hora_atual->format('d');
                        $mes     = $this->data_hora_atual->format('m');                    
                        $dt_ini =   $ano."-".$mes."-"."01";
                        $dt_fim  =  $ano."-".$mes."-".$dia;
                    }else{
                        $dia     = $this->data_hora_atual->format('d');
                        $mes     = $this->data_hora_atual->format('m');
                        $ano     = $this->data_hora_atual->format('Y');                   
                        $dt_ini =   $ano."-".$mes."-"."01";   
                        $dt_fim  =  $ano."-".$mes."-".$dia;                 
                    }  
                    break;
                case 'ultimo':
                    if(isset($ano)){
                        $ano    = $ano - 1;
                        $dia    = $this->data_hora_atual->format('d');
                        $dt_fim = $ano."-12-".$dia;
                        $dt_ini = $ano."-12-01";
                    }else{
                        $ano    = $this->data_hora_atual->format('Y');
                        $dia    = $this->data_hora_atual->format('d');
                        $ano    = $ano - 1;
                        $dt_fim = $ano."-12-".$dia;
                        $dt_ini= $ano."-12-01";
                    }
                    break;
                case 'atual':
                    if(isset($ano)){
                        $dia     = $this->data_hora_atual->format('d');
                        $mes     = $this->data_hora_atual->format('m');                    
                        $dt_ini =   $ano."-01-"."01";
                        $dt_fim  =  $ano."-".$mes."-".$dia;
                    }else{
                        $dia     = $this->data_hora_atual->format('d');
                        $mes     = $this->data_hora_atual->format('m');
                        $ano     = $this->data_hora_atual->format('Y');                   
                        $dt_ini =   $ano."-01-"."01"; 
                        $dt_fim  =  $ano."-".$mes."-".$dia;                 
                    }
                break;
                case 'anterior':
                    if(isset($ano)){
                        $dia     = $this->data_hora_atual->format('d');
                        $mes     = $this->data_hora_atual->format('m'); 
                        $ano     = $ano - 1;                   
                        $dt_ini  = $ano."-01-"."01";
                        $dt_fim  = $ano."-".$mes."-".$dia;
                    }else{
                        $dia     = $this->data_hora_atual->format('d');
                        $mes     = $this->data_hora_atual->format('m');
                        $ano     = $this->data_hora_atual->format('Y');   
                        $ano     = $ano - 1;           
                        $dt_ini  = $ano."-01-"."01"; 
                        $dt_fim  = $ano."-".$mes."-".$dia;                 
                    }
                break;
                case 'mediaAnual':
                    $dt_ini = getDataAtual();
                    $dt_ini->modify('first day of january');
                    $dt_ini->modify('-1 year');
                    
                    $dt_fim = clone $dt_ini;
                    $dt_fim->modify('last day of december');
                    
                    $dt_ini  = $dt_ini->format('Y-m-d');
                    $dt_fim  = $dt_fim->format('Y-m-d');

                break;
                case 'ultimo_fechado':
                    $ano     = $this->data_hora_atual->format('Y') - 1;
                    $dt_ini =   $ano."-12-01";
                    $dt_fim  =  $ano."-12-31";
                    break;
                case 'mes_anterior':
                    $data = getDataAtual();
                    $data->modify('-1 month');
                    $dt_ini = $data->format('Y-m')."-01";
                    $data->modify('last day of this month');
                    $dt_fim = $data->format('Y-m-d');
                    break;
                default:
                    # code...
                break;
            }            
        }else{
            if($ano){
                $dt_ini = $ano."-01-01";
                $dt_fim = $ano."-12-31";
            }else{
                $ano = $this->data_hora_atual->format('Y');
                $dt_ini = $ano."-01-01";
                $dt_fim = $ano."-12-31";
            }        
        }   

       
                              
        if(isset($carteiras) && !empty($carteiras)){           
            foreach ($carteiras as $key => $value) {
                $detalhe[$value->id] = json_decode($this->modelo->getCarteiraContrato(null,null,null,$value->id));
                $totalizador[$value->id]['owner'] = $value->nome_carteira;               
                if(isset($detalhe[$value->id]) && !empty($detalhe[$value->id])){
                    foreach ($detalhe[$value->id] as $key => $value_detalhe) {
                        if($value_detalhe->codigo != "ADM0001"){                            
                            if(isset($value_detalhe->id_carteira)){
                                $contratos[$value->id][] = $value_detalhe->contrato_carteira;
                            }
                        }
                    }             
                    if(isset($contratos[$value->id]) && !empty($contratos[$value->id])){                      
                        $tarifacoes = json_decode($this->modelo->getTarifacoesPorContrato($dt_ini, $dt_fim, $contratos[$value->id]));                   
                        if($tarifacoes){                           
                            foreach ($tarifacoes as $key => $value_tarifa) {
                                $totalizador[$value->id]['total']['periodo']                                   = 'DE: '.convertDate($dt_ini).' ATÉ: '.convertDate($dt_fim);
                                $totalizador[$value->id]['total']['total_transacoes']                          += $value_tarifa->total_transacoes;   
                                $totalizador[$value->id]['contratos'][$value_tarifa->id]['transacoes']         = $value_tarifa->total_transacoes;
                                $totalizador[$value->id]['contratos'][$value_tarifa->id]['cliente_transacoes'] = $value_tarifa->razao_social;                                     
                            }
                        }else{
                            $totalizador[$value->id]['total']['periodo']                                   = 'DE: '.convertDate($dt_ini).' ATÉ: '.convertDate($dt_fim);
                            $totalizador[$value->id]['total']['total_transacoes']                          = 0;   
                        }                        
                    }   
                }else{
                    $totalizador[$value->id]['total']['periodo']            = 'DE: '.convertDate($dt_ini).' ATÉ: '.convertDate($dt_fim);
                    $totalizador[$value->id]['total']['total_transacoes']   = 0;   
                    $totalizador[$value->id]['contratos']                   = "CARTEIRA SEM CONTRATOS";
                }                
            }                
            return $totalizador;           
        }else{
            return false;
        }
    }

    function percentual($hoje, $ultimo, $format = true){
        if(!isset($hoje) || empty($hoje)){
            $hoje = 0;
        }
        if(!isset($ultimo) || empty($ultimo)){
            $ultimo = 0;            
        }         
        $x =  $hoje - $ultimo;       
        if($hoje == 0 || $ultimo == 0){            
            $y = $x;            
        }else{
            $x =  $hoje - $ultimo;
            $y =  $x / $ultimo;
            $y =  $y * 100;
        }        
        if($format){
            if($y < 0){
                $retorno['percentual'] = "<b style='color:red;font-size:12px'>".funcValor(str_replace("-","",$y),'C',0)."%</b>";
                $retorno['diferenca']  = "<b style='color:red;font-size:12px'>".funcValor(str_replace("-","",$x),'C',0)."</b>";
            }else{
                if($y == 0){
                    $retorno['percentual'] = "<b style='font-size:12px'>".funcValor(str_replace("-","",$y),'C',0)."%</b>";
                    $retorno['diferenca']  = "<b style='font-size:12px'>".funcValor(str_replace("-","",$x),'C',0)."</b>";
                }else{
                    $retorno['percentual'] = "<b style='color:green;font-size:12px'>".funcValor(str_replace("-","",$y),'C',0)."%</b>";
                    $retorno['diferenca']  = "<b style='color:green;'>".funcValor(str_replace("-","",$x),'C',0)."</b>";
                }
            }
        }else{
            $retorno['percentual'] = funcValor(str_replace("-","",$y),'C',0);
            $retorno['diferenca']  = funcValor(str_replace("-","",$x),'C',0);
        }
        return $retorno;   
    }

    function calculoComissao($implantacao, $percentual, $status){     
      
        $x = $implantacao / 100;
        $y = $x * $percentual;
       
        if(isset($status) && $status != "pago"){
            return 0;
        }else{
            return floatval($y);
        }        
    }

    function periodoCorte($notas){
       
        if(($notas->tipo == "I" || $notas->tipo == "M") && isset($notas->numero_parcela) && isset($notas->parcelas)){
            $periodo_corte = "Parcela: ".$notas->numero_parcela."/".$notas->parcelas;
        }else{                  
            $contratos    = json_decode($this->modelo->getContrato($notas->id_contrato));                  
            $data_emissao = getDataAtual($notas->data_emisao);
            if(isset($contratos) && $contratos[0]->data_corte_faturamento < 10){
                $data_corte_ini = "0".$contratos[0]->data_corte_faturamento;                        
                $data_corte_fim = "0".$contratos[0]->data_corte_faturamento - 1;
            }else{
                $data_corte_ini = $contratos[0]->data_corte_faturamento;
                $data_corte_fim = $contratos[0]->data_corte_faturamento - 1;
            }                   
            $data_fim = $data_corte_fim.$data_emissao->format("/m/Y");
            $data_emissao->modify("-1 month");
            $data_ini = $data_corte_ini.$data_emissao->format("/m/Y");
            $periodo_corte = "DE: ".$data_ini." ATÉ: ".$data_fim;                        
        } 
        return $periodo_corte;
    }

    function formataComissao($id_nota, $id_comissao_usuario){
        $comissao_pagamento = json_decode($this->modelo->getComissoesPagamento($id_nota,$id_comissao_usuario));
        if(isset($comissao_pagamento) && !empty($comissao_pagamento)){
            if($comissao_pagamento[0]->status == "pago"){
                $comissao['status'] = "<button type='button' style='font-size:8px;' class='btn-success btn-xs'><b>PAGO</b></button>";
            }else if($comissao_pagamento[0]->status == "pendente"){
                $comissao['status'] = "<button type='button' style='font-size:8px;' class='btn-warning btn-xs'><b>PENDENTE</b></button>";
            }else if($comissao_pagamento[0]->status == "isento"){
                $comissao['status'] = "<button type='button' style='font-size:8px;' class='btn-danger btn-xs'><b>ISENTO</b></button>";
            }else{
                $comissao['status'] = "<i class='fa fa-ban'></i>";
            }   
            
            if($comissao_pagamento[0]->status == 'pago'){
                $alterado = explode(" ",$comissao_pagamento[0]->data_pagamento);
                $comissao['data_pagamento'] = convertDate($alterado[0]);
            }else{
                $comissao['data_pagamento'] = "<i class='fa fa-ban'></i>";
            }

            if(isset($comissao_pagamento[0]->observacao)){
                $comissao['observacao']  = "<button type='button' class='btn btn-info btn-xs observacao' value='".$comissao_pagamento[0]->id."'>
                    <i class='fa fa-eye'></i> <b style='font-size:8px'>OBS</b>
                </button>";                
            }else{
                $comissao['observacao']  = null;
            }
        }else{
            $comissao['status']      = "<i class='fa fa-ban'></i>";
            $comissao['data_pagamento'] = "<i class='fa fa-ban'></i>";
            $comissao['observacao']  = null;
        }
        return $comissao;
    }

    function numeroComissao($notas){      
        if(strtoupper($notas->tipo) == "A"){
            $obj_assinatura  = getDataAtual($notas->data_assinatura);
            $obj_emissao     = getDataAtual($notas->data_emissao);
            $obj_periodo_ini = getDataAtual($notas->periodo_de);          
            if($obj_assinatura->format('d') <= $notas->faturamento_todo_dia){
                if($obj_assinatura->format('m-Y') == $obj_periodo_ini->format('m-Y')){
                    $numero_comissao = "01/".$notas->meses_validade;
                    return $numero_comissao;
                }else{
                    for ($i=1; $i <= $notas->meses_validade; $i++) { 
                        if($obj_assinatura->format('m-Y') == $obj_periodo_ini->format('m-Y')){
                            $numero = $i;
                            if($numero < 10){
                                $numero = "0".$numero;
                            }
                            $numero_comissao = $numero."/".$notas->meses_validade;
                            return $numero_comissao;
                        } 
                        $obj_assinatura->modify("+1 month");
                    }
                }
            }else{
                for ($i=1; $i <= $notas->meses_validade; $i++) { 
                    if($obj_assinatura->format('m-Y') == $obj_periodo_ini->format('m-Y')){
                        $numero = $i;
                        if($numero < 10){
                            $numero = "0".$numero;
                        }                        
                        $numero_comissao = $numero."/".$notas->meses_validade;
                        return $numero_comissao;
                    }  
                    $obj_assinatura->modify("+1 month");
                }
            }                    
            return "<b style='font-size:7px;color:blue;'>COMISSÃO FINALIZADAA</b>";         
        }   
    }

    function detalheComissao(){
        try{
            if(isset($this->parametros[0]) && !empty($this->parametros[0])){
                $ano_mes = $this->parametros[0];
            }else{
                $retorno['codigo']      = 1;                
                $retorno['input']       = $this->parametros;
                $retorno['output']      = null;
                $retorno['mensagem']    = "Erro paramêtros referência";
                throw new Exception(json_encode($retorno));
            }

            if(isset($this->parametros[1]) && !empty($this->parametros[1])){
                $id_comissao = $this->parametros[1];
            }else{
                $retorno['codigo']      = 1;                
                $retorno['input']       = $this->parametros;
                $retorno['output']      = null;
                $retorno['mensagem']    = "Erro paramêtros id_comissão";
                throw new Exception(json_encode($retorno));
            }

            $data_ini = getDataAtual($ano_mes);
            $data_fim = getDataAtual($ano_mes);
            $data_fim = $data_fim->modify('last day of this month');
                       
            $comissao_contrato = json_decode($this->modelo->notaComissaoContrato(null, $id_comissao, $data_ini->format('Y-m-d'), $data_fim->format('Y-m-d')));                 
            if(!isset($comissao_contrato) || empty($comissao_contrato)){
                $retorno['codigo']      = 1;                
                $retorno['input']       = $this->parametros;
                $retorno['output']      = null;
                $retorno['mensagem']    = "Erro obter detalhes da comissão consolidada";
                throw new Exception(json_encode($retorno));
            }else{     
                foreach ($comissao_contrato as $key => $value) {                
                    $comissao_progressiva[$value->id][$value->id_comissao] = $this->calculoComissaoProgressiva($value->id_comissao,$value->id_if_contrato);     
                }              
                
                $html = $this->gerarHtmlComissao($comissao_contrato,$comissao_progressiva);                  
                $retorno['codigo']      = 0;                
                $retorno['input']       = $comissao_contrato;
                $retorno['output']      = $html;
                $retorno['mensagem']    = "Sucesso";
                throw new Exception(json_encode($retorno));
            }            
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    function gerarHtmlComissao($comissao_contrato,$percentual_comissao){       
        $html = "";
        foreach ($comissao_contrato as $key => $value) {
            $data_ref = explode("-",$value->data_pagamento);
            $html .= "<tr class='tr_comissao' style='text-align:center;font-size:9px;'>";
                $html .= "<td>";
                    $html .= $data_ref[1]."/".$data_ref[0];
                $html .= "</td>";
                $html .= "<td>";
                    $html .= $value->nome;
                $html .= "</td>";
                $html .= "<td>";
                    $html .= $value->numero;
                $html .= "</td>";
                $html .= "<td>";
                    $html .= convertDate($value->data_emissao);
                $html .= "</td>";
                $html .= "<td>";
                    $html .= $value->razao_social;
                $html .= "</td>";
                $html .= "<td>";
                    $html .= funcValor($value->valor_liquido,'C',2);
                $html .= "</td>";
                $html .= "<td>";
                    $html .= $percentual_comissao[$value->id][$value->id_comissao]."%";
                $html .= "</td>";
                $html .= "<td>";
                    $html .= funcValor($this->calculoComissao($value->valor_liquido,$percentual_comissao[$value->id][$value->id_comissao],$value->status),'C',2);
                $html .= "</td>";
                $html .= "<td>";
                    if($value->status == "pago"){
                        $html .= "<button type='button' class='btn btn-success btn-xs' style='font-size:10px;font-weight:bold;'>".strtoupper($value->status)."</button>";
                    }else if($value->status == "pendente"){
                        $html .= "<button type='button' class='btn btn-warning btn-xs' style='font-size:10px;font-weight:bold;'>".strtoupper($value->status)."</button>";
                    }else if($value->status == "isento"){
                        $html .= "<button type='button' class='btn btn-danger btn-xs' style='font-size:10px;font-weight:bold;'>".strtoupper($value->status)."</button>";
                    }else{
                        $html .= strtoupper($value->status);
                    }                    
                $html .= "</td>";
                $html .= "<td>";
                    $html .= $value->observacao;
                $html .= "</td>";
            $html .= "</tr>";
        }
        return $html;
    }

    //By Caio Freitas - 17/01/2022
    function alterarDiversosStatus(){
        try{
            if(!isset($this->parametros[0]) || empty($this->parametros[0])){
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro requisição sem status";
                throw new Exception (json_encode($retorno), 1);
            }else{
                $insert['status']         = $this->parametros[0];
                $insert['data_pagamento'] = $this->data_hora_atual->format('Y-m-d H:i:s');
                $insert['observacao']     = null;
            }

           
            if(!isset($this->parametros[1]) || empty($this->parametros[1])){
                $retorno['codigo']   = 1;
                $retorno['input']    = $this->parametros;
                $retorno['output']   = null;
                $retorno['mensagem'] = "Erro requisição, selecione uma nota";
                throw new Exception (json_encode($retorno), 1);
            }else{
                $nota_check = explode(",",$this->parametros[1]);
            }
                     
            $this->modelo->setTable('comissoes_pagamento');
            foreach ($nota_check as $key => $value) {
                $dados = explode("-",$value);
                $insert['id_nota']     = $dados[0];
                $insert['id_comissao'] = $dados[1];
                $comissao_pagamento = json_decode($this->modelo->getComissoesPagamento($insert["id_nota"],$insert["id_comissao"]));
                if(isset($comissao_pagamento) && !empty($comissao_pagamento)){
                    $id_comissao_pagamento = $comissao_pagamento[0]->id;
                }                 
                $save = $this->modelo->save($insert,$id_comissao_pagamento);
                if(!$save){
                    $retorno['codigo']   = 1;
                    $retorno['input']    = $this->parametros;
                    $retorno['output']   = $this->modelo->info;
                    $retorno['mensagem'] = "Erro em atualizar status nota: ".$insert['nota']." id_comissão: ".$insert['id_comissao'];
                    throw new Exception (json_encode($retorno), 1);
                }                
            }

            $retorno['codigo']   = 0;
            $retorno['input']    = $this->parametros;
            $retorno['output']   = $insert;
            $retorno['mensagem'] = "Sucesso";
            throw new Exception (json_encode($retorno), 1);          
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    //By Caio Freitas - 26/01/2023
    function calculoComissaoProgressiva($user_comissao, $id_contrato){           
        $user_comissionado = json_decode($this->modelo->getComissaoContratoCarteira($user_comissao,$id_contrato));      
        if(isset($user_comissionado) && !empty($user_comissionado)){                
            $data_assinatura = explode("-",$user_comissionado[0]->data_assinatura);
            $comissao_progressiva = json_decode($this->modelo->comissoesProgressiva($user_comissionado[0]->id_carteira,$data_assinatura[0],$data_assinatura[1]));
            if(!isset($comissao_progressiva)){
                $comissao_default = json_decode($this->modelo->comissaoUsuarioPerfil($user_comissao));
                if(isset($comissao_default)){
                    return str_replace("%","",$comissao_default[0]->percentual);
                }else{
                    return 0;
                }                
            }else{
                return $comissao_progressiva[0]->porcentagem_final;                
            }
        }else{
            $comissao_default = json_decode($this->modelo->comissaoUsuarioPerfil($user_comissao));
            if(isset($comissao_default)){
                return str_replace("%","",$comissao_default[0]->percentual);
            }else{
                return 0;
            }    
        }        
    }

     //By Caio Freitas - 03/02/2023
     function referenciaComissao($user_comissao, $id_contrato){           
        $user_comissionado = json_decode($this->modelo->getComissaoContratoCarteira($user_comissao,$id_contrato));      
        if(isset($user_comissionado) && !empty($user_comissionado)){                
            $data_assinatura = explode("-",$user_comissionado[0]->data_assinatura);            
            $comissao_progressiva = json_decode($this->modelo->comissoesProgressiva($user_comissionado[0]->id_carteira,$data_assinatura[0],$data_assinatura[1]));
            if(!isset($comissao_progressiva)){
                $comissao_default = json_decode($this->modelo->comissaoUsuarioPerfil($user_comissao));
                if(isset($comissao_default)){
                    $comissao['percentual'] = str_replace("%","",$comissao_default[0]->percentual);
                    $comissao['referencia'] = "DEFAULT";                    
                }else{
                    $comissao['percentual'] = 0;
                    $comissao['referencia'] = "DEFAULT";                    
                }                
            }else{
                $comissao['percentual'] = $comissao_progressiva[0]->porcentagem_final;
                $comissao['referencia'] = nomeMes($comissao_progressiva[0]->mes); 
            }
        }else{
            $comissao_default = json_decode($this->modelo->comissaoUsuarioPerfil($user_comissao));
            if(isset($comissao_default)){
                $comissao['percentual'] = str_replace("%","",$comissao_default[0]->percentual);
                $comissao['referencia'] = "DEFAULT";
            }else{
                $comissao['percentual'] = 0;
                $comissao['referencia'] = "DEFAULT";
            }    
        }     
        return $comissao;     
    }

    function rotinaProgressiva(){
        // $this->obj_notificacao->alertaTeams('alerta_comissao_progressiva');
        $obj_data = getDataAtual();
        $obj_data->modify('-1 year'); 
        
        
        $fixado = json_decode($this->modelo->getHistorico(null, $obj_data->format('Y'), 'fixado'));        
        if(!isset($fixado) || empty($fixado)){
            $parametros['mensagem'] = 'ERRO ROTINA DE COMISSÃO: Fixado do ano '. $obj_data->format('Y').' não encontrado.';
            $this->obj_notificacao->alertaTeams('erro_comissao_progressiva',$parametros);            
            $retorno['codigo']   = 1;
            $retorno['mensagem'] = $parametros['mensagem'];
        }

        $carteiras = json_decode($this->modelo->getCarteira());      
        $totalizador           = $this->dashboardTransacoes($carteiras, $ano, "mes_anterior");
      
        $data_ref = getDataAtual();
        $data_ref->modify('-1 month');
        $mes = $data_ref->format('m');
        $ano = $data_ref->format('Y');

        foreach ($fixado as $key => $value) {
            if(isset($totalizador[$value->id_carteira]['total']['total_transacoes'])){
                $x                              = $totalizador[$value->id_carteira]['total']['total_transacoes'] - $value->transacoes;
                $y                              = $x / $value->transacoes;
                $resultado[$value->id_carteira] = $y * 100;               
            }             
            $comissao_progressiva = json_decode($this->modelo->comissoesProgressiva($value->id_carteira,$ano,$mes));   
            if(isset($comissao_progressiva) && !empty($comissao_progressiva)){               
                $percentual_ini[$value->id_carteira] = $comissao_progressiva[0]->porcentagem_final;
            }else{
                $comissao_default = json_decode($this->modelo->getUserComissao(null,null,null,$value->id_usuario));                
                if(!isset($comissao_default) || empty($comissao_default)){
                    $parametros['mensagem'] = "ERRO ROTINA DE COMISSÃO: Comissão default do usuário id: ".$value->id_usuario." não encontrado.";
                    $this->obj_notificacao->alertaTeams('erro_comissao_progressiva',$parametros);            
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] = $parametros['mensagem'];
                }else{                                       
                    $percentual_ini[$value->id_carteira]   = str_replace("%","",$comissao_default[0]->percentual);
                }
            }
            
            $x1 = $resultado[$value->id_carteira] * $percentual_ini[$value->id_carteira];
            $x2 = $x1 / 100;    
                                                      
            $percentual_final[$value->id_carteira] = $percentual_ini[$value->id_carteira] + $x2; 
            $calculo[$value->id_carteira] = $x2;
            if($percentual_final[$value->id_carteira] <= 0){
                $percentual_final[$value->id_carteira] = 0;
            }
        }    
      
        if(isset($percentual_final) && is_array($percentual_final)){
            $this->modelo->setTable("comissoes_progressiva");
            foreach ($percentual_final as $key => $value) {
                $comissao_progressiva_atual = json_decode($this->modelo->comissoesProgressiva($key,$this->data_hora_atual->format('Y'),$this->data_hora_atual->format('m')));
                if(!isset($comissao_progressiva_atual)){
                    $insert['id_carteira']         = $key;
                    $insert['ano']                 = $this->data_hora_atual->format('Y');
                    $insert['mes']                 = $this->data_hora_atual->format('m');
                    $insert['transacoes']          = $totalizador[$key]['total']['total_transacoes'];
                    $insert['porcentagem_ini']     = $percentual_ini[$key];
                    $insert['calculo_percentual']  = str_replace(",",".",funcValor($calculo[$key],'C',2));
                    $insert['variacao_percentual'] = str_replace(",",".",funcValor($resultado[$key],'C',2));
                    if($resultado[$key] < 0){
                        $insert['operador'] = "debito";
                    }else if($resultado[$key] == 0){
                        $insert['operador'] = 'igual';
                    }else{
                        $insert['operador'] = 'credito';
                    }
                    $insert['porcentagem_final'] = str_replace(",",".",funcValor($percentual_final[$key],'C',2));   
                    $save = $this->modelo->save($insert);
                    if(!$save){
                        $parametros['mensagem'] = "ERRO ROTINA DE COMISSÃO: ERRo EM SALVAR COMISSÃO PROGRESSIVNO BANCO, INFO: ".json_encode($this->modelo->info);
                        $this->obj_notificacao->alertaTeams('erro_comissao_progressiva',$parametros); 
                        $retorno['codigo'] = 1;
                        $retorno['mensagem'] = $parametros['mensagem'];
                    }                 
                }else{
                    $parametros['mensagem'] = "AVISO COMISSÃO: Comissão da carteira id: ".$key." do mês ".$this->data_hora_atual->format('m')." e ano ".$this->data_hora_atual->format('Y')." já cadastrada.";
                    $this->obj_notificacao->alertaTeams('erro_comissao_progressiva',$parametros);     
                    $retorno['codigo'] = 1; 
                    $retorno['mensagem'] = $parametros['mensagem'];
                }
            }
        }else{
            $parametros['mensagem'] = "ERRO ROTINA DE COMISSÃO: PERCENTUAL FINAL NÃO GERADO";
            $this->obj_notificacao->alertaTeams('erro_comissao_progressiva',$parametros); 
            $retorno['codigo'] = 1;
            $retorno['mensagem'] = $parametros['mensagem'];
        }


        if(isset($retorno) && $retorno['codigo'] == 1){
            $this->obj_notificacao->alertaTeams('erro_comissao_progressiva',$retorno['mensagem']); 
        }else{
            $this->obj_notificacao->alertaTeams('sucesso_rotina'); 
        }
                             
    }

    function comissaoProgressivaDetalhe(){
        try{           
            $ano = $this->data_hora_atual->format('Y');
            if(isset($this->parametros[0]) && !empty($this->parametros[0])){
                $id_carteira = $this->parametros[0];
            }else{
                $retorno['codigo']      = 1;                
                $retorno['input']       = $this->parametros;
                $retorno['output']      = null;
                $retorno['mensagem']    = "Erro paramêtros id_carteira";
                throw new Exception(json_encode($retorno));
            }
            if(isset($this->parametros[1]) && !empty($this->parametros[1])){
                $mes = $this->parametros[1];
            }else{
                $retorno['codigo']      = 1;                
                $retorno['input']       = $this->parametros;
                $retorno['output']      = null;
                $retorno['mensagem']    = "Erro paramêtros mês";
                throw new Exception(json_encode($retorno));
            }            

            $get_comissao_progressiva = json_decode($this->modelo->comissoesProgressiva($id_carteira,$ano,$mes));
            if(!isset($get_comissao_progressiva) || empty($get_comissao_progressiva)){
                $retorno['codigo']      = 1;                
                $retorno['input']       = $this->parametros;
                $retorno['output']      = null;
                $retorno['mensagem']    = "Erro ao encontrar comissão progressiva";
                throw new Exception(json_encode($retorno));
            }else{
                $ano_anterior = $ano - 1;                
                $fixado = json_decode($this->modelo->getHistorico($id_carteira,$ano_anterior,'fixado'));
              
                $html = $this->formatarComissaoProgressiva($get_comissao_progressiva,$fixado[0]->transacoes);
                if($html == false){
                    $retorno['codigo']      = 1;                
                    $retorno['input']       = $get_comissao_progressiva;
                    $retorno['output']      = $html;
                    $retorno['mensagem']    = "Erro ao formatar informação";
                    throw new Exception(json_encode($retorno));
                }else{
                    $retorno['codigo']      = 0;                
                    $retorno['input']       = $this->parametros;
                    $retorno['output']      = $html;
                    $retorno['mensagem']    = "Sucesso";
                    throw new Exception(json_encode($retorno));
                }
            }            

        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    function formatarComissaoProgressiva($comissao,$fixado){        
        $html = "";       
        if(isset($comissao) && is_array($comissao)){
            foreach ($comissao as $key => $value) {
                $html .= "<tr class='tr_comissao_progressiva' style='text-align:center;font-size:11px'>";
                    if(isset($value->nome_usuario) && !empty($value->nome_usuario)){
                        $html .= "<td style='vertical-align:middle;'>";
                            $html .= $value->nome_usuario;
                        $html .= "</td>";
                    }
                    $html .= "<td style='vertical-align:middle;'>";
                        $html .= $value->ano;
                    $html .= "</td>";
                    $html .= "<td style='vertical-align:middle;'>";
                        if(isset($value->mes) && !empty($value->mes)){
                            $html .= strtoupper(nomeMes($value->mes));
                        }else{
                            $html .= "<b style='color:blue;font-size:10px'>DEFAULT</b>";
                        }
                    $html .= "</td>";                   
                    $html .= "<td style='vertical-align:middle;'>";
                        if(isset($value->transacoes) && !empty($value->transacoes)){
                            $html .= funcValor($value->transacoes,'C',0);
                        }else{
                            $html .= " - ";
                        }
                    $html .= "</td>";
                    $html .= "<td style='vertical-align:middle;'>";
                        if(isset($fixado)){
                            $html .= funcValor($fixado,'C',0);
                        }else{
                            $html .= " - ";
                        }
                    $html .= "</td>";
                    $html .= "<td style='vertical-align:middle;'>";
                        if(isset($value->variacao_percentual)){
                            if($value->variacao_percentual > 0){
                                $html .= "<b style='color:green'>".$value->variacao_percentual."%</b>";
                            }else if($value->variacao_percentual < 0){
                                $html .= "<b style='color:red'>".$value->variacao_percentual."%</b>";
                            }else{
                                $html .= "<b>".$value->variacao_percentual."%</b>";
                            }
                        }else{
                            $html .= "<b> - </b>";
                        }
                    $html .= "</td>";
                    $html .= "<td style='vertical-align:middle;'>";
                        if(isset($value->porcentagem_ini) && !empty($value->porcentagem_ini)){
                            if($value->porcentagem_ini > 0){
                                $html .= "<b style='color:green'>".$value->porcentagem_ini."%</b>";
                            }else if($value->porcentagem_ini < 0){
                                $html .= "<b style='color:red'>".$value->porcentagem_ini."%</b>";
                            }else{
                                $html .= "<b>".$value->porcentagem_ini."%</b>";
                            }
                        }else if(isset($value->percentual) && !empty($value->percentual)){
                            if($value->percentual > 0){
                                $html .= "<b style='color:green'>".$value->percentual."</b>";
                            }else if($value->percentual < 0){
                                $html .= "<b style='color:red'>".$value->percentual."</b>";
                            }else{
                                $html .= "<b>".$value->percentual."</b>";
                            }
                        }else{
                            $html .= "<b> - </b>";
                        }
                    $html .= "</td>";               
                    $html .= "<td style='vertical-align:middle;'>";
                        if(isset($value->calculo_percentual) && !empty($value->calculo_percentual)){
                            if($value->calculo_percentual > 0){
                                $html .= "<b style='color:green'>".$value->calculo_percentual."</b>";
                            }else if($value->calculo_percentual < 0){
                                $html .= "<b style='color:red'>".$value->calculo_percentual."</b>";
                            }else{
                                $html .= "<b>".$value->calculo_percentual."</b>";
                            }
                        }else{
                            $html .= "<b> - </b>";
                        }
                    $html .= "</td>";
                    $html .= "<td style='vertical-align:middle;'>";
                        if(isset($value->operador) && !empty($value->operador)){
                            if($value->operador == "debito"){
                                $html .= "<b style='color:red'>".strtoupper($value->operador)."</b>";
                            }else{
                                $html .= "<b style='color:green'>".strtoupper($value->operador)."</b>";
                            }
                        }else{
                            $html .= "<b> - </b>";
                        }
                    $html .= "</td>";
                    $html .= "<td style='vertical-align:middle;'>";
                    if(isset($value->porcentagem_final) && !empty($value->porcentagem_final)){
                        if($value->porcentagem_final > 0){
                            $html .= "<b style='color:green'>".$value->porcentagem_final."%</b>";
                        }else if($value->porcentagem_final < 0){
                            $html .= "<b style='color:red'>".$value->porcentagem_final."%</b>";
                        }else{
                            $html .= "<b>".$value->porcentagem_final."%</b>";
                        }
                    }else if(isset($value->percentual) && !empty($value->percentual)){
                        if($value->percentual > 0){
                            $html .= "<b style='color:green'>".$value->percentual."</b>";
                        }else if($value->percentual < 0){
                            $html .= "<b style='color:red'>".$value->percentual."</b>";
                        }else{
                            $html .= "<b>".$value->percentual."</b>";
                        }
                    }else{
                        $html .= "<b> - </b>";
                    }
                    $html .= "</td>";
                $html .= "</tr>";
            }
            return $html;
        }
        return false;
    }

    function formatarComissaoProgressivaHistorico($comissao,$fixado){        
        $html = "";       
        if(isset($comissao) && is_array($comissao)){
            foreach ($comissao as $key => $value) {
                $html .= "<tr class='tr_comissao_progressiva' style='text-align:center;font-size:11px'>";
                    if(isset($value->nome_usuario) && !empty($value->nome_usuario)){
                        $html .= "<td style='vertical-align:middle;'>";
                            $html .= $value->nome_usuario;
                        $html .= "</td>";
                    }
                    $html .= "<td style='vertical-align:middle;'>";
                        $html .= $value->ano;
                    $html .= "</td>";
                    $html .= "<td style='vertical-align:middle;'>";
                        if(isset($value->mes) && !empty($value->mes)){
                            $html .= strtoupper(nomeMes($value->mes));
                        }else{
                            $html .= "<b style='color:blue;font-size:10px'>DEFAULT</b>";
                        }
                    $html .= "</td>";                   
                    // $html .= "<td style='vertical-align:middle;'>";
                    //     if(isset($value->transacoes) && !empty($value->transacoes)){
                    //         $html .= funcValor($value->transacoes,'C',0);
                    //     }else{
                    //         $html .= " - ";
                    //     }
                    // $html .= "</td>";
                    // $html .= "<td style='vertical-align:middle;'>";
                    //     if(isset($fixado)){
                    //         $html .= funcValor($fixado,'C',0);
                    //     }else{
                    //         $html .= " - ";
                    //     }
                    // $html .= "</td>";
                    // $html .= "<td style='vertical-align:middle;'>";
                    //     if(isset($value->variacao_percentual)){
                    //         if($value->variacao_percentual > 0){
                    //             $html .= "<b style='color:green'>".$value->variacao_percentual."%</b>";
                    //         }else if($value->variacao_percentual < 0){
                    //             $html .= "<b style='color:red'>".$value->variacao_percentual."%</b>";
                    //         }else{
                    //             $html .= "<b>".$value->variacao_percentual."%</b>";
                    //         }
                    //     }else{
                    //         $html .= "<b> - </b>";
                    //     }
                    $html .= "</td>";
                    $html .= "<td style='vertical-align:middle;'>";
                        if(isset($value->porcentagem_ini) && !empty($value->porcentagem_ini)){
                            if($value->porcentagem_ini > 0){
                                $html .= "<b style='color:green'>".$value->porcentagem_ini."%</b>";
                            }else if($value->porcentagem_ini < 0){
                                $html .= "<b style='color:red'>".$value->porcentagem_ini."%</b>";
                            }else{
                                $html .= "<b>".$value->porcentagem_ini."%</b>";
                            }
                        }else if(isset($value->percentual) && !empty($value->percentual)){
                            if($value->percentual > 0){
                                $html .= "<b style='color:green'>".$value->percentual."</b>";
                            }else if($value->percentual < 0){
                                $html .= "<b style='color:red'>".$value->percentual."</b>";
                            }else{
                                $html .= "<b>".$value->percentual."</b>";
                            }
                        }else{
                            $html .= "<b> - </b>";
                        }
                    $html .= "</td>";               
                    $html .= "<td style='vertical-align:middle;'>";
                        if(isset($value->calculo_percentual) && !empty($value->calculo_percentual)){
                            if($value->calculo_percentual > 0){
                                $html .= "<b style='color:green'>".$value->calculo_percentual."</b>";
                            }else if($value->calculo_percentual < 0){
                                $html .= "<b style='color:red'>".$value->calculo_percentual."</b>";
                            }else{
                                $html .= "<b>".$value->calculo_percentual."</b>";
                            }
                        }else{
                            $html .= "<b> - </b>";
                        }
                    $html .= "</td>";
                    $html .= "<td style='vertical-align:middle;'>";
                        if(isset($value->operador) && !empty($value->operador)){
                            if($value->operador == "debito"){
                                $html .= "<b style='color:red'>".strtoupper($value->operador)."</b>";
                            }else{
                                $html .= "<b style='color:green'>".strtoupper($value->operador)."</b>";
                            }
                        }else{
                            $html .= "<b> - </b>";
                        }
                    $html .= "</td>";
                    $html .= "<td style='vertical-align:middle;'>";
                    if(isset($value->porcentagem_final) && !empty($value->porcentagem_final)){
                        if($value->porcentagem_final > 0){
                            $html .= "<b style='color:green'>".$value->porcentagem_final."%</b>";
                        }else if($value->porcentagem_final < 0){
                            $html .= "<b style='color:red'>".$value->porcentagem_final."%</b>";
                        }else{
                            $html .= "<b>".$value->porcentagem_final."%</b>";
                        }
                    }else if(isset($value->percentual) && !empty($value->percentual)){
                        if($value->percentual > 0){
                            $html .= "<b style='color:green'>".$value->percentual."</b>";
                        }else if($value->percentual < 0){
                            $html .= "<b style='color:red'>".$value->percentual."</b>";
                        }else{
                            $html .= "<b>".$value->percentual."</b>";
                        }
                    }else{
                        $html .= "<b> - </b>";
                    }
                    $html .= "</td>";
                $html .= "</tr>";
            }
            return $html;
        }
        return false;
    }    

    function getComissaoHistorico(){
        try{
            $ano = $this->data_hora_atual->format('Y') - 1;
            $get_default = json_decode($this->modelo->getUserComissaoCarteira('CLOSER',$ano,"fixado"));              
            if(isset($get_default) && is_array($get_default)){
                foreach ($get_default as $key => $value) {
                    $value->ano = $ano+1; 
                    $get[]      = $value;                                  
                    $html      .= $this->formatarComissaoProgressivaHistorico($get);     
                    unset($get);               
                }
            }else{
                $retorno['codigo']      = 1;                
                $retorno['input']       = null;
                $retorno['output']      = null;
                $retorno['mensagem']    = "Erro em obter comissão default";
                throw new Exception(json_encode($retorno));
            }            
            $get_historico = json_decode($this->modelo->comissoesProgressivaUser(null,null,null,"nome"));            
            if(isset($get_historico) && is_array($get_historico)){
                foreach ($get_historico as $key => $value) {
                    $historico[]     = $value;
                    $fixado          = json_decode($this->modelo->getHistorico($value->id_carteira));                             
                    $html            .= $this->formatarComissaoProgressivaHistorico($historico,$fixado[0]->transacoes);     
                    unset($historico);               
                }
            }else{
                $retorno['codigo']      = 1;                
                $retorno['input']       = null;
                $retorno['output']      = null;
                $retorno['mensagem']    = "Erro em obter historico de comissoes progressiva";
                throw new Exception(json_encode($retorno));
            } 
                                  
            if(empty($html) || $html == false){
                $retorno['codigo']      = 1;                
                $retorno['input']       = $get_historico;
                $retorno['output']      = $fixado;
                $retorno['mensagem']    = "Erro em formatar informação";
                throw new Exception(json_encode($retorno));
            }else{
                $retorno['codigo']      = 0;                
                $retorno['input']       = $get_historico;
                $retorno['output']      = $html;
                $retorno['mensagem']    = "Sucesso";
                throw new Exception(json_encode($retorno));
            }           
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }

    function detalhePercentual(){
        try{

            if(isset($this->parametros[0]) && !empty($this->parametros[0])){
                $id_user_comissao = $this->parametros[0]; 
            }else{
                $retorno['codigo']      = 1;                
                $retorno['input']       = $this->parametros;
                $retorno['output']      = null;
                $retorno['mensagem']    = "Erro parâmetros id_user_comissão";
                throw new Exception(json_encode($retorno));
            }

            if(isset($this->parametros[1]) && !empty($this->parametros[1])){
                $dt_ini = $this->parametros[1]; 
            }else{
                $retorno['codigo']      = 1;                
                $retorno['input']       = $this->parametros;
                $retorno['output']      = null;
                $retorno['mensagem']    = "Erro parâmetros data_ini";
                throw new Exception(json_encode($retorno));
            }

            if(isset($this->parametros[2]) && !empty($this->parametros[2])){
                $dt_fim = $this->parametros[2]; 
            }else{
                $retorno['codigo']      = 1;                
                $retorno['input']       = $this->parametros;
                $retorno['output']      = null;
                $retorno['mensagem']    = "Erro parâmetros data_fim";
                throw new Exception(json_encode($retorno));
            }

            $contratos = json_decode($this->modelo->notaComissaoPagamento(null, $id_user_comissao, "pago", $dt_ini, $dt_fim)); 
            if(!isset($contratos) || empty($contratos)){
                $retorno['codigo']      = 1;                
                $retorno['input']       = $this->parametros;
                $retorno['output']      = null;
                $retorno['mensagem']    = "Erro em obter comissão pagamento";
                throw new Exception(json_encode($retorno));
            }else{
                $html = "";
                foreach ($contratos as $key => $value) {
                    if($value->status == "pago"){      
                        $comissao = $this->referenciaComissao($value->id_comissao_usuario,$value->id_if_contrato);         
                        $html .= "<tr class='text-center tr_percentual'>";
                            $html .= "<td>";
                                $html .= $value->cliente;
                            $html .= "</td>";
                            $html .= "<td>";
                                $html .= convertDate($value->data_assinatura);
                            $html .= "</td>";
                            $html .= "<td>";
                                $html .= $comissao['percentual']."%";
                            $html .= "</td>";
                            $html .= "<td>";
                                $html .= strtoupper($comissao['referencia']);
                            $html .= "</td>";
                        $html .= "</tr>";
                        
                        $array = explode(" ",$value->nome);
                        $nome  = $array[0]." ".$array[1];

                     
                        // $comissao_progressiva[$value->id][$value->id_comissao]['cliente']         = $value->cliente;
                        // $comissao_progressiva[$value->id][$value->id_comissao]['data_assinatura'] = convertDate($value->data_assinatura);
                        // $comissao_progressiva[$value->id][$value->id_comissao]['percentual']      = $this->calculoComissaoProgressiva($value->id_comissao_usuario,$value->id_if_contrato);                                   
                    }
                }
            }
                      
            if(isset($html) && !empty($html)){
                $retorno['codigo']      = 0;                
                $retorno['input']       = $nome;
                $retorno['output']      = $html;
                $retorno['mensagem']    = "Sucesso";
                throw new Exception(json_encode($retorno));
            }else{
                $retorno['codigo']      = 1;                
                $retorno['input']       = $this->parametros;
                $retorno['output']      = null;
                $retorno['mensagem']    = "Erro em gerar percentual de comissão";
                throw new Exception(json_encode($retorno));
            }           
        }catch(Exception $e){
            echo $e->getMessage();
        }
    }
}
?>