<?php
	ini_set("memory_limit","512M");
	//error_reporting(E_ALL);
	//ini_set("display_errors", 1);
	class ReportController extends MainController{
		protected 
			$meses_fat,
			$mov_controller,
			$faturamento,
			$hoje,
			$class_report;
		public
			$obj_contrato,
			$obj_movimento,
			$obj_cadastros,
			$obj_quotas,
			$obj_despesas,
			$obj_orcamento,
			$obj_nf,
			$obj_report;


		function __construct($parametros){
			$this->setModulo('report');
			$this->setView('report');

			$this->hoje = getDataAtual();
			parent::__construct( $parametros, 'report', false );
			$this->class_report  = new Report( $this );
			$this->obj_contrato  = $this->load_model('contratos/contratos', true);
			$this->obj_cadastros = $this->load_model('cadastros/cadastros', true);
			$this->obj_orcamento = $this->load_model('orcamento/orcamento', true);
			$this->obj_despesas  = $this->load_model('despesas/despesas', true);
			// $this->obj_quotas   = $this->load_model('quotas/quotas', true);
			$this->obj_nf          = $this->load_model('notas-fiscais/notas-fiscais', true);
			$this->obj_report      = $this->load_model('report/report', true);
			
			$db_movimento['db_name'] = DB_NAME_MOVIMENTO;
			$this->mov_controller = new MainController(null, 'tarifador', false);
			$this->obj_movimento  = $this->mov_controller->load_model('movimento/movimento', true);
			$this->obj_movimento->setDb(new Db($db_movimento));
			$this->meses_fat      = json_decode($this->obj_movimento->getMesesFat());
			$this->faturamento    = new Faturamento($this->mov_controller, false);
		}

		function index(){
			//$this->report($this->parametros[1]);
		}

		function Geral(){
			include "config_extras.php";	
			$codigo_cliente = null;
			$codigo_produto = null;
			$codigo_modulo  = null;
			$periodo_de     = null;
			$periodo_ate    = null;
			$produto_model  = $this->load_model('produtos/produtos', true);

			$clientes = json_decode($this->obj_contrato->clientesAtivos());
			
			if(isset($_POST['codigo_cliente']) && !empty($_POST['codigo_cliente'])){
				$codigo_cliente = $_POST['codigo_cliente'];
			}

			if(isset($_POST['codigo_produto']) && !empty($_POST['codigo_produto'])){
				$codigo_produto = $_POST['codigo_produto'];
				if(isset($_POST['codigo_modulo']) && !empty($_POST['codigo_modulo'])){
					$codigo_modulo = $_POST['codigo_modulo'];
				}
				$produtos = json_decode($produto_model->getProdutosPorCliente($codigo_cliente));
				$modulos  = json_decode($produto_model->getProdutoEmodulo($codigo_produto));
			}else{
				$produtos = json_decode($produto_model->getProdutosPorCliente($codigo_cliente));
			}

			if(isset($_POST['periodo_de']) && !empty($_POST['periodo_de'])){
				$periodo_de = new DateTime(convertDate(trim($_POST['periodo_de'])));
			}else{
				$obj_data   = getDataAtual();
				// $obj_data->modify('first day of this month');
				$periodo_de = $obj_data;
			}

			if(isset($_POST['periodo_ate']) && !empty($_POST['periodo_ate'])){
				$periodo_ate = new DateTime(convertDate(trim($_POST['periodo_ate'])));
			}else{
				$periodo_ate = clone($this->data_hora_atual);
			}	
													
			$param['codigo_cliente'] = $codigo_cliente;
			$param['codigo_produto'] = $codigo_produto;
			$param['codigo_modulo']  = $codigo_modulo;
			$param['dt_ini']         = $periodo_de->format('Y-m-d');
			$param['dt_fim']         = $periodo_ate->format('Y-m-d');		
			$dados_extrato 			 = json_decode( $this->obj_movimento->ReportGeral( $param ) );
			require_once ABSPATH . '/views/'.$this->nome_view.'/geral-view.php';
		}

		function faturamento(){
			$codigo_cliente = null;
			$codigo_produto = null;
			$codigo_modulo  = null;
			$periodo_de     = null;
			$periodo_ate    = null;
			$produto_model  = $this->load_model('produtos/produtos', true);
			$clientes = json_decode($this->obj_contrato->clientesAtivos());
			
			if(isset($_POST['codigo_cliente']) && !empty($_POST['codigo_cliente'])){
				$codigo_cliente = $_POST['codigo_cliente'];
			}

			if(isset($_POST['codigo_produto']) && !empty($_POST['codigo_produto'])){
				$codigo_produto = $_POST['codigo_produto'];
				if(isset($_POST['codigo_modulo']) && !empty($_POST['codigo_modulo'])){
					$codigo_modulo = $_POST['codigo_modulo'];
				}
				$produtos = json_decode($produto_model->getProdutosPorCliente($codigo_cliente));
				$modulos  = json_decode($produto_model->getProdutoEmodulo($codigo_produto, $codigo_modulo));

			}else{
				$produtos = json_decode($produto_model->getProdutosPorCliente($codigo_cliente));
			}

			if(isset($_POST['periodo_de']) && !empty($_POST['periodo_de'])){
				$periodo_de = new DateTime(convertDate(trim($_POST['periodo_de'])));
			}else{
				$periodo_de = clone($this->data_hora_atual);
			}

			if(isset($_POST['tipo_data']) && !empty($_POST['tipo_data'])){
				$tipo_data = $_POST['tipo_data'];
			}else{
				$tipo_data = 'data_emissao';
			}

			if(isset($_POST['periodo_de']) && !empty($_POST['periodo_de'])){
				$periodo_de = getDataAtual(convertDate(trim($_POST['periodo_de'])));
			}else{
				$periodo_de = getDataAtual();
			}
			
			if(isset($_POST['periodo_ate']) && !empty($_POST['periodo_ate'])){
				$periodo_ate = getDataAtual(convertDate(trim($_POST['periodo_ate'])));
			}else{
				$periodo_ate = getDataAtual();
			}

			$param['tipo_data']      = $tipo_data;
			$param['codigo_cliente'] = $codigo_cliente;
			$param['codigo_produto'] = $codigo_produto;
			$param['codigo_modulo']  = $codigo_modulo;
			$param['data_de']         = $periodo_de->format('Y-m-d');
			$param['data_ate']         = $periodo_ate->format('Y-m-d');
			
			if(isset($_POST) && !empty($_POST)){
				$notas_fiscais = json_decode($this->obj_nf->getNotaByParametros($param));
				if($notas_fiscais){
					if($codigo_modulo){
						foreach($notas_fiscais as $key => $value){
							$remove = true;
							$faturamento = json_decode($value->faturamento_relacionado);
							foreach ($faturamento as $k1 => $v1){
								foreach ($v1 as $k2 => $v2) {
									if($v2->codigo_modulo == $codigo_modulo){
										$remove = false;
										$notas_fiscais[$key]->codigo_modulo  = $codigo_modulo;
										$notas_fiscais[$key]->valor_liquido  = $v2->impostos->totalizadores->valor_base;
										$notas_fiscais[$key]->valor_fatura   = $v2->impostos->totalizadores->valor_base;
										$notas_fiscais[$key]->valor_impostos = $v2->impostos->totalizadores->{'sem retencao'}->total;
										$notas_fiscais[$key]->valor_total    = $v2->valor_total;
									}
								}
							}
							if($remove){
								unset($notas_fiscais[$key]);
							}
						}
					}
				}
			}
			require_once ABSPATH . '/views/'.$this->nome_view.'/faturamento-view.php';
		}

		function listaMeses(){
			$codigo_cliente = $this->parametros[0];
			if(is_numeric($codigo_cliente)){
				$codigo_produto = $this->parametros[1];
				$lista_meses = $this->obj_movimento->getListaMeses($codigo_cliente, $codigo_produto);
				
				echo $lista_meses;
			}else{
				echo 'Codigo do cliente incorreto, impossivel mostrar os meses!';
			}
		}

		function extratoCliente(){
			//codigo implementado para resolver um problema de relatorio da FORTLEV
			//o cnpj da fortlev está divergente no tarifador em relação ao rocket.
			
			if($this->parametros[0] == '31751050'){
				$codigo_cliente = '10921911';
			}elseif($this->parametros[0] == '04467870'){
				$codigo_cliente = '04088208';
			}elseif($this->parametros[0] == '49502677'){
				$codigo_cliente = '08065557';
			}elseif($this->parametros[0] == '24525055'){
				$codigo_cliente = '31504994';
			}else{
				$codigo_cliente = $this->parametros[0];
			}

			if(is_numeric($codigo_cliente)){
				
				$codigo_produto = $this->parametros[1];
				$contrato = json_decode($this->obj_contrato->getContratosAndProdutos($codigo_cliente, $codigo_produto));
				
				
				if(isset($contrato[0]->data_corte_faturamento) && !empty($contrato[0]->data_corte_faturamento)){
					$data_corte = $contrato[0]->data_corte_faturamento;
				}else{
					$data_corte = '03';
				}

				$periodo = $this->parametros[2];
				
				$obj_date1 = new datetime($periodo.'-'.$data_corte);
				//$obj_date1->add(new DateInterval('P1D'));
				
				$obj_date2 = new datetime($periodo.'-'.$data_corte);
				$obj_date2->add(new DateInterval('P1M'));
				$obj_date2->sub(new DateInterval('P1D'));
				
				$dados_extrato = json_decode($this->obj_movimento->getExtrato($obj_date1->format('Y-m-d'), $obj_date2->format('Y-m-d'), $codigo_cliente, $codigo_produto));
				
				if($dados_extrato){
					$var_string = '{';
					foreach ($dados_extrato as $key => $value) {
						$obj_date = new DateTime($value->data_tarifacao);
						$dados[$key]['codigo_cliente'] = (int)$value->codigo_cliente;
						$dados[$key]['codigo_produto'] = $value->codigo_produto;
						$dados[$key]['nome_produto'] = $value->nome_produto;
						$dados[$key]['codigo_modulo'] = $value->codigo_modulo;
						$dados[$key]['nome_modulo'] = $value->nome_modulo;
						$dados[$key]['data_tarifacao'] = $obj_date->format('d/m/Y');
						$dados[$key]['timestamp_tarifacao'] = (int)strtotime($obj_date->format('Ymd'));
						$dados[$key]['qtd_transacoes'] = (int)$value->qtd_transacoes;
						$dados[$key]['login'] = $value->login;
						$dados[$key]['codigo_cliente'] = $value->codigo_cliente;
					}
				}
				echo json_encode($dados, JSON_UNESCAPED_SLASHES);
			}else{
				echo 'Codigo do cliente incorreto, use apenas numeros';
			}
		}

		function extratoLP(){
			$nome_modulo = null;
			//var_dump('aqui');
			//codigo implementado para resolver um problema de relatorio da FORTLEV
			//o cnpj da fortlev está divergente no tarifador em relação ao rocket.
			//gambiarra
			if($this->parametros[0] == '31751050'){//FORTLEV
				$codigo_cliente = '10921911';
				$codigo_produto = $this->parametros[1];
			}elseif($this->parametros[0] == '04467870'){//
				$codigo_cliente = '04088208';
				$codigo_produto = $this->parametros[1];
			}elseif($this->parametros[0] == '49502677'){//tecnisa
				$codigo_cliente = '08065557';
				$codigo_produto = $this->parametros[1];
			}elseif($this->parametros[0] == '24525055'){//QUASAR FLASH FOMENTO MERCANTIL LTDA
				$codigo_cliente = '31504994';
				$codigo_produto = $this->parametros[1];
			}elseif($this->parametros[0] == '04814563'){//04814563
				$codigo_cliente = $this->parametros[0];
				$codigo_produto = 'SOE0001';
			}/*elseif($this->parametros[0] == '61820817' && $this->parametros[1] != 'SPB0001'){//SOCOPA / BANCO PAULISTA
				$codigo_cliente = '62285390';
				$codigo_produto = $this->parametros[1];
			}*/else{
				$codigo_cliente = $this->parametros[0];
				$codigo_produto = $this->parametros[1];
			}
			
			if(is_numeric($codigo_cliente)){
				switch ($codigo_produto) {
					case 'SPB0001':
					case 'SOE0001':
					case 'FSP0001':
					case 'SPI0001':
						$codigo_produto = array('SPB0001', 'SOE0001', 'FSP0001', 'SPI0001');
					break;
				}

				$contrato = json_decode($this->obj_contrato->getContratosAndProdutos($codigo_cliente, $codigo_produto, true));

				if($contrato){
					$lista_preco = json_decode($this->obj_contrato->getListaPrecoCodigoCliente($contrato[0]->id_contrato, $codigo_produto));
				}

				if(isset($contrato[0]->data_corte_faturamento) && !empty($contrato[0]->data_corte_faturamento)){
					$data_corte = $contrato[0]->data_corte_faturamento;
				}else{
					$data_corte = '03';
				}

				// var_dump($data_corte);
				// exit;

				$periodo = $this->parametros[2];
				$obj_date1 = new datetime($periodo.'-'.$data_corte);
				//$obj_date1->add(new DateInterval('P1D'));
				$obj_date2 = new datetime($periodo.'-'.$data_corte);
				$obj_date2->add(new DateInterval('P1M'));
				$obj_date2->sub(new DateInterval('P1D'));

				$dados_extrato = json_decode($this->obj_movimento->getExtrato($obj_date1->format('Y-m-d'), $obj_date2->format('Y-m-d'), $codigo_cliente, $codigo_produto));

				// if($dados_extrato){
				// 	foreach($dados_extrato as $key => $value){
				// 		$dados['extrato'][] = $value;
				// 	}	
				// }	
				
				if($lista_preco){
					foreach($lista_preco as $key => $value){
						$id_contrato = $value->id_contrato;
						unset($value->id_contrato);
						if($nome_modulo != $value->nome_modulo){
							$k = $key;
							$nome_modulo = $value->nome_modulo; 
							$lp[$k]['codigo_modulo'] = $value->codigo_modulo;
							$lp[$k]['nome_modulo'] 	 = $value->nome_modulo;
							unset($value->codigo_modulo);
							unset($value->nome_modulo);
							$lp[$k]['faixas'][] = $value;
						}else{
							unset($value->codigo_modulo);
							unset($value->nome_modulo);
							$lp[$k]['faixas'][] = $value;
						}
					}
					foreach($lp as $key => $value){
						$lp_final[] = $value;		
					}
				}
				if($dados_extrato){
					$var_string = '{';
					foreach ($dados_extrato as $key => $value) {
						$obj_date = new DateTime($value->data_tarifacao);
						$dados['extrato'][$key]['codigo_cliente'] = (int)$value->codigo_cliente;
						$dados['extrato'][$key]['codigo_produto'] = $value->codigo_produto;
						$dados['extrato'][$key]['nome_produto'] = $value->nome_produto;
						$dados['extrato'][$key]['codigo_modulo'] = $value->codigo_modulo;
						$dados['extrato'][$key]['nome_modulo'] = $value->nome_modulo;
						$dados['extrato'][$key]['data_tarifacao'] = $obj_date->format('d/m/Y');
						$dados['extrato'][$key]['timestamp_tarifacao'] = (int)strtotime($obj_date->format('Ymd'));
						$dados['extrato'][$key]['qtd_transacoes'] = (int)$value->qtd_transacoes;
						$dados['extrato'][$key]['login'] = $value->login;
						$dados['extrato'][$key]['codigo_cliente'] = $value->codigo_cliente;
					}
				}
				$dados['lista_preco'] = $lp_final;
				header('Content-Type: application/json');
				echo json_encode($dados, JSON_UNESCAPED_SLASHES);
			}else{
				echo 'Codigo do cliente incorreto, impossivel mostrar lista de preços!';
			}
		}

		function extratoByPeriodo(){
		
			$codigo_cliente = $this->parametros[0];
			$codigo_produto = $this->parametros[1];
			$dt_ini         = $this->parametros[2];
			$dt_fim         = $this->parametros[3];
		
			echo $this->obj_movimento->getExtrato($dt_ini, $dt_fim, $codigo_cliente, $codigo_produto);
		}

		function extratoComercial(){
			$string    = null;
			$upselling = null;
			$cliente   = null;
			$produto   = null;
			if(isset($this->parametros[1])){
				$obj_dt_ini = new DateTime($this->parametros[1]);
				$dt_ini = $obj_dt_ini->format('Y-m-d');
			}else{
				$dt_ini = null;
			}

			if(isset($this->parametros[2])){
				$obj_dt_fim = new DateTime($this->parametros[2]);
				$dt_fim = $obj_dt_fim->format('Y-m-d');
			}else{
				$dt_fim = null;
			}

			if(isset($this->parametros[3]) && !empty($this->parametros[3])){
				$cliente = $this->parametros[3];
			}

			if(isset($this->parametros[4]) && !empty($this->parametros[4])){
				$produto = $this->parametros[4];
			}

			if($this->parametros[0] == 'todos'){
				$result = json_decode($this->obj_movimento->getMovPorComercial(null, $dt_ini, $dt_fim, $cliente, $produto));
				if($result){
					foreach ($result as $key => $value) {
						$movimento[] = $value;
					}
				}
			}elseif($this->parametros[0] == 'upselling'){
				$contratos = json_decode($this->obj_cadastros->getComissionadosPorContrato(null, null, $upselling));
				if($contratos){
					foreach ($contratos as $key => $value){
						$array_ids[]  = $value->id_contrato;
					}
					$result = json_decode($this->obj_movimento->getMovPorComercial(null, $dt_ini, $dt_fim, $cliente, $produto));
					if($result){
						foreach ($result as $key => $value) {
							$movimento[] = $value;
						}
					}
				}
			}else{
				$vendedor = json_decode($this->obj_cadastros->getVendedoresByEmail($this->parametros[0].'@cmsw.com'));
				$quota    = json_decode($this->obj_quotas->getQuotasByAnoEvendedor(null, $vendedor[0]->id, 'up Selling'));
				
				if($quota){
					$upselling = true;
				}

				if($vendedor){
					$contratos = json_decode($this->obj_cadastros->getComissionadosPorContrato($vendedor[0]->id, $vendedor[0]->cargo, $upselling));
					if($contratos){
						foreach ($contratos as $key => $value){
							$array_ids[]  = $value->id_contrato;
						}
						$result = json_decode($this->obj_movimento->getMovPorComercial($array_ids, $dt_ini, $dt_fim, $cliente, $produto));
						if($result){
							foreach ($result as $key => $value) {
								$movimento[] = $value;
							}
						}
					}
				}
			}

			$string->data = $movimento;
			echo json_encode($string);
		}

		function DashBoard(){
			switch ($this->parametros[0]) {
				case '1':
					$this->dashBoardUm();
				break;
				case '2':
					$this->dashBoardDois();
				break;
				case '3':
					$this->dashBoardTres();
				break;
				case '4':
					$this->dashBoardQuatro();
				break;
				case '5':
					$this->DashBoardCinco();
				break;
				default:
					echo 'DashBoard Invalido';
				break;
			}
		}

		function DashBoardUm(){
			if($_SESSION['cmswerp']['userdata']->nome_perfil != 'CEO' && $_SESSION['cmswerp']['userdata']->nome_perfil != 'SYSTEM ADMIN'){
				header('location: /login/index');
				exit;
			}

			$tabela = null;
			$header = null;	
			// $_POST['ano_atual'] = 2020;
			if( isset($_POST['ano_atual']) && !empty($_POST['ano_atual']) && is_numeric($_POST['ano_atual']) ){
				$data_atual = $_POST['ano_atual'].'-'.$this->data_hora_atual->format('m-d');
				$data_atual = getDataAtual($data_atual);
			}else{
				$data_atual = clone $this->data_hora_atual;
			}

			$last_12m_atual  = clone($data_atual);
			$last_12m_atual->sub(new DateInterval('P11M'));
			$last_12m_atual->modify('first day of this month');

			$last_12m_anterior  = clone($data_atual);
			$last_12m_anterior->sub(new DateInterval('P12M'));
			$last_12m_anterior->modify('first day of this month');

			$dia_atual = clone($data_atual);
			$mes_atual_ini = clone($data_atual);
			$mes_atual_ini->modify('first day of this month');
			$mes_atual_fim = clone($data_atual);
			$mes_atual_fim->modify('last day of this month');

			$anoatual_ini = clone($data_atual);
			$anoatual_ini->modify('first day of January');
			$anoatual_fim = clone($data_atual);
			$anoatual_fim->modify('last day of December');

			$dia_mes_ant = clone($data_atual);
			$dia_mes_ant->modify('-1 month');
			$mes_ant_ini = clone($dia_mes_ant);
			$mes_ant_ini->modify('first day of this month');
			$mes_ant_fim = clone($dia_mes_ant);
			$mes_ant_fim->modify('last day of this month');
			$despesas_pagas_anterior = null;

			$tr_diaria_atual     = json_decode($this->obj_movimento->getMovPeriodoResume($mes_atual_ini->format('Y-m-d'), $dia_atual->format('Y-m-d')));
			$tr_diaria_anterior  = json_decode($this->obj_movimento->getMovPeriodoResume($mes_ant_ini->format('Y-m-d'), $dia_mes_ant->format('Y-m-d')));
			
			$tr_media_atual    = ($tr_diaria_atual[0]->qtd_transacoes / $dia_atual->format('d'));
			$tr_media_anterior = ($tr_diaria_anterior[0]->qtd_transacoes / $dia_mes_ant->format('d'));

			$desp_pagas_atual    = json_decode($this->obj_despesas->getDespesasAnoResume($mes_atual_ini->format('Y-m-d'), $mes_atual_fim->format('Y-m-d'), 'pago', null, 'pagamento'));
			$desp_pagas_anterior = json_decode($this->obj_despesas->getDespesasAnoResume($mes_ant_ini->format('Y-m-d'), $mes_ant_fim->format('Y-m-d'), 'pago', null, 'pagamento'));

			$desp_abertas_atual    = json_decode($this->obj_despesas->getDespesasAnoResume($mes_atual_ini->format('Y-m-d'), $mes_atual_fim->format('Y-m-d'), 'aberto', null, 'vencimento'));
			$desp_abertas_anterior = json_decode($this->obj_despesas->getDespesasAnoResume($mes_ant_ini->format('Y-m-d'), $mes_ant_fim->format('Y-m-d'), 'aberto', null, 'vencimento'));
				
			$despesas_pagas_atual    = ($desp_pagas_atual[0]->valor_total + $desp_pagas_atual[0]->atmon_total + $desp_pagas_atual[0]->juros_total + $desp_pagas_atual[0]->multa_total + $desp_pagas_atual[0]->outros_total - $desp_pagas_atual[0]->desconto_total - $desp_pagas_atual[0]->abatimento_total);
			$despesas_pagas_anterior = ($desp_pagas_anterior[0]->valor_total + $desp_pagas_anterior[0]->atmon_total + $desp_pagas_anterior[0]->juros_total + $desp_pagas_anterior[0]->multa_total + $desp_pagas_anterior[0]->outros_total - $desp_pagas_anterior[0]->desconto_total - $desp_pagas_anterior[0]->abatimento_total);

			$despesas_aberta_atual    = null;
			$despesas_aberta_anterior = null;

			if($desp_abertas_atual){
				$despesas_aberta_atual = ($desp_abertas_atual[0]->valor_total + $desp_abertas_atual[0]->atmon_total + $desp_abertas_atual[0]->juros_total + $desp_abertas_atual[0]->multa_total + $desp_abertas_atual[0]->outros_total - $desp_abertas_atual[0]->desconto_total - $desp_abertas_atual[0]->abatimento_total);
			}

			if($despesas_aberta_anterior){
				$despesas_aberta_anterior = ($desp_abertas_anterior[0]->valor_total + $desp_abertas_anterior[0]->atmon_total + $desp_abertas_anterior[0]->juros_total + $desp_abertas_anterior[0]->multa_total + $desp_abertas_anterior[0]->outros_total - $desp_abertas_anterior[0]->desconto_total - $desp_abertas_anterior[0]->abatimento_total);
			}

			$fat_emitido_atual     = json_decode($this->obj_nf->getNotaResumeGroup('emissao', $mes_atual_ini->format('Y-m-d'), $dia_atual->format('Y-m-d')));
			$fat_emitido_anterior  = json_decode($this->obj_nf->getNotaResumeGroup('emissao', $mes_ant_ini->format('Y-m-d'), $dia_mes_ant->format('Y-m-d')));

			$fat_recebido_atual    = json_decode($this->obj_nf->getNotaResumeGroup('recebimento', $mes_atual_ini->format('Y-m-d'), $mes_atual_fim->format('Y-m-d')));
			$fat_recebido_anterior = json_decode($this->obj_nf->getNotaResumeGroup('recebimento', $mes_ant_ini->format('Y-m-d'), $mes_ant_fim->format('Y-m-d')));
		
			$lucro_mensal_atual    = ($fat_recebido_atual[0]->total_fatura - $despesas_pagas_atual);
			$lucro_mensal_anterior = ($fat_recebido_anterior[0]->total_fatura - $despesas_pagas_anterior);

			$ticket_medio_atual     = ($fat_emitido_atual[0]->total_fatura / $tr_diaria_atual[0]->qtd_transacoes);
			$ticket_medio_anterior  = ($fat_emitido_anterior[0]->total_fatura / $tr_diaria_anterior[0]->qtd_transacoes);

			// bloco de calculos anuais

			$desp_anual_atual     = json_decode($this->obj_despesas->getSomaDespesaByPeriodo($last_12m_atual->format('Y-m-d'), $mes_atual_fim->format('Y-m-d'), 'pago', null, 'pagamento'));
			$desp_anual_anterior  = json_decode($this->obj_despesas->getSomaDespesaByPeriodo($last_12m_anterior->format('Y-m-d'), $mes_ant_fim->format('Y-m-d'), 'pago', null, 'pagamento'));

			$despesas_anual_atual    = ($desp_anual_atual[0]->valor_total + $desp_anual_atual[0]->atmon_total + $desp_anual_atual[0]->juros_total + $desp_anual_atual[0]->multa_total + $desp_anual_atual[0]->outros_total - $desp_anual_atual[0]->desconto_total - $desp_anual_atual[0]->abatimento_total);
			$despesas_anual_anterior = ($desp_anual_anterior[0]->valor_total + $desp_anual_anterior[0]->atmon_total + $desp_anual_anterior[0]->juros_total + $desp_anual_anterior[0]->multa_total + $desp_anual_anterior[0]->outros_total - $desp_anual_anterior[0]->desconto_total - $desp_anual_anterior[0]->abatimento_total);
			
			$fat_anual_atual    = json_decode($this->obj_nf->getNotaResume('recebimento', $last_12m_atual->format('Y-m-d'), $mes_atual_fim->format('Y-m-d'), 'recebido'));
			$fat_anual_anterior = json_decode($this->obj_nf->getNotaResume('recebimento', $last_12m_anterior->format('Y-m-d'), $mes_ant_fim->format('Y-m-d'), 'recebido'));

			$lucro_anual_atual    = ($fat_anual_atual[0]->total_fatura - $despesas_anual_atual);
			$lucro_anual_anterior = ($fat_anual_anterior[0]->total_fatura - $despesas_anual_anterior);

			// Total de transações por produtos
			$transacoes_produtos = json_decode($this->obj_movimento->getMovPeriodoResumeByProduto($anoatual_ini->format('Y-m-d'), $anoatual_fim->format('Y-m-d')));
			// v13 OK
			// Total de transações por produto, OBS: todos produtos SPB serão igual a PIX
			// começo bloco de produtos
			if($transacoes_produtos){
				$arrayProdutos = null;
				foreach($transacoes_produtos as $key => $value) {
					$id11 = nomeMes($value->mes);
					switch ($value->codigo_produto) {
						case 'FSP0001':
						case 'SOE0001':
						case 'SPB0001':
						case 'SPI0001':
						case 'SPBALL':
							$p1 = 'CORNER PIX';
							$o1 = 4;
						break;
						case 'RCK0001':
							$p1 = $value->codigo_produto;
							$o1 = 2;
						break;
						case 'ATF0001':
							$p1 = $value->codigo_produto;
							$o1 = 1;
						break;
						default:
							$p1 = $value->codigo_produto;
							$o1 = 5;
						break;
					}
					$arrayProdutos[$o1][$p1][$id11] += $value->qtd_transacoes;
				}
			}

			$dados_mov_aux = json_decode($this->obj_nf->getTotalNFPorProdutoResume($periodo_ini, $periodo_fim, 'ECS0001'));
			if($dados_mov_aux){
				foreach($dados_mov_aux as $key => $value) {
					$i1 = nomeMes($value->mes);
					$i2 = $value->codigo_produto;
					$o1 = 3;
					$arrayProdutos[$o1][$i2][$i1] = $value->transacoes;
				}
			}
			ksort($arrayProdutos);
			$tab_atual['linhas']['j013'] = $arrayProdutos;
			ksort($tab_atual['linhas']);
			// var_dump($tab_atual['linhas']);
			// var_dump($tab_atual['linhas']['j013']);
			if(isset($tab_atual['linhas']['j013']) && count($tab_atual['linhas']['j013']) > 0){
				$str      = null;
				$nm       = null;
				$dados    = null;
				$total    = null;
				$totais   = null;
				$leg      = null;
				$fcounter = null;
				$sdonut   = null;
				$donuts   = null;
				$colors   = array('blue', 'red', 'green', 'black');
				$fcount   = count($tab_atual['linhas']['j013']); 
				foreach ($tab_atual['linhas']['j013'] as $key => $value) {
					foreach ($value as $k1 => $v1){
						if($k1 != 'ECS0001'){
							$leg[$k1] = $k1;
							foreach ($v1 as $k2 => $v2) {
								$soma_produtos['total'] += $v2;
								$soma_produtos['soma'][$k1] += $v2; 
								$dados[$k2][$k1] = $v2;
							}
						}
					}
				}

				for ($i=1; $i <= 12 ; $i++) { 
					$counter    = 1;
					$nm = nomeMes($i);
					$str .= "{t:'".$nm."',";
					foreach ($leg as $key => $value) {
						if($key != 'ECS0001'){
							// var_dump($counter);
							if(isset($dados[$nm][$key]) && !empty($dados[$nm][$key])){
								$str .= "'$key'".':'.$dados[$nm][$key];
							}else{
								$str .= "'$key'".':0';
							}
							
							$sdonut .= '{label:'."'".$key."', value:".$totais[$key]."}";
							if($counter < $fcount) {
								$str .= ',';
							}
							$counter++;
						}
					}
					if($i < 12){
						$str .= '},';
					}else{
						$str .= '}';
					}
				}
			}

			foreach ($soma_produtos['soma'] as $key => $value){
				// {label: "Friends", value: 30},
				$porcentagem = porcentagem_nx($value, $soma_produtos['total']);
				$porcentagem = number_format($porcentagem,'2', '.', '');
				$donuts .= '{label: "'.$key.'", value: '.$porcentagem.'},';
			}
			require_once ABSPATH . '/views/'.$this->nome_view.'/dashboard-view.php';
		}

		function DashBoardDois(){
			if($_SESSION['cmswerp']['userdata']->nome_perfil != 'CEO' && $_SESSION['cmswerp']['userdata']->nome_perfil != 'SYSTEM ADMIN'){
				header('location: /login/index');
				exit;
			}

			$tabela = null;
			$header = null;	
			// $_POST['ano_atual'] = 2020;
			if( isset($_POST['ano']) && !empty($_POST['ano']) && is_numeric($_POST['ano']) ){
				$data_atual = $_POST['ano'].'-'.$this->data_hora_atual->format('m-d');
				$data_atual = getDataAtual($data_atual);
			}else{
				$data_atual = clone $this->data_hora_atual;
			}

			for ($ano_ini =2017; $ano_ini <= $this->data_hora_atual->format('Y'); $ano_ini++) { 
				$array_ano[] = $ano_ini;
			}

			$ano_ini = clone $data_atual;
			$ano_ini->modify('first day of January');
			$ano_fim = clone $data_atual;
			$ano_fim->modify('last day of December');

			$dados = null;
			$topdez_juridico = $this->modelo->getTopDespesasByAno($ano_ini->format('Y-m-d'), $ano_fim->format('Y-m-d'), null, null, array('fornecedor', 'tributos'));
			$id_fornecedores = array_column($topdez_juridico, 'id_fornecedor');
			// 
			$pessoa_juridica = json_decode($this->modelo->getTopDespesasByMes($ano_ini->format('Y-m-d'), $ano_fim->format('Y-m-d'), $id_fornecedores, null, array('fornecedor', 'tributo'), false));
			$pessoa_fisica	 = json_decode($this->modelo->getTopDespesasByMes($ano_ini->format('Y-m-d'), $ano_fim->format('Y-m-d'), null, null, 'pessoal', false));
			
			// var_dump($pessoa_juridica);
			// exit;
			// $counter = 1;
			// $limit   = 10;
			foreach ($pessoa_juridica as $key => $value) {
				$i1 = $value->nome_fantasia;
				switch ($value->mes) {
					case '01':
					case '02':
					case '03':
						$i3 = 'Primeiro Trimestre';
					break;
					case '04':
					case '05':
					case '06':
						$i3 = 'Segundo Trimestre';
					break;
					case '07':
					case '08':
					case '09':
						$i3 = 'Terceiro Trimestre';
					break;
					case '10':
					case '12':
					case '12':
						$i3 = 'Quarto Trimestre';
					break;
				}
				$dados[$i1]['dados']['nome'] 	   = $value->nome_fantasia;
				$dados[$i1]['dados']['total'][$i3] += $value->total_despesas;
				$ordenador[$i1] 				   += $value->total_despesas;
			}
			
			
			foreach ($pessoa_fisica as $key => $value) {
				switch ($value->mes) {
					case '01':
					case '02':
					case '03':
						$i3 = 'Primeiro Trimestre';
					break;
					case '04':
					case '05':
					case '06':
						$i3 = 'Segundo Trimestre';
					break;
					case '07':
					case '08':
					case '09':
						$i3 = 'Terceiro Trimestre';
					break;
					case '10':
					case '12':
					case '12':
						$i3 = 'Quarto Trimestre';
					break;
				}
				$dados['folha']['dados']['nome'] 	   = 'FOLHA DE PAGAMENTO';
				$dados['folha']['dados']['total'][$i3] += $value->total_despesas;
				$ordenador['folha'] 		  		   += $value->total_despesas;
			}
			
			if(isset($dados) && count($dados) > 0){
				foreach ($dados as $key => $value) {
					foreach ($value as $k1 => $v1) {
						if(!array_key_exists("Primeiro Trimestre", $v1['total'])){
							$dados[$key][$k1]['total']['Primeiro Trimestre'] = '0,00';
						}

						if(!array_key_exists("Segundo Trimestre", $v1['total'])){
							$dados[$key][$k1]['total']['Segundo Trimestre'] = '0,00';
						}
						
						if(!array_key_exists("Terceiro Trimestre", $v1['total'])){
							$dados[$key][$k1]['total']['Terceiro Trimestre'] = '0,00';
						}

						if(!array_key_exists("Quarto Trimestre", $v1['total'])){
							$dados[$key][$k1]['total']['Quarto Trimestre'] = '0,00';
						}
					}
				}
			}
			arsort($ordenador);
			$ordenador = array_chunk($ordenador, 4, true);
			// $dashboard = array_chunk($dados, 4, true);
			// var_dump($ordenador, $dados);
			// exit;
			require_once ABSPATH . '/views/'.$this->nome_view.'/dashboard2-view.php';
		}

		function DashBoardTres(){
			if($_SESSION['cmswerp']['userdata']->nome_perfil != 'CEO' && $_SESSION['cmswerp']['userdata']->nome_perfil != 'SYSTEM ADMIN'){
				header('location: /login/index');
				exit;
			}

			$tabela = null;
			$header = null;	
			// $_POST['ano_atual'] = 2020;
			if( isset($_POST['ano']) && !empty($_POST['ano']) && is_numeric($_POST['ano']) ){
				$ano_atual  = $_POST['ano'];
				$data_atual = $ano_atual.'-'.$this->data_hora_atual->format('m-d');
				$data_atual = getDataAtual($data_atual);
			}else{
				$data_atual = clone $this->data_hora_atual;
				$ano_atual  = $data_atual->format('Y');
			}

			for ($ano_ini =2017; $ano_ini <= $this->data_hora_atual->format('Y'); $ano_ini++) { 
				$array_ano[] = $ano_ini;
			}

			$ano_ini = clone $data_atual;
			$ano_ini->modify('first day of January');
			$ano_fim = clone $data_atual;
			$ano_fim->modify('last day of December');

			$dados_orcamento = null;
			$dados_despesas  = null;
			$orcamento = json_decode($this->modelo->getOrcamentoByDiretoriaMes($ano_atual));
			$despesas  = json_decode($this->modelo->getDespesasByDiretoriaMes($ano_ini->format('Y-m-d'), $ano_fim->format('Y-m-d')));
			
			$trimestres = array('01'=>'Primeiro Trimestre', '02'=>'Segundo Trimestre', '03'=>'Terceiro Trimestre', '04'=>'Quarto Trimestre');
			
			foreach ($despesas as $key => $value) {
				$i1 = $value->nome;
				switch ($value->mes) {
					case '01':
					case '02':
					case '03':
						$i3 = '01';
					break;
					case '04':
					case '05':
					case '06':
						$i3 = '02';
					break;
					case '07':
					case '08':
					case '09':
						$i3 = '03';
					break;
					case '10':
					case '12':
					case '12':
						$i3 = '04';
					break;
				}
				$dados_orcamento[$i1]['total_despesa'][$i3] += $value->total_despesas;
			}
			// exit;
			foreach ($orcamento as $key => $value) {
				$i1 = $value->nome;
				switch ($value->mes) {
					case '01':
					case '02':
					case '03':
						$i3 = '01';
					break;
					case '04':
					case '05':
					case '06':
						$i3 = '02';
					break;
					case '07':
					case '08':
					case '09':
						$i3 = '03';
					break;
					case '10':
					case '12':
					case '12':
						$i3 = '04';
					break;
				}
				$dados_orcamento[$i1]['total_orcamento'][$i3] += $value->total_lancamentos;
				$dados_orcamento[$i1]['nome'] = $value->nome;
				if(isset($dados_orcamento[$i1]['total_despesa'][$i3])){
					$dados_orcamento[$i1]['consumo'][$i3] = porcentagem_nx($dados_orcamento[$i1]['total_despesa'][$i3], $dados_orcamento[$i1]['total_orcamento'][$i3]);
				}else{
					$dados_orcamento[$i1]['consumo'][$i3] = 0;
				}
			}
			
			foreach ($trimestres as $key => $value) {
				foreach ($orcamento as $k1 => $v1) {
					$i1 = $v1->nome;
					$i2 = $key;
					if(!isset($dados_orcamento[$i1]['total_orcamento'][$i2])){
						$dados_orcamento[$i1]['total_orcamento'][$i2] = 0;
					}

					if(!isset($dados_orcamento[$i1]['total_despesa'][$i2])){
						$dados_orcamento[$i1]['total_despesa'][$i2] = 0;
					}

					if(empty($dados_orcamento[$i1]['total_despesa'][$i2])){
						$dados_orcamento[$i1]['consumo'][$i2] = 0;
					}elseif($dados_orcamento[$i1]['total_despesa'][$i2] > 0 && $dados_orcamento[$i1]['total_orcamento'][$i2] > 0){
						$dados_orcamento[$i1]['consumo'][$i2] = porcentagem_nx($dados_orcamento[$i1]['total_despesa'][$i2], $dados_orcamento[$i1]['total_orcamento'][$i2]);
					}else{
						$dados_orcamento[$i1]['consumo'][$i2] = $dados_orcamento[$i1]['total_despesa'][$i2];
					}
				}
			}
			$dashboard = array_chunk($dados_orcamento, 4);
			// var_dump($dashboard[0]);
			require_once ABSPATH . '/views/'.$this->nome_view.'/dashboard3-view.php';
		}

		function DashBoardQuatro(){
			if($_SESSION['cmswerp']['userdata']->nome_perfil != 'CEO' && $_SESSION['cmswerp']['userdata']->nome_perfil != 'SYSTEM ADMIN'){
				header('location: /login/index');
				exit;
			}

			$tabela = null;
			$header = null;	
			// $_POST['ano_atual'] = 2020;
			if( isset($_POST['ano']) && !empty($_POST['ano']) && is_numeric($_POST['ano']) ){
				$ano_atual  = $_POST['ano'];
				$data_atual = $ano_atual.'-'.$this->data_hora_atual->format('m-d');
				$data_atual = getDataAtual($data_atual);
			}else{
				$data_atual = clone $this->data_hora_atual;
				$ano_atual  = $data_atual->format('Y');
			}
			
			for ($ano_ini =2017; $ano_ini <= $this->data_hora_atual->format('Y'); $ano_ini++) { 
				$array_ano[] = $ano_ini;
			}

			$ano_ini = clone $data_atual;
			$ano_ini->modify('first day of January');
			$ano_fim = clone $data_atual;
			$ano_fim->modify('last day of December');

			$dados_orcamento = null;
			$dados_despesas  = null;
			$recebimentos = $this->modelo->getRecebimentosByAno($ano_ini->format('Y-m-d'), $ano_fim->format('Y-m-d'));
			$id_contratos = array_column($recebimentos, 'codigo_cliente');
			$trimestre    = json_decode($this->modelo->getRecebimentosByMes($ano_ini->format('Y-m-d'), $ano_fim->format('Y-m-d'), $id_contratos));
			if($trimestre){
				foreach ($trimestre as $key => $value) {
					$i1 = $value->codigo_cliente;
					switch ($value->mes) {
						case '01':
						case '02':
						case '03':
							$i3 = 'Primeiro Trimestre';
						break;
						case '04':
						case '05':
						case '06':
							$i3 = 'Segundo Trimestre';
						break;
						case '07':
						case '08':
						case '09':
							$i3 = 'Terceiro Trimestre';
						break;
						case '10':
						case '12':
						case '12':
							$i3 = 'Quarto Trimestre';
						break;
					}
					$dados[$i1]['dados']['nome'] 	    = $value->razao_social;
					$dados[$i1]['dados']['total'][$i3]  += $value->total_recebimentos;
					$ordenador[$i1] 		  			+= $value->total_recebimentos;
				}
			}

			if(isset($dados) && count($dados) > 0){
				foreach ($dados as $key => $value) {
					foreach ($value as $k1 => $v1) {
						if(!array_key_exists("Terceiro Trimestre", $v1['total'])){
							$dados[$key][$k1]['total']['Terceiro Trimestre'] = '0,00';
						}

						if(!array_key_exists("Quarto Trimestre", $v1['total'])){
							$dados[$key][$k1]['total']['Quarto Trimestre'] = '0,00';
						}
					}
				}
			}
			
			arsort($ordenador);
			$ordenador = array_chunk($ordenador, 4, true);
			require_once ABSPATH . '/views/'.$this->nome_view.'/dashboard4-view.php';
		}
		
		function DashBoardCinco(){
			if($_SESSION['cmswerp']['userdata']->nome_perfil != 'CEO' && $_SESSION['cmswerp']['userdata']->nome_perfil != 'SYSTEM ADMIN'){
				header('location: /login/index');
				exit;
			}

			$tabela = null;
			$header = null;	
			// $_POST['ano_atual'] = 2020;
			if( isset($_POST['ano']) && !empty($_POST['ano']) && is_numeric($_POST['ano']) ){
				$ano_atual  = $_POST['ano'];
				$data_atual = $ano_atual.'-'.$this->data_hora_atual->format('m-d');
				$data_atual = getDataAtual($data_atual);
			}else{
				$data_atual = clone $this->data_hora_atual;
				$ano_atual  = $data_atual->format('Y');
			}

			for ($ano_ini =2017; $ano_ini <= $this->data_hora_atual->format('Y'); $ano_ini++) { 
				$array_ano[] = $ano_ini;
			}

			$ano_ini = clone $data_atual;
			$ano_ini->modify('first day of January');
			$ano_fim = clone $data_atual;
			$ano_fim->modify('last day of December');

			$dados_orcamento = null;
			$dados_despesas  = null;
			$orcamento = json_decode($this->modelo->getOrcamentoByGrupoMes($ano_atual));
			$despesas  = json_decode($this->modelo->getDespesasByGrupoMes($ano_ini->format('Y-m-d'), $ano_fim->format('Y-m-d')));
			
			$trimestres = array('01'=>'Primeiro Trimestre', '02'=>'Segundo Trimestre', '03'=>'Terceiro Trimestre', '04'=>'Quarto Trimestre');
			
			foreach ($despesas as $key => $value) {
				$i1 = $value->nome;
				switch ($value->mes) {
					case '01':
					case '02':
					case '03':
						$i3 = '01';
					break;
					case '04':
					case '05':
					case '06':
						$i3 = '02';
					break;
					case '07':
					case '08':
					case '09':
						$i3 = '03';
					break;
					case '10':
					case '12':
					case '12':
						$i3 = '04';
					break;
				}
				$dados_orcamento[$i1]['total_despesa'][$i3] += $value->total_despesas;
			}
			// exit;
			foreach ($orcamento as $key => $value) {
				$i1 = $value->nome;
				switch ($value->mes) {
					case '01':
					case '02':
					case '03':
						$i3 = '01';
					break;
					case '04':
					case '05':
					case '06':
						$i3 = '02';
					break;
					case '07':
					case '08':
					case '09':
						$i3 = '03';
					break;
					case '10':
					case '12':
					case '12':
						$i3 = '04';
					break;
				}
				$dados_orcamento[$i1]['total_orcamento'][$i3] += $value->total_lancamentos;
				$dados_orcamento[$i1]['nome'] = $value->nome;
				if(isset($dados_orcamento[$i1]['total_despesa'][$i3])){
					$dados_orcamento[$i1]['consumo'][$i3] = porcentagem_nx($dados_orcamento[$i1]['total_despesa'][$i3], $dados_orcamento[$i1]['total_orcamento'][$i3]);
				}else{
					$dados_orcamento[$i1]['consumo'][$i3] = 0;
				}
			}
			
			foreach ($trimestres as $key => $value) {
				foreach ($orcamento as $k1 => $v1) {
					$i1 = $v1->nome;
					$i2 = $key;
					if(!isset($dados_orcamento[$i1]['total_orcamento'][$i2])){
						$dados_orcamento[$i1]['total_orcamento'][$i2] = 0;
					}

					if(!isset($dados_orcamento[$i1]['total_despesa'][$i2])){
						$dados_orcamento[$i1]['total_despesa'][$i2] = 0;
					}

					if(empty($dados_orcamento[$i1]['total_despesa'][$i2])){
						$dados_orcamento[$i1]['consumo'][$i2] = 0;
					}elseif($dados_orcamento[$i1]['total_despesa'][$i2] > 0 && $dados_orcamento[$i1]['total_orcamento'][$i2] > 0){
						$dados_orcamento[$i1]['consumo'][$i2] = porcentagem_nx($dados_orcamento[$i1]['total_despesa'][$i2], $dados_orcamento[$i1]['total_orcamento'][$i2]);
					}else{
						$dados_orcamento[$i1]['consumo'][$i2] = $dados_orcamento[$i1]['total_despesa'][$i2];
					}
				}
			}
			$dashboard = array_chunk($dados_orcamento, 4);
			// var_dump($dashboard[0]);
			require_once ABSPATH . '/views/'.$this->nome_view.'/dashboard5-view.php';
		}
		
		function KpiDois(){
			if($_SESSION['cmswerp']['userdata']->nome_perfil != 'CEO'){
				header('location: /login/index');
				exit;
			}
			// datas
			$tabela 	   = null;
			$header 	   = null;
			$arrayProdutos = null;

			
			if(isset($_POST['ano']) && !empty($_POST['ano']) && $_POST['ano'] != $this->data_hora_atual->format('Y')){
				$data_atual = getDataAtual($_POST['ano'].'-01-01');		
			}else{
				$data_atual = clone($this->data_hora_atual);
			}

			
			for ($ano_ini=2017; $ano_ini <= $this->data_hora_atual->format('Y'); $ano_ini++) { 
				$array_ano[] = $ano_ini;
			}

			$ultimos12m  = clone($data_atual);
			$ultimos12m->sub(new DateInterval('P12M'));
			$ultimos12m->modify('first day of this month');

			$anoatual_ini = clone($data_atual);
			$anoatual_ini->modify('first day of January');

			$anoatual_fim = clone($data_atual);
			$anoatual_fim->modify('last day of December');

			$periodo_ini = $anoatual_ini->format('Y-m-d');
			$periodo_fim = $anoatual_fim->format('Y-m-d');
			
			$dia_atual = $data_atual->format('d');
			$mes_atual = $data_atual->format('m');
			$ano_atual = $data_atual->format('Y');
			
			// total de modulos tarifados
			$modulos_tarifados = json_decode($this->obj_movimento->getModuloTarifador($periodo_ini, $periodo_fim));
			// total de transações tarifaveis
			$total_transacoes = json_decode($this->obj_movimento->getMovPeriodoResume($periodo_ini, $periodo_fim));
			// Total de transações por produtos
			$transacoes_produtos = json_decode($this->obj_movimento->getMovPeriodoResumeByProduto($periodo_ini, $periodo_fim));
			// total de faturamento nf emitdas pagas e não pagas
			$total_fat1       = json_decode($this->obj_nf->getNotaResumeGroup('emissao', $periodo_ini, $periodo_fim));
			// total de faturamento nf recebidas
			$total_fat2       = json_decode($this->obj_nf->getNotaResumeGroup('recebimento', $periodo_ini, $periodo_fim, 'recebido'));
			// total de faturamento nf emitidas e não recebidas 
			$total_fat3       = json_decode($this->obj_nf->getNotaResumeGroup('emissao', $periodo_ini, $periodo_fim, 'receber'));
			// total de faturamento nf emitdas ultimos 12 meses
			$total_fat4       = json_decode($this->obj_nf->getNotaResumeGroup('emissao', $ultimos12m->format('Y-m-d'), $data_atual->format('Y-m-d')), 'recebido');
			// total de despeas aprovadas e pagas
			$total_desp1       = json_decode($this->obj_despesas->getDespesasAnoResume($periodo_ini, $periodo_fim, 'pago', null, 'pagamento'));
			// total de despesas em aberto
			$total_desp2       = json_decode($this->obj_despesas->getDespesasAnoResume($periodo_ini, $periodo_fim, 'aberto', null));
			// total de despeas aprovadas pagas e não pagas
			$total_desp3       = json_decode($this->obj_despesas->getDespesasAnoResume($periodo_ini, $periodo_fim, null, 'aprovado'));
			
			// ticket medio do KP1
			$ticket_medio      = json_decode($this->modelo->getIndicadoresPorAnoMes('i0020', $anoatual_ini->format('Y')));
			$contratos_ativos  = json_decode($this->modelo->getIndicadoresPorAnoMes('i0001', $anoatual_ini->format('Y')));
			$clientes_ativos   = json_decode($this->modelo->getIndicadoresPorAnoMes('i0002', $anoatual_ini->format('Y')));
			$total_modulos     = json_decode($this->modelo->getIndicadoresPorAnoMes('i0011', $anoatual_ini->format('Y')));

			// tabela com dados para exibir
			for($x = 1; $x<=12; $x++){
				$i1 = nomeMes($x);
				$header[$i1] = $i1;
			}

			$tabela['header'] = $header;
			
			foreach($total_transacoes as $key => $value) {
				$i2 = nomeMes($value->mes);
				$tabela['transacoes'][$i2] = $value->qtd_transacoes;
			}
		
			foreach($ticket_medio as $key => $value) {
				$i3 = nomeMes($value->mes);
				$tabela['ticket'][$i3] = $value->quantidade;
			}
			
			foreach($total_fat1 as $key => $value) {
				$i4 = nomeMes($value->mes_emissao);
				$tabela['faturamento'][$i4] = $value->total_fatura;
			}

			foreach($contratos_ativos as $key => $value) {
				$i5 = nomeMes($value->mes);
				$tabela['contratos_ativos'][$i5] = $value->quantidade;
			}

			foreach($clientes_ativos as $key => $value) {
				$i6 = nomeMes($value->mes);
				$tabela['clientes_ativos'][$i6] = $value->quantidade;
			}

			foreach($total_modulos as $key => $value) {
				$i7 = nomeMes($value->mes);
				$tabela['total_modulos'][$i7] = $value->quantidade;
			}

			// v1 OK
			// Todos pagamentos realizados do mes atual + pagamentos aprovados, divididos por fatura emitida KPI1
			foreach($total_desp3 as $key => $value) {
				$id1 = nomeMes($value->mes);
				//var_dump($value->valor_total, $value->atmon_total, $value->juros_total, $value->multa_total, $value->outros_total, $value->desconto_total, $value->abatimento_total);
				$v1[$id1] = (($value->valor_total + $value->atmon_total + $value->juros_total + $value->multa_total + $value->outros_total - $value->desconto_total - $value->abatimento_total) / $tabela['ticket'][$id1]);
				$tabela['linhas']['j001'][$id1] = $v1[$id1];
			}

			// v2 OK
			// Soma de tarifacoes do mes dividido pelo dia do mes
			// No mes fechado dividir pelo ultimo dia do respectivo mes
			foreach($total_transacoes as $key => $value){
				$id2 = nomeMes($value->mes);
				if($value->mes == $mes_atual){
					$ultimo_dia = $dia_atual;
					//var_dump($ultimo_dia, $id2, $mes_atual);
				}else{
					$ultimo_dia = cal_days_in_month(CAL_GREGORIAN, $value->mes, $ano_atual);
				}
				
				$v2[$id2] = ($tabela['transacoes'][$id2] / $ultimo_dia);
				$tabela['linhas']['j002'][$id2] = $v2[$id2];
			}
			
			// v3 OK
			// Soma de todas as transacoes do mes dividida pela soma do faturamento(notas faturadas), contar pela data de emissão com 06 casas decimais
			foreach($total_transacoes as $key => $value) {
				$id3 = nomeMes($value->mes);
				$v3 = ($tabela['faturamento'][$id3] / $tabela['transacoes'][$id3]);
				$tabela['linhas']['j003'][$id3] = $v3;
			}
			
			// v4 OK
			// Soma de todas as despesas aprovadas e pagas dividido por v3
			foreach($total_desp1 as $key => $value) {
				$id4 = nomeMes($value->mes);
				$v4[$id1] = (($value->valor_total + $value->atmon_total + $value->juros_total + $value->multa_total + $value->outros_total - $value->desconto_total - $value->abatimento_total));
				$tabela['linhas']['j004'][$id4] = ($v4[$id1] / $tabela['linhas']['j003'][$id4]);
			}
					
			// v5 OK
			// Soma de todas as tranasacoes do mes - v4
			foreach($total_transacoes as $key => $value) {
				$id5 = nomeMes($value->mes);
				$v5[$id5] = ($tabela['transacoes'][$id5] - $tabela['linhas']['j004'][$id5]);;
				$tabela['linhas']['j005'][$id5] = $v5[$id5];
			}
			
			// v6 OK
			// Total de contratos ativos
			$tabela['linhas']['j006'] = $tabela['contratos_ativos'];

			// v7 OK
			// total de clientes ativos
			$tabela['linhas']['j007'] = $tabela['clientes_ativos'];

			// v8 OK
			// total de faturamento global e comercial
			$tabela['linhas']['j008'] = $tabela['faturamento'];
			
			// v9 OK
			// Total recebido igual EBTDA
			foreach($total_fat2 as $key => $value) {
				$id7 = nomeMes($value->mes_recebimento);
				$tabela['linhas']['j009'][$id7] = $value->total_fatura;
			}

			// v10 OK
			// soma de todas as despesas aprovadas e não pagas
			foreach($total_desp2 as $key => $value) {
				$id8 = nomeMes($value->mes);
				$v10[$id8] = ($value->valor_total + $value->atmon_total + $value->juros_total + $value->multa_total + $value->outros_total - $value->desconto_total - $value->abatimento_total);
				$tabela['linhas']['j010'][$id8] =  $v10[$id8];
			}
			
			// v11 OK
			// Total de notas emitidas e não recebidas
			foreach($total_fat3 as $key => $value) {
				$id9 = nomeMes($value->mes_emissao);
				$tabela['linhas']['j011'][$id9] = $value->total_fatura;
			}

			// v12
			// Total de pagamentos igual EBTA
			foreach($total_desp1 as $key => $value) {
				$id10 = nomeMes($value->mes);
				$v12[$id10] = ($value->valor_total + $value->atmon_total + $value->juros_total + $value->multa_total + $value->outros_total - $value->desconto_total - $value->abatimento_total);
				// var_dump($v12[$id10]);
				$tabela['linhas']['j012'][$id10] = $v12[$id10];
			}

			// v14 OK
			// Total de modulos tarifados
			$tabela['linhas']['j014'] = $tabela['total_modulos'];
			
			// v15 OK
			// Total de notas recebidas - total de despesas pagas
			foreach($total_fat2 as $key => $value) {
				$id13 = nomeMes($value->mes_recebimento);
				$v15[$id13]  = ($value->total_fatura - $tabela['linhas']['j012'][$id13]);
				$tabela['linhas']['j015'][$id13] = $v15[$id13];
			}
			// var_dump($total_fat2, $total_desp1, $tabela['linhas']['j015'] );
			// exit;
			// v17
			// Soma das notas fiscais faturadas dos ultimos 12 meses
			for ($i=1; $i<=12 ; $i++){

				$id14 = nomeMes($i);
				
				if($i < 10){
					$data_base = $ano_atual.'-0'.$i.'-01';
				}else{
					$data_base = $ano_atual.'-'.$i.'-01';
				}

				$data_inicial = getDataAtual($data_base);
				$data_inicial->modify('first day of this month');
				$data_inicial->sub(new DateInterval('P12M'));
				$data_final   = getDataAtual($data_base);
				$data_final->modify('last day of this month');
				//echo '<pre>';
				//    var_dump($data_inicial, $data_final);
				//echo '</pre>';
				
				$nfs = json_decode($this->obj_nf->getSomaNotaByPeriodo('recebimento', $data_inicial->format('Y-m-d'), $data_final->format('Y-m-d'), 'recebido'));

				if($nfs){
					foreach($nfs as $key => $value){
						$calc_nfs = $value->total_fatura;
					}
				}else{
					$calc_nfs = 0;
				}
				$tabela['linhas']['j017'][$id14] = $calc_nfs;
			}

			// v18
			// Total de despesas pagas dos ultimos 12 meses
			for ($i=1; $i<=12 ; $i++){
				$id14 = nomeMes($i);
				if($i < 10){
					$data_base = $ano_atual.'-0'.$i.'-01';
				}else{
					$data_base = $ano_atual.'-'.$i.'-01';
				}

				$data_inicial = getDataAtual($data_base);
				$data_inicial->modify('first day of this month');
				$data_inicial->sub(new DateInterval('P12M'));
				$data_final   = getDataAtual($data_base);
				$data_final->modify('last day of this month');

				$despesas = json_decode($this->obj_despesas->getSomaDespesaByPeriodo($data_inicial->format('Y-m-d'), $data_final->format('Y-m-d'), 'pago', null, 'pagamento'));

				if($despesas){
					foreach($despesas as $key => $value){
						$calc_despesa = ($value->valor_total + $value->atmon_total + $value->juros_total + $value->multa_total + $value->outros_total - $value->desconto_total - $value->abatimento_total);
					}
				}else{
					$calc_despesa = 0;
				}
				$tabela['linhas']['j018'][$id14] =  $calc_despesa;
			}

			// v16 OK
			// Soma do lucro liquido dos ultimos 12 meses
			for ($i=1; $i<=12 ; $i++){
				$id14 = nomeMes($i);
				$tabela['linhas']['j016'][$id14] = ($tabela['linhas']['j017'][$id14] - $tabela['linhas']['j018'][$id14]);
			}

			// v13 OK
			// Total de transações por produto, OBS: todos produtos SPB serão igual a PIX
			// começo bloco de produtos
			foreach($transacoes_produtos as $key => $value) {
				$id11 = nomeMes($value->mes);
				switch ($value->codigo_produto) {
					case 'FSP0001':
					case 'SOE0001':
					case 'SPB0001':
					case 'SPI0001':
					case 'SPBALL':
						$p1 = 'CORNER PIX';
						$o1 = 4;
					break;
					case 'RCK0001':
						$p1 = $value->codigo_produto;
						$o1 = 2;
					break;
					case 'ATF0001':
						$p1 = $value->codigo_produto;
						$o1 = 1;
					break;
					default:
						$p1 = $value->codigo_produto;
						$o1 = 5;
					break;
				}
				$arrayProdutos[$o1][$p1][$id11] += $value->qtd_transacoes;
			}
			$dados_mov_aux = json_decode($this->obj_nf->getTotalNFPorProdutoResume($periodo_ini, $periodo_fim, 'ECS0001'));
			if($dados_mov_aux){
				foreach($dados_mov_aux as $key => $value) {
					$i1 = nomeMes($value->mes);
					$i2 = $value->codigo_produto;
					$o1 = 3;
					$arrayProdutos[$o1][$i2][$i1] = $value->transacoes;
				}
			}
			ksort($arrayProdutos);
			$tabela['linhas']['j013'] = $arrayProdutos;
			ksort($tabela['linhas']);
			// var_dump($tabela['linhas']);
			// exit;
			// fim bloco produtos
			$tabela['nomes']['j001'] = 'Faturamento necessario';
			$tabela['nomes']['j002'] = 'Média de transações diarias';
			$tabela['nomes']['j003'] = 'Ticket Médio de transações';
			$tabela['nomes']['j004'] = 'Transações necessarias';
			$tabela['nomes']['j005'] = 'Saldo de transações';
			$tabela['nomes']['j006'] = 'Total de contratos ativos';
			$tabela['nomes']['j007'] = 'Total de clientes ativos';
			$tabela['nomes']['j008'] = 'Total de faturamento';
			$tabela['nomes']['j009'] = 'Total recebido';
			$tabela['nomes']['j010'] = 'Total a pagar';
			$tabela['nomes']['j011'] = 'Total a receber';
			$tabela['nomes']['j012'] = 'Total de pagamentos';
			$tabela['nomes']['j013'] = 'Total de transações';
			$tabela['nomes']['j014'] = 'Total de modulos tarifados';
			$tabela['nomes']['j015'] = 'Lucro liquido mensal';
			$tabela['nomes']['j016'] = 'Lucro liquido anual';
			$tabela['nomes']['j017'] = 'Receita Anual';
			$tabela['nomes']['j018'] = 'Despesa Anual';
			require_once ABSPATH . '/views/'.$this->nome_view.'/kpi2-view.php';
		}
		
		function KpiUm(){
			if($_SESSION['cmswerp']['userdata']->nome_perfil != 'CEO'){
				header('location: /login/index');
				exit;
			}
			if(isset($_POST['ano'])){
				$ano = $_POST['ano'];
			}else{
				$ano = $this->data_hora_atual->format('Y');
			}
			
			if(isset($_POST['mes'])){
				$mes = $_POST['mes'];
				$mes = str_pad($mes, 2, '0', STR_PAD_LEFT);
			}else{
				$mes = $this->data_hora_atual->format('m');
			}

			if(isset($_POST['reprocessar']) && 'reprocessar' == strtolower($_POST['reprocessar'])){
				$action = 'reprocessar';
			}elseif($mes == $this->data_hora_atual->format('m') && $ano == $this->data_hora_atual->format('Y')){
				$action = 'reprocessar';
			}else{
				$action = 'visualizar';
			}

			$now = new Datetime($ano.'-'.$mes.'-01', new DateTimeZone('America/Sao_Paulo'));
			$this->execIndicador($now, $action);
		}

		function execIndicador($now = null, $action = 'visualizar'){
			
			for ($ano_ini=2017; $ano_ini <= $this->data_hora_atual->format('Y'); $ano_ini++) { 
				$array_ano[] = $ano_ini;
			}

			for ($mes_ini=1; $mes_ini <= 12; $mes_ini++) { 
				$array_meses[] = $mes_ini;
			}

			if(!$now){
				$now = $this->hoje;
			}

			$chk     = null;
			$is_save = null;
			$param   = null;
			$dados   = null;

			if('reprocessar' == $action){
				$ultimo_dia_mes = cal_days_in_month(CAL_GREGORIAN, $now->format('m'), $now->format('Y'));
				//indicador de contratos ativos
				
				$contratos = json_decode($this->obj_report->getContratosAtivos($now->format('Y-m-'.$ultimo_dia_mes)));
				
				$chk = json_decode($this->obj_report->getIndicadoresPorAnoMes('i0001',$now->format('Y'), $now->format('m')));
				$param['nome']   	 = 'Total de Contratos Ativos (+)';
				$param['codigo'] 	 = 'i0001';
				$param['tipo']   	 = 'indicador';
				$param['ano'] 	 	 = $now->format('Y');
				$param['mes'] 	 	 = $now->format('m');
				$param['quantidade'] = $contratos[0]->contratos_ativos;
				
				if(empty($chk)){
					$is_save = $this->obj_report->saveIndicador($param);
				}else{
					$is_save = $this->obj_report->saveIndicador($param, $chk[0]->id);
				}
				
				$chk = null;
				$is_save = null;
				$param= null;
				$dados = null;
				
				//indicador de clientes ativos
				$clientes = json_decode($this->obj_report->getClientesAtivos($now->format('Y-m-'.$ultimo_dia_mes)));
				$chk = json_decode($this->obj_report->getIndicadoresPorAnoMes('i0002', $now->format('Y'), $now->format('m')));
				
				$param['nome']   = 'Total de Clientes Ativos (+)';
				$param['codigo'] = 'i0002';
				$param['tipo']   = 'indicador';
				$param['ano'] 	 = $now->format('Y');
				$param['mes'] 	 = $now->format('m');
				$param['quantidade'] = $clientes[0]->clientes_ativos;
				
				if(!$chk){
					$is_save = $this->obj_report->saveIndicador($param);
				}else{
					$is_save = $this->obj_report->saveIndicador($param, $chk[0]->id);
				}
				
				$chk     = null;
				$is_save = null;
				$param   = null;
				$dados   = null;

				$chk = json_decode($this->obj_report->getIndicadoresPorAnoMes('i0011',$now->format('Y'), $now->format('m')));
				$dados = count(json_decode($this->obj_movimento->countModulosporAnoMes($now->format('Y'), $now->format('m'))));
				$param['nome']   = 'Total de Módulos que geraram faturamento (+)';
				$param['codigo'] = 'i0011';
				$param['tipo']   = 'indicador';
				$param['ano'] 	 = $now->format('Y');
				$param['mes'] 	 = $now->format('m');
				$param['quantidade'] = $dados;
				
				if(!$chk){
					$is_save = $this->obj_report->saveIndicador($param);
				}else{
					$is_save = $this->obj_report->saveIndicador($param, $chk[0]->id);
				}

				$chk     = null;
				$is_save = null;
				$param   = null;
				$dados   = null;
				//indicadores de media por transacoes
				$this->cacularTransacoesPorAnoProduto('ADM0001', 'i0003', 'Tarifações Realizadas ADM (-)', $now);
				$this->cacularTransacoesPorAnoProduto('COB0001', 'i0004', 'Tarifações Realizadas Cobrança (+)', $now);
				$this->cacularTransacoesPorAnoProduto('ECS0001', 'i0005', 'Tarifações Realizadas ECS (+)', $now);
				$this->cacularTransacoesPorAnoProduto('GCK0001', 'i0006', 'Tarifações Realizadas Gochk (+)', $now);
				$this->cacularTransacoesPorAnoProduto('LIQ0001', 'i0007', 'Tarifações Realizadas Liquidado (+)', $now);
				$this->cacularTransacoesPorAnoProduto('PWD0001', 'i0008', 'Tarifações Realizadas Powerdeck (+)', $now);
				$this->cacularTransacoesPorAnoProduto('RCK0001', 'i0009', 'Tarifações Realizadas Rocket (+)', $now);
				$this->cacularTransacoesPorAnoProduto('SPB0001', 'i0010', 'Tarifações Realizadas SPbx (+)', $now);
				$this->cacularTransacoesPorAnoProduto('SOE0001', 'i0026', 'Tarifações Realizadas SPB/x OBE (+)', $now);
				$this->cacularTransacoesPorAnoProduto('FSP0001', 'i0028', 'Tarifações Realizadas FullString (+)', $now);
				$this->cacularTransacoesPorAnoProduto('ATF0001', 'i0029', 'Tarifações Realizadas CornerPix Anti Fraude (+)', $now);
				$this->cacularTransacoesPorAnoProduto('RLT0001', 'i0032', 'Tarifações Realizadas Rocket Lite (+)', $now);
				$this->cacularTransacoesPorAnoProduto('SKB0001', 'i0033', 'Tarifações Realizadas SkinBd (+)', $now);
				$this->cacularTransacoesPorAnoProduto('SPI0001', 'i0037', 'Tarifações Realizadas SPI (+)', $now);
				$this->cacularTransacoesPorAnoProduto('CRY0001', 'i0038', 'Tarifações Realizadas CRYSTAL (+)', $now);
				$this->cacularTransacoesPorAnoProduto('TPX0001', 'i0039', 'Tarifações Realizadas TRIPLEPIX (+)', $now);
				$this->cacularTransacoesPorAnoProduto('YLW0001', 'i0040', 'Tarifações Realizadas YELLOW (+)', $now);
				
				//indicadores de media por produto
				$this->calcularMediaAssinatura('RCK0001', 'i0013', 'Tempo médio aquisição Rocket (-)', $now);
				$this->calcularMediaAssinatura('COB0001', 'i0012', 'Tempo médio aquisição Cobrança (-)', $now);
				$this->calcularMediaAssinatura('ECS0001', 'i0014', 'Tempo médio aquisição ECS (-)', $now);
				$this->calcularMediaAssinatura('GCK0001', 'i0015', 'Tempo médio aquisição GoChk (-)', $now);
				$this->calcularMediaAssinatura('LIQ0001', 'i0016', 'Tempo médio aquisição Liquidado (-)', $now);
				$this->calcularMediaAssinatura('PWD0001', 'i0017', 'Tempo médio aquisição Powerdeck (-)', $now);
				$this->calcularMediaAssinatura('SPB0001', 'i0018', 'Tempo médio aquisição SPbx (-)', $now);
				$this->calcularMediaAssinatura('SOE0001', 'i0027', 'Tempo médio aquisição SPB/x OBE (-)', $now);
				$this->calcularMediaAssinatura('FSP0001', 'i0030', 'Tempo médio aquisição FullString (-)', $now);
				$this->calcularMediaAssinatura('ATF0001', 'i0031', 'Tempo médio aquisição CornerPix Anti Fraude (-)', $now);
				$this->calcularMediaAssinatura('RLT0001', 'i0034', 'Tempo médio aquisição Rocket Lite (-)', $now);
				$this->calcularMediaAssinatura('SKB0001', 'i0035', 'Tempo médio aquisição SPI (-)', $now);
				$this->calcularMediaAssinatura('SPI0001', 'i0036', 'Tempo médio aquisição SkinBd (-)', $now);
				$this->calcularMediaAssinatura('CRY0001', 'i0041', 'Tempo médio aquisição Crystal (-)', $now);
				$this->calcularMediaAssinatura('TPX0001', 'i0042', 'Tempo médio aquisição TriplePix (-)', $now);
				$this->calcularMediaAssinatura('YLW0001', 'i0043', 'Tempo médio aquisição Yellow (-)', $now);
				
				$chk = json_decode($this->obj_report->getIndicadoresPorAnoMes('i0019',$now->format('Y'), $now->format('m')));
				$dados = json_decode($this->obj_despesas->getCountFornecedorSoma($now->format('Y'), $now->format('m')));
				
				if($dados){
					$ticket_medio_pagamento = ($dados[0]->valor / $dados[0]->count_fornecedor);
					$total_contas_pagas     = (float)$dados[0]->valor;
				}else{
					$total_contas_pagas     = 0;
					$ticket_medio_pagamento = 0;
				}

				$param['nome']   = 'Ticket Médio de Pagamentos (-)';
				$param['codigo'] = 'i0019';
				$param['tipo']   = 'indicador';
				$param['ano'] 	 = $now->format('Y');
				$param['mes'] 	 = $now->format('m');
				$param['quantidade'] = $ticket_medio_pagamento;
				
				if(!$chk){
					$is_save = $this->obj_report->saveIndicador($param);
				}else{
					$is_save = $this->obj_report->saveIndicador($param, $chk[0]->id);
				}

				$chk     = null;
				$is_save = null;
				$param   = null;
				$dados   = null;
				$chk     = json_decode($this->obj_report->getIndicadoresPorAnoMes('i0020',$now->format('Y'), $now->format('m')));
				$dados   = json_decode($this->obj_nf->mediaSomaNotas($now->format('Y'), $now->format('m')));
				
				if($dados){
					$ticket_medio_fatura = ($dados[0]->valor_total / $dados[0]->contador_notas);
					$ponto_equilibrio = ($total_contas_pagas / $ticket_medio_fatura);
				}else{
					$ticket_medio_fatura = 0;
					$ponto_equilibrio = 0;
				}

				$param['nome']   = 'Ticket Médio Fatura Emitida (-)';
				$param['codigo'] = 'i0020';
				$param['tipo']   = 'indicador';
				$param['ano'] 	 = $now->format('Y');
				$param['mes'] 	 = $now->format('m');
				$param['quantidade'] = $ticket_medio_fatura;

				if(!$chk){
					$is_save = $this->obj_report->saveIndicador($param);
				}else{
					$is_save = $this->obj_report->saveIndicador($param, $chk[0]->id);
				}

				$chk     = null;
				$is_save = null;
				$param   = null;
				$dados   = null;

				$chk = json_decode($this->obj_report->getIndicadoresPorAnoMes('i0024', $now->format('Y'), $now->format('m')));
				$dados_orcamento = json_decode($this->obj_orcamento->getSomaLancamentoPorPeriodo($now->format('Y'), $now->format('m')));
				$orcamento_cliente = (float)($dados_orcamento[0]->valor_total / (float)$ticket_medio_fatura);
				
				$param['nome']   = 'Orçamento Clientes';
				$param['codigo'] = 'i0024';
				$param['tipo']   = 'indicador';
				$param['ano'] 	 = $now->format('Y');
				$param['mes'] 	 = $now->format('m');
				$param['quantidade'] = $orcamento_cliente;
				
				if(!$chk){
					$is_save = $this->obj_report->saveIndicador($param);
				}else{
					$is_save = $this->obj_report->saveIndicador($param, $chk[0]->id);
				}
				
				$chk = null;
				$is_save = null;
				$param= null;
				$dados = null;

				$dados_despesas = json_decode($this->obj_despesas->getSomaDespesasAnoMes($now->format('Y'), $now->format('m')));
				$chk = json_decode($this->obj_report->getIndicadoresPorAnoMes('i0025', $now->format('Y'), $now->format('m')));
				$projetado_cliente = (float)($dados_despesas[0]->valor_total / $ticket_medio_fatura);

				$param['nome']   = 'Projetado  Clientes';
				$param['codigo'] = 'i0025';
				$param['tipo']   = 'indicador';
				$param['ano'] 	 = $now->format('Y');
				$param['mes'] 	 = $now->format('m');
				$param['quantidade'] = $projetado_cliente;
				
				if(!$chk){
					$is_save = $this->obj_report->saveIndicador($param);
				}else{
					$is_save = $this->obj_report->saveIndicador($param, $chk[0]->id);
				}
			}

			$ano_ini = getDataAtual($this->data_hora_atual->format('Y').'-01-01');
			$ano_fim = getDataAtual($this->data_hora_atual->format('Y').'-12-31');

			$despesas = json_decode($this->obj_despesas->getDespesas(null, $now->format('Y').'-01-01', $ano_fim->format('Y').'-12-31', null, 'aberto', 'pendente'));
			
			if($despesas){
				foreach ($despesas as $key => $value){
					$vencimento          = getDataAtual($value->data_vencimento);
					$mes = nomeMes($vencimento->format('m'));
					$tabela_dados['i0038']['codigo']      = 'i0038';
					$tabela_dados['i0038']['nome']        = 'Total despesas em aberto (+)';
					$tabela_dados['i0038']['meses'][$mes] = $tabela_dados['i0038']['meses'][$mes]+1;
				}
			}

			$dados_indicadores = json_decode($this->modelo->getIndicadoresPorAnoMes(null, $now->format('Y')));
			
			if($dados_indicadores){
				foreach ($dados_indicadores as $key => $value) {
					$nome   = $value->nome;
					$codigo = $value->codigo;
					$mes    = nomeMes($value->mes);
					$tabela_dados[$codigo]['codigo']      = $codigo;
					$tabela_dados[$codigo]['nome']        = $nome;
					$tabela_dados[$codigo]['meses'][$mes] = round($value->quantidade);
				}
			}
			require_once ABSPATH . '/views/'.$this->nome_view.'/kpi1-view.php';
		}
			
		function calcularMediaAssinatura($codigo_produto, $codigo_indicador, $texto, $now){
			$difday = null;
			$dados = json_decode($this->obj_contrato->contratosAtivosDataAssinatura(null, $codigo_produto, false, $now));
			if($dados){
				$count = count($dados);
				$date1 = null;
				$date2 = null;
				foreach ($dados as $key => $value) {
					if(!isset($date1) || empty($date1)){
						$date1 = new Datetime($value->data_assinatura);
					}else{
						$date2 = new Datetime($value->data_assinatura);
						$obj_dif = $date1->diff($date2);
						$difday += $obj_dif->days;
						if($codigo_produto == 'RCK0001'){
							$teste = ($date2->format('Ymd') - $date1->format('Ymd'));
							// echo $date1->format('Y-m-d').'<br>';
							// echo ' dia 1 contrato '.$value->id_contrato.': '.$date1->format('Y-m-d').' dia 2: '.$date2->format('Y-m-d').' dias '.$obj_dif->days.'<br>';
							//echo $obj_dif->days.'<br>';
						}
						$date1 = $date2;
					}
				}
				// $teste = $media_assinatura = ($difday / $count);
				//$media_assinatura = ($difday / $count);
				$media_assinatura = ($difday / $count);
				// if($codigo_produto == 'RCK0001'){
				// 	echo 'Data 1 '.$date1->format('Y-m-d').'<br>';
				// 	echo 'Data 1 '.$date1->format('Y-m-d').'<br>';
				// 	echo 'Teste :'.$teste.'<br>';
				// 	echo 'quantidade de contratos :'.$count.'<br>';
				// 	echo 'Soma de dias: '.$difday.'<br>';
				// 	echo 'tempo médio :'.$media_assinatura.'<br>';
				// }
				$param['quantidade'] = $media_assinatura;
			}else{
				$param['quantidade'] = 0;
			}

			$chk = json_decode($this->obj_report->getIndicadoresPorAnoMes($codigo_indicador,$now->format('Y'), $now->format('m')));
			$param['nome']   = $texto;
			$param['codigo'] = $codigo_indicador;
			$param['tipo']   = 'indicador';
			$param['ano'] 	 = $now->format('Y');
			$param['mes'] 	 = $now->format('m');

			if(!$chk){
				$is_save = $this->obj_report->saveIndicador($param);
			}else{
				$is_save = $this->obj_report->saveIndicador($param, $chk[0]->id);
			}
		}

		function cacularTransacoesPorAnoProduto($codigo_produto, $codigo_indicador, $texto, $now){
			$param['quantidade'] = null;
			if($codigo_produto == 'ADM0001'){
				$dados_mov_aux = json_decode($this->obj_nf->getTotalMovAuxPorProduto($codigo_produto, $now->format('Y'), $now->format('m')));
				if(isset($dados_mov_aux[0]->transacoes)){
					$param['quantidade'] += $dados_mov_aux[0]->transacoes;	
				}else{
					$param['quantidade'] += 0;
				}

				$nf_adm = json_decode($this->obj_nf->getTotalNFPorProduto($codigo_produto, $now->format('Y'),  $now->format('m')));
				if($nf_adm){
					$param['quantidade'] += $nf_adm[0]->transacoes;
				}else{
					$param['quantidade'] += 0;	
				}
			}elseif($codigo_produto == 'ECS0001'){
				$dados_mov_aux = json_decode($this->obj_nf->getTotalNFPorProduto($codigo_produto, $now->format('Y'), $now->format('m')));
				$param['quantidade'] += $dados_mov_aux[0]->transacoes;
			}else{
				$dados = json_decode($this->obj_movimento->countTransacoesPorAnoProduto($now->format('Y'), $now->format('m'), $codigo_produto));
				if($dados){
					$param['quantidade'] = $dados[0]->transacoes;
				}else{
					$param['quantidade'] = 0;
				}
			}

			$param['nome']   = $texto;
			$param['codigo'] = $codigo_indicador;
			$param['tipo']   = 'indicador';
			$param['ano'] 	 = $now->format('Y');
			$param['mes'] 	 = $now->format('m');
			
			$chk = json_decode($this->obj_report->getIndicadoresPorAnoMes($codigo_indicador, $now->format('Y'), $now->format('m')));

			if(!$chk){
				$is_save = $this->obj_report->saveIndicador($param);
			}else{
				$is_save = $this->obj_report->saveIndicador($param, $chk[0]->id);
			}
		}

		function GarantiaReceita(){
			parent::__construct($this->parametros, 'report', true);
			$exceto['produtos'][] = 'GCK0001';
			$exceto['produtos'][] = 'ADM0001';
			$exceto['modulos'][]  = 'SPB0012';
			$exceto['modulos'][]  = 'SOE0032';
			$exceto['modulos'][]  = 'SOE0033';
			$exceto['modulos'][]  = 'SOE0034';
			$exceto['modulos'][]  = 'SOE0035';
			$exceto['modulos'][]  = 'SPB0012';
			$exceto['modulos'][]  = 'RCK0051';
			$exceto['modulos'][]  = 'RCK0052';
			$exceto['modulos'][]  = 'RCK0053';
			$exceto['modulos'][]  = 'RCK0054';
			$exceto['modulos'][]  = 'RCK0033';
			set_time_limit(1800);//coloque no inicio do arquivo
			try{
				//configura data de hoje
				$hoje            = getDataAtual();
				$produto_model   = $this->load_model('produtos/produtos', true);
				$lista_contratos = json_decode($this->obj_contrato->clientesAtivos());
				$relatorio 	     = null;
				$codigo_produto  = null;
				$codigo_modulo   = null;
				
				if(isset($_POST['codigo_cliente']) && !empty($_POST['codigo_cliente'])){
					$codigo_cliente = $_POST['codigo_cliente'];
				}else{
					$codigo_cliente = null;
				}

				if(isset($_POST['codigo_produto']) && !empty($_POST['codigo_produto'])){
					$codigo_produto = $_POST['codigo_produto'];
					if(isset($_POST['codigo_modulo']) && !empty($_POST['codigo_modulo'])){
						$codigo_modulo = $_POST['codigo_modulo'];
					}
					$produtos = json_decode($produto_model->getProdutosPorCliente($codigo_cliente));
					$modulos  = json_decode($produto_model->getProdutoEmodulo($codigo_produto, $codigo_modulo));
				}else{
					$produtos = json_decode($produto_model->getProdutosPorCliente($codigo_cliente));
				}

				//configura a data de ontem
				if(isset($_POST['dia_atual']) && !empty($_POST['dia_atual'])){
					$ontem = getDataAtual(convertDate($_POST['dia_atual']));
				}else{
					$ontem = clone $hoje;
					
					$ontem = $ontem->sub(new DateInterval('P1D'));
				}
				// setando para hora zero
				$ontem->setTime(00,00,00);

				if(isset($_POST['tipo_movimentacao']) && $_POST['tipo_movimentacao'] == 'sm'){
					$transacoes = json_decode($this->obj_movimento->getMovTotal(null, $codigo_cliente, $codigo_produto, true));
					// var_dump($transacoes);
					if($transacoes){
						foreach ($transacoes as $key => $value) {
							if(empty($value->transacoes)){
								if(!in_array($value->codigo_produto, $exceto['produtos'])){
									$i1 = $value->id_contrato;
									$relatorio[$i1]['dados']['id_contrato']            = $value->id_contrato;
									$relatorio[$i1]['dados']['nome']                   = $value->nome_fantasia;
									$relatorio[$i1]['dados']['nome_produto']           = $value->nome_produto;
									$relatorio[$i1]['dados']['data_assinatura']        = $value->data_assinatura;
									$relatorio[$i1]['dados']['data_corte_faturamento'] = $value->data_corte_faturamento;
									$relatorio[$i1]['dados']['status_contrato']        = $value->status_contrato;
								}
							}
						}
					}
				}else{
					// $codigo_cliente = '00250699';
					// $codigo_cliente = 61186680;
					// $codigo_cliente = '07945233';
					$contratos = json_decode($this->obj_contrato->clientesPorCodigo($codigo_cliente, $codigo_produto, true, false));
					if(isset($contratos) && !empty($contratos)){
						foreach ($contratos as $key => $value) {
							if(!$contratos){
								$retorno['codigo'] = 1;
								$retorno['input']  = $_POST;
								$retorno['output'] = $contratos;
								$retorno['mensagem'] = 'Contratos não encontrados';
								throw new Exception(json_encode($retorno), 1);
							}
		
							$i1      = $value->id_contrato;
							$i2      = $value->codigo_produto;
							$mc_ini  = null;
							$mc_fim  = null;
							$mcp_ini = null;
							$mcp_fim = null;
							
							$relatorio[$i1]['dados']['id_contrato']            = $value->id_contrato;
							$relatorio[$i1]['dados']['nome']                   = $value->nome_fantasia;
							$relatorio[$i1]['dados']['nome_produto']           = $value->nome_produto;
							$relatorio[$i1]['dados']['data_assinatura']        = $value->data_assinatura;
							$relatorio[$i1]['dados']['data_corte_faturamento'] = $value->data_corte_faturamento;
							$relatorio[$i1]['dados']['hoje']                   = $hoje->format('d/m/Y');
							$relatorio[$i1]['dados']['ontem']                  = $ontem->format('d/m/Y');
								
							if(!in_array($value->codigo_produto, $exceto['produtos'])){
								$dt_corte_ini = getDataAtual($ontem->format('Y-m').'-'.str_pad($value->data_corte_faturamento, 2, "0", STR_PAD_LEFT));
								$dt_corte_ini->setTime(00,00,00);
								if($dt_corte_ini == $ontem){
									// var_dump($ontem);
									$mc_ini = clone $dt_corte_ini;
									$mc_fim = clone $ontem;
									
									// bloco mes corrente - PM
									$mcp_ini = clone $mc_ini;
									$mcp_ini->sub(new DateInterval('P2M'));
									$mcp_ini->add(new DateInterval('P1D'));
									
									$mcp_fim = clone $ontem;
									$mcp_fim->sub(new DateInterval('P1M'));
		
									// // // bloco 2 meses - SM
									$m2p_ini = clone $mc_ini;
									$m2p_ini->sub(new DateInterval('P3M'));
									$m2p_ini->add(new DateInterval('P1D'));

									$m2p_fim = clone $ontem;
									$m2p_fim->sub(new DateInterval('P2M'));
		
									// // // bloco 3 meses - DM
									$m3p_ini = clone $mc_ini;
									$m3p_ini->sub(new DateInterval('P4M'));
									$m3p_ini->add(new DateInterval('P1D'));

									$m3p_fim = clone $ontem;
									$m3p_fim->sub(new DateInterval('P3M'));

								}elseif($dt_corte_ini < $ontem){
									$mc_ini = $dt_corte_ini;
									$mc_fim = clone $ontem;
								
									// bloco mes corrente - PM
									$mcp_ini = clone $mc_ini;
									$mcp_ini->sub(new DateInterval('P1M'));
									$mcp_fim = clone $ontem;
									$mcp_fim->sub(new DateInterval('P1M'));
		
									// bloco 2 meses - SM
									$m2p_ini = clone $mc_ini;
									$m2p_ini->sub(new DateInterval('P2M'));
									$m2p_fim = clone $ontem;
									$m2p_fim->sub(new DateInterval('P2M'));
		
									// bloco 3 meses - DM
									$m3p_ini = clone $mc_ini;
									$m3p_ini->sub(new DateInterval('P3M'));
									$m3p_fim = clone $ontem;
									$m3p_fim->sub(new DateInterval('P3M'));
								}elseif($dt_corte_ini > $ontem){
									
									$mc_ini = $dt_corte_ini;
									$mc_ini->sub(new DateInterval('P1M'));
									$mc_fim = clone $ontem;
		
									// bloco mes corrente - PM
									$mcp_ini = clone $mc_ini;
									$mcp_ini->sub(new DateInterval('P1M'));
									$mcp_fim = clone $ontem;
									$mcp_fim->sub(new DateInterval('P1M'));
		
									// bloco 2 meses - SM
									$m2p_ini = clone $mc_ini;
									$m2p_ini->sub(new DateInterval('P2M'));
									$m2p_fim = clone $ontem;
									$m2p_fim->sub(new DateInterval('P2M'));
		
									// bloco 3 meses - DM
									$m3p_ini = clone $mc_ini;
									$m3p_ini->sub(new DateInterval('P3M'));
									$m3p_fim = clone $ontem;
									$m3p_fim->sub(new DateInterval('P3M'));
								}
								
								$relatorio[$i1]['dados']['fat_ini'] = $mc_ini->format('Y-m-d');
					            //var_dump($mc_ini->format('Y-m-d'), $mc_fim->format('Y-m-d'));
					            $tarifacoes = json_decode($this->obj_movimento->getMovPeriodo($mc_ini->format('Y-m-d'), $mc_fim->format('Y-m-d'),   $value->codigo_cliente, $value->codigo_produto));
								$pm         = json_decode($this->obj_movimento->getMovPeriodo($mcp_ini->format('Y-m-d'), $mcp_fim->format('Y-m-d'), $value->codigo_cliente, $value->codigo_produto));
								$sm         = json_decode($this->obj_movimento->getMovPeriodo($m2p_ini->format('Y-m-d'), $m2p_fim->format('Y-m-d'), $value->codigo_cliente, $value->codigo_produto));
								$dm         = json_decode($this->obj_movimento->getMovPeriodo($m3p_ini->format('Y-m-d'), $m3p_fim->format('Y-m-d'), $value->codigo_cliente, $value->codigo_produto));
								
								if($tarifacoes){
									foreach ($tarifacoes as $k1 => $v1){
										$i3          = $v1->codigo_modulo;
										$nome_modulo = $v1->nome_modulo;
										if(!in_array($v1->codigo_modulo, $exceto['modulos'])){
											$relatorio[$i1]['tarifacao'][$i2][$i3]['nome_modulo'] = (isset($v1->nome_modulo) && !empty($v1->nome_modulo))?$v1->nome_modulo:null;
											$relatorio[$i1]['tarifacao'][$i2][$i3]['tm'] = $v1;
										}
									}
								}else{
									//$relatorio[$i1]['tarifacao'][$i2]['pst']['nome_modulo'] = ' SEM ATIVIDADE ';
								}
								
								if($pm){
									foreach ($pm as $k1 => $v1){
										$i3 = $v1->codigo_modulo;
										if(!in_array($v1->codigo_modulo, $exceto['modulos'])){
											$relatorio[$i1]['tarifacao'][$i2][$i3]['nome_modulo'] = (isset($v1->nome_modulo) && !empty($v1->nome_modulo))?$v1->nome_modulo:null;
											$relatorio[$i1]['tarifacao'][$i2][$i3]['pm']    = $v1;
										}
									}
								}else{
									//$relatorio[$i1]['tarifacao'][$i2]['pst']['nome_modulo'] = ' SEM ATIVIDADE ';
								}
		
								if($sm){
									foreach ($sm as $k1 => $v1){
										$i3 = $v1->codigo_modulo;
										if(!in_array($v1->codigo_modulo, $exceto['modulos'])){
											$relatorio[$i1]['tarifacao'][$i2][$i3]['nome_modulo'] = (isset($v1->nome_modulo) && !empty($v1->nome_modulo))?$v1->nome_modulo:null;
											$relatorio[$i1]['tarifacao'][$i2][$i3]['sm'] = $v1;
										}
									}
								}else{
									//$relatorio[$i1]['tarifacao'][$i2]['pst']['nome_modulo'] = ' SEM ATIVIDADE ';
								}
								
								if($dm){
									foreach ($dm as $k1 => $v1){
										$i3 = $v1->codigo_modulo;
										if(!in_array($v1->codigo_modulo, $exceto['modulos'])){
											$relatorio[$i1]['tarifacao'][$i2][$i3]['nome_modulo'] = (isset($v1->nome_modulo) && !empty($v1->nome_modulo))?$v1->nome_modulo:null;
											$relatorio[$i1]['tarifacao'][$i2][$i3]['dm'] = $v1;
										}
									}
								}else{
									//$relatorio[$i1]['tarifacao'][$i2]['pst']['nome_modulo'] = ' SEM ATIVIDADE ';
								}
							}
						}
					}
				}
				
				$retorno['codigo']   = 0;
				$retorno['input']    = $_POST;
				$retorno['output']   = $relatorio;
				$retorno['mensagem'] = 'Sucesso';
				throw new Exception(json_encode($retorno), 1);
			}catch (Exception $e) {
				$result = json_decode($e->getMessage());
			}
			require_once ABSPATH . '/views/'.$this->nome_view.'/garantia_receita.php';
		}

		function getRoi(){
			$dados = json_decode($this->modelo->getRoi());
			if($dados){
				$file = TMP_FILES.'roi.csv';
				$fp = fopen($file, 'w');
				foreach ($dados as $key => $value) {
					$value = (array) $value;
					// echo '<pre>';
					// 	var_dump($value);
					// echo '</pre>';
					fputcsv($fp, $value);
				}
				fclose($fp);
			}
			header('Content-Type: application/text');
			//header('Cache-control: private');
			//header('Content-Length: '.filesize($arquivo_full));
			header('Content-Disposition: filename=export.csv');
			readfile($file);
		}

		function viewGrafana(){
			$hoje 	 = clone $this->data_hora_atual;
			$firstday = clone $hoje;
			$firstday->modify('-1 month');
			$firstday->modify('first day of this month');

			$lastday = clone $hoje;
			$lastday->modify('-1 month');
			$lastday->modify('last day of this month');

			$ultimo90dias = clone $hoje;
			$ultimo90dias->modify('-90 day');

			$total_clientes = 0;
			$registros = json_decode($this->obj_contrato->getAllContratos());

			if($registros){
				$contratos = new StdClass();
				foreach ($registros as $key => $value) {
					if($value->codigo_produto != 'ADM0001'){
						$contratos->total++;
						switch ($value->status) {
							case 'ativo':
								$contratos->total_primeiro_dia++;
								$contratos->produto[90][ $value->codigo_produto ]['nome'] = $value->nome_produto;
								$contratos->produto[90][ $value->codigo_produto ]['ativos']['qtde'] += 1;
							break;
							case 'suspenso':
								$contratos->suspenso++;
							break;
							case 'inativo':
								if( $value->inativado_em){
									$inativado_em = getDataAtual($value->inativado_em);
									if($inativado_em <= $ultimo90dias){
										$contratos->produto[90][ $value->codigo_produto ]['nome'] = $value->nome_produto;
										$contratos->produto[90][ $value->codigo_produto ]['inativos']['qtde'] += 1;
									}
									if($inativado_em > $firstday && $inativado_em < $lastday){
										$contratos->inativado++;
									}else{
										$contratos->inativado_ateriores++;
									}
								}else{
									$contratos->semdata++;
								}
							break;
							default:
								$contratos->nda++;
							break;
						}
					}
				}
			}
			require_once ABSPATH.'/template/report/grafana-template.php';
		}

		function viewPonto(){
			ini_set('memory_limit', '1500000M');
			ini_set("pcre.backtrack_limit", "3000000");
			try {
				$pontoModel = $this->load_model('ponto/ponto', true);
				$parametros['tipo_relatorio'] = null;
				if(!isset($_GET['relatorio_ini']) || empty($_GET['relatorio_ini'])){
					$retorno["codigo"]   = 1;
					$retorno["input"]    = $_GET;
					$retorno["output"]   = null;
					$retorno["mensagem"] = "Informe a data de";
					throw new Exception(json_encode($retorno),1);
				}else{
					$parametros['relatorio_ini'] = getDataAtual( $_GET['relatorio_ini'] );
				}

				if( !isset( $_GET['relatorio_fim'] ) || empty( $_GET['relatorio_fim'] ) ){
					$retorno["codigo"]   = 1;
					$retorno["input"]    = $_GET;
					$retorno["output"]   = null;
					$retorno["mensagem"] = "Informe a data até";
					throw new Exception(json_encode($retorno),1);
				}else{
					$parametros['relatorio_fim'] = getDataAtual( $_GET['relatorio_fim'] );
				}
				
				if( isset( $_GET['tipo_relatorio'] ) && !empty( $_GET['tipo_relatorio'] ) ){
					switch ( $_GET['tipo_relatorio'] ) {
						case 'periodo':
							$parametros['tipo_relatorio'] = 'periodo';
						break;
						default:
							$parametros['tipo_relatorio'] = 'fechamento';
						break;
					}
				}else{
					$parametros['tipo_relatorio'] = 'fechamento';
				}

				if( isset( $_GET['funcionario'] ) && !empty( $_GET['funcionario'] ) && is_numeric( $_GET['funcionario'] ) ){
					$parametros['id_usuario'] = $_GET['funcionario'];
				}

				if( isset( $_GET['agrupar'] ) && !empty( $_GET['agrupar'] ) ){
					switch ( $_GET['agrupar'] ) {
						case 'funcionario':
							$parametros['agrupar'] = 'funcionario';
						break;
						default:
							$parametros['agrupar'] = 'departamento';
						break;
					}
				}else{
					$parametros['agrupar'] = 'departamento';
				}

				if( isset( $_GET['departamento'] ) && !empty( $_GET['departamento'] ) ){
					$parametros['departamento'] = $_GET['departamento'];
				}

				switch ( $parametros['agrupar'] ) {
					case 'funcionario':
						if( isset( $parametros['id_usuario'] ) && !empty( $parametros['id_usuario'] ) && is_numeric( $parametros['id_usuario'] ) ){
							$parametros['id_usuario']     = $parametros['id_usuario'];
							$usuarios 					  = json_decode( $pontoModel->getJornadaUsuarioById( $parametros['id_usuario'] ) );	
						}else{
							$retorno["codigo"]   = 1;
							$retorno["input"]    = $_GET;
							$retorno["output"]   = null;
							$retorno["mensagem"] = "Informe o funcionario 1";
							throw new Exception(json_encode($retorno),1);
						}
						$this->obj_ponto = new RhPonto( $this, $parametros['id_usuario'] ); //jornada noturna
						$this->obj_ponto->gerarEspelho( $parametros['relatorio_ini'], $parametros['relatorio_fim'], $parametros['tipo_relatorio'] );
						
						$dicionario   = $this->obj_ponto->mapa_ocorrencias;
						$user   = $this->obj_ponto->user;
						$dados  = $this->obj_ponto->calendario['diario'];
						$pausas = $this->obj_ponto->matriz_calendario['diario']['pausa'];
						$extras = $this->obj_ponto->matriz_calendario['diario']['extra'];
						$pontos = $this->obj_ponto->matriz_calendario['diario']['marcacoes'];
						$totais = $this->obj_ponto->calendario['total'];
						require_once ABSPATH.'/template/ponto/espelho-template.php';
					break;
					case 'departamento':
						if( isset( $_GET['departamento'] ) && !empty( $_GET['departamento'] ) ){
							$usuarios 					= json_decode( $pontoModel->getJornadaUsuarioByDepartamento( $parametros['departamento'] ) );
							if( $usuarios ){
								$resumo = new StdClass();
								foreach ($usuarios as $key => $value) {
									$this->obj_ponto = new RhPonto( $this, $value->id_usuario ); //jornada noturna
									$this->obj_ponto->gerarEspelho( $parametros['relatorio_ini'], $parametros['relatorio_fim'], $parametros['tipo_relatorio'] );
									$user = $this->obj_ponto->user;
									$i1 = $user->id;
									$resumo->user[$i1]['dados'] 	  = $user;
									$resumo->user[$i1]['data_inicio'] = $this->obj_ponto->data_inicio->format('d/m/Y');
									$resumo->user[$i1]['data_fim'] 	  = $this->obj_ponto->data_fim->format('d/m/Y');
									$resumo->user[$i1]['id_anexo'] 	  = $this->obj_ponto->ultimo_fechamento['id_anexo'];
									$resumo->user[$i1]['ponto'] 	  = $this->obj_ponto->calendario['total'];
								}
								require_once ABSPATH.'/template/ponto/espelho-resumo-template.php';
							}
						}else{
							$retorno["codigo"]   = 1;
							$retorno["input"]    = $_GET;
							$retorno["output"]   = null;
							$retorno["mensagem"] = "Informe o departamento";
							throw new Exception(json_encode($retorno),1);
						}
					break;
					default:
						$retorno["codigo"]   = 1;
						$retorno["input"]    = $_GET;
						$retorno["output"]   = null;
						$retorno["mensagem"] = "Informe o tipo de relatório";
					break;
				}
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}

		function createFechamentoPdf(){
			$dados = filter_input_array( INPUT_POST, FILTER_DEFAULT );
			if( !$dados ){
				$dados = filter_input_array(INPUT_GET, FILTER_DEFAULT);
			}
			$relatorio_ini 	 = getDataAtual($dados['periodo_ini']);
			$relatorio_fim 	 = getDataAtual($dados['periodo_fim']);
			$dados_user		 = json_decode($dados['dados_usuario']);
			$resumo_jornada  = json_decode($dados['resumo_jornada']);
			if( base64_decode( $dados['json_fechamento'] ) ){
				$json_fechamento =  json_decode(  base64_decode( $dados['json_fechamento'] ) );
			}else{
				$json_fechamento = json_decode( $dados['json_fechamento'] );
			}
			$dados  		 = $json_fechamento->diario;
			$totais 		 = $json_fechamento->total;
			require_once ABSPATH.'/template/ponto/espelho-fechamento.php';
		}
	}