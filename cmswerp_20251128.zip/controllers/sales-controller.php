<?php
	class SalesController extends MainController{
		protected $module = 'sales', $model_contratos, $obj_api;

		function __construct($parametros = null){
			$this->nome_modulo = 'sales';
			parent::__construct($parametros);
		}

		function index(){
			// $this->propostasList();
		}

		function ifview(){
			$records  = json_decode($this->modelo->getIf(null, false, true));
			require_once ABSPATH . '/views/'.$this->module.'/if-list-view.php';			
		}

		function ifdetalhe(){
			// var_dump($this->obj_api);
			// $parametros['cnpj'] = '00.250.699/0001-48';
			// $dados_cnpj = json_decode($this->obj_api->action('cnpj', 'cnpj', 'consultar', $parametros));
			if($this->parametros[1]){
				$records = json_decode($this->modelo->contratosAtivos($this->parametros[1], false, true));
				if(!$records[0]->mes_reajuste){
					$data_assinatura = new Datetime($records[0]->data_assinatura);
					$mes_reajuste = $data_assinatura->format('m');
				}else{
					$mes_reajuste = $records[0]->mes_reajuste;
				}
			}
			require_once ABSPATH . '/views/'.$this->module.'/if-detalhe-view.php';
		}
		
		function comissoes(){
			try{
				$dados_if = json_decode($this->modelo->getIf($this->parametros[1]));
				echo '<pre>';
					var_dump($this->parametros, $dados_if);
				echo '</pre>';
			}catch(Exception $e){
				$e->getMessage();
			}
			require_once ABSPATH . '/views/'.$this->module.'/comissoes-list-view.php';
		}

		// inclusao do reembolso
		function reembolso_list(){
			try{
				$dados_if = json_decode($this->modelo->getIf($this->parametros[1]));
				echo '<pre>';
					var_dump($this->parametros, $dados_if);
				echo '</pre>';
			}catch(Exception $e){
				$e->getMessage();
			}
			require_once ABSPATH . '/views/'.$this->module.'/reembolso-list-view.php';
		}

		function reembolso_detalhe(){
			try{
				$dados_if = json_decode($this->modelo->getIf($this->parametros[1]));
				echo '<pre>';
					var_dump($this->parametros, $dados_if);
				echo '</pre>';
			}catch(Exception $e){
				$e->getMessage();
			}
			require_once ABSPATH . '/views/'.$this->module.'/reembolso-detalhe-view.php';
		}


		function getDadosCnpjJson(){
			$this->obj_api = new Api($this);
			$param['cnpj'] = $_POST['cnpj'];
			$param['cnpj'] = '07003180000104';
			$dados_cnpj    = json_decode($this->obj_api->action('cnpj', 'cnpj', 'consultar', $param));
			if($dados_cnpj){
				$dados_cnpj->output->cep = removeCaracteres($dados_cnpj->output->cep, 'char');
				echo json_encode($dados_cnpj);
			}else{
				echo false;
			}
		}

		function save(){
			$contrato_adm    = null;
			$id_contrato_adm = null;
			$ultima_if = json_decode($this->modelo->getLastIf());
			if(isset($ultima_if[0]->numero_contrato) && $ultima_if[0]->numero_contrato > 0){
				$_POST['numero_contrato'] = $ultima_if[0]->numero_contrato + 1;
			}else{
				$_POST['numero_contrato'] = 1;
			}
			
			if(isset($_POST['cnpj']) && !empty($_POST['cnpj'])){
				$_POST['cnpj'] = removeCaracteres($_POST['cnpj'], 'char', null);
			}

			if(empty($_POST['nome_fantasia'])){
				$_POST['nome_fantasia'] = $_POST['razao_social'];
			}

			if($_POST['status'] == 'inativo' || $_POST['status'] == 'suspenso'){
				$_POST['inativado_em'] = $this->data_hora_atual->format('Y-m-d H:i:s');
			}
			
			if(!empty($_POST['data_assinatura']) && $_POST['data_assinatura']!= '00/00/0000'){
				$_POST['data_assinatura'] = convertDate($_POST['data_assinatura'], true, null);
			}

			if(!empty($_POST['data_reajuste']) && $_POST['data_reajuste']!= '00/00/0000'){
				$_POST['data_reajuste'] = convertDate($_POST['data_reajuste'], true, null);
			}else{
				//caso a data de reajuste não seja configurada ela será igual a data de assinatura.
				$_POST['data_reajuste'] = $_POST['data_assinatura'];
			}

			$_POST['codigo_cliente']              = substr(removeCaracteres($_POST['cnpj'], 'char', null), '0', '8');
			$_POST['cep']                         = removeCaracteres($_POST['cep'], 'char', null);
			$_POST['isento_de']                   = (!empty($_POST['isento_de']) && $_POST['isento_de'] != '00/00/0000')?convertDate($_POST['isento_de'], true, null):null;
			$_POST['isento_ate']                  = (!empty($_POST['isento_ate']) && $_POST['isento_ate']!= '00/00/0000')?convertDate($_POST['isento_ate'], true, null):null;
			$_POST['data_primeiro_faturamento']   = (!empty($_POST['data_primeiro_faturamento']) && $_POST['data_primeiro_faturamento']!= '00/00/0000')?convertDate($_POST['data_primeiro_faturamento'], true, null):null;
			$_POST['inicio_producao_em']          = (!empty($_POST['inicio_producao_em']) && $_POST['inicio_producao_em'] != '00/00/0000')?convertDate($_POST['inicio_producao_em'], true, null):null;
			$_POST['ultima_data_demo']            = (!empty($_POST['ultima_data_demo']) && $_POST['ultima_data_demo']!= '00/00/0000')?convertDate($_POST['ultima_data_demo'], true, null):null;
			$_POST['carencia_de_uso']             = (!empty($_POST['carencia_de_uso']) && $_POST['carencia_de_uso']!= '00/00/0000')?convertDate($_POST['carencia_de_uso'], true, null):null;
			$_POST['primeira_parcela_em'] = (!empty($_POST['primeira_parcela_em']) && $_POST['primeira_parcela_em']!= '00/00/0000')?convertDate($_POST['primeira_parcela_em'], true, null):null;
			$_POST['valor_implantacao'] = removeCaracteres($_POST['valor_implantacao'], 'moeda2', null);
			$_POST['hospedagem_mensal'] = removeCaracteres($_POST['hospedagem_mensal'], 'moeda2', null);
			$_POST['licenca_uso_mensal'] = removeCaracteres($_POST['licenca_uso_mensal'], 'moeda2', null);
			$_POST['data_corte_faturamento'] = (!empty($_POST['data_corte_faturamento']))?$_POST['data_corte_faturamento']:01;

			if(count($_POST) > 0){
				$this->modelo->setTable('instrucao_faturamento');
				$return = $this->modelo->save($_POST, $this->parametros[1]);
				header('location: /sales/comissoes/contrato/'.$return);
			}else{
				echo 'Dados do conrtato não informados';
			}
		}
	}