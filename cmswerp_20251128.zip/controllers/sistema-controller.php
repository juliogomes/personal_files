<?php
    class SistemaController extends MainController{
        function __construct( $parametros = null ){
            $this->setModulo( 'sistema' );
            $this->setView( 'sistema' );
            parent::__construct( $parametros, false  );
        }
        
        function index(){}

        function modulos(){
            $lista_modulos = json_decode( $this->modelo->getAllModulos() );
            require_once ABSPATH.'/views/'.$this->nome_view.'/modulos-view.php';
        }
        
        function logsTarifacao(){
            set_time_limit(7200);
            $path = ABSPATH.DS.'logs';
            $codigo_cliente  = '18394228';
            $produto_cliente = 'SPBALL';
            $data_ini       = getDataAtual('2024-05-01');
            $data_fim       = getDataAtual('2024-05-08');
            $diff           = $data_ini->diff( $data_fim );
            $arquivos       = scandir( $path );
            $inicio         = clone $data_ini;
            for ( $i=0; $i <= $diff->days; $i++ ) {
                $file_name = 'msg_tarifacao_'.$inicio->format('Ymd').'.txt';
                foreach ( $arquivos as $arquivo ) {
                    // Ignorar "." e ".."
                    if( $arquivo == $file_name ){
                        echo 'Processando arquivo '.$file_name.'<br>';
                        // Abrir o arquivo para leitura
                        $handle = fopen( $path.DS.$file_name, "r");
                        if ( $handle ) {
                            // Ler o arquivo linha por linha
                            while ( ( $linha = fgets( $handle ) ) !== false ) {
                                $obj = json_decode( $linha );
                                if( $obj->ispb == $codigo_cliente && $obj->produto == $produto_cliente ){
                                    echo $obj->modulo.';'.$obj->login.';'.$obj->data.';'.$obj->dados->count.'<br>';
                                }
                            }
                            // Fechar o arquivo
                            fclose($handle);
                        } else {
                            // Erro ao abrir o arquivo
                            echo "Não foi possível abrir o arquivo.";
                        }
                    }
                }
                $inicio->add( new DateInterval( 'P1D' ) );
            }
        }
    }