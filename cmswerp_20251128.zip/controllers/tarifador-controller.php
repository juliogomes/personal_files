<?php
	set_time_limit(7200);
	class TarifadorController extends MainController{
		protected $meses_fat;
		protected $contratos;
		protected $mov_controller;
		protected $faturamento;
		protected $obj_mov;
		protected $obj_movimento;
		protected $hoje;
		function __construct($parametros){
			$this->setModulo('tarifador');
			$this->setView('tarifador');
			parent::__construct($parametros);
			$db_movimento['db_name'] = DB_NAME_MOVIMENTO;
			$this->faturamento   = new Faturamento($this);
			$this->contratos     = $this->load_model('contratos/contratos', true);
			$this->modelo->setDb(new Db($db_movimento));
			$this->obj_movimento = $this->load_model('movimento/movimento', true);
			$this->obj_movimento->setDb(new Db($db_movimento));
			$this->meses_fat     = json_decode($this->obj_movimento->getMesesFat());
		}

		function diario(){
			$hoje = $this->data_hora_atual->format('d/m/Y');
			require_once ABSPATH . '/views/'.$this->nome_view.'/tarifador-diario.php';
		}

		function diariojson(){
			if(!isset($_GET['data_faturamento']) || empty($_GET['data_faturamento'])){
				$data_atual = $this->data_hora_atual->format('Y-m-d');
			}else{
				$data_atual = convertDate($_GET['data_faturamento']);
			}
			$lista_contratos = null;
			$x = 0;
			$contratos  = json_decode( $this->contratos->getCustomContratos() );
			$records    = json_decode( $this->modelo->getMovDiario($data_atual) );
			if($contratos && $records){
				foreach($contratos as $key => $value){
					foreach ($records as $chave => $valor){
						if($value->codigo_cliente == $valor->codigo_cliente){
							$lista_contratos[$chave]->razao_social = $value->razao_social;
							$lista_contratos[$chave]->nome_fantasia = $value->nome_fantasia;
						}
						if($value->codigo_produto == $valor->codigo_produto){
							$lista_contratos[$chave]->nome_produto = $value->nome_produto;
						}
						if($value->codigo_modulo == $valor->codigo_modulo ){
							$lista_contratos[$chave]->descricao = $value->descricao;
						}
						$lista_contratos[$chave] = $valor;
					}
				}
			}else{
				$lista_contratos = $records;
			}
			require_once ABSPATH . '/views/'.$this->nome_view.'/tarifador-diario-json.php';
		}

		function analitico(){
			$periodo_atual = $this->data_hora_atual->format('Y-m');
			require_once ABSPATH . '/views/'.$this->nome_view.'/tarifador-analitico.php';
		}

		function analiticojson(){
			if(isset($this->parametros[0]) && $this->parametros[0] == 'ano_mes'){
				$arr_date = explode('-', $this->parametros[1]);
				$ano = $arr_date[0];
				$mes = $arr_date[1];
			}else{
				$ano = $this->data_hora_atual->format('Y');
				$mes = $this->data_hora_atual->format('m');
			}
			$dados_faturamento = $this->faturamento->getAnaliticoPorPeriodo($ano, $mes, 'relatorio');
			require_once ABSPATH . '/views/'.$this->nome_view.'/tarifador-analitico-json.php';
		}

		function cliente(){
			require_once ABSPATH . '/views/'.$this->nome_view.'/tarifador-cliente.php';
		}

		function clientejson(){
			$lista_contratos = null;
			$x = 0;
			$contratos = json_decode($this->contratos->getCustomContratos());
			if(isset($_POST['periodo']) && !empty($_POST['periodo'])){
				$arr_date = explode('/', $_POST['periodo']);
				$start = $arr_date[1].'-'.$arr_date['0'].'-'.'01';
				$end = $arr_date[1].'-'.$arr_date['0'].'-'.cal_days_in_month(CAL_GREGORIAN, $arr_date[0], $arr_date[1]);
			}else{
				$start = $this->data_hora_atual->format('Y-m-01');
				$end   = $this->data_hora_atual->format('Y-m').'-'.cal_days_in_month(CAL_GREGORIAN, $this->data_hora_atual->format('m'), $this->data_hora_atual->format('Y'));
			}
			
			$records = json_decode($this->modelo->getSumarizeMovDiario($start, $end));
			if($contratos){
				foreach($contratos as $key => $value){
					$x = 0;
					foreach ($records as $chave => $valor){
						if($value->codigo_cliente == $valor->codigo_cliente)	{
							$lista_contratos[$x]->razao_social = $value->razao_social;
							$lista_contratos[$x]->nome_fantasia = $value->nome_fantasia;
						}
						if($value->codigo_produto == $valor->codigo_produto){
							$lista_contratos[$x]->nome_produto = $value->nome_produto;
						}
						if($value->codigo_modulo == $valor->codigo_modulo ){
							$lista_contratos[$x]->descricao = $value->descricao;
						}
						$lista_contratos[$x] = $valor;
						$x++;
					}
				}
			}else{
				$lista_contratos = $records;
			}
			require_once ABSPATH . '/views/'.$this->nome_view.'/tarifador-cliente-json.php';
		}
	}