<?php
    class TasksController extends MainController{
		protected 
            $module = 'tasks', $lista_perfis, $perfil_model;
        public
            $obj_task;
        function __construct( $parametros = null, $do_login = true ){

            if( isset( $parametros['task'] ) ){
                $tasks = $parametros['task'];
            }else{
                $tasks = null;
            }
            $this->nome_modulo = 'tasks';
            parent::__construct( $parametros, 'tasks', $do_login );
            $this->obj_task = new Tasks( $this, $tasks );
        }

        function index(){
            $this->listar();
        }

        function listar(){
            if ( $this->cl_permissoes->alcada_acesso >= 4 ){
                $listar_tasks = json_decode($this->modelo->getTasks());
                if ( $listar_tasks ) {
                    $array = null;
                    foreach ($listar_tasks as $key => $value) {
                        $dateTimeIni = new DateTime($value->periodo_ini);
                        $dateTimeFim = new DateTime($value->periodo_fim);
                        $dataFormatadaIni = $dateTimeIni->format('d/m/Y');
                        if ( $value->tempo_indeterminado == 0 ){
                            $dataFormatadaFim = 'Tempo indeterminado';
                        }else{
                            $dataFormatadaFim = $dateTimeFim->format('d/m/Y');
                        }
                        if ( $value->ativo == 0 ){
                            $ativo = 'Inativo';
                        }else{
                            $ativo = 'Ativo';
                        }
                        $i = $value->id;
                        $array[$i]['id'] = $value->id;
                        $array[$i]['codigo'] = $value->codigo;
                        $array[$i]['grupo'] = $value->grupo;
                        $array[$i]['nome'] = $value->nome;
                        $array[$i]['descricao'] = $value->descricao;
                        $array[$i]['modulo_origem'] = $value->modulo_origem;
                        $array[$i]['periodo_ini'] = $dataFormatadaIni;
                        $array[$i]['periodo_fim'] = $dataFormatadaFim;
                        $array[$i]['tipo_frequencia'] = $value->tipo_frequencia;
                        $array[$i]['frequencia'] = $value->frequencia;
                        $array[$i]['tempo_indeterminado'] = $value->tempo_indeterminado;
                        $array[$i]['ultima_execucao'] = $value->ultima_execucao;
                        $array[$i]['info_execucao'] = $value->info_execucao;
                        $array[$i]['ativo'] = $ativo;
                        $array[$i]['alterado_por'] = $value->alterado_por;
                        $array[$i]['alterado_em'] = $value->alterado_em;
                    }                
                }
            }else{
                echo 'sem permissao de acesso';
                exit;
            }
            require_once ABSPATH . '/views/tasks/index.php';
        }

        function detalhe(){
            if ( $this->cl_permissoes->alcada_acesso >= 4 ){
                if ( isset( $this->parametros[1] ) && is_numeric( $this->parametros[1] ) && !empty( $this->parametros[1] ) ){
                    $listar_tasks = json_decode($this->modelo->getTasks( $this->parametros[1] ));
                }
            }else{
                echo 'sem permissao de acesso';
                exit;
            }
            require_once ABSPATH . '/views/tasks/detalhe-view.php';

        }

        function adcDiaSemana(){
            try {
                if ( isset( $this->parametros[0] ) && !empty( $this->parametros[0] ) && is_numeric( $this->parametros[0] ) ){
                    if ( !isset( $_POST ) || empty( $_POST ) ){
                        $retorno['codigo'] = 1;
                        $retorno['mensgem'] = "Nenhum dia selecionado!";
                        throw new Exception( json_encode( $retorno ), 1);
                    }else{
                        $dias_semana = implode( ',', $_POST);
                    }

                    $lista_task = json_decode($this->modelo->getTasks( $this->parametros[0] ));
                    foreach ($lista_task as $key => $value) {
                        $codigo = $value->codigo;
                        $nome = $value->nome;
                    }

                    if ( $this->cl_permissoes->alcada_acesso >= 4 ){
                        $param_save['tipo_frequencia'] = $dias_semana;
                        $param_save['codigo'] = $codigo;
                        $param_save['nome'] = $nome;
                        $param_save['tipo_execucao'] = 'semanal';
                        $param_save['frequencia'] = '00:10';
                        $is_save = $this->modelo->save( $param_save, $this->parametros[0] );                   
                        if ( $is_save ){
                            $retorno['codigo']   = 0;
                            $retorno['output']   = $is_save;
                            $retorno['mensagem'] = 'Sucesso ao atualizar datas!';
                            throw new Exception( json_encode( $retorno ), 1);
                        }else{
                            $retorno['codigo']   = 1;
                            $retorno['mensagem'] = 'Erro ao tentar atualizar datas!';
                            throw new Exception( json_encode( $retorno ), 1);
                        }
                    }else{
                        echo 'Sem permissão para acessar!';
                        exit;
                    }
                }else{
                    if ( !isset( $_POST ) || empty( $_POST ) ){
                        $retorno['codigo'] = 1;
                        $retorno['mensgem'] = "Nenhum dia selecionado!";
                        throw new Exception( json_encode( $retorno ), 1);
                    }else{
                        $dias_semana = implode( ',', $_POST );
                    }

                    if ( $this->cl_permissoes->alcada_acesso >= 4 ){
                        $param_save['tipo_frequencia'] = $dias_semana;
                        $param_save['codigo'] = 0;
                        $param_save['nome'] = '';
                        $param_save['tipo_execucao'] = '';
                        $param_save['frequencia'] = '';
                        $is_save = $this->modelo->save($param_save);                    
                        if ( $is_save ){
                            $retorno['codigo']   = 0;
                            $retorno['output']   = $is_save;
                            $retorno['mensagem'] = 'Sucesso ao salvar datas!';
                            throw new Exception( json_encode( $retorno ), 1);
                        }else{
                            $retorno['codigo']   = 1;
                            $retorno['mensagem'] = 'Erro ao tentar salvar datas!';
                            throw new Exception( json_encode( $retorno ), 1);
                        }
                    }else{
                        echo 'Sem permissão para acessar!';
                        exit;
                    }
                }
            } catch (Exception $e) {
                echo $e->getMessage();
            }
        }

        function adcTask(){
            try {
                if ( !isset( $_POST['nome'] ) || empty( $_POST['nome'] ) ){
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] =  'Campo nome não informado!';
                    throw new Exception( json_encode( $retorno ), 1);
                }

                if ( !isset( $_POST['codigo'] ) || empty( ( $_POST['codigo'] ) ) ){
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] =  'Campo codigo não informado!';
                    throw new Exception( json_encode( $retorno ), 1);
                }

                if ( !isset( $_POST['grupo'] ) || empty( ( $_POST['grupo'] ) ) ){
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] =  'Campo grupo não informado!';
                    throw new Exception( json_encode( $retorno ), 1);
                }

                if ( !isset( $_POST['data_ini'] ) || empty( ( $_POST['data_ini'] ) ) ){
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] =  'Campo Data Inicial não informado!';
                    throw new Exception( json_encode( $retorno ), 1);
                }

                if ( !isset( $_POST['modulo_origem'] ) || empty( ( $_POST['modulo_origem'] ) ) ){
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] =  'Campo Módulo não informado!';
                    throw new Exception( json_encode( $retorno ), 1);
                }                

                if ( !isset( $_POST['tipo_exec'] ) || empty( ( $_POST['tipo_exec'] ) ) ){
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] =  'Campo Tipo Execução não informado!';
                    throw new Exception( json_encode( $retorno ), 1);
                }
                
                if ( !isset( $_POST['descricao'] ) || empty( ( $_POST['descricao'] ) ) ){
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] =  'Campo Descrição não informado!';
                    throw new Exception( json_encode( $retorno ), 1);
                }

                if ( isset( $_POST['tipo_tempo'] ) && $_POST['tipo_tempo'] == 'hora' ){
                    $tipo_frequencia = 'hora';
                    $hora = $_POST['frequencia_hora'];
                    $minuto = '';
                }else if ( isset( $_POST['tipo_tempo'] ) && $_POST['tipo_tempo'] == 'minutos' ){
                    $tipo_frequencia = 'minutos';
                    $hora = '';
                    if ( $_POST['frequencia_min'] > 0 && $_POST['frequencia_min'] < 59 ){
                        $minuto = $_POST['frequencia_min'];
                    }else{
                        $retorno['codigo'] = 1;
                        $retorno['mensagem'] =  'Formato inválido para o campo minutos, digite apenas números de 0 a 59.';
                        throw new Exception( json_encode( $retorno ), 1);    
                    }
                }else if( isset($_POST['tipo_exec']) && $_POST['tipo_exec'] == 'semanal' || $_POST['tipo_exec'] == 'diario' ){
                    $lista_task = json_decode($this->modelo->getTasks( $this->parametros[0] ));
                    foreach ($lista_task as $key => $value) {
                        $tipo_frequencia = $value->tipo_frequencia;
                    }
                }else{
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] = 'Erro na gravação do campo tipo_tempo e tipo_exec';
                    throw new Exception( json_encode( $retorno ), 1);
                }

                if ( $this->cl_permissoes->alcada_acesso >= 4 ){
                    $param_save['nome']                = $_POST['nome'];
                    $param_save['codigo']              = $_POST['codigo'];
                    $param_save['grupo']               = $_POST['grupo'];
                    $param_save['modulo_origem']       = $_POST['modulo_origem'];
                    $param_save['tipo_execucao']       = $_POST['tipo_exec'];
                    $param_save['tipo_frequencia']     = $tipo_frequencia;
                    $param_save['tempo_indeterminado'] = $_POST['tempo_indeterminado'];
                    $param_save['periodo_ini']         = convertDate($_POST['data_ini']);                   
                    if ( $_POST['tempo_indeterminado'] == 0 ){
                        $periodo_fim = '';
                    }else{
                        $periodo_fim = convertDate($_POST['data_fim']);
                    }
                    $param_save['periodo_fim']         = $periodo_fim;
                    $param_save['descricao']           = $_POST['descricao'];

                    if ( !empty($hora) ){
                        $param_save['frequencia'] = $hora;
                    }else if ( !empty($minuto) ){
                        $param_save['frequencia'] = $minuto;
                    }
                    
                    if ( isset( $this->parametros[0] ) && !empty( $this->parametros[0] ) && is_numeric( $this->parametros[0] ) ){
                        $is_save = $this->modelo->save($param_save , $this->parametros[0]);
                        if ( $is_save ){
                            $retorno['codigo'] = 0;
                            $retorno['output']   = $is_save;
                            $retorno['mensagem'] = 'Sucesso ao atualizar!';
                            throw new Exception( json_encode( $retorno ), 1);
                        }else{
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Erro ao tentar atualizar tarefa!';
                            throw new Exception( json_encode( $retorno ), 1);
                        }
                    }else{
                        $is_save = $this->modelo->save($param_save);
                        if ( $is_save ){
                            $retorno['codigo'] = 0;
                            $retorno['output'] = $is_save;
                            $retorno['mensagem'] = 'Sucesso';
                            throw new Exception( json_encode( $retorno ), 1);
                        } else {
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Erro ao tentar salvar nova tarefa!';
                            throw new Exception( json_encode( $retorno ), 1);
                        }
                    }
                }else{
                    echo 'Sem permissão para acessar!';
                    exit;
                }
            } catch (Exception $e) {
                echo $e->getMessage();
            }
        }

        function deletarTask(){
            try {
                $dados_req = $_POST['dados_req'];
                if ( !isset( $dados_req ) || empty( $dados_req ) ){
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] = 'Nenhum id selecionado!';
                    throw new Exception( json_encode( $retorno ), 1);
                }else{
                    $dados_req = $_POST['dados_req'];
                }
                foreach ($dados_req as $key => $value) {
                    $id = $value['value'];
                    if ( !isset( $id ) && empty( $id ) && !is_numeric( $id )){
                        $retorno['codigo'] = 1;
                        $retorno['mensagem'] = 'Não foi possivel identifar ID para deletar!';
                        throw new Exception( json_encode( $retorno ), 1);
                    }
                    $param_save['deleted'] = 1;
                    if ( $this->cl_permissoes->alcada_acesso >= 4 ){
                        $is_save = $this->modelo->save($param_save, $id);
                        if ( !$is_save ){
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Erro ao tentar deletar task!';
                            throw new Exception( json_encode( $retorno ), 1);
                        }    
                    }else{
                        echo 'Sem permissão para acessar!';
                        exit;
                    }
                }
                $retorno['codigo'] = 0;
                $retorno['mensagem'] = 'Sucesso ao deletar!';
                throw new Exception( json_encode( $retorno ), 1);
            } catch (Exception $e) {
                echo $e->getMessage();
            }
        }

        function inativarTask(){
            try {
                $dados_req = $_POST['dados_req'];
                if ( !isset( $dados_req ) || empty( $dados_req ) ){
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] = 'Nenhum id selecionado!';
                    throw new Exception( json_encode( $retorno ), 1);
                }else{
                    $dados_req = $_POST['dados_req'];
                }
                foreach ($dados_req as $key => $value) {
                    $id = $value['value'];
                    if ( !isset( $id ) && empty( $id ) && !is_numeric( $id )){
                        $retorno['codigo'] = 1;
                        $retorno['mensagem'] = 'Não foi possivel identifar ID para inativar!';
                        throw new Exception( json_encode( $retorno ), 1);
                    }

                    if ( $this->cl_permissoes->alcada_acesso >= 4 ){
                        $param_save['ativo'] = 0;
                        $this->modelo->setTable('tasks');
                        $is_save = $this->modelo->save($param_save, $id);
                        if ( !$is_save ){
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Erro ao tentar inativar task!';
                            throw new Exception( json_encode( $retorno ), 1);
                        }
                    }else{
                        echo 'Sem permissão para acessar!';
                        exit;
                    }
                }
                $retorno['codigo'] = 0;
                $retorno['mensagem'] = 'Sucesso ao inativar!';
                throw new Exception( json_encode( $retorno ), 1);
            } catch (Exception $e) {
                echo $e->getMessage();
            }
        }

        function ativarTask(){
            try {
                $dados_req = $_POST['dados_req'];
                if ( !isset( $dados_req ) || empty( $dados_req ) ){
                    $retorno['codigo'] = 1;
                    $retorno['mensagem'] = 'Nenhum id selecionado!';
                    throw new Exception( json_encode( $retorno ), 1);
                }else{
                    $dados_req = $_POST['dados_req'];
                }
                foreach ($dados_req as $key => $value) {
                    $id = $value['value'];
                    if ( !isset( $id ) && empty( $id ) && !is_numeric( $id )){
                        $retorno['codigo'] = 1;
                        $retorno['mensagem'] = 'Não foi possivel identifar ID para ativar!';
                        throw new Exception( json_encode( $retorno ), 1);
                    }
                    if ( $this->cl_permissoes->alcada_acesso >= 4 ){
	                    $param_save['ativo'] = 1;
                        $is_save = $this->modelo->save($param_save, $id);
                        if ( !$is_save ){
                            $retorno['codigo'] = 1;
                            $retorno['mensagem'] = 'Erro ao tentar ativar task!';
                            throw new Exception( json_encode( $retorno ), 1);
                        }
                    }else{
                        echo 'Sem permissão para acessar!';
                        exit;
                    }
                }
                $retorno['codigo'] = 0;
                $retorno['mensagem'] = 'Sucesso ao inativar!';
                throw new Exception( json_encode( $retorno ), 1);                
            } catch (Exception $e) {
                echo $e->getMessage();
            }
        }
    }