<?php
class uploadsController extends MainController{
	function __construct($parametros = null){
		$this->setModulo('uploads');
		$this->setView('uploads');
		parent::__construct($parametros, null, false);
	}

	function getRps(){
		if(isset($this->parametros[0]) && !empty($this->parametros[0])){
			$path = UP_ABSPATH.'notas-fiscais'.DS.$this->parametros[0];
			if(file_exists($path)){
				require_once($path);
			}else{
				echo 'Arquivo '.$this->parametros[0].' não existe';
			}
		}else{
			echo 'Nome do arquivo não informado';
		}
	}
}
?>