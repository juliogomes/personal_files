<?php
class UsuariosController extends MainController{
	protected $module = 'usuarios', $lista_perfis, $perfil_model;
	function __construct($parametros = false){
		$this->nome_modulo = 'usuarios';
		parent::__construct($parametros);
		$this->perfil_model = $this->load_model('perfis/perfis', true);
		$this->lista_perfis = json_decode($this->perfil_model->getPerfis());
	}

	function index(){
		$this->lista();
	}

	function lista(){
		$records  = json_decode($this->modelo->getAllUser());
		if(isset($records) && is_array($records)){
			foreach ($records as $key => $value) {			
				$boss[$value->id] = json_decode($this->modelo->getAllUser($value->boss));	
			}
		}	
		
		require_once ABSPATH . '/views/usuarios/usuarios-view.php';
	}

	function detalhe(){
		$lista_usuarios = json_decode( $this->user_model->getAllUser() );
		$lista_empresa  = json_decode( $this->modelo->getEmpresasCm() );
		if(!empty($this->parametros[1])){
			$records = json_decode($this->modelo->getUser($this->parametros[1]));
			$jornada = json_decode($this->modelo->getUsuarioJornada($this->parametros[1]));			
			$usuario = json_decode($this->modelo->getUser($this->parametros[1]));
			if(isset($records[0]->permissoes)){
				$permissoes = json_decode($records[0]->permissoes);
				if(isset($permissoes)){
					$lista_permissoes['nome'] = $permissoes->nome;
					foreach ($permissoes->modulos as $key => $value) {
						if($value->permissoes > 0 || $_SESSION['cmswerp']['userdata']->master == 1){
						    if(isset($value->grupo) && !empty($value->grupo)){
								$i1 = $value->grupo;
								$i2 = $value->id;
								$lista_permissoes['modulos'][$i1][$i2] = $value;							
							}
							// ksort($lista_permissoes['modulos'][$i1][$i2]);
						}
					}
					ksort($lista_permissoes['modulos']);
				}
			}
		}
		require_once ABSPATH . '/views/usuarios/usuarios-detalhe-view.php';
	}

	function save(){
		try {
			if(!is_numeric($this->parametros[1])){
				$retorno['codigo']   = 1;
				$retorno['tipo']     = 'error';
				$retorno['input']    = $_POST;
				$retorno['output']   = null;
				$retorno['mensagem'] = 'ID usuario invalido';
			}
			
			if(!isset($_POST['cpf']) || empty($_POST['cpf'])){
				$retorno['codigo']   = 1;
				$retorno['tipo']     = 'error';
				$retorno['input']    = $_POST;
				$retorno['output']   = $this->modelo->info;
				$retorno['mensagem'] = 'Informe o CPF';
				throw new Exception (json_encode($retorno), 1);
			}

			if(!isset($_POST['email_pessoal']) || empty($_POST['email_pessoal'])){
				$retorno['codigo']   = 1;
				$retorno['tipo']     = 'error';
				$retorno['input']    = $_POST;
				$retorno['output']   = $this->modelo->info;
				$retorno['mensagem'] = "Informe o email pessoal";
				throw new Exception (json_encode($retorno), 1);
			}

			if(!isset($_POST['data_nasc']) || empty($_POST['data_nasc'])){
				$retorno['codigo']   = 1;
				$retorno['tipo']     = 'error';
				$retorno['input']    = $_POST;
				$retorno['output']   = $this->modelo->info;
				$retorno['mensagem'] = "Informe da data de nascimento";
				throw new Exception (json_encode($retorno), 1);
			}
			
			if(!isset($_POST['data_demissao']) || empty($_POST['data_demissao'])){				
				unset($_POST['data_demissao']);
			}else{
				$_POST['data_demissao'] = convertDate($_POST['data_demissao']);
			}

			$_POST['cep']      = removeCaracteres(trim($_POST['cep']), 'all');
			$_POST['cpf']      = removeCaracteres(trim($_POST['cpf']), 'all');
			$_POST['id_slack'] = removeCaracteres(trim($_POST['id_slack']), 'all');
			if(isset($_POST['senha']) && !empty($_POST['senha'])){
				$_POST['senha'] = md5($_POST['senha']);
			}else{
				unset($_POST['senha']);
			}
			$_POST['email_hash'] 	= md5($_POST['email']);
			$_POST['data_nasc'] 	= convertDate($_POST['data_nasc']);
			$_POST['data_admissao'] = convertDate($_POST['data_admissao']);
			// echo '<pre>';
			// 	var_dump( $_POST );
			// echo '</pre>';
			// exit;
			$is_save = $this->modelo->save( $_POST, $this->parametros[1] );
			if($is_save){
				$retorno['codigo']   = 0;
				$retorno['tipo']     = 'sucesso';
				$retorno['input']    = $_POST;
				$retorno['output']   = $is_save;
				$retorno['mensagem'] = 'Sucesso ao salvar alterações';
			}else{
				$retorno['codigo']   = 1;
				$retorno['tipo']     = 'error';
				$retorno['input']    = $_POST;
				$retorno['output']   = $this->modelo->info;
				$retorno['mensagem'] = 'Erro ao salvar alterações';
			}
			throw new Exception(json_encode($retorno), 1);
		} catch (Exception $e) {
			echo $e->getMessage();
		}
	}
	function updateStatus(){
		if(isset($this->parametros[1]) && !empty($this->parametros[1])){
			$this->modelo->updateStatus($_POST['status'], $this->parametros[1]);
		}
		header('location: /usuarios/lista/');
	}
}
?>
