<?php

use function GuzzleHttp\json_encode;

    class UsuariosGrupoController extends MainController{
        protected
            $module = 'usuariosgrupo';

        function __construct( $parametros ){
            $this->setModulo('usuariosgrupo');
            $this->setView('usuariosgrupo');
            parent::__construct($parametros, 'usuariosgrupo');
        }

        function index(){
            $this->listar();
        }

        function listar(){
            $usuarios_grupo = json_decode( $this->modelo->getSistemaGrupo() );

            if ( $usuarios_grupo ) {
                $array = null;
                foreach ($usuarios_grupo as $key => $value) {
                    $i = $value->id;
                    $array[$i]['id']           = $value->id;
                    $array[$i]['nome']         = $value->nome;
                    $array[$i]['codigo']       = $value->codigo;
                    $array[$i]['tipo']         = $value->tipo;
                    $array[$i]['status']       = $value->status;
                    $array[$i]['descricao']    = $value->descricao;
                    $array[$i]['alterado_por'] = $value->alterado_por;
                    $array[$i]['alterado_em']  = $value->alterado_em;

                }
            }

            require_once ABSPATH . '/views/' . $this->nome_view.'/index.php';
        }

        function detalhe(){
            require_once ABSPATH . '/views/' . $this->nome_view.'/detalhe-view.php';
        }

        function gravarCadastro() {
            if ( !isset( $_POST['nome'] ) || empty( $_POST['nome'] ) ) {
                $retorno['codigo'] = 1;
                $retorno['mensagem'] = 'Campo nome não informado!';
                throw new Exception( json_encode( $retorno ), 1);
            }

            if ( !isset( $_POST['tipo'] ) || empty( $_POST['tipo'] ) ) {
                $retorno['codigo'] = 1;
                $retorno['mensagem'] = 'Campo tipo não informado!';
                throw new Exception( json_encode( $retorno ), 1);
            }

            if ( !isset( $_POST['status'] ) || empty( $_POST['status'] ) ) {
                $retorno['codigo'] = 1;
                $retorno['mensagem'] = 'Campo status não informado!';
                throw new Exception( json_encode( $retorno ), 1);
            }

            if ( !isset( $_POST['codigo'] ) || empty( $_POST['codigo'] ) ) {
                $retorno['codigo'] = 1;
                $retorno['mensagem'] = 'Campo codigo não informado!';
                throw new Exception( json_encode( $retorno ), 1);
            }

            if ( !isset( $_POST['descricao'] ) || empty( $_POST['descricao'] ) ) {
                $retorno['codigo'] = 1;
                $retorno['mensagem'] = 'Campo descricao não informado!';
                throw new Exception( json_encode( $retorno ), 1);
            }

            // $param_save['id']           = 
            $param_save['nome']         = $_POST['nome'];
            $param_save['codigo']       = $_POST['codigo'];
            $param_save['tipo']         = $_POST['tipo'];
            $param_save['status']       = $_POST['status'];
            $param_save['descricao']    = $_POST['descricao'];
            $param_save['alterado_por'] = $this->userdata->id;
            $param_save['alterado_em']  = $this->data_hora_atual->format('Y-m-d H:i:s');
            $param_save['deleted']      = 0;

            $is_save = $this->modelo->save( $param_save );
            if ( $is_save ) {
                $retorno['codigo'] = 0;
                $retorno['mensagem'] = 'Sucesso';
                throw new Exception( json_encode( $retorno ), 1);
            }else{
                $retorno['codigo'] = 1;
                $retorno['mensagem'] = 'Erro ao salvar requisição!';
                throw new Exception( json_encode( $retorno ), 1);
            }

            // echo '<pre>';
            //     var_dump( $_POST );
            // echo '</pre>';
        }

        function deletar() {
            if ( !isset( $_POST ) || empty( $_POST ) ){
                $retorno['codigo']   = 1;
                $retorno['mensagem'] = 'Porblema ao encontrar dados DELETAR!';
                throw new Exception( json_encode( $retorno ), 1);
            }

            $lista_deletar = json_encode( $_POST );
            echo '<pre>';
                var_dump( $lista_deletar );
            echo '</pre>';

            // if ( $lista_deletar ) {
            //     foreach ( $lista_deletar as $key => $value ) {
            //         $id = $value->id_grupo; 
            //     }
            // }

        }
    }