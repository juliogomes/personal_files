<?php
    class UtilsController extends MainController{
    	function __construct( $parametros = null ){
    		$this->setModulo( 'utils' );
    		$this->setView( 'utils' );
    		parent::__construct( $parametros, 'utils', false );
    	}
    	
    	function completaLp()
        {
            $model_contratos = $this->load_model('contratos/contratos', true);
            $model_lp        = $this->load_model('lista-precos/lista-precos', true);
            $contratos       = json_decode($model_contratos->getTodosContratosEModulos());
            foreach ($contratos as $key => $value) {
                if ($value->codigo_produto == 'COR0001') {
                    $lp = json_decode($model_lp->getLpByCustomer($value->id_contrato, $value->id_modulo, $value->id_produto));
                    if (!$lp) {
                        if (
                            $value->codigo_modulo != 'INT0010' &&
                            $value->codigo_modulo != 'IMP0010' &&
                            $value->codigo_modulo != 'MUL0010' &&
                            $value->codigo_modulo != 'REA0010'
                        ) {
                            $param['id_contrato']   = $value->id_contrato;
                            $param['tipo_cobranca'] = 'VOLUMETRIA';
                            $param['modalidade']    = 'provisorio';
                            $param['qtd_de'] = '1';
                            $param['qtd_ate'] = 1000000000000000;
                            $param['valor_real'] = 1.23;
                            $param['deleted'] = 0;
                            $param['id_modulo'] = $value->id_modulo;
                            $param['id_produto'] = $value->id_produto;
                            $param['status'] = 'ativo';
                            $save = $model_lp->save($param);
                            if (!$save) {
                                echo '<pre>';
                                var_dump($value->id_contrato, $value->codigo_modulo,  $param, $save);
                                echo '</pre>';
                                exit;
                            }
                        }
                    }
                }
            }
            echo 'Concluido.....';
        }

    	
    	function gerarCodigoUnico($prefixo, $digitos, $model_contratos)
        {
            do {
                // Gera número aleatório com a quantidade de dígitos especificada
                $numero = str_pad(mt_rand(0, pow(10, $digitos) - 1), $digitos, '0', STR_PAD_LEFT);
                $codigo = strtoupper($prefixo . $numero);
                // Verifica se já existe no banco
                $existe = json_decode($model_contratos->getUltimoCodigoContrato($codigo));
            } while ($existe); // Continua tentando até gerar um que não exista
    
            return $codigo;
        }
    
        function updateCodigoContratos()
        {
            $model_contratos = $this->load_model('contratos/contratos', true);
            $contratos       = json_decode($model_contratos->getAllContratos());
            if ($contratos) {
                foreach ($contratos as $value) {
                    switch (strtoupper($value->codigo_produto)) {
                        case 'SPB0001':
                        case 'SOE0001':
                        case 'SPI0001':
                        case 'FSP0001':
                        case 'ATF0001':
                        case 'TPX0001':
                        case 'COR0001':
                            /*if (strlen($value->codigo_contrato) >= 3 && ctype_alpha(substr($value->codigo_contrato, 0, 3))) {
                                $novo_codigo = 'COR' . substr($value->codigo_contrato, 3);
                            } else {
                                $novo_codigo = $value->codigo_contrato; // ou trate como erro
                            }
                            $param['codigo_contrato'] = $novo_codigo;
                            $is_save = $model_contratos->save($param, $value->id);
                            if ($is_save) {
                                echo 'Codigo atualizado de ' . $value->codigo_contrato . ' para ' . $novo_codigo . ' no contrato id ' . $value->id . '<br>';
                            } else {
                                echo 'Erro ao atribuir código ao contrato ID ' . $value->id . '<br>';
                            }*/
                            break;
                        default:
                            # code...
                            break;
                    }
                }
            }
        }

        function migrarContrato()
        {
            $model_contratos = $this->load_model('contratos/contratos', true);
            $contratos       = json_decode($model_contratos->getAllContratos());
            if ($contratos) {
                $count = 0;
                // echo 'ids <br>';
                foreach ($contratos as $value) {
                    if (strtolower($value->status) == 'ativo') {
                        switch (strtoupper($value->codigo_produto)) {
                            //case 'SPB0001':
                            //case 'SOE0001':
                            //case 'SPI0001':
                            //case 'FSP0001':
                            case 'ATF0001':
                                $contrato_cor = json_decode($model_contratos->getContratosAndProdutos($value->codigo_cliente, 'COR0001'));
                                if (!$contrato_cor) {
                                    'linha numero: ' . $count++ . '<br>';
                                    $param['codigo_contrato']        = $this->gerarCodigoUnico('COR', 7, $model_contratos);
                                    $param['id_agente_comercial']    = $value->id_agente_comercial;
                                    $param['numero_contrato']        = $param['codigo_contrato'];
                                    $param['status']                 = $value->status;
                                    $param['razao_social']           = $value->razao_social;
                                    $param['nome_fantasia']          = $value->nome_fantasia;
                                    $param['cnpj']                   = $value->cnpj;
                                    $param['cnpj_fantasia']          = $value->cnpj_fantasia;
                                    $param['inscricao_estadual']     = $value->inscricao_estadual;
                                    $param['inscricao_municipal']    = $value->inscricao_municipal;
                                    $param['segmento']               = $value->segmento;
                                    $param['endereco']               = $value->endereco;
                                    $param['codigo_pais']            = $value->codigo_pais;
                                    $param['ddi_pais']               = $value->ddi_pais;
                                    $param['numero']                 = $value->numero;
                                    $param['complemento']            = $value->complemento;
                                    $param['cep']                    = $value->cep;
                                    $param['bairro']                 = $value->bairro;
                                    $param['cidade']                 = $value->cidade;
                                    $param['estado']                 = $value->estado;
                                    $param['url']                    = $value->url;
                                    $param['email_nf']               = $value->email_nf;
                                    $param['nome_representante']     = $value->nome_representante;
                                    $param['cpf_representante']      = $value->cpf_representante;
                                    $param['email_representante']    = $value->email_representante;
                                    $param['telefone_representante'] = $value->telefone_representante;
                                    $param['contato'] = $value->contato;
                                    $param['email_contato'] = $value->email_contato;
                                    $param['contato_tecnico'] = $value->contato_tecnico;
                                    $param['email_contato_tecnico'] = $value->email_contato_tecnico;
                                    $param['data_assinatura'] = $value->data_assinatura;
                                    $param['inativar_em'] = $value->inativar_em;
                                    $param['data_reajuste'] = $value->data_reajuste;
                                    $param['duracao_contrato'] = $value->duracao_contrato;
                                    $param['id_empresa'] = $value->id_empresa;
                                    $param['indice_reajuste'] = $value->indice_reajuste;
                                    $param['reajuste_automatico'] = $value->reajuste_automatico;
                                    $param['moeda'] = $value->moeda;
                                    $param['taxa_inatividade'] = $value->taxa_inatividade;
                                    $param['prazo_inatividade'] = $value->prazo_inatividade;
                                    $param['tipo_tarifacao'] = $value->tipo_tarifacao;
                                    $param['renovacao_automatica'] = $value->renovacao_automatica;
                                    $param['data_corte_faturamento'] = $value->data_corte_faturamento;
                                    $param['vencimento_todo_dia'] = $value->vencimento_todo_dia;
                                    $param['numero_dias_apos_corte'] = $value->numero_dias_apos_corte;
                                    $param['multa'] = $value->multa;
                                    $param['juros'] = $value->juros;
                                    $param['hospedagem_mensal'] = $value->hospedagem_mensal;
                                    $param['licenca_uso_mensal'] = $value->licenca_uso_mensal;
                                    $param['id_produto'] = 7000000;
                                    $param['data_primeiro_faturamento'] = $value->data_primeiro_faturamento;
                                    $param['inicio_producao_em'] = $value->inicio_producao_em;
                                    $param['isento_ate'] = $value->isento_ate;
                                    $param['isento_de'] = $value->isento_de;
                                    $param['ultima_data_demo'] = $value->ultima_data_demo;
                                    $param['carencia_de_uso'] = $value->carencia_de_uso;
                                    $param['primeira_parcela_em'] = $value->primeira_parcela_em;
                                    $param['valor_implantacao'] = $value->valor_implantacao;
                                    $param['parcelado_em'] = $value->parcelado_em;
                                    $param['contrato_indeterminado'] = $value->contrato_indeterminado;
                                    $param['preco_com_imposto'] = $value->preco_com_imposto;
                                    $param['upselling'] = $value->upselling;
                                    $param['codigo_cliente'] = $value->codigo_cliente;
                                    $param['vinculado_producao'] = $value->vinculado_producao;
                                    $param['enviar_email_cobranca'] = $value->enviar_email_cobranca;
                                    $param['nf_automatica'] = 0;
                                    $param['obs_nf'] = $value->obs_nf;
                                    $param['obs_contrato'] = 'JULIO 13/06/2025 <br> VERIFICAR FATURAMENTO ANTERIOR ANTES DA MIGRAÇÃO PARA CORNER FULL <br>' . $value->obs_contrato;
                                    $param['id_banco'] = $value->id_banco;
                                    $param['meio_pagamento'] = $value->meio_pagamento;
                                    $param['alerta_inatividade'] = $value->alerta_inatividade;
                                    $param['inativado_em'] = $value->inativado_em;
                                    $param['alterado_em'] = $value->alterado_em;
                                    $param['alterado_por'] = $value->alterado_por;
                                    $param['deleted'] = $value->deleted;
                                    $is_save = $model_contratos->save($param);
                                    if ($is_save) {
                                        $contrato_antigo['obs_contrato']  = 'JULIO 13/06/2025 <br> VERIFICAR FATURAMENTO ANTERIOR ANTES DA MIGRAÇÃO PARA CORNER FULL <br>' . $value->obs_contrato;
                                        $contrato_antigo['nf_automatica'] = 0;
                                        $save_contrato = $model_contratos->save($contrato_antigo, $value->id);
                                        if ($save_contrato) {
                                            echo 'Contrato do cliente ' . $value->razao_social . ' migrado ID original ' . $value->id . ' para o contrato id ' . $is_save . '<br>';
                                        } else {
                                            echo 'Erro ao atualizar contrato original ' . $value->id . '<br>';
                                        }
                                    } else {
                                        echo 'Erro ao migrar o ID ' . $value->id . '<br>';
                                    }
                                }
                                break;
                            default:
                                # code...
                                break;
                        }
                    }
                }
            }
        }

        function gerarCodigoContratos()
        {
            $model_contratos = $this->load_model('contratos/contratos', true);
            $contratos       = json_decode($model_contratos->getAllContratos());
            if ($contratos) {
                foreach ($contratos as $value) {
                    if (!$value->codigo_contrato) {
                        $prefixo = strtoupper(substr($value->codigo_produto, 0, 3));
                        // Gera código único de 7 dígitos numéricos com prefixo
                        $param['codigo_contrato'] = $this->gerarCodigoUnico($prefixo, 7, $model_contratos);
                        $is_save = $model_contratos->save($param, $value->id);
                        if ($is_save) {
                            echo 'Código de contrato ' . $param['codigo_contrato'] . ' atribuído ao contrato ID ' . $value->id . ' com sucesso<br>';
                        } else {
                            echo 'Erro ao atribuir código ao contrato ID ' . $value->id . '<br>';
                        }
                    }
                }
            } else {
                echo 'Nenhum contrato encontrado';
            }
        }
        
        function checkHorasServidor(){
            $now = getDataAtual();
            echo '<pre>';
                var_dump($now);
            echo '</pre>';
        }

        function fileExplorer(){
            require_once ABSPATH . '/views/'.$this->nome_view.'/file_explorer-view.php';
        }

        function uploadFile(){
            $url = '/var/www/html/dir_ged/minuta/48332726000158/minuta_2000037_20250210090204.pdf';
            // $url = '/var/www/html/dir_ged/minuta/56365009000150/minuta_2000014_20240918160953.pdf';
            // $url_teste = 'C:\Users\julio.gomes\Documents\projetos\tarifador\web\www_producao_20230807\temp_files\minuta_1000040_20240215130215.pdf';
            $is_move = move_uploaded_file( $_FILES['arquivo']['tmp_name'], $url );
            echo '<pre>';
                var_dump($is_move, $_POST, $_FILES['arquivo']['tmp_name']);
            echo '</pre>';
        }

        function lerExtratoCliente(){
            $tipo = $this->parametros[0];
            switch ( $tipo ) {
                case '1':
                    $url = URL_SISTEMA.'report/extratoLP/'.$this->parametros[1].'/'.$this->parametros[2].'/'.$this->parametros[3].'/';
                break;
            }
            // Obtém o conteúdo da URL
            $conteudo = file_get_contents( $url );
            // Verifica se houve algum erro
            if ( $conteudo === false ) {
                echo "Não foi possível obter o conteúdo da URL.";
            } else {
                // Exibe o conteúdo
                $dados = json_decode( $conteudo );
                if( $dados->extrato ){
                    foreach ( $dados->extrato as $key => $value ) {
                        $m = $value->codigo_produto;
                        $m = $value->codigo_modulo;
                        $n = $value->nome_modulo;
                        $d = $value->data_tarifacao;
                        $l = $value->login;
                        $consolidado['totais']['geral']          += $value->qtd_transacoes;
                        $consolidado['totais']['modulo'][$m]     += $value->qtd_transacoes;
                        $consolidado['diario']['modulo'][$m][$d] += $value->qtd_transacoes;
                    }
                }
                echo '<pre>';
                    var_dump( $consolidado['diario'] );
                echo '</pre>';
            }
        }

        function moveFiles(){
            $dir_origem  = ABSPATH."/temp_files/pessoal";
            $dir_destino = ABSPATH."/temp_files/pessoal/departamento";
            $diretorios  = array(
                'suporte', 'produtos','presidencia', 'operacoes','modelos preditivos', 'modelos_preditivos','marketing','desenvolvimento','comercial','bi','adm'
            );
            
            // Verifica se o diretório de origem existe
            if ( !is_dir( $dir_origem ) ) {
                die("Diretório de origem não existe.\n");
            }

            // Verifica se o diretório de destino existe, senão cria
            if ( !is_dir( $dir_destino ) ) {
                if ( !mkdir($dir_destino, 0777, true ) ) {
                    die("Falha ao criar o diretório de destino.\n");
                }
            }

            // Abre o diretório de origem
            $files = scandir( $dir_origem );
            foreach ( $files as $file ) {
                // Ignora os diretórios '.' e '..'
                if ( $file != '.' && $file != '..' ) {
                    if ( in_array( $file, $diretorios ) ) {
                        $sub_files = scandir( $dir_origem.DS.$file );
                        $sub_files = array_diff( $sub_files, array('.', '..') );
                        if( !empty( $sub_files ) ){
                            foreach ( $sub_files as $sub_file ) {
                                if ( $sub_file != '.' && $sub_file != '..' ) {
                                    $file_d     = str_replace(' ', '_', $file );
                                    $sub_file_d = str_replace(' ', '_', $sub_file );
                                    if( !file_exists( $dir_destino.DS.$file_d ) ) {
                                        if ( !mkdir( $dir_destino.DS.$file_d, 0777, true ) ) {
                                            die("Falha ao criar o diretório de destino COD: 92.\n");
                                        }
                                    }
                                    // Move o arquivo
                                    $sourceFile = $dir_origem.DS.$file.DS.$sub_file;
                                    $destFile   = $dir_destino.DS.$file_d.DS.$sub_file_d;
                                    if ( !rename( $sourceFile, $destFile ) ) {
                                        echo "Falha ao mover o arquivo $file.\n";
                                    } else {
                                        echo "Arquivo $file movido com sucesso.\n";
                                    }
                                }
                            }
                        }else{
                            if( is_dir( $dir_origem.DS.$file ) ) {
                                echo $dir_origem.DS.$file;
                                rmdir( $dir_origem.DS.$file );
                            }
                        } 
                    }
                }
            }
        }

        function renomearParaPdf(){
            $dir_origem = ABSPATH."/temp_files/pessoal/departamento";
            $files      = scandir( $dir_origem );
            $files      = array_diff( $files, array('.', '..') );
            if( $files ){
                foreach ( $files as $subdir ) {
                    $path_subdir = $dir_origem.DS.$subdir;
                    $subfiles    = scandir( $path_subdir );
                    $subfiles    = array_diff( $subfiles, array('.', '..') );
                    if( $subfiles ){
                        foreach ( $subfiles as $subfile ) {
                            $path_full_subdir = $path_subdir.DS.$subfile;
                            $info_file         = pathinfo( $path_full_subdir );
                            if( !$info_file['extension'] || $info_file['extension'] != 'pdf' ){
                                rename( $path_full_subdir, $path_full_subdir.'.pdf' );
                            }
                        }
                    }
                }
            }
        }

        function refazerFechamentoPonto(){
            $id_usuario      = 5;
            $ponto_model     = $this->load_model( 'ponto/ponto', true );
            $fechamento      = json_decode( $ponto_model->getFechamentoByUsuario( $id_usuario ) );
            $json_fechamento = base64_decode( $fechamento[0]->json_fechamento );
            if( $json_fechamento ){
                // $obj_fechamento = json_decode( $json_fechamento );
                $dt_ini = getDataAtual( $fechamento[0]->periodo_ini );
                $dt_fim = getDataAtual( $fechamento[0]->periodo_fim );
                $obj_ponto = new RhPonto( $this, $id_usuario );
                $param['dados_usuario']    = json_encode( $obj_ponto->user );
                $param['periodo_ini']      = $fechamento[0]->periodo_ini;
                $param['periodo_fim']      = $fechamento[0]->periodo_fim;
                $param['saldo_fechamento'] = $fechamento[0]->saldo_fechamento;
                $param['json_fechamento']  = $fechamento[0]->json_fechamento;
                $param['status']           = $fechamento[0]->status;
                $param['alterado_em']      = $fechamento[0]->alterado_em;
                $param['alterado_por']     = $fechamento[0]->alterado_por;
                $param['deleted']          = $fechamento[0]->deleted;                
                $obj_ponto->savePdfEspelho( $param );
            }
        }
        
        function editorHtml(){
            require_once ABSPATH . '/views/'.$this->nome_view.'/editorhtml-view.php';
        }

        function viewTemplate(){
            try {
                $faturamento_relacionado = null;
                $faturamento             = null;
                $retorno['codigo']       = 1;
                $nf_model                = $this->load_model('notas-fiscais/notas-fiscais', true);
                $contrato_model          = $this->load_model('contratos/contratos', true);
                $empresa_model           = $this->load_model('empresas/empresas', true);
                if (!isset($_POST['id_nf']) || !is_numeric($_POST['id_nf']) || empty($_POST['id_nf'])) {
                    $retorno['mensagem'] = 'informe o ID da nota fiscal';
                    throw new Exception(json_encode($retorno), 1);
                }
    
                if (!$nf_model) {
                    $retorno['mensagem'] = 'Erro ao recuperar o modelo';
                    throw new Exception(json_encode($retorno), 1);
                }
    
                $dados_nota = json_decode($nf_model->getNota($_POST['id_nf']));
                if ($dados_nota) {
                    $data_vencimento         = getDataAtual($dados_nota[0]->data_vencimento);
                    $faturamento_relacionado = json_decode($dados_nota[0]->faturamento_relacionado);
                } else {
                    $retorno['mensagem'] = 'Erro ao recuperar dados da nota ';
                    throw new Exception(json_encode($retorno), 1);
                }
    
                $dados_contrato = json_decode($contrato_model->getJustContratos($dados_nota[0]->id_contrato));
                $dados_empresa  = json_decode($empresa_model->getEmpresa($dados_contrato[0]->id_empresa));
                if (!$dados_contrato) {
                    $retorno['mensagem'] = 'Erro ao recuperar dados do contrato ';
                    throw new Exception(json_encode($retorno), 1);
                }
            } catch (Exception $e) {
                echo $e->getMessage();
            }
            
            if (isset($faturamento_relacionado->faturamento) && !empty($faturamento_relacionado->faturamento)) {
                $faturamento = $faturamento_relacionado->faturamento;
                $juros       = (isset($faturamento_relacionado->multa)) ? $faturamento_relacionado->multa : null;
                $multa       = (isset($faturamento_relacionado->juros)) ? $faturamento_relacionado->juros : null;
            } else {
                if (is_array($faturamento_relacionado)) {
                    foreach ($faturamento_relacionado as $key => $value) {
                        $faturamento[] = $value;
                    }
                }
                $juros       = '0,00';
                $multa       = '0,00';
            }
            
            if (count($juros) == 0) {
                $juros = null;
            } elseif (count($juros) == 1 && empty($juros[0])) {
                $juros = null;
            }
    
            if (count($multa) == 0) {
                $multa = null;
            } elseif (count($multa) == 1 && empty($multa[0])) {
                $multa = null;
            }
            require_once ABSPATH . '/template/nota_fiscal/usa/modelo_usa.php';
        }
    }