<?php
class WebServiceController extends MainController{
	//verificar se modulo esta sendo usado
	
	protected $module = 'webservice';
	protected $ws;
	protected $obj_contrato;
	
	function __construct($parametros = false)	{
		require_once('classes/class-WebService.php');
		$this->nome_modulo = 'webservice';
		parent::__construct($parametros);
		$this->ws    	    = new WebService(); 
		$this->obj_contrato = $this->load_model('contratos/contratos', true);
	}

	function index(){
		echo 'teste';
	}

	//funções com erro ao consultar o WS implemtar e corrigir depois;
	function getProdutos(){
		$input  = array('codigo_cliente'=>'xsd:string',
					   'codigo_produto'=>'xsd:int');
		$output = array('retorno'=>'xsd:string');
		$this->ws->register('getProdutos', $input, $output, 'Retorna os produtos ativos');
		$this->ws->getData($HTTP_RAW_POST_DATA);
	}

	function getClientes(){
		$input  = array('id_contrato'=>'xsd:string',
					   'codigo_cliente'=>'xsd:int');
		$output = array('retorno'=>'xsd:string');
		$this->ws->register('getClientes', $input, $output, 'Retorna os clientes ativos');
		$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : 'teste';
		$this->ws->getData($HTTP_RAW_POST_DATA);
	}
}
?>
