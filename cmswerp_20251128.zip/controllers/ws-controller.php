<?php
class WSController extends MainController
{
    function __construct($parametros = false)
    {
        $this->nome_modulo = 'ws';
        parent::__construct($parametros);
    }
}
