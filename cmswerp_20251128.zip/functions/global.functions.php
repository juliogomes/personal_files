<?php
	/**
	 * Created by PhpStorm.
	 * User: julio.gomes
	 * Date: 10/10/2016
	 * Time: 17:02
	 * Verifica chaves de arrays
	 * Verifica se a chave existe no array e se ela tem algum valor.
	 * Obs.: Essa função está no escopo global, pois, vamos precisar muito da mesma.
	 * @param array  $array O array
	 * @param string $key   A chave do array
	 * @return string|null  O valor da chave do array ou nulo
	 */
	function formatarString( $tipo, $value ){
		switch ($tipo) {
			case 'cep':
				$mask = substr($value, 0, 5);
				$mask_2 = substr($value, 5);
				$string = $mask."-".$mask_2;
				break;	
			case 'telefone':
				$count = strlen($value);			
				if($count == 10){
					$mask = substr($value, 0, 2);
					$mask_2 = substr($value, 2, 4);
					$mask_3 = substr($value, 6);
				}else{
					$mask = substr($value, 0, 2);
					$mask_2 = substr($value, 2, 5);
					$mask_3 = substr($value, 7);
				}			
				$string = "(".$mask.") ".$mask_2."-".$mask_3;
				break;
			case 'cnpj':
				$mask  = substr($value, 0, 2);
				$mask1 = substr($value, 2, 3);
				$mask2 = substr($value, 5, 3);
				$mask3 = substr($value, 8, 4);
				$mask4 = substr($value, 12, 2);
				$string = $mask.".".$mask1.".".$mask2."/".$mask3."-".$mask4;			
				break;
			case 'cpf':
				$mask  = substr($value, 0, 3);
				$mask1 = substr($value, 3, 3);
				$mask2 = substr($value, 6, 3);
				$mask3 = substr($value, 9, 2);			
				$string = $mask.".".$mask1.".".$mask2."-".$mask3;
				break;
			default:
				# code...
				break;
		}
		return $string;
	}

	function removerEspacos( $string ){
		return preg_replace('/\\s\\s+/', ' ', $string);
	}

	function getDiaSemana(DateTime $data, $number = false){
		if ($number) {
			return nomeSemana($data->format('N'));
		} else {
			return $data->format('N');
		}
	}

	function nomeSemana( $param ){
		$dia = array(
			'0' => 'dom',
			'1' => 'seg',
			'2' => 'ter',
			'3' => 'qua',
			'4' => 'qui',
			'5' => 'sex',
			'6' => 'sab',
			'7' => 'dom',
		);
		return $dia[$param];
	}

	function returMesData( $data = null ){
		$obj_data = getDataAtual($data);
		$mes = nomeMes($obj_data->format('m'));	
		return $mes;
	}

	function returAnoData( $data = null ){
		$obj_data = getDataAtual($data);
		$ano = $obj_data->format('Y');	
		return $ano;
	}

	function validate_hour( $input ){
		$format = 'H:i';
		$date = DateTime::createFromFormat('!'. $format, $input);
		return $date && $date->format($format) === $input;
	}

	function convertHorasMinutos( $hora_decimal, $tipo = 'hora>decimal', $converter = false ){
		switch($tipo){
			case 'hora>decimal':
				$array = explode(':', $hora_decimal);
				$minutos_all = (($array[0] * 60) + $array[1]);
				$horas = (int)($minutos_all / 60);
				$minutos = ($minutos_all % 60);
				break;
			case 'decimal>horas':
				$hora_decimal = abs(-$hora_decimal);
				$horas = (int)($hora_decimal / 60);
				if($horas < 10){
					$horas = "0".$horas;
				}
				$minutos = ($hora_decimal % 60);
				if($minutos < 10){
					$minutos = "0".$minutos;
				}
				break;
			case 'decimal>horas_sem_formatacao':
				$horas = (int)($hora_decimal / 60);
				$minutos = ($hora_decimal % 60);
				break;
		}
		if($converter){
			$horas_convertida = $horas.":".$minutos;
			return $horas_convertida;
		}else{
			return $minutos_all;
		}	
	}

	function calculaPeriodo( $periodo_ini, $periodo_fim ){
		$obj_ini = new DateTime($periodo_ini);
		$obj_fim = new DateTime($periodo_fim);
		$diff = $obj_ini->diff($obj_fim);      
		$diff_horario =  formatarHorasMinutos($diff->h, null, null, 'horas').":".formatarHorasMinutos(null, $diff->i, null, 'minutos');    
		return $diff_horario;
	}

	function retirarSegundos( $hora ){
		if($hora){
			$x = explode(":",$hora);
			$hora_format = $x[0].":".$x[1];
		}else{
			$hora_format = null;
		}
		return $hora_format;
	}

	function returnPeriodo( $data, $tipo = "data" ){
		$explode = explode(" ",$data);
		
		if($tipo == "data"){
			return $explode[0];
		}elseif($tipo == "hora"){
			return retirarSegundos($explode[1]);
		}
	}

	function formatarHorasMinutos( $horas, $minutos, $segundos = null, $tipo = 'all' ){
		if($tipo == "horas" || $tipo == "all"){    
			if($horas != null || $horas == '0' || $horas == '00'){
				if(isset($horas) || $horas == '0' || $horas == '00'){
					if($horas < 10){
						if($horas == '0' || $horas == '00'){
							$horas_formatada = "00";    
						}else{
							$horas_formatada = "0".$horas;
						}
					}else{
						$horas_formatada = $horas;
					}
				}
			}
		}
		if($tipo == "minutos" || $tipo == "all"){
			if($minutos != null || $minutos == '0' || $minutos == '00'){        
				if(isset($minutos) || $minutos == '0' || $minutos == '00'){        
					if($minutos < 10 || $minutos == '0' || $minutos == '00'){
						if($minutos == '0' || $minutos == '00'){
							$minutos_formatado = "00";  
						}elseif($minutos < 0){
							$minutos_formatado = 60 + $minutos;
							$horas_formatada -= 1;                          
							$horas_formatada = $horas_formatada;
						}else{
							$minutos_formatado = "0".$minutos;
						}
					}else{
						$minutos_formatado = $minutos;
					}
				}
			}  
		}
		if($tipo == "segundos" || $tipo == "all"){
			if($segundos != null || $segundos == '0' || $segundos == '00'){
				if( isset($segundos) || $segundos == '0' || $segundos == '00'){
					if($segundos || $segundos == '0' || $segundos == '00'){                    
						if($segundos < 10){
							if($segundos == 0){
								$segundos_formatado = "00";
							}elseif($segundos < 0){
								$segundos_formatado = 60 + $segundos;
								$minutos_formatado -= 1;                            
								$minutos_formatado = $minutos_formatado;
							}else{
								$segundos_formatado = "0".$segundos;
							}
						}else{
							$segundos_formatado = $segundos;
						}      
					}
				}
			}
		}  
		
		if(isset($horas_formatada) && isset($minutos_formatado) && isset($segundos_formatado)){
			$horas_formatada_final = $horas_formatada.":".$minutos_formatado.":".$segundos_formatado;
		}else{      
			if(isset($horas_formatada) && isset($minutos_formatado)){          
				$horas_formatada_final = $horas_formatada.":".$minutos_formatado;  
			}elseif(isset($minutos_formatado)){    
				$horas_formatada_final = $minutos_formatado;
			}elseif(isset($horas_formatada)){          
				$horas_formatada_final = $horas_formatada;
			}      
		}
		return $horas_formatada_final;
	}

	function returnMesData( $data = null, $tipo = "mes" ){
		$obj_data = getDataAtual($data);
		if($obj_data){
			if($tipo == "mes"){
				$mes = nomeMes($obj_data->format('m'));	
				return $mes;
			}
			if($tipo == "ano"){
				return $obj_data->format('Y');
			}

			if($tipo == "dia"){
				return $obj_data->format('d');
			}
		}else{
			echo '<pre>';
				var_dump('240', $data);
			echo '</pre>';
			exit;
		}
	}

	function getDateTime( $data, $format = 'Y-m-d' ){
		$data 	= new DateTime( $data );
		$hora 	= $data->format('H:i:s');
		$array 	= explode( ':', $hora ); 
		$data->setTimezone( new DateTimeZone( TIME_ZONE ) );
		$data->setTime( $array[0], $array[1], $array[2] );
		return $data;
	}

	function getDataAtual( $date = null, $format = 'd/m/Y' ){ // informar o formato yyyy-mm-dd
		$data_atual = null;
		if( $date ){
			$v1 = strpos( $date, '-' );
			$v2 = strpos( $date, '/' );
			if( $v1 || $v2 ){
				if( $format == 'd/m/Y' && $v1 ){
					$date = convertDate( $date );
				}

				if( $format == 'Y-m-d' && $v2 ){
					$date = convertDate( $date );
				}
				$data_atual = DateTime::createFromFormat( $format, $date, new DateTimeZone( TIME_ZONE ));
			}else{
				switch ( $format ){
					case 'YMD':
						$format = 'Ymd';
					break;
					case 'DMY':
						$format = 'dmY';
					break;
				}
				$data_atual = DateTime::createFromFormat( $format, $date, new DateTimeZone( TIME_ZONE ) );
			}
		}

		if( $data_atual ){
			return $data_atual;
		}else{
			$data_atual = new DateTime();
			$data_atual->setTimezone( new DateTimeZone( TIME_ZONE ) );
			return $data_atual;
		}
	}
	
	function chk_array ( $array, $key ){
		// Verifica se a chave existe no array
		if ( isset( $array[ $key ] ) && ! empty( $array[ $key ] ) ){
			// Retorna o valor da chave
			return $array[ $key ];
		}
		// Retorna nulo por padrão
		return null;
	} // chk_array

	function autoLoad( $class_name ){
		$arr_class = explode('\\', $class_name);
		if($arr_class[0] != 'Hmarinjr' &&  $class_name != 'OpenBoleto\Agente' && $class_name != 'Client' && $class_name != 'PhantomJS' && $class_name != 'HTMLParserMode'){
			$file = ABSPATH.DS.'classes/class-'.$class_name.'.php';
			if ( ! file_exists( $file ) ){
				//echo '<br>'.$class_name.'<br>';
				// include_once ABSPATH.DS.'includes/404.php';
				return;
			}
			require_once $file;
		}	
	}
	
	spl_autoload_register('autoLoad'); // __autoload

	function validaData( $date = null, $format = 'd/m/Y'){
		$data_atual = DateTime::createFromFormat( $format, $date );	
		if( $data_atual ){
			return true;
		}else{
			return false;
		}
	}
	
	function validaForm( $param, $required = false ){
		$allow = true;
		if($required = 'all')
		{
			foreach ($param as $campo => $valor)
			{
				if($valor !=  '0' && empty($valor))
				{
					$allow = false;
				}
			}
			return $allow;
		}
		if($required != 'all')
		{
		}
	}

	function removeAcentos( $string, $slug = false ){
		// Código ASCII das vogais
		$ascii['a'] = range(224, 230);
		$ascii['e'] = range(232, 235);
		$ascii['i'] = range(236, 239);
		$ascii['o'] = array_merge(range(242, 246), array(240, 248));
		$ascii['u'] = range(249, 252);
		// Código ASCII dos outros caracteres
		$ascii['b'] = array(223);
		$ascii['c'] = array(231);
		$ascii['d'] = array(208);
		$ascii['n'] = array(241);
		$ascii['y'] = array(253, 255);
		foreach ($ascii as $key => $item) {
			$acentos = '';
			foreach ($item as $codigo) {
				$acentos .= chr($codigo);
			}
			$troca[$key] = '/[' . $acentos . ']/i';
		}

		$string = preg_replace(array_values($troca), array_keys($troca), $string);
		// Slug?
		if ($slug) {
			// Troca tudo que não for letra ou número por um caractere ($slug)
			$string = preg_replace('/[^a-z0-9]/i', $slug, $string);
			// Tira os caracteres ($slug) repetidos
			$string = preg_replace('/' . $slug . '{2,}/i', $slug, $string);
			$string = trim($string, $slug);
		}

		return $string;
	}

	function removeCaracteres( $string, $all, $param = null ){
		if( is_string( $string ) || is_float( $string ) ){
			if($all == true){
				$return = preg_replace("([^a-zA-Z0-9 ])", "", $string);
				$return = str_replace(' ', '', $return);
				$return = str_replace("/", '', $return);
			}
			
			if( $all === 'char'){
				$return = preg_replace("([^0-9 ])", "", $string);
			}
			
			if( $all === 'number' ) {
				$return = preg_replace("([^a-zA-Z])", "", $string);
			}
			
			if( $all === 'moeda' ){
				$return = preg_replace("([^0-9. ])", "", $string);
			}

			if( $all === 'moeda2' ){
				$string = str_replace ('.','',$string);
				$string = str_replace (',','.',$string);
				$return = $string;
			}

			if( $all === 'moeda3' ){
				$string = str_replace (',','.',$string);
				$return = $string;
			}

			if( $all === 'moeda4' ){
				return number_format( $string, '6', ',', '.' );
			}

			if( $all === 'char_especiais' ){
				$return = preg_replace(array("/(á|à|ã|â|ä)/","/(Á|À|Ã|Â|Ä)/","/(é|è|ê|ë)/","/(É|È|Ê|Ë)/","/(í|ì|î|ï)/","/(Í|Ì|Î|Ï)/","/(ó|ò|õ|ô|ö)/","/(Ó|Ò|Õ|Ô|Ö)/","/(ú|ù|û|ü)/","/(Ú|Ù|Û|Ü)/","/(ñ)/","/(Ñ)/","/(Ç)/","/(ç)/"),explode(" ","a A e E i I o O u U n N C c"),$string);
				$return = str_replace('~', '', $return);
				$return = preg_replace("/[ÁÀÂÃÄáàâãä]/", "a", $return);
				$return = preg_replace("/[ÉÈÊéèê]/", "e", $return);
				$return = preg_replace("[ÍÌíì]", "i", $return);
				$return = preg_replace("/[ÓÒÔÕÖóòôõö]/", "o", $return);
				$return = preg_replace("/[ÚÙÜúùü]/", "u", $return);
				$return = preg_replace("/Çç/", "c", $return);
				if( $param == 'all' ){
					$return = preg_replace("/[][><}{)(:;,!?*%~^`@]/", "", $return);
					$return = preg_replace("/ /", "_", $return);
					$return = str_replace('.', '', $return);
					$return = str_replace('/', '', $return);
				}
			}
		}else{
			$return = $string;
		}
		return $return;
	}

	function mask( $val, $mask ){
		$maskared = '';
		$k		  = 0;
		for( $i = 0; $i <= strlen( $mask )-1; $i++ ){
			if($mask[$i] == '#'){
				if( isset( $val[$k] ) )
					$maskared .= $val[$k++];
			}else{
				if( isset( $mask[$i] ) )
					$maskared .= $mask[$i];
			}
		}
		return $maskared;
	}

	// Obsoleto verificar se pode apagar
	function DateValidation( $data ){
		// data é menor que 8
		if ( strlen($data) < 8){
			return false;
		}else{
			// verifica se a data possui
			// a barra (/) de separação
			if(strpos($data, "/") !== FALSE){
				//
				$partes = explode("/", $data);
				// pega o dia da data
				$dia = $partes[0];
				// pega o mês da data
				$mes = $partes[1];
				// prevenindo Notice: Undefined offset: 2
				// caso informe data com uma única barra (/)
				$ano = isset($partes[2]) ? $partes[2] : 0;
	
				if (strlen($ano) < 4) {
					return false;
				} else {
					// verifica se a data é válida
					if (checkdate($mes, $dia, $ano)) {
						return true;
					} else {
						return false;
					}
				}
			}else{
				return false;
			}
		}
	}

	function convertDate( $date, $mask = 0 ){
		$arr1 = explode('/', $date);
		$arr2 = explode('-', $date);
		
		if(count($arr1) == 3){
			if(1 == $mask){
				$date = trim($arr1[2]).trim($arr1[1]).trim($arr1[0]);
			}else{
				$date = trim($arr1[2]).'-'.trim($arr1[1]).'-'.trim($arr1[0]);			
			}
		}elseif(3 == count($arr2)){
			$date = trim($arr2[2]).'/'.trim($arr2[1]).'/'.trim($arr2[0]);
		}elseif(isset( $date[7] )){
			$ano = substr($date, 0, 4);
			$mes = substr($date, 4, 2);
			$dia = substr($date, 6, 2);
			$date = $ano.'-'.$mes.'-'.$dia;
		}else{
			$date = false;
		}
		return $date;
	}

	function download( $path, $fileName = '' ){
		if( $fileName == '' ){
			$fileName = basename( $path );
		}
		header("Content-Type: application/force-download");
		header("Content-type: application/octet-stream;");
		header("Content-Length: " . filesize( $path ) );
		header("Content-disposition: attachment; filename=" . $fileName );
		header("Pragma: no-cache");
		header("Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0");
		header("Expires: 0");
		readfile( $path );
		flush();
	}

	function nomeMes( $param ){
		$mes = array(
			'1'  => 'Janeiro',
			'01' => 'Janeiro',
			'2'  => 'Fevereiro',
			'02' => 'Fevereiro',
			'3'  => 'Março',
			'03' => 'Março',
			'4'  => 'Abril',
			'04' => 'Abril',
			'5'  => 'Maio',
			'05' => 'Maio',
			'6'  => 'Junho',
			'06' => 'Junho',
			'7'  => 'Julho',
			'07' => 'Julho',
			'8'  => 'Agosto',
			'08' => 'Agosto',
			'9'  => 'Setembro',
			'09' => 'Setembro',
			'10' => 'Outubro',
			'11' => 'Novembro',
			'12' => 'Dezembro',
		);
		return $mes[$param];
	};

	function nomeTrimestre( $param ){
		$trimestre = array(
			'1'  => 'Primeiro Trimestre',
			'01' => 'Primeiro Trimestre',
			'2'  => 'Segundo Trimestre',
			'02' => 'Segundo Trimestre',
			'3'  => 'Terceiro Trimestre',
			'03' => 'Terceiro Trimestre',
			'4'  => 'Quantro Trimestre',
			'04' => 'Quantro Trimestre',
		);
		return $trimestre[$param];
	};

	//funcao para montar campos com meses
	function returMes( $dig = 1 ){
		$mes_dg1 = array(
			'1'  => 'Janeiro',
			'2'  => 'Fevereiro',
			'3'  => 'Março',
			'4'  => 'Abril',
			'5'  => 'Maio',
			'6'  => 'Junho',
			'7'  => 'Julho',
			'8'  => 'Agosto',
			'9'  => 'Setembro',
			'10' => 'Outubro',
			'11' => 'Novembro',
			'12' => 'Dezembro',
		);

		$mes_dg2 = array(
			'01'  => 'Janeiro',
			'02'  => 'Fevereiro',
			'03'  => 'Março',
			'04'  => 'Abril',
			'05'  => 'Maio',
			'06'  => 'Junho',
			'07'  => 'Julho',
			'08'  => 'Agosto',
			'09'  => 'Setembro',
			'10' => 'Outubro',
			'11' => 'Novembro',
			'12' => 'Dezembro',
		);

		if($dig == 1){
			return $mes_dg1;
		}else{
			return $mes_dg2;
		}
	}

	function listaAnos(){
		$data_inicial = getDataAtual('2017-01-01');
		$data_atual   = getDataAtual();
		$diff = $data_inicial->diff($data_atual);
		for ($i=0; $i <= $diff->y ; $i++) {
			$i1 = $data_inicial->format('Y');
			$anos[$i1] = $i1; 
			$data_inicial->modify('+1 year');
		}
		return $anos;
	}

	function setHorario(DateTime $data, $horaString){
		list($hora, $minuto) = explode(':', $horaString);
		$data->setTime((int)$hora, (int)$minuto);
		return $data;
	}

	function returAnos(){
		$mes = array(
			'2017' => '2017',
			'2018' => '2018',
			'2019' => '2019',
			'2020' => '2020',
			'2021' => '2021',
			'2022' => '2022',
			'2023' => '2023',
			'2024' => '2024',
			'2025' => '2025',
			'2026' => '2026',
			'2027' => '2027',
			'2028' => '2028',
			'2029' => '2029',
			'2030' => '2030',
		);
		return $mes;
	}

	function returnNumeroMes(){
		$meses = null;
		for ($i=1; $i <=12 ; $i++) { 
			$meses[] = $i;
		}
		return $meses;
	}

	function funcValor( $aValor, $aTipo, $a_dec = 2 ) { // valores com mascara e sem mascara
		$valor  = $aValor;
		$aValor = (double)$aValor;
		switch ($aTipo):
			case 'L':// com mascara
				$valor = str_replace( ',', '.', str_replace( '.', '', $valor ) );
			break;
			case 'C':// com mascara
				$valor = number_format( arredondado( $aValor, $a_dec), $a_dec, ',', '.' );
			break;
			case 'S':// sem mascara
				$valor = str_replace(',', '.', str_replace('.', '', $aValor));
				$valor = number_format($valor, $a_dec, '', '');
			break;
			case 'A':// arrendonda
				$valor = arredondado($aValor, $a_dec);
				$valor = number_format($valor, $a_dec, '.', '');
				break;
			case 'D':// Decimais sem arredonda,sem mascara
				$posPonto = strpos($aValor, '.');
				if ($posPonto > 0):
					$valor = substr($aValor, 0, $posPonto) . '.' . substr($aValor, $posPonto + 1, $a_dec);
				else:
					$valor = $aValor;
				endif;
			break;
			case 'E':// Decimais sem arredonda,sem mascara
				$posPonto = strpos($aValor, '.');
				if ($posPonto > 0):
					$decimal = str_pad(substr($aValor, $posPonto + 1, $a_dec), 2, 0, STR_PAD_RIGHT);
					$valor = substr($aValor, 0, $posPonto) . '.' . $decimal;
					$valor = str_replace(',', '.', str_replace('.', '', $valor));
				else:
					$valor = $aValor.'00';
				endif;
			break;
			case 'F':// Decimais sem arredondamento,sem mascara
				if(strpos($aValor, '-') !== false){
					$aValor = str_replace('-', '', $aValor);
					$negative = '-';
				}else{
					$negative = null;
				}
				$size = strlen($aValor);
				if($size > 2){
					$size     = ($size - 2);
					$parte1   = (string)substr($aValor, 0, $size);
					$centavos = substr($aValor, -2);
					$valor_convertido = $parte1.'.'.$centavos;
				}else{
					if($aValor > 10){
						$valor_convertido = '0.'.$aValor;
					}else{
						$valor_convertido = '0.0'.$aValor;
					}
				}
				$valor = $valor_convertido;
			break;
		endswitch;
		return $valor;
	}

	function arredondado ( $numero, $decimais ) {
		$fator = pow(10, $decimais);
		return (round($numero*$fator)/$fator); 
	}

	// Função de porcentagem: Quanto é X% de N?
	// Calcula quanto em valor representa uma porcentagem ex: 10% de 100 é = 10
	function porcentagem_xn ( $porcentagem, $total ) {
		return ( $porcentagem / 100 ) * $total;
	}

	// Função de porcentagem: N é X% de N
	// Calcula quanto um determinado valor representa em % de um total ex: 90 representa 18% de 500
	function porcentagem_nx ( $valor, $total ) {
		return ( $valor * 100 ) / $total;
	}

	// Função de porcentagem: N é N% de X
	// calcula o valor total a partir do valor parcial mais a porcentagem conhecida ex: o valor parcial noventa equiva a 18% de ? (Resposta 500)
	function porcentagem_nnx ( $parcial, $porcentagem ) {
		return ( $parcial / $porcentagem ) * 100;
	}

	// Função de porcentagem: N é N% de X
	// Calcula quanto um determinado valor está acima de outro em porcentagem, ex: o valor total representado por 100 é 1000% maior que 10
	function porcentagem_nxplus ( $v1, $v2 ) {
		$r1 = ( ( ( $v1 / $v2 ) * 100 ) -100 );
		return $r1;
	}

	// Para saber o valor anterior a um tendo apenas o valor atual e percentual, ex: o valor atual 780 com reajuste de 20% antes era 650 
	function porcentagem_pnn ( $valor, $percentual ) {
		$resultado = ( ( $valor * 100 ) / ( 100 + $percentual ) );
		return $resultado;
	}

	//unir dois array simples
	function unionSimpleArray( $arrayA, $arrayB ){
		if($arrayA && $arrayB){
			$arr = $arrayA;
			foreach ($arrayB as $key => $value) {
				$arr[] = $value;
			}
			return $arr;
		}else{
			return false;
		}
	}

	function mb_str_pad( $input, $pad_length, $pad_string = ' ', $pad_type = STR_PAD_RIGHT, $encoding = "UTF-8") {
		$diff = strlen( $input ) - mb_strlen($input, $encoding);
		return str_pad( $input, $pad_length + $diff, $pad_string, $pad_type );
	}

	function removeHtml( $string, $breakreplace = null ){
		$value = trim($string);
		
		if($breakreplace){
			$value = preg_replace('/[\n|\r|\n\r|\r\n]{2,}/',' ', $string );
			$value = str_replace('\n', '', $value);
			$value = str_replace('\r', '', $value);
			$value = str_replace('\r\n', '', $value);
			$value = str_replace('<p>&nbsp;</p>', '', $value);
			$value = str_replace('<p>&nbsp;</p>', '', $value);
			$value = str_replace('&nbsp;', '', $value);
			$value = str_replace('<p>', '', $value);
			$value = str_replace('</p>', $breakreplace, $value);
			$value = str_replace('<br>', $breakreplace, $value);
			$value = str_replace('<br />', $breakreplace, $value);
		}

		return strip_tags($value);
	}

	function restoDivisao( $var1, $var2 ) {
		$var1 = (float)$var1;
		$var2 = (float)$var2;
		$tmp = round(($var1/$var2),2);
		$tmp2 = round((float)($tmp * $var2),2);
		$return = round(($var1 - $tmp2), 2);
		return $return;
	}

	function convertToObject( $variable ){
		if(is_array($variable)){
			$variable = json_encode($variable);
		}
		return json_decode($variable);
	}

	function CurlExec( $url, $param = null, $curl_options = null ){
		set_time_limit(1800);
		$curl  = curl_init($url);
		// parametros padrões do CURL, podem ser sobrepostos pelo 
		curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0");
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');
		curl_setopt($curl, CURLOPT_POSTFIELDS, $param);
		if($curl_options){
			foreach ($curl_options as $key => $value) {
				curl_setopt($curl, $key, $value);
			}
		}

		if( curl_errno( $curl ) ){
			$error_code    = curl_errno($curl);
			$error_message = curl_error($curl);
		}
		$output = curl_exec( $curl );
		$info 	= curl_getinfo( $curl );
		curl_close( $curl );
		return $output;
	}

	function generateRandomString( $length = 10 ) {
		$characters 	  = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen( $characters );
		$randomString 	  = '';
		for ( $i = 0; $i < $length; $i++ ) {
			$randomString .= $characters[ rand( 0, $charactersLength - 1 ) ];
		}
		return $randomString;
	}

	function randDouble( $min, $max, $precision = 2 ) {
		// Definindo o fator de escala com base na precisão desejada
		$factor = pow(10, $precision);
		// Gerando um número inteiro aleatório entre min*factor e max*factor
		$randInt = rand($min * $factor, $max * $factor);
		// Convertendo o número inteiro de volta para um float com a precisão desejada
		return $randInt / $factor;
	}

	function gerarNumeroRandom( $tipo, $ini = null, $limit = null ){
		$args = func_get_args();
		switch ( $args[0] ) {
			case 'money':
				if( $args[1] ){
					$inicio = $args[1];
				}else{
					$inicio = 0.01;
				}

				if( $args[2] ){
					$limit = $args[2];
				}else{
					$limit = 0.10;
				}
				$retorno = number_format( randDouble( $inicio, $limit ), 2, '.', '');
			break;
			case 'unico':
				if ( $ini <= 13 ) {
					// Caso o comprimento solicitado seja menor ou igual a 13
					return substr( uniqid( mt_rand(), true ), 0, $ini );
				}
				$uniqueString = uniqid( mt_rand(), true);
				// Adiciona mais entropia para aumentar o comprimento
				while ( strlen( $uniqueString ) < $ini ) {
					$uniqueString .= uniqid( mt_rand(), true );
				}
				$retorno = substr( $uniqueString, 0, $ini );
			break;
			default:
				if( $args[1] ){
					$inicio = $args[1];
				}else{
					$inicio = 1001;
				}

				if( $args[2] ){
					$limit = $args[2];
				}else{
					$limit = 9999;
				}
				$retorno = rand( $inicio, $limit );
			break;
		}
		return $retorno;
	}

	function pegarIp(){
		//verifica se não é vazio
		if (!empty($_SERVER['HTTP_CLIENT_IP'])){
			$ip=$_SERVER['HTTP_CLIENT_IP'];
		}
		//verifica se vem de um proxy
		elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
			$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
		}
		else{
			$ip=$_SERVER['REMOTE_ADDR'];
		}
		//retorna ip
		return $ip;
	}
	
	function pegaBrowser(){
		$userAgent = $_SERVER['HTTP_USER_AGENT'];
		$browser = "Unknown Browser";

		// Lista de navegadores comuns
		$browserArray = array(
			'/msie/i'       => 'Internet Explorer',
			'/firefox/i'    => 'Firefox',
			'/safari/i'     => 'Safari',
			'/chrome/i'     => 'Chrome',
			'/edge/i'       => 'Edge',
			'/opera/i'      => 'Opera',
			'/netscape/i'   => 'Netscape',
			'/maxthon/i'    => 'Maxthon',
			'/konqueror/i'  => 'Konqueror',
			'/mobile/i'     => 'Handheld Browser'
		);

		// Verifica qual navegador corresponde ao user agent
		foreach ($browserArray as $regex => $value) {
			if (preg_match($regex, $userAgent)) {
				$browser = $value;
			}
		}
		return $browser;
	}

	function pegarEsquema(){
		return ( !empty($_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
	}

	function pegarHost(){
		return $_SERVER['HTTP_HOST'];
	}

	function pegarUri(){
		return $_SERVER['REQUEST_URI'];
	}

	function pegarUrl(){
		return pegarEsquema().'://'.pegarHost().pegarUri();
	}

	function getLocalInfo(){
		$retorno['ip'] 		= pegarIp();
		$retorno['esquema'] = pegarEsquema();
		$retorno['host'] 	= pegarHost();
		$retorno['uri']     = pegarUri();
		$retorno['url']     = pegarUrl();
		$retorno['browser'] = pegaBrowser();
		return json_encode( $retorno );
	}

	//declara a função
	function list_files( $dir ){
		// verifica se a é um diretório
		if( is_dir( $dir ) ){
			//abre o diretorio
			if( $handle = opendir( $dir ) ){
				// percorre os registros do diretorio
				while( ( $file = readdir( $handle ) ) !== false ){
					if( $file != "." && $file != ".." && $file != "Thumbs.db" ){
						//monta um link com o nome do arquivo
						echo '<a target="_blank" href="'.$dir.$file.'">'.$file.'</a><br>'."n";
					}
				}
				closedir($handle);
			}
		}
	}

	function getDiasUteis( $dtInicio, $dtFim, $feriados = [] ) {
		$tsInicio = strtotime($dtInicio);
		$tsFim = strtotime($dtFim);
		$quantidadeDias = 0;
		while ($tsInicio <= $tsFim) {
			// Verifica se o dia é igual a sábado ou domingo, caso seja continua o loop
			$diaIgualFinalSemana = (date('D', $tsInicio) === 'Sat' || date('D', $tsInicio) === 'Sun');
			// Verifica se é feriado, caso seja continua o loop
			$diaIgualFeriado = (count($feriados) && in_array(date('Y-m-d', $tsInicio), $feriados));

			$tsInicio += 86400; // 86400 quantidade de segundos em um dia

			if ($diaIgualFinalSemana || $diaIgualFeriado) {
				continue;
			}

			$quantidadeDias++;
		}
		return $quantidadeDias;
	}

	function countSemanasMes ($ano, $mes) {
		$data = new DateTime("$ano-$mes-01");
		$dataFimMes = new DateTime($data->format('Y-m-t'));

		$numSemanaInicio = $data->format('W');
		$numSemanaFinal  = $dataFimMes->format('W') + 1;

		// Última semana do ano pode ser semana 1
		$numeroSemanas = ($numSemanaFinal < $numSemanaInicio)  
			? (52 + $numSemanaFinal) - $numSemanaInicio
			: $numSemanaFinal - $numSemanaInicio;

		return $numeroSemanas;

	}

	function weekOfYear($date) {
		$weekOfYear = intval(date("W", $date));
		if (date('n', $date) == "1" && $weekOfYear > 51) {
			// It's the last week of the previos year.
			$weekOfYear = 0;    
		}
		return $weekOfYear;
	}

	function weekOfMonth($date) {
		//Get the first day of the month.
		$firstOfMonth = strtotime(date("Y-m-01", $date));
		//Apply above formula.
		return weekOfYear($date) - weekOfYear($firstOfMonth) + 1;
	}

	function validar( $string, $tipo ){
		switch ($tipo) {
			case 'cnpj':
				return validarCNPJ($string);
			break;
			case 'cpf':
				return validarCPF($string);
			break;
			case 'email':
				# code...
				return filter_var( filter_var( $string, FILTER_SANITIZE_EMAIL ), FILTER_VALIDATE_EMAIL );
			break;
			case 'telefone':
				return validarTelefone($string);
			break;
			default:
				return false;
			break;
		}
	}

	function validarCNPJ($cnpj){
		// Deixa o CNPJ com apenas números
		$cnpj = preg_replace( '/[^0-9]/', '', $cnpj );
			
		// Garante que o CNPJ é uma string
		$cnpj = (string)$cnpj;

		// O valor original
		$cnpj_original = $cnpj;

		// Captura os primeiros 12 números do CNPJ
		$primeiros_numeros_cnpj = substr( $cnpj, 0, 12 );

		/**
		 * Multiplicação do CNPJ
		 *
		 * @param string $cnpj Os digitos do CNPJ
		 * @param int $posicoes A posição que vai iniciar a regressão
		 * @return int O
		 *
		 */
		if ( ! function_exists('multiplica_cnpj') ) {
			function multiplica_cnpj( $cnpj, $posicao = 5 ) {
				// Variável para o cálculo
				$calculo = 0;
				
				// Laço para percorrer os item do cnpj
				for ( $i = 0; $i < strlen( $cnpj ); $i++ ) {
					// Cálculo mais posição do CNPJ * a posição
					$calculo = $calculo + ( $cnpj[$i] * $posicao );
					
					// Decrementa a posição a cada volta do laço
					$posicao--;
					
					// Se a posição for menor que 2, ela se torna 9
					if ( $posicao < 2 ) {
						$posicao = 9;
					}
				}
				// Retorna o cálculo
				return $calculo;
			}
		}

		// Faz o primeiro cálculo
		$primeiro_calculo = multiplica_cnpj( $primeiros_numeros_cnpj );

		// Se o resto da divisão entre o primeiro cálculo e 11 for menor que 2, o primeiro
		// Dígito é zero (0), caso contrário é 11 - o resto da divisão entre o cálculo e 11
		$primeiro_digito = ( $primeiro_calculo % 11 ) < 2 ? 0 :  11 - ( $primeiro_calculo % 11 );

		// Concatena o primeiro dígito nos 12 primeiros números do CNPJ
		// Agora temos 13 números aqui
		$primeiros_numeros_cnpj .= $primeiro_digito;

		// O segundo cálculo é a mesma coisa do primeiro, porém, começa na posição 6
		$segundo_calculo = multiplica_cnpj( $primeiros_numeros_cnpj, 6 );
		$segundo_digito = ( $segundo_calculo % 11 ) < 2 ? 0 :  11 - ( $segundo_calculo % 11 );

		// Concatena o segundo dígito ao CNPJ
		$cnpj = $primeiros_numeros_cnpj . $segundo_digito;

		// Verifica se o CNPJ gerado é idêntico ao enviado
		if ( $cnpj === $cnpj_original ) {
			return true;
		}else{
			return false;
		}
	}

	function validarCPF($cpf){
		if(!$cpf){
			return false;
		}elseif (
			$cpf == '00000000000' || 
			$cpf == '11111111111' || 
			$cpf == '22222222222' || 
			$cpf == '33333333333' || 
			$cpf == '44444444444' || 
			$cpf == '55555555555' || 
			$cpf == '66666666666' || 
			$cpf == '77777777777' || 
			$cpf == '88888888888' || 
			$cpf == '99999999999'
		){
			return false;
		}elseif(strlen($cpf) != 11){
			return false;
		}
		
		// Extrai somente os números
		$cpf = preg_replace( '/[^0-9]/is', '', $cpf );
			
		// Verifica se foi informado todos os digitos corretamente
		if (strlen($cpf) != 11) {
			return false;
		}

		// Verifica se foi informada uma sequência de digitos repetidos. Ex: 111.111.111-11
		if (preg_match('/(\d)\1{10}/', $cpf)) {
			return false;
		}

		// Faz o calculo para validar o CPF
		for ($t = 9; $t < 11; $t++) {
			for ($d = 0, $c = 0; $c < $t; $c++) {
				$d += $cpf[$c] * (($t + 1) - $c);
			}
			$d = ((10 * $d) % 11) % 10;
			if ($cpf[$c] != $d) {
				return false;
			}
		}
		return true;
	}

	function validarTelefone($telefone){
		//processa a string mantendo apenas números no valor de entrada.
		$telefone = preg_replace("/[^0-9]/", "", $telefone); 
		$lentelefone = strlen($telefone);
		//validando a quantidade de caracteres de telefone fixo ou celular.
		if($lentelefone != 10 && $lentelefone != 11)
			return false;

		//DD e número de telefone não podem começar com zero.
		if($telefone[0] == "0" || $telefone[2] == "0")
			return false;

		return true;
	}

	function convertIP( $ip, $to = 'decimal' ){
		if($ip){
			switch ($to) {
				case 'decimal':
					$ip_array = explode('.', $ip);
					if(count($ip_array) > 1){
						$ip_decimal = (($ip_array[0] * (256*256*256)) + ($ip_array[1] * (256*256)) + ($ip_array[2] * (256)) + $ip_array[3]);
						return $ip_decimal;
					}else{
						return false;
					}
				break;
			}
		}else{
			return false;
		}
	}

	function calculaPeriodoEmMinutos( $periodo_ini, $periodo_fim ){
		if( is_object( $periodo_ini ) && is_object( $periodo_fim ) ){
			$obj_ini = clone $periodo_ini;
			$obj_fim = clone $periodo_fim;
		}else{
			$obj_ini = new DateTime( $periodo_ini );
			$obj_fim = new DateTime( $periodo_fim );
		}
		$diff = $obj_ini->diff( $obj_fim );
		$total_minutos = ($diff->days * 24 * 60); 
		$total_minutos += ($diff->h * 60); 
		$total_minutos += $diff->i;
		return $total_minutos;
	}

	function primeiroUltimoDiaSemana( $data ){
		$obj_data = getDataAtual( $data );	
		switch ( $obj_data->format( "w" ) ) {
			case '0':
				$retorno['first_week'] = $obj_data->format("Y-m-d");
				$obj_data->modify("+6 days");
				$retorno['last_week']  = $obj_data->format("Y-m-d");
			break;
			case '1':
				$obj_data->modify("-1 days");
				$retorno['first_week'] = $obj_data->format("Y-m-d");
				$obj_data->modify("+6 days");
				$retorno['last_week']  = $obj_data->format("Y-m-d");
			break;
			case '2':
				$obj_data->modify("-2 days");
				$retorno['first_week'] = $obj_data->format("Y-m-d");
				$obj_data->modify("+6 days");
				$retorno['last_week']  = $obj_data->format("Y-m-d");
			break;
			case '3':
				$obj_data->modify("-3 days");
				$retorno['first_week'] = $obj_data->format("Y-m-d");
				$obj_data->modify("+6 days");
				$retorno['last_week']  = $obj_data->format("Y-m-d");
			break;
			case '4':
				$obj_data->modify("-4 days");
				$retorno['first_week'] = $obj_data->format("Y-m-d");
				$obj_data->modify("+6 days");
				$retorno['last_week']  = $obj_data->format("Y-m-d");
			break;
			case '5':
				$obj_data->modify("-5 days");
				$retorno['first_week'] = $obj_data->format("Y-m-d");
				$obj_data->modify("+6 days");
				$retorno['last_week']  = $obj_data->format("Y-m-d");
			break;
			case '6':
				$obj_data->modify("-6 days");
				$retorno['first_week'] = $obj_data->format("Y-m-d");
				$obj_data->modify("+6 days");
				$retorno['last_week']  = $obj_data->format("Y-m-d");
			break;		
			default:
			break;
		}
		return $retorno;
	}

	function getCodigoPaises(){
		return json_decode(file_get_contents( ABSPATH.DS.'includes'.DS.'lista_paises_onu.json' ));
	}

	function getDdiPaises(){
		return json_decode(file_get_contents( ABSPATH.DS.'includes'.DS.'lista_paises_ddi.json' ));
	}

	function getDadosPaises(){
		return json_decode(file_get_contents( ABSPATH.DS.'includes'.DS.'lista_paises.json'));
	}


	function gerarCPF() {
		// Gera os 9 primeiros dígitos do CPF aleatoriamente
		$noveDigitos = '';
		for ($i = 0; $i < 9; $i++) {
			$noveDigitos .= mt_rand(0, 9);
		}

		// Calcula o primeiro dígito verificador
		$primeiroDigito = calcularDigitoVerificador($noveDigitos);

		// Adiciona o primeiro dígito verificador ao CPF
		$dezDigitos = $noveDigitos . $primeiroDigito;

		// Calcula o segundo dígito verificador
		$segundoDigito = calcularDigitoVerificador($dezDigitos);

		// Monta o CPF completo com os dígitos verificadores
		$cpfCompleto = $dezDigitos . $segundoDigito;

		return $cpfCompleto;
	}

	function calcularDigitoVerificador($base) {
		$tamanho = strlen($base);
		$soma = 0;
		$peso = $tamanho + 1;

		for ($i = 0; $i < $tamanho; $i++) {
			$soma += $base[$i] * $peso;
			$peso--;
		}

		$resto = $soma % 11;
		return $resto < 2 ? 0 : 11 - $resto;
	}

	function validaId( $id ){
		if ( isset( $id ) && !empty( $id ) && is_numeric( $id )){
			return true;
		}else{
			return false;
		}
	}

	function loadExtras( $n1, $n2 ){
		global $VAR_SYSTEM;
		return $VAR_SYSTEM[$n1][$n2];
	}

	// dado um array com valores a funcao retorna o valor mais proximo do que foi informado
	function valorMaisProximo($array, $valor) {
		$maisProximo = null;
		$menorDiferenca = PHP_INT_MAX;
		foreach ($array as $item) {
			$diferenca = abs($item - $valor);
			if ($diferenca < $menorDiferenca) {
				$menorDiferenca = $diferenca;
				$maisProximo = $item;
			}
		}
		return $maisProximo;
	}
	
	function encryptData($data)
	{
		// Obtendo a senha do ambiente
		$password = getenv('PASSWORD_CRIPTO');
		if (!$password) {
			die("Erro: A variável de ambiente PASSWORD_CRIPTO não está definida.\n");
		}

		// Salt fixo ou obtido de um banco de dados/arquivo seguro
		$salt = getenv('SALT_CRIPTO');
		if (!$salt) {
			die("Erro: A variável de ambiente SALT_CRIPTO não está definida.\n");
		}

		// Gerar chave usando PBKDF2 (SHA-256, 10000 iterações, 32 bytes)
		$key = hash_pbkdf2("sha256", $password, $salt, 10000, 32, true);

		// Criar IV aleatório de 16 bytes
		$iv = openssl_random_pseudo_bytes(16);

		// Criptografar os dados
		$encrypted = openssl_encrypt($data, 'AES-256-CBC', $key, 0, $iv);

		// Retornar IV + dado criptografado (codificado em Base64)
		return base64_encode($iv . $encrypted);
	}

	function decryptData($encryptedData)
	{
		// Obtendo a senha do ambiente
		$password = getenv('PASSWORD_CRIPTO');
		if (!$password) {
			die("Erro: A variável de ambiente PASSWORD_CRIPTO não está definida.\n");
		}

		// Salt fixo ou obtido de um banco de dados/arquivo seguro
		$salt = getenv('SALT_CRIPTO');
		if (!$salt) {
			die("Erro: A variável de ambiente SALT_CRIPTO não está definida.\n");
		}

		// Gerar chave novamente para descriptografar
		$key = hash_pbkdf2("sha256", $password, $salt, 10000, 32, true);

		// Decodificar Base64
		$raw = base64_decode($encryptedData);

		// Separar IV (16 bytes) e o dado criptografado
		$iv = substr($raw, 0, 16);
		$ciphertext = substr($raw, 16);

		// Descriptografar os dados
		return openssl_decrypt($ciphertext, 'AES-256-CBC', $key, 0, $iv);
	}
	
	function simNao($param)
	{
		switch (strtolower($param)) {
			case 'sim':
			case '1':
				return 'SIM';
				break;
			default:
				return 'NÃO';
				break;
		}
	}
	
	function gerarCodigoUnico($prefixo = 'CM', $tamanho_total = 12)
	{
		$prefixo = strtoupper(substr(preg_replace('/[^A-Z0-9]/', '', $prefixo), 0, 3));
		$restante = max($tamanho_total - strlen($prefixo), 1);
		$numeros = '';

		for ($i = 0; $i < $restante; $i++) {
			$numeros .= mt_rand(0, 9);
		}

		return $prefixo . $numeros;
	}

	function lastKey(array $array)
	{
		if (empty($array)) {
			return null; // se o array for vazio
		}
		end($array);          // move o ponteiro para o último elemento
		return key($array);   // retorna a chave
	}

	/**
	 * Busca avançada recursiva em arrays/objetos com múltiplos filtros e operadores.
	 * Compatível com PHP 5.6 até 8.x
	 *
	 * @param array|object $dados          Estrutura de dados (array ou objeto)
	 * @param string|array $filtros        Filtros:
	 *    - string: nome parcial ou completo do atributo (retorna valores)
	 *    - array: ['campo' => 'valor', 'campo2' => ['operador' => '>', 'valor' => 10]]
	 * @param bool         $retornarArray  Se true, retorna sempre array
	 *
	 * @return mixed  Valor, array de valores ou objetos correspondentes
	 */
	function buscarAtributo($dados, $filtros, $retornarArray = false){
		$resultados = array();

		// Normaliza filtros simples
		if (is_string($filtros)) {
			$filtros = array($filtros => null);
		}

		// Função comparadora (suporta operadores)
		$comparar = function ($valorCampo, $condicao) {
			if (is_array($condicao)) {
				$op = isset($condicao['operador']) ? strtolower($condicao['operador']) : '=';
				$valor = isset($condicao['valor']) ? $condicao['valor'] : null;
			} else {
				$op = '=';
				$valor = $condicao;
			}

			switch ($op) {
				case '=':  return $valorCampo == $valor;
				case '!=': return $valorCampo != $valor;
				case '>':  return $valorCampo > $valor;
				case '<':  return $valorCampo < $valor;
				case '>=': return $valorCampo >= $valor;
				case '<=': return $valorCampo <= $valor;
				case 'in': return is_array($valor) && in_array($valorCampo, $valor);
				case 'not_in': return is_array($valor) && !in_array($valorCampo, $valor);
				case 'like': return (stripos($valorCampo, $valor) !== false);
				case 'regex': return @preg_match($valor, $valorCampo);
				default: return false;
			}
		};

		// Busca recursiva (sem arrow functions, compatível com PHP 5.6)
		$buscarRecursivo = function ($item, $chavePai = null) use (&$buscarRecursivo, $filtros, &$resultados, $comparar) {
			if (is_object($item)) {
				$campos = get_object_vars($item);
				$corresponde = true;

				// Testa todos os filtros
				foreach ($filtros as $campo => $condicao) {
					$encontrado = false;
					foreach ($campos as $nome => $valor) {
						// Permite busca parcial no nome do atributo
						if (stripos($nome, $campo) !== false) {
							$encontrado = true;
							if ($condicao !== null && !$comparar($valor, $condicao)) {
								$corresponde = false;
								break;
							}
						}
					}
					if (!$encontrado) $corresponde = false;
					if (!$corresponde) break;
				}

				if ($corresponde) {
					$key = $chavePai ? $chavePai : spl_object_hash($item);
					$resultados[$key] = $item;
				}

				// Busca recursiva nas propriedades
				foreach ($campos as $k => $v) {
					if (is_array($v) || is_object($v)) {
						$buscarRecursivo($v, $chavePai ? $chavePai : $k);
					}
				}
			} elseif (is_array($item)) {
				foreach ($item as $k => $v) {
					$buscarRecursivo($v, $k);
				}
			}
		};

		$buscarRecursivo($dados);

		// Se for apenas um atributo simples sem valor, retorna valores dele
		if (count($filtros) === 1 && reset($filtros) === null) {
			$atributo = key($filtros);
			$valores = array();
			foreach ($resultados as $k => $obj) {
				foreach (get_object_vars($obj) as $nome => $valor) {
					if (stripos($nome, $atributo) !== false) {
						$valores[$k] = $valor;
					}
				}
			}
			$resultados = $valores;
		}

		// Retorno
		if ($retornarArray) {
			return $resultados;
		}

		if (count($resultados) === 1) {
			return reset($resultados);
		}

		return $resultados;
	}

	/**
	 * Busca recursivamente por atributos existentes (ou parte do nome) e retorna seus valores.
	 * Compatível com PHP 5.6 a 8.x
	 *
	 * @param array|object $dados         Estrutura de dados (array ou objeto)
	 * @param string       $atributoBusca Nome (ou parte) do atributo a procurar
	 * @param bool         $retornarArray Se true, sempre retorna array
	 * @param bool         $retornarObjetos Se true, retorna objetos completos que possuem o atributo
	 *
	 * @return mixed  Valor único, array de valores, ou objetos correspondentes
	 */
	//
	// 1️⃣ Buscar onde existe "origem_elemento" e retornar os valores encontrados
	//
	// $result = buscarAtributoExistente($dados, 'origem_elemento');
	// → ['COR0010' => 'COR0010', 'sub' => 'SUB0010', 'COR0011' => 'COR0011']

	//
	// 2️⃣ Buscar apenas se existe (exemplo: "valor_limite")
	//    retorna vazio se nenhum encontrado
	//
	// $result = buscarAtributoExistente($dados, 'valor_limite');
	// → []
	//
	// 3️⃣ Retornar os objetos que possuem o atributo (em vez do valor)
	//
	// $result = buscarAtributoExistente($dados, 'origem_elemento', true, true);
	// → ['COR0010' => stdClass(...), 'sub' => stdClass(...), 'COR0011' => stdClass(...)]
	function buscarAtributoExistente($dados, $atributoBusca, $retornarArray = false, $retornarObjetos = false)
	{
		$resultados = array();

		$buscarRecursivo = function ($item, $chavePai = null) use (&$buscarRecursivo, $atributoBusca, &$resultados, $retornarObjetos) {
			if (is_object($item)) {
				$campos = get_object_vars($item);

				foreach ($campos as $nome => $valor) {
					// Verifica se o atributo existe (ou contém parte do nome)
					if (stripos($nome, $atributoBusca) !== false) {
						$key = $chavePai ? $chavePai : spl_object_hash($item);
						if ($retornarObjetos) {
							$resultados[$key] = $item;
						} else {
							$resultados[$key] = $valor;
						}
					}

					// Se o valor for array/objeto, continua buscando
					if (is_array($valor) || is_object($valor)) {
						$buscarRecursivo($valor, $chavePai ? $chavePai : $nome);
					}
				}
			} elseif (is_array($item)) {
				foreach ($item as $k => $v) {
					$buscarRecursivo($v, $k);
				}
			}
		};

		$buscarRecursivo($dados);

		// Se for apenas um resultado, retorna direto (a menos que queira sempre array)
		if (!$retornarArray && count($resultados) === 1) {
			return reset($resultados);
		}

		return $resultados;
	}

	/**
	 * Verifica se um array é "vazio de fato".
	 * Compatível com PHP 5.x até 8.x
	 *
	 * Considera o array vazio se:
	 *   - não possui elementos, ou
	 *   - todos os elementos são nulos, vazios ou arrays vazios recursivamente.
	 *
	 * @param mixed $arr
	 * @return bool
	 */
	function arrayVazio($arr){
		if (!is_array($arr)) {
			return true; // não é array, então consideramos "vazio de fato"
		}

		if (empty($arr)) {
			return true;
		}

		foreach ($arr as $valor) {
			// Se encontrar algum valor "real" (não vazio), retorna falso
			if (is_array($valor)) {
				if (empty($valor) || count($valor) == 0) {
					return false;
				}
			} elseif (!is_null($valor) && $valor !== '' && $valor !== false) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Une dois arrays aninhados de objetos com lógica inteligente e logging.
	 * Compatível com PHP 5.6 a 8.x
	 *
	 * Regras:
	 *  - Numéricos → soma
	 *  - Strings → concatena (com separador)
	 *  - Arrays → une recursivamente
	 *  - Objetos → mescla atributos recursivamente
	 *  - Outros → sobrescreve (ou mantém, se $sobrescrever = false)
	 *
	 * @param array  $arr1
	 * @param array  $arr2
	 * @param bool   $sobrescrever        Se false, mantém valores originais
	 * @param string $separadorConcat     Separador usado para concatenar strings
	 * @param bool   $logAtivo            Se true, ativa o modo log
	 * @param string $arquivoLog          Caminho opcional do arquivo de log (ou null para exibir na tela)
	 * @return array
	 */
	function unirArraysObjetosInteligente(array $arr1, array $arr2, $sobrescrever = true, $separadorConcat = ' ', $logAtivo = false, $arquivoLog = null)
	{
		// Função interna para registrar log
		$log = function ($mensagem) use ($logAtivo, $arquivoLog) {
			if (!$logAtivo) return;
			$linha = '[' . date('Y-m-d H:i:s') . "] " . $mensagem . "\n";
			if ($arquivoLog) {
				@file_put_contents($arquivoLog, $linha, FILE_APPEND);
			} else {
				echo $linha;
			}
		};

		foreach ($arr2 as $chaveExterna => $subArray) {

			if (!isset($arr1[$chaveExterna])) {
				$arr1[$chaveExterna] = $subArray;
				$log("Adicionado grupo externo: {$chaveExterna}");
				continue;
			}

			foreach ($subArray as $chaveInterna => $objeto) {

				if (!isset($arr1[$chaveExterna][$chaveInterna])) {
					$arr1[$chaveExterna][$chaveInterna] = $objeto;
					$log("Adicionado novo módulo {$chaveInterna} em {$chaveExterna}");
					continue;
				}

				$destino = $arr1[$chaveExterna][$chaveInterna];

				// Ambos são objetos → mescla propriedades
				if (is_object($destino) && is_object($objeto)) {
					foreach (get_object_vars($objeto) as $prop => $val) {

						if (!property_exists($destino, $prop)) {
							$destino->{$prop} = $val;
							$log("Novo campo {$prop} adicionado em {$chaveExterna}->{$chaveInterna}");
							continue;
						}

						$destVal = $destino->{$prop};

						// --- Fusão inteligente ---
						if (is_numeric($destVal) && is_numeric($val)) {
							$old = $destVal;
							$destino->{$prop} = $destVal + $val;
							$log("Somado {$chaveExterna}->{$chaveInterna}->{$prop}: {$old} + {$val} = {$destino->{$prop}}");
						} elseif (is_string($destVal) && is_string($val)) {
							if ($destVal !== $val && $val !== '') {
								$old = $destVal;
								$destino->{$prop} = trim($destVal . $separadorConcat . $val);
								$log("Concatenado {$chaveExterna}->{$chaveInterna}->{$prop}: '{$old}' + '{$val}'");
							}
						} elseif (is_array($destVal) && is_array($val)) {
							$destino->{$prop} = unirArraysObjetosInteligente($destVal, $val, $sobrescrever, $separadorConcat, $logAtivo, $arquivoLog);
							$log("Mesclado array em {$chaveExterna}->{$chaveInterna}->{$prop}");
						} elseif (is_object($destVal) && is_object($val)) {
							foreach (get_object_vars($val) as $p2 => $v2) {
								if (!property_exists($destVal, $p2) || $sobrescrever) {
									$destVal->{$p2} = $v2;
									$log("Mesclado objeto interno {$chaveExterna}->{$chaveInterna}->{$prop}->{$p2}");
								}
							}
							$destino->{$prop} = $destVal;
						} elseif ($sobrescrever) {
							$old = is_scalar($destVal) ? $destVal : gettype($destVal);
							$destino->{$prop} = $val;
							$log("Sobrescrito {$chaveExterna}->{$chaveInterna}->{$prop}: '{$old}' → '{$val}'");
						}
					}
				} else {
					if ($sobrescrever) {
						$arr1[$chaveExterna][$chaveInterna] = $objeto;
						$log("Substituído objeto {$chaveExterna}->{$chaveInterna}");
					}
				}
			}
		}

		return $arr1;
	}

	/**
	 * Lê o log de merge e gera um resumo estatístico das operações realizadas.
	 * Compatível com PHP 5.6 a 8.x.
	 *
	 * @param string $arquivoLog Caminho do arquivo de log gerado por unirArraysObjetosInteligente()
	 * @param bool   $exibirDetalhes Se true, exibe também as amostras das linhas encontradas
	 * @return array Retorna um array associativo com as contagens de operações
	 */
	function merge_debug_resumo($arquivoLog, $exibirDetalhes = true)
	{
		if (!file_exists($arquivoLog)) {
			echo "Arquivo de log não encontrado: {$arquivoLog}\n";
			return array();
		}

		$conteudo = @file($arquivoLog, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
		if (!$conteudo) {
			echo "Log vazio ou ilegível.\n";
			return array();
		}

		$resumo = array(
			'somados'       => 0,
			'concatenados'  => 0,
			'arrays_mesclados' => 0,
			'objetos_mesclados' => 0,
			'sobrescritos'  => 0,
			'novos_campos'  => 0,
			'novos_modulos' => 0,
			'grupos_adicionados' => 0,
			'total_linhas'  => count($conteudo)
		);

		foreach ($conteudo as $linha) {
			if (stripos($linha, 'Somado') !== false) $resumo['somados']++;
			elseif (stripos($linha, 'Concatenado') !== false) $resumo['concatenados']++;
			elseif (stripos($linha, 'Mesclado array') !== false) $resumo['arrays_mesclados']++;
			elseif (stripos($linha, 'Mesclado objeto') !== false) $resumo['objetos_mesclados']++;
			elseif (stripos($linha, 'Sobrescrito') !== false) $resumo['sobrescritos']++;
			elseif (stripos($linha, 'Novo campo') !== false) $resumo['novos_campos']++;
			elseif (stripos($linha, 'Adicionado novo módulo') !== false) $resumo['novos_modulos']++;
			elseif (stripos($linha, 'Adicionado grupo externo') !== false) $resumo['grupos_adicionados']++;
		}

		if ($exibirDetalhes) {
			echo "=========================\n";
			echo " RESUMO DO MERGE INTELIGENTE\n";
			echo "=========================\n";
			echo "Linhas processadas: " . $resumo['total_linhas'] . "\n";
			echo "Somados:            " . $resumo['somados'] . "\n";
			echo "Concatenados:       " . $resumo['concatenados'] . "\n";
			echo "Arrays mesclados:   " . $resumo['arrays_mesclados'] . "\n";
			echo "Objetos mesclados:  " . $resumo['objetos_mesclados'] . "\n";
			echo "Sobrescritos:       " . $resumo['sobrescritos'] . "\n";
			echo "Novos campos:       " . $resumo['novos_campos'] . "\n";
			echo "Novos módulos:      " . $resumo['novos_modulos'] . "\n";
			echo "Grupos adicionados: " . $resumo['grupos_adicionados'] . "\n";
			echo "=========================\n\n";

			// Mostra amostras de cada tipo (útil para auditoria)
			$amostras = array_slice($conteudo, -10);
			echo "Últimas 10 operações:\n";
			foreach ($amostras as $linha) {
				echo "  " . trim($linha) . "\n";
			}
			echo "\n";
		}

		return $resumo;
	}

		
	// Função para gerar segredo Base32
	function generateSecret($length = 16) {
		$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
		$secret = '';
		for ($i = 0; $i < $length; $i++) {
			$secret .= $chars[rand(0, strlen($chars) - 1)];
		}
		return $secret;
	}

	// Base32 decode
	function base32Decode($b32) {
		$alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
		$b32 = strtoupper($b32);
		$l = strlen($b32);
		$n = 0;
		$j = 0;
		$binary = '';
		for ($i = 0; $i < $l; $i++) {
			$n = ($n << 5) + strpos($alphabet, $b32[$i]);
			$j += 5;
			if ($j >= 8) {
				$j -= 8;
				$binary .= chr(($n & (0xFF << $j)) >> $j);
			}
		}
		return $binary;
	}

	function buscarCampo($array, $campoBusca, $valorBusca, $campoRetorno = null, $retornarObjeto = false, $retornarMultiplos = false) {
		$resultados = array();

		foreach ($array as $obj) {
			if (isset($obj->$campoBusca) && $obj->$campoBusca == $valorBusca) {

				if ($retornarObjeto) {
					$resultado = $obj;
				} elseif ($campoRetorno !== null && isset($obj->$campoRetorno)) {
					$resultado = $obj->$campoRetorno;
				} else {
					$resultado = null;
				}

				if ($retornarMultiplos) {
					$resultados[] = $resultado;
				} else {
					return $resultado; // sai no primeiro achado
				}
			}
		}

		return $retornarMultiplos ? $resultados : null;
	}

	/**
	 * Cria subdiretórios dentro de um caminho base, compatível com Windows e Linux.
	 *
	 * @param string $basePath Caminho base absoluto
	 * @param string $relativePath Caminho relativo a ser criado dentro do base
	 * @param int $mode Permissões do mkdir
	 * @return array ['success'=>bool, 'path'=>string|null, 'error'=>string|null]
	 */
	function ensure_create_subdirs($basePath, $relativePath, $mode = 0777){
		// Detecta o separador correto do sistema
		$ds = DIRECTORY_SEPARATOR;
		
		// Normaliza separadores no basePath
		$basePath = str_replace(array('/', '\\'), $ds, trim($basePath));
		
		// Remove barra final do base
		$basePath = rtrim($basePath, $ds);
		
		// Normaliza separadores no relativePath
		$relativePath = str_replace(array('/', '\\'), $ds, trim($relativePath));

		// Remove barras do início e do fim
		$relativePath = trim($relativePath, " {$ds}");

		// Se relativePath estiver vazio, nada a criar
		if ($relativePath === '') {
			return array('success' => true, 'path' => $basePath, 'error' => null);
		}

		// Quebra por diretórios
		$parts = explode($ds, $relativePath);
		$safeParts = array();
		foreach ($parts as $p) {
			if ($p === '' || $p === '.') {
				continue;
			}
			if ($p === '..') {
				// Impede escapar acima do base
				if (count($safeParts) === 0) {
					return array(
						'success' => false,
						'path'    => null,
						'error'   => "O caminho relativo tenta sair do diretório base usando '..'"
					);
				}
				array_pop($safeParts);
				continue;
			}
			$safeParts[] = $p;
		}

		// Monta caminho final
		$targetPath = $basePath . $ds . implode($ds, $safeParts);
		// Verifica conflito com arquivo
		if (file_exists($targetPath) && !is_dir($targetPath)) {
			return array(
				'success' => false,
				'path'    => null,
				'error'   => "Existe um arquivo no lugar do diretório: {$targetPath}"
			);
		}

		// Cria diretórios
		if (!is_dir($targetPath)) {
			if (!@mkdir($targetPath, $mode, true)) {
				$err = error_get_last();
				return array(
					'success' => false,
					'path'    => null,
					'error'   => isset($err['message']) ? $err['message'] : 'mkdir falhou'
				);
			}
		}

		return array(
			'success' => true,
			'path'    => $targetPath,
			'error'   => null
		);
	}
