<?php
$texto[0] =
"       
    À  <br> 
    <b> **--CLIENTE--** </b> <br> 
    **--ENDERECO--** - **--BAIRRO--** <br> 
    **--CEP--** - **--CIDADE--** - **--UF--** <br> 
    <br> 
    <b> A/C.: **--REPRESENTANTE_LEGAL--** </b> 
    <br></br> 
    Assunto: Contrato de Prestação de Serviços – ECS Exclusive Colocation Service
    <br></br>
    Prezado Senhor(a),
    <br>
    <p>
        Primeiramente manifestamos nossos sinceros agradecimentos pela contratação dos serviços de ECS Exclusive Colocation Service, e concedemos as <b>Boas Vindas</b> à C&M Software.
    </p>
    <p>
        Encaminhamos em anexo o “Contrato de Prestação de Serviços – ECS Exclusive Colocation Service”, e pedimos a gentileza de ser assinado em 02 (duas) vias com o reconhecimento de 
        firma das assinaturas, e ser entregue no seguinte endereço:
    </p>
                
    <b>**--CM_SOFTWARE--**</b>
    <br> A/C: Departamento Jurídico. 
    <br> Alameda Rio Pardo, nº 27 - Alphaville Industrial. 
    <br> 06455-005 – Barueri – SP.  

    <p> Solicitamos, ainda, encarecidamente, que nos envie juntamente com o mencionado Contrato, os seguintes documentos: </p>      
    
    <ul>  Cópia simples do Contrato Social/Estatuto Social, bem como última alteração/ata de assembleia; </ul> 
    <ul>  Cartão do CNPJ;  </ul>
    <ul>  Cópia simples do RG e CPF do signatário do Contrato; e, </ul>
    <ul>  Se o signatário não constar do Contrato Social/Estatuto Social, solicitamos cópia da procuração que lhe outorgou poderes. </ul>         

    <br>
    Quaisquer dúvidas podem ser encaminhadas para os e-mails contratos@cmsw.com e juridico@cmsw.com, ou pelo telefone (11) 3365-2666.
    <br></br><br></br><br></br><br>
    Atenciosamente
    <br></br><br></br>    
    <table>
        <thead>
            <th style='text-align:center; width:800px;' >               
                <small>
                    **--CM_SOFTWARE--**
                    <br>Departamento Jurídico 
                </small>                               
            </th>
        </thead>
    </table>
";

$texto[1] =
"
    <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>
                <td style='text-align:center;border-bottom:2px solid;'>
                    <h3>INSTRUMENTO PARTICULAR DE PRESTAÇÃO DE SERVIÇOS – ECS EXCLUSIVE COLOCATION SERVICE E OUTRA AVENÇAS</h3>                        
                </td>
            </tr>
        </tbody>
    </table>
    <table cellpadding='1' cellspacing='4' style='width:100%'> 
        <tbody>
            <tr>
                <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'><b><small>QUADRO RESUMO</small></b></td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>
                    <b><small>CONTRATADA</small></b>
                    <br></br>
                    <p>
                        <b> **--CM_SOFTWARE--** </b>, pessoa jurídica de direito privado com sede na Alameda Rio Pardo, nº 27, 
                        Bairro Alphaville Industrial, no município de Barueri, Estado de São Paulo, CEP 06455-005, inscrita no CNPJ/MF sob o 
                        nº **--CM_SOFTWARE_CNPJ--**, doravante denominada simplesmente “<b>C&M SOFTWARE</b>”;
                    </p>
                    <br>
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>
                    <b><small>CONTRATANTE</small></b>
                    <br></br>
                    <p>
                        <b> **--CLIENTE--** </b>, pessoa jurídica de direito privado com endereço **--ENDERECO--** - **--BAIRRO--**, na cidade de **--CIDADE--**, Estado de **--UF--**, 
                        CEP **--CEP--**, inscrita no C.N.P.J. nº **--CNPJ--**, neste ato representada na forma de seus atos constitutivos por 
                        <b>**--REPRESENTANTE_LEGAL--**</b>, **--REPRESENTANTE_LEGAL/CARGO--**, C.P.F. nº **--REPRESENTANTE_LEGAL/CPF--** , e-mail: **--REPRESENTANTE_LEGAL/EMAIL--**, 
                        telefone: **--REPRESENTANTE_LEGAL/TELEFONE--** **--REPRESENTANTE_2--** doravante denominada simplesmente <b>“CLIENTE”</b>.
                    </p>                        
                    <br>
                        <ul>CONTATO RESPONSÁVEL: **--CONTATO_RESPONSAVEL--** - e-mail: **--CONTATO_RESPONSAVEL/EMAIL--** - telefone: **--CONTATO_RESPONSAVEL/TELEFONE--** </ul>                                                       
                        <ul>FINANCEIRO: **--CONTATO_FINANCEIRO--** - e-mail: **--CONTATO_FINANCEIRO/EMAIL--** - telefone: **--CONTATO_FINANCEIRO/TELEFONE--** </ul>
                        **--CONTATO_FINANCEIRO_2--**
                    <br>
                </td>
            </tr>    
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>                       
                    <b><small>TESTEMUNHAS:</small></b>                      
                    <p>
                        <br>
                        Nome: **--TESTEMUNHA_CMSW--** da C&M C.P.F. nº **--TESTEMUNHA_CMSW/CPF--** e-mail: **--TESTEMUNHA_CMSW/EMAIL--** 
                        <br>
                        Nome: **--TESTEMUNHA--** C.P.F. nº **--TESTEMUNHA_CPF--** e-mail: **--TESTEMUNHA_EMAIL--** 
                    </p>
                </td>
            </tr>        
        </tbody>
    </table>  
   
";

$texto[2] =
"   
    <p><b>CLÁUSULA PRIMEIRA: DO OBJETO</b></p>
    <p>
        <b>1.1.</b> Constitui objeto do presente Contrato a prestação de serviços de Colocation, que consiste no fornecimento de infra-estrutura no DATA CENTER da <b>C&M SOFTWARE</b> para hospedagem 
        e operação de equipamentos de propriedade do <b>CLIENTE</b>, conforme Anexo.
    </p>
    <p>
        <b>1.1.1.</b> As Áreas de Colocation contam com dispositivos adequados, tais como, mas não se limitando a, ambiente climatizado, alta disponibilidade de alimentação de energia 
        elétrica, geradores e no-breaks garantem a total disponibilidade, exclusiva sala de utilização local com 4 estações, telefone e acesso a Internet. Nas Áreas de Colocation 
        somente poderão ser instalados Equipamentos previamente aprovados e inspecionados pela <b>C&M SOFTWARE</b>.
    </p>
    <p>
        <b>1.2.</b> O <b>CLIENTE</b> tem ciência que a área reservada para cada Anexo são as dimensões de um RACK de 40U, sendo que a totalidade dos equipamentos a serem instalados não 
        poderão ultrapassar tais dimensões.
    </p>
    <p>
        <b>1.2.1.</b> O espaço físico para cada servidor dentro de 01 RACK Fechado (40U) tem as seguintes dimensões: altura: 1.95m, largura: 0.60m, profundidade: 0,87m.
    </p>
    <p>
        <b>1.2.2.</b> Caso as dimensões ultrapassarem tais dimensões, outro anexo de SERVIÇO deverá ser assinado, com custo idêntico ao anterior.
    </p>
    <p>
        <b>1.3.</b> O serviço ora contratado será prestado pela <b>C&M SOFTWARE</b> vinte e quatro (24) horas por dia, sete (7) dias da semana. Isto não impede que o serviço seja interrompido ou 
        suspenso, conforme definições dos anexos ou por motivo de força maior, caso fortuito ou a manutenção preventiva ou corretiva.  
    </p>
    <p>
        <b>1.4.</b> Com exceção da Rede do Sistema Financeiro Nacional, os serviços ora contratados não preveem nenhum fornecimento de acesso remoto, ou link para este propósito, e 
        todos devem ser contratados pelo <b>CLIENTE</b>.
    </p>   
    <p>
        <b>1.5.</b> Com relação à conectividade interna e interconexão, todos os links de comunicação necessários serão contratados pelo <b>CLIENTE</b>, ficando a <b>C&M SOFTWARE</b> responsável pela 
        cross-conexão (cabeamento) entre o Network Room (chegada da rede de dados) e o ECS (localização dos equipamentos). As necessidades de cross-conexão devem ser especificadas 
        pelo <b>CLIENTE</b>. Uma vez definidas as necessidades de cross-conexão, fica o <b>CLIENTE</b> sujeito a faturamento adicional relativo a novas alterações de cross-conexões, aqui conhecido 
        como (SETUP DO AMBIENTE).
    </p>
    <p>
        <b>1.6.</b> O <b>CLIENTE</b> poderá solicitar a inclusão de novos serviços, sob consulta prévia à <b>C&M SOFTWARE</b> e a sua viabilidade técnica. Com a concretização, se firmarão aditivos contratuais 
        que correspondam às condições que se prestarão os novos SERVIÇOS. O término dos novos SERVIÇOS contará a partir da assinatura dos respectivos aditivos e da ATA DE ENTREGA e o 
        término do respectivo aditamento. Da mesma forma, se os novos SERVIÇOS oferecidos e pretendidos pelo <b>CLIENTE</b> tiverem cláusula de permanência mínima e prorrogação automática por 
        igual período, deverá concordar com tal condição. 
    </p>
    <p><b>CLÁUSULA SEGUNDA: OBRIGAÇÕES DO CLIENTE</b></p>
    <p>
        <b>2.1.</b> Efetuar o pagamento dos valores objetos do presente Contrato, até a data de vencimento, sob pena de pagamento de multa e outras medidas aplicáveis.
    </p>
    <p>
        <b>2.2.</b> Os Equipamentos que serão instalados no DATA CENTER são de propriedade do <b>CLIENTE</b>, que assume os riscos e condições de proprietário e exonera a <b>C&M SOFTWARE</b> por quaisquer 
        danos que sofram na utilização do serviço.
    </p>
    <p>
        <b>2.3.</b> Configurar, instalar, remover, desinstalar os Equipamentos de forma a operarem de forma segura e adequada, assumindo inteira responsabilidade pelo correto uso do 
        Serviço e em relação à configuração de seus Equipamentos, obedecendo aos padrões e características técnicas autorizadas pela <b>C&M SOFTWARE</b>, sob pena de suspensão do Serviço.
    </p>
    <p>
        <b>2.4.</b> Encaminhar o registro da pessoa que terá acesso ao DATA CENTER da <b>C&M SOFTWARE</b> e durante a permanência e circulação nas dependências da <b>C&M SOFTWARE</b>, o <b>CLIENTE</b> deve respeitar todos 
        os procedimentos internos de segurança e orientações da <b>C&M SOFTWARE</b> e somente ter á acesso às dependências da <b>C&M SOFTWARE</b> onde estão colocados os seus respectivos Equipamentos.
    </p>
    <p>
        <b>2.5.</b> O <b>CLIENTE</b> será responsável pela arquitetura de seu ambiente, incluindo as suas manutenções, bem como para a conversão de equipamentos para o padrão rack, quando 
        isto se fizer necessário, bem como o fornecimento de switch(es) para a conexão dos seus equipamentos.
    </p>
    <p>
        <b>2.6.</b> O <b>CLIENTE</b> será responsável pela aquisição, configuração e gerência dos Equipamentos e dos licenciamentos de softwares a serem instalados equipamentos de 
        Informática, bem como as bases de dados, suas aplicações, suporte e administração relacionadas no presente contrato. No entanto, a <b>C&M SOFTWARE</b> poderá ser autorizada a realizar as 
        configurações dos Equipamentos. O <b>CLIENTE</b> deverá autorizar EXPRESSAMENTE essa atividade, quando então a <b>C&M SOFTWARE</b> poderá proceder às alterações da configuração.
    </p>
    <p>
        <b>2.7.</b> O <b>CLIENTE</b> deverá manter os espaços físicos e bens disponibilizados pela <b>C&M SOFTWARE</b> nas mesmas condições em que os mesmos foram entregues, devendo preservá-los e arcar 
        com todos os custos de reparo, reposição, manutenção de rotina e de emergência dos espaços e bens avariados ou danificados. Na hipótese da <b>C&M SOFTWARE</b> emprestar qualquer bem ao 
        <b>CLIENTE</b>, incluindo, mas não se limitando a, mouse, teclado, monitor ou afins, os mesmos deverão ser devolvidos quando solicitados pela <b>C&M SOFTWARE</b> e nas mesmas condições em que foram 
        entregues, assumindo o <b>CLIENTE</b>, portanto, as responsabilidades atinentes à condição de fiel depositário dos bens entregues ao <b>CLIENTE</b>.
    </p>   
    

";

$texto[3] =
"   
    <p>
        <b>2.8.</b> Manter backup de todos os dados armazenados em seus Equipamentos ou relativos à execução dos Serviços, sem exceção, responsabilizando-se e prezando pela segurança 
        e confiabilidade dos dados.
    </p>
    <p>
        <b>2.9.</b> Atender às instruções da <b>C&M SOFTWARE</b> para o uso do serviço contratado e informar qualquer irregularidade que se apresente.
    </p>
    <p>
        <b>2.10.</b> Observar as condições do presente Contrato e as recomendações da <b>C&M SOFTWARE</b>, comprometendo-se a não praticar por si ou por terceiros, atos que violem a lei, a moral e os 
        bons costumes, ou que sejam lesivos, afetem ou prejudiquem direitos de terceiros, inclusive usuários da internet, incluindo, mas não se limitando a, leis de patente, direitos 
        autorais e/ou propriedade intelectual. No mesmo sentido, não utilizar os Serviços contratados para colocar, transmitir ou retransmitir material ilegal, ameaçador ou abusivo, 
        bem como qualquer tipo de material a entidades que não os solicitem expressamente.
    </p>
    <p>
        <b>2.11.</b> Não comercializar, ceder, locar, sublocar, compartilhar, disponibilizar ou transferir o Serviço a terceiros, sob pena de rescisão contratual.
    </p>
    <p>
        <b>2.12.</b> Manter sigilo absoluto sobre qualquer identificação ou código de acesso seguro que seja fornecido pela <b>C&M SOFTWARE</b>. 
    </p>
    <p>
        <b>2.13.</b> Informar à <b>C&M SOFTWARE</b>, para sua aprovação, as modificações nos equipamentos de informática e demais especificações técnicas, que de alguma forma possam afetar o serviço.
    </p>
    <p>
        <b>2.14.</b> Retirar os equipamentos de informática, dentro de 15 (quinze) dias consecutivos, seguintes ao encerramento do presente contrato com a <b>C&M SOFTWARE</b>, que não se 
        responsabilizará pelos danos, furto ou roubo dos equipamentos.
    </p>
    <p>
        <b>2.15.</b> Responsabilizar-se pelo transporte ou traslado dos equipamentos nas instalações do DATA CENTER, conforme o tempo especificado. 
    </p>
    <p>
        <b>2.16.</b> A suas expensas e vontade, responsabilizar-se por seguros adicionais que desejar aos equipamentos instalados no DATA CENTER.
    </p>

    <p>
        <b>2.17.</b> Permitir a vistoria técnica da <b>C&M SOFTWARE</b> nos Equipamentos quando da instalação, ativação ou manutenção dos Serviços.
    </p>
    <p>
        <b>2.18.</b> O <b>CLIENTE</b> deverá fornecer à <b>C&M SOFTWARE</b> informações precisas e completas a fim de manter atualizados seus dados. Deverá comunicá-los, por escrito, em até 30 (trinta) 
        dias da ocorrência das mudanças.
    </p>
    <p>
        <b>2.19.</b> No momento que a <b>C&M SOFTWARE</b> detectar que alguma dessas obrigações não está sendo cumprida, notificará o <b>CLIENTE</b> para que dentro do prazo determinado tome as ações 
        corretivas suficientes e necessárias. A <b>C&M SOFTWARE</b> dará por encerrado o presente contrato sem necessidade de interpelação ou notificação judicial ou extrajudicial e sem qualquer 
        pagamento de qualquer prejuízo ou indenização para o <b>CLIENTE</b>. A <b>C&M SOFTWARE</b> se reserva ao direito de propor as ações legais e/ou jurídicas pelo inadimplemento por parte do <b>CLIENTE</b>.
    </p>
    <p><b>CLÁUSULA TERCEIRA: OBRIGAÇÕES DA C&M SOFTWARE</b></p>
    <p>
        <b>3.1.</b> Habilitar o serviço no seu DATA CENTER, estabelecendo todos os espaços e necessidades elétricas e conectividade de rede, assim como todos os demais deste contrato.
    </p>
    <p>
        <b>3.2.</b> Manter o nível de disponibilidade de cada serviço e, caso contrário, aplicar as compensações necessárias, conforme os parâmetros estabelecidos no anexo.
    </p>
    <p>
        <b>3.3.</b> A <b>C&M SOFTWARE</b> garantirá pelo período de vigência do presente contrato, o perfeito funcionamento dos seus subsistemas para a prestação dos serviços contratados, sempre que 
        qualquer problema diagnosticado ocorra por falhas ou defeitos ocasionados nestes. Neste caso, a <b>C&M SOFTWARE</b> procederá à regularização sem qualquer custo para o <b>CLIENTE</b>.
    </p>
    <p>
        <b>3.4.</b> Responder no DATA CENTER pelas condições ambientais e de energia elétrica, além da conectividade. 
    </p>
    <p>
        <b>3.5.</b> Prestar os Serviços conforme contratado, devendo observar os níveis de serviço acordados, sob pena de conceder os descontos ou os ressarcimentos estabelecidos.
    </p>
    <p>
        <b>3.6.</b> Prestar esclarecimentos ao <b>CLIENTE</b>, livre de ônus, considerando eventuais reclamações e dúvidas relativas à fruição dos Serviços.
    </p>
    <p>
        <b>3.7.</b> A <b>C&M SOFTWARE</b> se obriga a prestar ao <b>CLIENTE</b> o serviço de Suporte por telefone por 24 (vinte e quatro) horas por dia nos 7 (sete) dias da semana. 
    </p>
    <p>
        <b>3.8.</b> Efetuar a manutenção preventivas dos SUBSISTEMAS do DATA CENTER e da REDE. 
    </p>
    <p>
        <b>3.9.</b> Levar a cabo a necessária manutenção corretiva dos SUBSISTEMAS e elementos da REDE, ou quando for detectado um erro por parte da <b>C&M SOFTWARE</b>, emitir um relatório 
        informativo ao <b>CLIENTE</b>.
    </p>
    <p>
        <b>3.10.</b> Em se tratando de falhas no serviço que não são de responsabilidade do <b>CLIENTE</b>, a <b>C&M SOFTWARE</b> se encarregará por conduzir atividades de reparação. Quando ocorrerem 
        falhas no serviço por causas de responsabilidade do <b>CLIENTE</b>, a <b>C&M SOFTWARE</b> fornecerá suporte telefônico e, se necessário, realizará todas as verificações necessárias. Se a conclusão 
        for que o defeito é de responsabilidade do <b>CLIENTE</b> ou de terceiros por este contratado, quer por mau uso da configuração dos equipamentos ou qualquer outra de sua 
        responsabilidade, o <b>CLIENTE</b> autoriza expressamente por meio deste instrumento, a <b>C&M SOFTWARE</b> a cobrar pelos serviços necessários ao restabelecimento do serviço na próxima fatura.
    </p> 
    

";


$texto[4] =
"      
    <p>
        <b>CLÁUSULA QUARTA: DOS PREÇOS, CONDIÇÕES DE PAGAMENTO, REAJUSTE E INADIMPLEMENTO</b>
    </p>
    <p>
        <b>4.1.</b> Os preços dos serviços oferecidos e suas adaptações são descritos nos anexos, que serão faturados em moeda corrente nacional - REAL. Os valores não contemplam tributos e 
        serão acrescidos quando da emissão da Nota Fiscal/Fatura.
    </p>
    <p>
        <b>4.2.</b> A <b>C&M SOFTWARE</b> fará as cobranças referentes à prestação dos serviços e demais valores estabelecidos no presente contrato, mensalmente, através da emissão de Nota Fiscal.
    </p>
    <p>
        <b>4.3.</b> O inadimplemento de toda e qualquer importância cobrada com base no presente Contrato, na data de seu vencimento, implicará na incidência automática de multa 
        moratória no percentual de **--PERCENTUAL_MULTA--** **--PERCENTUAL_MULTA/EXTENSO--** e juros de mora de **--PERCENTUAL_JUROS--** **--PERCENTUAL_JUROS/EXTENSO--** ao mês, 
        encargos esses incidentes sobre o valor do débito atualizado de acordo com o **--INDICE_REAJUSTE--**, divulgado pela Fundação Getulio Vargas, calculado “pro rata die” a partir da data de 
        vencimento do respectivo documento de cobrança até a data do efetivo pagamento.
    </p>
    <p>
        <b>4.3.1.</b> Além dos encargos previstos em caso de inadimplemento, o não pagamento do débito facultará à <b>C&M SOFTWARE</b>:
        <br>
        a) Suspender a prestação dos Serviços, transcorridos 10 (dez) dias de atraso no pagamento, até a data de quitação integral da dívida; e,
        <br>
        b) Cancelar a prestação dos Serviços e rescindir o presente Contrato, transcorrido período de 60 (sessenta) dias de atraso no pagamento.
    </p>
    <p>
        <b>4.4.</b> O não recebimento do documento de cobrança não isenta o <b>CLIENTE</b> de realizar o pagamento dos valores por ele devidos, até a data de seu vencimento. Neste caso, o 
        <b>CLIENTE</b> deverá entrar em contato com a <b>C&M SOFTWARE</b>, que informará o procedimento a ser adotado para efetivação do pagamento devido.
    </p>
    <p>
        <b>4.5.</b> O <b>CLIENTE</b> concorda que, em caso de atraso nos pagamentos, não poderá exigir descontos pela indisponibilidade do serviço. 
    </p>  

    <p>
        <b>4.6.</b> Os valores para os serviços ora contratados poderão ser reajustados após decorridos 12 (doze) meses de vigência deste Contrato, pelo **--INDICE_REAJUSTE--**, divulgado pela Fundação 
        Getulio Vargas, ou outro índice similar aplicável. Caso a legislação permita reajuste em prazo inferior a 12 (doze) meses, o reajuste poderá ser aplicado imediatamente.
    </p>
    <p>
        <b>4.7.</b> Os tributos referentes à assinatura e execução do presente contrato estarão sob responsabilidade da parte em que a lei estabelecer, definido como contribuinte, 
        responsável legal ou responsável pela retenção na fonte.
    </p>
    <p><b>CLÁUSULA QUINTA: DA VIGÊNCIA E EXTINÇÃO DO CONTRATO</b></p>
    <p>
        <b>5.1.</b> O presente Contrato entra em vigor na data de sua assinatura e permanecerá vigente pelo prazo estabelecido no Anexo.
    </p>
    <p>
        <b>5.2.</b> Sem prejuízo das condições previstas na prestação deste serviço, a <b>C&M SOFTWARE</b> poderá suspender ou dar por encerrada as presentes condições, sem necessidade de 
        interpelação ou notificação extrajudicial, entre outras, por qualquer das seguintes causas:
        <ul>
            Pelo descumprimento total ou parcial de qualquer das obrigações assumidas pelo <b>CLIENTE</b> em relação ao serviço; 
        </ul>
        <ul>
            Pelo fornecimento de informações falsas ou adulteradas;
        </ul>
        <ul>
            Por razões de força maior, caso fortuito ou atos de terceiros, alheios à <b>C&M SOFTWARE</b>, ordem de autoridades competentes ou causas estabelecidas na lei ou regulamentos; 
        </ul>
        <ul>
            Por dar ao serviço uma função diferente daquela contratada; 
        </ul>
        <ul>
            Por interferir ou prejudicar a operação e manutenção das redes e demais equipamentos necessários para fornecer os serviços que são propriedade da <b>C&M SOFTWARE</b> ou de terceiros; e,
        </ul>
        <ul>
            Por impedir ou prejudicar os trabalhos de inspeção e/ou manutenção realizados pelos funcionários autorizados pela <b>C&M SOFTWARE</b>.
        </ul>
    </p>
    <p>
        <b>5.3.</b> O <b>CLIENTE</b> poderá encerrar o Contrato nos casos de graves e reiterados inadimplementos pela <b>C&M SOFTWARE</b> nas suas obrigações contratuais, desde que devidamente comprovadas 
        em cada caso, neste caso não se observará a clausula do anexo sobre permanência mínima.
    </p>
    <p>
        <b>5.4.</b> O presente Contrato poderá ser rescindido a qualquer tempo com base nos itens abaixo indicados, mediante notificação por escrito, com até 30 (trinta) dias de 
        antecedência, exclusivamente nos casos em que a parte faltosa notificada não sanar o descumprimento ou não providenciar alternativas de continuidade da prestação, no prazo 
        acima indicado:
        <ul> 
            descumprimento ou cumprimento irregular das cláusulas e condições deste Contrato;
        </ul>
        <ul>        
            determinação judicial, legal ou regulamentar que impeça a prestação do Serviço;
        </ul>
        <ul>
            se qualquer Parte ajuizar pedido de recuperação judicial ou ter homologado plano de recuperação extrajudicial, ou lhe for requerida ou decretada falência ou, ainda, 
            quando sua insolvência se manifestar por meio de protestos de títulos de qualquer espécie ou execuções.
        </ul>
    </p>
    
";

$texto[5] = 
"   
    <p>
        <b>5.5.</b> A partir da extinção deste Contrato, o <b>CLIENTE</b> está ciente que deverá devolver eventuais bens de propriedade da <b>C&M SOFTWARE</b>, quando aplicável, bem como efetuar o pagamento 
        de todos os valores referentes aos serviços prestados, até o seu efetivo cancelamento.
    </p>
    <p>
        <b>CLÁUSULA SEXTA: CONFIDENCIALIDADE</b>
    </p> 
    <p>
        <b>6.1.</b> As partes se obrigam a guardar absoluto sigilo sobre toda e qualquer informação que lhe seja dada a conhecer por ocasião do desenvolvimento do presente contrato, 
        tratado como “INFORMAÇÕES CONFIDENCIAIS”. A confidencialidade se estende a qualquer informação que as partes recebam, direta ou indiretamente, em função do presente 
        instrumento. Essas obrigações não se estendem nos casos de:     
        <ul>
        	As informações que eram de domínio público antes da data em que foram entregues ao respectivo correspondente
        </ul>
        <ul>
        	Informações que se tornaram públicas, de forma lícita, durante a vigência do presente contrato
        </ul>
        <ul>
        	Informações que devam ser entregues por determinação legal, para tender ordem judicial. Por conseqüência, as partes assumem o compromisso de tomar todos os cuidados 
            necessários para garantir a confidencialidade do material e informações a que tenham acesso ou que recebam por ocasião da celebração da presente avença e execução, sobre 
            as quais, em nenhum caso, serão inferiores àquelas a que se referem seus assuntos internos importantes, quando a natureza assim o requer se abstiver de fazer para si, ou 
            para terceiros, modalidades, reproduções, adaptações ou qualquer outra classe de alteração, deformação ou modificação do sistema ou dados que cheguem a seu conhecimento 
            por ocasião da negociação e execução do presente contrato. Na ocorrência, por erro de qualquer das partes, receba ou tenha acesso a Informação Confidencial de qualquer 
            outra parte ou de <b>CLIENTES</b> das partes, aquele que a recebeu se obriga a devolver de imediato ao seu superior imediato e a guardar absoluto sigilo sobre a mesma.
        </ul>
    </p>
    <p><b>CLÁUSULA NONA: DAS DISPOSIÇÕES GERAIS</b></p>
    <p>
        <b>9.1.</b> Fazem parte deste contrato os anexos de serviços que estabelecem as condições mínimas da cláusula de prorrogação automática e valores a pagar no caso da rescisão 
        antecipada do contrato. Depois de expressamente aceitos pelo <b>CLIENTE</b>, de acordo com as condições estabelecidas.
    </p>
    <p>
        <b>9.2.</b> Nenhuma disposição deste contrato poderá ser interpretada como tendo as Partes estabelecido qualquer forma de sociedade ou associação, de fato ou de direito, 
        remanescendo cada uma das partes com suas obrigações civis, comerciais, trabalhistas e tributárias, de forma autônoma.
    </p>
    <p>
        <b>9.3.</b> Nenhuma das Partes poderá ceder ou transferir, no todo ou em parte, os direitos e obrigações decorrentes deste Contrato, sem a anuência prévia e expressa da outra 
        Parte.
    </p>
    <p>
        <b>9.4.</b> Qualquer aditamento ou alteração a este Contrato somente será válida se feito por meio de aditivo contratual, escrito e assinado pelas Partes.
    </p>
    <p>
        <b>9.5.</b> Todas as obrigações e condições aqui estipuladas obrigam as Partes e seus sucessores a qualquer título.
    </p>
    <p>
        <b>9.6.</b> Todas as notificações ou comunicações dadas segundo o presente Contrato, de uma Parte à outra, deverão ser endereçadas por via postal através de carta registrada, 
        por telegrama ou por correio eletrônico, todos com aviso de recebimento, para os representantes legais nos endereços constantes na qualificação das Partes. 
    </p>
    <p>
        <b>9.7.</b> A tolerância de uma Parte com a outra, relativamente a qualquer violação ou descumprimento de quaisquer obrigações ora assumidas, não será considerada moratória, 
        novação ou renúncia a qualquer direito, constituindo mera liberalidade, que não impedirá a Parte tolerante de exigir da outra o fiel cumprimento deste Contrato, a qualquer 
        tempo.
    </p>
    <p>
        <b>9.8.</b> Se qualquer cláusula ou condição deste Contrato vier a ser considerada ilegal, inválida ou inexequível nos termos da legislação brasileira, as demais cláusulas e 
        condições continuarão em pleno vigor e efeito.
    </p>
    <p>
        <b>9.9.</b> O presente Contrato constitui o acordo final entre as Partes com relação às matérias aqui expressamente tratadas, superando e substituindo todas as propostas, 
        acordos, entendimentos e declarações anteriores, orais ou escritos.
    </p>
    <p>
        <b>9.10.</b> Cada uma das Partes declara, garante e concorda, reciprocamente, que a celebração, outorga e execução deste Contrato foi devidamente autorizada pelos seus legítimos 
        representantes legais, na forma dos seus respectivos documentos societários, sendo que o fornecimento de eventual informação inverídica, incompleta ou inidônea será considerado 
        infração aos princípios da informação e boa-fé contratual, respondendo a parte que assim as prestou civil e criminalmente, restando claro que este contrato constitui obrigação 
        legal, válida e vinculante entre as Partes.
    </p>   
    <p><b>CLÁUSULA DÉCIMA: DO FORO</b></p>
    <p>
        <b>10.1.</b> Fica eleito o foro da comarca de Barueri do Estado de São Paulo para dirimir quaisquer questões advindas deste Instrumento, renunciando as partes a qualquer outro, 
        por mais privilegiado que seja.
    </p>

";

$texto[6] =
"
    <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>                
                <td class='td_cabecalho' style='text-align:center;border-top:2px solid;border-bottom:2px solid;'>
                    <h3>ACORDOS DE NÍVEIS DE SERVIÇO</h3>                        
                </td>
            </tr>
        </tbody>
    </table>    
    <p>
        Os acordos de Níveis de Serviço – ANS – representam os níveis de serviço que a C&M garantirá ao <b>CLIENTE</b> pelo SERVIÇO que é prestado. Os parâmetros estabelecidos, são medidos 
        dentro do DATA CENTER e não requerem nenhum equipamento especializado por parte do <b>CLIENTE</b>. O SERVIÇO inclui os seguintes acordos: 
    </p>
    <p>
        <b>1. Tempo Estimado</b> 
        <br>
        É o tempo que a C&M levará para preparar e instalar um SERVIÇO completamente e entregar em funcionamento ao <b>CLIENTE</b>. 
        <br></br>
        Compreende as etapas de: 
        <br>
        <b>a)</b>	Viabilidade 
        <br>
        <b>b)</b>	Instalação e Colocação em Funcionamento
    </p>
    <p>
        <b>1.1.</b> Viabilidade 
        <br>
        É o tempo que leva a C&M para determinar a viabilidade técnica da solução a contratar, incluindo não só a disponibilização de recursos técnicos (disponibilidade de espaço, a 
        capacidade dos subsistemas, etc), mas também os custos para a execução do SERVIÇO. Durante este tempo pode-se fazer uma ou mais reuniões com o cliente para ajustar requisitos. 
        Como resultado deste estudo, a C&M entrega um relatório que concentra todos os requisitos e os custos associados à sua execução ou adoção.   
        <ul>
            Viabilidade: 8 dias úteis 
        </ul>
    </p>
    <p>
        <b>1.2.</b> Instalação e Colocação em Funcionamento 
        <br>
        Depois do estudo de viabilidade e seu respectivo desenho, a etapa de instalação e colocação em funcionamento é o tempo que a C&M pode levar para fornecer os equipamentos e 
        instalação dos mesmos, com suas respectivas aplicações e/ou SERVIÇOS requeridos pelo <b>CLIENTE</b>.   
        <ul>
            Instalação e Colocação em Funcionamento do Serviço Colocation: é o estabelecido na proposta comercial e Contados a partir da assinatura do respectivo contrato. 
        </ul>
    </p>
    <p>
        <b>2. Disponibilidade do SERVIÇO.</b>
        <br>
        A C&M garantirá a disponibilidade do SERVIÇO mensal e a compensação em caso dos níveis especificados seja inferiores, de acordo com as avaliações mensais.
    </p>
    <p>
        A disponibilidade corresponde à porcentagem do total do período de tempo no qual o SERVIÇO está disponível.
    </p>
    <p>
        A indisponibilidade do serviço de tempo começa a correr a partir do momento que existe uma falha no DATA CENTER da C&M e/ou o <b>CLIENTE</b> apresenta problemas para abrir um chamado 
        através do Suporte da C&M e será atribuído um número de rastreamento.
    </p>
    <p>
        Exclui-se dos motivos de indisponibilidade, as falhas produzidas na instalação interna do <b>CLIENTE</b>, equipamentos e/ou componentes fornecidos pela C&M com culpa imputável ao 
        <b>CLIENTE</b>. Não são considerados para o cálculo do indicador como os casos de caso fortuito ou de força maior, alteração da ordem pública ou interrupções programadas no SERVIÇO.
    </p>   
    <p>        
        A disponibilidade do SERVIÇO se calcula pela seguinte fórmula: 
        <br></br>
        <b> DE = [((N*24)-Y) / (N*24)] * 100 </b>
        <br>
        <b>DE:</b> Disponibilidade do SERVIÇO 
        <br>
        <b>N:</b> Número de Dias do mês específico
        <br>
        <b>Y:</b> Número de horas registradas mediante a realização da chamada ao Suporte da C&M SOFTWARE durante as quais o SERVIÇO se encontrava indisponível. S
    </p>
    <p>
        Para os SERVIÇOS do DATA CENTER, a disponibilidade do SERVIÇO é definida como a disponibilidade dos SISTEMAS OPERACIONAIS (se aplicável), o hardware e infra-estrutura geral.
    </p>
    <p>
        Disponibilidade de SERVIÇO 
    </p>
    <p>
        A disponibilidade mensal de SERVIÇO no DATA CENTER da C&M SOFTWARE é: 99.7%
    </p>
    <p>
        <b>3. Políticas de Apoio.</b>
        <br>
        A C&M SOFTWARE fará o serviço de inserção das mídias para restauração e a realização de backups, sendo que os comandos para realização do backup ou restauro do mesmo serão de inteira 
        responsabilidade do <b>CLIENTE</b>.
    </p>
    <p>        
        Não será contado como indisponibilidade o tempo utilizado para a execução do backup.
    </p>
    <p>    
        Indica a melhor Política de Continuidade de Negócios a guarda destas mídias em ambiente externo ao DATA CENTER. 
    </p>
   
";


$texto[7] =
"   
    <p>
        <b>4. Compensações pela indisponibilidade.</b>
        <br>
        Quando alguma razão não se cumpre a disponibilidade oferecida a C&M SOFTWARE compensa o <b>CLIENTE</b> com uma percentagem fixa mensal da taxa de serviço. O resultado da taxa de disponibilidade 
        é usado para definir o fator da compensação. O Service Level Agreement (SLA), não será compensado nos seguintes casos: 
        <ul>
            Manutenção Programada: motivo pela qual se apresentarão interrupções programadas pela C&M SOFTWARE para manutenção preventiva ou corretiva dos SERVIÇOS determinados no acordo. 
            Manutenção programada se define como aquela manutenção realizada no DATA CENTER, onde para o SERVIÇO o <b>CLIENTE</b> é localizado e para onde o <b>CLIENTE</b> será notificado por fax, 
            e-mail, telefone, com 24 horas de antecedência para sua realização. A manutenção ocorrerá entre a meia noite e seis da manhã, no horário acordado com o <b>CLIENTE</b> e C&M SOFTWARE.
        </ul>
        <ul>
            Indisponibilidade da Rede: por indisponibilidade da Rede, devido a manutenções programadas, as falhas dos circuitos de infra-estrutura ou aplicações do <b>CLIENTE</b>, a 
            incompatibilidade de aplicações com os hardware e softwares oferecidos pela C&M SOFTWARE, a atos ou omissões do <b>CLIENTE</b> ou qualquer usuário por ele autorizado.
        </ul>
        <ul>
            Nos eventos de exceção contemplados pelos Regulamentos Oficiais. 
        </ul>
    </p>
    <p>
        <b>4.1.</b> Processo de Compensação do Serviço
    </p>
    <p>
        Se o <b>CLIENTE</b> notifica a C&M SOFTWARE sobre a indisponibilidade do SERVIÇO e a C&M SOFTWARE determina que tal indisponibilidade do SERVIÇO é creditada a uma falha interna, se fará uma compensação. 
        A duração da indisponibilidade do SERVIÇO será contada sobre o total de indisponibilidade em um período mensal e se aplicará segundo as normas vigentes no momento da falha. 
        Os registros da C&M SOFTWARE serão a base para todos os cálculos de indisponibilidade e compensação. A compensação se aplicará à medição mensal do SERVIÇO contratado. 
    </p>
    <p>
        Uma vez que a C&M SOFTWARE defina que haverá a compensação, o valor da mesma será aplicado, no mais tardar, nos dois faturamentos seguintes.
    </p>
    <p>
        Para os serviços de DATA CENTER, as compensações por indisponibilidade de SERVIÇO serão aplicadas de acordo com a seguinte tabela:   
        <ul>
            De: 97.0% Até:95.0% de disponibilidade mensal desconto de 5 % na fatura dos SERVIÇOS.
        </ul>
        <ul>
            De: 95.0% Até:90.0% de disponibilidade mensal desconto de 10 % na fatura dos SERVIÇOS.
        </ul>
        <ul>
            Maior que 90.0% de disponibilidade mensal desconto de 100% na fatura dos SERVIÇOS.
        </ul>
    </p>
    <p>
        <b>5. Diagnóstico e Atenção às Falhas.</b>
        <br>    
        Como parte dos serviços, a <b>C&M SOFTWARE</b> oferece um Suporte Técnico que opera 24 horas por dia nos 365 dias do ano.
    </p>
    <p>
        No encerramento das negociações, o Gerente Comercial da <b>C&M SOFTWARE</b> fornecerá ao <b>CLIENTE</b> o número telefônico de contato para Suporte 7x24. 
    </p>
    <p>
        Procedimento de Atenção.
        <br>
        a)	Em caso de necessidade de suporte técnico, o <b>CLIENTE</b> deverá se comunicar com o número telefônico do Suporte Técnico da <b>C&M SOFTWARE</b> e deve informar o seguinte:
        <ul>
            (1)	Hora da ocorrência 
        </ul>
        <ul>
            (2)	Descrição da ocorrência.
        </ul>
        <ul>
            (3)	Mensagem de Erro (se aplicável) 
        </ul>   
        <br>
        b)	Posteriormente lhe será atribuído um número de registro de atenção que poderá ser utilizado pelo <b>CLIENTE</b> para acompanhar a ordem de SERVIÇO.
        <br>    
        c)	O tempo de atenção e o processo de analise dos incidentes se basearão na categoria do mesmo, que se estabelece pelo acordo ao impacto gerado no sistema e estes estão descritos 
        em nosso site (www.cmsoftware.com.br).
    </p>

";

$texto[8] =
"
    <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>
                <td class='td_cabecalho' style='text-align:center;border-top:2px solid;border-bottom:2px solid;'>
                    <h3>ANEXO COLOCATION ECS 40U</h3>                        
                </td>
            </tr>
        </tbody>
    </table>
    <table cellpadding='1' cellspacing='4' style='width:100%'> 
        <tbody>
            <tr>
                <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'>
                    Data de Início da Contratação
                </td>
                <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'>
                    A partir da data de assinatura do presente contrato.
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'>
                    Valor Implantação
                </td>
                <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'>
                    **--IMPLANTACAO--** **--IMPLANTACAO/EXTENSO--** **--TEXTO_IMPLANTACAO--**.
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'>
                    Valor Mensal R$ 
                </td>
                <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'>
                    O valor mensal por servidor instalado na estrutura da C&M Software será de **--PACOTE_ECS--** **--PACOTE_ECS/EXTENSO--**.
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'>
                    Servidores
                </td>
                <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'>
                    Os servidores deverão ser fornecidos pelo CLIENTE.
                </td>
            </tr>  
            <tr>
                <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'>
                    Faturamento
                </td>
                <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'>
                    Salvo o valor da implantação que segue sistemática própria, todos os faturamentos terão datas de cortes para aferição todo o dia **--CORTE_FATURAMENTO--** **--CORTE_FATURAMENTO/EXTENSO--** 
                    de cada mês, com prazo de pagamento de **--PRAZO_PAGAMENTO--** **--PRAZO_PAGAMENTO/EXTENSO--** dias contados da apresentação da nota fiscal/fatura, ocorrendo o primeiro 
                    faturamento **--PRIMEIRO_FATURAMENTO--** após a data da assinatura do presente Contrato, independentemente da conclusão da implantação e do uso.
                </td>
            </tr>     
            <tr>
                <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'>
                    Vigência Contrato
                </td>
                <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'>
                    **--VIGENCIA_CONTRATO--** **--VIGENCIA_CONTRATO/EXTENSO--**
                </td>
            </tr>     
        </tbody>
    </table>  
    <p>
        <b>O SERVIÇO É COMPOSTO POR:</b>
        <ul>
            Espaço Físico de 01 RACK Fechado (40U)
        </ul>
        <ul>
            Operação 7 x 24 x 365, com larga experiência no Mercado Financeiro e suas demandas.
        </ul>
        <ul>
            Alta Disponibilidade de Alimentação de Energia Elétrica
        </ul>
        <ul>
            Geradores e No-Breaks garantem a total disponibilidade.
        </ul>
        <ul>
            Climatização Controlada e Precisa.
        </ul>
        <ul>
            Rack Exclusivo.
        </ul>
        <ul>
            Exclusiva Sala de Utilização Local com 4 estações, telefone e acesso a Internet.
        </ul>
        <ul>
            O presente anexo possui um prazo de permanência mínimo a fim de garantir os investimentos realizados, o nível de serviço contratado e exigido pelo CLIENTE e, por conseguinte 
            coibir a perda de receita, danos, prejuízos ou quaisquer outras indenizações e ressarcimentos.
        </ul>
        <ul>
            O cancelamento do presente ANEXO implica no pagamento de multa pelo CLIENTE, corresponde nte a 95% (dez por cento) do valor da mensalidade, descrito no presente anexo, multiplicado 
            pelo número de meses restantes para que se completassem o Período de Permanência Mínima.
        </ul>
    </p>
    <p>
        Os valores não contemplam tributos e serão acrescidos quando da emissão da Nota Fiscal/Fatura.
    </p>
";

?>