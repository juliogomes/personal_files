<?php
	echo 'Metodo não encontrado!!';


