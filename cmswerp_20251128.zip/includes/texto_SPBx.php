<?php
$texto[0] =
"
    À<br> 
    <b> **--CLIENTE--** </b> <br>
    **--ENDERECO--** - **--BAIRRO--** <br> 
    **--CEP--** - **--CIDADE--** - **--UF--** <br>  
    <br> 
    <b> A/C.: **--REPRESENTANTE_LEGAL--** </b> 
    <br></br>     

    <b>Assunto: Contrato de Licenciamento de Uso do Software Produtos de Liquidação BACEN (PL-BACEN).</b>
    <br></br> 
    Prezado Senhor,
    <br> 
    <p>
        Primeiramente manifestamos nossos sinceros agradecimentos pela contratação da nossa plataforma, e lhe damos as <b>Boas-Vindas</b> à família C&M Software.
    </p>
    <p>
        Encaminhamos em anexo o contrato de Licenciamento do Software que será assinado na <b>Plataforma de Assinaturas</b> da D4Sign (especializada em identificação digital), com plena 
        validade jurídica. As assinaturas das pessoas jurídicas da Contratante e Contratada serão realizadas sob a forma digital, com a utilização de Certificados Digitais e-CNPJ.
    </p>
    <p>
        As testemunhas assinarão eletronicamente (sem a necessidade de Certificado Digital), de acordo com as formas de comprovação de autoria e integridade de documentos realizadas 
        pela Plataforma de Assinaturas da <b>D4Sign</b>. O passo-a-passo para assinatura do presente instrumento será enviado por <b>e-mail</b>.
    </p>
    <p>
        Caso contrário, segue anexo o “Contrato de Licenciamento do Produto PL-BACEN”, é necessário que seja assinado em 02 (duas) vias e entregue no  endereço de nossa sede:
    </p>

    <p><b>**--CM_SOFTWARE--**</b></p>
    <br> A/C: Departamento Jurídico.
    <br> Alameda Rio Pardo, nº 27 - Alphaville Industrial.
    <br> 06455-005 – Barueri – SP. 

    <br> Os documentos que devem acompanhar o contrato são:

    <ul> Cópia simples do Contrato Social/Estatuto Social, bem como a última alteração/ata da assembleia; </ul>
    <ul> Cartão do CNPJ; </ul>
    <ul> Cópia simples do RG e CPF do signatário do Contrato; e, </ul>
    <ul> Se o signatário não constar do Contrato Social/Estatuto Social, solicitamos cópia da procuração que lhe outorgou poderes. </ul>

    <br>
    Quaisquer dúvidas podem ser encaminhadas para os e-mails contratos@cmsw.com e juridico@cmsw.com, ou pelo telefone (11) 3365-2666.
    <br></br><br></br><br></br><br>
    Atenciosamente,

    <br></br>
    <table>
        <thead>
            <th style='text-align:center; width:800px;' >               
                <small>
                    **--CM_SOFTWARE--**
                    <br>Departamento Jurídico 
                </small>                               
            </th>
        </thead>
    </table>
";

$texto[1] = 
"
    <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>
                <td style='text-align:center;border-bottom:2px solid;'>
                    <h3>Contrato de Licenciamento do Software - Produto de Liquidação</h3>                        
                </td>
            </tr>
        </tbody>
    </table>
    
    <table cellpadding='1' cellspacing='4' style='width:100%'> 
        <tbody>
            <tr>
                <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'><b><small>QUADRO RESUMO</small></b></td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>
                    <b><small>CONTRATADA</small></b>
                    <br></br>
                    <p>
                        <b> **--CM_SOFTWARE--** </b>, pessoa jurídica de direito privado com sede na Alameda Rio Pardo, nº 27, 
                        Bairro Alphaville Industrial, no município de Barueri, Estado de São Paulo, CEP 06455-005, inscrita no CNPJ/MF sob o 
                        nº <b> **--CM_SOFTWARE_CNPJ--** </b>, doravante denominada simplesmente “<b>C&M SOFTWARE</b>”;
                    </p>
                    <br>
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>
                    <b><small><b>CONTRATANTE</b></small></b>
                    <br></br>
                    <p>
                        <b> **--CLIENTE--** </b>, pessoa jurídica de direito privado com endereço **--ENDERECO--** - **--BAIRRO--**, na cidade de **--CIDADE--**, Estado de **--UF--**, 
                        CEP **--CEP--**, inscrita no C.N.P.J. nº **--CNPJ--**, neste ato representada na forma de seus atos constitutivos por 
                        <b>**--REPRESENTANTE_LEGAL--**</b>, **--REPRESENTANTE_LEGAL/CARGO--**, C.P.F. nº **--REPRESENTANTE_LEGAL/CPF--** , e-mail: **--REPRESENTANTE_LEGAL/EMAIL--**, 
                        telefone: **--REPRESENTANTE_LEGAL/TELEFONE--** **--REPRESENTANTE_2--**  doravante denominada simplesmente <b>“CLIENTE”</b>.
                    </p>                        
                    <br>
                        <ul>CONTATO RESPONSÁVEL: **--CONTATO_RESPONSAVEL--** - e-mail: **--CONTATO_RESPONSAVEL/EMAIL--** - telefone: **--CONTATO_RESPONSAVEL/TELEFONE--** </ul>                                                       
                        <ul>FINANCEIRO: **--CONTATO_FINANCEIRO--** - e-mail: **--CONTATO_FINANCEIRO/EMAIL--** - telefone: **--CONTATO_FINANCEIRO/TELEFONE--** </ul>
                        **--CONTATO_FINANCEIRO_2--**
                    <br>
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>
                    <b><small>OBJETO DO CONTRATO</small></b>
                    <p>
                        <br>
                        O objeto deste Contrato é o Licenciamento de uso do Software <b>PL-BACEN</b>, em caráter temporário e intransferível, nos termos e condições aqui avençadas, 
                        viabilizando ao <b>CLIENTE</b> a operação diretamente nos Sistemas de Liquidação do Banco Central do Brasil, conforme regulamentação em vigor.
                    </p>
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'> 
                    <b><small>PRAZO DE VIGÊNCIA</small></b>  
                    <p>
                        <br>
                        O presente Contrato vigorará pelo prazo determinado em seu <b>anexo próprio</b>, e assinado nos termos da <b>MEDIDA PROVISÓRIA No 2.200-2, DE 24 DE AGOSTO DE 2001 e 
                        LEI Nº 14.063, DE 23 DE SETEMBRO DE 2020</b>, (Assinatura Digital) ou da forma convencional de assinatura vigorará pelo prazo determinado de <b> **--VIGENCIA_CONTRATO--** **--VIGENCIA_CONTRATO/EXTENSO--** </b>.                      
                    </p>                                            
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                    <b><small>PREÇO</small></b>   
                    <p> 
                        <p>
                            <b>V.1)</b> O valor da Implantação, assessoria e as condições comerciais de uso estão descritos no anexo específico para o sistema contratado a ser 
                            integrado ao Banco Central do Brasil.
                        </p>
                        <p>
                            <b>V.2)</b> Pelo licenciamento de uso do software PL-BACEN serão cobrados os preços, por mensagem processada, conforme Tabela de Preços disposta no anexo 
                            específico do presente Contrato.
                        </p>
                        <p>    
                            <b>V.3)</b> Os valores não contemplam tributos e serão acrescidos quando da emissão da Nota Fiscal/Fatura.
                        </p>                        
                    </p>                        
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                    <b><small>RENOVAÇÃO DO CONTRATO</small></b>   
                    <p>    
                        <br>                 
                        Caso não haja manifestação por nenhuma das partes com antecedência mínima de <b>120 (cento e vinte) dias</b> do vencimento do Contrato, esse prorrogar-se-á 
                        automaticamente por igual período e assim sucessivamente por iguais períodos, mantendo-se todas as cláusulas originais avençadas.
                    </p>                        
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                    <b><small>RESCISÃO CONTRATUAL</small></b>                       
                    <p>
                        <br>
                        O contrato não poderá ser rescindido antecipadamente, por qualquer das partes, sem justo motivo, sob pena de aplicação automática de multa compensatória e 
                        prefixação de perdas e danos equivalente a <b>60% (sessenta)</b> do valor da média do faturamento mensal (soma de todos os pagamentos realizados), <b>nos 
                        últimos 12 meses</b>, monetariamente reajustadas, multiplicado pelo número de meses restantes para a conclusão do prazo integral, com a finalidade de recompor a <b>C&M SOFTWARE</b> 
                        pelos prejuízos decorrentes da rescisão antecipada e injustificada, posto que a <b>C&M SOFTWARE</b> realizou o gerenciamento e planejamento de custos, infraestrutura 
                        de equipamentos e softwares, equipes técnicas de suporte, manutenção e desenvolvimento de sistemas além das exigências regulatórias impostas pelo <b>BACEN</b> ao 
                        <b>PSTI C&M Software</b>, com vistas ao cumprimento das obrigações contratuais no prazo contratado entre as Partes.
                    </p>                    
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                    <b><small>REAJUSTE CONTRATUAL</small></b>                       
                    <p>
                        <br>
                        O reajuste se dará automaticamente a cada <b>12 (doze) meses</b> de vigência do contrato, pelo <b>**--INDICE_REAJUSTE--**</b>, nos termos da legislação vigente a contar da data de 
                        assinatura do presente Contrato, ou qualquer outro índice que venha, legalmente, a substituí-lo. 
                    </p>                    
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>
                    <b><small>FATURAMENTO</small></b>                        
                    <p>
                        <br>
                        Data de corte todo o dia <b> **--CORTE_FATURAMENTO--** **--CORTE_FATURAMENTO/EXTENSO--** de cada mês</b>, com prazo de pagamento <b> **--PRAZO_PAGAMENTO--** **--PRAZO_PAGAMENTO/EXTENSO--**</b> contados da apresentação da nota
                        fiscal/fatura, ocorrendo o primeiro faturamento <b> 19 (dezenove) </b>, independentemente da conclusão da implantação e do uso.   
                    </p>              
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                    <b><small>TAXA POR INATIVIDADE</small></b>                    
                    <p>
                        <br>
                        Após o prazo de 90 (noventa) dias contados da assinatura digital do presente contrato, sempre que o faturamento mensal for igual a R$ 0,00 (zero), ou seja, 
                        sempre que não existir valores a faturar, o <b>CLIENTE</b> está ciente que haverá o faturamento automático do valor de R$ 3.500.00 (três mil e quinhentos reais), 
                        referente a taxa por inatividade, para custear investimentos realizados pela <b>C&M SOFTWARE</b> para manutenção do ambiente e atualização dos produtos de hardware 
                        e software que dão origem ao presente contrato.
                    </p>
                    <p>
                        O faturamento da taxa por inatividade será realizado conforme previsto no item VIII) DO FATURAMENTO.
                    </p>
                    <br>
                </td>
            </tr> 
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>
                    <b><small>DIVULGAÇÃO</small></b>                        
                    <p>
                        <br>
                        O <b>CLIENTE</b>, desde já, autoriza a <b>C&M SOFTWARE</b> a incluir o seu nome na sua lista de clientes, assim como sua divulgação, pelos meios de comunicação próprios, 
                        juntamente com os nomes de outros clientes, mas não revelará, comunicará ou de qualquer forma fará propaganda a qualquer terceiro de detalhes deste Contrato.
                    </p>              
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>
                    <b><small>FORO</small></b>                        
                    <p>
                        <br>
                        Fica eleito o foro da comarca de Barueri do Estado de São Paulo para dirimir quaisquer questões advindas deste Instrumento, 
                        renunciando as partes a qualquer outro, por mais privilegiado que seja.
                    </p>              
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>                       
                    <b><small>TESTEMUNHAS:</small></b>                      
                    <p>
                        <br>
                        Nome: **--TESTEMUNHA_CMSW--** da C&M C.P.F. nº **--TESTEMUNHA_CMSW/CPF--** e-mail: **--TESTEMUNHA_CMSW/EMAIL--** 
                        <br>
                        Nome: **--TESTEMUNHA--** C.P.F. nº **--TESTEMUNHA_CPF--** e-mail: **--TESTEMUNHA_EMAIL--** 
                    </p>
                </td>
            </tr>            
        </tbody>
    </table>      
";

$texto[2] =
"
    <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>
                <td class='td_cabecalho' style='text-align:center;border-top:2px solid;border-bottom:2px solid;'>
                    <small><b>INSTRUMENTO PARTICULAR DE CONTRATO DE LICENCIAMENTO DOS SOFTWARES de PRODUTOS DE LIQUIDAÇÃO BACEN – PL-BACEN</b></small>
                </td>
            </tr>
        </tbody>
    </table>
    <p><b>CLÁUSULA PRIMEIRA: DO OBJETO</b></p>
    <p>
        <b>1.1.</b> O objeto do presente Contrato é o licenciamento de uso do software, de forma não exclusiva, intransferível e temporária, nos termos e condições aqui avençadas, 
        viabilizando ao CLIENTE a operação diretamente nos Sistemas de Liquidação do Banco Central do Brasil, conforme regulamentação em vigor.
    </p>
    <p>
        <b>1.2.</b> Todos os novos produtos/módulos ou funcionalidades, criados pela C&M SOFTWARE e disponibilizados na plataforma dos softwares PL-BACEN, serão informados ao CLIENTE.
        A opção, pelo CLIENTE, pelos novos produtos/módulos ou funcionalidades ocorrerá na primeira utilização, servindo para todo e qualquer efeito de direito, como aceitação dos 
        preços e condições disponibilizadas no Painel de Controle constante no site do produto.
    </p>
    <p>
        <b>1.3.</b> Este Contrato é composto pelos anexos abaixo descritos fazem parte integrante e indissociável do Contrato para todos os fins de direito:
    </p>
    <ul> Anexo Principal – Termo do PL-BACEN:SPI/x indireto; </ul>
    <ul> Anexo III – SISTEMA DA PAGAMENTOS INSTANTÂNEOS – SPI/x. </ul>
    <ul> (1) Declaração de Conformidade Social e Sigilo das Informações; </ul>
    <ul> (2) Política de Segurança da Informação e Cibernética; </ul>
    <ul> (3) Plano de Continuidade de Negócios; </ul>
    <ul> (4) Propriedade Intelectual; </ul>
    <ul> (5) Código de Ética; </ul>
    <ul> (6) Política Interna LGPD – “C&M2021-01-LGPD”. </ul>
    <br>
    <b>IMPORTANTE:</b> 	Os documentos referenciados de (1) a (6) estarão sempre disponíveis e atualizados no endereço: https://br.cmsw.com/politicas/

    <p><b>CLÁUSULA SEGUNDA: DO PRAZO DE VIGÊNCIA</b></p>
    <p> 
        <b>2.1.</b> O presente contrato terá vigência pelo prazo estabelecido no item “IV – DO PRAZO DE VIGÊNCIA” do Quadro Resumo.
    </p>
    <p>
        <b>CLÁUSULA TERCEIRA: DO PREÇO</b>
    </p>
    <p> 
        <b>3.1.</b> Os preços são aqueles mencionados no item “V – DO PREÇO” do Quadro Resumo e deverão ser pagos à <b>C&M SOFTWARE</b> por meio de DOC, TED ou boleto bancário, ou qualquer 
        outro sistema que venha substituí-los.
    </p>
    <p>
        <b>3.1.1.</b> O primeiro faturamento da “Hospedagem” será integralmente cobrado, conforme valor estabelecido no item “V – DO PREÇO” do Quadro Resumo, independente das datas de 
        vencimento e início do Contrato, não sendo aplicada a forma de cobrança “pro rata die”.
    </p>
    <p>
        <b>3.2.</b> Acordam as Partes que o faturamento decorrente do presente instrumento ocorrerá na forma estabelecida no item “IX – DO FATURAMENTO” do Quadro Resumo.
    </p>
    <p>
        <b>3.2.1.</b> A <b>C&M SOFTWARE</b> informará ao <b>CLIENTE</b> sobre a emissão do documento fiscal específico, por meio do e-mail disposto no item “II.2 – RESPONSÁVEIS FINANCEIROS” 
        do Quadro Resumo, enviando também nessa oportunidade o link para emissão da Nota Fiscal Eletrônica e respectivos boletos de pagamento, quando aplicável.
    </p>
    <p>
        <b>3.3.</b> Serão de responsabilidade do <b>CLIENTE</b> as despesas de viagens referentes ao transporte aéreo ou terrestre (quando o aéreo não for possível) e estadias ocorridas com 
        os profissionais da <b>C&M SOFTWARE</b>, sempre que houver necessidade de deslocamento da equipe da <b>C&M SOFTWARE</b>, a locais fora da região metropolitana de São Paulo/SP e Barueri/SP.
    </p>
    <p>
        <b>3.4.</b> Como forma de manter a hegemonia dos custos, as partes elegem, desde já, o índice estabelecido no item “VIII – DO REAJUSTE CONTRATUAL” do Quadro Resumo, como 
        índice de correção monetária, aplicável aos preços referidos neste Contrato.
    </p>
    <p>
        <b>3.4.1.</b> Quando aplicável e na hipótese de atraso ou ausência de publicação do índice aplicável, a <b>C&M SOFTWARE</b> emitirá as notas fiscais/faturas usando o último índice 
        publicado. Imediatamente após a publicação seguinte do referido índice, a <b>C&M SOFTWARE</b> emitirá os títulos para o pagamento e/ou ressarcimento da diferença entre valor 
        já cobrado e os valores efetivamente devidos, de acordo com o prazo de vencimento estabelecido no item “IX – DO FATURAMENTO” do Quadro Resumo.
    </p>
";

$texto[3] =
"
    <p>
        <b>3.4.2.</b> Na falta desse índice ou, se permitido por lei, ou por decisão judicial, será aplicado aos preços qualquer outro índice oficial, de variação diária, ou, se 
        inexistente, de variação mensal, calculando “pro rata die”, e que mais eficientemente elide os efeitos inflacionários da moeda corrente nacional, o qual será eleito mediante 
        comum acordo entre as partes.
    </p>
    <p>
        <b>3.5.</b> Na hipótese de ocorrerem fatos ou atos que possam prejudicar o equilíbrio econômico-financeiro do Contrato, as partes envidarão seus melhores esforços para 
        regular e disciplinar a situação criada, de forma a evitar qualquer perda de natureza econômica, financeira ou outra qualquer.
    </p>
    <p>
        <b>3.6.</b> Se, durante a vigência deste Contrato, forem criados novos tributos ou alteradas as alíquotas dos atuais, de forma a majorar ou diminuir o ônus das Partes 
        contratantes, os preços poderão ser revistos, de modo a serem ajustados a essas modificações, mediante envio de notificação por escrito da <b>C&M SOFTWARE</b> ao <b>CLIENTE</b>.
    </p>
    <p>
        <b>3.7.</b> A <b>C&M SOFTWARE</b> executará os serviços descritos neste Contrato em sua sede, ou de suas futuras filiais, as quais emitirão o correspondente documento fiscal, haja 
        vista serem consideradas, individualmente, como estabelecimentos ou locais, onde a <b>C&M SOFTWARE</b> desenvolve a sua atividade principal, de modo permanente ou eventual, nos 
        termos do artigo 4º da Lei Complementar nº 116, de 31/07/2003, publicada no Diário Oficial da União de 1/08/2003.
    </p>
    <p>
        <b>3.8.</b> O inadimplemento de toda e qualquer importância cobrada com base no presente Contrato, na data de seu vencimento, implicará na incidência automática de multa 
        moratória no percentual de <b>**--PERCENTUAL_MULTA--** **--PERCENTUAL_MULTA/EXTENSO--**</b> e juros de mora de <b>**--PERCENTUAL_JUROS--** **--PERCENTUAL_JUROS/EXTENSO--**</b> ao mês, encargos esses incidentes sobre o valor do débito atualizado de acordo com o 
        índice estabelecido no item “VIII – DO REAJUSTE CONTRATUAL” do Quadro Resumo, calculado “pro rata die” a partir da data de vencimento do respectivo documento de cobrança até 
        a data do efetivo pagamento.
    </p>
    <p>
        <b>3.8.1.</b> Os mencionados juros de mora, multa moratória e atualização monetária serão cobrados automaticamente no faturamento do mês subsequente.
    </p>
    <p>
        <b>3.9.</b> O acesso ao software poderá ser suspenso, sem aviso prévio, se a inadimplência do CLIENTE durar mais de 10 (dez) dias, contados da data de vencimento, e neste 
        caso não será reiniciada a não ser que todos os valores devidos sejam pagos na sua totalidade, sem prejuízo do direito da C&M SOFTWARE de rescindir o presente Contrato.
    </p>
    <p>
        <b>3.9.1.</b> Após a comprovação do pagamento dos valores em atraso pelo CLIENTE, o acesso aos softwares será desbloqueado e voltará a funcionar automaticamente.
    </p>
    <p><b>CLÁUSULA QUINTA: DO ACESSO AO PL-BACEN, IMPLANTAÇÃO E ATUALIZAÇÕES</b></p>
    <p>
        <b>4.1.</b> O <b>CLIENTE</b> recebeu no momento da contratação, ou até mesmo durante o processo de implantação e ativação dos produtos contratados, manuais explicativos 
        exemplificando o acesso aos softwares.
    </p>
    <p>
        <b>4.2.</b> A <b>C&M SOFTWARE</b> poderá promover atualizações nos softwares e serão sempre aplicadas na última versão disponibilizada em uso.
    </p>
    <p>
        <b>4.2.1.</b> Toda nova implementação ou atualização do software, solicitada pelo <b>CLIENTE</b>, após aprovação da <b>C&M SOFTWARE</b>, será incorporada na forma de licenciamento e 
        propriedade do <b>PL-BACEN</b>. 
    </p>
    <p>
        <b>4.3.</b> Se forem realizadas atualizações dos softwares, a <b>C&M SOFTWARE</b> obriga-se a comunicar e disponibilizá-las ao CLIENTE, gratuita e imediatamente.
    </p>
    <p><b>CLÁUSULA QUINTA: DAS OBRIGAÇÕES DA C&M SOFTWARE</b></p>
    <p>
        5.1. Sem prejuízo das demais obrigações previstas neste Contrato, a <b>C&M SOFTWARE</b> obriga-se a: 
    </p>
    <p>
        <b>5.1.1.</b> Executar o objeto deste Contrato, com a sua usual diligência, padrão e com observância das leis aplicáveis.
    </p>
    <p>
        <b>5.1.2.</b> Realizar a manutenção preventiva e corretiva do software objeto deste Contrato.
    </p>
    <p>
        <b>5.1.3.</b> Atualizar os sistemas que compõem o <b>PL-BACEN</b> para não incorrer em obsolescência tecnológica.
    </p>
    <p>
        <b>5.1.4.</b> A partir da assinatura do presente Contrato e durante toda a sua vigência, possuir e manter infraestrutura tecnológica que suporte o volume mínimo de mensagens 
        contratado e eventual superação de uso deste mesmo volume em até 3 (três) vezes, de tal modo a não gerar impacto impeditivo de uso ao <b>CLIENTE</b> no momento do uso.
    </p>
    <p>
        <b>5.1.5.</b> Toda e qualquer responsabilidade da <b>C&M SOFTWARE</b> limita-se,  única e exclusivamente, aos sistemas desenvolvidos sob sua autoria. A <b>C&M</b> não responderá pela 
        qualidade de produtos de terceiros, mesmo que tais produtos de terceiros precisem ser incorporados ao sistema.
    </p>
    <p>
        <b>5.2.</b> Segregar, no prazo de 90 (noventa) dias, os dados do <b>CLIENTE</b> dos demais dados de outros clientes dos softwares. Não será permitida a guarda de dados ou informações 
        nos Banco de Dados da C&M Software por período superior ao acima avençado.
    </p>
";

$texto[4] =
"
    <p><b>CLÁUSULA SEXTA: DAS OBRIGAÇÕES DO CLIENTE</b></p>
    <p>
        <b>6.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, o CLIENTE obriga-se a: 
    </p>
    <p>
        <b>6.1.1.</b> Agir de acordo com todas as leis, regras e regulamentações governamentais aplicáveis no acesso às informações. 
    </p>
    <p>
        <b>6.1.2.</b> Efetuar os pagamentos devidos pela contratação, de acordo com as disposições deste Contrato.
    </p>
    <p>
        <b>6.1.3.</b> Disponibilizar todos os dados/informações, dados e ambientes de terceiros, necessários à execução deste Contrato.
    </p>
    <p>
        <b>6.1.4.</b> Manter sob sigilo os códigos e senhas de acesso aos softwares, sendo de sua plena e total responsabilidade o uso indevido. Em caso de perda, fraude ou qualquer 
        outro risco na guarda, a <b>C&M SOFTWARE</b> deverá ser comunicada por escrito, da necessidade de bloqueio do acesso anterior e criação de novo acesso.
    </p>
    <p>
        <b>6.1.5.</b> Responsabilizar-se, civilmente por atos próprios, ou quaisquer atos de seus empregados, comitentes ou prepostos que vierem dar prejuízos, tanto materiais quanto 
        de imagem, ou de qualquer forma diminuir o patrimônio da <b>CONTRATANTE</b>.
    </p>
    <p>
        <b>6.1.6.</b> Manter estrutura adequada para o uso dos softwares, assim como, realizar a manutenção preventiva e corretiva dos itens fornecidos pela <b>C&M SOFTWARE</b>, mantendo os 
        equipamentos atualizados e operantes.
    </p>
    <p>
        <b>6.1.7.</b> Desde já, reconhecer que independente do uso do volume mínimo de mensagens contratado conforme item “V – DO PREÇO” do Quadro Resumo, que a infraestrutura 
        responsável por acolher este volume em até 3 (três) vezes já se encontra a sua disposição para uso a partir do momento da assinatura do presente Contrato, ficando a sua 
        deliberação e decisão o melhor momento para uso, sendo que esta decisão não impactará as demais responsabilidades deste instrumento.
    </p>
    <p>
        <b>6.2.</b> Cada parte deverá orientar seus representantes para que cumpram as orientações relativas à segurança, bem como normas e procedimentos, durante o período em que 
        esses representantes estiverem designados para prestarem serviços nas dependências da outra parte. 
    </p>
    <p><b>CLÁUSULA SÉTIMA: DA RESCISÃO</b></p>
    <p>
        <b>7.1.</b> O presente Contrato não poderá ser rescindido, antecipadamente, por qualquer das partes, sem justo motivo, sob pena de aplicação automática de multa disposta no 
        item “VI – DA RENOVAÇÃO DO CONTRATO” do Quadro Resumo.
    </p>
    <p>
        <b>7.2.</b> Este instrumento poderá ser rescindido, ainda, motivadamente, de forma imediata e de pleno direito:
        <br></br>        
        <b>a)</b> descumprimento de qualquer das cláusulas do Contrato, desde que não sanada no prazo de 10 (dez) dias a contar do recebimento da notificação da outra Parte neste 
        sentido;
        <br>
        <b>b)</b> a outra Parte vir a ter a sua falência ou recuperação judicial/extrajudicial requerida ou decretada, ou insolvência civil dos sócios, mesmo que presumida, bem como a 
        condenação de qualquer um dos seus sócios em processos criminais; e,
        <br>
        <b>c)</b> a outra Parte vir a ter sua idoneidade técnica ou financeira abalada ou o seu quadro societário modificado, de forma a prejudicar a fiel execução de suas obrigações 
        contratuais, a critério da outra Parte.
        <br>
        <b>d)</b> o encerramento das atividades, mesmo que voluntário, do <b>CLIENTE</b> ou alienação de direitos ou carteira, não o exime das infrações contratuais e consequentes multas a serem 
        aplicadas.
    </p>
    <p>    
        <b>7.2.1.</b> A parte que der causa à rescisão do presente Contrato, de forma motivada, arcará com a multa por quebra de acordo comercial e preços equivalente a 60% (sessenta) 
        do valor da média do faturamento mensal dos últimos 12 meses, devidamente reajustadas, multiplicado pelo número de meses restantes para a conclusão do prazo integral.
    </p>
    <p>
        <b>7.2.2.</b> O <b>CLIENTE</b> fico isento da aplicação da Cláusula 7.2.1 somente quando a rescisão contratual for oriunda do descumprimento por parte da <b>C&M SOFTWARE</b> ao Comunicado do 
        Banco Central do Brasil 8.454 e sua Circular 3.629/2013.
    </p>
    <p>
        <b>7.3.</b> O presente Contrato poderá ser encerrado, sem qualquer ônus, em razão da ocorrência de eventos de caso fortuito ou de força maior, regularmente comprovados, 
        impeditivos da execução deste Contrato. Quando for possível a execução apenas parcial do Contrato, o <b>CLIENTE</b> poderá decidir entre o cumprimento parcial ou o término 
        do Contrato.
    </p>
    <p>        
        <b>7.4.</b> Na ocorrência do término deste Contrato, por qualquer motivo, o <b>CLIENTE</b> remunerará a <b>C&M SOFTWARE</b> pelos serviços já prestados e concluídos, bem como 
        efetuará o pagamento das despesas já ocorridas, estabelecendo as Partes desde já que o faturamento da “Hospedagem” , em função do tipo de contratação (licenciamento do software) 
        será integralmente cobrado, conforme valor estabelecido no item “V – DO PREÇO” do Quadro Resumo, independente das datas de rescisão e vencimento, não sendo aplicada a forma de 
        cobrança “pro rata die”.
    </p>
    <p>
        <b>7.5.</b> Esta cláusula se aplica a qualquer dos contratos individualmente, e será assim considerada para ambos.
    </p>
    <p><b>CLÁUSULA OITAVA: DAS DISPOSIÇÕES GERAIS</b></p>
    <p>
        <b>8.1.</b> Nenhuma disposição deste Contrato poderá ser interpretada como tendo as Partes estabelecido qualquer forma de sociedade ou associação, de fato ou de direito, 
        remanescendo cada uma das partes com suas obrigações civis, comerciais, trabalhistas e tributárias, de forma autônoma.
    </p>
";

$texto[5] =
"
    <p>
        <b>8.2.</b> Nenhuma das Partes poderá ceder ou transferir, no todo ou em parte, os direitos e obrigações decorrentes deste Contrato, sem a anuência prévia e expressa da 
        outra Parte.
    </p>
    <p>
        <b>8.3.</b> Qualquer aditamento ou alteração a este Contrato somente será válida se feito por meio de aditivo contratual, escrito e assinado pelas Partes.
    </p>
    <p>
        <b>8.4.</b> Todas as obrigações e condições aqui estipuladas obrigam as Partes e seus sucessores a qualquer título.
    </p>
    <p>
        <b>8.5.</b> Todas as notificações ou comunicações dadas segundo o presente Contrato, de uma Parte à outra, deverão ser endereçadas somente por via postal através de carta 
        registrada, todos com aviso de recebimento, para os representantes legais nos endereços constantes na qualificação das Partes. Se houver alteração do Representante Legal, 
        deverá ser anexado documento de comprovação para o exercício do ato.
    </p>
    <p> 
        <b>8.6.</b> A tolerância de uma Parte com a outra, relativamente a qualquer violação ou descumprimento de quaisquer obrigações ora assumidas, não será considerada moratória, 
        novação ou renúncia a qualquer direito, constituindo mera liberalidade, que não impedirá a Parte tolerante de exigir da outra o fiel cumprimento deste Contrato, a qualquer 
        tempo.
    </p>
    <p>
        <b>8.7.</b> Se qualquer cláusula ou condição deste Contrato vier a ser considerada ilegal, inválida ou inexequível nos termos da legislação brasileira, as demais cláusulas e 
        condições continuarão em pleno vigor e efeito.
    </p>
    <p>
        <b>8.8.</b> O presente Contrato constitui o acordo final entre as Partes com relação às matérias aqui expressamente tratadas, superando e substituindo todas as propostas, 
        acordos, entendimentos e declarações anteriores, orais ou escritos.
    </p>
    <p>
        <b>8.9.</b> Cada uma das Partes declara, garante e concorda, reciprocamente, que a celebração, outorga e execução deste Contrato foi devidamente autorizada pelos seus 
        legítimos representantes legais, na forma dos seus respectivos documentos societários, sendo que o fornecimento de eventual informação inverídica, incompleta ou inidônea 
        será considerado infração aos princípios da informação e boa-fé contratual, respondendo a parte que assim as prestou civil e criminalmente, restando claro que este contrato 
        constitui obrigação legal, válida e vinculante entre as Partes.
    </p>
    <p>
        <b>8.10.</b> As <b>Partes</b> comprometem-se a não aliciar os profissionais regidos por Contrato de Trabalho e/ou como Prestadores de Serviços que estão envolvidos, direta ou 
        indiretamente, com objeto deste contrato. Esta prática, quando comprovada, motivará a parte afetada à rescisão motivada do presente contrato, aplicando-se, ainda, à <b>Parte</b> 
        afetada, a aplicação do <b>art. 608 do Código Civil.</b>
    </p>
    <p>
        <b>8.11.</b> O presente Contrato é considerado título executivo extrajudicial, nos termos do inciso III, do artigo 784, do Código de Processo Civil, sujeitando-se, dessa 
        forma, à legislação aplicável à matéria.
    </p>
    <p>
        <b>8.12.</b> As Partes elegem o foro da Comarca conforme declinado no item “<b>XI – DO FORO</b>” do Quadro Resumo, para dirimir quaisquer dúvidas ou atos oriundos ou relativos 
        a este contrato, renunciando a qualquer outro por mais privilegiado que seja. E assim, por estarem justas e contratadas, as partes assinam o presente em 02 (duas) vias de igual 
        teor, na presença das testemunhas abaixo
    </p>
";

$texto[6] =
"
    <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>
                <td class='td_cabecalho' style='text-align:center;border-top:2px solid;border-bottom:2px solid;'>
                    <small><b>ANEXO – DO SPB Open Banking Edition - OBE/x</b></small>
                </td>
            </tr>
        </tbody>
    </table>

    <p><b>CLÁUSULA PRIMEIRA: DO OBJETO</b></p>
    <p>
        <b>1.1.</b> O objeto do presente Contrato é o licenciamento de uso do software <b>SPB Open Banking Edition - OBE /x</b>, de forma não exclusiva, intransferível e temporária, nos 
        termos e condições aqui avençadas, viabilizando ao <b>CLIENTE</b> a operação diretamente no Sistema de Transmissão de Reservas (STR) via Domínio SPB Open Banking Edition - OBE 01 
        e o processo de Boletos Registrados da Nova Plataforma de Cobrança via Domínio SPB Open Banking Edition - OBE 02, bem como de compensação de cobranças e DOCs do Sistema de 
        Liquidação Diferida das Transferências Interbancárias de Ordens de Crédito – SILOC/Câmara Interbancária de Pagamentos – CIP, sendo este, ANEXO indissociável do <b>Contrato de 
        Licenciamento de Uso do Software Produtos de Liquidação BACEN (PL-BACEN).</b>
    </p>
    <p>
        <b>1.2.</b> Todos os novos produtos/módulos ou funcionalidades, criados pela <b>C&M SOFTWARE</b> e disponibilizados na plataforma do software <b>SPB Open Banking Edition - 
        OBE /x</b>, serão informados ao <b>CLIENTE</b>. A opção pelo <b>CLIENTE</b> aos novos produtos/módulos ou funcionalidades ocorrerá na primeira utilização, servindo para todo e qualquer efeito 
        de direito, como aceitação aos preços e condições disponibilizadas no Painel de Controle constante no site do produto.
    </p>
    <p><b>CLÁUSULA SEGUNDA: DO SPB Open Banking Edition - OBE</b></p>
    <p> 
        <b>2.1.</b> O <b>SPB Open Banking Edition - OBE</b>  viabiliza ao <b>CLIENTE</b> a operação diretamente no Sistema de Transmissão de Reservas (STR) via Domínio SPB Open 
        Banking Edition - OBE 01 e o processo de Boletos Registrados da Nova Plataforma de Cobrança via Domínio SPB OBE 02.
    </p>
    <p>
        <b>2.1.1.</b> Não serão tarifadas/faturadas as mensagens identificadas com a tipificação “R1” e demais identificações e tipificações serão objeto de tarifação e faturamento 
        no ambiente de produção
    </p>
    <p>
        <b>2.2.</b> Pelos serviços de Implantação a <b>C&M SOFTWARE</b> configurará os sistemas que compõem a solução SPB Open Banking Edition - OBE , compreendendo os ambientes de 
        Homologação e Produção, contemplando os seguintes serviços:
        <br></br>
        <b>a)</b> Geração do MQ-Series: Configuração e Geração do MQ-Series, segundo os padrões adotados pelo Banco Central do Brasil;
        <br>
        <b>b)</b> Geração da Rede Lógica: Configuração de Serviços de Rede (DNS) e Servidores para o suporte das atividades do <b>CLIENTE</b>, e elementos de redes necessários quando da 
        conexão remota solicitada pelo <b>CLIENTE</b>;
        <br>
        <b>c)</b> Geração do Message Router: Configuração dos Servidores de Mensagens XML;
        <br>
        <b>d)</b> Criptógrafos: Instalação, na sede do <b>CLIENTE</b>, de softwares de propriedade da <b>C&M SOFTWARE</b> necessários para a cifragem das mensagens a serem geradas para o Banco 
        Central do Brasil, seguindo o padrão por ele estipulado.
    </p>
    <p>
        <b>2.2.1.</b> A Implantação contempla, ainda, o treinamento ao <b>SPB Open Banking Edition - OBE</b>  concedido pela C&M SOFTWARE ou terceiros por ela credenciados, nas 
        instalações físicas da <b>C&M SOFTWARE</b>, do <b>CLIENTE</b>, ou outro local indicado por este, de até 3 (três) profissionais da <b>CONTRATANTE</b> na utilização do software 
        ora contratado, conforme abaixo descrito:
        <br></br>    
        <b>a)</b> Treinamento Mensageria: Consiste no treinamento na utilização do Sistema C&M Message Router;
        <br>
        <b>b)</b> Treinamento Piloto de Reserva: Consiste no treinamento da utilização do C&M Piloto de Reserva e suas funcionalidades desenvolvidas até a data do treinamento; e,
        <br>
        <b>c)</b> Treinamento Piloto de Reserva Configurações: Consiste no treinamento do C&M Piloto de Reserva aplicável somente as condições de filtragem disponível nas funcionalidades 
        desenvolvidas até a data do treinamento.
    </p>
    <p>
        <b>2.2.2.</b> O treinamento deverá ser solicitado pelo <b>CLIENTE</b>, com um prazo mínimo de 30 (trinta) dias de antecedência, sendo que, caso o local escolhido seja fora da região 
        metropolitana da cidade de São Paulo, as despesas com transportes, hospedagem e alimentação dos instrutores, serão de responsabilidade exclusiva do <b>CLIENTE</b>.
    </p>
    <p>
        <b>2.3.</b> A licença de uso do SPB Open Banking Edition - OBE contempla: 
        <br></br>
        <b>a)</b> Licença de Uso C&M Message Router: Utilização do Sistema de Mensageria da C&M SOFTWARE;
        <br>
        <b>b)</b> Licença de Uso C&M Piloto de Reserva: Utilização do Sistema de Gerenciamento de Conta Reserva de propriedade da C&M SOFTWARE;
        <br>
        <b>c)</b> Licença de Uso C&M Suite Package Security: Módulo de Cifragem que compõe a Solução; e,
        <br>
        <b>d)</b> Acesso a RSFN: Acessos aos serviços da C&M SOFTWARE na RSFN, através de seus links próprios.
    </p>
     <p>
        <b>2.4.</b> No ambiente conhecido como produção do SPB Open Banking Edition - OBE a <b>C&M SOFTWARE</b> garantirá os seguintes níveis de desempenho:
        <br></br>    
        <b>a)</b> 100 (cem) mensagens recebidas e/ou enviadas por minuto, desconsiderando os tempos relativos ao tempo de transmissão, recepção, de Rede Interna e RSFN;
        <br>
        <b>b)</b> 03 (três) segundos para acesso às telas de consulta de mensagens, desconsiderando os tempos relativos ao tempo de transmissão, recepção, de Rede Interna e RSFN, 
        considerando ainda que o <b>CLIENTE</b> compromete-se a utilizar na aferição equipamentos com a configuração mínima exigida na época da avaliação;
        <br>
        <b>c)</b> caso a indisponibilidade da C&M SOFTWARE acarrete ao <b>CLIENTE</b> a utilização dos serviços de contingência do BACEN, a C&M SOFTWARE reembolsará em faturamento futuro as 
        despesas decorrentes desta contratação.
    </p>
";

$texto[7] =
"   
    <p>
        <b>2.5.</b> Manter a disponibilidade mínima de operacionalidade de 99,8% (noventa e nova inteiros e oito centésimos por cento), por 7 (sete) dias na semana e 24 
        (vinte e quatro) horas no dia, conforme Comunicado n° 8454 do Banco Central do Brasil.
    </p>
    <p>
        <b>2.5.1.</b> Não serão considerados para cálculo de nível de operacionalidade os seguintes casos:
        <br></br>
        <b>a)</b> execução de manutenção, comunicada pela <b>C&M SOFTWARE</b> com mínimo de 15 (quinze) dias de antecedência;
        <br>
        <b>b)</b> operação inadequada do software e dos equipamentos pelo <b>CLIENTE</b>, em desacordo com as instruções da <b>C&M SOFTWARE</b>;
        <br>
        <b>c)</b> falhas ocasionadas em relação à infra-estrutura do <b>CLIENTE</b> ou de seus clientes finais.
        <br>
        <b>d)</b> quando, por qualquer motivo, o <b>CLIENTE</b> impedir o acesso da <b>C&M SOFTWARE</b> onde estejam localizados seus equipamentos ou os por ela mantidos, postergando 
        assim o restabelecimento da operação.
    </p>
    <p>
        <b>2.6.</b> O <b>CLIENTE</b> tem conhecimento que toda a comunicação por intermédio da rede mundial de computadores (internet) está sujeita a interrupções e/ou atrasos, 
        podendo ocorrer problemas de transmissão ou de recepção das informações acessadas.    
    </p>
    <p><b>CLÁUSULA TERCEIRA: DAS OBRIGAÇÕES DA C&M SOFTWARE</b></p>
    <p> 
        <b>3.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, a C&M SOFTWARE obriga-se a: 
    </p>
    <p>
        <b>3.1.1.</b> Manter e atualizar seus Sistemas que compõem a solução SPB Open Banking Edition - OBE, Ambiente de Homologação e Produção, conforme abaixo:
        <br></br>

        <b> a) </b> MQ-Series, manter atualizado com o padrão estipulado pelo Banco Central do Brasil e as Câmaras que participam do Sistema;
        <br>
        <b> b) </b> Mensageria, sempre atualizada com a última versão do “book” de Mensagens e DTD padronizadas pelo Banco Central do Brasil e as Câmaras que participam do Sistema;
        <br>
        <b> c) </b> Módulo de Segurança, manter atualizado com a última versão divulgada pelo Banco Central do Brasil;
        <br>
        <b> d) </b> Piloto de Reservas, manter compatível com o todo do Sistema SPB Open Banking Edition - OBE , segundo especificações do Banco Central do Brasil.
    </p>
   
    <p>
        <b>3.1.2.</b> Manter o histórico de mensagens dos últimos 02 (dois) meses, mais o mês corrente disponíveis para acesso online. A base histórica anterior a esse período deverá 
        ser guardada pelo <b>CLIENTE</b>.
    </p>
    <p>
        <b>3.1.2.1.</b> Mensalmente a <b>C&M SOFTWARE</b> disponibilizará ao <b>CLIENTE</b> gerará um arquivo .ZIP em um site FTP com a base anterior ao mês corrente para guarda do 
        <b>CLIENTE</b>.
    </p>
    <p>
        <b>3.1.2.2.</b> Fornecerá também um software, durante a vigência deste Contrato, para visualização das mensagens conforme padrão exigido pelo Banco Central do Brasil, 
        convencionado no documento “Manual de Segurança de Mensagens do SPB Open Banking Edition - OBE ”, capítulo que trata da manutenção e guarda dos registros para fins de 
        auditoria.
    </p>
    <p><b>CLÁUSULA QUARTA: DAS OBRIGAÇÕES DO CLIENTE</b></p>
    <p>
        <b>4.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, o <b>CLIENTE</b> obriga-se a: 
    </p>
    <p>
        <b>4.1.1.</b> Fornecer, por escrito, todos os dados técnicos que vierem a ser solicitados pela C&M SOFTWARE, necessários para a elaboração do Projeto e execução do Contrato.
    </p>
    <p> 
        <b>4.1.2.</b> Fornecer, durante a execução da Implantação, sem ônus para a C&M SOFTWARE, recursos telefônicos e de fac-símile para comunicação, bem como facilidades para 
        fotocópias de documentos. 
    </p>
    <p>
        <b>4.1.3.</b> Fornecer todos os dados técnicos necessários à disponibilização do acesso da C&M SOFTWARE, através dos seus links próprios, à RSFN.
    </p>
    <p>
        <b>4.1.4.</b> Abster-se de reparar, modificar, ou mesmo adicionar novos componentes ou conexões, ou fazer alterações e/ou mudanças de qualquer tipo nas Estações de 
        Telecomunicações, sem prévia autorização por escrito por parte da <b>C&M SOFTWARE.</b>
    </p>        
";

$texto[8] =
"   
    <p><b>CLÁUSULA QUINTA: SERVIÇOS NO SILOC/CIP</b></p>
    <p>
        <b>5.1.</b> Os serviços de <b>Compensação de Cobranças e de DOCS do SILOC/CIP</b> serão executados considerando os seguintes procedimentos:
    </p>  
    <p>
        <b>5.2. Representação junto à CIP/SILOC – Tráfego de Arquivos e Troca Física de Documentos: </b>
    </p>
    <p>
        <b>5.2.1.</b> Representar o <b>CLIENTE PARTICIPANTE</b> do <b>SILOC</b> junto à <b>CIP</b> (Câmara Interbancária de Pagamentos), com o credenciamento do BANCOOB, parceiro da 
        <b>CONTRATADA</b>, para a realização da <b>troca física</b> dos documentos de <b>CAC</b> (Comunicado de Acerto de Cobrança) e de <b>Inconsistência de Cobrança</b> com os 
        participantes do <b>SILOC</b> (Sistema de Liquidação Diferida das Transferências Interbancárias de Ordens de Crédito) ou  seus representantes, na cidade de São Paulo/SP;
    </p>
    <p>
        <b>5.2.2.</b> Efetuar a troca física de documentos de Comunicado Acerto de Cobrança <b>(CAC)</b> e de Inconsistência de Cobrança do <b>CLIENTE PARTICIPANTE</b> do <b>SILOC</b>, 
        realizando inclusive o transporte até as instalações dos participantes do SILOC ou de seus representantes, na cidade de São Paulo/SP;
    </p>
    <p>
        <b>5.3.</b> Representar o <b>CLIENTE PARTICIPANTE</b> do <b>SILOC</b> junto à <b>CIP</b>, com o credenciamento do BANCOOB, parceiro da <b>CONTRATADA</b>, para o Tráfego de Arquivos de 
        todas as rotinas de Cobranças e de DOCs, incluindo os Resultados de Ordens de Crédito (ROCs) do <b>SILOC</b>, através da comunicação via software Connect Direct com os sites 
        (principal e contingência) do Executante.
    </p>
    <p><b>6. Tráfego de Arquivos Compensação de Cobranças/DOCs do SILOC junto à CIP:</b></p>
    <p>        
        <b>6.1.</b> Recepcionar do <b>CLIENTE PARTICIPANTE</b> do <b>SILOC</b>, por link de internet através de FTP ou por outro meio de comunicação utilizado pela <b>CONTRATADA</b>, os arquivos lógicos 
        de compensação da Nossa Remessa de Cobranças e de DOCs, nos layouts COB605 e DCR605, respectivamente.
    </p>
    <p>
        <b>6.2.</b> Transmitir para a CIP, através dos sites do Executante (principal e contingência) e com o uso do software Connect Direct, os arquivos lógicos COB605 da Nossa 
        Remessa de Cobranças e DCR605 da Nossa Remessa de DOCs e de Remessa de Acertos de Arquivos ROC605 do <b>CLIENTE PARTICIPANTE</b> do <b>SILOC</b>;
    </p>
    <p>
        <b>6.3.</b> Recepcionar da CIP, através dos sites do Executante (principal e contingência), com o uso do software Connect Direct, os arquivos COB615 da Sua Remessa de 
        Cobranças e os arquivos DCR615 da Sua Remessa de DOCs do <b>CLIENTE PARTICIPANTE</b> do <b>SILOC</b>, recebidos dos participantes  do <b>SILOC</b>; 
    </p>
    <p>
        <b>6.4.</b> Transmitir para o <b>CLIENTE PARTICIPANTE</b> do <b>SILOC</b>, por link de internet através de FTP ou outro meio de comunicação utilizado pela <b>CONTRATADA</b>, os arquivos COB615 da 
        Sua Remessa de Cobranças e DCR615 da Sua Remessa DOCs, recepcionados da CIP com os registros enviados pelos participantes do <b>SILOC</b>;
    </p>
    <p>
        <b>6.5.</b> Transmitir para o <b>CLIENTE PARTICIPANTE</b> do <b>SILOC</b>, por link de internet através de FTP ou outro meio de comunicação utilizado pela <b>CONTRATADA</b>, se houver movimentos, 
        os arquivos DVC615 de Devoluções Recebidas de Cobrança e DCR615 de Devoluções Recebidas de DOCs, recepcionados da CIP com os registros devolvidos pelos participantes do <b>SILOC</b>;
    </p>
    <p>
        <b>6.6.</b> Transmitir também para o <b>CLIENTE PARTICIPANTE</b> do <b>SILOC</b>, por link de internet através de FTP ou outro meio de comunicação utilizado pela <b>CONTRATADA</b>, os arquivos 
        ROC640N9 (sessão noturna) e ROC640D9 (sessão diurna), recepcionados da CIP com os Resultados de Ordens de Crédito (ROCs) do Sistema de Liquidação Diferida das Transferências 
        Interbancárias de Ordens de Crédito (SILOC).
    </p>
    <p><b>7. Geração de Arquivos para Devoluções Remetidas de Cobrança e de DOCs:</b></p>
    <p>
        <b>7.1.</b> Recepcionar do <b>CLIENTE PARTICIPANTE</b> do <b>SILOC</b>, através de e-mail destinado ao Centro de Serviços da <b>CONTRATADA</b>, na cidade de São Paulo/SP, com os dados das 
        Cobranças da Sua Remessa e/ou dos DOCs da Sua Remessa de movimentos de dias úteis anteriores, conforme prazo estabelecido pela CIP, para a geração de arquivos de devolução 
        aos respectivos remetentes participantes do <b>SILOC</b>; 
    </p>
    <p>
        <b>7.2.</b> Carregar, em sistemas de Devolução da <b>CONTRATADA</b>, os arquivos da Sua Remessa de Cobranças e/ou da Sua Remessa de DOCs de movimentos de dias úteis anteriores,  
        conforme prazo estabelecido pela CP,  para localizar os documentos informados em e-mail do <b>CLIENTE PARTICIPANTE</b> do <b>SILOC</b>; 
    </p>
    <p>
        <b>7.3.</b> Processar, após a conferência com os dados no e-mail recebido do <b>CLIENTE PARTICIPANTE</b> do <b>SILOC</b>, os documentos localizados nos arquivos da Sua Remessa de Cobranças 
        e/ou de DOCs de movimentos de dias úteis anteriores, conforme prazo estabelecido pela CIP, para  geração dos arquivos de devolução aos remetentes participantes do <b>SILOC</b>; 
    </p>
     <p>
        <b>7.4.</b> Gerar os arquivos de devolução de Cobranças da Sua Remessa no layout DVC605 e os arquivos de devolução de DOCs da Sua Remessa no layout DCR607 do CLIENTE 
        PARTICIPANTE do SILOC, para transmissão na grade horária definida pela CIP; 
    </p>
    <p>
        <b>7.5.</b> Transmitir para a CIP, através dos sites do Executante (principal e contingência) e utilização de software Connect Direct, os arquivos DVC605 com as Devoluções de 
        Cobranças da Sua Remessa e os arquivos DCR607 com as Devoluções de DOCs da Sua Remessa do CLIENTE PARTICIPANTE do SILOC, para os remetentes participantes do SILOC.  
    </p>
";


$texto[9] = 
"   
   
    <p>
        <b>8. Geração de Remessas de Acerto de Cobrança de Arquivos “ROC605” para CACs:</b>
    </p>
    <p>
        <b>8.1.</b> Recepcionar do CLIENTE PARTICIPANTE do SILOC, através de e-mail destinado ao Centro de Serviços da CONTRATADA, na cidade de São Paulo/SP, as solicitações de 
        emissão de documentos de Comunicado de Acerto de Cobrança (CAC) com as informações e as comprovações necessárias, para emissão e geração de Remessas de Acerto de Arquivos 
        ROC605; 
    </p>
    <p>
        <b>8.2.</b> Digitar, em aplicativo da CONTRATADA, com base no e-mail do CLIENTE PARTICIPANTE do SILOC, os dados, principalmente tipo de movimento, código do participante 
        destinatário e o valor, para a emissão de cada Comunicado de Acerto de Cobrança (CAC); 
    </p>
    <p>
        <b>8.3.</b> Emitir os documentos de Comunicado de Acerto de Cobrança (CAC), realizando a impressão no aplicativo da CONTRATADA, após a conferência dos dados digitados 
        confrontando com as informações no (s) e-mail (s) recebido (s)l do CLIENTE PARTICIPANTE do SILOC; 
    </p>
    <p>
        <b>8.4.</b> Gerar as Remessas de Acerto do CLIENTE PARTICIPANTE do SILOC com os documentos de Comunicado de Acerto de Cobrança (CAC) no layout ROC605, para transmissão na 
        grade horária estabelecida pela CIP; 
    </p>
    <p>
        <b>8.5.</b> Transmitir para a CIP, através dos sites do Executante (principal e contingência) com uso do software Connect Direct, as Remessas de Acerto no layout ROC605 dos 
        documentos de Comunicado de Acerto de Cobrança (CAC)  do CLIENTE PARTICIPANTE do SILOC; 
    </p>
    <p>
        <b>8.6.</b> Liberar, após a transmissão das Remessas de Acerto no layout ROC605 para a CIP, os Comunicados de Acertos de Cobrança (CACs) para a entrega nas instalações aos 
        destinatários participantes do SILOC ou seus representantes, na cidade de São Paulo/SP.
    </p>
    <p>
        <b>9.</b> Tratamento de Inconsistência de Cobrança:</b>
    </p>
    <p>
        <b>9.1.</b> Recepcionar, até as 11h00, arquivo enviado pela CIP com as solicitações de Inconsistências de Cobranças, para o Centro de Serviços da CONTRATADA, na cidade de São Paulo, 
        acionar a área competente do CLIENTE PARTICIPANTE do SILOC, responsável pelas providências das respectivas cópias;
    </p>
    <p>
        <b>9.2.</b> Importar o arquivo recebido em aplicativo da CONTRATADA e efetuar a geração de relatório com as solicitações de Inconsistências de Cobranças, para encaminhar à 
        área competente do CLIENTE PARTICIPANTE do SILOC;
    </p>
    <p>
        <b>9.3.</b> Encaminhar para a área competente do CLIENTE PARTICIPANTE do SILOC, até às 12h00, por meio de link de internet através de FTP ou por outro meio de comunicação 
        utilizado pela CONTRATADA, o relatório gerado com as solicitações de Inconsistências de Cobrança; 
    </p>
    <p>
        <b>9.4.</b> Receber do CLIENTE PARTICIPANTE do SILOC, através de e-mail e até às 15h00, os documentos comprobatórios das solicitações de Inconsistências de Cobrança, para o 
        Centro de Serviços da CONTRATADA, na cidade de São Paulo, providenciar a entrega nas instalações dos participantes do SILOC ou de seus representantes; 
    </p>
    <p>
        <b>9.5.</b> Entregar as cópias dos documentos das inconsistências de cobrança solicitadas, realizando o transporte até as instalações dos destinatários participantes do SILOC 
        ou de seus representantes, na cidade São Paulo/SP, conforme a grade horária definida pela CIP.
    </p>
    <p>
        <b>10. Exercício de Homologação do CLIENTE PARTICIPANTE do SILOC junto à CIP:</b>
    </p>
    <p>
        <b>10.1.</b> Gerar e transmitir, pelo período que for definido pela CIP – Câmara Interbancária de Pagamentos, os arquivos testes da Nossa Remessa de Cobranças e de DOCs do CLIENTE 
        PARTICIPANTE do SILOC para o ambiente de Homologação do Sistema de Liquidação Diferida das Transferências Interbancárias de Ordens de Crédito (SILOC), conforme segue:
        <br></br>
        COB405 (Nossa Remessa Cobranças - Homologação) - Sessão Noturna;
        <br>
        DCR405 (Nossa Remessa DOCs - Homologação) - Sessão Noturna; 
    </p>
     <p>
        <b>10.2.</b> Recepcionar do Ambiente de Homologação do <b>SILOC</b>, pelo período definido pela <b>CIP</b>, os arquivos de testes para a crítica do resultado do processamento da Nossa Remessa de 
        Cobranças e de DOCs, conforme segue;
        <br>
        COB470 (Crítica Nossa Remessa de Cobranças) - Sessão Noturna;
        <br>
        DCR470 (Crítica Nossa Remessa de DOCs) - Sessão Noturna. 
    </p>

";

$texto[10] =
"      
    <p>    
        <b>10.3.</b> Recepcionar do Ambiente de Homologação do <b>SILOC</b>, pelo período definido pela <b>CIP</b>, os arquivos de testes da Sua Remessa de Cobranças e de DOCs, conforme segue;
        COB415 (Sua Remessa de Cobranças) – Sessão Noturna;
        DCR415 (Sua Remessa de DOCs) - Sessão Diurna. 
    </p>
    <p>
        <b>10.4.</b> Gerar e transmitir, pelo período definido pela <b>CIP</b>, os arquivos testes das Devoluções Remetidas de Cobranças e de DOCs, para o Ambiente de Homologação do <b>SILOC</b>, 
        conforme segue:
        <br>
        DVC405 (Devoluções de Cobranças) - Sessão Noturna;
        <br>
        DCR407 (Devoluções de DOCs) - Sessão Diurna; 
    </p>
    <p>
        <b>10.5.</b> Recepcionar do Ambiente de Homologação do <b>SILOC</b>, pelo período definido pela <b>CIP</b>, os arquivos testes para a crítica do resultado do processamento das Devoluções 
        Remetidas de Cobranças e de DOCs, conforme segue:
        <br>
        DVC470 (Crítica Devoluções de Cobranças) - Sessão Noturna;
        <br>
        DCR470 (Crítica Devoluções de DOCs) - Sessão Diurna. 
    </p>
    <p>
        <b>10.6.</b> Recepcionar do Ambiente de Homologação do <b>SILOC</b>, pelo período definido pela <b>CIP</b>, os arquivos de testes das Devoluções Recebidas de Cobranças e de DOCs, 
        conforme segue:
        <br>
        DVC415 (Devoluções Recebidas de Cobranças) - Sessão Noturna;
        <br>
        DCR415 (Devoluções Recebidas de DOCs) - Sessão Diurna.
    </p>
    <p> 
        <b>10.7.</b> Gerar e transmitir, pelo período que for definido pela <b>CIP</b>, os <b>arquivos de testes</b> das <b>Remessas de Acerto</b> de testes dos documentos de Comunicado de Acertos de Cobrança 
        (CAC), para o Ambiente de Homologação do <b>SILOC</b>, conforme segue:
        <br>
        ROC405 (Remessa de Acerto para CACs) - Sessão Noturna.
    </p>
    <p>
        <b>10.8.</b> Recepcionar do Ambiente de Homologação do <b>SILOC</b>, pelo período definido pela <b>CIP</b>, os arquivos testes para crítica do resultado do processamento das 
        Remessas de Acerto gerados para documentos de Comunicado de Acerto de Cobrança (CAC), conforme segue:
        <br>
        ROC470 (Crítica Devoluções de Cobranças) - Sessão Noturna;
    </p>
    <p>
        <b>10.9.</b> Recepcionar do ambiente de Homologação do <b>SILOC</b>, pelo período definido pela <b>CIP</b>, os arquivos testes dos Resultados das Ordens Crédito (ROCs) das 
        remessas e das devoluções na sessão diurna e na sessão noturna, conforme segue:
        <br>
        ROC440N9 (Resultado de Ordens de Crédito) - Sessão Noturna; 
        <br>
        ROC440D9 (Resultado de Ordens de Crédito) - Sessão Diurna.  
    </p>
    <p>
        <b>11. Do Transporte:</b>
    </p>
    <p>
        <b>11.1.</b> O <b>CONTRATANTE</b> reconhece que a <b>CONTRATADA</b> não possui serviço de transporte próprio e, por essa razão, autoriza a contratação de empresa especializada no transporte 
        de documentos, para entrega e/ou coleta de documentos de Comunicado de Acerto de Cobrança <b>(CAC)</b> e de Inconsistência de Cobrança nas instalações dos participantes do Sistema de 
        Liquidação Diferida das Transferências Interbancárias de Ordens de Crédito <b>(SILOC)</b> na praça de São Paulo/SP, mediante utilização de carro leve ou moto.
    </p>
    <p>
        <b>11.2.</b> A <b>CONTRATADA</b>, em caráter irrevogável e irretratável, que em nenhuma hipótese poderá ser atribuída à <b>CONTRATANTE</b> qualquer responsabilidade trabalhista, custo, 
        encargo ou indenização pela contratação de empresa especializada no transporte de documentos;
    </p>
    <p>
        <b>11.3.</b> Em razão da impossibilidade da <b>CONTRATADA</b> em responder pela execução do serviço de transporte, as Partes ajustam que a responsabilidade da <b>CONTRATADA</b> 
        restringe-se exclusivamente por atos de dolo ou culpa nos processos sob sua gestão direta, sem que seja possível imputar-lhe quaisquer ocorrências relacionadas a roubos e sinistros de 
        malotes / documentos do <b>CONTRATANTE</b> e seus clientes durante o período de transporte;
    </p>
     <p>
        <b>11.4.</b> Para os casos de roubos e sinistros de malotes / documentos do <b>CONTRATANTE</b> e/ou seus clientes que serão entregues e/ou coletados durante o período de transporte, a 
        partir de dados em arquivos lógicos, a <b>CONTRATADA</b> envidará os seus melhores esforços para resgatar as informações  e assumirá os custos desses procedimentos, para o processamento 
        de acordo com o manual da Câmara Interbancária de Pagamentos (<b>CIP</b>) e/ou do manual da compensação do Banco do Brasil, sem que lhe seja imputado quaisquer prejuízos oriundos do 
        insucesso dessa prática.
    </p>
    <p>
        <b>12.</b> Na prestação dos serviços de compensação de Cobranças e de DOCs do <b>CLIENTE PARTICIPANTE</b> do SILOC junto à <b>CIP</b>, para o tráfego de arquivos lógicos e para a troca física 
        dos documentos com os outros participantes do SILOC destacam-se os seguintes itens contemplados neste contrato:
        <ul> 
            Infraestrutura composta por instalações, equipamentos, pessoas, sistemas, servidores, links externos e softwares de comunicação para o tráfego de arquivos das rotinas de 
            Cobranças e de DOCs junto à <b>CIP</b>, através dos sites (principal e contingência) do Executante, bem como transporte para a troca física de documentos nas instalações dos 
            participantes do SILOC ou seus representantes; 
        </ul>
        <ul>
            Ambiente de Homologação composto por equipe técnica, servidores, softwares e links de comunicação, para realizar a troca de arquivos de testes durante o período do Exercício 
            de Homologação do <b>CLIENTE PARTICIPANTE</b> do SILOC junto à <b>CIP</b> e quando ocorrer fases de validação de novos processos que forem estabelecidos pelo SILOC;   
        </ul>
    </p>

";

$texto[11] =
"
    <p><b>CLÁUSULA SEXTA: DO PRAZO DE IMPLANTAÇÃO</b></p>
    <p>
        <b>6.1</b> Os serviços contemplados neste Anexo, incluindo o serviço especial do Exercício de Homologação do <b>CLIENTE PARTICIPANTE</b> do SILOC junto à <b>CIP</b>, poderão ser iniciados pela 
        <b>CONTRATADA</b> no prazo de até 20 (vinte) dias úteis, a contar da assinatura do instrumento contratual pelas partes.
    </p>

    <p><b>CLÁUSULA SÉTIMA: DO EQUIPAMENTO E SOFTWARE</b></p>
    <p>
        <b>7.1.</b> O <b>CLIENTE</b> não terá qualquer direito à propriedade de qualquer equipamento fornecido pela ou através da <b>C&M SOFTWARE</b>, a não ser que tal equipamento tenha sido adquirido 
        pelo <b>CLIENTE</b>, mediante assinatura do competente Contrato de Compra e Venda. 
    </p>
    <p>
        <b>7.2.</b> O <b>CLIENTE</b> é responsável pela instalação, operação ou manutenção do equipamento na propriedade do <b>CLIENTE</b> ou por outro equipamento ou software (a incluir sem limitação, 
        o cabeamento) não fornecidos pela <b>C&M SOFTWARE</b> (coletivamente, “equipamento ou software não C&M”).
    </p>
    <p>
        <b>7.3.</b> O Direito de Propriedade Intelectual dos softwares fornecidos pela <b>C&M SOFTWARE</b> para os fins deste contrato, a ela está assegurado.
    </p>
    <p><b>CLÁUSULA OITAVA: DO SUPORTE TÉCNICO</b></p>
    <p>
        <b.8.1.</b> O suporte técnico ao SPB Open Banking Edition - OBE será prestado pela <b>C&M SOFTWARE</b> ou terceiros por ela credenciados via telefone (+55 11 3365-2666) ou correio 
        eletrônico (suporte@cmsw.com.br), sem custos adicionais para o <b>CLIENTE</b>, nas seguintes condições:
    </p>
    <p>
        <b>8.1.1.</b> O Suporte Operacional da <b>C&M SOFTWARE</b>, responsável direto pela disponibilidade do produto, bem como por responder a questionamentos iniciais, poderá ser acessado 
        07 (sete) dias por semana, 24 (vinte e quatro) horas por dia, 365 (trezentos e sessenta e cinco) dias por ano (7x24x365).
    </p>
";

$texto[12] =
"
    <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>
                <td class='td_cabecalho' style='text-align:center;border-top:2px solid;border-bottom:2px solid;'>
                    <small><b>ANEXO – TABELA DE PREÇOS</b></small>
                </td>
            </tr>
        </tbody>
    </table>
    <p>
        <b>CLÁUSULA PRIMEIRA:</b> Pelo licenciamento de uso do software <b>SPB Open Banking Edition - OBE</b> serão cobrados os preços, por mensagem processada, nos termos a seguir:
    </p>    
    <p>
        <b>1.1.</b>	O valor da Implantação é de **--IMPLANTACAO--** **--IMPLANTACAO/EXTENSO--**, que será pago incluir as condições de pagamento, parcelas, prazos e datas da emissão 
        da assinatura do contrato ou emissão da nota fiscal
    </p>
    <p>
        <b>1.2.</b>	Caso necessitem de auxílio durante as integrações só poderão contratar pacotes múltiplos de <b>10hs</b> no valor de <b>**--HORA_HOMEM--**</b>. Contratação mínima de pacote de 10 
        horas, sendo o primeiro pacote contratado obrigatoriamente no ato da assinatura do contrato e as demais de acordo com a necessidade do cliente. Contabilização sempre 
        homem/hora cheia. Exemplo: se o tempo demandado for de 30 minutos, será tarifado uma hora cheia e debitada do banco de horas. O saldo das horas será expirado sem ressarcimento 
        na entrada em produção do SPBx OBE.
    </p>
    <p>
        <b>1.3.</b>	Por exigência fiscal, os valores dos serviços de Assessoria Técnica ou BACEN e Adequações do Projeto, quando cabíveis, serão faturados por <b>C&M SOFTWARE E 
        CONSULTORIA LTDA., C.N.P.J. nº 14.289.105/0001-04</b>;
    </p>
    <p>
        <b>1.4.</b>	O faturamento mínimo mensal é de <b>**--VALOR_PACOTE_SPB--**</b> <b>**--VALOR_PACOTE_SPB_EXTENSO--**</b> mensais, contemplando         
        <b>**--TRANSACOES_PACOTE_SPB--**</b> <b>**--TRANSACOES_PACOTE_SPB_EXTENSO--**</b> mensagens.
    </p>
    <p>
        <b>1.5.</b>	Para o quantitativo de mensagens excedentes serão aplicados, progressivamente, os preços da demais faixas de forma escalonada, até atingir o volume total de 
        consultas.
    </p>
    <p>
        <b>1.6.</b>	O valor total mensal será calculado pela somatória do valor mínimo mensal previsto no item “b.1” acima, acrescido do valor resultante das mensagens excedentes.
    </p>
    <p>
        <b>1.7.</b>	A não utilização pelo <b>CLIENTE</b> de qualquer funcionalidade do Software <b>SPB Open Banking Edition - OBE</b>, bem como a não utilização das mensagens 
        contempladas no faturamento mínimo mensal, não gerará ao <b>CLIENTE</b> nenhum crédito e/ou desconto, pois toda infraestrutura do Software estará mensalmente disponibilizada ao 
        <b>CLIENTE</b> desde a assinatura do presente Contrato.
    </p>
    <p>
        <b>1.8.</b>	A não utilização integral das mensagens contempladas no faturamento mínimo mensal não serão transferidas para o mês seguinte, sendo zeradas a cada período de 
        cobrança mensal e não se compensarão com eventual utilização excedente em mês(es) futuro(s).
        <br>
        Em face do tipo de contratação (licenciamento de software), os valores mensais não estão sujeitos a cálculos “pro rata die”.
        <ul>
            Os valores não contemplam tributos e serão acrescidos quando da emissão da Nota Fiscal/Fatura.
        </ul>
    </p>
    <p><b>CLÁUSULA SEGUNDA. – PREÇOS</b></p>
    <p>        
        <b> Registro e Baixa COMPE - **--BAIXA_COMPE--** </b>  
        <ul> 
            Conversão CIP e DDA para COB605
        </ul>
        <ul>
            Criptografia e Conexão com a COMPE
        </ul>
    <p>
        <b> Serviços Open Banking (TED/Boleto etc...) </b>
        <ul>
            TRX – WebService Tokenizado **--WEBSERVICE--**
        </ul>
        <ul>
            TRX – Lote/Arquivo Tokenizado **--LOTE_ARQUIVO--**
        </ul>
    </p>
";

$texto[13] =
"
    
    <p>    
        <b>TRATAMENTO DE INCONSISTÊNCIA: **--TRATAMENTO_INCONSISTENCIA--**</b>
    </p>
    <p>
        <b>Tabela Mensagens SPB Open Banking Edition - OBE : Faturamento mínimo mensal se iniciará após a entrada do produto em produção.</b>
    </p>
    **--TABLE--**

";

$texto[14] =
"
    <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>
                <td class='td_cabecalho' style='text-align:center;border-top:2px solid;border-bottom:2px solid;'>
                    <small><b>ANEXO - SISTEMA DA PAGAMENTOS INSTANTÂNEOS – SPI/x.</b></small>
                </td>
            </tr>
        </tbody>
    </table>
    <p>
        O objetivo do presente anexo é estabelecer procedimentos exclusivos para o Licenciamento de uso do Software do Sistema de Pagamentos Instantâneo - <b>SPI/x</b>, em caráter temporário 
        e intransferível, nos termos e condições aqui avençadas, viabilizando ao <b>CLIENTE</b> a operação diretamente nos Sistemas de Liquidação do Banco Central do Brasil, conforme 
        regulamentação em vigor.
        <br>
        <b>RESOLVEM</b> as partes, por estarem de comum acordo e pactuadas, firmar o presente Contrato de Licenciamento ao Sistema de Pagamentos Instantâneos (SPI/x), sendo este, ANEXO 
        indissociável do <b>Contrato de Licenciamento de Uso do Software Produtos de Liquidação BACEN (PL-BACEN)</b>. que se regerá pelas cláusulas e condições a seguir:
    </p>
    <p>
        <b>CLÁUSULA PRIMEIRA: CONDIÇÕES GERAIS</b>
    </p>  
    <p>
        <b>1.</b> Destina-se o presente instrumento a integrar o <b>CLIENTE</b> com a finalidade de atender o Comunicado nº 32.927 de 21 de dezembro de 2018 (e subsequentes correlatos), 
        que dispõem sobre o novo ecossistema de pagamentos brasileiros, Pagamentos Instantâneos, ora identificado como como SPI/x.
    </p>
    <p>
        <b>2.</b> A <b>C&M SOFTWARE</b>, com a assinatura do presente termo estende-se, integralmente, as responsabilidades das partes pactuadas no contrato principal também ao 
        SPI/x, além das novas regulamentações a serem publicadas pelo BACEN também fazerem parte ao presente de maneira inconteste.
    </p>
    <p>
        <b>3.</b> Com vistas a promover uma melhor precificação e utilização da infraestrutura alocada para a execução do produto ora licenciado, a C&M Software concede ao CLIENTE, 
        a tabela abaixo a ser aplicada como forma redutora de preços com base no horário de execução da transação associada
    </p>
    <ul>
        Valor Integral da transação a Crédito do <b>CLIENTE</b> (conforme cláusula <b>2.3.</b>)           
    </ul>
    <ul>  
        Valor Integral da transação a Débito do <b>CLIENTE</b> (conforme cláusula <b>2.3.</b>)
    </ul>
    
        Desconto por transações trafegada nos seguintes horários:
        <table style='border:thin solid 1px;'>
            <thead>  
                <tr>
                    <th style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;background-color:#c25647;color:rgb(255, 255, 255);'><small><b>TIPO / HORÁRIO</b></small></th>";
                    foreach ($this->dicionario['TEXTO_SLIDE']['FULL']['TABLE_FULL']['HORARIO'] as $key => $value) {
                        $texto[14] .= 
                        "                 
                            <th  style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;background-color:#c25647;color:rgb(255, 255, 255);'><small><b>".$value."</b></small></th>                              
                        ";
                    }
        $texto[14] .="    
                </tr>
            </thead>
                <tbody>
                    <tr>
                        <th style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;background-color:#c25647;color:rgb(255, 255, 255);'><small><b>CREDITO CLIENTE</b></small></th>";
                        foreach ($this->dicionario['TEXTO_SLIDE']['FULL']['TABLE_FULL']['HORARIO'] as $key => $value) {
                            $texto[14] .= 
                            "                 
                                <td style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;'><small>".$this->dicionario['TEXTO_SLIDE']['FULL']['TABLE_FULL'][$value]['CREDITO']."</small></td>                              
                            ";
                        }
                    $texto[14] .= 
                    "</tr>
                        <tr>
                            <th style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;background-color:#c25647;color:rgb(255, 255, 255);'> <small><b>DEBITO DO CLIENTE</b></small></th>";
                        foreach ($this->dicionario['TEXTO_SLIDE']['FULL']['TABLE_FULL']['HORARIO'] as $key => $value) {
                            $texto[14] .= 
                            "                 
                                <td style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;'><small>"
                                    .$this->dicionario['TEXTO_SLIDE']['FULL']['TABLE_FULL'][$value]['DEBITO'].
                                "</small></td>                              
                            ";
                        }
                    $texto[14] .= "</tr>
            <thead>
        </table>   
        <ul>     
            <b>Paragrafo Primeiro.</b> Entenda-se: Transações a crédito do <b>CLIENTE</b>, são as que resultam em crédito na Conta do <b>CLIENTE</b> junto ao BACEN, e, respectivamente, 
            transações a débito <b>CLIENTE</b>, são aquelas que resultam em débito na Conta do <b>CLIENTE</b> junto ao BACEN.
        </ul>
        <ul>
            <b>Paragrafo Segundo.</b> A apuração do uso será mensal, respeitando as datas de corte e datas de faturamento pactuados no contrato principal e/ou seus anexos anteriores.
        </ul>
        <ul>        
            <b>Paragrafo terceiro.</b> A presente tarifação somente ocorrerá quando do ingresso em produção junto ao BACEN do SPI/x. Não ocorrerá qualquer cobrança no período de testes 
            e homologação, seguindo as datas de faturamento pactuada no contrato ora aditado.  
        </ul>
    
    <p>
        <b>4.</b> Somente serão tarifadas/faturadas mensagens que de alguma maneira afetem o saldo do <b>CLIENTE</b> junto ao BACEN tanto a crédito quanto a débito, respeitando a política da 
        Clausula Primeira item 3.     
    </p>
    <p>
        <b>5.</b> Como o BACEN criou a instituição PSTI SWITCH, que terá operações similares a uma CLEARING HOUSE entre os clientes do PSTI, fica intrínseco que, a divulgação do 
        <b>CLIENTE</b> como participante do PSTI C&M Software é necessária a fim de habilitar tal recurso especificado pelo BACEN no SPI/x, sem que se explore publicitariamente as 
        marcas envolvidas.    
    </p>
    <p> 
        <b>CLÁUSULA SEGUNDA: VIGÊNCIA, PREÇOS E CONDIÇÕES:</b>
    </p>    
    <p>
        <b>2.1.</b> O valor da Implantação é de **--IMPLANTACAO--** **--IMPLANTACAO/EXTENSO--**, que será pago inserir condições de pagamento, número de 
        parcelas, prazo e datas.
    </p>
";

$texto[15] =
"
    <p>
        <b>2.2.</b> Os valores das transações seguem as condições abaixo: 
    </p>
    <ul>
    	Valor Integral da transação a Crédito do CLIENTE = **--CREDITO_CLIENTE--**
    </ul>
    <ul>
        Valor Integral da transação a Débito do CLIENTE = **--DEBITO_CLIENTE--**
    </ul>
    <ul>
    	Os valores não contemplam tributos e serão acrescidos quando da emissão da Nota Fiscal/Fatura.
    </ul>
    <p>
        <b>2.3.</b> Para fins de suporte ao investimento realizado pela <b>C&M SOFTWARE</b>, as partes concordam que, sob nenhum aspecto, venham a rescindir o presente instrumento por, 
        no mínimo, o primeiro período contratado, a contar da data da assinatura do presente instrumento.
    </p>
    <p><b>CLÁUSULA TERCEIRA: DOS REQUISITOS TÉCNICOS E SUPORTE DO SPI/x </b></p>
    <p>
        <b>3.1.</b> Pelos serviços de Implantação a <b>C&M SOFTWARE</b> configurará os sistemas que compõem a solução SPI/x, compreendendo os ambientes de Homologação e Produção, contemplando os 
        seguintes serviços:
    </p>
    <p>
        <b>3.1.1.</b> A Implantação contempla, ainda, o treinamento ao <b>SPI/x</b> concedido pela <b>C&M SOFTWARE</b> ou terceiros por ela credenciados, nas instalações físicas da <b>C&M SOFTWARE</b>, 
        do CLIENTE, ou outro local indicado por este, de até 3 (três) profissionais da <b>CONTRATANTE</b> na utilização do software ora contratado, conforme abaixo descrito:
    </p>
    <ul>    
        Treinamento Mensageria: Consiste no treinamento na utilização do Sistema C&M Message Router;
    </ul>
    <ul>
        Treinamento Piloto de Reserva: Consiste no treinamento da utilização do C&M Piloto de Reserva e suas funcionalidades desenvolvidas até a data do treinamento; e,
    </ul>
    <ul>
        Treinamento Piloto de Reserva Configurações: Consiste no treinamento do C&M Piloto de Reserva aplicável somente as condições de filtragem disponível nas funcionalidades 
        desenvolvidas até a data do treinamento.
    </ul>
    
    <p>
        <b>3.1.2.</b> O treinamento deverá ser solicitado pelo <b>CLIENTE</b>, com um prazo mínimo de 30 (trinta) dias de antecedência, sendo que, caso o local escolhido seja fora 
        da região metropolitana da cidade de São Paulo, as despesas com transportes, hospedagem e alimentação dos instrutores, serão de responsabilidade exclusiva do <b>CLIENTE</b>.
    </p>
    <p>
        <b>3.2.</b> A licença de uso do SPI/x contempla: 
    </p>
    <ul>
        Licença de Uso C&M Message Router: Utilização do Sistema de Mensageria da <b>C&M SOFTWARE</b>;
    </ul>
    <ul>
        Licença de Uso C&M Piloto de Reserva: Utilização do Sistema de Gerenciamento de Conta Reserva de propriedade da <b>C&M SOFTWARE</b>;
    </ul>
    <ul>
        Licença de Uso C&M Suite Package Security: Módulo de Cifragem que compõe a Solução; e,
    </ul>
    <ul>
        Acesso a RSFN: Acessos aos serviços da <b>C&M SOFTWARE</b> na RSFN, através de seus links próprios.
    </ul>
    <p>
        <b>3.3.</b> Manter a disponibilidade mínima de operacionalidade de 99,8% (noventa e nova inteiros e oito centésimos por cento), por 7 (sete) dias na semana e 
        24 (vinte e quatro) horas no dia e 365 (trezentos e sessenta e cinco dias) por ano.
    </p>
    <p>
        <b>3.3.1.</b> Não serão considerados para cálculo de nível de operacionalidade os seguintes casos:
    </p>
    <ul>
        execução de manutenção, comunicada pela <b>C&M SOFTWARE</b> com mínimo de 15 (quinze) dias de antecedência;
    </ul>
    <ul>
        operação inadequada do software e dos equipamentos pelo <b>CLIENTE</b>, em desacordo com as instruções da <b>C&M SOFTWARE</b>;
    </ul>
    <ul>
        falhas ocasionadas em relação à infraestrutura do <b>CLIENTE</b> ou de seus clientes finais.
    </ul>
    <ul>
        quando, por qualquer motivo, o <b>CLIENTE</b> impedir o acesso da <b>C&M SOFTWARE</b> onde estejam localizados seus equipamentos ou os por ela mantidos, postergando assim o 
        restabelecimento da operação.
    </ul>
    <p>
        <b>3.5.</b> O <b>CLIENTE</b> tem conhecimento que toda a comunicação por intermédio da rede mundial de computadores (internet) está sujeita a interrupções e/ou atrasos, 
        podendo ocorrer problemas de transmissão ou de recepção das informações acessadas.
    </p>
    <p>
        <b>CLÁUSULA QUARTA: DAS OBRIGAÇÕES DA C&M SOFTWARE</b>
    </p>
    <p>
        <b>4.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, a <b>C&M SOFTWARE</b> obriga-se a: 
    </p>
";

$texto[16] =
"
    <p>
        <b>4.1.1.</b> Manter e atualizar seus Sistemas que compõem a solução SPI/x, Ambiente de Homologação e Produção, conforme abaixo:
    </p>
    <ul>
        MQ-Series, manter atualizado com o padrão estipulado pelo Banco Central do Brasil e as Câmaras que participam do Sistema;
    </ul>
    <ul>
        Mensageria, sempre atualizada com a última versão do “book” de Mensagens e DTD padronizadas pelo Banco Central do Brasil e as Câmaras que participam do Sistema;
    </ul>
    <ul>
        Módulo de Segurança, manter atualizado com a última versão divulgada pelo Banco Central do Brasil;
    </ul>
    <ul>
        Piloto de Reservas, manter compatível com o todo do Sistema SPB, segundo especificações do Banco Central do Brasil.
    </ul>
    <p>
        <b>4.1.2.</b> Manter o histórico de mensagens dos últimos 02 (dois) meses, mais o mês corrente disponíveis para acesso online. A base histórica anterior a esse período 
        deverá ser guardada pelo <b>CLIENTE</b>.
    </p>
    <p>
        <b>4.1.2.1.</b> Mensalmente a <b>C&M SOFTWARE</b> disponibilizará ao <b>CLIENTE</b> gerará um arquivo .ZIP em um site FTP com a base anterior ao mês corrente para guarda do 
        <b>CLIENTE</b>.
    </p>
    <p>
        <b>4.1.4.2.</b> Fornecerá também um software, durante a vigência deste Contrato, para visualização das mensagens conforme padrão exigido pelo Banco Central do Brasil, 
        convencionado no documento “Manual de Segurança de Mensagens do SPI/x”, capítulo que trata da manutenção e guarda dos registros para fins de auditoria.
    </p>
    <p>
        <b>4.1.3.</b> Manter toda a estrutura de suporte e investimentos para homologação do Sistema continuamente.
    </p>
    <p>
        <b>CLÁUSULA QUINTA: DAS OBRIGAÇÕES DO CLIENTE</b>
    </p>
    <p>
        <b>5.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, o <b>CLIENTE</b> obriga-se a: 
    </p>
    <p>
        <b>5.1.1.</b> Fornecer, por escrito, todos os dados técnicos que vierem a ser solicitados pela <b>C&M SOFTWARE</b>, necessários para a elaboração do Projeto e execução do 
        Contrato. 
    </p>
    <p>    
        <b>5.1.2.</b> Fornecer, durante a execução da Implantação, sem ônus para a <b>C&M SOFTWARE</b>, recursos telefônicos e de fac-símile para comunicação, bem como facilidades 
        para fotocópias de documentos. 
    </p>
    <p>
        <b>5.1.3.</b> Fornecer todos os dados técnicos necessários à disponibilização do acesso da <b>C&M SOFTWARE</b>, através dos seus links próprios, à RSFN.
    </p>
    <p>
        <b>5.1.4.</b> Abster-se de reparar, modificar, ou mesmo adicionar novos componentes ou conexões, ou fazer alterações e/ou mudanças de qualquer tipo nas Estações de 
        Telecomunicações, sem prévia autorização por escrito por parte da <b>C&M SOFTWARE</b>.
    </p>
    <p>
        <b>5.2.</b> O <b>CLIENTE</b> reconhece, diante dos vultosos investimentos em andamento, que os domínios primários para processamento do sistema, objeto deste anexo, deve, 
        durante toda a sua vigência, ficar sob total domínio do <b>PSTI C&M Software</b> e o direcionamento e cadastramentos junto ao <b>BACEN</b> serem indicados, exclusivamente, para o 
        <b>PSTI C&M Software</b>, que terá completo poder de gestão da <b>C&M SOFTWARE</b>, vez que controla estas terminações nos ambientes de homologação, produção e contingência, sendo que 
        as alteração não concordadas acarretarão em estimativa de perdas e danos e lucros cessantes baseado no volume de transações tarifáveis a que este contrato regula, a ser definido.
    </p>
    <p>
        <b>CLÁUSULA SEXTA: DO EQUIPAMENTO E SOFTWARE</b>
    </p>
    <p>
        <b>6.1.</b> O <b>CLIENTE</b> não terá qualquer direito à propriedade de qualquer equipamento fornecido pela ou através da <b>C&M SOFTWARE</b>, a não ser que tal equipamento 
        tenha sido adquirido pelo <b>CLIENTE</b>, mediante assinatura do competente Contrato de Compra e Venda. 
    </p>
    <p>
        <b>6.2.</b> O <b>CLIENTE</b> é responsável pela instalação, operação ou manutenção do equipamento na propriedade do <b>CLIENTE</b> ou por outro equipamento ou software 
        (a incluir sem limitação, o cabeamento) não fornecidos pela <b>C&M SOFTWARE</b> (coletivamente, “equipamento ou software não C&M”).
    </p>
    <p>
        <b>6.3.</b> O Direito de Propriedade Intelectual dos softwares fornecidos pela <b>C&M SOFTWARE</b> para os fins deste contrato, a ela está assegurado.
    </p>  
    <p><b>CLÁUSULA SÉTIMA: DO SUPORTE TÉCNICO</b></p>
    <p>
        <b>7.1.</b> O suporte técnico ao SPI/x será prestado pela <b>C&M SOFTWARE</b> ou terceiros por ela credenciados via telefone (+55 11 3365-2666) ou correio eletrônico 
        (suporte@cmsw.com.br) sem custos adicionais para o CLIENTE, nas seguintes condições:
    </p>
    <p>
        <b>7.2.</b> O Suporte Operacional da <b>C&M SOFTWARE</b>, responsável direto pela disponibilidade do produto, bem como por responder a questionamentos iniciais, poderá ser 
        acessado 07 (sete) dias por semana, 24 (vinte e quatro) horas por dia, 365 (trezentos e sessenta e cinco) dias por ano (7x24x365).
    </p>  
";

?>