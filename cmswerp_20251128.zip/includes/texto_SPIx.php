<?php
setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
$data_extenso = strftime('%d de %B de %Y', strtotime('today'));
$texto[0] =
"
    À<br> 
    <b> **--CLIENTE--** </b> <br>
    **--ENDERECO--** - **--BAIRRO--** <br> 
    **--CEP--** - **--CIDADE--** - **--UF--** <br> 
    <br> 
    <b> A/C.: **--REPRESENTANTE_LEGAL--** </b> 
    <br></br> 
   
    Assunto: Contrato de Licenciamento de Uso do Software Produtos de Liquidação BACEN (PL-BACEN). 
    <br></br> 
    Prezado Senhor,
    <br>   

    <p>Primeiramente manifestamos nossos sinceros agradecimentos pela contratação do nosso software, e lhes damos Boas-Vindas à família C&M Software.</p>
    <p>
        Encaminhamos em anexo o Contrato de Licenciamento de Uso do Software do sistema <b>PL-BACEN:SPI/x</b> que será assinado na <b>Plataforma de Assinaturas</b> da <b>D4Sign</b>
        (especializada em identificação digital), com plena validade jurídica. As assinaturas das pessoas jurídicas da Contratante e Contratada serão realizadas com a 
        utilização de Certificado Digital <b>e-CNPJ</b>.
    </p>
    <p>
        As testemunhas assinarão eletronicamente (sem a necessidade de Certificado Digital), de acordo com as formas de comprovação de autoria e integridade de documentos realizadas 
        pela Plataforma de Assinaturas da <b>D4Sign</b>. O passo-a-passo será encaminhado por <b>e-mail</b>. 
    </p>    
    <p>
        No caso da assinatura convencional, segue o “Contrato de Licenciamento dos Produtos PL-BACEN”. Necessário seja assinado em <b>02 (duas) vias</b> e entregue no endereço:
    </p>
    

    <b>**--CM_SOFTWARE--**</b>
    <br> A/C: Departamento Jurídico.
    <br> Alameda Rio Pardo, nº 27 - Alphaville Industrial.
    <br> 06455-005 – Barueri – SP. 

    <br> Os documentos que devem acompanhar o contrato são:
    
    <ul> Cópia simples do Contrato Social/Estatuto Social, bem como a última alteração/ata de assembleia; </ul>
    <ul> Cartão do CNPJ; </ul>
    <ul> Cópia simples do RG e CPF do signatário do Contrato; e, </ul>
    <ul> Se o signatário não constar do Contrato Social/Estatuto Social, solicitamos cópia da procuração que lhe outorgou poderes. </ul>
    
    <br>
    Quaisquer dúvidas podem ser esclarecidas através do e-mail juridico@cmsw.com, ou pelo telefone (11) 3365-2666.
    <br></br><br></br><br></br><br>
    Atenciosamente,
    <br></br><br>
    <table>
        <thead>
            <th style='text-align:center; width:800px;' >               
                <small>
                    **--CM_SOFTWARE--**
                    <br>Departamento Jurídico 
                </small>                               
            </th>
        </thead>
    </table>
";

$texto[1] = 
"
    <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>
                <td style='text-align:center;border-bottom:2px solid;'>
                    <h3>Produtos de Liquidação BACEN (PL-BACEN)</h3>                        
                </td>
            </tr>
        </tbody>
    </table>

    <table cellpadding='1' cellspacing='4' style='width:100%'> 
        <tbody>
            <tr>
                <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'><b><small>QUADRO RESUMO</small></b></td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>
                    <b><small>CONTRATADA</small></b>
                    <br></br>
                    <p>
                        <b> **--CM_SOFTWARE--** </b>, pessoa jurídica de direito privado com sede na Alameda Rio Pardo, nº 27, 
                        Bairro Alphaville Industrial, no município de Barueri, Estado de São Paulo, CEP 06455-005, inscrita no CNPJ/MF sob o 
                        nº <b> **--CM_SOFTWARE_CNPJ--** </b>, doravante denominada simplesmente “<b>C&M SOFTWARE</b>”;
                    </p>
                    <br>
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>
                    <b><small>CONTRATANTE</small></b>
                    <br></br>
                    <p>
                        <b> **--CLIENTE--** </b>, pessoa jurídica de direito privado com endereço **--ENDERECO--** - **--BAIRRO--**, na cidade de **--CIDADE--**, Estado de **--UF--**, 
                        CEP **--CEP--**, inscrita no C.N.P.J. nº **--CNPJ--**, neste ato representada na forma de seus atos constitutivos por 
                        <b>**--REPRESENTANTE_LEGAL--**</b>, **--REPRESENTANTE_LEGAL/CARGO--**, C.P.F. nº **--REPRESENTANTE_LEGAL/CPF--** , e-mail: **--REPRESENTANTE_LEGAL/EMAIL--**, 
                        telefone: **--REPRESENTANTE_LEGAL/TELEFONE--** **--REPRESENTANTE_2--** doravante denominada simplesmente <b>“CLIENTE”</b>.
                    </p>                        
                    <br>
                        <ul>CONTATO RESPONSÁVEL: **--CONTATO_RESPONSAVEL--** - e-mail: **--CONTATO_RESPONSAVEL/EMAIL--** - telefone: **--CONTATO_RESPONSAVEL/TELEFONE--** </ul>               
                        <ul>FINANCEIRO: **--CONTATO_FINANCEIRO--** - e-mail: **--CONTATO_FINANCEIRO/EMAIL--** - telefone: **--CONTATO_FINANCEIRO/TELEFONE--** </ul>
                        **--CONTATO_FINANCEIRO_2--**
                    <br>
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>   
                    <b><small>OBJETO DO CONTRATO</small></b>                                        
                    <p>
                        <br>
                        O objeto deste Contrato é o Licenciamento de uso do Software SPI/x, em caráter temporário e intransferível, nos termos e condições aqui avençadas, 
                        viabilizando ao <b>CLIENTE</b> a operação diretamente nos Sistemas de Liquidação do Banco Central do Brasil, conforme regulamentação.
                    </p>
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>   
                    <b><small>PRAZO DE VIGÊNCIA</small></b>                            
                    <p>
                        <br>
                        O presente Contrato, vigorará pelo prazo determinado de <b> **--VIGENCIA_CONTRATO--** **--VIGENCIA_CONTRATO/EXTENSO--** </b>, contados a partir da data de assinatura digital, 
                        conforme termos da <b>MEDIDA PROVISÓRIA No 2.200-2, DE 24 DE AGOSTO DE 2001.</b>, ou da forma convencional de assinatura e não poderá ser rescindido antecipadamente, por 
                        qualquer das partes, sem justo motivo, sob pena de aplicação automática de multa compensatória e prefixação de perdas e danos equivalente a 60% (sessenta) do valor 
                        da média do faturamento mensal dos últimos 12 meses, devidamente reajustadas, multiplicado pelo número de meses restantes para a conclusão do prazo 
                        integral, com a finalidade de recompor a <b>C&M SOFTWARE</b> pelos prejuízos decorrentes da rescisão antecipada e injustificada, posto que a <b>C&M SOFTWARE</b> realizou 
                        o gerenciamento e planejamento de custos, infraestrutura de equipamentos e softwares, equipes técnicas de suporte, manutenção e desenvolvimento, etc., com 
                        vistas ao cumprimento das obrigações contratuais no prazo contratado entre as Partes.                    
                    </p>
                   
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                    <b><small>PREÇO</small></b>                 
                    <p>
                        <br>
                        <b>1.</b> O valor da Implantação, assessoria e as condições comerciais de uso estão descritos no anexo específico para o sistema contratado a ser integrado 
                        ao Banco Central do Brasil.                            
                    </p>
                    <p>
                        <b>2.</b> Pelo licenciamento de uso do software PL-BACEN serão cobrados os preços, por mensagem processada, conforme Tabela de Preços disposta no anexo 
                        específico do presente Contrato.
                    </p>
                    <p>
                        <b>3.</b> Os valores não contemplam tributos e serão acrescidos quando da emissão da Nota Fiscal/Fatura.                       
                    </p>                             
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>   
                    <b><small>RENOVAÇÃO DO CONTRATO</small></b>                     
                    <p> 
                        <br>
                        Caso não haja manifestação por nenhuma das partes com antecedência mínima de 120 (cento e vinte) dias do vencimento do Contrato, esse prorrogar-se-á automaticamente
                        por igual período e assim sucessivamente por iguais períodos, não podendo ser rescindido, antecipadamente, por qualquer das partes, sem justo motivo, sob pena de 
                        aplicação automática de compensatória e prefixação de perdas e danos equivalente a 60% (sessenta) do valor da média do faturamento mensal dos últimos 12 meses, 
                        devidamente reajustadas, multiplicado pelo número de meses restantes para a conclusão do prazo integral, com a finalidade de recompor a <b>C&M SOFTWARE</b> pelos prejuízos 
                        decorrentes da rescisão antecipada e injustificada, posto que a <b>C&M SOFTWARE</b> realizou o gerenciamento e planejamento de custos, infraestrutura de equipamentos e 
                        softwares, equipes técnicas de suporte, manutenção e desenvolvimento, etc., com vistas ao cumprimento das obrigações contratuais no prazo contratado entre as Partes.
                    </p>
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>   
                    <b><small>REAJUSTE CONTRATUAL</small></b>                     
                    <p> 
                        <br>
                        A cada 12 (doze) meses pelo **--INDICE_REAJUSTE--**, ou qualquer outro índice que venha a substituí-lo, a contar da data de assinatura do presente Contrato. 
                    </p>
                </td>
            </tr>            
        </tbody>
    </table> 
";

$texto[2] =
"    
    <table cellpadding='1' cellspacing='4' style='width:100%'> 
        <tbody>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                    <b><small>FATURAMENTO </small></b>                    
                    <p>
                        <br>
                        Salvo o valor da implantação que segue sistemática própria, todos os faturamentos terão datas de cortes para aferição todo o dia <b> **--CORTE_FATURAMENTO--** 
                        **--CORTE_FATURAMENTO/EXTENSO--** de cada mês</b>, com prazo de pagamento <b> **--PRAZO_PAGAMENTO--** **--PRAZO_PAGAMENTO/EXTENSO--**</b> dias contados da apresentação da nota fiscal/fatura, ocorrendo o primeiro 
                        faturamento <b> 19 (dezenove) </b>, independentemente da conclusão da implantação e do uso.
                    </p>
                    <br>
                </td>
            </tr>    
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                    <b><small>TAXA POR INATIVIDADE</small></b>                    
                    <p>
                        <br>
                        Após o prazo de 90 (noventa) dias contados da assinatura digital do presente contrato, sempre que o faturamento mensal for igual a R$ 0,00 (zero), ou seja, 
                        sempre que não existir valores a faturar, o <b>CLIENTE</b> está ciente que haverá o faturamento automático do valor de R$ 3.500.00 (três mil e quinhentos reais), 
                        referente a taxa por inatividade, para custear investimentos realizados pela <b>C&M SOFTWARE</b> para manutenção do ambiente e atualização dos produtos de hardware 
                        e software que dão origem ao presente contrato.
                    </p>
                    <p>
                        O faturamento da taxa por inatividade será realizado conforme previsto no item VIII) DO FATURAMENTO.
                    </p>
                    <br>
                </td>
            </tr>        
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>
                    <b><small>DIVULGAÇÃO</small></b>
                    <p>
                        <br>
                        O <b>CLIENTE</b>, desde já, autoriza a <b>C&M SOFTWARE</b> a incluir o seu nome na sua lista de clientes, assim como sua divulgação, pelos meios de comunicação próprios, juntamente
                        com os nomes de outros clientes, mas não revelará, comunicará ou de qualquer forma fará propaganda a qualquer terceiro de detalhes deste Contrato.
                    </p>              
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>
                    <b><small>FORO</small></b>                    
                    <p>
                        <br>
                        Fica eleito o foro da comarca de Barueri do Estado de São Paulo para dirimir quaisquer questões advindas deste Instrumento, renunciando as partes a qualquer outro,
                        por mais privilegiado que seja.
                    </p>              
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>                       
                    <b><small>TESTEMUNHAS:</small></b>                  
                    <p>
                        <br>
                        Nome: **--TESTEMUNHA_CMSW--** da C&M C.P.F. nº **--TESTEMUNHA_CMSW/CPF--** e-mail: **--TESTEMUNHA_CMSW/EMAIL--** 
                        <br>
                        Nome: **--TESTEMUNHA--** C.P.F. nº **--TESTEMUNHA_CPF--** e-mail: **--TESTEMUNHA_EMAIL--** 
                    </p>
                </td>
            </tr>
        </tbody>
    </table>    
    <br>     
";

$texto[3] = 
"   
    <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>
                <td class='td_cabecalho' style='text-align:center;border-top:2px solid;border-bottom:2px solid;'>
                    <small><b>INSTRUMENTO PARTICULAR DE CONTRATO DE LICENCIAMENTO DOS SOFTWARES de PRODUTOS DE LIQUIDAÇÃO BACEN – PL-BACEN</b></small>
                </td>
            </tr>
        </tbody>
    </table>

    
    <p><b>CLÁUSULA PRIMEIRA: OBJETO</b></p>    
    <p> 
        <b>1.1.</b> O objeto do presente Contrato é o licenciamento de uso do software, de forma não exclusiva, intransferível e temporária, nos termos e condições aqui avençadas, 
        viabilizando ao <b>CLIENTE</b> a operação diretamente nos Sistemas de Liquidação do Banco Central do Brasil, conforme regulamentação em vigor.
    </p>   
    <p>
        <b>1.2.</b> Todos os novos produtos/módulos ou funcionalidades, criados pela <b>C&M SOFTWARE</b> e disponibilizados na plataforma dos softwares <b>PL-BACEN</b>, serão informados ao <b>CLIENTE</b>.
        A opção, pelo <b>CLIENTE</b>, pelos novos produtos/módulos ou funcionalidades ocorrerá na primeira utilização, servindo para todo e qualquer efeito de direito, como aceitação dos 
        preços e condições disponibilizadas no Painel de Controle constante no site do produto.
    </p>
    <p>
        <b>1.3.</b> Este Contrato é composto pelos anexos e políticas abaixo descritas e fazem parte integrante e indissociável do Contrato para todos os fins de direito:
        <menu>
            <ul> Anexo Principal – Termo do PL-BACEN:SPI/x; </ul>
            <ul> Anexo III – SISTEMA DA PAGAMENTOS INSTANTÂNEOS – SPI/x. </ul>
            <ul> (1) Declaração de Conformidade Social e Sigilo das Informações; </ul>
            <ul> (2) Política de Segurança da Informação e Cibernética; </ul>
            <ul> (3) Plano de Continuidade de Negócios; </ul> 
            <ul> (4) Propriedade Intelectual; </ul>
            <ul> (5) Código de Ética; </ul>
            <ul> (6) Política Interna LGPD – “C&M2021-01-LGPD”. </ul>   
        </menu>  
        <p> 
            <b>IMPORTANTE:</b> Os documentos referenciados de (1) a (6) estarão sempre disponíveis e atualizados no endereço: https://br.cmsw.com/politicas/
        </p>
    </p>

    <p><b>CLÁUSULA SEGUNDO: PRAZO DE VIGÊNCIA </b></p>

    <p>
        <b>2.1.</b> O presente contrato terá vigência pelo prazo estabelecido no item “DO PRAZO DE VIGÊNCIA” do Quadro Resumo.
    </p>

    <p><b>CLÁUSULA TERCEIRA: PREÇO </b></p>

    <p>
        <b>3.1.</b> Os preços são aqueles mencionados no item “V – DO PREÇO” do Quadro Resumo e deverão ser pagos à <b>C&M SOFTWARE</b> por meio de DOC, TED ou boleto bancário, 
        ou qualquer outro sistema que venha substituí-los.
    </p>   
    <p> 
        <b>3.1.1.</b> O primeiro faturamento da “Hospedagem” será integralmente cobrado, conforme valor estabelecido no item “V – DO PREÇO” do Quadro Resumo, independente das datas 
        de vencimento e início do Contrato, não sendo aplicada a forma de cobrança “pro rata die”.
    </p>
    <p>
        <b>3.2.</b> Acordam as Partes que o faturamento decorrente do presente instrumento ocorrerá na forma estabelecida no item “VIII – DO FATURAMENTO” do Quadro Resumo.
    </p>
    <p>
        <b>3.2.1.</b> A <b>C&M SOFTWARE</b> informará ao <b>CLIENTE</b> sobre a emissão do documento fiscal específico, por meio do e-mail disposto no item “II.2 – DADOS PARA FATURAMENTO” do 
        Quadro Resumo, enviando também nessa oportunidade o link para emissão da Nota Fiscal Eletrônica e respectivos boletos de pagamento, quando aplicável.
    </p>
    <p>
        <b>3.3.</b> Serão de responsabilidade do <b>CLIENTE</b> as despesas de viagens referentes ao transporte aéreo ou terrestre (quando o aéreo não for possível) e estadias ocorridas com os 
        profissionais da <b>C&M SOFTWARE</b>, sempre que houver necessidade de deslocamento da equipe da <b>C&M SOFTWARE</b>, a locais fora da região metropolitana de São Paulo/SP e Barueri/SP.
    </p>    

    <p>
        <b>3.4.</b> Como forma de manter a hegemonia dos custos, as partes elegem, desde já, o índice estabelecido no item “VII – DO REAJUSTE CONTRATUAL” do Quadro Resumo, 
        como índice de correção monetária, aplicável aos preços referidos neste Contrato.
    </p>
    <p>
        <b>3.4.1.</b> Quando aplicável e na hipótese de atraso ou ausência de publicação do índice aplicável, a <b>C&M SOFTWARE</b> emitirá as notas fiscais/faturas usando o último 
        índice publicado. Imediatamente após a publicação seguinte do referido índice, a <b>C&M SOFTWARE</b> emitirá os títulos para o pagamento e/ou ressarcimento da diferença entre 
        valor já cobrado e os valores efetivamente devidos, de acordo com o prazo de vencimento estabelecido no item “VIII – DO FATURAMENTO” do Quadro Resumo.
    </p>
    
";

$texto[4] =
"   
    <p>
        <b>3.4.2.</b> Na falta desse índice ou, se permitido por lei, ou por decisão judicial, será aplicado aos preços qualquer outro índice oficial, de variação diária, ou, se 
        inexistente, de variação mensal, calculando “pro rata die”, e que mais eficientemente elide os efeitos inflacionários da moeda corrente nacional, o qual será eleito mediante
        comum acordo entre as partes.
    </p>
    <p>
        <b>3.5.</b> Na hipótese de ocorrerem fatos ou atos que possam prejudicar o equilíbrio econômico-financeiro do Contrato, as partes envidarão seus melhores esforços para regular
        e disciplinar a situação criada, de forma a evitar qualquer perda de natureza econômica, financeira ou outra qualquer.
    </p>
    <p>
        <b>3.6.</b> Se, durante a vigência deste Contrato, forem criados tributos ou alteradas as alíquotas dos atuais, de forma a majorar ou diminuir o ônus das Partes contratantes, 
        os preços poderão ser revistos, de modo a serem ajustados a essas modificações, mediante envio de notificação por escrito da <b>C&M SOFTWARE</b> ao <b>CLIENTE</b>.
    </p>
    <p>
        <b>3.7.</b> A <b>C&M SOFTWARE</b> executará os serviços descritos neste Contrato em sua sede, ou de suas futuras filiais, as quais emitirão o correspondente documento fiscal,
        haja vista serem consideradas, individualmente, como estabelecimentos ou locais, onde a <b>C&M SOFTWARE</b> desenvolve a sua atividade principal, de modo permanente ou eventual,
         nos termos do artigo 4º da Lei Complementar nº 116, de 31/07/2003, publicada no Diário Oficial da União de 1/08/2003.
    </p>
    <p>
        <b>3.8.</b> O inadimplemento de toda e qualquer importância cobrada com base no presente Contrato, na data de seu vencimento, implicará na incidência automática de multa 
        moratória no percentual de **--PERCENTUAL_MULTA--** **--PERCENTUAL_MULTA/EXTENSO--** e juros de mora de **--PERCENTUAL_JUROS--** **--PERCENTUAL_JUROS/EXTENSO--** ao mês, encargos esses incidentes sobre o valor do débito atualizado de acordo com o índice
        estabelecido no item “VII – DO REAJUSTE CONTRATUAL” do Quadro Resumo, calculado “pro rata die” a partir da data de vencimento do respectivo documento de cobrança até a data do
        efetivo pagamento.
    </p>
    <p>
        <b>3.8.1.</b> Os mencionados juros de mora, multa moratória e atualização monetária serão cobrados automaticamente no faturamento do mês subsequente.
    </p>
    <p>
        <b>3.9.</b> O acesso ao software poderá ser suspenso, sem aviso prévio, se a inadimplência do <b>CLIENTE</b> durar mais de 10 (dez) dias, contados da data de vencimento, 
        e neste caso não será reiniciada a não ser que todos os valores devidos sejam pagos na sua totalidade, sem prejuízo do direito da <b>C&M SOFTWARE</b> de rescindir o presente 
        Contrato.
    </p>
    <p>
        <b>3.9.1.</b> Após a comprovação do pagamento dos valores em atraso pelo <b>CLIENTE</b>, o acesso aos softwares será desbloqueado e voltará a funcionar automaticamente.
    </p>    

    <p><b>CLÁUSULA QUARTA: DO ACESSO AO PL-BACEN, IMPLANTAÇÃO E ATUALIZAÇÕES</b></p>
    <p>
        <b>4.1.</b> O <b>CLIENTE</b> recebeu no momento da contratação, ou até mesmo durante o processo de implantação e ativação dos produtos contratados, manuais explicativos 
        exemplificando o acesso aos softwares.
    </p>
    <p>
        <b>4.2.</b> A <b>C&M SOFTWARE</b> poderá promover atualizações nos softwares e serão sempre aplicadas na última versão disponibilizada em uso.
    </p>
    <p>
        <b>4.2.1.</b> Toda nova implementação ou atualização do software, solicitada pelo ,<b>CLIENTE</b>, após aprovação da <b>C&M SOFTWARE</b>, será incorporada na forma de 
        licenciamento e propriedade do PL-BACEN. 
    </p>
    <p>
        <b>4.3.</b> Se forem realizadas atualizações dos softwares, a <b>C&M SOFTWARE</b> obriga-se a comunicar e disponibilizá-las ao <b>CLIENTE</b>, gratuita e imediatamente.
    </p>

    <p><b>CLÁUSULA QUINTA: DAS OBRIGAÇÕES DA C&M SOFTWARE</b></p>
    <p>
        <b>5.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, a <b>C&M SOFTWARE</b> obriga-se a: 
    </p>
    <p>
        <b>5.1.1.</b> Executar o objeto deste Contrato, com a sua usual diligência, padrão e com observância das leis aplicáveis.
    </p>
    <p>
        <b>5.1.2.</b> Realizar a manutenção preventiva e corretiva do software objeto deste Contrato.
    </p>
    <p>
        <b>5.1.3.</b> Atualizar os sistemas que compõem o <b>PL-BACEN</b> para não incorrer em obsolescência tecnológica.
    </p>
    <p>
        <b>5.1.4.</b> A partir da assinatura do presente Contrato e durante toda a sua vigência, possuir e manter infraestrutura tecnológica que suporte o volume mínimo de mensagens 
        contratado e eventual superação de uso deste mesmo volume em até 3 (três) vezes, de tal modo a não gerar impacto impeditivo de uso ao <b>CLIENTE</b> no momento do uso.
    </p>
    <p>
        <b>5.1.5.</b> Toda e qualquer responsabilidade da <b>C&M SOFTWARE</b> limita-se,  única e exclusivamente, aos sistemas desenvolvidos sob sua autoria. A <b>C&M</b> não 
        responderá pela qualidade de produtos de terceiros, mesmo que tais produtos de terceiros precisem ser incorporados ao sistema.
    </p>
    <p>
        <b>5.2.</b> Segregar, no prazo de 90 (noventa) dias, os dados do <b>CLIENTE</b> dos demais dados de outros clientes dos softwares. Não será permitida a guarda de dados ou 
        informações nos Banco de Dados da C&M Software por período superior ao acima avençado.
    </p>
    <p>
        <b>CLÁUSULA SEXTA: DAS OBRIGAÇÕES DO CLIENTE</b>
    </p>
    <p>
        <b>6.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, o <b>CLIENTE</b> obriga-se a: 
    </p>
    <p>
        <b>6.1.1.</b> Agir de acordo com todas as leis, regras e regulamentações governamentais aplicáveis no acesso às informações. 
    </p>
    
    
";

$texto[5] =
"   
    <p>
        <b>6.1.2.</b> Efetuar os pagamentos devidos pela contratação, de acordo com as disposições deste Contrato.
    </p>
    <p>
        <b>6.1.3.</b> Disponibilizar todos os dados/informações, dados e ambientes de terceiros, necessários à execução deste Contrato.
    </p>
    <p>
        <b>6.1.4.</b> Manter sob sigilo os códigos e senhas de acesso aos softwares, sendo de sua plena e total responsabilidade o uso indevido. Em caso de perda, fraude ou qualquer 
        outro risco na guarda, a <b>C&M SOFTWARE</b> deverá ser comunicada por escrito, da necessidade de bloqueio do acesso anterior e criação de novo acesso.
    </p>
    <p>
        <b>6.1.5.</b> Responsabilizar-se, civilmente por atos próprios, ou quaisquer atos de seus empregados, comitentes ou prepostos que vierem dar prejuízos, tanto materiais quanto 
        de imagem, ou de qualquer forma diminuir o patrimônio da <b>CONTRATANTE</b>.
    </p>
    <p>
        <b>6.1.6.</b> Manter estrutura adequada para o uso dos softwares, assim como, realizar a manutenção preventiva e corretiva dos itens fornecidos pela <b>C&M SOFTWARE</b>, mantendo os 
        equipamentos atualizados e operantes.
    </p>
    <p>
        <b>6.1.7.</b> Desde já, reconhecer que independente do uso do volume mínimo de mensagens contratado conforme item “V – DO PREÇO” do Quadro Resumo, que a infraestrutura 
        responsável por acolher este volume em até 3 (três) vezes já se encontra a sua disposição para uso a partir do momento da assinatura do presente Contrato, ficando a sua 
        deliberação e decisão o melhor momento para uso, sendo que esta decisão não impactará as demais responsabilidades deste instrumento.
    </p>
    <p>
        <b>6.2.</b> Cada parte deverá orientar seus representantes para que cumpram as orientações relativas à segurança, bem como normas e procedimentos, durante o período em que 
        esses representantes estiverem designados para prestarem serviços nas dependências da outra parte. 
    </p>

    <p><b>CLÁUSULA SÉTIMA: DA RESCISÃO</b></p>
    <p>
        <b>7.1.</b> O presente Contrato não poderá ser rescindido, antecipadamente, por qualquer das partes, sem justo motivo, sob pena de aplicação automática de multa disposta nos 
        itens “IV – DO PRAZO DE VIGÊNCIA” e “VI – DA RENOVAÇÃO DO CONTRATO” do Quadro Resumo.
    </p>    
    <p>
        <b>7.2.</b> Este instrumento poderá ser rescindido, ainda, motivadamente, de forma imediata e de pleno direito:
    </p>
    <p>
        <b>a)</b> descumprimento de qualquer das cláusulas do Contrato, desde que não sanada no prazo de 10 (dez) dias a contar do recebimento da notificação da outra Parte 
        neste sentido;
    </p>
    <p>
        <b>b)</b> a outra Parte vir a ter a sua falência ou recuperação judicial/extrajudicial requerida ou decretada, ou insolvência civil dos sócios, mesmo que presumida, 
        bem como a condenação de qualquer um dos seus sócios em processos criminais; e,
    </p>
    <p>
        <b>c)</b> a outra Parte vir a ter sua idoneidade técnica ou financeira abalada ou o seu quadro societário modificado, de forma a prejudicar a fiel execução de suas 
        obrigações contratuais, a critério da outra Parte.
    </p>
    <p>
        <b>d)</b> o encerramento das atividades, mesmo que voluntário, do CLIENTE ou alienação de direitos ou carteira, não o exime das infrações contratuais e consequentes multas
        a serem aplicadas.
    </p>
    <p>       
        <b>7.2.1.</b> A parte que der causa à rescisão do presente Contrato, de forma motivada, arcará com a multa por quebra de acordo comercial e preços equivalente a 60% (sessenta)
        do valor da média do faturamento mensal dos últimos 12 meses, devidamente reajustadas, multiplicado pelo número de meses restantes para a conclusão do prazo integral.
    </p>
    <p>
        <b>7.2.2.</b> O <b>CLIENTE</b> fico isento da aplicação da Cláusula <b>7.2.1</b> somente quando a rescisão contratual for oriunda do descumprimento por parte da <b>C&M SOFTWARE</b>
        ao Comunicado do Banco Central do Brasil 8.454 e sua Circular 3.629/2013.    
    </p>   
    <p>   
        <b>7.3.</b> O presente Contrato poderá ser encerrado, sem qualquer ônus, em razão da ocorrência de eventos de caso fortuito ou de força maior, regularmente comprovados, 
        impeditivos da execução deste Contrato. Quando for possível a execução apenas parcial do Contrato, o <b>CLIENTE</b> poderá decidir entre o cumprimento parcial ou o término 
        do Contrato.
    </p>
    <p>
        <b>7.4.</b> Na ocorrência do término deste Contrato, por qualquer motivo, o <b>CLIENTE</b> remunerará a <b>C&M SOFTWARE</b> pelos serviços já prestados e concluídos, 
        bem como efetuará o pagamento das despesas já ocorridas, estabelecendo as Partes desde já que o faturamento da “Hospedagem” , em função do tipo de contratação 
        (licenciamento do software) será integralmente cobrado, conforme valor estabelecido no item “V – DO PREÇO” do Quadro Resumo, independente das datas de rescisão e vencimento, 
        não sendo aplicada a forma de cobrança “pro rata die”.
    </p>
    <p>
        <b>7.5.</b> Esta cláusula se aplica a qualquer dos contratos individualmente, e será assim considerada para ambos.
    </p>
   
";

$texto[6] = 
"   
    <p><b>CLÁUSULA OITAVA: DAS DISPOSIÇÕES GERAIS</b></p>
    <p>
        <b>8.1.</b> Nenhuma disposição deste Contrato poderá ser interpretada como tendo as Partes estabelecido qualquer forma de sociedade ou associação, de fato ou de direito, 
        remanescendo cada uma das partes com suas obrigações civis, comerciais, trabalhistas e tributárias, de forma autônoma.
    </p>
    <p>
        <b>8.2.</b> Nenhuma das Partes poderá ceder ou transferir, no todo ou em parte, os direitos e obrigações decorrentes deste Contrato, sem a anuência prévia e expressa 
        da outra Parte.
    </p>
    <p>
        <b>8.3.</b> Qualquer aditamento ou alteração a este Contrato somente será válida se feito por meio de aditivo contratual, escrito e assinado pelas Partes.
    </p>
    <p>
        <b>8.4.</b> Todas as obrigações e condições aqui estipuladas obrigam as Partes e seus sucessores a qualquer título.
    </p>
    <p>
        <b>8.5.</b> Todas as notificações ou comunicações dadas, segundo o presente Contrato, de uma Parte à outra, deverão ser endereçadas somente por via postal através de 
        carta registrada, todas com aviso de recebimento, para os representantes legais nos endereços constantes na qualificação das Partes. Se houver alteração do 
        Representante Legal, deverá ser anexado documento de comprovação para o exercício do ato. 
    </p>
    <p>
        <b>8.6.</b> A tolerância de uma Parte com a outra, relativamente a qualquer violação ou descumprimento de quaisquer obrigações ora assumidas, não será considerada moratória, 
        novação ou renúncia a qualquer direito, constituindo mera liberalidade, que não impedirá a Parte tolerante de exigir da outra o fiel cumprimento deste Contrato, a qualquer 
        tempo.
    </p>
    <p>
        <b>8.7.</b> Se qualquer cláusula ou condição deste Contrato vier a ser considerada ilegal, inválida ou inexequível nos termos da legislação brasileira, as demais cláusulas e 
        condições continuarão em pleno vigor e efeito.
    </p>
    <p>
        <b>8.8.</b> O <b>CLIENTE</b> outorga a gestão integral dos ambientes de homologação e produção dos sistemas ora licenciados, ciente que o funcionamento e disponibilidade destes 
        dependem desta condição. Qualquer alteração nas suas configurações, sem conhecimento prévio da <b>C&M SOFTWARE</b>, resultará na imediata rescisão deste contrato, com a consequente 
        aplicação da multa, por inviabilidade técnica de continuidade.
    </p>
    <p>
        <b>8.9.</b> O presente Contrato constitui o acordo final entre as Partes com relação às matérias aqui expressamente tratadas, superando e substituindo todas as propostas, 
        acordos, entendimentos e declarações anteriores, orais ou escritos.
    </p>
    <p>
        <b>8.10.</b> Cada uma das Partes declara, garante e concorda, reciprocamente, que a celebração, outorga e execução deste Contrato foi devidamente autorizada pelos seus 
        legítimos representantes legais, na forma dos seus respectivos documentos societários, sendo que o fornecimento de eventual informação inverídica, incompleta ou inidônea 
        será considerado infração aos princípios da informação e boa-fé contratual, respondendo a parte que assim as prestou civil e criminalmente, restando claro que este contrato 
        constitui obrigação legal, válida e vinculante entre as Partes.
    </p>
    <p>
        <b>8.11.</b> O presente Contrato é considerado título executivo extrajudicial, nos termos do inciso III, do artigo 784, do Código de Processo Civil, sujeitando-se, 
        dessa forma, à legislação aplicável à matéria.
    </p>
    <p>
        <b>8.12.</b> As Partes elegem o foro da Comarca conforme declinado no item “<b>X – DO FORO</b>” do Quadro Resumo, para dirimir quaisquer dúvidas ou atos oriundos ou relativos a este
        contrato, renunciando a qualquer outro por mais privilegiado que seja.
    </p>    
";

$texto[7] = "
    <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>
                <td class='td_cabecalho' style='text-align:center;border-top:3px solid;border-bottom:3px solid;'>
                    <small><b>ANEXO I - SISTEMA DA PAGAMENTOS INSTANTÂNEOS – SPI/x.</b></small>
                </td>
            </tr>
        </tbody>
    </table>
    <p>
        O objetivo do presente anexo é estabelecer procedimentos exclusivos para o Licenciamento de uso do Software do Sistema de Pagamentos Instantâneo - <b>SPI/x</b>, em caráter temporário
        e intransferível, nos termos e condições aqui avençadas, viabilizando ao <b>CLIENTE</b> a operação diretamente nos Sistemas de Liquidação do Banco Central do Brasil, conforme 
        regulamentação em vigor.
    </p>
    <p>
        <b>RESOLVEM</b> as partes, por estarem de comum acordo e pactuadas, firmar o presente Contrato de Licenciamento ao Sistema de Pagamentos Instantâneos (SPI/x) que se regerá pelas 
        cláusulas e condições a seguir:
    </p>

    <p><b>CLÁUSULA PRIMEIRA: CONDIÇÕES GERAIS</b></p>

    <p>
        <b>1.</b> Destina-se o presente instrumento a integrar o <b>CLIENTE</b> com a finalidade de atender o Comunicado nº 32.927 de 21 de dezembro de 2018 (e subsequentes correlatos), 
        que dispõem sobre o novo ecossistema de pagamentos brasileiros, Pagamentos Instantâneos, ora identificado como como SPI/x.
    </p>
    <p>
        <b>2.</b> A <b>C&M SOFTWARE</b>, com a assinatura do presente termo estende-se, integralmente, as responsabilidades das partes pactuadas no contrato principal também ao SPI/x, 
        além das novas regulamentações a serem publicadas pelo BACEN também fazerem parte ao presente de maneira inconteste.
    </p>
    <p>
        <b>3.</b> Com vistas a promover uma melhor precificação e utilização da infraestrutura alocada para a execução do produto ora licenciado, a C&M Software concede ao CLIENTE, 
        a tabela abaixo a ser aplicada como forma redutora de preços com base no horário de execução da transação associada         
    </p>

    <menu>
        <ul>Valor Integral da transação a Crédito do <b>CLIENTE</b> (conforme cláusula 2.3.) </ul>
        <ul>Valor Integral da transação a Débito do <b>CLIENTE</b> (conforme cláusula 2.3.)</ul>
        <ul> Desconto a ser aplicado no valor base das transações trafegada nos seguintes horários: </ul> 
        
        <table style='border:thin solid 1px;'>
            <thead>  
                <tr>
                    <th style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;background-color:#c25647;color:rgb(255, 255, 255);'><small><b>TIPO / HORÁRIO</b></small></th>";
                    foreach ($this->dicionario['TEXTO_SLIDE']['FULL']['TABLE_FULL']['HORARIO'] as $key => $value) {
                        $texto[7] .= 
                        "                 
                            <th  style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;background-color:#c25647;color:rgb(255, 255, 255);'><small><b>".$value."</b></small></th>                              
                        ";
                    }
        $texto[7] .="    
                </tr>
            </thead>
                <tbody>
                    <tr>
                        <th style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;background-color:#c25647;color:rgb(255, 255, 255);'><small><b>CREDITO CLIENTE</b></small></th>";
                        foreach ($this->dicionario['TEXTO_SLIDE']['FULL']['TABLE_FULL']['HORARIO'] as $key => $value) {
                            $texto[7] .= 
                            "                 
                                <td style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;'><small>".$this->dicionario['TEXTO_SLIDE']['FULL']['TABLE_FULL'][$value]['CREDITO']."</small></td>                              
                            ";
                        }
                    $texto[7] .= 
                    "</tr>
                        <tr>
                            <th style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;background-color:#c25647;color:rgb(255, 255, 255);'> <small><b>DEBITO DO CLIENTE</b></small></th>";
                        foreach ($this->dicionario['TEXTO_SLIDE']['FULL']['TABLE_FULL']['HORARIO'] as $key => $value) {
                            $texto[7] .= 
                            "                 
                                <td style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;'><small>"
                                    .$this->dicionario['TEXTO_SLIDE']['FULL']['TABLE_FULL'][$value]['DEBITO'].
                                "</small></td>                              
                            ";
                        }
                    $texto[7] .= "</tr>
            <thead>
        </table>            
    </menu>
    <p>
        <b>Paragrafo Primeiro</b>. Entenda-se: Transações a crédito do <b>CLIENTE</b>, são as que resultam em crédito na Conta do <b>CLIENTE</b> junto ao BACEN, e, respectivamente, transações a débito 
        <b>CLIENTE</b>, são aquelas que resultam em débito na Conta do <b>CLIENTE</b> junto ao BACEN.
    </p>    
    <p>
       <b>Paragrafo Segundo</b>. A apuração do uso será mensal, respeitando as datas de corte e datas de faturamento pactuados no contrato principal e/ou seus anexos anteriores.
    </p>
    <p>
        <b>Paragrafo terceiro</b>. A presente tarifação somente ocorrerá quando do ingresso em produção junto ao BACEN do SPI/x. Não ocorrerá qualquer cobrança no período de testes e 
        homologação, seguindo as datas de faturamento pactuada no contrato ora aditado.
    </p>
    <p>
        <b>4.</b> Somente serão tarifadas/faturadas mensagens que de alguma maneira afetem o saldo do <b>CLIENTE</b> junto ao BACEN tanto a crédito quanto a débito, respeitando a 
        política da Clausula Primeira item 3.
    </p>
    <p>
        <b>5.</b> Como o BACEN criou a instituição PSTI SWITCH, que terá operações similares a uma CLEARING HOUSE entre os clientes do PSTI, fica intrínseco que, a divulgação do 
        <b>CLIENTE</b> como participante do <b>PSTI C&M Software</b> é necessária a fim de habilitar tal recurso especificado pelo BACEN no SPI/x, sem que se explore publicitariamente
         as marcas envolvidas.
    </p>
    <p><b>CLÁUSULA SEGUNDA: VIGÊNCIA, PREÇOS E CONDIÇÕES:</b></p>
   
    <p>
        <b>2.1.</b> O valor da Implantação é de **--IMPLANTACAO--** **--IMPLANTACAO/EXTENSO--**, **--TEXTO_IMPLANTACAO--** mediante apresentação da respectiva nota fiscal.
    </p>
    <p>
        <b>2.2.</b> Os valores das transações seguem as condições abaixo:
        **--VALORES_BASE_TARIFACAO--** 
        <small> Os valores não contemplam tributos e serão acrescidos quando da emissão da Nota Fiscal/Fatura. </small>
    </p> 
    <p>
        <b> 2.3. </b> Para fins de suporte ao investimento realizado pela <b>C&M SOFTWARE</b>, as partes concordam que, sob nenhum aspecto, venham a rescindir o presente instrumento por, 
        no mínimo, o primeiro período contratado, a contar da data da assinatura do presente instrumento.
    </p>
";

$texto[8] = 
"       
    <p><b> CLÁUSULA TERCEIRA: DOS REQUISITOS TÉCNICOS E SUPORTE DO SPI/x </b></p>
    <p>
        <b>3.1.</b> Pelos serviços de Implantação a <b>C&M SOFTWARE</b> configurará os sistemas que compõem a solução SPI/x, compreendendo os ambientes de Homologação e Produção, 
        contemplando os seguintes serviços:
    </p>
    <p>
        <b>3.1.1.</b> A Implantação contempla, ainda, o treinamento ao <b>SPI/x</b> concedido pela <b>C&M SOFTWARE</b> ou terceiros por ela credenciados, nas instalações físicas da 
        <b>C&M SOFTWARE</b>, do <b>CLIENTE</b>, ou outro local indicado por este, de até 3 (três) profissionais da <b>CONTRATANTE</b> na utilização do software ora contratado, 
        conforme abaixo descrito:
    </p>
    <p>
        <b>a)</b> Treinamento Mensageria: Consiste no treinamento na utilização do Sistema C&M Message Router;
    </p>
    <p>
        <b>b)</b> Treinamento Piloto de Reserva: Consiste no treinamento da utilização do C&M Piloto de Reserva e suas funcionalidades desenvolvidas até a data do treinamento; e,
    </p>
    <p>
        <b>c)</b> Treinamento Piloto de Reserva Configurações: Consiste no treinamento do C&M Piloto de Reserva aplicável somente as condições de filtragem disponível nas 
        funcionalidades desenvolvidas até a data do treinamento.
    </p>
    <p>
        <b>3.1.2.</b> O treinamento deverá ser solicitado pelo <b>CLIENTE</b>, com um prazo mínimo de 30 (trinta) dias de antecedência, sendo que, caso o local escolhido seja fora da região 
        metropolitana da cidade de São Paulo, as despesas com transportes, hospedagem e alimentação dos instrutores, serão de responsabilidade exclusiva do <b>CLIENTE</b>.
    </p>
    <p>
        <b>3.2.</b> A licença de uso do SPI/x contempla: 
    </p>   
    <p>
        <b>a)</b> Licença de Uso C&M Message Router: Utilização do Sistema de Mensageria da <b>C&M SOFTWARE</b>;
    </p>
    <p>
        <b>b)</b> Licença de Uso C&M Piloto de Reserva: Utilização do Sistema de Gerenciamento de Conta Reserva de propriedade da <b>C&M SOFTWARE</b>;
    </p>
    <p>
        <b>c)</b> Licença de Uso C&M Suite Package Security: Módulo de Cifragem que compõe a Solução; e,
    </p>
    <p>
        <b>d)</b> Acesso a RSFN: Acessos aos serviços da <b>C&M SOFTWARE</b> na RSFN, através de seus links próprios.
    </p>    
    <p>
        <b>3.3.</b> Manter a disponibilidade mínima de operacionalidade de 99,8% (noventa e nova inteiros e oito centésimos por cento), por 7 (sete) dias na semana e 24 
        (vinte e quatro) horas no dia e 365 (trezentos e sessenta e cinco dias) por ano.
    </p>
    <p>        
        <b>3.3.1.</b> Não serão considerados para cálculo de nível de operacionalidade os seguintes casos:
    </p>   
    <p> 
        <b>a)</b> execução de manutenção, comunicada pela <b>C&M SOFTWARE</b> com mínimo de 15 (quinze) dias de antecedência; 
    </p>
    <p> 
        <b>b)</b> operação inadequada do software e dos equipamentos pelo <b>CLIENTE</b>, em desacordo com as instruções da <b>C&M SOFTWARE</b>; 
    </p>
    <p> 
        <b>c)</b> falhas ocasionadas em relação à infraestrutura do <b>CLIENTE</b> ou de seus clientes finais. 
    </p>
    <p> 
        <b>d)</b> quando, por qualquer motivo, o <b>CLIENTE</b> impedir o acesso da <b>C&M SOFTWARE</b> onde estejam localizados seus equipamentos ou os por ela mantidos, postergando 
        assim o restabelecimento da operação. 
    </p>     
    <p>
        <b>3.5.</b> O <b>CLIENTE</b> tem conhecimento que toda a comunicação por intermédio da rede mundial de computadores (internet) está sujeita a interrupções e/ou atrasos, 
        podendo ocorrer problemas de transmissão ou de recepção das informações acessadas.  
    </p>

    <p><b>CLÁUSULA QUARTA: DAS OBRIGAÇÕES DA C&M SOFTWARE</b></p>   
     
    <p>
        <b>4.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, a C&M SOFTWARE obriga-se a: 
    </p>
    <p>
        <b>4.1.1.</b> Manter e atualizar seus Sistemas que compõem a solução SPI/x, Ambiente de Homologação e Produção, conforme abaixo:
    </p>        
    <p> 
        <b>a)</b> MQ-Series, manter atualizado com o padrão estipulado pelo Banco Central do Brasil e as Câmaras que participam do Sistema;
    </p>
    <p> 
        <b>b)</b> Mensageria, sempre atualizada com a última versão do “book” de Mensagens e DTD padronizadas pelo Banco Central do Brasil e as Câmaras que participam do Sistema;
    </p>
    <p> 
        <b>c)</b> Módulo de Segurança, manter atualizado com a última versão divulgada pelo Banco Central do Brasil;
    </p>
    <p> 
        <b>d)</b> Piloto de Reservas, manter compatível com o todo do Sistema SPB, segundo especificações do Banco Central do Brasil. 
    </p>   
";

$texto[9] = 
"   
       
    <p>
        <b>4.1.2.</b> Manter o histórico de mensagens dos últimos 02 (dois) meses, mais o mês corrente disponíveis para acesso online. A base histórica anterior a esse período 
        deverá ser guardada pelo <b>CLIENTE</b>.
    </p>
    <p>
        <b>4.1.2.1.</b> Mensalmente a <b>C&M SOFTWARE</b> disponibilizará ao <b>CLIENTE</b> gerará um arquivo .ZIP em um site SFTP com a base anterior ao mês corrente para 
        guarda do CLIENTE.
    </p>
    <p>
        <b>4.1.4.2.</b> Fornecerá também um software, durante a vigência deste Contrato, para visualização das mensagens conforme padrão exigido pelo Banco Central do Brasil,
            convencionado no documento “Manual de Segurança de Mensagens do SPI/x”, capítulo que trata da manutenção e guarda dos registros para fins de auditoria.    
    </p>     
    <p>       
        <b>4.1.3.</b> Manter toda a estrutura de suporte e investimentos para homologação do Sistema continuamente, mesmo que exceda a data prevista de novembro de 2020.
    </p>
        
    <p><b>CLÁUSULA QUINTA: DAS OBRIGAÇÕES DO CLIENTE</b></p>
    <p>    
        <b>5.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, o CLIENTE obriga-se a: 
    </p>
    <p>
        <b>5.1.1.</b> Fornecer, por escrito, todos os dados técnicos que vierem a ser solicitados pela <b>C&M SOFTWARE</b>, necessários para a elaboração do Projeto e 
        execução do Contrato. 
    </p>
    <p>
        <b>5.1.2.</b> Fornecer, durante a execução da Implantação, sem ônus para a C&M SOFTWARE, recursos telefônicos e de fac-símile para comunicação, bem como facilidades 
        para fotocópias de documentos. 
    </p>
    <p>
        <b>5.1.3.</b> Fornecer todos os dados técnicos necessários à disponibilização do acesso da <b>C&M SOFTWARE</b>.
    </p>
    <p>
        <b>5.1.4.</b> Abster-se de reparar, modificar, ou mesmo adicionar novos componentes ou conexões, ou fazer alterações e/ou mudanças de qualquer tipo nas Estações de 
        Telecomunicações, sem prévia autorização por escrito por parte da <b>C&M SOFTWARE</b>.   
    </p> 
    <p>
        <b>5.2.</b> O <b>CLIENTE</b> reconhece, diante dos vultosos investimentos em andamento, que os domínios primários para processamento do sistema, objeto deste anexo, deve, 
        durante toda a sua vigência, ficar sob total domínio do <b>PSTI C&M Software</b> e o direcionamento e cadastramentos junto ao <b>BACEN</b> serem indicados, exclusivamente, para o 
        <b>PSTI C&M Software</b>, que terá completo poder de gestão da <b>C&M SOFTWARE</b>, vez que controla estas terminações nos ambientes de homologação, produção e contingência, 
        sendo que as alteração não concordadas acarretarão em estimativa de perdas e danos e lucros cessantes baseado no volume de transações tarifáveis a que este contrato regula, 
        a ser definido.
    </p>

    <p><b>CLÁUSULA SEXTA: DO EQUIPAMENTO E SOFTWARE</b></p>

    <p>
        <b>6.1.</b> O <b>CLIENTE</b> não terá qualquer direito à propriedade de qualquer equipamento fornecido pela ou através da <b>C&M SOFTWARE</b>, a não ser que tal equipamento 
        tenha sido adquirido pelo <b>CLIENTE</b>, mediante assinatura do competente Contrato de Compra e Venda.         
    </p>
    <p>
        <b>6.2.</b> O <b>CLIENTE</b> é responsável pela instalação, operação ou manutenção do equipamento na propriedade do <b>CLIENTE</b> ou por outro equipamento ou software 
        (a incluir sem limitação, o cabeamento) não fornecidos pela <b>C&M SOFTWARE</b> (coletivamente, “equipamento ou software não <b>C&M</b>”).
    </p>
    <p>
        <b>6.3.</b> O Direito de Propriedade Intelectual dos softwares fornecidos pela <b>C&M SOFTWARE</b> para os fins deste contrato, a ela está assegurado.
    </p>

    <p><b>CLÁUSULA SÉTIMA: DO SUPORTE TÉCNICO</b></p>

    <p>
        <b>7.1.</b> O suporte técnico ao <b>SPI/x</b> será prestado pela <b>C&M SOFTWARE</b> ou terceiros por ela credenciados via telefone (+55 11 3365-2666) ou correio eletrônico 
        (suporte@cmsw.com.br) sem custos adicionais para o <b>CLIENTE</b>, nas seguintes condições:
    </p>
    <p>
        <b>7.2.</b> O Suporte Operacional da <b>C&M SOFTWARE</b>, responsável direto pela disponibilidade do produto, bem como por responder a questionamentos iniciais, poderá ser 
        acessado 07 (sete) dias por semana, 24 (vinte e quatro) horas por dia, 365 (trezentos e sessenta e cinco) dias por ano (7x24x365).
    </p>
";

?>