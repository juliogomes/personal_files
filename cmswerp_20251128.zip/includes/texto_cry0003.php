<?php
    $texto[0] = '
        <table>
            <tbody>
                <tr>
                    <td>
                    <h2><strong>QUADRO RESUMO</strong></h2>
                    </td>
                </tr>
                <tr>
                    <td><strong>I &ndash; CONTRATADA CRYSTAL BMC - INSTITUI&Ccedil;&Atilde;O DE PAGAMENTO LTDA</strong>., pessoa jur&iacute;dica de direito privado com sede na Alameda Rio Pardo, n&ordm; 27, Bairro Alphaville Industrial, no munic&iacute;pio de Barueri, Estado de S&atilde;o Paulo, CEP 06455-005, inscrita no CNPJ/MF sob o n&ordm; n&ordm;43.561.343/0001-38, doravante denominada simplesmente <strong>&ldquo;CRYSTAL BMC&rdquo;;</strong></td>
                </tr>
                <tr>
                    <td>
                    <p><strong>**--CLIENTE--**</strong>, pessoa jur&iacute;dica de direito privado com endere&ccedil;o **--ENDERECO--** - **--BAIRRO--**, na cidade de **--CIDADE--**, Estado de **--UF--**, CEP **--CEP--**, inscrita no C.N.P.J. n&ordm; **--CNPJ--**, neste ato representada na forma de seus atos constitutivos por <strong>**--REPRESENTANTE_LEGAL--**</strong>, **--REPRESENTANTE_LEGAL/CARGO--**, C.P.F. n&ordm; **--REPRESENTANTE_LEGAL/CPF--**, e-mail **--REPRESENTANTE_LEGAL/EMAIL--**, telefone **--REPRESENTANTE_LEGAL/TELEFONE--**, doravante denominada simplesmente &ldquo;CLIENTE&rdquo;.</p>

                    <p><strong>CONTATO RESPONS&Aacute;VEL:</strong></p>

                    <p>CONTATO RESPONS&Aacute;VEL: **--CONTATO_RESPONSAVEL--** - e-mail: **--CONTATO_RESPONSAVEL/EMAIL--** - telefone: **--CONTATO_RESPONSAVEL/TELEFONE--**</p>

                    <p><strong>FINANCEIRO:</strong></p>

                    <p>FINANCEIRO: **--CONTATO_FINANCEIRO--** - e-mail: **--CONTATO_FINANCEIRO/EMAIL--** - telefone: **--CONTATO_FINANCEIRO/TELEFONE--**</p>
                    </td>
                </tr>
                <tr>
                    <td>
                    <p><strong>III &ndash; DO OBJETO DO CONTRATO</strong></p>

                    <p>O objeto do presente Contrato consiste em regular a contrata&ccedil;&atilde;o do servi&ccedil;o de Inicia&ccedil;&atilde;o de Pagamento no &acirc;mbito do Open Finance (&ldquo;Servi&ccedil;o Open Finance Inicia&ccedil;&atilde;o de Pagamento&rdquo;).</p>
                    </td>
                </tr>
                <tr>
                    <td>
                    <p><strong>III &ndash; DO OBJETO DO CONTRATO</strong></p>

                    <p>O objeto do presente Contrato consiste em regular a contrata&ccedil;&atilde;o do servi&ccedil;o de Inicia&ccedil;&atilde;o de Pagamento no &acirc;mbito do Open Finance (&ldquo;Servi&ccedil;o Open Finance Inicia&ccedil;&atilde;o de Pagamento&rdquo;).</p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p><strong>IV &ndash; DO PRAZO DE VIG&Ecirc;NCIA</strong></p>
                        <p>O presente Contrato, assinado na forma do artigo 10&deg; da Medida Provis&oacute;ria n&ordm; 2.200-2/2001 (Assinatura Digital), vigorar&aacute; pelo prazo **--VIGENCIA_CONTRATO--**( **--VIGENCIA_CONTRATO/EXTENSO--** ) meses, contado a partir da data da assinatura digital pelo <strong>CLIENTE.</strong></p>
                    </td>
                </tr>
                <tr>
                    <td>
                    <p><strong>V &ndash; PRE&Ccedil;O</strong></p>

                    <p><strong>V.I</strong> - O valor da Implanta&ccedil;&atilde;o &eacute; de R$ <strong>**--IMPLANTACAO--** **--IMPLANTACAO/EXTENSO--**, **--TEXTO_IMPLANTACAO--**</strong>, que ser&aacute; pago em at&eacute; 10 (dez) dias ap&oacute;s a assinatura digital do presente contrato.</p>

                    <p>O valor da implanta&ccedil;&atilde;o corresponde a instala&ccedil;&atilde;o e configura&ccedil;&atilde;o do produto, al&eacute;m de todos os ajustes e configura&ccedil;&otilde;es necess&aacute;rios para a integra&ccedil;&atilde;o.</p>

                    <p><strong>V.II</strong> - Os pre&ccedil;os s&atilde;o aqueles mencionados no item &ldquo;IV &ndash; ORDEM DE SERVI&Ccedil;O&rdquo;..</p>

                    <p><strong>V.III</strong> - Os valores n&atilde;o contemplam tributos e ser&atilde;o acrescidos quando da emiss&atilde;o da Nota Fiscal/Fatura.</p>
                    </td>
                </tr>
                <tr>
                    <td>
                    <p><strong>VI &ndash; DO FATURAMENTO</strong></p>

                    <p>Data de corte todo o dia **--CORTE_FATURAMENTO--**( **--CORTE_FATURAMENTO/EXTENSO--** ) de cada m&ecirc;s, com prazo de pagamento de **--PRAZO_PAGAMENTO--** ( **--PRAZO_PAGAMENTO/EXTENSO--** ) dias contados da apresenta&ccedil;&atilde;o da nota fiscal/fatura, ocorrendo o primeiro faturamento no primeiro dia 25 (vinte e cinco), independentemente da conclus&atilde;o da implanta&ccedil;&atilde;o e do uso.</p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p><strong>VII - DO REAJUSTE CONTRATUAL</strong></p>
                        <p><span style="color:black">A cada 12 (doze) meses pelo **--INDICE_REAJUSTE--** / IBGE, </span>a contar da data de assinatura do presente Contrato, sem necessidade de celebra&ccedil;&atilde;o de aditivo ou pr&eacute;via autoriza&ccedil;&atilde;o.</p>
                    </td>
                </tr>
                <tr>
                    <td>
                    <p><strong>VIII - DA RENOVA&Ccedil;&Atilde;O DO CONTRATO</strong></p>

                    <p>Caso n&atilde;o haja manifesta&ccedil;&atilde;o por nenhuma das partes com anteced&ecirc;ncia m&iacute;nima de 60 (sessenta) dias do vencimento do Contrato, esse prorrogar-se-&aacute; automaticamente por igual per&iacute;odo e assim sucessivamente por iguais per&iacute;odos, podendo ser rescindido, antecipadamente, por qualquer das partes, sem justo motivo, sem qualquer &ocirc;nus ou penalidades.</p>
                    </td>
                </tr>
                <tr>
                    <td>
                    <p><strong>IX &ndash; DA DIVULGA&Ccedil;&Atilde;O</strong></p>

                    <p>O CLIENTE, desde j&aacute;, autoriza a CRYSTAL BMC a incluir o seu nome na sua lista de clientes, assim como sua divulga&ccedil;&atilde;o, pelos meios de comunica&ccedil;&atilde;o pr&oacute;prios, juntamente com os nomes de outros clientes, mas n&atilde;o revelar&aacute;, comunicar&aacute; ou de qualquer forma far&aacute; propaganda a qualquer terceiro de detalhes deste Contrato.</p>
                    </td>
                </tr>
                <tr>
                    <td>
                    <p><strong>X &ndash; DO FORO</strong></p>

                    <p>Fica eleito o foro da comarca de Barueri do Estado de S&atilde;o Paulo para dirimir quaisquer quest&otilde;es advindas deste Instrumento, renunciando as partes a qualquer outro, por mais privilegiado que seja.</p>
                    </td>
                </tr>
                <tr>
                    <td>
                    <p><strong>TESTEMUNHAS:</strong></p>

                    <p><strong>Nome</strong>: **--TESTEMUNHA_CMSW--** da C&amp;M C.P.F. n&ordm; **--TESTEMUNHA_CMSW/CPF--** e-mail: **--TESTEMUNHA_CMSW/EMAIL--**</p>

                    <p><strong>Nome</strong>: **--TESTEMUNHA--** C.P.F. n&ordm; **--TESTEMUNHA_CPF--** e-mail: **--TESTEMUNHA_EMAIL--**</p>
                    </td>
                </tr>
            </tbody>
        </table>
        <table>
            <tbody>
                <tr>
                    <td>Contrato assinado digitalmente nos termos da MEDIDA PROVIS&Oacute;RIA No 2.200-2, DE 24 DE AGOSTO DE 2001 e LEI N&ordm; 14.063, DE 23 DE SETEMBRO DE 2020, entre CRYSTAL BMC e CLIENTE.</td>
                </tr>
            </tbody>
        </table>
    ';

    $texto[1] = '
        <h2><strong>INSTRUMENTO PARTICULAR DE CONTRATO DE LICENCIAMENTO PLATAFORMA CRYSTAL</strong></h2>

        <p>Pelo presente instrumento e na melhor forma de direito, as partes qualificadas no<strong> QUADRO RESUMO</strong> e considerando que</p>

        <p><strong>(I)</strong> As Condi&ccedil;&otilde;es Gerais de Uso do Servi&ccedil;o (&ldquo;Condi&ccedil;&otilde;es Gerais&rdquo; ou &ldquo;Contrato&rdquo;) da Crystal descrevem os direitos e obriga&ccedil;&otilde;es que voc&ecirc; (&ldquo;CLIENTE&rdquo;) tem na contrata&ccedil;&atilde;o dos servi&ccedil;os constantes em nossa plataforma de software (&ldquo;Plataforma&rdquo; ou &ldquo;Servi&ccedil;os&rdquo; ou &ldquo;Software&rdquo;).</p>

        <p><strong>(II)</strong> Ao contratar qualquer um dos Servi&ccedil;os da Plataforma, voc&ecirc; celebrar&aacute; um contrato vinculativo com a <strong>CRYSTAL BMC</strong>.</p>

        <p><strong>(III)</strong> <strong>A CRYSTAL BMC</strong> poder&aacute;, a qualquer tempo, alterar os termos do Contrato, seus anexos e/ou pol&iacute;ticas, visando o aprimoramento e a melhoria dos servi&ccedil;os prestados, ou at&eacute; mesmo em obedi&ecirc;ncia ao regulat&oacute;rio ao qual ela est&aacute; submetida pelo Banco Central do Brasil e do projeto Open Finance, Open Banking Brasil.</p>

        <p>Este Contrato &eacute; composto pelos anexos abaixo descritos, que vistos e rubricados pelas Partes far&atilde;o parte integrante e indissoci&aacute;vel do Contrato para todos os fins de direito:</p>

        <p><strong>Anexo I</strong> &ndash; Acordo de N&iacute;vel de Servi&ccedil;o;</p>

        <p><strong>Anexo II</strong> &ndash; Condi&ccedil;&otilde;es Especiais Open Finance Agrega&ccedil;&atilde;o de Dados;</p>

        <p><strong>Anexo III</strong> - Condi&ccedil;&otilde;es Especiais Open Finance Inicia&ccedil;&atilde;o de Pagamento; e,</p>

        <p><strong>Anexo IV</strong> &ndash; Ordem De Servi&ccedil;o</p>

        <p><strong>CL&Aacute;USULA PRIMEIRA - DEFINI&Ccedil;&Otilde;ES</strong></p>

        <p><strong>1.1.</strong> Sem preju&iacute;zo das demais defini&ccedil;&otilde;es inseridas ao longo do presente Contrato, as express&otilde;es abaixo ter&atilde;o as defini&ccedil;&otilde;es estabelecidas a seguir, no plural ou singular:</p>

        <p><strong>ACORDO DE N&Iacute;VEL DE SERVI&Ccedil;O (&ldquo;SLA&rdquo;):</strong> n&iacute;vel de servi&ccedil;o oferecido pela CRYSTAL BMC ao CLIENTE sobre o atendimento e suporte aos usu&aacute;rios, bem como a manuten&ccedil;&atilde;o e a disponibilidade da Plataforma;</p>

        <p><strong>API:</strong> interface de programa&ccedil;&atilde;o de aplicativo fornecida pela CRYSTAL BMC cujo fim &eacute; permitir que a Plataforma seja integrada e acessada por Usu&aacute;rio Final atrav&eacute;s do site ou aplicativo do CLIENTE</p>

        <p><strong>CLIENTE:</strong> empresa interessada(**--CLIENTE--** ) que decidiu contratar os Servi&ccedil;os da CRYSTAL BMC.</p>

        <p><strong>DADOS PESSOAIS:</strong> significam quaisquer informa&ccedil;&otilde;es relacionadas a uma pessoa natural identificada ou identific&aacute;vel que seja coletada em decorr&ecirc;ncia das obriga&ccedil;&otilde;es das Partes no contexto deste Contrato, bem como informa&ccedil;&otilde;es relacionadas a uma pessoa natural que sejam compartilhadas ou disponibilizadas a outra Parte nos termos deste Contrato.</p>

        <p><strong>DADOS TRANSACIONAIS:</strong> significam quaisquer dados financeiros e dados de transa&ccedil;&otilde;es realizadas por Usu&aacute;rios Finais que s&atilde;o compartilhados entre as Partes, no &acirc;mbito do Open Finance e/ou do uso das APIs da CRYSTAL BMC.</p>

        <p><strong>DOCUMENTA&Ccedil;&Atilde;O:</strong> significa os guias do usu&aacute;rio de integra&ccedil;&atilde;o de API e Kit de Desenvolvimento de Software (SDKs) proporcionados pela CRYSTAL BMC e que est&atilde;o dispon&iacute;veis para download para os Clientes que contratantes.</p>

        <p><strong>OPEN FINANCE:</strong> significa o Sistema Financeiro Aberto, sistema de compartilhamento padronizado de dados e servi&ccedil;os por meio de abertura e integra&ccedil;&atilde;o de sistemas, por parte de institui&ccedil;&otilde;es financeiras, institui&ccedil;&otilde;es de pagamento e demais institui&ccedil;&otilde;es autorizadas a funcionar pelo Banco Central do Brasil, nos termos da Resolu&ccedil;&atilde;o Conjunta 1 e regulamenta&ccedil;&otilde;es subsequentes.</p>

        <p><strong>ORDEM DE SERVI&Ccedil;O:</strong> significa o Anexo IV do presente Contrato, o qual cont&eacute;m os detalhes do Software, dos Servi&ccedil;os, incluindo seus par&acirc;metros e n&iacute;veis (o &ldquo;Acordo de N&iacute;veis de Servi&ccedil;o&rdquo;), da vig&ecirc;ncia e do pre&ccedil;o da contrata&ccedil;&atilde;o ora pactuada.</p>

        <p><strong>REPRESENTANTES:</strong> todas as pessoas integrantes do grupo econ&ocirc;mico das Partes, seus s&oacute;cios, administradores, diretores, conselheiros, parceiros, procuradores, assessores, consultores, funcion&aacute;rios, agentes, subcontratados ou quaisquer terceiros direta ou indiretamente relacionados &agrave;s Partes, bem como qualquer pessoa, f&iacute;sica ou jur&iacute;dica, incluindo aquelas que, direta ou indiretamente, exer&ccedil;am controle sobre tal pessoa jur&iacute;dica, bem como suas controladoras, controladas, coligadas, interligadas e empresas sob controle comum, nos termos da Lei n&ordm; 6.404/1976, conforme alterada.</p>

        <p><strong>USU&Aacute;RIO FINAL:</strong> qualquer pessoa natural ou jur&iacute;dica que mant&eacute;m relacionamento com o CLIENTE.</p>
    ';

    $texto[2] = '
       <h3><strong>CL&Aacute;USULA SEGUNDA - DO OBJETO</strong></h3>

        <p><strong>2.1.</strong> O objeto do presente contrato &eacute; o licenciamento de uso da Plataforma <strong>CRYSTAL</strong> de forma n&atilde;o exclusiva, intransfer&iacute;vel e tempor&aacute;ria, nos termos e condi&ccedil;&otilde;es aqui aven&ccedil;adas.</p>

        <p><strong>2.2.</strong> O Servi&ccedil;o &eacute; prestado da maneira como est&aacute; dispon&iacute;vel, podendo passar por constantes aprimoramentos e atualiza&ccedil;&otilde;es, tais aprimoramentos e atualiza&ccedil;&otilde;es ser&atilde;o disponibilizadas ao <strong>CLIENTE</strong> sem &ocirc;nus adicionais.</p>

        <p><strong>2.3.</strong> A CRYSTAL BMC poder&aacute; desenvolver novos servi&ccedil;os durante o per&iacute;odo de vig&ecirc;ncia do Contrato, tais servi&ccedil;os poder&atilde;o ser contratados pelo <strong>CLIENTE</strong>, mediante novo acordo por escrito.</p>

        <p><strong>2.4.</strong> Qualquer customiza&ccedil;&atilde;o dever&aacute; estar expressamente disposta na Ordem de Servi&ccedil;o ou em instrumento espec&iacute;fico.</p>

        <h3><strong>CL&Aacute;USULA TERCEIRA &ndash; DO PRAZO DE VIG&Ecirc;NCIA</strong></h3>

        <p><strong>3.1.</strong> O presente contrato ter&aacute; validade pelo prazo estabelecido no item <strong>&ldquo;IV &ndash; DO PRAZO DE VIG&Ecirc;NCIA&ldquo;</strong>do quadro resumo.</p>

        <h3><strong>CL&Aacute;USULA QUARTA &ndash; DO PRE&Ccedil;O E PAGAMENTO</strong></h3>

        <p><strong>4.1.</strong> O pre&ccedil;o pelos servi&ccedil;os prestados est&aacute; estabelecido na Ordem de Servi&ccedil;o.</p>

        <p><strong>4.2.</strong> Acordam as PARTES que o faturamento decorrente do presente instrumento ocorrer&aacute; na forma estabelecida no item &ldquo;VI &ndash; DO FATURAMENTO&rdquo; do Quadro Resumo.</p>

        <p><strong>4.3.</strong> Caso esse &iacute;ndice venha a ser extinto ou deixar de ser utilizado, ser&aacute; adotado o &iacute;ndice que vier a ser institu&iacute;do pelas autoridades para substitu&iacute;-lo e, na sua falta, ser&aacute; determinada de comum acordo entre as Partes outra forma de reajuste.</p>

        <p><strong>4.4.</strong> O inadimplemento de toda e qualquer import&acirc;ncia cobrada com base no presente contrato, na data de seu vencimento, implicar&aacute; na incid&ecirc;ncia autom&aacute;tica de multa morat&oacute;ria no percentual de 2% (dois por cento) e juros de mora de 1% (um por cento) ao m&ecirc;s, encargos esses incidentes sobre o valor do d&eacute;bito atualizado de acordo com o &iacute;ndice estabelecido no item <strong>&ldquo;VII &ndash; DO REAJUSTE CONTRATUAL&rdquo;</strong> do Quadro Resumo, calculado &ldquo;pro rata die&rdquo; a partir da data de vencimento do respectivo documento de cobran&ccedil;a at&eacute; a data do efetivo pagamento.</p>

        <h3><strong>CL&Aacute;USULA QUINTA &ndash; DAS OBRIGA&Ccedil;&Otilde;ES DA CRYSTAL BMC</strong></h3>

        <p><strong>5.1.</strong> Garantir a qualidade dos Servi&ccedil;os, conforme o disposto no Contrato e seus Anexos.</p>

        <p><strong>5.2.</strong> Prestar os servi&ccedil;os t&eacute;cnicos de suporte e manuten&ccedil;&atilde;o relacionados com o Servi&ccedil;o, nos prazos e condi&ccedil;&otilde;es acordadas.</p>

        <p><strong>5.3.</strong> Manter os Servi&ccedil;os em conformidade com a regulamenta&ccedil;&atilde;o, conforme aplic&aacute;vel.</p>

        <h3><strong>CL&Aacute;USULA SEXTA &ndash; OBRIGA&Ccedil;&Otilde;ES DO CLIENTE</strong></h3>

        <p><strong>6.1.</strong> O CLIENTE se obriga a:</p>

        <p><strong>6.1.1.</strong> Efetuar os pagamentos devidos pela contrata&ccedil;&atilde;o &agrave; <strong>CRYSTAL BMC</strong>, conforme o prazo e as condi&ccedil;&otilde;es estabelecidos no Contrato e na Ordem de Servi&ccedil;o.</p>

        <p><strong>6.1.2.</strong> Se manter unicamente respons&aacute;vel pelo uso que d&aacute; aos Servi&ccedil;os.</p>

        <p><strong>6.1.3.</strong> Manter, segundo as melhores pr&aacute;ticas de mercado, estrutura de seguran&ccedil;a de informa&ccedil;&atilde;o, prote&ccedil;&atilde;o de dados e compliance;</p>

        <p><strong>6.1.4.</strong> Obter &agrave;s suas exclusivas expensas, as devidas licen&ccedil;as, certificados e/ou autoriza&ccedil;&otilde;es e demais documentos de car&aacute;ter regulat&oacute;rio, jur&iacute;dico, t&eacute;cnico e de seguran&ccedil;a que se fa&ccedil;am necess&aacute;rios para a fiel consecu&ccedil;&atilde;o do objeto do presente Contrato.</p>

        <p><strong>6.1.5.</strong> Se manter unicamente respons&aacute;vel por suas a&ccedil;&otilde;es e pelas a&ccedil;&otilde;es de seu Usu&aacute;rio Final durante o uso da Plataforma da <strong>CRYSTAL</strong>;</p>

        <p><strong>6.1.6.</strong> N&atilde;o compartilhar suas credenciais para acessar os Servi&ccedil;os;</p>

        <p><strong>6.1.7.</strong> N&atilde;o usar a Plataforma para fins ilegais, respondendo por qualquer dano ou falha decorrente da inobserv&acirc;ncia do estabelecido na presente cl&aacute;usula perante si, perante a <strong>CRYSTAL BMC</strong> ou perante terceiros;</p>

        <p><strong>6.1.8.</strong> N&atilde;o acessar informa&ccedil;&otilde;es, recursos ou outras ferramentas desenvolvidas pela <strong>CRYSTAL BMC</strong> que o <strong>CLIENTE</strong> n&atilde;o esteja expressamente autorizado a acessar.</p>

        <p><strong>6.1.9.</strong> Caso ocorra uma falha ou incidente nos Servi&ccedil;os, cooperar com a <strong>CRYSTAL BMC</strong>, sempre que poss&iacute;vel, provendo informa&ccedil;&otilde;es que auxiliem a <strong>CRYSTAL BMC</strong> a compreender as circunst&acirc;ncias em que tal falha e/ou incidente ocorreu.</p>

        <p><strong>6.1.10.</strong> N&atilde;o ir&aacute; traduzir, modificar, descompilar, decompor e/ou aplicar engenharia reversa nos Servi&ccedil;os;</p>

        <p><strong>6.1.11.</strong> Notificar acerca de qualquer uso indevido dos Servi&ccedil;os, bem como sobre qualquer viola&ccedil;&atilde;o de seguran&ccedil;a ou acesso n&atilde;o autorizado.</p>

        <p><strong>6.1.12.</strong> Orientar seus colaboradores a buscarem o suporte da <strong>CRYSTAL BMC</strong> caso identifiquem algum comportamento inesperado ou mau funcionamento. &Eacute; proibido que terceiros n&atilde;o autorizados pela <strong>CRYSTAL BMC</strong> interfiram nos Servi&ccedil;os.</p>

    ';

    $texto[3] = '
       <h3><strong>CL&Aacute;USULA S&Eacute;TIMA &ndash; DA RESCIS&Atilde;O</strong></h3>

        <p><strong>7.1.</strong> Caso n&atilde;o haja manifesta&ccedil;&atilde;o por nenhuma das partes com anteced&ecirc;ncia m&iacute;nima de 60 (sessenta) dias do vencimento do Contrato, esse prorrogar-se-&aacute; automaticamente por igual per&iacute;odo e assim sucessivamente por iguais per&iacute;odos, podendo ser rescindido, antecipadamente, por qualquer das partes, sem justo motivo, sem qualquer &ocirc;nus ou penalidades.</p>

        <p><strong>7.2.</strong> O presente Contrato poder&aacute; ser rescindido por justa causa, independentemente do aviso pr&eacute;vio, nas seguintes hip&oacute;teses:</p>

        <p><strong>7.2.1.</strong> Pela <strong>CRYSTAL BMC</strong>, em caso de atraso nos pagamentos de maneira injustificada pelo <strong>CLIENTE</strong> por prazo superior a 30 (trinta) dias, contados de seu vencimento;</p>

        <p><strong>7.2.2.</strong> Em caso de inadimplemento por qualquer das Partes de qualquer obriga&ccedil;&atilde;o prevista neste Contrato, ap&oacute;s transcorrido o prazo de cura de 30 (trinta) dias sem que o descumprimento tenha sido sanado, contados da notifica&ccedil;&atilde;o enviada pela outra Parte informando o descumprimento;</p>

        <p><strong>7.2.3.</strong> Em caso de requerimento, decreta&ccedil;&atilde;o ou homologa&ccedil;&atilde;o de interven&ccedil;&atilde;o, regime de administra&ccedil;&atilde;o especial tempor&aacute;ria, fal&ecirc;ncia, dissolu&ccedil;&atilde;o, liquida&ccedil;&atilde;o, extin&ccedil;&atilde;o ou recupera&ccedil;&atilde;o judicial ou extrajudicial de qualquer das Partes;</p>

        <p><strong>7.2.4.</strong> Pr&aacute;tica de atividades consideradas ilegais por uma das Partes;</p>

        <p><strong>7.2.5.</strong> Pr&aacute;tica de atividades que possam gerar dano reputacional a uma das Partes;</p>

        <p><strong>7.2.6.</strong> Se n&atilde;o forem renovadas ou forem canceladas, revogadas ou suspensas as autoriza&ccedil;&otilde;es, concess&otilde;es, alvar&aacute;s e licen&ccedil;as necess&aacute;rias para o regular exerc&iacute;cio das atividades do CLIENTE ou para a presta&ccedil;&atilde;o dos Servi&ccedil;os;</p>

        <p><strong>7.3.</strong> Em caso de rescis&atilde;o deste Contrato pela <strong>CRYSTAL BMC</strong>, o <strong>CLIENTE</strong> pagar&aacute; a integralidade dos valores vincendos.</p>

        <p><strong>7.3.1.</strong> A rescis&atilde;o deste Contrato n&atilde;o eximir&aacute;, em qualquer hip&oacute;tese, o <strong>CLIENTE</strong> de sua obriga&ccedil;&atilde;o de efetuar o pagamento dos valores devidos &agrave; <strong>CRYSTAL BMC</strong> pelo per&iacute;odo anterior &agrave; data da efetiva rescis&atilde;o deste Contrato.</p>

        <p><strong>7.3.2.</strong> Em caso de rescis&atilde;o deste Contrato pelo <strong>CLIENTE</strong>, eventuais valores devidos pela <strong>CRYSTAL BMC</strong> estar&atilde;o sujeitos &agrave;s limita&ccedil;&otilde;es estabelecidas no presente Contrato.</p>

        <p><strong>7.4.</strong> O CLIENTE tem ci&ecirc;ncia e concorda que eventuais imprecis&otilde;es, inexatid&otilde;es, erros, falhas e/ou outras diverg&ecirc;ncias relacionadas aos resultados gerados a partir do uso dos Servi&ccedil;os n&atilde;o constituir&atilde;o, em qualquer circunst&acirc;ncia, hip&oacute;tese para a rescis&atilde;o antecipada do Contrato.</p>

        <p><strong>7.5.</strong> Todas as previs&otilde;es de propriedade intelectual, remunera&ccedil;&atilde;o e limita&ccedil;&otilde;es de responsabilidade permanecer&atilde;o vigentes mesmo ap&oacute;s a extin&ccedil;&atilde;o deste Contrato e dos documentos a eles vinculados.</p>

        <h3><strong>CL&Aacute;USULA OITAVA &ndash; DAS GARANTIAS E LIMITA&Ccedil;&Atilde;O DA RESPONSABILIDADE</strong></h3>

        <p><strong>8.1.</strong> O <strong>CLIENTE</strong> declara e garante que analisou e concordou com todos os termos, pol&iacute;ticas e anexos aplic&aacute;veis aos Servi&ccedil;os</p>

        <p><strong>8.2. </strong>O <strong>CLIENTE</strong> reconhece que o acesso aos Servi&ccedil;os n&atilde;o implica o direito &agrave; sua reprodu&ccedil;&atilde;o, venda, licenciamento, aluguel ou qualquer outra forma de transfer&ecirc;ncia.</p>

        <p><strong>8.3. </strong>O <strong>CLIENTE</strong> concorda e aceita expressamente que o uso do Servi&ccedil;o, por si e por seus Usu&aacute;rios Finais, &eacute; feito sob sua inteira responsabilidade e risco.</p>

        <p><strong>8.4.</strong> Os Servi&ccedil;os s&atilde;o utilizados &ldquo;no estado em que se encontram&rdquo;, &ldquo;com todas as falhas e defeitos&rdquo;, &ldquo;conforme dispon&iacute;vel&rdquo; e sem garantias de qualquer esp&eacute;cie, sejam expressas ou impl&iacute;citas.</p>

        <p><strong>8.5. </strong>O <strong>CLIENTE</strong> reconhece que a CRYSTAL BMC n&atilde;o garante a disponibilidade ininterrupta do Servi&ccedil;o, nem a aus&ecirc;ncia de quaisquer problemas t&eacute;cnicos e/ou operacionais, incluindo falhas, perda de informa&ccedil;&otilde;es, suspens&otilde;es, interrup&ccedil;&otilde;es e outros problemas de desempenho.</p>

        <p><strong>8.6.</strong> <strong>A CRYSTAL BMC</strong> n&atilde;o assegura a impossibilidade de seus sistemas e servidores serem atacados, invadidos, modificados ou lesados de qualquer forma por terceiros.</p>

        <p><strong>8.7.</strong> A <strong>CRYSTAL BMC</strong> n&atilde;o ser&aacute; respons&aacute;vel por quaisquer danos sofridos pelo CLIENTE, pelos Usu&aacute;rios Finais e/ou por terceiros decorrentes do uso inapropriado do Servi&ccedil;o, tampouco por incidentes de seguran&ccedil;a causados exclusivamente pelo <strong>CLIENTE</strong>, em decorr&ecirc;ncia de mau uso, imper&iacute;cia ou em descumprimento &agrave;s instru&ccedil;&otilde;es e documenta&ccedil;&atilde;o da CRYSTAL BMC.</p>

        <p><strong>8.8.</strong> <strong>A CRYSTAL</strong> n&atilde;o responder&aacute; por danos, incluindo lucros cessantes ou perdas financeiras, que venham a surgir em raz&atilde;o da presta&ccedil;&atilde;o do Servi&ccedil;o, em rela&ccedil;&atilde;o ao CLIENTE, aos Usu&aacute;rios Finais e/ou qualquer terceiro.</p>

        <p><strong>8.9.</strong> A Parte que sofrer demandas judiciais ou administrativas decorrentes de terceiros da outra parte receber&aacute; reembolso das despesas e a parte causadora do dano ser&aacute; respons&aacute;vel pelas obriga&ccedil;&otilde;es exigidas, isentando a parte lesada de qualquer responsabilidade ou perdas.</p>

        <h3><strong>CL&Aacute;USULA NONA &ndash; DO COMBATE &Agrave; CORRUP&Ccedil;&Atilde;O E LAVAGEM DE DINHEIRO</strong></h3>

        <p><strong>9.1.</strong> As Partes declaram, por si e por seus Representantes, que atuam em conformidade com todas as leis e regulamenta&ccedil;&otilde;es relacionadas a combate e preven&ccedil;&atilde;o &agrave; corrup&ccedil;&atilde;o e lavagem de dinheiro.</p>

        <p><strong>9.2.</strong> As Partes declaram estar ciente que n&atilde;o realizaram, n&atilde;o realizam e n&atilde;o realizar&atilde;o quaisquer atos ou pr&aacute;ticas que, direta ou indiretamente, envolvam oferecimento, promessas, suborno, extors&atilde;o, autoriza&ccedil;&atilde;o, solicita&ccedil;&atilde;o, aceite, pagamento, entrega ou qualquer outro ato relacionado a vantagem pecuni&aacute;ria indevida ou qualquer outro favorecimento ilegal em desconformidade com a legisla&ccedil;&atilde;o mencionada acima e aplic&aacute;vel, inclusive as relativas &agrave; corrup&ccedil;&atilde;o e lavagem de dinheiro.</p>

        <p><strong>9.3.</strong> As Partes declaram que n&atilde;o est&atilde;o envolvidas com qualquer alega&ccedil;&atilde;o de crime de lavagem de dinheiro, delito financeiro, financiamento de atividades il&iacute;citas ou atos contra a administra&ccedil;&atilde;o p&uacute;blica, corrup&ccedil;&atilde;o, fraude em licita&ccedil;&otilde;es ou suborno.</p>

        <p><strong>9.4.</strong> As Partes declaram que, direta ou indiretamente, n&atilde;o ir&atilde;o receber, transferir, manter, usar ou esconder recursos que decorram de qualquer atividade il&iacute;cita, bem como n&atilde;o ir&atilde;o contratar como empregado ou de alguma forma manter relacionamento profissional com pessoas f&iacute;sicas ou jur&iacute;dicas envolvidas em atividades criminosas, em especial pessoas investigadas pelos delitos previstos nas leis anticorrup&ccedil;&atilde;o, de lavagem de dinheiro, tr&aacute;fico de drogas e terrorismo.</p>

    ';

    $texto[4] = '
        <h3><strong>CL&Aacute;USULA D&Eacute;CIMA &ndash; DA PROPRIEDADE INTELECTUAL </strong></h3>

        <p><strong>10.1.</strong> Os direitos de propriedade intelectual da <strong>CRYSTAL BMC</strong> (inclusive customiza&ccedil;&otilde;es solicitadas ou n&atilde;o pelo <strong>CLIENTE</strong>) e demais materiais intelectuais que os comp&otilde;em, s&atilde;o de propriedade exclusiva da <strong>CRYSTAL BMC</strong>.</p>

        <p><strong>10.1.1.</strong> O CLIENTE n&atilde;o tem qualquer autoriza&ccedil;&atilde;o para agir em nome da CRYSTAL BMC ou promover qualquer registro em autoridade competente.</p>

        <p><strong>10.2.</strong> O CLIENTE n&atilde;o poder&aacute; licenciar, revender, copiar, modificar, distribuir, transferir, fazer engenharia reversa, dos Servi&ccedil;os, sem a autoriza&ccedil;&atilde;o por escrito da CRYSTAL BMC.</p>

        <p><strong>10.3.</strong> A CRYSTAL BMC &eacute; a &uacute;nica titular e propriet&aacute;ria de qualquer aprendizado sist&ecirc;mico (&ldquo;machine learning&rdquo;) ocorrido no &acirc;mbito dos Servi&ccedil;os por meio de intelig&ecirc;ncia artificial (ou qualquer outra tecnologia), sem que isso implique qualquer viola&ccedil;&atilde;o &agrave; propriedade intelectual do CLIENTE.</p>

        <p><strong>10.4.</strong> Cada Parte dever&aacute; respeitar toda Propriedade Intelectual da outra Parte.</p>

        <p><strong>10.5.</strong> A CRYSTAL BMC pode, a sua discricionariedade, incluir a marca e o nome de seus Clientes em seus materiais de vendas para prospec&ccedil;&otilde;es com potenciais clientes (folder, website, slides e apresenta&ccedil;&otilde;es comerciais).</p>

        <p><strong>10.5.1.</strong> Eventuais press releases sobre a rela&ccedil;&atilde;o comercial entre as Partes dever&atilde;o ser previamente aprovadas.</p>

        <h3><strong>CL&Aacute;USULA D&Eacute;CIMA PRIMEIRA &ndash; DA CONFIDENCIALIDADE</strong></h3>

        <p><strong>11.1. </strong>Cada Parte poder&aacute; revelar informa&ccedil;&otilde;es confidenciais &agrave; outra Parte. As informa&ccedil;&otilde;es confidenciais ser&atilde;o limitadas a informa&ccedil;&otilde;es t&eacute;cnicas, comerciais, financeiras, de neg&oacute;cios e outras informa&ccedil;&otilde;es sens&iacute;veis que n&atilde;o s&atilde;o de conhecimento p&uacute;blico e que foram identificadas como confidenciais pela parte divulgadora.</p>

        <p><strong>11.2.</strong> Cada Parte concorda em manter as informa&ccedil;&otilde;es confidenciais da outra Parte em sigilo e n&atilde;o as divulgar a terceiros sem o consentimento pr&eacute;vio por escrito da outra parte, exceto na medida em que seja necess&aacute;rio para a execu&ccedil;&atilde;o deste Contrato.</p>

        <p><strong>11.3.</strong> Esta obriga&ccedil;&atilde;o de confidencialidade n&atilde;o se aplica a informa&ccedil;&otilde;es que: (a) s&atilde;o ou se tornam publicamente dispon&iacute;veis; (b) foram obtidas de terceiros sem viola&ccedil;&atilde;o de obriga&ccedil;&otilde;es de confidencialidade; (c) foram desenvolvidas independentemente pela parte receptora; ou (d) s&atilde;o exigidas por lei, regulamento ou autoridade.</p>

        <p><strong>11.4.</strong> Esta obriga&ccedil;&atilde;o de confidencialidade permanecer&aacute; em vigor durante a vig&ecirc;ncia deste Contrato e por um per&iacute;odo de 2 (dois) anos ap&oacute;s o t&eacute;rmino deste Contrato.</p>

        <p><strong>11.5.</strong> Ap&oacute;s o t&eacute;rmino deste Contrato, cada Parte dever&aacute; devolver ou destruir todas as informa&ccedil;&otilde;es confidenciais da outra Parte.</p>

        <p><strong>CL&Aacute;USULA D&Eacute;CIMA SEGUNDA &ndash; DA PROTE&Ccedil;&Atilde;O, SEGURAN&Ccedil;A E GUARDA DE DADOS</strong></p>

        <p><strong>12.1.</strong> As Partes, em comum acordo, submetem-se ao cumprimento dos deveres e obriga&ccedil;&otilde;es referentes &agrave; prote&ccedil;&atilde;o de dados pessoais e se obrigam a tratar os Dados Pessoais coletados e/ou compartilhados no &acirc;mbito deste Contrato de acordo com a legisla&ccedil;&atilde;o vigente aplic&aacute;vel, incluindo, mas n&atilde;o se limitando &agrave; Lei Geral de Prote&ccedil;&atilde;o de Dados (&ldquo;<strong>LGPD</strong>&rdquo;). As Partes dever&atilde;o garantir que seus empregados, agentes e subcontratados observem a legisla&ccedil;&atilde;o de prote&ccedil;&atilde;o de dados.</p>

        <p><strong>12.2.</strong> Para fins do presente Contrato, o <strong>CLIENTE </strong>poder&aacute; vir a compartilhar com a <strong>CRYSTAL BMC</strong>:</p>

        <p><strong>(I)</strong> Dados Pessoais dos Representantes do <strong>CLIENTE</strong>, observado que tais Dados Pessoais dos Representantes do CLIENTE ser&atilde;o tratados pela CRYSTAL BMC com a finalidade de gerar credenciais de acesso e viabilizar o manuseio do Software pelos Representantes do <strong>CLIENTE</strong>; e</p>

        <p><strong>(II)</strong> Dados Pessoais de usu&aacute;rios finais, para finalidades relacionadas &agrave; presta&ccedil;&atilde;o dos servi&ccedil;os ora contratados.</p>

        <p><strong>12.2.1.</strong> O <strong>CLIENTE</strong> desde j&aacute; tem ci&ecirc;ncia e concorda que a <strong>CRYSTAL BMC</strong> processar&aacute; as informa&ccedil;&otilde;es obtidas em raz&atilde;o dos servi&ccedil;os prestados, para fins de avaliar, desenvolver, modificar, atualizar e aperfei&ccedil;oar a Plataforma e seus servi&ccedil;os.</p>

        <p><strong>12.3.</strong> O <strong>CLIENTE</strong> assegura que os Dados Pessoais fornecidos &agrave;<strong> CRYSTAL BMC</strong> s&atilde;o obtidos em conformidade com a <strong>LGPD</strong>, bem como outras legisla&ccedil;&otilde;es que regem o tratamento de dados pessoais, realizando todas as medidas necess&aacute;rias como a garantia da transpar&ecirc;ncia dos processos em sua pol&iacute;tica de privacidade e demais documentos aplic&aacute;veis, e obten&ccedil;&atilde;o de consentimento dos Usu&aacute;rios Finais, quando aplic&aacute;vel, para assegurar que a CRYSTAL BMC tenha o direito de tratar tais Dados Pessoais.</p>

        <p><strong>12.4.</strong> &Eacute; parte integrante deste Contrato a Pol&iacute;tica de Privacidade da <strong>CRYSTAL BMC</strong>, que ir&aacute; dispor como a <strong>CRYSTAL BMC</strong> trata os Dados Pessoais em sua Plataforma, com o <strong>CLIENTE </strong>declarando ter ci&ecirc;ncia do conte&uacute;do do referido documento.</p>

        <p><strong>12.5.</strong> <strong>A CRYSTAL BMC</strong> dever&aacute;, desde que por determina&ccedil;&atilde;o legal, realizar o registro de todas as atividades realizadas em seus sistemas/ambientes (&ldquo;Registros&rdquo;) no m&iacute;nimo enquanto viger este Contrato, incluindo qualquer atividade relativa a Dados Pessoais tratados sob determina&ccedil;&atilde;o do <strong>CLIENTE</strong>, de modo a permitir a identifica&ccedil;&atilde;o de quem as realizou.</p>

        <p>Tais Registros poder&atilde;o conter:</p>

        <p><strong>(I) </strong>A&ccedil;&atilde;o;</p>

        <p><strong>(II)</strong> Identifica&ccedil;&atilde;o de usu&aacute;rios do sistema;</p>

        <p><strong>(III)</strong> Dados de IP no momento da a&ccedil;&atilde;o;</p>

        <p><strong>(IV)</strong> Data/hora da a&ccedil;&atilde;o, com refer&ecirc;ncia UTC (Universal Time Coordinated), sendo que os rel&oacute;gios de seus sistemas est&atilde;o sincronizados com a hora legal brasileira e de acordo com o protocolo NTP (ntp.br) de sincroniza&ccedil;&atilde;o dos rel&oacute;gios; e</p>

        <p><strong>(V)</strong> Session ID da conex&atilde;o utilizada.</p>

        <p><strong>12.6</strong>. Os Registros poder&atilde;o ser utilizados com a finalidade de:</p>

        <p><strong>(I)</strong> identificar e atender o <strong>CLIENTE </strong>e cumprir as obriga&ccedil;&otilde;es do Contrato;</p>

        <p>(<strong>II)</strong> aperfei&ccedil;oar o Software;</p>

        <p><strong>(III)</strong> resguardar direitos e obriga&ccedil;&otilde;es relacionadas ao uso do Software e</p>

        <p><strong>(IV)</strong> cumprir ordem judicial e/ou de autoridade administrativa.</p>

        <p><strong>12.7</strong>. No &acirc;mbito da presta&ccedil;&atilde;o dos servi&ccedil;os, as medidas de seguran&ccedil;a adotadas pela <strong>CRYSTAL BMC</strong> para a transmiss&atilde;o e armazenamento podem ser consultadas em: https:// becrystal.finance/security/.</p>
    ';

    $texto[5] = '
        <h3><strong>CL&Aacute;USULA D&Eacute;CIMA TERCEIRA &ndash; DISPOSI&Ccedil;&Otilde;ES GERAIS</strong></h3>

        <p><strong>13.1.</strong> Em caso de diverg&ecirc;ncia entre o conte&uacute;do da Ordem de Servi&ccedil;o e as Condi&ccedil;&otilde;es Gerais, prevalecer&aacute; o disposto na Ordem de Servi&ccedil;o.</p>

        <p><strong>13.2.</strong> Este Contrato n&atilde;o cria nenhuma forma de sociedade, associa&ccedil;&atilde;o, joint venture, ag&ecirc;ncia, cons&oacute;rcio, ou responsabilidade solid&aacute;ria entre as Partes.</p>

        <p><strong>13.3.</strong> Este Contrato n&atilde;o cria, direta ou indiretamente, qualquer v&iacute;nculo empregat&iacute;cio, obriga&ccedil;&atilde;o ou responsabilidade entre as Partes em rela&ccedil;&atilde;o aos profissionais da outra Parte.</p>

        <p><strong>13.3.1.</strong> Cada Parte &eacute; exclusivamente respons&aacute;vel por todos os encargos decorrentes de legisla&ccedil;&atilde;o vigente sobre seus pr&oacute;prios colaboradores.</p>

        <p><strong>13.4.</strong> Visando o aprimoramento e a melhoria dos servi&ccedil;os prestados, a <strong>CRYSTAL BMC</strong> poder&aacute;, a qualquer tempo, alterar os termos do Contrato, seus anexos e/ou pol&iacute;ticas, sem necessidade de aviso pr&eacute;vio ou acordo por escrito.</p>

        <p><strong>13.5.</strong> Mediante justificativa fundamentada, a <strong>CRYSTAL BMC</strong> poder&aacute; auditar o <strong>CLIENTE</strong>, com a finalidade de verificar se os Servi&ccedil;os est&atilde;o sendo utilizados em cumprimento com o Contrato e a lei.</p>

        <p><strong>13.5.1.</strong> As auditorias dever&atilde;o ser agendadas previamente e realizadas com a colabora&ccedil;&atilde;o do <strong>CLIENTE</strong>. Os custos de auditoria dever&atilde;o ser pagos pelo <strong>CLIENTE</strong>, caso a seja apurado que esta usou o Servi&ccedil;o em desacordo com o Contrato e a lei.</p>

        <p><strong>13.5.2</strong> Qualquer aditamento ou altera&ccedil;&atilde;o a este Contrato somente ser&aacute; v&aacute;lida se feito por meio de aditivo contratual, escrito e assinado pelas Partes.</p>

        <p><strong>13.5.3</strong> Todas as obriga&ccedil;&otilde;es e condi&ccedil;&otilde;es aqui estipuladas obrigam as Partes e seus sucessores a qualquer t&iacute;tulo.</p>

        <p><strong>13.5.4</strong> Todas as notifica&ccedil;&otilde;es ou comunica&ccedil;&otilde;es dadas segundo o presente Contrato, de uma Parte &agrave; outra, dever&atilde;o ser endere&ccedil;adas somente por via postal atrav&eacute;s de carta registrada ou, por telegrama, todos com aviso de recebimento, para os representantes legais nos endere&ccedil;os constantes na qualifica&ccedil;&atilde;o das Partes.</p>

        <p><strong>13.6.</strong> A toler&acirc;ncia das Partes por qualquer descumprimento de obriga&ccedil;&otilde;es assumidas neste Contrato n&atilde;o ser&aacute; considerada nova&ccedil;&atilde;o, ren&uacute;ncia ou desist&ecirc;ncia a qualquer direito, constituindo mera liberalidade, n&atilde;o impedindo a Parte tolerante de exigir da outra parte o fiel cumprimento do Contrato, a qualquer tempo.</p>

        <p><strong>13.7.</strong> O presente Contrato constitui o acordo final entre as Partes com rela&ccedil;&atilde;o &agrave;s mat&eacute;rias aqui expressamente tratadas, superando e substituindo todas as propostas, acordos, entendimentos e declara&ccedil;&otilde;es anteriores, orais ou escritos.</p>

        <p><strong>13.8.</strong> O contrato &eacute; regido pelas leis da Rep&uacute;blica Federativa do Brasil.</p>

        <p><strong>13.9.</strong> Cada uma das Partes declara, garante e concorda, reciprocamente, que a celebra&ccedil;&atilde;o, outorga e execu&ccedil;&atilde;o deste Contrato foi devidamente autorizada pelos seus leg&iacute;timos representantes legais, na forma dos seus respectivos documentos societ&aacute;rios, sendo que o fornecimento de eventual informa&ccedil;&atilde;o inver&iacute;dica, incompleta ou inid&ocirc;nea ser&aacute; considerado infra&ccedil;&atilde;o aos princ&iacute;pios da informa&ccedil;&atilde;o e boa-f&eacute; contratual, respondendo a parte que assim as prestou civil e criminalmente, restando claro que este contrato constitui obriga&ccedil;&atilde;o legal, v&aacute;lida e vinculante entre as Partes. E, por estarem justas e contratadas, as partes acima designadas celebram o presente instrumento em 02 (duas) vias de igual teor e forma na presen&ccedil;a das testemunhas abaixo assinadas.</p>

        <table>
            <tbody>
                <tr>
                    <td>Contrato assinado digitalmente nos termos da MEDIDA PROVIS&Oacute;RIA No 2.200-2, DE 24 DE AGOSTO DE 2001 e LEI N&ordm; 14.063, DE 23 DE SETEMBRO DE 2020, entre CRYSTAL BMC e CLIENTE.</td>
                </tr>
            </tbody>
        </table>
    ';

    $texto[6] = '
        <h3><strong>ANEXO I - ACORDO DE N&Iacute;VEL DE SERVI&Ccedil;O</strong></h3>

        <p><strong>1.</strong> A CRYSTAL BMC far&aacute; o poss&iacute;vel para manter os Servi&ccedil;os funcionando corretamente e corrigir quaisquer problemas que possam ocorrer. Manter a disponibilidade m&iacute;nima de 95% (noventa e cinco por cento) do sistema e de suporte, por 7 (sete) dias na semana e 24 (vinte e quatro) horas no dia, garantindo, adicionalmente, durante o hor&aacute;rio comercial a disponibilidade m&iacute;nima de 99,7 % (noventa e nove v&iacute;rgula sete por cento).</p>

        <p><strong>1.1.</strong> N&atilde;o caracterizar&aacute; indisponibilidade do sistema a ocorr&ecirc;ncia dos seguintes eventos:</p>

        <p><strong>a)</strong> execu&ccedil;&atilde;o de manuten&ccedil;&atilde;o, comunicada pela <strong>CRYSTAL BMC</strong> com m&iacute;nimo de 15 (quinze) dias de anteced&ecirc;ncia;</p>

        <p><strong>b)</strong> opera&ccedil;&atilde;o inadequada do software e dos equipamentos pelo <strong>CLIENTE</strong>, em desacordo com as instru&ccedil;&otilde;es da <strong>CRYSTAL BMC</strong>;</p>

        <p><strong>c)</strong> falhas ocasionadas em rela&ccedil;&atilde;o &agrave; infraestrutura do <strong>CLIENTE </strong>ou na rede de comunica&ccedil;&atilde;o;</p>

        <p><strong>2.</strong> O <strong>CLIENTE </strong>tem conhecimento que toda a comunica&ccedil;&atilde;o por interm&eacute;dio da rede mundial de computadores (internet) est&aacute; sujeita a interrup&ccedil;&otilde;es e/ou atrasos, podendo ocorrer problemas de transmiss&atilde;o ou de recep&ccedil;&atilde;o das informa&ccedil;&otilde;es acessadas.</p>

        <p><strong>3.</strong> Toda e qualquer responsabilidade da <strong>CRYSTAL BMC</strong> limita-se, &uacute;nica e exclusivamente, aos sistemas desenvolvidos sob sua autoria. <strong>A CRYSTAL BMC</strong> n&atilde;o responder&aacute; pela qualidade de produtos de terceiros, mesmo que tais produtos de terceiros precisem ser incorporados ao sistema.</p>

        <table>
            <tbody>
                <tr>
                    <td><strong>Contrato assinado digitalmente nos termos da MEDIDA PROVIS&Oacute;RIA No 2.200-2, DE 24 DE AGOSTO DE 2001 e LEI N&ordm; 14.063, DE 23 DE SETEMBRO DE 2020, entre CRYSTAL BMC e CLIENTE.</strong></td>
                </tr>
            </tbody>
        </table>

        <h3><strong>ANEXO II - CONDI&Ccedil;&Otilde;ES ESPECIAIS (OPEN FINANCE AGREGA&Ccedil;&Atilde;O DE DADOS) </strong></h3>

        <p>Esse Anexo Open Finance Agrega&ccedil;&atilde;o de Dados, somente &eacute; aplic&aacute;vel caso o <strong>CLIENTE</strong> tenha contratado o Servi&ccedil;o Open Finance Data Aggregation.</p>

        <p>O servi&ccedil;o de Open Finance Agrega&ccedil;&atilde;o de Dados &eacute; prestado pela: <strong>CRYSTAL INSTITUI&Ccedil;&Atilde;O DE PAGAMENTO LTDA.</strong></p>

        <h3><strong>CL&Aacute;USULA PRIMEIRA &ndash; DO OBJETO</strong></h3>

        <p><strong>1.1.</strong> O objeto do presente Contrato consiste em regular a contrata&ccedil;&atilde;o do servi&ccedil;o de Agrega&ccedil;&atilde;o de Dados no &acirc;mbito do Open Finance, por meio de integra&ccedil;&atilde;o via APIs da CRYSTAL BMC l (&ldquo;Servi&ccedil;o Open Finance Agrega&ccedil;&atilde;o de Dados OFDA&rdquo;).</p>

        <h3><strong>CL&Aacute;USULA SEGUNDA &ndash; DAS OBRIGA&Ccedil;&Otilde;ES ADICIONAIS DO CLIENTE</strong></h3>

        <p><strong>2.1.</strong> Se manter unicamente respons&aacute;vel pelo uso que d&aacute; ao Servi&ccedil;o OFDA e as informa&ccedil;&otilde;es compartilhadas e/ou obtidas por meio deste Servi&ccedil;o.</p>

        <p><strong>2.2.</strong> Observar e respeitar as defini&ccedil;&otilde;es de experi&ecirc;ncia do usu&aacute;rio previstas na regula&ccedil;&atilde;o aplic&aacute;vel ao Open Finance, n&atilde;o realizando qualquer modifica&ccedil;&atilde;o, que n&atilde;o tenha sido acordada, por escrito, com a <strong>CRYSTAL BMC</strong>.</p>

        <p><strong>2.3.</strong> No caso de descumprimento desta cl&aacute;usula pelo <strong>CLIENTE</strong>, as limita&ccedil;&otilde;es de responsabilidade previstas neste contrato n&atilde;o ser&atilde;o aplic&aacute;veis e o <strong>CLIENTE </strong>ser&aacute; respons&aacute;vel por ressarcir a <strong>CRYSTAL BMC</strong> de todos os danos, de qualquer natureza, que a <strong>CRYSTAL BMC</strong> possa sofrer.</p>

        <p><strong>2.4.</strong> Implementar nos primeiros n&iacute;veis de seus principais canais com o Usu&aacute;rio Final, a ser determinado de forma conjunta com a <strong>CRYSTAL BMC</strong>, um ambiente Open Finance, de forma a permitir acesso r&aacute;pido e f&aacute;cil a funcionalidade de &ldquo;Gest&atilde;o do Consentimento&rdquo;, de acordo com os requisitos do Manual de Experi&ecirc;ncia do Usu&aacute;rio do Open Finance.</p>

        <p><strong>2.5.</strong> Informar a <strong>CRYSTAL BMC</strong>, imediatamente, caso entre com pedido de autoriza&ccedil;&atilde;o perante o Banco Central do Brasil para se tornar uma institui&ccedil;&atilde;o financeira, institui&ccedil;&atilde;o de pagamento ou qualquer outro tipo de institui&ccedil;&atilde;o sujeita a regula&ccedil;&atilde;o do Banco Central do Brasil.</p>

        <p><strong>CL&Aacute;USULA TERCEIRA &ndash; DA LIMITA&Ccedil;&Atilde;O DA RESPONSABILIDADE</strong></p>

        <p><strong>3.1.</strong> O <strong>CLIENTE </strong>&eacute; o &uacute;nico respons&aacute;vel pelos servi&ccedil;os prestados aos seus usu&aacute;rios finais, mesmo que esses servi&ccedil;os estejam relacionados ao Servi&ccedil;o Open Finance Agrega&ccedil;&atilde;o de Dados.</p>

        <p><strong>3.2.</strong> O <strong>CLIENTE </strong>dever&aacute; isentar a <strong>CRYSTAL BMC</strong> de qualquer dano, erro ou responsabilidade decorrente da presta&ccedil;&atilde;o desses servi&ccedil;os.</p>

        <p><strong>3.3.</strong> Se a <strong>CRYSTAL BMC</strong> for demandada judicial ou extrajudicialmente pelos Usu&aacute;rios Finais por qualquer motivo relacionado aos servi&ccedil;os prestados pelo CLIENTE, o CLIENTE concorda em (i) ressarcir a CRYSTAL BMC por todos os danos, custos e despesas efetivamente incorridos para defender seus direitos e interesses; e (ii) fazer todos os esfor&ccedil;os necess&aacute;rios para assumir sua responsabilidade e substituir a CRYSTAL BMC no polo passivo de qualquer demanda judicial ou administrativa iniciada pelos usu&aacute;rios finais.</p>

        <p><strong>3.4.</strong> As Partes concordam que, caso a <strong>CRYSTAL BMC</strong> esteja operando em um cen&aacute;rio contingente devido a situa&ccedil;&otilde;es fora de seu controle, como interrup&ccedil;&atilde;o nos servi&ccedil;os do Open Finance, assim como, falha de servidores de terceiros, atrasos nos tempos de resposta de transa&ccedil;&otilde;es, falhas nos sistemas banc&aacute;rios e outros erros ou falhas que possam ocorrer durante esse cen&aacute;rio, a <strong>CRYSTAL BMC</strong> estar&aacute; isenta do cumprimento dos n&iacute;veis de servi&ccedil;o acordados enquanto perdurarem tais eventos.</p>

        <table>
            <tbody>
                <tr>
                    <td><strong>Contrato assinado digitalmente nos termos da MEDIDA PROVIS&Oacute;RIA No 2.200-2, DE 24 DE AGOSTO DE 2001 e LEI N&ordm; 14.063, DE 23 DE SETEMBRO DE 2020, entre CRYSTAL BMC e CLIENTE.</strong></td>
                </tr>
            </tbody>
        </table>
    ';

    $texto[7] = '
        <h3><strong>ANEXO II - CONDI&Ccedil;&Otilde;ES ESPECIAIS (OPEN FINANCE AGREGA&Ccedil;&Atilde;O DE DADOS)</strong></h3>

        <p>Esse Anexo Open Finance Agrega&ccedil;&atilde;o de Dados, somente &eacute; aplic&aacute;vel caso o <strong>CLIENTE </strong>tenha contratado o Servi&ccedil;o Open Finance Data Aggregation. O servi&ccedil;o de Open Finance Agrega&ccedil;&atilde;o de Dados &eacute; prestado pela: <strong>CRYSTAL INSTITUI&Ccedil;&Atilde;O DE PAGAMENTO LTDA. CL&Aacute;USULA PRIMEIRA &ndash; DO OBJETO </strong></p>

        <p><strong>1.1.</strong> O objeto do presente Contrato consiste em regular a contrata&ccedil;&atilde;o do servi&ccedil;o de Agrega&ccedil;&atilde;o de Dados no &acirc;mbito do Open Finance, por meio de integra&ccedil;&atilde;o via APIs da <strong>CRYSTAL BMC</strong> (&ldquo;Servi&ccedil;o Open Finance Agrega&ccedil;&atilde;o de Dados OFDA&rdquo;).</p>

        <h3><strong>CL&Aacute;USULA SEGUNDA &ndash; DAS OBRIGA&Ccedil;&Otilde;ES ADICIONAIS DO CLIENTE</strong></h3>

        <p><strong>2.1.</strong> Se manter unicamente respons&aacute;vel pelo uso que d&aacute; ao Servi&ccedil;o OFDA e as informa&ccedil;&otilde;es compartilhadas e/ou obtidas por meio deste Servi&ccedil;o.</p>

        <p><strong>2.2.</strong> Observar e respeitar as defini&ccedil;&otilde;es de experi&ecirc;ncia do usu&aacute;rio previstas na regula&ccedil;&atilde;o aplic&aacute;vel ao Open Finance, n&atilde;o realizando qualquer modifica&ccedil;&atilde;o, que n&atilde;o tenha sido acordada, por escrito, com a<strong> CRYSTAL BMC</strong>.</p>

        <p><strong>2.3.</strong> No caso de descumprimento desta cl&aacute;usula pelo CLIENTE, as limita&ccedil;&otilde;es de responsabilidade previstas neste contrato n&atilde;o ser&atilde;o aplic&aacute;veis e o <strong>CLIENTE </strong>ser&aacute; respons&aacute;vel por ressarcir a CRYSTAL BMC de todos os danos, de qualquer natureza, que a <strong>CRYSTAL BMC</strong> possa sofrer.</p>

        <p><strong>2.4.</strong> Implementar nos primeiros n&iacute;veis de seus principais canais com o Usu&aacute;rio Final, a ser determinado de forma conjunta com a <strong>CRYSTAL BMC</strong>, um ambiente Open Finance, de forma a permitir acesso r&aacute;pido e f&aacute;cil a funcionalidade de &ldquo;Gest&atilde;o do Consentimento&rdquo;, de acordo com os requisitos do Manual de Experi&ecirc;ncia do Usu&aacute;rio do Open Finance.</p>

        <p><strong>2.5.</strong> Informar a <strong>CRYSTAL BMC</strong>, imediatamente, caso entre com pedido de autoriza&ccedil;&atilde;o perante o Banco Central do Brasil para se tornar uma institui&ccedil;&atilde;o financeira, institui&ccedil;&atilde;o de pagamento ou qualquer outro tipo de institui&ccedil;&atilde;o sujeita a regula&ccedil;&atilde;o do Banco Central do Brasil.</p>

        <h3><strong>CL&Aacute;USULA TERCEIRA &ndash; DA LIMITA&Ccedil;&Atilde;O DA RESPONSABILIDADE</strong></h3>

        <p><strong>3.1.</strong> O <strong>CLIENTE </strong>&eacute; o &uacute;nico respons&aacute;vel pelos servi&ccedil;os prestados aos seus usu&aacute;rios finais, mesmo que esses servi&ccedil;os estejam relacionados ao Servi&ccedil;o Open Finance Agrega&ccedil;&atilde;o de Dados.</p>

        <p><strong>3.2.</strong> O <strong>CLIENTE </strong>dever&aacute; isentar a CRYSTAL BMC de qualquer dano, erro ou responsabilidade decorrente da presta&ccedil;&atilde;o desses servi&ccedil;os.</p>

        <p><strong>3.3.</strong> Se a <strong>CRYSTAL BMC</strong> for demandada judicial ou extrajudicialmente pelos Usu&aacute;rios Finais por qualquer motivo relacionado aos servi&ccedil;os prestados pelo <strong>CLIENTE</strong>, o <strong>CLIENTE </strong>concorda em</p>

        <p><strong>(I)</strong> ressarcir a <strong>CRYSTAL BMC</strong> por todos os danos, custos e despesas efetivamente incorridos para defender seus direitos e interesses; e</p>

        <p><strong>(II)</strong> fazer todos os esfor&ccedil;os necess&aacute;rios para assumir sua responsabilidade e substituir a <strong>CRYSTAL BMC</strong> no polo passivo de qualquer demanda judicial ou administrativa iniciada pelos usu&aacute;rios finais.</p>

        <p><strong>3.4.</strong> As Partes concordam que, caso a <strong>CRYSTAL BMC</strong> esteja operando em um cen&aacute;rio contingente devido a situa&ccedil;&otilde;es fora de seu controle, como interrup&ccedil;&atilde;o nos servi&ccedil;os do Open Finance, assim como, falha de servidores de terceiros, atrasos nos tempos de resposta de transa&ccedil;&otilde;es, falhas nos sistemas banc&aacute;rios e outros erros ou falhas que possam ocorrer durante esse cen&aacute;rio, a <strong>CRYSTAL BMC</strong> estar&aacute; isenta do cumprimento dos n&iacute;veis de servi&ccedil;o acordados enquanto perdurarem tais eventos.</p>

        <table>
            <tbody>
                <tr>
                    <td><strong>Contrato assinado digitalmente nos termos da MEDIDA PROVIS&Oacute;RIA No 2.200-2, DE 24 DE AGOSTO DE 2001 e LEI N&ordm; 14.063, DE 23 DE SETEMBRO DE 2020, entre CRYSTAL BMC e CLIENTE.</strong></td>
                </tr>
            </tbody>
        </table>
    ';

    $texto[8] = '
        <h3><strong>ANEXO III - CONDI&Ccedil;&Otilde;ES ESPECIAIS (OPEN FINANCE INICIA&Ccedil;&Atilde;O DE PAGAMENTO)</strong></h3>

        <p>Esse Anexo somente &eacute; aplic&aacute;vel caso o Cliente tenha contratado o Servi&ccedil;o Open Finance Inicia&ccedil;&atilde;o de Pagamento O servi&ccedil;o de Open Finance Payment Initiation &eacute; prestado pela: <strong>CRYSTAL TECNOLOGIAS LTDA</strong> e seu Parceiro ou pela <strong>CRYSTAL INSTITUI&Ccedil;&Atilde;O DE PAGAMENTO LTDA.</strong></p>

        <h3><strong>CL&Aacute;USULA PRIMEIRA &ndash; DO OBJETO</strong></h3>

        <p><strong>1.1.</strong> O objeto do presente Contrato consiste em regular a contrata&ccedil;&atilde;o do servi&ccedil;o de Inicia&ccedil;&atilde;o de Pagamento no &acirc;mbito do Open Finance (&ldquo;Servi&ccedil;o Open Finance Inicia&ccedil;&atilde;o de Pagamento&rdquo;).</p>

        <h3><strong>CL&Aacute;USULA SEGUNDA &ndash; DAS OBRIGA&Ccedil;&Otilde;ES ADICIONAIS DO CLIENTE</strong></h3>

        <p><strong>2.1.</strong> Implementar processos de risco e compliance que visem evitar que as inicia&ccedil;&otilde;es de pagamento sejam utilizadas como instrumentos para a realiza&ccedil;&atilde;o de atividades il&iacute;citas, incluindo, mas n&atilde;o se limitando a</p>

        <p><strong>(I)</strong> lavagem de dinheiro;</p>

        <p><strong>(II)</strong> financiamento ao terrorismo; e</p>

        <p><strong>(III)</strong> corrup&ccedil;&atilde;o (&ldquo;Processos de Compliance&rdquo;).</p>

        <p><strong>2.2.</strong> Fornece toda a informa&ccedil;&atilde;o ou documenta&ccedil;&atilde;o referente a Usu&aacute;rios Finais que tenha sido coletada durante os Processos de Compliance.</p>

        <p><strong>2.3.</strong> Observar e respeitar as defini&ccedil;&otilde;es de experi&ecirc;ncia do usu&aacute;rio previstas na regula&ccedil;&atilde;o aplic&aacute;vel ao Open Finance, n&atilde;o realizando qualquer modifica&ccedil;&atilde;o, que n&atilde;o tenha sido acordada, por escrito, com a <strong>CRYSTAL BMC</strong>.</p>

        <p><strong>2.4.</strong> No caso de descumprimento desta cl&aacute;usula pelo <strong>CLIENTE</strong>, as limita&ccedil;&otilde;es de responsabilidade previstas neste contrato n&atilde;o ser&atilde;o aplic&aacute;veis e o <strong>CLIENTE </strong>ser&aacute; respons&aacute;vel por ressarcir a <strong>CRYSTAL BMC</strong> de todos os danos, de qualquer natureza, que a <strong>CRYSTAL BMC</strong> possa sofrer.</p>

        <h3><strong>CL&Aacute;USULA TERCEIRA &ndash; DA LIMITA&Ccedil;&Atilde;O DA RESPONSABILIDADE</strong></h3>

        <p><strong>3.1.</strong> <strong>O CLIENTE</strong> &eacute; o &uacute;nico respons&aacute;vel pelos servi&ccedil;os prestados aos seus usu&aacute;rios finais, mesmo que esses servi&ccedil;os estejam relacionados ao Servi&ccedil;o Open Finance Inicia&ccedil;&atilde;o de Pagamento.</p>

        <p><strong>3.2.</strong> O <strong>CLIENTE </strong>dever&aacute; isentar a CRYSTAL BMC de qualquer dano, erro ou responsabilidade decorrente da presta&ccedil;&atilde;o desses servi&ccedil;os.</p>

        <p><strong>3.3.</strong> Se a <strong>CRYSTAL BMC</strong> for demandada judicial ou extrajudicialmente pelos Usu&aacute;rios Finais por qualquer motivo relacionado aos servi&ccedil;os prestados pelo <strong>CLIENTE</strong>, o <strong>CLIENTE </strong>concorda em</p>

        <p><strong>(I)</strong> ressarcir a <strong>CRYSTAL </strong>por todos os danos, custos e despesas efetivamente incorridos para defender seus direitos e interesses; e</p>

        <p><strong>(II)</strong> fazer todos os esfor&ccedil;os necess&aacute;rios para assumir sua responsabilidade e substituir a <strong>CRYSTAL </strong>no polo passivo de qualquer demanda judicial ou administrativa iniciada pelos usu&aacute;rios finais.</p>

        <p><strong>3.4.</strong> As Partes concordam que, caso a <strong>CRYSTAL BMC</strong> esteja operando em um cen&aacute;rio contingente devido a situa&ccedil;&otilde;es fora de seu controle, como interrup&ccedil;&atilde;o nos servi&ccedil;os do SPI, DICT, PIX ou do Open Finance, assim como, falha de servidores de terceiros, atrasos nos tempos de resposta de transa&ccedil;&otilde;es, falhas nos sistemas banc&aacute;rios e outros erros ou falhas que possam ocorrer durante esse cen&aacute;rio, a CRYSTAL BMC estar&aacute; isenta do cumprimento dos n&iacute;veis de servi&ccedil;o acordados enquanto perdurarem tais eventos.</p>

        <p><strong>CL&Aacute;USULA QUARTA &ndash; DO PARCEIRO</strong></p>

        <p><strong>4.1.</strong> Para a presta&ccedil;&atilde;o do Servi&ccedil;o OFPI, a <strong>CRYSTAL BMC</strong> poder&aacute; contar com uma institui&ccedil;&atilde;o parceira, que ter&aacute; um papel cr&iacute;tico na presta&ccedil;&atilde;o do servi&ccedil;o, seja no n&iacute;vel de infraestrutura ou atuando como a institui&ccedil;&atilde;o regulada apta a realizar opera&ccedil;&otilde;es de inicia&ccedil;&atilde;o de pagamento (&ldquo;Parceiro&rdquo;).</p>

        <p><strong>4.2.</strong> A <strong>CRYSTAL BMC</strong>, sem necessidade de aviso e/ou autoriza&ccedil;&atilde;o pr&eacute;via e a seu exclusivo crit&eacute;rio, poder&aacute; alterar o Parceiro.</p>

        <p><strong>4.3.</strong> A <strong>CRYSTAL BMC</strong> e o Parceiro poder&atilde;o recusar a inicia&ccedil;&atilde;o de transa&ccedil;&atilde;o de pagamento, quando constatados ind&iacute;cios de fraude e/ou ilegalidade na transa&ccedil;&atilde;o, conforme crit&eacute;rios internos.</p>

        <p><strong>4.4.</strong> A <strong>CRYSTAL BMC</strong> n&atilde;o precisar&aacute; justificar ao <strong>CLIENTE </strong>as raz&otilde;es que a levaram a recusa da transa&ccedil;&atilde;o.</p>

        <table>
            <tbody>
                <tr>
                    <td><strong>Contrato assinado digitalmente nos termos da MEDIDA PROVIS&Oacute;RIA No 2.200-2, DE 24 DE AGOSTO DE 2001 e LEI N&ordm; 14.063, DE 23 DE SETEMBRO DE 2020, entre CRYSTAL BMC e CLIENTE.</strong></td>
                </tr>
            </tbody>
        </table>
    ';

    $texto[9] = '
        <h3><strong>ANEXO IV - ORDEM DE SERVI&Ccedil;O</strong></h3>
        <p>A seguir, apresentamos a rela&ccedil;&atilde;o de servi&ccedil;os a serem disponibilizados ao <strong>CLIENTE</strong>, juntamente com os valores mensais correspondentes a serem cobrados com base no uso.</p>
        <table>
            <tbody>
                <tr>
                    <td><strong>Contrato assinado digitalmente nos termos da MEDIDA PROVIS&Oacute;RIA No 2.200-2, DE 24 DE AGOSTO DE 2001 e LEI N&ordm; 14.063, DE 23 DE SETEMBRO DE 2020, entre CRYSTAL BMC e CLIENTE.</strong></td>
                </tr>
            </tbody>
        </table>
    ';
?>