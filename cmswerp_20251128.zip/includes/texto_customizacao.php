<?php
    setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
    $data_extenso = strftime('%d de %B de %Y', strtotime('today')); 

    $texto[0] = 
    "
        À  <br> 
        <b> **--CLIENTE--** </b> <br> 
        **--ENDERECO--** - **--BAIRRO--** <br> 
        **--CEP--** - **--CIDADE--** - **--UF--** <br> 
        <br> 
        <b> A/C.: **--REPRESENTANTE_LEGAL--** </b> 
        <br></br> 
        Assunto: Contrato de Customização do Software 
        <br></br> 
        Prezado Senhor,
        <br>
        <p>Primeiramente manifestamos nossos sinceros agradecimentos pela contratação do nosso software, e lhe damos as Boas-Vindas à família <b>C&M SOFTWARE</b>.</p> 
        <p>
            Encaminhamos em anexo o contrato de Customização do Software <b>ROCKET</b>, que será assinado na 
            <b>Plataforma de Assinaturas</b> da <b>D4Sing</b> (especializada em identificação digital), com plena validade jurídica. 
            As assinaturas das pessoas jurídicas da Contratante e Contratada serão realizadas com a utilização de Certificados Digitais <b>e-CNPJ</b>.
        </p> 
        <p>As testemunhas assinarão eletronicamente (sem a necessidade de Certificado Digital), de acordo com as formas de comprovação de autoria e integridade de documentos
        realizadas pela Plataforma de Assinaturas da <b>D4Sing</b>. O passo-a-passo para assinatura do presente instrumento será enviado por <b>e-mail</b>.</p>
    
        Caso contrário, segue anexo o “Contrato de Licenciamento do Software <b>ROCKET®</b>”, é necessário que seja assinado em <b>02 (duas) vias</b> e entregue no endereço de nossa sede:       
        <br>
        <br><b>**--CM_SOFTWARE--**</b>
        <br> A/C: Departamento Jurídico. 
        <br> Alameda Rio Pardo, nº 27 - Alphaville Industrial. 
        <br> 06455-005 – Barueri – SP.        
        <br> Os documentos que devem acompanhar o contrato são:        
        
            <ul>  Cópia simples do Contrato Social/Estatuto Social, bem como última alteração/ata de assembleia; </ul> 
            <ul>  Cartão do CNPJ;  </ul>
            <ul>  Cópia simples do RG e CPF do signatário do Contrato; e, </ul>
            <ul>  Se o signatário não constar do Contrato Social/Estatuto Social, solicitamos cópia da procuração que lhe outorgou poderes. </ul>         
        
        <br>
        Quaisquer dúvidas podem ser encaminhadas para os e-mails contratos@cmsw.com e juridico@cmsw.com, ou pelo telefone (11) 3365-2666.
        <br></br><br></br><br></br><br>
        Atenciosamente
        <br></br><br>       
        <table>
            <thead>
                <th style='text-align:center; width:800px;' >               
                    <small>
                        **--CM_SOFTWARE--**
                        <br>Departamento Jurídico 
                    </small>                               
                </th>
            </thead>
        </table>
    ";

    $texto[1] =
    "          
        <table cellpadding='1' cellspacing='1' style='width:100%'>
            <tbody>
                <tr>
                    <td style='text-align:center;border-bottom:2px solid;'>
                        <h3>Contrato de Customização de Softwares</h3>                        
                    </td>
                </tr>
            </tbody>
        </table>
       
        <table cellpadding='1' cellspacing='4' style='width:100%'> 
            <tbody>
                <tr>
                    <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'><b><small>QUADRO RESUMO</small></b></td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>
                        <b><small>CONTRATADA</small></b>
                        <br></br>
                        <p>
                            <b>**--CM_SOFTWARE--**</b>, pessoa jurídica de direito privado com sede na Alameda Rio Pardo, nº 27, 
                            Bairro Alphaville Industrial, no município de Barueri, Estado de São Paulo, CEP 06455-005, inscrita no CNPJ/MF sob o 
                            nº <b>**--CM_SOFTWARE_CNPJ--**</b>, doravante denominada simplesmente “<b>C&M SOFTWARE</b>”;
                        </p>
                        <br>
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>
                        <b><small>CONTRATANTE</small></b>
                        <br></br>
                        <p>
                            <b> **--CLIENTE--** </b>, pessoa jurídica de direito privado com endereço **--ENDERECO--** - **--BAIRRO--**, na cidade de **--CIDADE--**, Estado de **--UF--**, 
                            CEP **--CEP--**, inscrita no C.N.P.J. nº **--CNPJ--**, neste ato representada na forma de seus atos constitutivos por 
                            <b>**--REPRESENTANTE_LEGAL--**</b>, **--REPRESENTANTE_LEGAL/CARGO--**, C.P.F. nº **--REPRESENTANTE_LEGAL/CPF--** , e-mail: **--REPRESENTANTE_LEGAL/EMAIL--**, 
                            telefone: **--REPRESENTANTE_LEGAL/TELEFONE--** **--REPRESENTANTE_2--** doravante denominada simplesmente <b>“CLIENTE”</b>.
                        </p>
                        <br>
                            <ul>CONTATO RESPONSÁVEL: **--CONTATO_RESPONSAVEL--** - e-mail: **--CONTATO_RESPONSAVEL/EMAIL--** - telefone: **--CONTATO_RESPONSAVEL/TELEFONE--** </ul>                                                       
                            <ul>FINANCEIRO: **--CONTATO_FINANCEIRO--** - e-mail: **--CONTATO_FINANCEIRO/EMAIL--** - telefone: **--CONTATO_FINANCEIRO/TELEFONE--** </ul>
                            **--CONTATO_FINANCEIRO_2--**
                        <br> 
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>    
                        <b><small>OBJETO DO CONTRATO</small></b>
                        <p>
                            A Prestação de Serviços de Customização de Softwares pela <b>C&M SOFTWARE</b> quando for solicitado pelo <b>CLIENTE</b>. 
                        </p>
                        <p>
                            <b>1</b> – Para os fins e efeitos deste Contrato, a cada serviço de customização solicitado, o <b>CLIENTE</b> deverá enviar e-mail à <b>C&M SOFTWARE</b>, pelo endereço 
                            (juridico@cmsw.com ou contratos@cmsw.com) anexando o respectivo Pedido de Serviço assinado e digitalizado, conforme Anexo I (um) do presente Contrato. 
                        </p>
                        <p>
                            <b>2</b> – Fica desde já estabelecido que o signatário do presente Contrato e do Pedido de Serviço será considerado: (i) pessoa autorizada para celebrar este 
                            Contrato e o Pedido de Serviço em nome do <b>CLIENTE</b>, (ii) que concorda, em nome do <b>CLIENTE</b>, com os termos deste Contrato e do respectivo Pedido de Serviço. 
                        </p>                                              
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>    
                        <b><small>PRAZO DE VIGÊNCIA</small></b>
                        <p>
                            O presente Contrato, vigorará pelo prazo de contados a partir da data de assinatura digital, conforme termos da <b>MEDIDA PROVISÓRIA No 2.200-2, DE 24 DE 
                            AGOSTO DE 2001</b> e <b>LEI Nº 14.063, DE 23 DE SETEMBRO DE 2020</b>, ou da forma convencional de assinatura., ou da forma convencional, e poderão ser utilizados 
                            tantos pedidos de Customização de Softwares, quantos necessários conforme <b>ANEXO III – PEDIDO DE SERVIÇO DE CUSTOMIZAÇÃO DE SOFTWARES</b>.  
                        </p>                                                                   
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                        <b><small>PREÇO</small></b>                     
                        <ul>
                            Pela prestação dos serviços objeto deste Contrato o CLIENTE pagará à C&M SOFTWARE por horas técnicas trabalhadas (H/H) o valor de 
                            **--HORA_HOMEM--** **--HORA_HOMEM_EXTENSO--** 
                        </ul>
                        <ul> Os valores não contemplam tributos e serão acrescidos quando da emissão da Nota Fiscal/Fatura. </ul>                       
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                        <b><small>RENOVAÇÃO DO CONTRATO</small></b>                       
                        <p>
                            Caso não haja manifestação por nenhuma das partes com antecedência mínima de 30 (trinta) dias do vencimento do Contrato, esse prorrogar-se-á, 
                            automaticamente, por iguais períodos mantendo-se os modelos do pedido de customização. 
                        </p>                       
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>
                        <b><small>REAJUSTE CONTRATUAL</small></b>                       
                        <p>
                            A cada 12 (doze) meses pelo <b>**--INDICE_REAJUSTE--**</b>, ou qualquer outro índice que venha a substituí-lo, a contar da data de assinatura do presente Contrato. 
                        </p>                               
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>
                        <b><small>FATURAMENTO</small></b>
                        <br></br>
                        <p>
                            O faturamento ocorrerá no primeiro dia útil após o envio do Pedido de Serviço pelo <b>CLIENTE</b> à <b>C&M SOFTWARE</b>, com prazo de pagamento de <b>5 (cinco) dias</b>, 
                            contados da apresentação da respectiva nota fiscal/fatura.    
                        </p>              
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>                       
                        <b><small>FORO</small></b>                  
                        <p>
                            Fica eleito o foro da comarca de Barueri do Estado de São Paulo para dirimir quaisquer questões advindas deste Instrumento, renunciando as partes a 
                            qualquer outro, por mais privilegiado que seja. 
                        </p>
                    </td>
                </tr>               
            </tbody>
        </table>                
    ";

    $texto[2] = 
    "
        <table cellpadding='1' cellspacing='1' style='width:100%'>
            <tbody>
                <tr>
                    <td class='td_minuta' style='text-align:center;border-top:3px solid;border-bottom:3px solid;'>
                        <small><b>CONTRATO DE PRESTAÇÃO DE SERVIÇOS DE CUSTOMIZAÇÃO DE SOFTWARES E OUTRAS AVENÇAS</b></small>
                    </td>
                </tr>
            </tbody>
        </table>
        <p>
            Pelo presente instrumento e na melhor forma de direito, as partes qualificadas no QUADRO RESUMO e considerando que
        </p>
        <p>
            <b>(i)</b> a <b>C&M SOFTWARE</b> é titular exclusiva de todos os direitos autorais e patrimoniais do software Rocket;
        </p>
        <p>
            <b>(ii)</b> as Partes abaixo qualificadas celebraram o respectivo “Contrato de Licenciamento do Software Rocket” nesta mesma data; e,
        </p>
        <p>
            <b>(iii)</b> o <b>CLIENTE</b> poderá solicitar à <b>C&M SOFTWARE</b> modificações (“customizações”) aos parâmetros já existentes do Rocket, que o tornem aderentes às 
            necessidades particulares de sua empresa;
        </p>
        <p>
            <b>(iv)</b> as Partes abaixo qualificadas celebraram o competente “Contrato de Licenciamento do Software Rocket” nesta mesma data; e,
        </p>
        <p>
            <b>RESOLVEM</b>, as partes adiante qualificadas, celebrar o presente Contrato de Prestação de Serviços de Customização de Softwares e Outras Avenças, obedecidos os itens 
            constantes do Quadro Resumo e as cláusulas e condições adiante convencionadas, que reciprocamente estipulam, outorgam e aceitam, a saber:
        </p>        
        <p><b>CLÁUSULA PRIMEIRA: DO OBJETO</b></p>
        <p>
            <b>1.1.</b> A Prestação de Serviços de Customização de Softwares pela <b>C&M SOFTWARE</b> quando for solicitado pelo <b>CLIENTE</b>.
        </p>
        <p>
            <b>1.2.</b> A <b>C&M SOFTWARE</b> prestará os serviços descritos neste Contrato, que serão executados por meio de sua sede, ou de suas futuras filiais, as quais emitirão o 
            correspondente documento fiscal, haja vista serem consideradas, individualmente, como estabelecimentos ou locais, onde a <b>C&M SOFTWARE</b> desenvolve a atividade de 
            prestação de serviço, de modo permanente ou eventual, nos termos do artigo 4º da Lei Complementar nº. 116, de 31.07.2003.
        </p>
        <p><b>CLÁUSULA SEGUNDA: DO PRAZO DE VIGÊNCIA</b></p>
        <p> 
            <b>2.1.</b> O presente contrato terá validade pelo prazo estabelecido no item “<b>VIGÊNCIA</b>” do Quadro Resumo.
        </p>
        <p>
            <b>CLÁUSULA TERCEIRA: PREÇO</b> 
        </p>
        <p>
            <b>3.1.</b> O preço a ser pago pela prestação de serviços ora contratada será calculado com de acordo com as condições e valores estipulados no item <b>“PREÇO”</b> do 
            Quadro Resumo.
        </p>
        <p>
            <b>3.1.1.</b> O preço ajustado contempla as prestações de responsabilidade da <b>C&M SOFTWARE</b>, tais como a execução propriamente dita dos serviços contratados, os 
            encargos sociais, trabalhistas e previdenciários incidentes ou que venham a incidir sobre este contrato ou sobre a prestação de serviços dele objeto, salvo estipulação 
            em contrário.
        </p>
        <p>
            <b>3.2.</b> Serão de responsabilidade do <b>CLIENTE</b> as despesas de viagens referentes ao transporte aéreo ou terrestre (quando o aéreo não for possível) e estadias ocorridas 
            com os profissionais da <b>C&M SOFTWARE</b>, sempre que houver necessidade de deslocamento da equipe da <b>C&M SOFTWARE</b>, a locais fora da região metropolitana de 
            São Paulo/SP e Barueri/SP.
        </p>
        <p>
            <b>3.3.</b> Acordam as Partes que o faturamento decorrente do presente instrumento ocorrerá na forma estabelecida no item <b>“FATURAMENTO”</b> do Quadro Resumo.
        </p>
        <p>
            <b>3.4.</b> Como forma de manter a hegemonia dos custos, as partes elegem, desde já, o índice estabelecido no item <b>“REAJUSTE”</b> do Quadro Resumo, como 
            índice de correção monetária, aplicável aos preços aqui referidos, a cada 12 (doze) meses, a contar da data de assinatura do presente Contrato. 
        </p>
        <p>
            <b>3.4.1.</b> Na falta desse índice ou, se permitido por lei, ou por decisão judicial, será aplicado aos preços qualquer outro índice oficial, de variação diária, ou, se inexistente, 
            de variação mensal, calculando “pro rata die”, e que mais eficientemente elide os efeitos inflacionários da moeda corrente nacional, o qual será eleito mediante comum acordo 
            entre as partes.
        </p>
        <p>
            <b>3.4.2.</b> Quando aplicável e na hipótese de atraso ou ausência de publicação do índice aplicável, a <b>C&M SOFTWARE</b> emitirá as notas fiscais/faturas usando o último índice 
            publicado. Imediatamente após a publicação seguinte do referido índice, a <b>C&M SOFTWARE</b> emitirá os títulos para o pagamento e/ou ressarcimento da diferença entre valor 
            já cobrado e os valores efetivamente devidos, de acordo com o prazo de vencimento estabelecido no item <b>“FATURAMENTO”</b> do Quadro Resumo.
        </p>
        <p>
            <b>3.5.</b> Na hipótese de ocorrerem fatos ou atos que possam prejudicar o equilíbrio econômico financeiro do Contrato, as partes envidarão seus melhores esforços para regular e 
            disciplinar a situação criada, de forma a evitar qualquer perda de natureza econômica, financeira ou outra qualquer.
        </p>
        <p>
            <b>3.6.</b> O inadimplemento de toda e qualquer importância cobrada com base no presente Contrato e seus respectivos Pedidos de Serviços, na data de seu vencimento, implicará na 
            incidência automática de multa moratória no percentual de **--PERCENTUAL_MULTA--** **--PERCENTUAL_MULTA/EXTENSO--** e juros de mora de **--PERCENTUAL_JUROS--** **--PERCENTUAL_JUROS/EXTENSO--** 
            ao mês, encargos esses incidentes sobre o valor do débito atualizado de acordo com o índice estabelecido no item <b>“REAJUSTE”</b> do Quadro Resumo, calculado “pro rata die” a 
            partir da data de vencimento do respectivo documento de cobrança até a data do efetivo pagamento. 
        </p>
    ";

    $texto[3] =
    "
        <p>
            <b>3.7.</b> A prestação dos serviços ora contratada poderá ser suspensa, sem aviso prévio, se a inadimplência do <b>CLIENTE</b> durar mais de 10 (dez) dias, contados da data 
            de vencimento, e neste caso não será reiniciada a não ser que todos os valores devidos sejam pagos na sua totalidade, sem prejuízo do direito da <b>C&M SOFTWARE</b> de 
            rescindir motivadamente o presente Contrato.
        </p>
        <p>
            <b>CLÁUSULA QUARTA: DAS OBRIGAÇÕES DO CLIENTE</b>
        </p>
        <p>
            <b>4.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, o <b>CLIENTE</b> obriga-se a: 
            <ul>
                <b>a)</b> efetuar os pagamentos devidos pela contratação, de acordo com as disposições deste Contrato.
            </ul>
            <ul>
                <b>b)</b> disponibilizar todos os dados/informações, dados e ambientes de terceiros, necessários à execução deste Contrato.
            </ul>
            <ul>
                <b>c)</b> Assumir total responsabilidade por eventuais excessos cometidos por seus prepostos ou operadores;
            </ul>
            <ul>
                <b>d)</b> Permitir livre acesso, aos profissionais designados pela <b>C&M SOFTWARE</b> aos locais onde poderão ser executados os serviços objeto deste Contrato, nos 
                horários estabelecidos para estas tarefas.
            </ul>
        </p>
        <p>
            <b>4.2.</b> O <b>CLIENTE</b> declara que obtém e obteve as devidas autorizações, consentimentos e permissões, especialmente sobre os dados considerados sensíveis pela Lei, quando 
            utilizados, na forma da legislação em vigor, para o tratamento dos dados necessários para execução do software ora licenciado, eximindo a <b>C&M SOFTWARE</b> de qualquer 
            responsabilidade pela obtenção dos devidos consentimentos.
        </p>
        <p>
            <b>CLÁUSULA QUINTA: DAS OBRIGAÇÕES DA C&M SOFTWARE</b>
        </p>
        <p>
            <b>5.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato a <b>C&M SOFTWARE</b> obriga-se a:
            <ul>
                <b>a)</b> executar os serviços objeto deste Contrato, com a sua usual diligência, padrão e com observância das leis aplicáveis.
            </ul>
            <ul>
                <b>b)</b> a <b>C&M SOFTWARE</b> fica impedida de executar qualquer alteração de escopo de customização, supressão ou acréscimo dos serviços previstos no presente contrato, sem 
                que o <b>CLIENTE</b> previamente autorize por escrito, sob a forma de aditivo a este ou na forma de novo contrato.
            </ul>
            <ul> 
                <b>c)</b> responder pela guarda e conservação de quaisquer bens, informações e documentos do <b>CLIENTE</b> eventualmente entregue ou acessados pela <b>C&M SOFTWARE</b>, 
                seus empregados, subcontratados e/u representantes a qualquer título.
            </ul>
        </p>
        <p>
            <b>5.2.</b> Toda e qualquer responsabilidade da <b>C&M SOFTWARE</b> limita-se, única e exclusivamente, aos sistemas desenvolvidos sob sua autoria. A <b>C&M SOFTWARE</b> não responderá 
            pela qualidade de produtos de terceiros, mesmo que tais produtos de terceiros precisem ser incorporados ao sistema.
        </p>
        <p><b>CLÁUSULA SEXTA: DA PROPRIEDADE INTELECTUAL</b></p>
        <p>
            <b>6.1.</b> Na hipótese de quaisquer obras intelectuais serem desenvolvidas ou elaboradas pela <b>C&M SOFTWARE</b>, durante e em função da execução dos serviços ora avençados, as 
            <b>PARTES</b> acordam que os direitos relativos a este produto de trabalho, caracterizado aqui pela obra intelectual derivada ou criada, pertencerá única e exclusivamente 
            ao <b>CLIENTE</b> mediante o pagamento final e total de todos os valores devidos à <b>C&M SOFTWARE</b> sob este instrumento.
        </p>
        <p>
            <b>CLÁUSULA SÉTIMA: DOS TRIBUTOS, ENCARGOS E RESPONSABILIDADE TRABALHISTAS</b>
        </p>
        <p>
            <b>7.1.</b> Cada uma das Partes arcará com seus respectivos tributos, impostos, taxas e contribuições fiscais e parafiscais, exceto se disposto de maneira diversa neste 
            Contrato, inclusive de natureza previdenciária, social e trabalhista, bem como emolumentos, ônus ou encargos de qualquer natureza, decorrentes da celebração deste Contrato e 
            do cumprimento de seu objeto, certo de que sua celebração não acarreta, evidencia e/ou tem o objetivo de estabelecer qualquer vínculo empregatício entre os empregados de cada 
            uma das Partes, de forma que cada uma das Partes “per si”, responderá perante o poder judiciário ou autoridade competente, por eventuais demandas que venham a ser ajuizadas 
            por seus empregados, funcionários e prepostos ou ainda por débitos tributários que tenham sido contraídos individualmente por cada uma das Partes (“Demanda”).
        </p>
        <p>
            <b>7.1.1.</b> Ocorrendo uma Demanda, caberá à Parte responsável apresentar-se em juízo ou autoridade competente como responsável pela demanda, devendo tomar todas as medidas 
            disponíveis e/ou necessárias para manter a Parte inocente indene e à salvo de quaisquer prejuízos e/ou responsabilidade que não lhe sejam atribuídas ou que não tenham dado 
            causa.
        </p>
        <p>
            <b>7.2.</b> Nos casos em que uma das Partes ou seus prepostos, empregados, controladoras, controladas, coligadas ou quaisquer sociedades a ela ligadas, forem condenados e/ou 
            responsabilizados por responsabilidade solidária ou subsidiária como consequência deste Contrato, seja nas esferas administrativa ou judicial, a parte contrária e responsável 
            pela Demanda se obriga a reembolsá-la dos valores estipulados na condenação, bem como pelas custas e despesas do processo, razoavelmente incorridos e independentemente de 
            ação judicial para o recebimento.
        </p>
    
    ";

    $texto[4] =
    "
        <p>
            <b>CLÁUSULA OITAVA: DA RESCISÃO</b>
        </p>
        <p>
            <b>8.1.</b> Este Contrato poderá ser rescindido a qualquer momento e sem quaisquer ônus ou penalidades, por qualquer uma das partes, mediante comunicação por escrito, 
            com antecedência mínima de 30 (trinta) dias da data que pretender efetivar a rescisão.
        </p>
        <p>
            <b>8.1.2.</b> A comunicação mencionada no caput desta Cláusula deve ser enviada a outra Parte via postal e com aviso de recebimento, mediante assinatura do competente 
            representante legal.
        </p>
        <p>
            <b>8.2.</b> Este instrumento poderá ser rescindido, ainda, motivadamente, de forma imediata e de pleno direito:
            <ul>
                <b>a)</b> descumprimento de qualquer das cláusulas do Contrato, desde que não sanada no prazo de 10 (dez) dias a contar do recebimento da notificação da outra Parte neste 
                sentido;
            </ul>
            <ul>
                <b>b)</b> a outra Parte vir a ter a sua falência ou recuperação judicial/extrajudicial requerida ou decretada, ou insolvência civil dos sócios, mesmo que presumida, 
                bem como a condenação de qualquer um dos seus sócios em processos criminais; e,
            </ul>
            <ul>
                <b>c)</b> a outra Parte vir a ter sua idoneidade técnica ou financeira abalada ou o seu quadro societário modificado, de forma a prejudicar a fiel execução de suas 
                obrigações contratuais, a critério da outra Parte.
            </ul>
        </p>
        <p>
            <b>8.2.1.</b> A parte que der causa à rescisão do presente Contrato, de forma motivada, arcará com a multa por quebra de acordo comercial e preços equivalente a 2 (duas) 
            vezes a média de todos os faturamentos ocorridos.
        </p>
        <p>
            <b>8.3.</b> O presente Contrato poderá ser encerrado, sem qualquer ônus, em razão da ocorrência de eventos de caso fortuito ou de força maior, regularmente comprovados, 
            impeditivos da execução deste Contrato. Quando for possível a execução apenas parcial do Contrato, o <b>CLIENTE</b> poderá decidir entre o cumprimento parcial ou o término do 
            Contrato.
        </p>
        <p>
            <b>8.4.</b> O encerramento das atividades, mesmo que voluntário, do <b>CLIENTE</b> ou alienação de direitos ou carteira, não o exime das infrações contratuais e consequentes 
            multas a serem aplicadas.
        </p>
        <p><b>CLÁUSULA NONA: DAS DISPOSIÇÕES GERAIS</b></p>
        <p>
            <b>9.1.</b> O <b>CLIENTE</b>, desde já, autoriza a C&M SOFTWARE a incluir o seu nome na sua lista de clientes, assim como sua divulgação, pelos meios de comunicação 
            próprios, juntamente com os nomes de outros clientes, mas não revelará, comunicará ou de qualquer forma fará propaganda a qualquer terceiro de detalhes deste Contrato.
        </p>
        <p>
            <b>9.2.</b> Nenhuma disposição deste contrato poderá ser interpretada como tendo as Partes estabelecido qualquer forma de sociedade ou associação, de fato ou de direito, 
            remanescendo cada uma das partes com suas obrigações civis, comerciais, trabalhistas e tributárias, de forma autônoma.
        </p>
        <p>
            <b>9.3.</b> Nenhuma das Partes poderá ceder ou transferir, no todo ou em parte, os direitos e obrigações decorrentes deste Contrato, sem a anuência prévia e expressa da 
            outra Parte.
        </p>
        <p>
            <b>9.4.</b> Qualquer aditamento ou alteração a este Contrato somente será válida se feito por meio de aditivo contratual, escrito e assinado pelas Partes.
        </p>
        <p>
            <b>9.5.</b> Todas as obrigações e condições aqui estipuladas obrigam as Partes e seus sucessores a qualquer título.
        </p>
        <p>
            <b>9.6.</b> Todas as notificações ou comunicações dadas segundo o presente Contrato, de uma Parte à outra, deverão ser endereçadas somente por via postal através de carta 
            registrada ou por telegrama, todos com aviso de recebimento, para os representantes legais nos endereços constantes na qualificação das Partes. 
        </p>
        <p>
            <b>9.7.</b> A tolerância de uma Parte com a outra, relativamente a qualquer violação ou descumprimento de quaisquer obrigações ora assumidas, não será considerada moratória, 
            novação ou renúncia a qualquer direito, constituindo mera liberalidade, que não impedirá a Parte tolerante de exigir da outra o fiel cumprimento deste Contrato, a qualquer 
            tempo.
        </p>
        <p>
            <b>9.8.</b> Se qualquer cláusula ou condição deste Contrato vier a ser considerada ilegal, inválida ou inexequível nos termos da legislação brasileira, as demais cláusulas e 
            condições continuarão em pleno vigor e efeito.
        </p>
        <p>
            <b>9.9.</b> O presente Contrato, sem prejuízo dos demais documentos firmados pelas Partes nesta data, constitui o acordo final entre as Partes com relação às matérias aqui 
            expressamente tratadas, superando e substituindo todos os acordos, entendimentos e declarações anteriores, orais ou escritos.
        </p>
        <p>
            <b>9.10.</b> As <b>Partes</b> comprometem-se a não aliciar os profissionais regidos por Contrato de Trabalho e/ou como Prestadores de Serviços que estão envolvidos, direta ou 
            indiretamente, com objeto deste contrato. Esta prática, quando comprovada, motivará a parte afetada à rescisão motivada do presente contrato, aplicando-se, ainda, à <b>Parte</b> 
            afetada, a aplicação do <b>art. 608 do Código Civil</b>.
        </p>
    ";

    $texto[5] =
    "
        <p>
            <b>9.11.</b> Cada uma das Partes declara, garante e concorda, reciprocamente, que a celebração, outorga e execução deste Contrato foi devidamente autorizada pelos seus 
            legítimos representantes legais, na forma dos seus respectivos documentos societários, sendo que o fornecimento de eventual informação inverídica, incompleta ou inidônea 
            será considerado infração aos princípios da informação e boa-fé contratual, respondendo a parte que assim as prestou civil e criminalmente, restando claro que este 
            contrato constitui obrigação legal, válida e vinculante entre as Partes.
        </p>
        <p>
            <b>9.12.</b> As Partes elegem o foro da Comarca conforme declinado no item <b>“FORO”</b> do Quadro Resumo, para dirimir quaisquer dúvidas ou atos oriundos ou relativos a 
            este contrato, renunciando a qualquer outro por mais privilegiado que seja.
        </p>
        <p>
            E assim, por estarem justas e contratadas, as partes assinam o presente em 02 (duas) vias de igual teor, na presença das testemunhas abaixo.
        </p>        
    ";

    $texto[6] = 
    "
        <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>
                <td class='td_minuta' style='text-align:center;border-top:3px solid;border-bottom:3px solid;'>
                    <small><b>ANEXO III – MODELO DO PEDIDO DE SERVIÇO DE CUSTOMIZAÇÃO DE SOFTWARES</b></small>
                </td>
            </tr>
        </tbody>
        </table>

        <table>
            <thead>
                <th style='text-align:center';>               
                    <h5>
                        PEDIDO DE SERVIÇO DE CUSTOMIZAÇÃO DE SOFTWARES 
                    <h5>                               
                </th>
            </thead>
        </table>
        <p>
            <b>1.</b> Escopo: (Descrever) 
        </p>
        <p>
            <b>2.</b> Data de início: (Descrever) 
        </p>
        <p>
            <b>3.</b> Estimativa de horas técnicas para a conclusão do escopo: (Descrever)
        </p>
        <p>
            <b>3.1.</b> Caso o número de horas técnicas trabalhadas ultrapasse a estima de horas acima citada, a <b>C&M SOFTWARE</b> faturará o valor do tempo excedido. 
        </p>
        <p>
            <b>3.2.</b> Caso o número de horas técnicas não ultrapasse a estima de horas acima citada, a <b>C&M SOFTWARE</b> concederá créditos ao <b>CLIENTE</b>, relativos ao número de horas 
            técnicas que não excederam ao tempo estimado, podendo o CLIENTE utilizar esses créditos até 12 (doze) meses contados a partir da conclusão do serviço. 
        </p>
        <p>
            <b>4.</b> Preço: R$ 405,78 (quatrocentos e cinco reais e setenta e oito centavos), por hora técnica trabalhada. Esse valor não inclui tributos que serão acrescidos no 
            momento da fatura. 
        </p>
        <p>
            <b>5.</b> A presente contratação não tem por objeto a cessão de mão-de-obra por parte da <b>CONTRATADA</b> ao </b>CLIENTE</b>, não estando, portanto, sujeita aos termos do artigo 31 da 
            Lei Federal nº 8.212/91, com redação dada pela Lei Federal nº 11.488/07. 
        </p>
        <p>
            <b>6.</b> O presente Pedido de Serviço passará a fazer parte integrante do Contrato de Prestação de Serviços de Customização de Software e Outras Avenças nº XXX. 
        </p>        
    
    "

?>