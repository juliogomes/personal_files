<?php
     setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
     $data_extenso = strftime('%d de %B de %Y', strtotime('today')); 

    $texto[0] =
    "       
        À  <br> 
        <b> **--CLIENTE--** </b> <br> 
        **--ENDERECO--** - **--BAIRRO--** <br> 
        **--CEP--** - **--CIDADE--** - **--UF--** <br> 
        <br> 
        <b> A/C.: **--REPRESENTANTE_LEGAL--** </b> 
        <br></br> 
        Assunto: CONTRATO DE LICENCIAMENTO DE USO DO SOFTWARE FULL STR WEB & PIX 
        <br></br>
        Prezado Senhor,
        <br>
        <p>
            Primeiramente manifestamos nossos sinceros agradecimentos pela contratação do nosso software, e lhes damos Boas-Vindas à família C&M Software.
        </p>
        <p>
            Encaminhamos em anexo o Contrato de Licenciamento de Uso do Software <b> FULL STR WEB & PIX </b> que será assinado na plataforma de assinaturas da <b>D4Sign</b> 
            (especializada em identificação digital), com plena validade jurídica. As assinaturas das pessoas jurídicas da Contratante e Contratada serão realizadas 
            com a utilização de Certificado Digital <b>e-CNPJ</b>.
        </p>
        <p> As testemunhas assinarão eletronicamente (sem a necessidade de Certificado Digital), de acordo com as formas de comprovação de autoria e integridade de documentos 
            realizadas pela plataforma de assinaturas da D4Sign. </p> 
        <p> 
            No caso da assinatura convencional, segue o “Contrato de Licenciamento de Uso do Software FULL STR WEB & PIX”. 
            Necessário seja assinado em 02 (duas) vias e entregue no endereço: 
        </p>
                
        <b>**--CM_SOFTWARE--**</b>
        <br> A/C: Departamento Jurídico. 
        <br> Alameda Rio Pardo, nº 27 - Alphaville Industrial. 
        <br> 06455-005 – Barueri – SP.  

        <br> Os documentos que devem acompanhar o contrato são:        
        
        <ul>  Cópia simples do Contrato Social/Estatuto Social, bem como última alteração/ata de assembleia; </ul> 
        <ul>  Cartão do CNPJ;  </ul>
        <ul>  Cópia simples do RG e CPF do signatário do Contrato; e, </ul>
        <ul>  Se o signatário não constar do Contrato Social/Estatuto Social, solicitamos cópia da procuração que lhe outorgou poderes. </ul>         
    
        <br>
        Quaisquer dúvidas podem ser encaminhadas para os e-mails contratos@cmsw.com e juridico@cmsw.com, ou pelo telefone (11) 3365-2666.
        <br></br><br></br><br></br><br>
        Atenciosamente
        <br></br><br>       
        <table>
            <thead>
                <th style='text-align:center; width:800px;' >               
                    <small>
                        **--CM_SOFTWARE--**
                        <br>Departamento Jurídico 
                    </small>                               
                </th>
            </thead>
        </table>
    ";

    $texto[1] = "          
        <table cellpadding='1' cellspacing='1' style='width:100%'>
            <tbody>
                <tr>
                    <td style='text-align:center;border-bottom:2px solid;'>
                        <h3>Contrato de Licenciamento do Software FULL STR WEB & PIX</h3>                        
                    </td>
                </tr>
            </tbody>
        </table>
       
        <table cellpadding='1' cellspacing='4' style='width:100%'> 
            <tbody>
                <tr>
                    <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'><b><small>QUADRO RESUMO</small></b></td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>
                        <b><small>CONTRATADA</small></b>
                        <br></br>
                        <p>
                            <b> **--CM_SOFTWARE--** </b>, pessoa jurídica de direito privado com sede na Alameda Rio Pardo, nº 27, 
                            Bairro Alphaville Industrial, no município de Barueri, Estado de São Paulo, CEP 06455-005, inscrita no CNPJ/MF sob o 
                            nº <b> **--CM_SOFTWARE_CNPJ--** </b>, doravante denominada simplesmente “<b>C&M SOFTWARE</b>”;
                        </p>
                        <br>
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>
                        <b><small>CONTRATANTE</small></b>
                        <br></br>
                        <p>
                            <b> **--CLIENTE--** </b>, pessoa jurídica de direito privado com endereço **--ENDERECO--** - **--BAIRRO--**, na cidade de **--CIDADE--**, Estado de **--UF--**, 
                            CEP **--CEP--**, inscrita no C.N.P.J. nº **--CNPJ--**, neste ato representada na forma de seus atos constitutivos por 
                            <b>**--REPRESENTANTE_LEGAL--**</b>, **--REPRESENTANTE_LEGAL/CARGO--**, C.P.F. nº **--REPRESENTANTE_LEGAL/CPF--** , e-mail: **--REPRESENTANTE_LEGAL/EMAIL--**, 
                            telefone: **--REPRESENTANTE_LEGAL/TELEFONE--** **--REPRESENTANTE_2--** doravante denominada simplesmente <b>“CLIENTE”</b>.
                        </p>                        
                        <br>
                            <ul>CONTATO RESPONSÁVEL: **--CONTATO_RESPONSAVEL--** - e-mail: **--CONTATO_RESPONSAVEL/EMAIL--** - telefone: **--CONTATO_RESPONSAVEL/TELEFONE--** </ul>                                                       
                            <ul>FINANCEIRO: **--CONTATO_FINANCEIRO--** - e-mail: **--CONTATO_FINANCEIRO/EMAIL--** - telefone: **--CONTATO_FINANCEIRO/TELEFONE--** </ul>
                            **--CONTATO_FINANCEIRO_2--**
                        <br>
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                        <b><small>VIGÊNCIA / REAJUSTE / DENÚNCIA: **--VIGENCIA_CONTRATO--** **--VIGENCIA_CONTRATO/EXTENSO--** / **--INDICE_REAJUSTE--** / 180 (cento e oitenta) dias.<small></b>                        
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                        <b><small>PREÇO</small></b>                        
                        <br></br>
                        <ul> O valor da Implantação é de <b> R$ **--IMPLANTACAO--** **--IMPLANTACAO/EXTENSO--**, **--TEXTO_IMPLANTACAO--**.</b> </ul>
                        <p>
                            **--ASSESSORIA_BACEN--** 
                        </p>
                        <p>
                            **--ASSESSORIA_PIX--** 
                        </p>
                        <ul> O valor por hora para as adequações do projeto ao cliente é de R$ **--HORA_HOMEM--** (ANEXO V, cláusula 1.1.). </ul>  
                        <ul> Tabela dos PACOTES TARIFÁRIOS disponíveis no acesso ao STR. </ul>           
                        <div> **--PACOTE_FULL_STR--** </div>    
                        <ul> Para efeito de tarifação e faturamento ao ambiente do PIX os Valores BASE para tarifação serão: </ul>      
                        <div> **--VALORES_BASE_TARIFACAO--** </div>
                        
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                        <b><small>RESCISÃO CONTRATUAL</small></b>
                        <br></br>
                        <p>
                        	<b>60% (sessenta)</b> do valor da média do faturamento mensal dos últimos 12 meses, multiplicado pelos meses restantes.
                        </p>
                        <br>
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>
                        <b><small>FATURAMENTO</small></b>
                        <br></br>
                        <p>
                            Data de corte todo o dia <b> **--CORTE_FATURAMENTO--** **--CORTE_FATURAMENTO/EXTENSO--** de cada mês</b>, com prazo de pagamento <b> **--PRAZO_PAGAMENTO--** **--PRAZO_PAGAMENTO/EXTENSO--** </b> contados da apresentação da nota
                            fiscal/fatura, ocorrendo o primeiro faturamento <b> 19 (dezenove) </b>, independentemente da conclusão da implantação e do uso.   
                        </p>              
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>                       
                        <b><small>TESTEMUNHAS:</small></b>                       
                        <br>
                        <p>
                            Nome: **--TESTEMUNHA_CMSW--** da C&M C.P.F. nº **--TESTEMUNHA_CMSW/CPF--** e-mail: **--TESTEMUNHA_CMSW/EMAIL--** 
                            <br>
                            Nome: **--TESTEMUNHA--** C.P.F. nº **--TESTEMUNHA_CPF--** e-mail: **--TESTEMUNHA_EMAIL--** 
                        </p>
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>
                        <b><small>Observações:</small></b>
                    </td>
                </tr>
            </tbody>
        </table>                
    ";

    $texto[2] =
    "          
        <table cellpadding='1' cellspacing='1' style='width:100%'>
            <tbody>
                <tr>
                    <td class='td_cabecalho' style='text-align:center;border-top:2px solid;border-bottom:2px solid;'>
                        <small><b>INSTRUMENTO PARTICULAR DE CONTRATO DE LICENCIAMENTO DO SOFTWARE STR WEB & PIX </b></small>
                    </td>
                </tr>
            </tbody>
        </table>

        <p><b>CLÁUSULA PRIMEIRA: DO OBJETO</b></p>
        <p>
            <b>1.1.</b> O objeto do presente contrato é o licenciamento de uso do software <b>FULL STR WEB & PIX</b>, de forma não exclusiva, intransferível e temporária, nos termos e condições 
            aqui avençadas, viabilizando ao <b> CLIENTE </b> a operação diretamente nos Sistemas de Liquidação do Banco Central do Brasil, conforme regulamentação em vigor.
        </p>
        <p>
            <b>1.2.</b> Todos os novos produtos e/ou módulos e/ou funcionalidades, criados pela <b>C&M SOFTWARE</b> e disponibilizados na plataforma dos softwares <b>FULL STR WEB & PIX</b>, 
            serão informados ao <b> CLIENTE </b>. A opção, pelo <b> CLIENTE </b>, pelos novos produtos e/ou módulos e/ou funcionalidades ocorrerá na primeira utilização, servindo para todo e qualquer 
            efeito de direito, como aceitação dos preços e condições disponibilizadas no Painel de Controle constante no site do produto.
        </p>
        <p>
            <b>1.3.</b> Este contrato é composto pelos anexos e políticas abaixo descritas e fazem parte integrante e indissociável do Contrato para todos os fins de direito:
        </p>
        
        <menu>
            <ul> Anexo I – DO SISTEMA DE PAGAMENTOS BRASILEIRO – FULL STR WEB & PIX; </ul>
            <ul> Anexo V – TABELA DE PREÇOS FULL STR WEB & PIX </ul>
            <ul> (1) Declaração de Conformidade Social e Sigilo das Informações; </ul>
            <ul> (2) Política de Segurança da Informação e Cibernética; </ul>
            <ul> (3) Plano de Continuidade de Negócios; </ul>
            <ul> (4) Propriedade Intelectual; </ul>
            <ul> (5) Código de Ética; </ul>
            <ul> (6) Política Interna LGPD – “C&M2021-01-LGPD”. </ul>
        </menu>
        
        <p>
            <b>IMPORTANTE</b>: Os documentos referenciados de (1) a (6) estarão sempre disponíveis e atualizados no endereço: https://br.cmsw.com/politicas/
        </p>   
        
        <p><b>CLÁUSULA SEGUNDA: DO PRAZO DE VIGÊNCIA</b></p> 
        
        <p>
            <b>2.1.</b> O presente Contrato, vigorará pelo prazo de **--VIGENCIA_CONTRATO--** **--VIGENCIA_CONTRATO/EXTENSO--**, contados a partir da data da assinatura digital, conforme termos da <span style='color:blue;'><b>MEDIDA PROVISÓRIA No 2.200-2, 
            DE 24 DE AGOSTO DE 2001 e LEI Nº 14.063, DE 23 DE SETEMBRO DE 2020 </b></span>, ou da forma convencional de assinatura e, a partir de então, por prazo indeterminado com denúncia de 
            180 dias, conforme cláusula 7.6.
        </p>
        
        <p><b> CLÁUSULA TERCEIRA: DO PREÇO </b></p>

        <p>
            <b>3.1.</b> O valor da Implantação, Assessoria e as condições comerciais de uso estão descritos no Quadro de Resumo. Pelo licenciamento de uso do software <b>FULL STR WEB & PIX</b> 
            serão cobrados os preços, por mensagem processada, conforme Tabela de Preços e deverão ser quitados junto à <b>C&M SOFTWARE</b> por meio de PIX, DOC, TED ou boleto bancário, 
            ou qualquer outro sistema que venha substituí-los.
        </p>
        <p>
            <b>3.1.1.</b> O primeiro faturamento será integralmente cobrado, conforme valor estabelecido no item “PREÇO” do Quadro Resumo, independente das datas de vencimento e início 
            do Contrato, não sendo aplicada a forma de cobrança pro rata die.
        </p>
        <p>
            <b>3.2.</b> Salvo o valor da Implantação e/ou Assessoria que seguem sistemática própria, todos os faturamentos terão datas de corte para aferição todo o dia <b>  **--CORTE_FATURAMENTO--** **--CORTE_FATURAMENTO/EXTENSO--** </b>
            de cada mês, com prazo de pagamento de <b> **--PRAZO_PAGAMENTO--** **--PRAZO_PAGAMENTO/EXTENSO--** dias </b> contados da apresentação da nota fiscal/fatura, ocorrendo o primeiro faturamento <b> 19 (dezenove) </b>, 
            independentemente da conclusão da implantação e do uso, valor cheio, sem aplicar cálculo pro rata die.
        </p>

        <p>
            <b>3.2.1.</b> A <b>C&M SOFTWARE</b> informará ao <b>CLIENTE</b> sobre a emissão do documento fiscal específico, através de e-mail aos responsáveis indicados no 
            “FINANCEIRO”  do Quadro Resumo, enviando também nessa oportunidade o link para emissão da Nota Fiscal Eletrônica e respectivos boletos de pagamento, quando aplicável.
        </p>  
        <p>     
            <b>3.3.</b> Sempre que solicitado pelo <b> CLIENTE </b>, as visitas técnicas presenciais de profissionais da <b>C&M Software</b> na sede ou outro local determinado,
             serão de sua responsabilidade as despesas de viagens referentes ao transporte aéreo ou terrestre (quando o aéreo não for possível) e estadias ocorridas com os profissionais da 
             <b>C&M SOFTWARE</b>, exceto os deslocamentos dos profissionais da <b>C&M SOFTWARE</b> na região metropolitana de São Paulo/SP e Barueri/SP e cidades contíguas.
        </p>
        <p>
            <b>3.4.</b> Como forma de manter a hegemonia dos custos e o equilíbrio financeiro do contrato, as partes elegem, A cada <b>12 (doze) meses pelo **--INDICE_REAJUSTE--**</b>, ou qualquer outro 
            índice que venha a substituí-lo, a contar da data de assinatura do presente contrato, como o índice de correção monetária, aplicável aos preços referidos neste Contrato.
        </p>
        


        
    ";

    $texto[3] =
    "   <p>
            <b>3.4.1.</b> Quando aplicável e na hipótese de atraso ou ausência de publicação do índice aplicável, a <b>C&M SOFTWARE</b> emitirá as notas fiscais/faturas usando o último índice 
            publicado. Imediatamente após a publicação seguinte do referido índice, a <b>C&M SOFTWARE</b> emitirá os títulos para o pagamento e/ou ressarcimento da diferença entre valor já 
            cobrado e os valores efetivamente devidos, de acordo com o prazo de vencimento estabelecido.
        </p>
        <p>
            <b>3.4.2.</b> Na falta desse índice ou, se permitido por lei, ou por decisão judicial, será aplicado aos preços qualquer outro índice oficial, de variação diária, ou, 
            se inexistente, de variação mensal, calculando pro rata die, e que mais eficientemente elida os efeitos inflacionários da moeda corrente nacional, o qual será eleito mediante 
            comum acordo entre as partes.
        </p>
        <p>
            <b>3.5.</b> Na hipótese de ocorrerem fatos ou atos que possam prejudicar o equilíbrio econômico-financeiro do Contrato, as partes envidarão seus melhores esforços para regular
            e disciplinar a situação criada, de forma a evitar qualquer desequilíbrio econômico, financeiro ou outro qualquer.
        </p>
        <p>
            <b>3.6.</b> Se, durante a vigência deste Contrato, forem criados tributos ou alteradas as alíquotas dos atuais, de forma a majorar ou diminuir o ônus das Partes contratantes, 
            os preços poderão ser revistos, de modo a serem ajustados a essas modificações, mediante envio de notificação por escrito da <b>C&M SOFTWARE</b> ao <b>CLIENTE</b>.
        </p>
        <p>
            <b>3.7.</b> A <b>C&M SOFTWARE</b> disponibilizará o seu parque tecnológico para execução do software licenciado neste Contrato em sua sede, ou de suas futuras filiais, 
            as quais emitirão o correspondente documento fiscal, haja vista serem consideradas, individualmente, como estabelecimentos ou locais, onde a <b>C&M SOFTWARE</b> desenvolve a 
            sua atividade principal, de modo permanente ou eventual, nos termos do artigo 4º da Lei Complementar nº 116, de 31/07/2003, publicada no Diário Oficial da União de 1/08/2003.
        </p>
        <p>
            <b>3.8.</b> O inadimplemento de toda e qualquer importância cobrada com base no presente Contrato, na data de seu vencimento, implicará na incidência automática de multa 
            moratória no percentual de 2% (dois por cento) e juros de mora de 1% (um por cento) ao mês, encargos esses incidentes sobre o valor do débito atualizado de acordo com o 
            índice estabelecido no item “REAJUSTE CONTRATUAL” do Quadro Resumo, calculado “pro rata die” a partir da data de vencimento do respectivo documento de cobrança até a data do 
            efetivo pagamento.
        </p>
        <p>
            <b>3.8.1.</b> Os mencionados juros de mora, multa moratória e atualização monetária serão cobrados automaticamente no faturamento do mês subsequente.
        </p>
        <p>
            <b>3.9.</b> O acesso ao software poderá ser suspenso, sem aviso prévio, se a inadimplência do <b> CLIENTE </b> durar mais de 10 (dez) dias, contados da data de 
            vencimento, e neste caso não será reiniciada a não ser que todos os valores devidos sejam pagos na sua totalidade, sem prejuízo do direito da <b>C&M SOFTWARE</b> de rescindir 
            o presente Contrato.
        </p>
        <p>
            <b>3.9.1.</b> Após a comprovação do pagamento dos valores em atraso pelo <b>CLIENTE</b>, o acesso aos softwares será restabelecido automaticamente.
        </p>
        <p>
            <b>3.10</b> O <b> CLIENTE </b> adere e concorda que, até sua autorização e ingresso no ambiente de produção do <b>BACEN</b> deverá permanecer no <b>PACOTE TARIFARIO 1.</b>
        </p>
        <p>
            <b>3.10.1</b> A alteração de <b>PACOTE TARIFARIO 1</b>, poderá ser executada em qualquer data a partir do ingresso do <b> CLIENTE </b> no ambiente de produção do <b>BACEN</b>, 
            e esta alteração deverá ser feita diretamente pelo <b> CLIENTE </b> no Painel de Controle do <b> FULL STR WEB & PIX.</b> Sendo que as demais alterações dos pacotes 
            tarifários, deverão respeitar sempre o intervalo de <b>180 (cento e oitenta)</b> dias entre cada alteração. Em situação síncrona com a alteração realizada pelo <b> CLIENTE </b>, 
            (incremento ou decremento) a <b>C&M SOFTWARE</b> irá promover o ajuste comandado pelo <b> CLIENTE </b> em toda sua infraestrutura, motivo pelo qual a <b>C&M SOFTWARE</b> 
            precisará sempre de <b>180 (cento e oitenta) dias</b> para que a alteração solicitada consiga ser implementada junto a cadeia de fornecedores e serviços e reflita na infraestrutura e nos custos.
        </p>

        <p><b>CLÁUSULA QUARTA: DO ACESSO AO FULL STR WEB & PIX, IMPLANTAÇÃO E ATUALIZAÇÕES</b></p>
        <p>
            <b>4.1.</b> O <b>CLIENTE</b> recebeu no momento da contratação, ou até mesmo durante o processo de implantação e ativação dos produtos contratados, manuais explicativos 
            exemplificando o acesso aos softwares.
        </p>
        <p>
            <b>4.2.</b> A <b>C&M SOFTWARE</b> poderá promover atualizações nos softwares e serão sempre aplicadas na última versão disponibilizada em uso.
        </p>
        <p>
            <b>4.2.1.</b> Toda nova implementação ou atualização do software, solicitada pelo <b> CLIENTE </b>, após aprovação da <b>C&M SOFTWARE</b>, será incorporada na forma 
            de licenciamento e propriedade do <b>FULL STR WEB & PIX</b>.
        </p>
        <p>
            <b>4.3.</b> Se forem realizadas atualizações dos softwares, a <b>C&M SOFTWARE</b> obriga-se a comunicar e disponibilizá-las ao CLIENTE, gratuita e imediatamente.
        </p>

        <p><b>CLÁUSULA QUINTA: DAS OBRIGAÇÕES DA C&M SOFTWARE</b></p>
        <p>
            <b>5.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, a <b>C&M SOFTWARE</b> obriga-se a: 
        </p>
        <p>
            <b>5.1.1.</b> Executar o objeto deste Contrato, com a sua usual diligência, padrões de qualidade e com observância das regras e regulamentação governamental, aplicáveis.
        </p>
        <p>
            <b>5.1.2.</b> Realizar a manutenção preventiva e corretiva do software objeto deste Contrato.
        </p>
        <p>
            <b>5.1.3.</b> Atualizar os sistemas que compõem o <b>FULL STR WEB & PIX</b> para não incorrer em obsolescência tecnológica.
        </p>         
    ";

    $texto[4] = 
    "   
        <p>
            <b>5.1.4.</b> A partir da assinatura do presente Contrato e durante toda a sua vigência, possuir e manter infraestrutura tecnológica que suporte o volume mínimo de mensagens 
            contratado e eventual superação de uso deste mesmo volume em até 3 (três) vezes, de tal modo a não gerar impacto impeditivo de uso ao <b> CLIENTE </b> no momento do uso.
        </p>  
        <p>
            <b>5.1.5.</b> Toda e qualquer responsabilidade da <b>C&M SOFTWARE</b> limita-se, única e exclusivamente, aos sistemas desenvolvidos sob sua autoria. A <b>C&M SOFTWARE</b> não 
            responderá pela qualidade de produtos de terceiros, mesmo que tais produtos de terceiros precisem ser incorporados ao sistema.
        </p>
        <p>
            <b>5.2.</b> Segregar, no prazo de 90 (noventa) dias, os dados do <b> CLIENTE </b> das bases de dados da C&M SOFTWARE, no período inicial de estabilização do sistema. 
            Não será permitida a guarda de dados ou informações nos Banco de Dados da <b>C&M SOFTWARE</b> por período superior ao acima avençado.
        </p>
        <p><b>CLÁUSULA SEXTA: DAS OBRIGAÇÕES DO CLIENTE</b></p>

        <p>
            <b>6.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, o <b> CLIENTE </b> obriga-se a: 
        </p>
        <p>
            <b>6.1.1.</b> Agir de acordo com todas as leis, regras e regulamentações governamentais aplicáveis no acesso às informações. 
        </p>
        <p>
            <b>6.1.2.</b> Efetuar os pagamentos devidos pela contratação, de acordo com as disposições deste Contrato.
        </p>
        <p>
            <b>6.1.3.</b> Disponibilizar todos os dados/informações, dados e ambientes de terceiros, necessários à execução deste Contrato.
        </p>
        <p>
            <b>6.1.4.</b> Manter sob sigilo os códigos e senhas de acesso aos softwares, sendo de sua plena e total responsabilidade o uso indevido. Em caso de perda, fraude ou qualquer 
            outro risco na guarda, a <b>C&M SOFTWARE</b> deverá ser comunicada por escrito, da necessidade de bloqueio do acesso anterior e criação de novo acesso.
        </p>
        <p>
            <b>6.1.5.</b> Responsabilizar-se, civilmente por atos próprios, ou quaisquer atos de seus empregados, comitentes ou prepostos que vierem dar prejuízos, tanto materiais quanto 
            de imagem, ou de qualquer forma diminuir o patrimônio da <b> CLIENTE </b>.
        </p>
        <p>
            <b>6.1.6.</b> Manter estrutura adequada para o uso dos softwares, assim como, realizar a manutenção preventiva e corretiva dos itens fornecidos pela <b>C&M SOFTWARE</b>, 
            mantendo os equipamentos atualizados e operantes.
        </p>
        <p>
            <b>6.1.7.</b> Desde já, reconhecer que independente do uso do volume mínimo de mensagens contratado conforme item “PREÇO” do Quadro Resumo, que a infraestrutura responsável 
            por acolher este volume em até 3 (três) vezes já se encontra a sua disposição para uso a partir do momento da assinatura do presente Contrato, ficando a sua deliberação e 
            decisão o melhor momento para uso, sendo que esta decisão não impactará as demais responsabilidades deste instrumento.
        </p>
        <p>
            <b>6.1.8.</b> Abster-se de alterar seus dados cadastrais de cunho tecnológico e de infraestrutura junto ao <b>BACEN</b> que são utilizados pelo produto ora licenciado
        </p>
        <p>
            <b>6.1.9.</b> Observar as suas responsabilidades junto ao órgão regulador do sistema financeiro nacional na condução dos sistemas ora contratado.
        </p>
        <p>
            <b>6.2.</b> Cada parte deverá orientar seus representantes para que cumpram as orientações relativas à segurança, bem como normas e procedimentos, durante o período em que 
            esses estiverem designados para prestar serviços nas dependências da outra parte. 
        </p>
        <p>
            <b>6.3.</b> O <b> CLIENTE </b> reconhece e concorda, ainda que, o presente contrato contempla a gestão dos ambientes dos ecossistemas, domínios e subdomínios do 
            <b>SPB</b> e <b>PIX</b>, quer no ambiente de homologação, quer no ambiente de produção, e que, a alteração destas configurações comandadas pelo <b> CLIENTE </b>
            retirando a gestão dos domínios do <b>PIX</b> e <b>SPB</b>, ou dissociando os ambientes homologação e produção, implicará na sua imediata rescisão, com culpa, devendo o 
            <b> CLIENTE </b> pagar, em <b>até 5 (cinco) dias</b>, a multa de <b>6 (seis) vezes</b> a soma das <b>06 (seis) últimas parcelas</b>, a título de expor a contratada 
            a elevado risco operacional e de perda da sua homologação perante ao Banco Central do Brasil.
        </p>

        <p><b>CLÁUSULA SÉTIMA: DA RENOVAÇÃO ou RESCISÃO</b></p>
        <p>
            <b>7.1.</b> O contrato não poderá ser rescindido antecipadamente, por qualquer das partes, sem justo motivo, sob pena de aplicação automática de multa compensatória e 
            prefixação de perdas e danos equivalente a <b>60% (sessenta)</b> do valor da média do faturamento mensal (soma de todos os pagamentos realizados), nos <b>últimos 12 meses</b>, 
            monetariamente reajustadas, multiplicado pelo número de meses restantes para a conclusão do prazo integral, com a finalidade de recompor a <b>C&M SOFTWARE</b> pelos prejuízos 
            decorrentes da rescisão antecipada e injustificada, posto que a <b>C&M SOFTWARE</b> realizou o gerenciamento e planejamento de custos, infraestrutura de equipamentos e softwares, 
            equipes técnicas de suporte, manutenção e desenvolvimento de sistemas além das exigências regulatórias impostas pelo <b>BACEN</b> ao <b>PSTI C&M Software</b>, com vistas ao cumprimento 
            das obrigações contratuais no prazo contratado entre as Partes.
        </p>        
    ";

    $texto[5] =
    "   
    
        <b>7.2.</b> Este instrumento poderá ser rescindido, ainda, motivadamente, de forma imediata e de pleno direito:
        <menu>    
            <ul> 
                a) descumprimento de qualquer das cláusulas do Contrato, desde que não sanada no prazo de 10 (dez) dias a contar do recebimento da notificação da outra Parte 
                neste sentido;
            </ul>
            <ul>
                b) a outra Parte vir a ter a sua falência ou recuperação judicial/extrajudicial requerida ou decretada, ou insolvência civil dos sócios, mesmo que presumida, 
                bem como a condenação de qualquer um dos seus sócios em processos criminais; e,
            </ul>
            <ul>
                c) o encerramento das atividades, mesmo que voluntário, do <b> CLIENTE </b> ou alienação de direitos ou carteira, não o exime das infrações contratuais e 
                consequentes multas a serem aplicadas.
            </ul>
        </menu>       

        <p>
            <b>7.3.</b> O presente Contrato poderá ser encerrado, sem qualquer ônus, em razão da ocorrência de eventos de caso fortuito ou de força maior, regularmente comprovados, 
            impeditivos da execução deste Contrato. Quando for possível a execução apenas parcial do Contrato, o <b> CLIENTE </b> poderá decidir entre o cumprimento parcial ou o término do 
            Contrato.    
        </p>       
        <p>
            <b>7.4.</b> Na ocorrência do término deste Contrato, por qualquer motivo, o <b> CLIENTE </b> remunerará a <b>C&M SOFTWARE</b> pelos serviços já prestados e concluídos, 
            bem como efetuará o pagamento das despesas já ocorridas, estabelecendo as Partes desde já que o faturamento estabelecido no item “PREÇO” do Quadro Resumo, 
            independe das datas de rescisão e vencimento, não sendo aplicada a forma de cobrança pro rata die.
        </p>
        <p>
            <b>7.5.</b> Em função da especificidade do produto e do sistema de licenciamento, na denúncia do contrato, os <b>180 (cento e oitenta)</b> dias serão cobrados antecipadamente, 
            de uma única vez, na data do pedido, sob pena de não ter a rescisão processada e contagem de novo período contratual. Qualquer liberalidade da <b>C&M SOFTWARE</b> em relação a 
            esses valores não elidirá qualquer das outras obrigações.
        </p>
        <p>
            <b>7.6.</b> Após o período inicial de 12 meses contados a partir da assinatura do presente contrato, este vigorará por prazo indeterminado, bastando para o seu encerramento
            que uma das partes se manifeste com uma antecedência mínima de <b>180 (cento e oitenta) dias</b> através correspondência registrada assinada pelos seus representantes legais, 
            com reconhecimento de firma.
        </p>

        <p><b>CLÁUSULA OITAVA: DAS DISPOSIÇÕES GERAIS</b></p>

        <p>
            <b>8.1.</b> Nenhuma disposição deste Contrato poderá ser interpretada como tendo as Partes estabelecido qualquer forma de sociedade ou associação, de fato ou de direito, 
            remanescendo cada uma das partes com suas obrigações civis, comerciais, trabalhistas e tributárias, de forma autônoma.
        </p>
        <p>
            <b>8.2.</b> Nenhuma das Partes poderá ceder ou transferir, no todo ou em parte, os direitos e obrigações decorrentes deste Contrato, sem a anuência prévia e expressa da 
            outra Parte.
        </p>
        <p>
            <b>8.3.</b> Qualquer modificação deste Contrato somente será válida através de aditivo contratual, escrito e assinado pelas Partes.
        </p>
        <p>
            <b>8.4</b>. Todas as obrigações e condições aqui estipuladas obrigam as Partes e seus sucessores a qualquer título.
        </p>
        <p>
            <b>8.5.</b> Todas as notificações ou comunicações, segundo o presente Contrato, de uma Parte à outra, deverão ser endereçadas, <b>exclusivamente</b>, por via postal através de 
            carta registrada, com aviso de recebimento, para os representantes legais nos endereços constantes na qualificação das Partes. Se houver alteração do Representante Legal, 
            deverá ser anexado documento de comprovação. 
        </p>
        <p>
            <b>8.6.</b> A tolerância de uma Parte com a outra, relativamente a qualquer violação ou descumprimento de quaisquer obrigações ora assumidas, não será considerada moratória, 
            novação ou renúncia a qualquer direito, constituindo mera liberalidade, que não impedirá a Parte tolerante de exigir da outra o fiel cumprimento deste Contrato, a qualquer tempo.
        </p>
        <p>
            <b>8.7.</b> Se qualquer cláusula ou condição deste Contrato vier a ser considerada ilegal, inválida ou inexequível nos termos da legislação brasileira, as demais cláusulas e 
            condições continuarão em pleno vigor e efeito.
        </p>
        <p>
            <b>8.8.</b> O <b> CLIENTE </b>, desde já, autoriza a <b>C&M SOFTWARE</b> a incluir o seu nome na sua Lista de Clientes, assim como sua divulgação, pelos meios de 
            comunicação próprios, juntamente com os nomes de outros clientes, mas não revelará, comunicará ou de qualquer forma fará propaganda a qualquer terceiro de detalhes deste 
            Contrato.
        </p>
        <p>
            <b>8.9.</b> O presente Contrato constitui o acordo final entre as Partes com relação às matérias aqui expressamente tratadas, superando e substituindo todas as propostas, 
            acordos, entendimentos e declarações anteriores, orais ou escritos.
        </p>
        <p>
            <b>8.10.</b> Cada uma das Partes declara, garante e concorda, reciprocamente, que a celebração, outorga e execução deste Contrato foi devidamente autorizada pelos seus 
            legítimos representantes legais, na forma dos seus respectivos documentos societários, sendo que o fornecimento de eventual informação inverídica, incompleta ou inidônea 
            será considerado infração aos princípios da informação e boa-fé contratual, respondendo a parte que assim as prestou civil e criminalmente, restando claro que este contrato 
            constitui obrigação legal, válida e vinculante entre as Partes.
        </p>       
    
    ";

    $texto[6] = 
    "
        <p>
            <b>8.11.</b> As <b>Partes</b> comprometem-se em não aliciar os profissionais regidos por Contrato de Trabalho e/ou como Prestadores de Serviços que estão envolvidos, 
            direta ou indiretamente, com objeto deste contrato. Esta prática, quando comprovada, motivará a parte afetada à rescisão motivada do presente contrato, aplicando-se, ainda, 
            à <b>Parte</b> afetada, a aplicação do <b>art. 608 do Código Civil</b>.
        </p>
        <p>
            <b>8.12.</b> O presente Contrato é considerado título executivo extrajudicial, nos termos do inciso III, do artigo 784, do Código de Processo Civil, sujeitando-se, 
            dessa forma, à legislação aplicável à matéria.
        </p>
        <p>
            <b>8.13.</b> As Partes elegem o foro da Comarca de Barueri – SP, para dirimir quaisquer dúvidas ou atos oriundos relativos a este contrato, renunciando a qualquer outro por mais privilegiado que seja.
            E assim, por estarem justas e contratadas, as partes assinam o presente em 02 (duas) vias de igual teor e conteúdo, digital ou não, na presença das testemunhas
        </p>        
        
    ";

    $texto[7] = "

        <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
                <tr>
                    <td class='td_cabecalho' style='text-align:center;border-top:2px solid;border-bottom:2px solid;'>
                        <small><b>ANEXO I – DO SISTEMA DE PAGAMENTOS BRASILEIRO – FULL STR WEB & PIX</b></small>
                    </td>
                </tr>
            </tbody>
        </table>

        <p><b>CLÁUSULA PRIMEIRA: DA INSTALAÇÃO E IMPLANTAÇÃO</b></p>
        <p>
            <b>1.1.</b> Pelos serviços de implantação, a <b>C&M SOFTWARE</b> configurará os sistemas que compõem a solução <b>FULL STR WEB & PIX</b>, compreendendo os ambientes de Homologação
            e Produção, contemplando os seguintes serviços:
        </p>
        <menu>
            <ul> a) Geração do MQ-Series: de licenciamento da C&M Software para utilização do <b>CLIENTE</b> segundo os padrões adotados pelo Banco Central do Brasil; </ul>
            <ul> b) Geração das interfaces de webservices e canais de segurança segundo os padrões adotados pelo Banco Central do Brasil; </ul>
            <ul> c) Geração da Rede Lógica para disponibilização dos seus canais junto a RSFN pelo <b> CLIENTE</b> </ul>
            <ul> d) Configuração de Serviços de Rede (DNS); </ul>
            <ul> e) Configuração dos elementos de segurança e proteção a intrusão. </ul>
            <ul> f) Configuração da Base de Dados; </ul>
            <ul> g) Configuração dos elementos de mensageria STR e PIX; </ul>
            <ul> h) Configuração das interfaces e sistemas de uso pelos usuários do <b> CLIENTE </b> </ul>
            <ul> i) Instalação do Servidor de Criptografia nos ambientes STR e PIX do BACEN. </ul>
        </menu>

        <b>1.1.1.</b> A Implantação contempla, ainda, o treinamento ao <b>SPB/x</b> concedido pela <b>C&M SOFTWARE</b> ou terceiros por ela credenciados, nas instalações físicas da 
        <b>C&M SOFTWARE</b>, do <b> CLIENTE </b>, ou outro local indicado por este, de até 3 (três) profissionais do <b> CLIENTE </b> na utilização do software ora contratado, conforme 
        abaixo descrito:

        <menu>
            <ul> a) Treinamento Mensageria: Consiste no treinamento na utilização do FULL STR WEB & PIX; </ul>
            <ul> b) Treinamento Piloto de Reserva: Treinamento da utilização do C&M Piloto de Reserva e suas funcionalidades desenvolvidas até a data do treinamento; </ul>
            <ul> c) Treinamento dos administradores do sistema e sistemas de alçada; </ul>
        </menu>
        <p><b>1.1.2.</b> O treinamento deverá ser solicitado pelo <b> CLIENTE </b>, com um prazo mínimo de 30 (trinta) dias de antecedência, sendo que, caso o local escolhido seja fora da região
            metropolitana da cidade de São Paulo, as despesas com transportes, hospedagem e alimentação dos instrutores, serão de responsabilidade exclusiva do <b> CLIENTE </b>.</p>


        <p><b>1.2.</b> A licença de uso do <b>FULL STR WEB & PIX</b> contempla:</p>         
        <menu>
            <ul> a) Licença de Uso C&M Message Router: Utilização do Sistema de Mensageria da C&M SOFTWARE para o ambiente STR e PIX; </ul>
            <ul> b) Licença de Uso C&M Piloto de Reserva: Utilização do Sistema de Gerenciamento de Conta Reserva e Conta PI de propriedade da C&M SOFTWARE; </ul>
            <ul> c) Licença de Uso C&M Suite Package Security: Módulos de criptografia para PIX e STR; </ul>
            <ul> d) Interfaces de Integração sistêmicas. </ul>
        </menu>        

        <p><b>1.3.</b> No ambiente conhecido como produção do <b>FULL STR WEB & PIX</b>, a <b>C&M SOFTWARE</b> garantirá os seguintes níveis de desempenho:</p>
       
        <menu>
            <ul> 
                a) 100 (cem) mensagens recebidas e/ou enviadas por minuto, desconsiderando os tempos relativos ao tempo de transmissão, recepção, de Rede Interna, 
                RSFN e Internet;
            </ul>
            <ul>
                b) 03 (três) segundos para acesso às telas de consulta de mensagens, desconsiderando os tempos relativos ao tempo de transmissão, recepção, de Rede Interna, 
                RSFN e Internet, considerando ainda que o CLIENTE se compromete a utilizar na aferição equipamentos com a configuração mínima exigida na época da avaliação;
            </ul>
        </menu>        

        <p> <b>1.4.</b> A <b>C&M SOFTWARE</b> manterá a disponibilidade mínima de operacionalidade de 99,9% (noventa e nove inteiros e nove décimos por cento), por 7 (sete) dias na semana e 
        24 (vinte e quatro) horas no dia, conforme exigência regulatória do Banco Central do Brasil.  </p> 
        
        <p> <b>1.4.1.</b> Não serão considerados para cálculo de nível de operacionalidade os seguintes casos: </p>
        <ul> a) execução de manutenção, comunicada pela C&M SOFTWARE com mínimo de 15 (quinze) dias de antecedência; </ul>
        <ul> b) operação inadequada do software e dos equipamentos pelo CLIENTE, em desacordo com as instruções da C&M SOFTWARE; </ul>
        <ul> c) falhas ocasionadas em relação à infraestrutura do CLIENTE ou de seus clientes finais. </ul>
        <ul> d) quando, por qualquer motivo, o CLIENTE impedir o acesso da C&M SOFTWARE onde estejam localizados seus equipamentos ou os por ela mantidos, 
        postergando assim o restabelecimento da operação. </ul>               
                              
    ";

    $texto[8] = 
    "   
    <p>        
        <b>1.5.</b> O <b> CLIENTE </b> tem conhecimento que toda a comunicação por intermédio da rede mundial de computadores (internet) está sujeita a interrupções e/ou atrasos, 
        podendo ocorrer problemas de transmissão ou de recepção das informações acessadas.           
    </p>
    <p><b>CLÁUSULA SEGUNDA: DAS OBRIGAÇÕES DA C&M SOFTWARE</b></p>
    <p>
        <b>2.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, a <b>C&M SOFTWARE</b> obriga-se a: 
    </p>  
    <p>
        <b>2.1.1.</b> Realizar a manutenção preventiva e corretiva dos itens fornecidos pela <b>C&M SOFTWARE</b>, mantendo os equipamentos atualizados e operantes.
    </p>
    <p>
        <b>2.1.2.</b> Manter e atualizar seus Sistemas que compõem a solução STR E PIX, Ambiente de Homologação e Produção, conforme abaixo:
    </p>             

    <menu>
        <ul>
            a) MQ-Series, manter atualizado com o padrão estipulado pelo Banco Central do Brasil e as Câmaras que participam do Sistema;
        </ul>
        <ul>
            b) Mensageria, sempre atualizada com a última versão do “book” de Mensagens e DTD padronizadas pelo Banco Central do Brasil e as Câmaras que participam do Sistema;
        </ul>
        <ul>
            c) Módulo de Segurança, manter atualizado com a última versão divulgada pelo Banco Central do Brasil;
        </ul>
        <ul>
            d) Manter atualizado sua integração com os padrões de Mensagens do PIX estipulados pelo BACEN.
        </ul>
        <ul>
            e) Piloto de Reservas, manter compatível com o todo do Sistema SPB, segundo especificações do Banco Central do Brasil.
        </ul>
    </menu>

    <p><b>2.1.3.</b> Manter o histórico de mensagens dos últimos 02 (dois) meses, mais o mês corrente disponíveis para acesso online. A base histórica anterior a esse período 
    deverá ser guardada pelo <b> CLIENTE </b>.</p>
    <p>
        <b>2.1.3.1.</b> Mensalmente a <b>C&M SOFTWARE</b> disponibilizará ao <b>CLIENTE</b> um arquivo .ZIP em um site SFTP com a base anterior ao mês corrente para guarda 
        do <b> CLIENTE </b>.
    </p>
    <p>
        <b> 2.1.3.2. </b> Fornecerá também um software, durante a vigência deste Contrato, para visualização das mensagens conforme padrão exigido pelo Banco Central do Brasil, 
        convencionado no documento “Manual de Segurança de Mensagens do SPB”, capítulo que trata da manutenção e guarda dos registros para fins de auditoria.
    </p>


    <p><b>CLÁUSULA TERCEIRA: DAS OBRIGAÇÕES DO CLIENTE</b></p>
    <p>             
        <b>3.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, o <b> CLIENTE </b> obriga-se a: 
    </p>  
    <p>
        <b>3.1.1.</b> Fornecer, por escrito, todos os dados técnicos que vierem a ser solicitados pela <b>C&M SOFTWARE</b>, necessários para a elaboração do Projeto e execução 
        do Contrato.
    </p> 
        <p>
            <b>3.1.2.</b> Fornecer, durante a execução da Implantação, sem ônus para a <b>C&M SOFTWARE</b>, recursos telefônicos para comunicação, bem como facilidades para fotocópias de 
            documentos. 
        </p>
        <p>
            <b>3.1.3.</b> Fornecer todos os dados técnicos necessários à disponibilização do acesso da <b>C&M SOFTWARE</b>.
        </p>
        <p>
            <b>3.1.4.</b> Abster-se de reparar, modificar, ou mesmo adicionar novos componentes ou conexões, ou fazer alterações e/ou mudanças de qualquer tipo nas Estações de 
            Telecomunicações, sem prévia autorização por escrito por parte da <b>C&M SOFTWARE</b>.
        </p>  

        <p><b>CLÁUSULA QUARTA: DO EQUIPAMENTO E SOFTWARE</b></p>            
        <p>
            <b>4.1.</b> O <b> CLIENTE </b> não terá qualquer direito à propriedade de qualquer equipamento fornecido pela ou através da C&M SOFTWARE, a não ser que tal equipamento tenha 
            sido adquirido pelo CLIENTE, mediante assinatura do competente Contrato de Compra e Venda. 
        </p>
        <p>
            <b>4.2.</b> O <b> CLIENTE </b> é responsável pela instalação, operação ou manutenção do equipamento na propriedade do CLIENTE ou por outro equipamento ou 
            software (a incluir sem limitação, o cabeamento) não fornecidos pela C&M SOFTWARE (coletivamente, “equipamento ou software não C&M”).
        </p>
        <p>
            <b>4.3.</b> O Direito de Propriedade Intelectual dos softwares fornecidos pela C&M SOFTWARE para os fins deste contrato, a ela está assegurado.
            CLÁUSULA QUINTA: DO SUPORTE TÉCNICO
        </p>
        <p>
            <b>5.1.</b> O suporte técnico ao <b>FULL STR WEB & PIX</b> será prestado pela <b>C&M SOFTWARE</b> ou terceiros por ela credenciados via telefone (+55 11 3365-2666) 
            ou correio eletrônico (suporte@cmsw.com) sem custos adicionais para o <b> CLIENTE </b>, nas seguintes condições:
            <p>
                <b>5.1.1.</b> O Suporte Operacional da <b>C&M SOFTWARE</b>, responsável direto pela disponibilidade do produto, bem como por responder a questionamentos iniciais, 
                poderá ser acessado 07 (sete) dias por semana, 24 (vinte e quatro) horas por dia, 365 (trezentos e sessenta e cinco) dias por ano (7x24x365).
            </p>
        </p>";

        
    $texto[9] =
    "    
        <table cellpadding='1' cellspacing='1' style='width:100%'>
            <tbody>
                <tr>
                    <td class='td_cabecalho' style='text-align:center;border-top:3px solid;border-bottom:3px solid;'>
                        <small><b>ANEXO V – TABELA DE PREÇOS FULL STR WEB & PIX</b></small>
                    </td>
                </tr>
            </tbody>
        </table>

        <p> 
            <b>CLÁUSULA PRIMEIRA:</b> Pelo licenciamento de uso do software <b>FULL STR WEB & PIX</b> serão cobrados os preços, por mensagem processada, nos termos a seguir:
        </p>

        <p>
            <b>1.1.</b>	Os valores estão estabelecidos no QUADRO DE RESUMO – <b>PREÇOS</b>, assim como as condições gerais.
        </p>
        <ul>	O valor da Implantação: que serão pagos em até 10 (dez) dias após a assinatura do presente contrato </ul>
        <ul> O valor da Assessoria <b>BACEN</b> contempla o acompanhamento na avalição inicial e cronogramas de execução e testes. Apoio para a Solicitação para Abertura de Conta ou 
                Alteração de Forma e Modelos de Declarações, além da montagem do plano de testes e auxílio no fornecimento de informações de log, conforme Proposta.
            </ul>
            <ul> O valor por hora para as adequações do projeto ao <b> CLIENTE </b> é o valor cobrado pelo apoio da equipe técnica da C&M Software em processos como integração. 
                Necessário mapeamento detalhado de sistemas e processos para dimensionamento adequado de horas requisitadas, somente executadas mediante aprovação do <b> CLIENTE </b>. 
            </ul>
        <p>
            <span style='color:red'> 
                <b>1.2.</b>	Por exigência fiscal, os valores dos serviços de Assessoria BACEN e Adequações do Projeto, quando cabíveis, serão faturados por C&M SOFTWARE E CONSULTORIA LTDA,
                C.N.P.J. nº 14.289.105/0001-04;
            </span>
        </p>
        <p>
            <b> 1.3.</b> O modelo tarifário adotado é o de PACOTE, onde o <b> CLIENTE </b> faz a opção pelo pacote de transações mais adequado a sua realidade operacional, 
            sendo que para o caso de transações excedentes será aplicado o valor de mensagem individual do respectivo pacote selecionado, multiplicando o total de mensagens que 
            excederam o PACOTE contratado pelo valor individual de mensagens.
        </p>
        <p>
            <b> 1.4. </b> Para efeito de tarifação e faturamento no STR não serão tarifadas as transações das mensagens tipificadas e/ou identificadas como R1, todas as demais 
            tipificações serão tarifadas;
        </p>
        <p>
            <b>1.5.</b>	A partir da assinatura do contrato aplicar-se-á a Cláusula 3.10 e 3.10.1 do Contrato
        </p>
        <p>
            <b>1.6.</b>	Com vistas a promover uma melhor precificação e utilização da infraestrutura alocada para a execução do produto ora licenciado, a C&M SOFTWARE concede ao <b> CLIENTE </b>, 
            a tabela de descontos progressivos abaixo a ser aplicada como forma redutora dos preços descritos nas Cláusulas seguintes, com base no horário de execução da transação associada.
        </p>

        <ul> Desconto a ser aplicado no valor base das transações trafegada nos seguintes horários: </ul> 

        <table style='border:thin solid 1px;'>
            <thead>  
                <tr>
                    <th style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;background-color:#c25647;color:rgb(255, 255, 255);'><small><b>TIPO / HORÁRIO</b></small></th>";
                    foreach ($this->dicionario['TEXTO_SLIDE']['FULL']['TABLE_FULL']['HORARIO'] as $key => $value) {
                        $texto[9] .= 
                        "                 
                            <th  style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;background-color:#c25647;color:rgb(255, 255, 255);'><small><b>".$value."</b></small></th>                              
                        ";
                    }
$texto[9] .="    </tr>
            </thead>
                <tbody>
                    <tr>
                        <th style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;background-color:#c25647;color:rgb(255, 255, 255);'><small><b>CREDITO CLIENTE</b></small></th>";
                        foreach ($this->dicionario['TEXTO_SLIDE']['FULL']['TABLE_FULL']['HORARIO'] as $key => $value) {
                            $texto[9] .= 
                            "                 
                                <td style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;'><small>".$this->dicionario['TEXTO_SLIDE']['FULL']['TABLE_FULL'][$value]['CREDITO']."</small></td>                              
                            ";
                        }
                    $texto[9] .= 
                    "</tr>
                        <tr>
                            <th style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;background-color:#c25647;color:rgb(255, 255, 255);'> <small><b>DEBITO DO CLIENTE</b></small></th>";
                        foreach ($this->dicionario['TEXTO_SLIDE']['FULL']['TABLE_FULL']['HORARIO'] as $key => $value) {
                            $texto[9] .= 
                            "                 
                                <td style='border:thin solid 1px;border-color:#000000;height:25px;text-align:center;'><small>"
                                    .$this->dicionario['TEXTO_SLIDE']['FULL']['TABLE_FULL'][$value]['DEBITO'].
                                "</small></td>                              
                            ";
                        }
                    $texto[9] .= "</tr>
                <thead>
            </table>
            ";
    
    $texto[9] .= 
    "
        <p>
            <b>1.6.1.</b> Entenda-se: Transações a crédito do <b> CLIENTE </b>, são as que resultam em crédito na Conta do <b> CLIENTE </b> junto ao BACEN, e, respectivamente, transações a débito 
            <b> CLIENTE </b>, são aquelas que resultam em débito na Conta do <b> CLIENTE </b> junto ao BACEN.
        </p>
        <p>
            <b>1.6.2.</b> A apuração do uso será mensal, respeitando as datas de corte e datas de faturamento pactuados no contrato principal e/ou seus anexos anteriores.
        </p>
        <p>
            <b>1.6.3.</b> A presente tarifação somente ocorrerá quando do ingresso em produção junto ao BACEN do SPI/x. Não ocorrerá qualquer cobrança no período de testes e 
            homologação, seguindo as datas de faturamento pactuada no contrato.
        </p>   

        <p><b>CLÁUSULA SEGUNDA:</b></p>
        <p>
            <b>2.</b> A não utilização pelo <b> CLIENTE </b> de qualquer funcionalidade do Software <b>FULL STR WEB & PIX</b>, bem como a não utilização das mensagens contempladas no 
            PACOTE TARIFARIO selecionado, não gerará ao <b> CLIENTE </b> nenhum crédito e/ou desconto, pois toda infraestrutura do Software estará mensalmente disponibilizada ao 
            <b> CLIENTE </b> desde a assinatura do presente Contrato.
        </p>
        <p>
            <b>2.1.</b> A não utilização integral das mensagens contempladas no faturamento PACOTE TARIFARIO selecionado pelo CLIENTE não serão transferidas para o mês seguinte, 
            sendo “zeradas” a cada período de cobrança mensal e não se compensarão com eventual utilização excedente em mês(es) futuro(s).
        </p>
        <p>
            <b>2.2.</b> Em face do tipo de contratação (licenciamento de software), os valores mensais não estão sujeitos a cálculos “pro rata die”.
        </p>
        <p>
            <b>2.3.</b> Somente serão tarifadas mensagens cursadas no ambiente de produção do <b>BACEN</b>.
        </p>
        <p>
            <b>2.4.</b> Os valores não contemplam tributos e serão acrescidos quando da emissão da Nota Fiscal/Fatura.
        </p>
    "
?>