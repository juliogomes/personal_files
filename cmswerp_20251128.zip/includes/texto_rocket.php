<?php   
    setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
    $data_extenso = strftime('%d de %B de %Y', strtotime('today')); 

    $texto[0] = 
    "  
        À  <br> 
        <b> **--CLIENTE--** </b> <br> 
        **--ENDERECO--** - **--BAIRRO--** <br> 
        **--CEP--** - **--CIDADE--** - **--UF--** <br> 
        <br> 
        <b> A/C.: **--REPRESENTANTE_LEGAL--** </b> 
        <br></br> 
        Assunto: CONTRATO DE LICENCIAMENTO DE USO DO SOFTWARE ROCKET® 
        <br></br> 
        Prezado Senhor,
        <br>
        <p>Primeiramente manifestamos nossos sinceros agradecimentos pela contratação do nosso software, e lhe damos as Boas-Vindas à família C&M Software.</p> 
        <p>
            Encaminhamos em anexo o contrato de Licenciamento do Software <b>ROCKET®</b>, que será assinado na 
            <b>Plataforma de Assinaturas</b> da <b>D4Sing</b> (especializada em identificação digital), com plena validade jurídica. 
            As assinaturas das pessoas jurídicas da Contratante e Contratada serão realizadas com a utilização de Certificados Digitais <b>e-CNPJ</b>.
        </p> 
        <p>As testemunhas assinarão eletronicamente (sem a necessidade de Certificado Digital), de acordo com as formas de comprovação de autoria e integridade de documentos
        realizadas pela Plataforma de Assinaturas da <b>D4Sing</b>. O passo-a-passo para assinatura do presente instrumento será enviado por <b>e-mail</b>.</p>
       
        Caso contrário, segue anexo o “Contrato de Licenciamento do Software <b>ROCKET®</b>”, é necessário que seja assinado em <b>02 (duas) vias</b> e entregue no endereço de nossa sede:       
        <br>
        <br><b>**--CM_SOFTWARE--**</b>
        <br> A/C: Departamento Jurídico. 
        <br> Alameda Rio Pardo, nº 27 - Alphaville Industrial. 
        <br> 06455-005 – Barueri – SP.        
        <br> Os documentos que devem acompanhar o contrato são:        
        
            <ul>  Cópia simples do Contrato Social/Estatuto Social, bem como última alteração/ata de assembleia; </ul> 
            <ul>  Cartão do CNPJ;  </ul>
            <ul>  Cópia simples do RG e CPF do signatário do Contrato; e, </ul>
            <ul>  Se o signatário não constar do Contrato Social/Estatuto Social, solicitamos cópia da procuração que lhe outorgou poderes. </ul>         
        
        <br>
        Quaisquer dúvidas podem ser encaminhadas para os e-mails contratos@cmsw.com e juridico@cmsw.com, ou pelo telefone (11) 3365-2666.
        <br></br><br></br><br></br><br>
        Atenciosamente
        <br></br><br>       
        <table>
            <thead>
                <th style='text-align:center; width:800px;' >               
                    <small>
                        **--CM_SOFTWARE--**
                        <br>Departamento Jurídico 
                    </small>                               
                </th>
            </thead>
        </table>
    ";

    $texto[1] =
    "          
        <table cellpadding='1' cellspacing='1' style='width:100%'>
            <tbody>
                <tr>
                    <td style='text-align:center;border-bottom:2px solid;'>
                        <h3>Contrato de Licenciamento do Software - Rocket </h3>                        
                    </td>
                </tr>
            </tbody>
        </table>
       
        <table cellpadding='1' cellspacing='4' style='width:100%'> 
            <tbody>
                <tr>
                    <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'><b><small>QUADRO RESUMO</small></b></td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>
                        <b><small>CONTRATADA</small></b>
                        <br></br>
                        <p>
                            <b>**--CM_SOFTWARE--**</b>, pessoa jurídica de direito privado com sede na Alameda Rio Pardo, nº 27, 
                            Bairro Alphaville Industrial, no município de Barueri, Estado de São Paulo, CEP 06455-005, inscrita no CNPJ/MF sob o 
                            nº <b>**--CM_SOFTWARE_CNPJ--**</b>, doravante denominada simplesmente “<b>C&M SOFTWARE</b>”;
                        </p>
                        <br>
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>
                        <b><small>CONTRATANTE</small></b>
                        <br></br>
                        <p>
                            <b> **--CLIENTE--** </b>, pessoa jurídica de direito privado com endereço **--ENDERECO--** - **--BAIRRO--**, na cidade de **--CIDADE--**, Estado de **--UF--**, 
                            CEP **--CEP--**, inscrita no C.N.P.J. nº **--CNPJ--**, neste ato representada na forma de seus atos constitutivos por 
                            <b>**--REPRESENTANTE_LEGAL--**</b>, **--REPRESENTANTE_LEGAL/CARGO--**, C.P.F. nº **--REPRESENTANTE_LEGAL/CPF--** , e-mail: **--REPRESENTANTE_LEGAL/EMAIL--**, 
                            telefone: **--REPRESENTANTE_LEGAL/TELEFONE--** **--REPRESENTANTE_2--** doravante denominada simplesmente <b>“CLIENTE”</b>.
                        </p>
                        <br>
                            <ul>CONTATO RESPONSÁVEL: **--CONTATO_RESPONSAVEL--** - e-mail: **--CONTATO_RESPONSAVEL/EMAIL--** - telefone: **--CONTATO_RESPONSAVEL/TELEFONE--** </ul>                                                       
                            <ul>FINANCEIRO: **--CONTATO_FINANCEIRO--** - e-mail: **--CONTATO_FINANCEIRO/EMAIL--** - telefone: **--CONTATO_FINANCEIRO/TELEFONE--** </ul>
                            **--CONTATO_FINANCEIRO_2--**
                        <br> 
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                        <b><small>VIGÊNCIA / REAJUSTE / DENÚNCIA: **--VIGENCIA_CONTRATO--** **--VIGENCIA_CONTRATO/EXTENSO--** / **--INDICE_REAJUSTE--** / 30 (trinta) dias.</small></b>                        
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                        <b><small>PREÇO</small></b>                        
                        <br></br>
                        <ul>	O valor da Implantação é de <b> R$ **--IMPLANTACAO--** **--IMPLANTACAO/EXTENSO--**, **--TEXTO_IMPLANTACAO--** </b> </ul>
                        <ul>	A <b>Licença de Uso</b> é de <b>R$ **--PACOTE--** **--PACOTE/EXTENSO--** </b>, mensais. </ul>
                        <ul>	Incluindo  <b> **--TRANSACOES_ENGINE--** </b>  **--TRANSACOES_ENGINE/EXTENSO--** transações de Engine.  </ul>
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                        <b><small>RESCISÃO CONTRATUAL</small></b>
                        <br></br>
                        <p>
                            <b>4,5 (quatro vezes e meia)</b> a média dos faturamentos ocorridos nos <b>últimos 12 (doze) meses</b>, ou período inferior, se disponível.
                        </p>
                        <br>
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>
                        <b><small>FATURAMENTO</small></b>
                        <br></br>
                        <p>
                            Data de corte todo o dia <b> **--CORTE_FATURAMENTO--** **--CORTE_FATURAMENTO/EXTENSO--** de cada mês</b>, com prazo de pagamento <b> **--PRAZO_PAGAMENTO--** **--PRAZO_PAGAMENTO/EXTENSO--**</b> contados da apresentação da nota
                            fiscal/fatura, ocorrendo o primeiro faturamento <b> 19 (dezenove) </b>, independentemente da conclusão da implantação e do uso.   
                        </p>              
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>                       
                        <b><small>TESTEMUNHAS:</small></b>                       
                        <br></br>
                        <p>
                            Nome: **--TESTEMUNHA_CMSW--** da C&M C.P.F. nº **--TESTEMUNHA_CMSW/CPF--** e-mail: **--TESTEMUNHA_CMSW/EMAIL--** 
                            <br>
                            Nome: **--TESTEMUNHA--** C.P.F. nº **--TESTEMUNHA_CPF--** e-mail: **--TESTEMUNHA_EMAIL--** 
                        </p>
                    </td>
                </tr>
                <tr>
                    <td class='td_minuta' style='border:2px solid; border-color:black'>
                        <b><small>Observações:</small></b>
                    </td>
                </tr>
            </tbody>
        </table>                
    ";

    $texto[2] =
    "          
        <table cellpadding='1' cellspacing='1' style='width:100%'>
            <tbody>
                <tr>
                    <td class='td_minuta' style='text-align:center;border-top:3px solid;border-bottom:3px solid;'>
                        <small><b>INSTRUMENTO PARTICULAR DE CONTRATO DE LICENCIAMENTO DO SOFTWARE ROCKET</b></small>
                    </td>
                </tr>
            </tbody>
        </table>
                        
        Pelo presente instrumento e na melhor forma de direito, as partes qualificadas no <b>QUADRO RESUMO</b> e considerando que
            
        <p> 
            <b>(i)</b> a <b>C&M SOFTWARE</b> é titular exclusiva de todos os direitos autorais e patrimoniais do software ROCKET®, que será disponibilizado ao <b> CLIENTE </b>,
            sob a modalidade “SaaS” (Software as a Service), conforme abaixo:
        </p>

        <menu>    
            <ul> 
                processamento do software ROCKET® nos servidores da <b>C&M SOFTWARE</b>, instalados e operados no Brasil, e acessado pelo <b> CLIENTE </b> 
                via Internet (Cloud Computing), não necessitando, assim, de investimentos de grande porte pelo <b> CLIENTE </b> em infraestrutura e 
                capacitação de profissionais para manutenção e atualização do sistema; 
            </ul>
            <ul> 
                toda infraestrutura necessária para a disponibilização do software ROCKET® é de responsabilidade da <b>C&M SOFTWARE</b> 
                (servidores, comunicação, segurança das informações, Licença de Uso, licenças de banco de dados, etc.), disponível ao <b> CLIENTE </b> 
                por 7 sete dias da semana, 24 horas por dia e 365 dias por ano; 
            </ul>
            <ul> 
                todas as correções e novas versões mais modernas de tecnologia e processos de negócio são disponibilizadas ao <b> CLIENTE </b>; 
            </ul>
            <ul> 
                suporte técnico e monitoramento, disponibilizado pela <b>C&M SOFTWARE</b> ao <b> CLIENTE </b> por 7 sete dias da semana, 24 horas por dia e 365 dias por ano;  
            </ul>
            <ul> 
                a <b>C&M SOFTWARE</b> disponibiliza, ainda, ao <b> CLIENTE </b> site contingência com redundância da aplicação e Banco de Dados, isto é segunda infraestrutura 
                que está imediatamente disponível para uso quando da falha do dispositivo primário do sistema. 
            </ul>
        </menu>
        (ii) o <b> CLIENTE </b> objetiva utilizar o software ROCKET® para aperfeiçoar e programar processos de crédito, cobrança, vendas, risco, fraude e controles internos, assumindo a responsabilidade pelos dados enviados nos termos da Lei  nº 13.709, de 14 de agosto de 2018 e do art. 14 da Resolução 4.658 do BACEN;
        <p>
            <b>RESOLVEM</b>, as partes adiante qualificadas, celebrar o presente Contrato de Licenciamento do Software ROCKET®, obedecidos os itens constantes do Quadro Resumo 
            e as cláusulas e condições adiante convencionadas, que reciprocamente estipulam, outorgam e aceitam, a saber:
        </p>
        
        <p><b>CLÁUSULA PRIMEIRA: DO OBJETO E LOCALIZAÇÃO DOS SERVIDORES</b></p>
        
        <p>
            <b>1.1.</b> O objeto do presente Contrato é o licenciamento de uso do software ROCKET®, de forma não exclusiva, intransferível e temporária, nos termos e condições 
            aqui avençadas, sendo a sua finalidade de assessorar o <b> CLIENTE </b> nas suas decisões de análise e concessão de crédito, cobrança, cadastro, risco e venda, 
            disponibilizando todas as informações necessárias para assessorá-lo nas suas diretrizes de comercialização dos seus produtos. 
        </p>
        
        <p>
        <span style='color:black'>
            <b>1.1.1.</b> O processamento do software ROCKET® ocorrerá nos servidores da <b>C&M SOFTWARE</b>, instalados e operados no Brasil, no município de Barueri, 
            Estado de São Paulo. 
        </span>
        </p>

        <p> <b>1.2.</b> O software ROCKET® é composto por uma plataforma de módulos e integradores. </p>
        <p>
            <b> 1.3. </b> Todos os novos produtos/módulos ou funcionalidades, criados pela <b>C&M SOFTWARE</b> e disponibilizados na plataforma do ROCKET®, serão informados ao 
            <b> CLIENTE </b>. A adesão pelo <b> CLIENTE </b> aos novos produtos/módulos ou funcionalidades ocorrerá na primeira consulta realizada, 
            servindo para todo e qualquer efeito de direito, como adesão aos preços e condições disponibilizadas no Painel de Controle constante no endereço eletrônico: 
            https://rocket.cmsw.com 
        </p>
        <p> 
            <b>1.4.</b> Este Contrato é composto pelos anexos e políticas abaixo descritas e fazem parte integrante e indissociável do Contrato para todos os fins de direito: 
        </p>
            <menu style='margin-left:50px'>        
                <ul> ANEXO III – Tabelas de Preços. </ul>
                <ul> (1) Declaração de Conformidade Social e Sigilo das Informações; </ul>
                <ul> (2) Política de Segurança da Informação e Cibernética; </ul>
                <ul> (3) Plano de Continuidade de Negócios; </ul> 
                <ul> (4) Propriedade Intelectual; </ul>
                <ul> (5) Código de Ética; </ul>
                <ul> (6) Política Interna LGPD – “C&M2021-01-LGPD”. </ul>                
            </menu>
            
        <p> <b>IMPORTANTE:</b> Os documentos referenciados de (1) a (6) estarão sempre disponíveis e atualizados no endereço:  https://br.cmsw.com/politicas/ </p>
        
    ";

    $texto[3] = 
    "
        <p> <b> CLÁUSULA SEGUNDA: DO PRAZO DE VIGÊNCIA </b></p> 

        <p> 
            <b>2.1.</b> O presente Contrato, vigorará pelo prazo de <b> **--VIGENCIA_CONTRATO--** </b>, contados a partir da data da assinatura digital, conforme termos 
            da <b><u>MEDIDA PROVISÓRIA</b> No 2.200-2, DE 24 DE AGOSTO DE 2001 e LEI Nº 14.063, DE 23 DE SETEMBRO DE 2020 </b></u>, ou da forma convencional de assinatura.
        </p>
        
        <p> <b>CLÁUSULA TERCEIRA: DO PREÇO</b> </p> 

        <p> 
            <b>3.1.</b> Os preços estão aqueles mencionados com os critérios abaixo e deverão ser pagos à C&M SOFTWARE por meio de PIX, DOC, TED ou boleto bancário, 
            ou qualquer outro que venha substituí-los.
        </p>        
            <p> <b>a)</b> O valor da Implantação é de R$ **--IMPLANTACAO--** **--IMPLANTACAO/EXTENSO--**, **--TEXTO_IMPLANTACAO--** </p>
            
            <p>
                <b>a.1)</b> O valor da implantação descrito acima contempla: a) Setup do Data Center da C&M Software, b) Treinamento da Plataforma e c) 40 (quarenta) 
                horas para mapeamento de sistemas e processos.
            </p>
            
            <p> 
                <b>b)</b> Pelo licenciamento de uso do software ROCKET® serão cobrados os preços, por transação solicitada (independente se houve retorno dos órgãos consultados), 
                conforme Tabela de Preços disposta no Anexo III (três) do presente Contrato. 
            </p>
          
            <p>
                <b>b.1)</b> Não serão cobradas as execuções até 05 (cinco) laços dentro de um fluxo (nessa hipótese será considerada, para fins de cobrança, 
                uma transação solicitada). 
            </p>

            <p> <b>b.2)</b> A partir do processamento do 6º (sexto) laço (dentro de um fluxo), será cobrado cada laço como uma nova transação. </p>
            
            <p> 
                <b>b.3)</b> Laço (“Loop”): ocorre quando, dentro da execução de um determinado fluxo, há necessidade de processar um mesmo conjunto de instruções, 
                por repetidas vezes, de forma a coletar dados em cada interação dessa repetição.
            </p>
        
            <p> 
                <b> c) Licença de Uso </b>, no valor de <b> **--PACOTE--** **--PACOTE/EXTENSO--** </b> mensais, contempla: a) Suporte e Monitoramento 24x7x365; b) Atualização de versão; c) 
                Infraestrutura, incluindo licenças de Banco de Dados; d) Site de contingência com redundância da aplicação e Banco de Dados; e) 
                <b> **--TRANSACOES_ENGINE--** **--TRANSACOES_ENGINE/EXTENSO--** </b> transações de Engine:
            </p>         
            <p> 
                <b>c.1)</b> Para o quantitativo de consultas excedentes serão aplicados, progressivamente, os preços da demais faixas de forma escalonada, 
                até atingir o volume total de consultas.
            </p>
            <p> 
                <b>c.2)</b> O valor total mensal será calculado pela somatória do valor mínimo mensal previsto no item “c” acima, 
                acrescido do valor resultante das consultas excedentes.
            </p>                    
            <p> 
                <b>c.3)</b> A não utilização pelo <b> CLIENTE </b> de qualquer funcionalidade do Software Rocket, bem como a não utilização das transações contempladas no 
                valor mensal de <b>Licença de Uso</b>, não gerará ao <b> CLIENTE </b> nenhum crédito e/ou desconto, pois toda infraestrutura do Software Rocket estará mensalmente 
                disponibilizada ao <b> CLIENTE </b> desde a assinatura do presente Contrato.
            </p>                        
            <p>
                c.4) A não utilização integral das transações contempladas no valor mensal da <b>Licença de Uso</b> não serão transferidas para o mês seguinte, sendo 'zeradas' 
                a cada período de cobrança mensal e não se compensarão com eventual utilização excedente em mês(es) futuro(s).
            </p>
            <p>
                <b>c.5)</b> Pelo tipo de contratação (licenciamento de software), os valores mensais não estão sujeitos a cálculos “pro rata die”.
            </p>

            <p> <b>d)</b> Os valores não contemplam tributos e serão acrescidos quando da emissão da Nota Fiscal/Fatura. </p>
        
        <p> 
            <b>3.1.1.</b> O primeiro faturamento da “<b>Licença de Uso</b>” será integralmente cobrado, conforme valor estabelecido no item “V – DO PREÇO” do Quadro Resumo, 
            independente da data de vencimento e início do Contrato, não sendo aplicada a forma de cobrança “pro rata die”.
        </p>
        
            <p>
                <b>3.2.</b> Acordam as Partes que os faturamentos terão datas de cortes para aferição todo o dia <b> **--CORTE_FATURAMENTO--** **--CORTE_FATURAMENTO/EXTENSO--** </b>
                de cada mês, com prazo de pagamento de <b> **--PRAZO_PAGAMENTO--** **--PRAZO_PAGAMENTO/EXTENSO--** </b> dias contados da apresentação da nota fiscal/fatura, 
                ocorrendo o primeiro faturamento <b> 19 (dezenove) </b>, independentemente da conclusão da implantação e do uso.
            </p> 

            <p>
                <b> 3.2.1. </b> A <b>C&M SOFTWARE</b> informará ao <b> CLIENTE </b> sobre a emissão do documento fiscal específico, por meio do e-mail disposto no item “II.2 
                – RESPONSÁVEIS FINANCEIROS” do Quadro Resumo, enviando também nessa oportunidade o link para emissão da Nota Fiscal Eletrônica e respectivos boletos de pagamento.
            </p>
            <p><span style='color:#e74c3c'>
                <b>3.2.2.</b> Por exigência fiscal, os valores dos serviços de Assessoria e Adequações do Projeto, quando cabíveis ou diretamente contratados através 
                deste instrumento, serão faturados por <b> C&M SOFTWARE E CONSULTORIA LTDA</b>., C.N.P.J. nº 14.289.105/0001-04;
            </span></p>
           
            <p>
                <b>3.3.</b> Quando solicitada pelo <b> CLIENTE </b>, serão de sua responsabilidade as despesas de viagens referentes ao transporte aéreo ou terrestre 
                (quando o aéreo não for possível) e estadias ocorridas com os profissionais da <b>C&M SOFTWARE</b>, sempre que houver necessidade de deslocamento da equipe da 
                <b>C&M SOFTWARE</b>, a locais fora da região metropolitana de São Paulo/SP e Barueri/SP e cidades contíguas.
            </p>        
           
    ";

    $texto[4] =
    "   
        <p>
            <b>3.4.</b> Como forma de manter a hegemonia dos custos, as partes elegem, desde já, o índice estabelecido será o <b>**--INDICE_REAJUSTE--**</b>, aquele de correção monetária,
            aplicável, anualmente, ou prazo inferior, se a lei permitir, de acordo entre as partes, aos preços referidos neste Contrato.
        </p>

        <p>
            <b> 3.4.1. </b> Quando aplicável e na hipótese de atraso ou ausência de publicação do índice aplicável, a <b>C&M SOFTWARE</b> emitirá as notas fiscais/faturas usando o 
            último índice publicado. Imediatamente após a publicação seguinte do referido índice, a <b>C&M SOFTWARE</b> emitirá os títulos para o pagamento e/ou ressarcimento da 
            diferença entre valor já cobrado e os valores efetivamente devidos, de acordo com o prazo de vencimento.
        </p> 

        <p>                 
            <b>3.4.2.</b> Na falta desse índice ou, se permitido por lei, ou por decisão judicial, será aplicado aos preços qualquer outro índice oficial, de variação diária, 
            ou, se inexistente, de variação mensal, calculando “pro rata die”, e que mais eficientemente elide os efeitos inflacionários da moeda corrente nacional, 
            o qual será eleito mediante comum acordo entre as partes.
        </p>
        
        <p> 
            <b>3.5.</b> Na hipótese de ocorrerem fatos ou atos que possam prejudicar o equilíbrio econômico-financeiro do Contrato, as partes envidarão seus melhores esforços 
            para regular e disciplinar a situação criada, de forma a evitar qualquer perda de natureza econômica, financeira ou outra qualquer.
        </p>
        
        <p>
            <b>3.6.</b> Se, durante a vigência deste Contrato, forem criados tributos ou alteradas as alíquotas dos atuais, de forma a majorar ou diminuir o ônus das Partes, 
            os preços poderão ser revistos, de modo a serem ajustados a essas modificações, mediante envio de notificação por escrito da <b>C&M SOFTWARE</b> ao <b> CLIENTE </b>.
        </p>
        
        <p> 
            <b>3.7.</b> A <b>C&M SOFTWARE</b> executará os serviços descritos neste Contrato em sua sede, ou de suas futuras filiais, as quais emitirão o correspondente documento 
            fiscal, haja vista serem consideradas, individualmente, como estabelecimentos ou locais, onde a <b>C&M SOFTWARE</b> desenvolve a sua atividade principal, de modo permanente ou 
            eventual, nos termos do artigo 4º da Lei Complementar nº. 116, de 31.07.2003, publicada no Diário Oficial da União de 01/08/2003.
        </p>
        
        <p> 
            <b>3.8</b>. O inadimplemento de toda e qualquer importância cobrada com base no presente Contrato, na data de seu vencimento, implicará na incidência automática de multa 
            moratória no percentual de 2% (dois por cento) e juros de mora de 1% (um por cento) ao mês, encargos esses incidentes sobre o valor do débito atualizado de acordo com 
            o índice estabelecido no item “VIII – DO REAJUSTE CONTRATUAL” do Quadro Resumo, calculado “pro rata die” a partir da data de vencimento do respectivo documento de 
            cobrança até a data do efetivo pagamento.
        </p>
        <p>
            <b>3.8.1.</b> Os mencionados juros de mora, multa moratória e atualização monetária serão cobrados automaticamente no faturamento do mês subsequente.
        </p>
        <p>        
            <b>3.9.</b> O acesso ao software ROCKET® poderá ser suspenso, sem aviso prévio, se a inadimplência do <b> CLIENTE </b> durar <b>mais de 10 (dez) dias</b>, 
            contados da data de vencimento, e neste caso não será reiniciada a não ser que todos os valores devidos sejam pagos na sua totalidade, sem prejuízo do direito da 
            <b>C&M SOFTWARE</b> de rescindir o presente Contrato.
        </p>
        <p>
            <b>3.9.1.</b> Após a comprovação do pagamento dos valores em atraso pelo <b> CLIENTE </b>, o acesso ao software ROCKET® será restabelecido automaticamente.
        </p>
        <p><b>CLÁUSULA QUARTA: DO ACESSO AO ROCKET®, IMPLANTAÇÃO E ATUALIZAÇÕES</b></p>
        <p>
            <b>4.1.</b> O <b> CLIENTE </b> recebeu, no momento da contratação, ou até mesmo durante o processo de implantação e ativação dos produtos contratados, 
            manuais explicativos exemplificando o acesso ao software ROCKET®.
        </p>
        <p>
            <b>4.2.</b> A <b>C&M SOFTWARE</b> poderá promover atualizações no ROCKET® que serão sempre aplicadas na última versão disponibilizada em uso.
        </p>
        <p>
            <b>4.2.1.</b> Toda nova implementação ou atualização no ROCKET®, solicitada pelo <b> CLIENTE </b>, após aprovação da <b>C&M SOFTWARE</b>, 
            será incorporada na forma de licenciamento e propriedade do ROCKET®. 
        </p>
    
        <p> 
            <b>4.3.</b> Se forem realizadas atualizações do ROCKET®, a <b>C&M SOFTWARE</b> obriga-se a comunicar e disponibilizá-las ao <b> CLIENTE </b>, 
            gratuita e imediatamente.
        </p>
    
        <p><b>CLÁUSULA QUINTA: DO SUPORTE TÉCNICO</b></p>
        <p>
            <b>5.1.</b> O suporte técnico ao ROCKET® será prestado pela <b>C&M SOFTWARE</b> ou terceiros por ela credenciados via telefone (+55 11 3365-2666) ou correio eletrônico 
            (suporte@cmsw.com.br), sem custos adicionais para o <b> CLIENTE </b>, nas seguintes condições:
        </p>
        <p>
           <b>5.1.1.</b> O Suporte Operacional da <b>C&M SOFTWARE</b>, responsável direto pela disponibilidade do produto, bem como por responder a questionamentos iniciais, 
           poderá ser acessado 07 (sete) dias por semana, 24 (vinte e quatro) horas por dia, 365 (trezentos e sessenta e cinco) dias por ano (7x24x365).
        </p>
        <p>        
            <b>5.1.2.</b> O Suporte de Inteligência de Negócios (<b>SIN</b>) da <b>C&M SOFTWARE</b>, responsável direto pela aplicação de regras, fluxos, integrações e demais 
            conexões pertinentes e existentes no ROCKET®, poderá ser acessado no horário comercial (09:00 às 18:00) e segundo o calendário de feriados da cidade de Barueri/SP.
        </p>
        <p>
            <b>5.1.3.</b> O Suporte de Implantação e Qualidade (<b>SIQ</b>) da <b>C&M SOFTWARE</b>, responsável direto pelo Treinamento, Implantação e Qualidade do ROCKET®, 
            poderá ser acessado, também, no horário comercial e segundo o calendário de feriados da cidade de Barueri/SP.
        </p>    
    ";

    $texto[5] =
    "
        <b>CLÁUSULA SEXTA: DO TREINAMENTO</b>
        <p>
            <b>6.1.</b> O treinamento ao ROCKET® será concedido pela <b>C&M SOFTWARE</b> ou terceiros por ela credenciados, nas instalações físicas da <b>C&M SOFTWARE</b>, do 
            <b> CLIENTE </b>, ou outro local indicado por este.
        </p>
        <p>
            <b>6.2.</b> O treinamento deverá ser solicitado pelo <b> CLIENTE </b>, com um prazo mínimo de 30 (trinta) dias de antecedência, sendo que, caso o local escolhido 
            seja fora da região metropolitana da cidade de São Paulo, as despesas com transportes, Licença de Uso e alimentação dos instrutores, serão de responsabilidade exclusiva do 
            <b> CLIENTE </b>.
        </p>
        
        <p> <b>CLÁUSULA SÉTIMA: DAS OBRIGAÇÕES DA C&M SOFTWARE</b> </p>
        <p>
            <b>7.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, a <b>C&M SOFTWARE</b> obriga-se a: 
        </p>
        <p>
            <b>7.1.1.</b> Executar o objeto deste Contrato, com a sua usual diligência, padrão e com observância das leis aplicáveis.
        </p>
        <p>
            <b>7.1.2.</b> Realizar a manutenção preventiva e corretiva do software objeto deste Contrato.
        </p>
        <p>
            <b>7.1.3.</b> Atualizar os sistemas que compõem o ROCKET® para não incorrer em obsolescência tecnológica.
        </p>
        <p>
            <b>7.1.4.</b> A partir da assinatura do presente Contrato e durante toda a sua vigência, possuir e manter infraestrutura tecnológica que suporte o volume mínimo de 
            transações contratado e eventual superação de uso deste mesmo volume em até 3 (três) vezes, de tal modo a não gerar impacto impeditivo de uso ao <b> CLIENTE </b> no momento do uso.
        </p>
        <p>
            <b>7.1.5.</b> Segregar, no prazo de 90 (noventa) dias, os dados do <b> CLIENTE </b> dos demais dados de outros <b> CLIENTE s </b> do software ROCKET®, durante o período inicial até a
            estabilização. Não será permitida a guarda de dados ou informações nos Banco de Dados da <b>C&M SOFTWARE</b> por período superior ao acima avençado.
        </p>
        <p>
            <b>7.1.6.</b> Manter a disponibilidade mínima de 95% (noventa e cinco por cento) do sistema e de suporte, por 7 (sete) dias na semana e 24 (vinte e quatro) horas no dia, 
            garantindo, adicionalmente, durante o horário comercial a disponibilidade mínima de 99,7 % (noventa e nove vírgula sete por cento).
        </p>
        <p>
            <b>7.1.6.1.</b> Não caracterizará indisponibilidade do sistema a ocorrência dos seguintes eventos:
        </p>
            
            <ul> <b>a)</b> execução de manutenção, comunicada pela <b>C&M SOFTWARE</b> com mínimo de 15 (quinze) dias de antecedência; </ul>

            <ul> <b>b)</b> operação inadequada do software e dos equipamentos pelo <b> CLIENTE </b>, em desacordo com as instruções da <b>C&M SOFTWARE</b>; </ul>

            <ul> <b>c)</b> falhas ocasionadas em relação à infraestrutura do <b> CLIENTE </b> ou na rede de comunicação. </ul>
        <p>
            <b>7.1.7.</b> O <b> CLIENTE </b> tem conhecimento que toda a comunicação por intermédio da rede mundial de computadores (internet) está sujeita a interrupções 
            e/ou atrasos, podendo ocorrer problemas de transmissão ou de recepção das informações acessadas. 
        </p>
        <p>
            <b>7.1.8.</b> Toda e qualquer responsabilidade da <b>C&M SOFTWARE</b> limita-se, única e exclusivamente, aos sistemas desenvolvidos sob sua autoria. 
            A <b>C&M</b> não responderá pela qualidade de produtos de terceiros, mesmo que tais produtos de terceiros precisem ser incorporados ao sistema.
        </p>
        <p>
            <b>7.1.9.</b> A <b>C&M SOFTWARE</b> e o <b> CLIENTE </b>, desde já permitirão acesso do Banco Central do Brasil – BACEN aos contratos, à documentação e às informações 
            referentes ao licenciamento ora contratado, aos dados armazenados e às informações sobre seus processamentos, às cópias de segurança dos dados e das informações, 
            bem como aos códigos de acesso aos dados e às informações. 
        </p>
        
        <p><b>CLÁUSULA OITAVA: DAS OBRIGAÇÕES DO CLIENTE</b></p>
        <p>
            <b>8.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, o <b> CLIENTE </b> obriga-se a: 
        </p>
        <p>
            <b>8.1.1.</b> Agir de acordo com todas as leis, regras e regulamentações governamentais aplicáveis no acesso às informações. 
        </p>
        <p>
            <b>8.1.2.</b> Efetuar os pagamentos devidos pela contratação, de acordo com as disposições deste Contrato.
        </p>
        <p>
            <b>8.1.3.</b> Disponibilizar todos os dados/informações e ambientes de terceiros, necessários à execução deste Contrato.
        </p>
        <p>
            <b>8.1.4.</b> Em face de estar ciente que a informação tem objetivo único e exclusivo de suporte ao seu negócio, fica expressamente proibida a impressão e/ou divulgação a 
            terceiros das consultas realizadas, podendo a <b>C&M SOFTWARE</b> rescindir este Contrato por justa causa, bem como sendo o <b> CLIENTE </b> responsável pelas sanções penais e 
            civis delas advindas.
        </p>
        <p>
            <b>8.1.5.</b> O ROCKET® disponibiliza ao <b> CLIENTE </b> dados e informações pessoais ou empresariais dos consultados com quem pretende realizar negócios. Estes negócios devem estar 
            fundados na ética e comportamento moral ilibado, em especial, no uso das informações.
        </p>

    ";

    $texto[6] = 
    "
       <p>
            <b>8.1.6.</b> Manter sob sigilo os códigos e senhas de acesso ao ROCKET®, sendo de sua plena e total responsabilidade o uso indevido, bem como toda a gestão dos controles de 
            acesso. Em caso de perda, fraude ou qualquer outro risco na guarda, a <b>C&M SOFTWARE</b> deverá ser comunicada por escrito, da necessidade de bloqueio do acesso anterior e criação 
            de novo acesso.
        </p>
        <p>
            <b>8.1.7.</b> Não comercializar os serviços ou prestar informações a outras empresas e/ou entidades que prestam serviços de informações.
        </p>
        <p>
            <b>8.1.8.</b> Assumir total responsabilidade por eventuais excessos cometidos por seus prepostos ou operadores;
        </p>
        <p>            
            <b>8.1.9.</b> Manter estrutura adequada para o uso do software ROCKET®;
        </p>
        <p>
            <b>8.1.10.</b> Não utilizar os códigos de acesso e senha dos assinantes para outros fins que não seja o objeto deste contrato.
        </p>
        <p>
            <b>8.1.11.</b> Cumprir os planos de consultas oferecidos pela <b>C&M SOFTWARE</b> e quitá-las conforme previsto neste Contrato.
        </p>
        <p>
            <b>8.1.12.</b> Permitir livre acesso, aos profissionais designados pela <b>C&M SOFTWARE</b>, aos locais onde serão executadas manutenções, preventivas ou corretivas, do software objeto deste Contrato, nos horários estabelecidos para estas tarefas.
        </p>
        <p>
            <b>8.1.13.</b> Desde já, reconhecer que independente do uso do volume mínimo de transações contratado conforme item “PREÇO” do Quadro Resumo, que a infraestrutura responsável por acolher este volume em até 3 (três) vezes já se encontra a sua disposição para uso a partir do momento da assinatura do presente Contrato, ficando a sua deliberação e decisão o melhor momento para uso, sendo que esta decisão não impactará as demais responsabilidades deste instrumento.
        </p>
        <p>
            <b>8.2.</b> Cada parte deverá orientar seus representantes para que cumpram as orientações relativas à segurança, bem como normas e procedimentos, durante o período em que esses representantes estiverem designados para prestarem serviços nas dependências da outra parte. 
        </p>
        <p>            
            <b>8.3.</b> O <b> CLIENTE </b> declara que obtém e obteve as devidas autorizações, consentimentos e permissões, especialmente sobre os dados considerados sensíveis pela Lei, 
            quando utilizados, na forma da legislação em vigor, para o tratamento dos dados necessários para execução do software ora licenciado, eximindo a <b>C&M SOFTWARE</b> de 
            qualquer responsabilidade pela obtenção dos devidos consentimentos.
        </p>

        <p><b>CLÁUSULA NONA: DA RESCISÃO</b></p>
        <p>
            <b>9.1.</b> O contrato não poderá ser rescindido, antecipadamente, por qualquer das partes, sem justo motivo, sob pena de aplicação automática de multa compensatória e 
            prefixação de perdas e danos equivalente a 4 (quatro) vezes e meia (4,5) a média dos faturamentos ocorridos nos últimos 12 (doze) meses, ou período inferior, se disponível,
            com a finalidade de recompor a <b>C&M SOFTWARE</b> pelos prejuízos decorrentes da rescisão antecipada e injustificada, posto que esta realizou o gerenciamento e planejamento 
            de custos, infraestrutura de equipamentos e softwares, equipes técnicas de suporte, manutenção e desenvolvimento, etc., com vistas ao cumprimento das obrigações contratuais 
            no prazo contratado entre as Partes, assim como, o vencimento antecipado do período do Aviso Prévio, através de Nota Fiscal emitida na data da solicitação, com vencimento 
            para 05 (cinco) dias.
        </p>
        <p>
            <b>9.2.</b> Este instrumento poderá ser rescindido, ainda, motivadamente, de forma imediata e de pleno direito:
        </p>
        <p>
            <b>a)</b> descumprimento de qualquer das cláusulas do Contrato, desde que não sanada no prazo de 10 (dez) dias a contar do recebimento da notificação da outra Parte neste sentido;
        </p>
        <p>
            <b>b)</b> a outra Parte vir a ter a sua falência ou recuperação judicial/extrajudicial requerida ou decretada, ou insolvência civil dos sócios, mesmo que presumida, bem como a condenação de qualquer um dos seus sócios em processos criminais; e,
        </p>
        <p>
            <b>c)</b> a outra Parte vir a ter sua idoneidade técnica ou financeira abalada ou o seu quadro societário modificado, de forma a prejudicar a fiel execução de suas obrigações contratuais, a critério da outra Parte.
        </p>
        <p>
            <b>d)</b> o encerramento das atividades, mesmo que voluntária, do <b> CLIENTE </b> ou alienação de direitos ou carteira, não o exime das infrações contratuais e consequentes multas a serem aplicadas.
        </p>
        <p>
            <b>9.3.</b> O presente Contrato poderá ser encerrado, sem qualquer ônus, em razão da ocorrência de eventos de caso fortuito ou de força maior, regularmente comprovados, impeditivos 
            da execução deste Contrato. Quando for possível a execução apenas parcial do Contrato, o <b> CLIENTE </b> poderá decidir entre o cumprimento parcial ou o término do 
            Contrato.
        </p>
        <p>
            <b>9.4.</b> Na ocorrência do término deste Contrato, por qualquer motivo, o <b> CLIENTE </b> remunerará a <b>C&M SOFTWARE</b> pelos serviços já prestados e concluídos, 
            bem como efetuará o pagamento das despesas já ocorridas, estabelecendo as Partes desde já que o faturamento da “Licença de Uso”, em função do tipo de contratação 
            (licenciamento do software) será integralmente cobrado, conforme valor estabelecido no item “V – DO PREÇO” do Quadro Resumo, independente da data da rescisão, 
            não sendo aplicada a forma de cobrança “pro rata die”.
        </p>
        <p>
            <b>9.5.</b> Antes do término da vigência do presente Contrato, ou por qualquer outro motivo de rescisão deste Contrato, o <b> CLIENTE </b> poderá utilizar as ferramentas
            de exportação, conforme disponíveis, para realizar a transferência final dos registros (logs) associados com as atividades dos usuários do <b> CLIENTE </b>, configurando a 
            transferência dos dados de acesso. Quando do encerramento do Contrato, a <b>C&M SOFTWARE</b> excluirá todos os Dados Pessoais e de acesso remanescentes, 
            configurando a exclusão de todos os dados pessoais e de acesso.
        </p>
    ";

    $texto[7] = 
    "    
        <p><b>CLÁUSULA DÉCIMA: DAS DISPOSIÇÕES GERAIS</b></p>
        <p>
            <b>10.1.</b> Nenhuma disposição deste contrato poderá ser interpretada como tendo as Partes estabelecido qualquer forma de sociedade ou associação, de fato ou de direito, 
            remanescendo cada uma das partes com suas obrigações civis, comerciais, trabalhistas e tributárias, de forma autônoma.
        </p>
        <p>
            <b>10.2.</b> Nenhuma das Partes poderá ceder ou transferir, no todo ou em parte, os direitos e obrigações decorrentes deste Contrato, sem a anuência prévia e expressa da 
            outra Parte.
        </p>
        <p>
            <b>10.3.</b> Qualquer aditamento ou alteração a este Contrato somente será válida se feito por meio de aditivo contratual, escrito e assinado pelas Partes.
        </p>
        <p>
            <b>10.4.</b> Todas as obrigações e condições aqui estipuladas obrigam as Partes e seus sucessores a qualquer título.
        </p>
        <p>
            <b>10.5.</b> Todas as notificações ou comunicações dadas segundo o presente Contrato, de uma Parte à outra, deverão ser endereçadas somente por via postal através de 
            carta registrada, com aviso de recebimento, para os representantes legais nos endereços constantes na qualificação das Partes. Se houver alteração do Representante Legal,
            deverá ser anexado documento de comprovação para o exercício do ato. 
        </p>
        <p>
            <b>10.6.</b> A tolerância de uma Parte com a outra, relativamente a qualquer violação ou descumprimento de quaisquer obrigações ora assumidas, não será considerada 
            moratória, novação ou renúncia a qualquer direito, constituindo mera liberalidade, que não impedirá a Parte tolerante de exigir da outra o fiel cumprimento deste 
            Contrato, a qualquer tempo.
        </p>
        <p>
            <b>10.7.</b> Se qualquer cláusula ou condição deste Contrato vier a ser considerada ilegal, inválida ou inexequível nos termos da legislação brasileira, as demais 
            cláusulas e condições continuarão em pleno vigor e efeito.
        </p>
        <p>
            <b>10.8.</b> O <b> CLIENTE </b>, desde já, autoriza a <b>C&M SOFTWARE</b> a incluir o seu nome na sua <b>Lista de Clientes</b>, assim como sua divulgação, pelos meios 
            de comunicação próprios, juntamente com os nomes de outros clientes, mas não revelará, comunicará ou de qualquer forma fará propaganda a qualquer terceiro de detalhes 
            deste Contrato.
        </p>
        <p>
            <b>10.9.</b> O presente Contrato constitui o acordo final entre as Partes com relação às matérias aqui expressamente tratadas, superando e substituindo todas as propostas,
            acordos, entendimentos e declarações anteriores, orais ou escritos.
        </p>
        <p>
            <b>10.10.</b> As <b>Partes</b> comprometem-se a não aliciar os profissionais regidos por Contrato de Trabalho e/ou como Prestadores de Serviços que estão envolvidos, 
            direta ou indiretamente, com objeto deste contrato. Esta prática, quando comprovada, motivará a parte afetada à rescisão motivada do presente contrato, aplicando-se, 
            ainda, à <b>Parte</b> afetada, a aplicação do <b>art. 608 do Código Civil</b>.
        </p>
        <p>
            <b>10.11.</b> O presente Contrato é considerado título executivo extrajudicial, nos termos do inciso III, do artigo 784, do Código de Processo Civil, sujeitando-se, 
            dessa forma, à legislação aplicável à matéria.
        </p>
        <p>
            <b>10.12.</b> Cada uma das Partes declara, garante e concorda, reciprocamente, que a celebração, outorga e execução deste Contrato foi devidamente autorizada pelos seus 
            legítimos representantes legais, na forma dos seus respectivos documentos societários, sendo que o fornecimento de eventual informação inverídica, incompleta ou inidônea 
            será considerado infração aos princípios da informação e boa-fé contratual, respondendo a parte que assim as prestou civil e criminalmente, restando claro que este 
            contrato constitui obrigação legal, válida e vinculante entre as Partes.
        </p>
        <p>
            As Partes elegem o foro da Comarca de Barueri, Estado de São Paulo para dirimir quaisquer dúvidas ou atos oriundos ou relativos a este contrato, renunciando a qualquer 
            outro por mais privilegiado que seja.
        </p>
        <p>
            E assim, por estarem justas e contratadas, as partes assinam o presente em 02 (duas) vias de igual teor, na presença das testemunhas abaixo.
        </p>

        <p>Baruei $data_extenso </p>    
    ";

?>