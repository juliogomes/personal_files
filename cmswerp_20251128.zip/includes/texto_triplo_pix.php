<?php
setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
$data_extenso = strftime('%d de %B de %Y', strtotime('today'));

$texto[0] =
"
    À<br> 
    <b> **--CLIENTE--** </b> <br>
    **--ENDERECO--** - **--BAIRRO--** <br> 
    **--CEP--** - **--CIDADE--** - **--UF--** <br> 
    <br> 
    <b> A/C.: **--REPRESENTANTE_LEGAL--** </b> 
    <br></br> 
   
    Assunto: CONTRATO DE LICENCIAMENTO DE USO DO SOFTWARE TRIPLE PIX. 
    <br></br> 
    Prezado Senhor,
    <br>   

    <p>Primeiramente manifestamos nossos sinceros agradecimentos pela contratação do nosso software, e lhes damos Boas-Vindas à família C&M Software.</p>
    <p>
        Encaminhamos em anexo o contrato de Licenciamento do Software que será assinado na <b>Plataforma de Assinaturas</b> da <b>D4Sign</b> (especializada em identificação digital), 
        com plena validade jurídica. As assinaturas das pessoas jurídicas da Contratante e Contratada serão realizadas sob a forma digital, com a utilização de Certificados Digitais 
        e-CNPJ.
    </p>
    <p>
        As testemunhas assinarão eletronicamente (sem a necessidade de Certificado Digital), de acordo com as formas de comprovação de autoria e integridade de documentos realizadas 
        pela Plataforma de Assinaturas da D4Sign. O passo-a-passo para assinatura do presente instrumento será enviado por e-mail.
    </p>    
    <p>
        Caso contrário, segue anexo o “Contrato de Licenciamento do Produto TRIPLE Pix”, é necessário que seja assinado em 02 (duas) vias e entregue no endereço de nossa sede:
    </p>
    

    <b>**--CM_SOFTWARE--**</b>
    <br> A/C: Departamento Jurídico.
    <br> Alameda Rio Pardo, nº 27 - Alphaville Industrial.
    <br> 06455-005 – Barueri – SP. 

    <br> Os documentos que devem acompanhar o contrato são:
    
    <ul> Cópia simples do Contrato Social/Estatuto Social, bem como a última alteração/ata de assembleia; </ul>
    <ul> Cartão do CNPJ; </ul>
    <ul> Cópia simples do RG e CPF do signatário do Contrato; e, </ul>
    <ul> Se o signatário não constar do Contrato Social/Estatuto Social, solicitamos cópia da procuração que lhe outorgou poderes. </ul>
    
    <br>
    Quaisquer dúvidas podem ser esclarecidas através do e-mail juridico@cmsw.com, ou pelo telefone (11) 3365-2666.
    <br></br><br></br><br></br><br>
    Atenciosamente,
    <br></br><br>
    <table>
        <thead>
            <th style='text-align:center; width:800px;' >               
                <small>
                    **--CM_SOFTWARE--**
                    <br>Departamento Jurídico 
                </small>                               
            </th>
        </thead>
    </table>
";

$texto[1] =
"          
    <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>
                <td style='text-align:center;'>
                    <h3>CONTRATO DE LICENCIAMENTO DO SOFTWARE TRIPLE PIX</h3>
                    <hr>
                </td>
            </tr>
        </tbody>
    </table>
   
    <table border='1' cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>
                <td style='text-align:center'><b>QUADRO RESUMO</b></td>
            </tr>
            <tr>
                <td>
                    <b>CONTRATADA</b>
                    <br></br>
                    <p>
                        <b> **--CM_SOFTWARE--** </b>, pessoa jurídica de direito privado com sede na Alameda Rio Pardo, nº 27, 
                        Bairro Alphaville Industrial, no município de Barueri, Estado de São Paulo, CEP 06455-005, inscrita no CNPJ/MF sob o 
                        nº <b> **--CM_SOFTWARE_CNPJ--** </b>, doravante denominada simplesmente “<b>C&M SOFTWARE</b>”;
                    </p>
                    <br>
                </td>
            </tr>
            <tr>
                <td>
                    <b>CONTRATANTE</b>
                    <br></br>
                    <p>
                        <b> **--CLIENTE--** </b>, pessoa jurídica de direito privado com endereço **--ENDERECO--** - **--BAIRRO--**, na cidade de **--CIDADE--**, Estado de **--UF--**, 
                        CEP **--CEP--**, inscrita no C.N.P.J. nº **--CNPJ--**, neste ato representada na forma de seus atos constitutivos por 
                        <b>**--REPRESENTANTE_LEGAL--**</b>, **--REPRESENTANTE_LEGAL/CARGO--**, C.P.F. nº **--REPRESENTANTE_LEGAL/CPF--** , e-mail: **--REPRESENTANTE_LEGAL/EMAIL--**, 
                        telefone: **--REPRESENTANTE_LEGAL/TELEFONE--** **--REPRESENTANTE_2--** doravante denominada simplesmente <b>“CLIENTE”</b>.
                    </p>                        
                    <br>
                        <ul>CONTATO RESPONSÁVEL: **--CONTATO_RESPONSAVEL--** - e-mail: **--CONTATO_RESPONSAVEL/EMAIL--** - telefone: **--CONTATO_RESPONSAVEL/TELEFONE--** </ul>                                                       
                        <ul>FINANCEIRO: **--CONTATO_FINANCEIRO--** - e-mail: **--CONTATO_FINANCEIRO/EMAIL--** - telefone: **--CONTATO_FINANCEIRO/TELEFONE--** </ul>
                        **--CONTATO_FINANCEIRO_2--**
                    <br>
                </td>
            </tr>
            <tr>
                <td>                        
                    <b><small>VIGÊNCIA / REAJUSTE / DENÚNCIA: **--VIGENCIA_CONTRATO--** **--VIGENCIA_CONTRATO/EXTENSO--** / **--INDICE_REAJUSTE--** / 180 (cento e oitenta) dias.<small></b>                       
                </td>
            </tr>
            <tr>
                <td>                        
                    <b>PREÇO</b>                        
                    <br></br>
                    <ul> 
                        O valor da Implantação é de <b> R$ **--IMPLANTACAO--** **--IMPLANTACAO/EXTENSO--**, **--TEXTO_IMPLANTACAO--**.</b>
                    </ul>
                    <ul> 
                        Para efeito de tarifação e faturamento ao ambiente do <b>TRIPLE Pix</b> os Valores BASE para tarifação por transação, que multiplicados pela quantidade de transações, será: 
                    </ul>
                    
                    <table border='1' cellpadding='1' cellspacing='1' style='width:100%'>
                        <br>
                        <tbody>
                            <tr>
                                <td style='text-align:center'>
                                    <small>Triplo Pix <b>Consolidação</b> (por transação):</small>
                                </td>
                                <td style='text-align:center'>
                                    <b><small>**--TRIPLO_PIX--**</small></b>
                                </td>
                                <td style='text-align:center'>
                                    <b><small>**--TRIPLO_PIX_EXTENSO--**</small></b>
                                </td>
                            </tr>
                        </tbody>                        
                    </table>
                    <br>  
                    <ul>
                        Os valores não contemplam tributos e serão acrescidos quando da emissão da Nota Fiscal/Fatura.
                    </ul>
                </td>
            </tr>
            <tr>
                <td>                        
                    <b>RESCISÃO CONTRATUAL</b>
                    <br></br>
                    <p>
                        <b>60% (sessenta)</b> do valor da média do faturamento mensal, nos últimos 12 meses, multiplicado pelos meses restantes.
                    </p>
                    <br>
                </td>
            </tr>
            <tr>
                <td>
                    <b>FATURAMENTO</b>
                    <br></br>
                    <p>
                        Data de corte todo o dia <b> **--CORTE_FATURAMENTO--** **--CORTE_FATURAMENTO/EXTENSO--** de cada mês </b>, com prazo de pagamento <b> **--PRAZO_PAGAMENTO--** **--PRAZO_PAGAMENTO/EXTENSO--** dias</b> contados da apresentação da nota
                        fiscal/fatura, ocorrendo o primeiro faturamento <b> 19 (dezenove) </b>, independentemente da conclusão da implantação e do uso,   
                    </p>             
                </td>
            </tr>
            <tr>
                <td>                       
                    <b>TESTEMUNHAS:</b>                       
                    <p>
                        <br>
                        Nome: **--TESTEMUNHA_CMSW--** da C&M C.P.F. nº **--TESTEMUNHA_CMSW/CPF--** e-mail: **--TESTEMUNHA_CMSW/EMAIL--** 
                        <br>
                        Nome: **--TESTEMUNHA--** C.P.F. nº **--TESTEMUNHA_CPF--** e-mail: **--TESTEMUNHA_EMAIL--** 
                    </p>
                </td>
            </tr>
            <tr>
                <td>
                    <b>Observações:</b>
                </td>
            </tr>
        </tbody>
    </table>                
";

$texto[2] =
"          
    <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>
                <td style='text-align:center;border-top:3px solid;border-bottom:3px solid;'>
                    <h3>CONTRATO DE LICENCIAMENTO DO SOFTWARE “TRIPLE Pix”</h3>
                </td>
            </tr>
        </tbody>
    </table>                    
    <p><b>CLÁUSULA PRIMEIRA: DO OBJETO</b></p>
    <p>
        <b>1.1.</b> O objeto do presente contrato é o licenciamento de uso do software <b>Triple Pix</b>, de forma não exclusiva, intransferível e temporária, nos termos e condições aqui 
        avençadas.
    </p>
    <p>
        <b>1.2.</b> Todos os novos produtos/módulos ou funcionalidades, criados pela <b>C&M SOFTWARE</b> e disponibilizados na plataforma do software <b>TRIPLE Pix</b>, serão informados ao 
        <b>CONTRATANTE</b>. A opção, pelo <b>CONTRATANTE</b>, pelos novos produtos/módulos ou funcionalidades ocorrerá na primeira utilização, servindo para todo e qualquer efeito de direito, 
        como aceitação dos preços e condições disponibilizadas no Painel de Controle constante no site do produto.
    </p>
    <p>
        <b>1.3.</b> O TRIPLE PIX disponibiliza ao CONTRATANTE o acesso ao PIX COBRANÇA, com pagamento a um PSP direto e repasse do valor a qualquer Instituição Financeira, sempre 
        atendendo definições estabelecidas por este.
    </p>
    <p>
        <b>1.4.</b> Por exigência fiscal, os valores dos serviços de Assessoria <b>BACEN</b> e Adequações do Projeto, quando cabíveis, serão faturados por <b>C&M SOFTWARE E CONSULTORIA LTDA., 
        C.N.P.J. nº 14.289.105/0001-04</b>;
    </p>
    <p>
        <b>1.5.</b> Este contrato é composto pelos anexos abaixo descritos fazem parte integrante e indissociável do contrato para todos os fins de direito:
    </p>
    <ul>
    	(1) Declaração de Conformidade Social e Sigilo das Informações;
    </ul>
    <ul> 
    	(2) Política de Segurança da Informação e Cibernética;
    </ul>
    <ul>
    	(3) Plano de Continuidade de Negócios; 
    </ul>
    <ul>
    	(4) Propriedade Intelectual;
    </ul>
    <ul>
    	(5) Código de Ética;
    </ul>
    <ul>
    	(6) Política Interna LGPD – “C&M2021-01-LGPD”.
    </ul>
    <br>
    <b>IMPORTANTE:</b> Os documentos referenciados de (1) a (6) estarão sempre disponíveis e atualizados no endereço: https://br.cmsw.com/politicas/
    <p>
        <b>CLÁUSULA SEGUNDA: DO PRAZO DE VIGÊNCIA</b>
    </p>
    <p> 
        <b>2.1.</b> O presente contrato terá vigência pelo prazo estabelecido no item “VIGÊNCIA” do Quadro Resumo.
    </p>
    <p>
        <b>CLÁUSULA TERCEIRA: DO PREÇO</b>
    </p>
    <p> 
        <b>3.1.</b> Os preços são aqueles mencionados no item “PREÇO” do Quadro Resumo e deverão ser pagos à <b>C&M SOFTWARE</b> por meio de DOC, TED, boleto bancário, Pix ou qualquer outro 
        sistema que venha substituí-los.
    </p>
    <p>
        <b>3.2.</b> Acordam as Partes que o faturamento decorrente do presente instrumento ocorrerá na forma estabelecida no item “FATURAMENTO” do Quadro Resumo.
    </p>
    <p>
        <b>3.2.1.</b> A <b>C&M SOFTWARE</b> informará ao <b>CONTRATANTE</b> sobre a emissão do documento fiscal específico, por meio do e-mail os responsáveis financeiros designados no Quadro 
        Resumo, enviando também nessa oportunidade o link para emissão da Nota Fiscal Eletrônica e respectivos boletos de pagamento, quando aplicável.
    </p>
    <p>
        <b>3.2.2.</b> A não utilização pelo <b>CONTRATANTE</b> de qualquer funcionalidade do Software TRIPLE Pix, não gerará ao <b>CONTRATANTE</b> nenhum crédito e/ou desconto, pois toda 
        infraestrutura do Software estará mensalmente disponibilizada ao <b>CONTRATANTE</b> desde a assinatura do presente contrato.
    </p>
    <p>
        <b>3.3.</b> Por exigência fiscal, os valores dos serviços de Assessoria <b>BACEN</b> e Adequações do Projeto, quando cabíveis, serão faturados por <b>C&M SOFTWARE E CONSULTORIA LTDA., 
        C.N.P.J. nº 14.289.105/0001-04</b>;
    </p>
    <p>
        <b>3.4.</b> Serão de responsabilidade do <b>CONTRATANTE</b> as despesas de viagens referentes ao transporte aéreo ou terrestre (quando o aéreo não for possível) e estadias ocorridas 
        com os profissionais da <b>C&M SOFTWARE</b>, sempre que houver necessidade de deslocamento da equipe da <b>C&M SOFTWARE</b>, a locais fora da região metropolitana de São Paulo/SP e 
        Barueri/SP.
    </p>
    <p>
        <b>3.5.</b> Como forma de manter a hegemonia dos custos, as partes elegem, desde já, o índice estabelecido no item “REAJUSTE” do Quadro Resumo, como índice de correção 
        monetária, aplicável aos preços referidos neste contrato.
    </p>
    <p>
        <b>3.5.1.</b> Quando aplicável e na hipótese de atraso ou ausência de publicação do índice aplicável, a <b>C&M SOFTWARE</b> emitirá as notas fiscais/faturas usando o último índice 
        publicado. Imediatamente após a publicação seguinte do referido índice, a <b>C&M SOFTWARE</b> emitirá os títulos para o pagamento e/ou ressarcimento da diferença entre valor já 
        cobrado e os valores efetivamente devidos, de acordo com o prazo de vencimento estabelecido no item “FATURAMENTO” do Quadro Resumo.
    </p>
";

$texto[3] = 
"
    <p>
        <b>3.5.2.</b> Na falta desse índice ou, se permitido por lei, ou por decisão judicial, será aplicado aos preços qualquer outro índice oficial, de variação diária, ou, se 
        inexistente, de variação mensal, calculando “pro rata die”, e que mais eficientemente elide os efeitos inflacionários da moeda corrente nacional, o qual será eleito mediante 
        comum acordo entre as partes.
    </p>
    <p>
        <b.3.6.</b> Na hipótese de ocorrerem fatos ou atos que possam prejudicar o equilíbrio econômico-financeiro do contrato, as partes envidarão seus melhores esforços para regular 
        e disciplinar a situação criada, de forma a evitar qualquer perda de natureza econômica, financeira ou outra qualquer.
    </p>
    <p>
        <b>3.7.</b> Se, durante a vigência deste contrato, forem criados tributos ou alteradas as alíquotas dos atuais, de forma a majorar ou diminuir o ônus das Partes contratantes, 
        os preços poderão ser revistos, de modo a serem ajustados a essas modificações, mediante envio de notificação por escrito da <b>C&M SOFTWARE</b> ao <b>CONTRATANTE</b>.
    </p>
    <p>
        <b>3.8.</b> A <b>C&M SOFTWARE</b> executará os serviços descritos neste contrato em sua sede, ou de suas futuras filiais, as quais emitirão o correspondente documento fiscal, haja 
        vista serem consideradas, individualmente, como estabelecimentos ou locais, onde a <b>C&M SOFTWARE</b> desenvolve a sua atividade principal, de modo permanente ou eventual, nos 
        termos do artigo 4º da Lei Complementar nº 116, de 31/07/2003, publicada no Diário Oficial da União de 1/08/2003.
    </p>
    <p>
        <b>3.9.</b> O inadimplemento de toda e qualquer importância cobrada com base no presente contrato, na data de seu vencimento, implicará na incidência automática de multa 
        moratória no percentual de **--PERCENTUAL_MULTA--** **--PERCENTUAL_MULTA/EXTENSO--** e juros de mora de **--PERCENTUAL_JUROS--** **--PERCENTUAL_JUROS/EXTENSO--** ao mês, encargos esses incidentes sobre o valor do débito atualizado de acordo com o 
        índice estabelecido no item “REAJUSTE” do Quadro Resumo, calculado “pro rata die” a partir da data de vencimento do respectivo documento de cobrança até a data do efetivo 
        pagamento.
    </p>
    <p>
        <b>3.9.1.</b> Os mencionados juros de mora, multa moratória e atualização monetária serão cobrados automaticamente no faturamento do mês subsequente.
    </p>
    <p>
        <b>3.10.</b> O acesso ao software poderá ser suspenso, sem aviso prévio, se a inadimplência do <b>CONTRATANTE</b> durar mais de 10 (dez) dias, contados da data de vencimento, e neste 
        caso não será reiniciada a não ser que todos os valores devidos sejam pagos na sua totalidade, sem prejuízo do direito da <b>C&M SOFTWARE</b> de rescindir o presente contrato.
    </p>
    <p>
        <b>3.10.1.</b> Após a comprovação do pagamento dos valores em atraso pelo <b>CONTRATANTE</b>, o acesso ao software será desbloqueado e voltará a funcionar automaticamente.
    </p>
    <p>
        <b>CLÁUSULA QUARTA: DO ACESSO AO SOFTWARE, IMPLANTAÇÃO E ATUALIZAÇÕES</b>
    </p>
    <p>
        <b>4.1.</b> O <b>CONTRATANTE</b> recebeu no momento da contratação, ou até mesmo durante o processo de implantação e ativação dos produtos contratados, manuais explicativos exemplificando o 
        acesso aos softwares.
    </p>
    <p>
        <b>4.2.</b> A <b>C&M SOFTWARE</b> poderá promover atualizações nos softwares e serão sempre aplicadas na última versão disponibilizada em uso.
    </p>
    <p>
        <b>4.2.1.</b> Toda nova implementação ou atualização do software, solicitada pelo <b>CONTRATANTE</b>, após aprovação da <b>C&M SOFTWARE</b>, será incorporada na forma de licenciamento. 
    </p>
    <p>
        <b>4.3.</b> Se forem realizadas atualizações do <b>software</b>, a <b>C&M SOFTWARE</b> obriga-se a comunicar e disponibilizá-las ao <b>CONTRATANTE</b>, gratuita e imediatamente.
    </p>
    <p>
        <b>4.3.</b> Pelos serviços de Implantação a <b>C&M SOFTWARE</b> configurará os sistemas que compõem a solução <b>TRIPLE PIX</b>, compreendendo os ambientes de Homologação e Produção, 
        contemplando os seguintes serviços:
    </p>
    <p>
        <b>4.3.1.</b> A Implantação contempla, ainda, o treinamento ao <b>TRIPLE PIX</b> concedido pela <b>C&M SOFTWARE</b> ou terceiros por ela credenciados, nas instalações físicas da 
        <b>C&M SOFTWARE</b>, do <b>CONTRATANTE</b>, ou outro local indicado por este, de até 3 (três) profissionais da <b>CONTRATANTE</b> na utilização do software ora contratado.
    </p>
    <p>
        <b>4.3.2.</b> O treinamento deverá ser solicitado pelo <b>CONTRATANTE</b>, com um prazo mínimo de 30 (trinta) dias de antecedência, sendo que, caso o local escolhido seja fora da 
        região metropolitana da cidade de São Paulo e Barueri, as despesas com transportes, hospedagem e alimentação dos instrutores, serão de responsabilidade exclusiva do 
        <b>CONTRATANTE</b>.
    </p>
    <p>
        <b>4.4.</b> Manter a disponibilidade mínima de operacionalidade de 99,8% (noventa e nova inteiros e oito centésimos por cento), por 7 (sete) dias na semana e 24 
        (vinte e quatro) horas no dia e 365 (trezentos e sessenta e cinco dias) por ano.
    </p>
    <p>
        <b>4.4.1.</b> Não serão considerados para cálculo de nível de operacionalidade os seguintes casos:  
    </p>       
    <ul>
        execução de manutenção, comunicada pela <b>C&M SOFTWARE</b> com mínimo de 15 (quinze) dias de antecedência;
    </ul>
    <ul> 
        operação inadequada do software e dos equipamentos pelo <b>CONTRATANTE</b>, em desacordo com as instruções da <b>C&M SOFTWARE</b>;
    </ul>
    <ul>
        falhas ocasionadas em relação à infraestrutura do <b>CONTRATANTE</b> ou de seus clientes finais.
    </ul>
    <ul>
        quando, por qualquer motivo, o <b>CONTRATANTE</b> impedir o acesso da <b>C&M SOFTWARE</b> onde estejam localizados seus equipamentos ou os por ela mantidos, postergando 
        assim o restabelecimento da operação.
    </ul>
        
";

$texto[4] =
"    
    <p>
        <b>4.5.</b> O <b>CONTRATANTE</b> tem conhecimento que toda a comunicação por intermédio da rede mundial de computadores (internet) está sujeita a interrupções e/ou atrasos, podendo ocorrer 
        problemas de transmissão ou de recepção das informações acessadas.
    </p>
    <p>
        <b>CLÁUSULA QUINTA: DAS OBRIGAÇÕES DA C&M SOFTWARE</b>
    </p>
    <p>
        <b>5.1.</b> Sem prejuízo das demais obrigações previstas neste contrato, a <b>C&M SOFTWARE</b> obriga-se a: 
    </p>
    <p>
        <b>5.1.1.</b> Executar o objeto deste contrato, com a sua usual diligência, padrão e com observância das leis aplicáveis.
    </p>
    <p>
        <b>5.1.2.</b> Realizar a manutenção preventiva e corretiva do software objeto deste contrato.
    </p>
    <p>
        <b>5.1.3.</b> Atualizar os sistemas que compõem o <b>TRIPLE Pix</b> para não incorrer em obsolescência tecnológica.
    </p>
    <p>
        <b>5.1.4.</b> A partir da assinatura do presente contrato e durante toda a sua vigência, possuir e manter infraestrutura tecnológica que suporte o volume mínimo de mensagens 
        contratado e eventual superação de uso deste mesmo volume em até 3 (três) vezes, de tal modo a não gerar impacto impeditivo de uso ao <b>CONTRATANTE</b> no momento do uso.
    </p>
    <p>
        <b>5.1.5.</b> Toda e qualquer responsabilidade da <b>C&M SOFTWARE</b> limita-se, única e exclusivamente, aos sistemas desenvolvidos sob sua autoria. A C&M não responderá pela qualidade de 
        produtos de terceiros, mesmo que tais produtos de terceiros precisem ser incorporados ao sistema.
    </p>
    <p>
        <b>5.2.</b> Segregar, no prazo de 90 (noventa) dias, os dados do <b>CONTRATANTE</b> dos demais dados de outros clientes dos softwares. Não será permitida a guarda de dados ou informações nos Banco de Dados da C&M Software por período superior ao acima avençado.
        CLÁUSULA SEXTA: DAS OBRIGAÇÕES DO <b>CONTRATANTE</b>
    </p>
    <p>
        <b>6.1.</b> Sem prejuízo das demais obrigações previstas neste contrato, o <b>CONTRATANTE</b> obriga-se a: 
    </p>
    <p>
        <b>6.1.1.</b> Agir de acordo com todas as leis, regras e regulamentações governamentais aplicáveis no acesso às informações. 
    </p>
    <p>
        <b>6.1.2.</b> Efetuar os pagamentos devidos pela contratação, de acordo com as disposições deste contrato.
    </p>
    <p>
        <b>6.1.3.</b> Disponibilizar todos os dados/informações, dados e ambientes de terceiros, necessários à execução deste contrato.
    </p>
    <p>
        <b>6.1.4.</b> Manter sob sigilo os códigos e senhas de acesso aos softwares, sendo de sua plena e total responsabilidade o uso indevido. Em caso de perda, fraude ou qualquer 
        outro risco na guarda, a <b>C&M SOFTWARE</b> deverá ser comunicada por escrito, da necessidade de bloqueio do acesso anterior e criação de novo acesso.
    </p>
    <p>
        <b>6.1.5.</b> Responsabilizar-se, civilmente por atos próprios, ou quaisquer atos de seus empregados, comitentes ou prepostos que vierem dar prejuízos, tanto materiais quanto 
        de imagem, ou de qualquer forma diminuir o patrimônio da <b>CONTRATANTE</b>.
    </p>
    <p>
        <b>6.1.6.</b> Manter estrutura adequada para o uso dos softwares, assim como, realizar a manutenção preventiva e corretiva dos itens fornecidos pela <b>C&M SOFTWARE</b>, 
        mantendo os equipamentos atualizados e operantes.
    </p>
    <p>
        <b>6.1.7.</b> Desde já, reconhecer que independente do uso do volume mínimo de mensagens contratado conforme item “PREÇO” do Quadro Resumo, que a infraestrutura responsável 
        por acolher este volume em até 3 (três) vezes já se encontra a sua disposição para uso a partir do momento da assinatura do presente contrato, ficando a sua deliberação e 
        decisão o melhor momento para uso, sendo que esta decisão não impactará as demais responsabilidades deste instrumento.
    </p>
    <p>
        <b>6.2.</b> Cada parte deverá orientar seus representantes para que cumpram as orientações relativas à segurança, bem como normas e procedimentos, durante o período em que 
        esses representantes estiverem designados para prestarem serviços nas dependências da outra parte.
    </p>
    <p>
        <b>6.2.1.</b> Fornecer, por escrito, todos os dados técnicos que vierem a ser solicitados pela <b>C&M SOFTWARE</b>, necessários para a elaboração do Projeto e execução do 
        contrato. 
    </p>
    <p>
        <b>6.2.2.</b> Fornecer, durante a execução da Implantação, sem ônus para a <b>C&M SOFTWARE</b>, recursos telefônicos e de e-mail para comunicação, bem como facilidades para 
        fotocópias de documentos. 
    </p>
    <p>
        <b>6.2.3.</b> Fornecer todos os dados técnicos necessários à disponibilização do acesso da <b>C&M SOFTWARE</b>.
    </p>  
    <p>
        <b>6.2.4.</b> Abster-se de reparar, modificar, ou mesmo adicionar novos componentes ou conexões, ou fazer alterações e/ou mudanças de qualquer tipo nas Estações de Telecomunicações, 
        sem prévia autorização por escrito por parte da C&M SOFTWARE.
    </p>
    <p>
        <b>6.3.</b> Por indicação da <b>C&M SOFTWARE</b>, o <b>CONTRATANTE</b> estará responsável pelas contratações necessárias à integração do sistema licenciado devendo estar disponíveis até a 
        data de instalação do produto licenciado.
    </p>
    <p>
        <b>CLÁUSULA SÉTIMA: DO SUPORTE TÉCNICO</b>
    </p>
    <p>
        <b>7.1.</b> O suporte técnico ao TRIPLE PIX será prestado pela <b>C&M SOFTWARE</b> ou terceiros por ela credenciados via telefone (+55 11 3365-2666) ou correio eletrônico 
        (suporte@cmsw.com.br) sem custos adicionais para o <b>CONTRATANTE</b>.
    </p>
     
";

$texto[5] =
"      
    <p>
        <b>7.2.</b> O Suporte Operacional da <b>C&M SOFTWARE</b>, responsável direto pela disponibilidade do produto, bem como por responder a questionamentos iniciais, poderá ser 
        acessado 07 (sete) dias por semana, 24 (vinte e quatro) horas por dia, 365 (trezentos e sessenta e cinco) dias por ano (7x24x365).
    </p> 
    <p>
        <b>CLÁUSULA OITAVA: DA RENOVAÇÃO ou RESCISÃO</b>
    </p>
    <p>
        <b>8.1.</b> O presente contrato não poderá ser rescindido, antecipadamente, por qualquer das partes, sem justo motivo, sob pena de aplicação automática de multa disposta no 
        item “VI – DA RENOVAÇÃO DO CONTRATO” do Quadro Resumo.
    </p>
    <p>
        <b>8.2.</b> Para fins de suporte ao investimento realizado pela <b>C&M SOFTWARE</b>, as partes concordam que, sob nenhum aspecto, venham a rescindir o presente instrumento por, 
        no mínimo, o primeiro período contratado, a contar da data da assinatura do presente instrumento.
    </p>

    <p>
        <b>8.3.</b> Este instrumento poderá ser rescindido, ainda, motivadamente, de forma imediata e de pleno direito:
    </p>
    <ul>    
        a) descumprimento de qualquer das cláusulas do contrato, desde que não sanada no prazo de 10 (dez) dias a contar do recebimento da notificação da outra Parte neste sentido;
    </ul>
    <ul>
        b) a outra Parte vir a ter a sua falência ou recuperação judicial/extrajudicial requerida ou decretada, ou insolvência civil dos sócios, mesmo que presumida, bem como a 
        condenação de qualquer um dos seus sócios em processos criminais; e,
    </ul>
    <ul>
        c) a outra Parte vir a ter sua idoneidade técnica ou financeira abalada ou o seu quadro societário modificado, de forma a prejudicar a fiel execução de suas obrigações 
        contratuais, a critério da outra Parte.
    </ul>
    <ul>
        d) o encerramento das atividades, mesmo que voluntário, do <b>CONTRATANTE</b> ou alienação de direitos ou carteira, não o exime das infrações contratuais e consequentes multas 
        a serem aplicadas.
    </ul>
    
    <p>    
        <b>8.3.1.</b> A parte que der causa à rescisão do presente contrato, de forma motivada, arcará com a multa por quebra de acordo comercial e preços equivalente a 60% (sessenta) 
        do valor da média do faturamento mensal dos últimos 12 meses, devidamente reajustadas, multiplicado pelo número de meses restantes para a conclusão do prazo integral.
    </p>
    <p>
        <b>8.3.2.</b> O <b>CONTRATANTE</b> fico isento da aplicação da Cláusula 7.2.1 somente quando a rescisão contratual for oriunda do descumprimento por parte da <b>C&M SOFTWARE</b> 
        ao Comunicado do Banco Central do Brasil 8.454 e sua Circular 3.629/2013.
    </p>
    <p>
        <b>8.4.</b> O presente contrato poderá ser encerrado, sem qualquer ônus, em razão da ocorrência de eventos de caso fortuito ou de força maior, regularmente comprovados, 
        impeditivos da execução deste contrato. Quando for possível a execução apenas parcial do contrato, o <b>CONTRATANTE</b> poderá decidir entre o cumprimento parcial ou o término 
        do contrato.
    </p>
    <p>
        <b>8.5.</b> Na ocorrência do término deste contrato, por qualquer motivo, o <b>CONTRATANTE</b> remunerará a <b>C&M SOFTWARE</b> pelos serviços já prestados e concluídos, bem 
        como efetuará o pagamento das despesas já ocorridas, estabelecendo as Partes desde já que o faturamento da “Hospedagem” , em função do tipo de contratação (licenciamento do software) 
        será integralmente cobrado, conforme valor estabelecido no item “PREÇO” do Quadro Resumo, independente das datas de rescisão e vencimento, não sendo aplicada a forma de cobrança 
        “pro rata die”.
    </p>
    <p>
        <b>8.6.</b> Em função da especificidade do produto e do sistema de licenciamento, na denúncia do contrato, os 180 (cento e oitenta) dias serão cobrados antecipadamente, de uma 
        única vez, na data do pedido, sob pena de não ter a rescisão processada e contagem de novo período contratual. Qualquer liberalidade da <b>C&M SOFTWARE</b> em relação a esses 
        valores não elidirá qualquer das outras obrigações.
    </p>
    <p>
        <b>8.7.</b> Após o período inicial de 12 meses contados a partir da assinatura do presente contrato, este vigorará por prazo indeterminado, bastando para o seu encerramento 
        que uma das partes se manifeste com uma antecedência mínima de 180 (cento e oitenta) dias através correspondência registrada assinada pelos seus representantes legais, com 
        reconhecimento de firma.
    </p>
    <p>
        <b>CLÁUSULA NONA: DAS DISPOSIÇÕES GERAIS</b>
    </p>
    <p>
        <b>9.1.</b> Nenhuma disposição deste contrato poderá ser interpretada como tendo as Partes estabelecido qualquer forma de sociedade ou associação, de fato ou de direito, 
        remanescendo cada uma das partes com suas obrigações civis, comerciais, trabalhistas e tributárias, de forma autônoma.
    </p>
    <p>
        <b>9.2.</b> Nenhuma das Partes poderá ceder ou transferir, no todo ou em parte, os direitos e obrigações decorrentes deste contrato, sem a anuência prévia e expressa da outra 
        Parte.
    </p>
    <p>
        <b>9.3.</b> Qualquer aditamento ou alteração a este contrato somente será válida se feito por meio de aditivo contratual, escrito e assinado pelas Partes.
    </p>
    <p>
        <b>9.4.</b> Todas as obrigações e condições aqui estipuladas obrigam as Partes e seus sucessores a qualquer título.
    </p>
    <p>
        <b>9.5.</b> Todas as notificações ou comunicações dadas segundo o presente contrato, de uma Parte à outra, deverão ser endereçadas somente por via postal através de carta 
        registrada, todos com aviso de recebimento, para os representantes legais nos endereços constantes na qualificação das Partes. Se houver alteração do Representante Legal, 
        deverá ser anexado documento de comprovação para o exercício do ato. 
    </p>
";

$texto[6] =
"    
    <p>
        <b>9.6.</b> A tolerância de uma Parte com a outra, relativamente a qualquer violação ou descumprimento de quaisquer obrigações ora assumidas, não será considerada moratória, 
        novação ou renúncia a qualquer direito, constituindo mera liberalidade, que não impedirá a Parte tolerante de exigir da outra o fiel cumprimento deste contrato, a qualquer 
        tempo.
    </p>
    <p>
        <b>9.7.</b> Se qualquer cláusula ou condição deste contrato vier a ser considerada ilegal, inválida ou inexequível nos termos da legislação brasileira, as demais cláusulas e 
        condições continuarão em pleno vigor e efeito.
    </p>
    <p>
        <b>9.8.</b> O <b>CONTRATANTE</b>, desde já, autoriza a <b>C&M SOFTWARE</b> a incluir o seu nome na sua Lista de Clientes, assim como sua divulgação, pelos meios de comunicação 
        próprios, juntamente com os nomes de outros clientes, mas não revelará, comunicará ou de qualquer forma fará propaganda a qualquer terceiro de detalhes deste contrato.
    </p>
    <p>
        <b>9.9.</b> O presente contrato constitui o acordo final entre as Partes com relação às matérias aqui expressamente tratadas, superando e substituindo todas as propostas, 
        acordos, entendimentos e declarações anteriores, orais ou escritos.
    </p>
    <p>
        <b>9.10.</b> Cada uma das Partes declara, garante e concorda, reciprocamente, que a celebração, outorga e execução deste contrato foi devidamente autorizada pelos seus 
        legítimos representantes legais, na forma dos seus respectivos documentos societários, sendo que o fornecimento de eventual informação inverídica, incompleta ou inidônea será 
        considerado infração aos princípios da informação e boa-fé contratual, respondendo a parte que assim as prestou civil e criminalmente, restando claro que este contrato 
        constitui obrigação legal, válida e vinculante entre as Partes.
    </p>
    <p>
        <b>9.11.</b> O presente contrato é considerado título executivo extrajudicial, nos termos do inciso III, do artigo 784, do Código de Processo Civil, sujeitando-se, dessa 
        forma, à legislação aplicável à matéria.
    </p>
    <p>
        <b>9.12.</b> As Partes elegem o foro da Comarca Barueri- SP, para dirimir quaisquer dúvidas ou atos oriundos ou relativos a este contrato, renunciando a qualquer outro por 
        mais privilegiado que seja.
        <br>
        E assim, por estarem justas e contratadas, as partes assinam o presente em 02 (duas) vias de igual teor, na presença das testemunhas abaixo.
    </p>
";


?>