<?php
$texto[0] =
"
    À<br> 
    <b> **--CLIENTE--** </b> <br>
    **--ENDERECO--** - **--BAIRRO--** <br> 
    **--CEP--** - **--CIDADE--** - **--UF--** <br> 
    <br> 
    <b> A/C.: **--REPRESENTANTE_LEGAL--** </b> 
    <br></br>     

    <b>Assunto: CONTRATO DE LICENCIAMENTO DE USO DA PLATAFORMA YELLOW</b> 
    <br></br> 
    Prezado Senhor,
    <br> 
    <p>
        Primeiramente manifestamos nossos sinceros agradecimentos pela contratação da nossa plataforma, e lhe damos as <b>Boas-Vindas</b> à família C&M Software.
    </p>
    <p>
        Encaminhamos em anexo o contrato de Licenciamento da Plataforma <b>YELLOW</b> que será assinado na <b>Plataforma de Assinaturas</b> da <b>D4Sign</b> (especializada em identificação digital), 
        com plena validade jurídica. As assinaturas das pessoas jurídicas da Contratante e Contratada serão realizadas com a utilização de Certificados Digitais <b>e-CNPJ</b>.
    </p>
    <p>
        As testemunhas assinarão eletronicamente (sem a necessidade de Certificado Digital), de acordo com as formas de comprovação de autoria e integridade de documentos realizadas 
        pela Plataforma de Assinaturas da <b>D4Sign</b>. O passo-a-passo para assinatura do presente instrumento será enviado por <b>e-mail</b>.
    </p>
    <p>
        Caso contrário, segue anexo o “Contrato de Licenciamento da Plataforma <b>YELLOW</b>, sendo necessário que seja assinado em <b>02 (duas) vias</b> e entregue no endereço de 
        nossa sede:
    </p>

    <p><b>**--CM_SOFTWARE--**</b></p>
    <br> A/C: Departamento Jurídico.
    <br> Alameda Rio Pardo, nº 27 - Alphaville Industrial.
    <br> 06455-005 – Barueri – SP. 

    <br> Os documentos que devem acompanhar o contrato são:

    <ul> Cópia simples do Contrato Social/Estatuto Social, bem como a última alteração/ata da assembleia; </ul>
    <ul> Cartão do CNPJ; </ul>
    <ul> Cópia simples do RG e CPF do signatário do Contrato; e, </ul>
    <ul> Se o signatário não constar do Contrato Social/Estatuto Social, solicitamos cópia da procuração que lhe outorgou poderes. </ul>

    <br>
    Quaisquer dúvidas podem ser encaminhadas para os e-mails contratos@cmsw.com e juridico@cmsw.com, ou pelo telefone (11) 3365-2666.
    <br></br><br></br><br></br><br>
    Atenciosamente,
    <br></br><br>
    <table>
        <thead>
            <th style='text-align:center; width:800px;' >               
                <small>
                    **--CM_SOFTWARE--**
                    <br>Departamento Jurídico 
                </small>                               
            </th>
        </thead>
    </table>

";

$texto[1] = 
"          
    <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>
                <td style='text-align:center;border-bottom:2px solid;'>
                    <h3>Contrato de Licenciamento da Plataforma YELLOW</h3>                        
                </td>
            </tr>
        </tbody>
    </table>
    
    <table cellpadding='1' cellspacing='4' style='width:100%'> 
        <tbody>
            <tr>
                <td class='td_minuta' style='text-align:center;border:2px solid; border-color:black'><b><small>QUADRO RESUMO</small></b></td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>
                    <b><small>CONTRATADA</small></b>
                    <br></br>
                    <p>
                        <b> **--CM_SOFTWARE--** </b>, pessoa jurídica de direito privado com sede na Alameda Rio Pardo, nº 27, 
                        Bairro Alphaville Industrial, no município de Barueri, Estado de São Paulo, CEP 06455-005, inscrita no CNPJ/MF sob o 
                        nº <b>**--CM_SOFTWARE_CNPJ--**</b>, doravante denominada simplesmente “<b>C&M SOFTWARE</b>”;
                    </p>
                    <br>
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>
                    <b><small>CONTRATANTE</small></b>
                    <br></br>
                    <p>
                        <b> **--CLIENTE--** </b>, pessoa jurídica de direito privado com endereço **--ENDERECO--** - **--BAIRRO--**, na cidade de **--CIDADE--**, Estado de **--UF--**, 
                        CEP **--CEP--**, inscrita no C.N.P.J. nº **--CNPJ--**, neste ato representada na forma de seus atos constitutivos por 
                        <b>**--REPRESENTANTE_LEGAL--**</b>, **--REPRESENTANTE_LEGAL/CARGO--**, C.P.F. nº **--REPRESENTANTE_LEGAL/CPF--** , e-mail: **--REPRESENTANTE_LEGAL/EMAIL--**, 
                        telefone: **--REPRESENTANTE_LEGAL/TELEFONE--** **--REPRESENTANTE_2--** doravante denominada simplesmente <b>“CLIENTE”</b>.
                    </p>                        
                    <br>
                        <ul>CONTATO RESPONSÁVEL: **--CONTATO_RESPONSAVEL--** - e-mail: **--CONTATO_RESPONSAVEL/EMAIL--** - telefone: **--CONTATO_RESPONSAVEL/TELEFONE--** </ul>                                                       
                        <ul>FINANCEIRO: **--CONTATO_FINANCEIRO--** - e-mail: **--CONTATO_FINANCEIRO/EMAIL--** - telefone: **--CONTATO_FINANCEIRO/TELEFONE--** </ul>
                        **--CONTATO_FINANCEIRO_2--**
                    <br>
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                    <b><small>VIGÊNCIA / REAJUSTE / DENÚNCIA: **--VIGENCIA_CONTRATO--** **--VIGENCIA_CONTRATO/EXTENSO--**  / **--INDICE_REAJUSTE--** / 180 (cento e oitenta) dias.<small></b>                        
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                    <b><small>PREÇO</small></b>   
                    <p>                     
                        <ul>Conforme valores e condições descritas na clausula 3.o <b>DO PREÇO E CONDIÇÕES DE COBRANÇA</b>.</ul>
                    </p>                        
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>                        
                    <b><small>RESCISÃO CONTRATUAL</small></b>                       
                    <p>
                        <br>
                        <b>60% (sessenta)</b> do valor da média do faturamento mensal dos últimos 12 meses, multiplicado pelos meses restantes.
                    </p>
                    <br>
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>
                    <b><small>FATURAMENTO</small></b>                        
                    <p>
                        <br>
                        Data de corte todo o dia <b> **--CORTE_FATURAMENTO--** **--CORTE_FATURAMENTO/EXTENSO--** de cada mês</b>, com prazo de pagamento <b> **--PRAZO_PAGAMENTO--** **--PRAZO_PAGAMENTO/EXTENSO--** </b> contados da apresentação da nota
                        fiscal/fatura, ocorrendo o primeiro faturamento <b> 19 (dezenove) </b>, independentemente da conclusão da implantação e do uso.   
                    </p>              
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>                       
                    <b><small>TESTEMUNHAS:</small></b>                      
                    <p>
                        <br>
                        Nome: **--TESTEMUNHA_CMSW--** da C&M C.P.F. nº **--TESTEMUNHA_CMSW/CPF--** e-mail: **--TESTEMUNHA_CMSW/EMAIL--** 
                        <br>
                        Nome: **--TESTEMUNHA--** C.P.F. nº **--TESTEMUNHA_CPF--** e-mail: **--TESTEMUNHA_EMAIL--** 
                    </p>
                </td>
            </tr>
            <tr>
                <td class='td_minuta' style='border:2px solid; border-color:black'>
                    <b><small>Observações:</small></b>
                </td>
            </tr>
        </tbody>
    </table>                
";

$texto[2] = 
" 
    <table cellpadding='1' cellspacing='1' style='width:100%'>
        <tbody>
            <tr>
                <td class='td_cabecalho' style='text-align:center;border-top:2px solid;border-bottom:2px solid;'>
                    <small><b>CONTRATO DE LICENCIAMENTO DA PLATAFORMA YELLOW</b></small>
                </td>
            </tr>
        </tbody>
    </table>
    Pelo presente instrumento e na melhor forma de direito, as partes qualificadas no QUADRO RESUMO e, Considerando que:
    <p>
        <b>(i)</b> a <b>C&M SOFTWARE</b> é titular exclusiva de todos os direitos autorais e patrimoniais da <b>YELLOW</b>, que será disponibilizado à **--CLIENTE--**, sob a modalidade “SaaS” 
        (Software as a Service), conforme abaixo:
    </p>
    <ul>
        processamento das transações realizadas e dos processos cadastrais junto à Plataforma <b>YELLOW</b> nos servidores da <b>C&M SOFTWARE</b>, instalados e operados no Brasil, e acessado via 
        Internet (Cloud Computing), não necessitando, assim, de investimentos de grande porte em infraestrutura e capacitação de profissionais para manutenção e atualização do 
        sistema;
    </ul>
    <ul>
        toda infraestrutura necessária para a disponibilização da plataforma é de responsabilidade da <b>C&M SOFTWARE</b> (App, servidores, comunicação, segurança das informações, 
        hospedagem, licenças de banco de dados, etc.), disponível por 7 sete dias da semana, 24 horas por dia e 365 dias por ano;
    </ul>
    <ul>
        todas as correções e novas versões mais modernas de tecnologia e processos de negócio são disponibilizadas no sistema;
    </ul>
    <ul>
        suporte técnico e monitoramento, disponibilizado pela <b>C&M SOFTWARE</b> por 7 sete dias da semana, 24 horas por dia e 365 dias por ano; e,
    </ul>
    <ul>
        a <b>C&M SOFTWARE</b> disponibiliza, ainda, o <b>CONTRATANTE</b> site contingência com redundância da aplicação e Banco de Dados, isto é, uma segunda infraestrutura que está, prontamente, 
        disponível para uso quando da falha do dispositivo primário do sistema.
    </ul>
    <p>
        <b>(ii)</b> O <b>CONTRATANTE</b> objetiva utilizar a Plataforma <b>YELLOW</b> para captar, analisar e ceder o crédito o <b>PORTADOR</b>, assim como o destino/objetivo do crédito, sempre cuidando que o produto e/ou 
        crédito não deve ser utilizado para propósitos/fins ilegais, incluindo aquisição de itens, serviços e estabelecimentos proibidos ou vetados pela legislação em vigor e as 
        autoridades legais;
    </p>
    <p>
        <b>(iii)</b> As disposições da <b>“C&M2021-01-LGPD”</b>, prevalecerão sobre quaisquer inconsistências e/ou quaisquer outros acordos entre as Partes, incluindo o presente contrato, 
        salvo quando o documento, expressamente assinado pelas Partes, diferentemente, o declare. 
    </p>
    <p>
        <b>(iv)</b> Caso qualquer disposição do presente seja inválida ou inexequível, nos termos da lei civil vigente, o restante permanecerá válido e em vigor. A disposição inválida 
        ou inexequível deve ser: (i) alterada conforme necessário para garantir a sua validade e aplicabilidade, preservando as intenções das partes o máximo possível ou, se isso não 
        for possível; (ii) interpretadas de maneira como se a disposição inválida ou inexequível nunca estivesse contida.
    </p>
    <p>
        <b>RESOLVEM</b>, as partes adiante qualificadas, celebrar o presente Contrato de Licenciamento da Plataforma <b>YELLOW</b>, obedecidos os itens constantes do Quadro Resumo e 
        as cláusulas e condições adiante convencionadas, que reciprocamente estipulam, outorgam e aceitam, a saber:
    </p>
    <p><b>CLÁUSULA PRIMEIRA: DO OBJETO E LOCALIZAÇÃO DOS SERVIDORES</b></p>
    <p>
        <b>1.1.</b> O objeto do presente contrato é o licenciamento de uso da Plataforma <b>YELLOW</b> de forma não exclusiva, intransferível e temporária, nos termos e condições 
        aqui avençadas, sendo a sua função disponibilizar para o <b>CONTRATANTE</b> as funcionalidades necessárias para realizar operações de financiamento de transações Pix, através de 
        cessão de créditos direto ao consumidor, seja este Pessoa Física quanto Pessoa Jurídica. 
    </p>
    <p>
        <b>1.1.1.</b> O processamento da Plataforma <b>YELLOW</b> ocorrerá nos servidores da <b>C&M SOFTWARE</b>, instalados e operados no Brasil, no município de Barueri, Estado de 
        São Paulo.
    </p>
    <p>
        <b>1.1.2.</b> O <b>CONTRATANTE</b> reconhece desde já que a utilização da presente plataforma é exclusiva para a finalidade de disponibilizar ao seu cliente crédito direto através 
        do <b>Pix</b>, sendo o <b>CONTRATANTE</b>  responsável por todas as análises para liberação de crédito e seus respectivos limites para utilização, bem como responsável por administrar 
        e se relacionar com os clientes que compõem sua carteira. 
    </p>
    <p>
        <b>1.1.3.</b> O <b>CONTRATANTE</b> está ciente que é o único responsável pelo compartilhamento de qualquer transação realizada pela Plataforma <b>YELLOW</b>.
    </p>
    <p>
        <b>1.2.</b> O <b>CONTRATANTE</b> deverá disponibilizar acesso à C&M SOFTWARE para utilizar uma conta transacional e sua solução de Pix para realizar as transações de liquidação junto 
        aos estabelecimentos em que seus clientes (PORTADORES) realizarem transações. Esta conta deve estar disponível 24/7/365, sendo o <b>CONTRATANTE</b> responsável em administrar seu 
        saldo, conforme determinações.
    </p>
    <p>
        <b>1.2.1.</b> Caso o <b>CONTRATANTE</b> não seja participante Direto ou Indireto do <b>Pix</b> deverá possuir conta em banco comercial no sistema <b>OPEN FINANCE</b> como determinado 
        pelo <b>BACEN</b> e abrir ou firmar um relacionamento com um <b>Iniciador de Transação de Pagamento</b> autorizado pelo <b>BACEN</b> e homologado pela <b>C&M SOFTWARE</b>.
    </p>    
";

$texto[3] = 
"
    <p>
        <b>1.3.</b> Todos os novos produtos/módulos ou funcionalidades, criados pela <b>C&M SOFTWARE</b> e disponibilizados na Plataforma <b>YELLOW</b>, serão informados ao <b>CONTRATANTE</b>. 
        Sua adesão aos novos produtos/módulos ou funcionalidades ocorrerá na primeira consulta realizada, servindo para todo e qualquer efeito de direito, como adesão aos preços e condições 
        disponibilizadas no Painel de Controle do próprio produto. 
    </p>
    <p>
        <b>1.4.</b> Este Contrato é composto pelos anexos e políticas abaixo descritas e fazem parte integrante e indissociável do Contrato para todos os fins de direito:
    </p>
    <p>
        (1) Declaração de Conformidade Social e Sigilo das Informações; 
        <br>
        (2) Política de Segurança da Informação e Cibernética;
        <br>
        (3) Plano de Continuidade de Negócios; 
        <br>
        (4) Propriedade Intelectual;
        <br>
        (5) Código de Ética;
        <br>
        (6) Política Interna LGPD – “C&M2021-01-LGPD”.
        <br>
        <b>IMPORTANTE:</b> Os documentos referenciados de (1) a (6) estarão sempre disponíveis e atualizados no endereço: https://br.cmsw.com/politicas/
    <p>
   
    <p><b>CLÁUSULA SEGUNDA: DO PRAZO DE VIGÊNCIA</b></p>
    <p> 
        <b>2.1.</b> O presente Contrato, vigorará pelo prazo de **--VIGENCIA_CONTRATO--** **--VIGENCIA_CONTRATO/EXTENSO--**., contados a partir da data da assinatura digital, conforme termos da MEDIDA PROVISÓRIA 
        No 2.200-2, DE 24 DE AGOSTO DE 2001 e LEI Nº 14.063, DE 23 DE SETEMBRO DE 2020, ou da forma convencional de assinatura e com 180 dias para denúncia, renovando-se, 
        automaticamente, por iguais e sucessivos períodos.
    </p>
    <p><b>CLÁUSULA TERCEIRA: DO PREÇO E CONDIÇÕES DE COBRANÇA</b></p>
    <p>
        <b>3.1.</b> O valor da Implantação e disponibilização para o ambiente do <b>CONTRATANTE</b> é de **--IMPLANTACAO--** **--IMPLANTACAO/EXTENSO--**, **--TEXTO_IMPLANTACAO--**. 
    </p>
    <p>
        <b>a</b>. O valor da implantação descrito acima contempla: 
    </p>
    <ul> Setup da Plataforma Yellow no Data Center da C&M SOFTWARE;</ul>
    <ul> Treinamento da Plataforma </ul>
    <p>
        <b>b</b>. Segue abaixo demais serviços e suas descrições que não permitem sua contratação opcional, embora a tarifação destes estejam condicionadas a utilização e/ou 
        aplicabilidade dele.
    </p>
    <p>
        <b>b.1 Portador APP Yellow.</b>
        <br>     
        A ativação é cobrada para cada cliente do <b>CONTRATANTE</b> que seja habilitado dentro do mês para ser um Portador App Yellow e esteja apto à efetuar compras, pagamentos, 
        transferência e demais funcionalidades. Subsequente ao mês de ativação, para cada cliente habilitado, será cobrado o valor mensal correspondente a manutenção da conta.
    </p>
    <p>
        <b>Ativação</b> **--ATIVACAO--** **--ATIVACAO_EXTENSO--** 
    </p>
    <p>
        <b>Manutenção da Conta</b> **--MANUTENCAO_CONTA--**  **--MANUTENCAO_CONTA_EXTENSO--** , para a determinação do total de contas ativas que 
        estarão qualificadas para este faturamento, utilizar-se-á a quantidade total de contas do mês anterior ao faturamento corrente, mais a quantidade total de contas ativadas no 
        mês corrente, menos as contas que forem desativadas, não serão aplicadas nenhum “pro rata die”.
    </p>
    <p>
        <b>b.2 Royalty Yellow</b>
        <br>
        O Royalty Yellow, incide sobre o valor total aprovado pela Plataforma Yellow relativa as operações feitas pelos Portadores App Yellow, durante o período de apuração, o 
        período de apuração é mensal, iniciando-se do zero a cada mês. 
    </p>
    <p>
        <b>Exemplo:</b> se a somatória dos valores transacionados dentro do yellow por seus clientes portadores for de **--TRANSACAO_SILVER--**, o emissor irá repassar 
        **--PORCENTAGEM_SILVER--** desse valor como Royalty para a Plataforma Yellow, correspondente a tarifação de Royalty Silver, conforme tabela abaixo.
    </p>
";
$texto[3] .= 
" 
    <table>
        <thead>
            <tr>
                <th><b>Classificação do Royalty</b></th>
                <th><b>DE (R$)</b></th>
                <th><b>Até (R$)</b></th>
                <th><b>Royalty Tarifado.</b></th>
            </tr>
        </thead>
        <tbody>  
";
$contador = 0;
foreach ($lp_table as $key => $value) {  
   $texto[3] .= 
   "<tr>";
    if($contador == 0){
        $texto[3] .= "<td>Silver</td>";
    }elseif($contador == 1){
        $texto[3] .= "<td>Gold</td>";
    }else{
        $texto[3] .= "<td>Premium</td>";
    }
    $texto[3] .=
    "<td>".funcValor($value->qtd_de,"C",0)."</td>";
    if($contador > 1){
        $texto[3] .= "<td>Sem mais limites</td>";
    }else{
        $texto[3] .= "<td>".funcValor($value->qtd_ate,"C",0)."</td>"; 
    }       
    $texto[3] .= "<td>".funcValor($value->valor_real,"C",2)."% </td>";         
    $texto[3] .= "</tr>";
    $contador++;
}
$texto[3] .=
"
        </tbody>
    </table>";

$texto[4] =
"
    <p>
        <b>b.2.1</b> Os valores das faixas de Silver, Gold e Premium serão reajustados anualmente no mês de julho de cada ano independente da data de assinatura do contrato, o índice a 
        ser utilizado para a requalificação dos valores das faixas será o **--INDICE_REAJUSTE--**.
    </p>
    <p>
        <b>b.3 Baixa de pagamento ou parcela</b> **--BAIXA_PAGAMENTO--** **--BAIXA_PAGAMENTO_EXTENSO--**.
        <br>
        Tarifa incide sobre baixa da parcela, por pagamento feito pelo Portador App Yellow ou via API Yellow.
    </p>
    <p>
        <b>b.4 Liquidação fora do ambiente CorperPix da C&M Software</b> **--CORNER_PIX--** **--CORNER_PIX_EXTENSO--**.
        Incide quando a liquidação dessa parcela acontecer fora da nossa PSTI, o Corner Pix, ou seja, o serviço de mensageria do <b>CONTRATANTE</b>, não for o da C&M Software.
    </p>
    <p>
        <b>b.5 Marketing Cooperado Yellow</b> **--MARKETING_COOPERADO--** **--MARKETING_COOPERADO_EXTENSO--** trimestral.
        Apoiar as ações de divulgação e publicidade do Yellow, para o mercado, identificação dos pontos de vendas, apoiar os emissores na cultura e utilização do Yellow pelos portadores. 
        Caso o esteja na faixa de tarifação de Royalty Yellow denominado como Premium s o <b>CONTRATANTE</b> fica isento dessa tarifa
    </p>
    <p>
        <b>b.6 Gestão da Plataforma (Portal Emissor)</b> **--PORTAL_EMISSOR--** **--PORTAL_EMISSOR_EXTENSO--** .
        Acesso as opções disponíveis no portal do Emissor, tais como relatórios, gestão do App, entre outros, esse valor é fixo e mensal. Caso o esteja na faixa de tarifação de Royalty 
        Yellow denominado como Gold o <b>CONTRATANTE</b> fica isento dessa tarifa.
    </p>
    <p>
        <b>b.7 Gestão da Plataforma (Utilização API Yellow)</b> **--API_YELLOW--** **--API_YELLOW_EXTENSO--** chamada.
        Na API do Yellow, existem diversas opções de configuração, atualização, operação do sistema e sua tarifação é por chamada feita na API.
    </p>
    <p>
        <b>C.</b> As partes entendem que os demais serviços possuem caráter opcional sendo que o <b>CONTRATANTE</b> deverá acessar o site <b>http://nf.cmsw.com</b> escolhendo os serviços que deseja utilizar, 
        tomando neste site dos valores, descrição e condições de faturamento.
    </p>
    <p>
        <b>c.</b> Os valores <b>não contemplam tributos</b> e serão acrescidos quando da emissão da Nota Fiscal/Fatura.
    </p>
    <p>
        <b>3.1.1.</b> O primeiro faturamento será integralmente cobrado e deverão ser pagos à <b>C&M SOFTWARE</b> por meio de DOC, Pix, TED ou boleto bancário comum ou híbrido, 
        ou qualquer outro sistema que venha substituí-los, independentemente da data de vencimento e início do Contrato, não sendo aplicada a forma de cobrança “pro rata die”.
    </p>
    <p>
        <b>3.2.</b> Acordam as Partes que o faturamento decorrente do presente instrumento, salvo o valor da implantação que segue sistemática própria, terão datas de corte para aferição 
        todo o dia <b> **--CORTE_FATURAMENTO--** **--CORTE_FATURAMENTO/EXTENSO--** </b> de cada mês, com prazo de pagamento de <b> **--PRAZO_PAGAMENTO--** 
        **--PRAZO_PAGAMENTO/EXTENSO--** </b> dias contados da apresentação da nota fiscal/fatura, ocorrendo o primeiro faturamento <b> 19 (dezenove) </b>, independentemente da implantação 
        e/ou utilização.
    </p>
    <p>
        <b>3.2.1.</b> A C&M SOFTWARE informará ao <b>CONTRATANTE</b> sobre a emissão do documento fiscal específico, por meio dos e-mails indicados pelo FINANCEIRO, enviando também nessa oportunidade o 
        link para emissão da Nota Fiscal Eletrônica e respectivos boletos de pagamento, quando aplicável.
    </p>
    <p>
        <b>3.2.2.</b> O <b>CONTRATANTE</b> concorda, desde já, que os itens marcados com <b>“*” (asterisco)</b> são de <b>contratação obrigatória</b>, vez que fundamentais a operação do 
        sistema.
    </p>
    <p>
        <b>3.3.</b> Serão de responsabilidade do <b>CONTRATANTE</b>, quando solicitado por este, as despesas de viagens referentes ao transporte aéreo ou terrestre (quando o aéreo não for 
        possível) e estadias ocorridas com os profissionais da <b>C&M SOFTWARE</b>, sempre que houver necessidade de deslocamento da equipe para locais fora da região metropolitana de 
        São Paulo/SP e Barueri/SP e cidades contíguas.
    </p>
    <p>
        <b>3.4.</b> Como forma de manter a hegemonia dos custos, as partes elegem, desde já, o <b>**--INDICE_REAJUSTE--**</b>, como índice de correção monetária, aplicável aos preços referidos neste 
        Contrato.
    </p>
    <p>
        <b>3.4.1.</b> Quando aplicável e na hipótese de atraso ou ausência de publicação do índice aplicável, a <b>C&M SOFTWARE</b> emitirá as notas fiscais/faturas usando o último 
        índice publicado. Imediatamente após a publicação seguinte do referido índice, a <b>C&M SOFTWARE</b> emitirá os títulos para o pagamento e/ou ressarcimento da diferença entre valor já 
        cobrado e os valores efetivamente devidos, de acordo com o prazo de vencimento estabelecido.
    </p>
    <p>
        <b>3.4.2.</b> Na falta desse índice ou, se permitido por lei, ou por decisão judicial, será aplicado aos preços qualquer outro índice oficial, de variação diária, ou, se 
        inexistente, de variação mensal, calculando “pro rata die”, e que mais eficientemente elide os efeitos inflacionários da moeda corrente nacional, o qual será eleito mediante 
        comum acordo entre as partes.
    </p>
";

$texto[5] .=
"   
    <p>
        <b>3.5.</b> Na hipótese de ocorrerem fatos ou atos que possam prejudicar o equilíbrio econômico-financeiro do Contrato, as partes envidarão seus melhores esforços para regular e 
        disciplinar a situação criada, de forma a evitar qualquer perda de natureza econômica, financeira ou outra qualquer.
    </p>
    <p>
        <b>3.6.</b> Se, durante a vigência deste Contrato, forem criados tributos ou alteradas as alíquotas dos atuais, de forma a majorar ou diminuir o ônus das Partes contratantes, os 
        preços poderão ser revistos, de modo a serem ajustados a essas modificações, mediante envio de notificação por escrito da <b>C&M SOFTWARE</b> ao <b>CONTRATANTE</b>.
    </p>
    <p>
        <b>3.7.</b> A <b>C&M SOFTWARE</b> executará a operação descrita neste Contrato em sua sede, ou de suas futuras filiais, as quais emitirão o correspondente documento fiscal, haja 
        vista serem consideradas, individualmente, como estabelecimentos ou locais, onde a <b>C&M SOFTWARE</b> desenvolve a sua atividade principal, de modo permanente ou eventual, nos termos 
        do artigo 4º da Lei Complementar nº. 116, de 31.07.2003, publicada no Diário Oficial da União de 01/08/2003.
    </p>
    <p>
        <b>3.8.</b> O inadimplemento de toda e qualquer importância cobrada com base no presente Contrato, na data de seu vencimento, implicará na incidência automática de multa 
        moratória no percentual de 2% (dois por cento) e juros de mora de 1% (um por cento) ao mês, encargos esses incidentes sobre o valor do débito atualizado de acordo com o índice 
        estabelecido no item “REAJUSTE CONTRATUAL” do Quadro Resumo, calculado “pro rata die” a partir da data de vencimento do respectivo documento de cobrança até a data do efetivo 
        pagamento.
    </p>
    <p>
        <b>3.8.1.</b> Os mencionados juros de mora, multa moratória e atualização monetária serão cobrados automaticamente no faturamento do mês subsequente.
    </p>
    <p>
        <b>3.9.</b> O acesso à Plataforma <b>YELLOW</b>  poderá ser suspenso, sem aviso prévio, se a inadimplência do <b>CONTRATANTE</b> durar mais de 10 (dez) dias, contados da data de 
        vencimento, e neste caso não será reiniciada a não ser que todos os valores devidos sejam pagos na sua totalidade, sem prejuízo do direito da <b>C&M SOFTWARE</b> de rescindir o 
        presente Contrato.
    </p>
    <p>
        <b>3.9.1.</b> Após a comprovação do pagamento dos valores em atraso pelo <b>CONTRATANTE</b>, o acesso à Plataforma <b>YELLOW</b> será restabelecido automaticamente.
    </p>
    <p>
        <b>3.10.</b> O reajuste se dará a <b>cada 12 (doze) meses</b> pelo <b>**--INDICE_REAJUSTE--**</b>, ou, na extinção deste, aquele índice que venha a substituí-lo, a contar da data de assinatura 
        do presente Contrato.
    </p>
    <p><b>CLÁUSULA QUARTA: DO ACESSO À PLATAFORMA YELLOW, IMPLANTAÇÃO E ATUALIZAÇÕES</b></p>
    <p>
        <b>4.1.</b> A <b>CONTRATANTE</b> recebeu, no momento da contratação, ou até mesmo durante o processo de implantação e ativação dos produtos contratados, manuais explicativos exemplificando o 
        acesso à Plataforma <b>YELLOW</b>.
    </p>
    <p>
        <b>4.2.</b> A <b>C&M SOFTWARE</b> poderá promover atualizações na Plataforma <b>YELLOW</b> que serão sempre aplicadas à última versão disponibilizada.
    </p>
    <p>
        <b>4.2.1.</b> Toda nova implementação ou atualização na Plataforma <b>YELLOW</b> solicitada pelo <b>CONTRATANTE</b>, após aprovação da <b>C&M SOFTWARE</b>, será incorporada na forma de 
        licenciamento e propriedade da plataforma. 
    </p>
    <p>
        <b>4.3.</b> Se forem realizadas atualizações na Plataforma <b>YELLOW</b> a <b>C&M SOFTWARE</b> obriga-se a comunicar e disponibilizá-las à <b>CONTRATANTE</b>, gratuita e 
        imediatamente.
    </p>
    <p>
        <b>4.4.</b> O Manual do Emissor do <b>YELLOW</b> é parte integrante e indispensável deste instrumento já que seu cumprimento á item fundamental para mantença do contrato. 
        Seu descumprimento acarreta, de imediato, rescisão com culpa do Emissor.
    </p>
    <p><b>CLÁUSULA QUINTA: DO SUPORTE TÉCNICO</b></p>
    <p>
        <b>5.1.</b> O suporte técnico ao <b>YELLOW</b> será prestado pela <b>C&M SOFTWARE</b> ou terceiros por ela credenciados via telefone (+55 11 3365-2666) ou correio eletrônico 
        (suporte@cmsw.com.br), sem custos adicionais para o <b>CONTRATANTE</b>, nas seguintes condições:
    </p>
    <p>
        <b>5.1.1.</b> O Suporte Operacional da <b>C&M SOFTWARE</b>, responsável direto pela disponibilidade do produto, bem como por responder a questionamentos iniciais, poderá ser 
        acessado 07 (sete) dias por semana, 24 (vinte e quatro) horas por dia, 365 (trezentos e sessenta e cinco) dias por ano <b>(7x24x365)</b>.
    </p>
    <p>
        <b>5.1.2.</b> O Suporte de Inteligência de Negócios da <b>C&M SOFTWARE</b>, responsável direto pela aplicação de regras, fluxos, integrações e demais conexões pertinentes e existentes 
        no <b>YELLOW</b>, poderá ser acessado no horário comercial (09:00 às 18:00) e segundo o calendário de feriados da cidade de Barueri/SP.
    </p>
    <p>
        <b>5.1.3.</b> O Suporte de Implantação e Qualidade da <b>C&M SOFTWARE</b>, responsável direto pelo Treinamento, Implantação e Qualidade do <b>YELLOW</b> poderá ser acessado no horário comercial e 
        segundo o calendário de feriados da cidade de Barueri/SP.
    </p>

";

$texto[6] =
"   
    <p><b>CLÁUSULA SEXTA: DO TREINAMENTO</b></p>
    <p>
        <b>6.1.</b> O treinamento na Plataforma <b>YELLOW</b> será realizado por funcionários especializados da <b>C&M SOFTWARE</b> ou terceiros, por ela credenciados, nas instalações físicas 
        da <b>C&M SOFTWARE</b>, da <b>CONTRATANTE</b>, ou outro local indicado por este indicado.
    </p>
    <p>
        <b>6.2.</b> O treinamento deverá ser solicitado pela <b>CONTRATANTE</b>, com um prazo mínimo de <b>30 (trinta) dias</b> de antecedência, sendo que, caso o local escolhido seja fora da 
        região metropolitana da cidade de São Paulo, as despesas com transportes, hospedagem e alimentação dos instrutores, serão de sua responsabilidade exclusiva.
    </p>
    <p><b>CLÁUSULA SÉTIMA: DAS OBRIGAÇÕES DA C&M SOFTWARE</b></p>
    <p>
        <b>7.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, a <b>C&M SOFTWARE</b> obriga-se a: 
    </p>
    <p>
        <b>7.1.1.</b> Executar o objeto deste Contrato, com a sua usual diligência, padrão e com observância das leis aplicáveis.
    </p>
    <p>
        <b>7.1.2.</b> Realizar a manutenção preventiva e corretiva do software objeto deste Contrato.
    </p>
    <p>
        <b>7.1.3.</b> Atualizar os sistemas que compõem a Plataforma <b>YELLOW</b> para não incorrer em obsolescência tecnológica.
    </p>
    <p>
        <b>7.1.4.</b> Manter a disponibilidade mínima de 95% (noventa e cinco por cento) do sistema e de suporte, por 7 (sete) dias na semana e 24 (vinte e quatro) horas no dia, 
        garantindo, adicionalmente, durante o horário comercial a disponibilidade mínima de 99,7 % (noventa e nove vírgula sete por cento).
    </p>
    <p>
        <b>7.1.4.1.</b> Não caracterizará indisponibilidade do sistema a ocorrência dos seguintes eventos:    
        <ul> <b>a)</b> execução de manutenção, comunicada pela <b>C&M SOFTWARE</b> com mínimo de 15 (quinze) dias de antecedência; </ul>
        <ul> <b>b)</b> operação inadequada do software e dos equipamentos pela <b>CONTRATANTE</b>, em desacordo com as instruções da <b>C&M SOFTWARE</b>;</ul>
        <ul> <b>c)</b> falhas ocasionadas em relação à infraestrutura da <b>CONTRATANTE</b> ou na rede de comunicação. </ul>
    </p>
    <p>
        <b>7.1.5.</b> A <b>C&M SOFTWARE</b> disponibilizará em seu Portal <b>YELLOW</b> todas as atualizações e correções no Manual do Emissor comunicando-o em 24 (vinte e quatro) horas 
        da sua ocorrência.
    </p>
    <p>
        <b>7.1.6.</b> A <b>CONTRATANTE</b> tem conhecimento que toda a comunicação por intermédio da rede mundial de computadores (internet) está sujeita a interrupções e/ou atrasos, 
        podendo ocorrer problemas de transmissão ou de recepção das informações acessadas. 
    </p>
    <p>
        <b>7.1.7.</b> Toda e qualquer responsabilidade da <b>C&M SOFTWARE</b> limita-se, única e exclusivamente, aos sistemas desenvolvidos sob sua autoria. A <b>C&M SOFTWARE</b> não 
        responderá  pela qualidade de produtos de terceiros, mesmo que tais produtos de terceiros precisem ser incorporados ao sistema.
    </p>
    <p>
        <b>7.1.8.</b> A <b>C&M SOFTWARE</b> e o <b>CONTRATANTE</b>, desde já permitirão acesso do Banco Central do Brasil – BACEN aos contratos, à documentação e às informações referentes ao 
        licenciamento ora contratado, aos dados armazenados e às informações sobre seus processamentos, às cópias de segurança dos dados e das informações, bem como aos códigos de acesso 
        aos dados e às informações. 
    </p>
    <p>
        <b>CLÁUSULA OITAVA: DAS OBRIGAÇÕES DO CONTRATANTE</b>
    </p>
    <p>     
        <b>8.1.</b> Sem prejuízo das demais obrigações previstas neste Contrato, o <b>CONTRATANTE</b> obriga-se a: 
    </p>
    <p>
        <b>8.1.1.</b> Agir de acordo com todas as leis, regras e regulamentações governamentais aplicáveis no acesso às informações. 
    </p>
    <p>
        <b>8.1.2.</b> Efetuar os pagamentos devidos pela contratação, de acordo com as disposições deste Contrato.
    </p>
    <p>
        <b>8.1.3.</b> Disponibilizar todos os dados/informações, dados e ambientes de terceiros, devidamente autorizados, nos termos da LGPD, necessários à execução deste Contrato.
    </p>
    <p>
        <b>8.1.4.</b> Em face de estar ciente que a informação tem objetivo único e exclusivo de suporte ao seu negócio, fica expressamente proibida a impressão e/ou divulgação a 
        terceiros das consultas realizadas, podendo a <b>C&M SOFTWARE</b> rescindir este Contrato por justa causa, com aplicação imediata da multa, bem como sendo o <b>CONTRATANTE</b>  
        responsável pelas sanções penais e civis delas advindas, inclusive dos ganhos advindos dessa grave infração. 
    </p>
    <p>
        <b>8.1.5.</b> O <b>YELLOW</b> disponibiliza ao <b>CONTRATANTE</b> o processamento das transações <b>ISO 20.022</b>, dados com os quais o <b>CONTRATANTE</b> pretende realizar transações no 
        ambiente do <b>Pix</b>. Estes negócios devem estar fundados na ética e comportamento moral ilibado, em especial, no uso das informações.
    </p>    
";

$texto[7] =
"
    <p>
        <b>8.1.6.</b> Manter sob sigilo os códigos e senhas de acesso ao <b>YELLOW</b>, sendo de sua plena e total responsabilidade o uso indevido, bem como toda a gestão dos controles de 
        acesso. Em caso de perda, fraude ou qualquer outro risco na guarda, a <b>C&M SOFTWARE</b> deverá ser comunicada por escrito, da necessidade de bloqueio do acesso anterior e criação 
        de novo acesso.
    </p>
    <p>
        <b>8.1.7.</b> Assumir total responsabilidade por eventuais excessos cometidos por seus prepostos ou operadores;
    </p>
    <p>
        <b>8.1.8.</b> Manter estrutura adequada para o uso da Plataforma <b>YELLOW</b>;
    </p>
    <p>
        <b>8.1.9.</b> Não utilizar os códigos de acesso e senha dos assinantes para outros fins que não seja o objeto deste contrato.
    </p>
    <p>
        <b>8.1.10.</b> Cumprir os planos de consultas oferecidos pela <b>C&M SOFTWARE</b> e quitá-las conforme previsto neste Contrato.
    </p>
    <p>
        <b>8.1.11.</b> Permitir livre acesso, aos profissionais designados pela <b>C&M SOFTWARE</b>, aos locais onde serão executadas manutenções, preventivas ou corretivas, da Plataforma 
        objeto deste Contrato, nos horários estabelecidos para estas tarefas.
    </p>
    <p>
        <b>8.2.</b> Cada parte deverá orientar seus representantes para que cumpram as orientações relativas à segurança, bem como normas e procedimentos, durante o período em que 
        esses estiverem designados para prestarem serviços nas dependências da outra parte. 
    </p>
    <p>
        <b>8.3.</b> O <b>CONTRATANTE</b> declara que obteve e detém as devidas autorizações, consentimentos e permissões, especialmente sobre os dados considerados sensíveis pela Lei, quando 
        utilizados, na forma da legislação em vigor, para o tratamento dos dados necessários para execução da Plataforma ora licenciado, eximindo a <b>C&M SOFTWARE</b> de qualquer 
        responsabilidade pela obtenção dos devidos consentimentos.
    </p>
    <p>
        <b>8.4.</b> O <b>CONTRATANTE</b> declara estar ciente das Políticas Internas e Complience da <b>C&M SOFTWARE</b>, em especial, a <b>LGPD</b>.
    </p>
    <p>
        <b>8.5.</b> O <b>CONTRATANTE</b> deve selecionar, na página própria da Plataforma <b>YELLOW</b>, ao menos, os itens marcados com “*” (asterisco) vez que são de <b>contratação 
        obrigatória</b>, fundamentais a operação do sistema.
    </p>
    <p>
        <b>8.6</b> Na ocorrência das transações retornarem sem recursos do mecanismo de liquidez eleito pelo <b>CONTRATANTE</b> para liquidar as operações realizados pelos usuários do 
        APP YELLOW, o <b>CONTRATANTE</b> concorda que a C&M Software fature o valor total da transação que foi afetada pela ausência de fundos já no próximo faturamento a ser pago 
        pelo <b>CONTRATANTE</b> para a C&M Software. 
    </p>
    <p><b>CLÁUSULA NONA: DA RENOVAÇÃO ou RESCISÃO</b></p>
    <p>
        <b>9.1.</b> O contrato não poderá ser rescindido antecipadamente, por qualquer das partes, sem justo motivo, sob pena de aplicação automática de multa compensatória e 
        prefixação de perdas e danos equivalente a <b>60% (sessenta)</b> do valor da média do faturamento mensal (soma de todos os pagamentos realizados), nos <b>últimos 12 meses</b>, 
        monetariamente reajustadas, multiplicado pelo número de meses restantes para a conclusão do prazo integral, com a finalidade de recompor a <b>C&M SOFTWARE</b> pelos prejuízos 
        decorrentes da rescisão antecipada e injustificada, posto que esta realizou o gerenciamento e planejamento de custos, infraestrutura de equipamentos e softwares, equipes 
        técnicas de suporte, manutenção e desenvolvimento de sistemas além das exigências regulatórias impostas pelo BACEN ao PSTI C&M Software, com vistas ao cumprimento das 
        obrigações contratuais no prazo contratado entre as Partes..
    </p>
    <p>
        <b>9.2.</b> Este instrumento poderá ser rescindido, ainda, motivadamente, de forma imediata e de pleno direito:
        <ul> 
            <b>a)</b> descumprimento de qualquer das cláusulas do Contrato, desde que não sanada no prazo de <b>10 (dez) dias</b> a contar do recebimento da notificação da outra Parte neste 
            sentido;
        </ul>
        <ul>
            <b>b)</b> a outra Parte vir a ter a sua falência ou recuperação judicial/extrajudicial requerida ou decretada, ou insolvência civil dos sócios, mesmo que presumida, 
            bem como a condenação de qualquer um dos seus sócios em processos criminais; e,
        </ul>
        <ul>
            <b>c)</b> a outra Parte vir a ter sua idoneidade técnica ou financeira abalada ou o seu quadro societário modificado, de forma a prejudicar a fiel execução de suas 
            obrigações contratuais, a critério da outra Parte.
        </ul>
        <ul>
            <b>d)</b> o encerramento das atividades, mesmo que voluntário, do <b>CONTRATANTE</b> ou alienação de direitos ou carteira, não o exime das infrações contratuais e consequentes 
            multas a serem aplicadas.
        </ul>
    </p>
    <p>
        <b>9.3.</b> O presente Contrato poderá ser encerrado, sem qualquer ônus, em razão da ocorrência de eventos de caso fortuito ou de força maior, regularmente comprovados, impeditivos da 
        execução deste Contrato. Quando for possível a execução apenas parcial do Contrato, o <b>CONTRATANTE</b> poderá decidir entre o cumprimento parcial ou o término do Contrato.
    </p>
    <p>
        <b>9.4.</b> Na ocorrência do término deste Contrato, por qualquer motivo, o <b>CONTRATANTE</b> remunerará a <b>C&M SOFTWARE</b> pelas consultas/transações já prestadas e concluídas, 
        bem como efetuará o pagamento das despesas já ocorridas, independente da data da rescisão, não sendo aplicada a forma de cobrança “pro rata die”.
    </p>   
";

$texto[8] =
"   
    <p>
        <b>9.5.</b> Antes do término da vigência do presente Contrato, ou por qualquer outro motivo de rescisão deste Contrato, o <b>CONTRATANTE</b> poderá utilizar as ferramentas de exportação,
        conforme disponíveis, para realizar a transferência final dos registros (logs) associados com as atividades dos usuários do <b>CONTRATANTE</b>, configurando a transferência dos dados de 
        acesso. Quando do encerramento do Contrato, a <b>C&M SOFTWAREM</b> excluirá todos os Dados Pessoais e de acesso remanescentes, configurando a exclusão de todos os dados pessoais e de 
        acesso.
    </p>    
    <p>
        <b>9.6.</b> Em <b>até 30 (trinta) dias</b> após o encerramento do presente contrato, a <b>C&M SOFTWAREM</b> disponibilizará a <b>CONTRATANTE</b> todo o conjunto de dados em utilização, formato 
        “in natura”, nos termos do presente sem nenhum tipo de adequação ou ordenamento.
    </p>
    <p><b>CLÁUSULA DÉCIMA: DAS DISPOSIÇÕES GERAIS</b></p>
    <p>
        <b>10.1.</b> Nenhuma disposição deste contrato poderá ser interpretada como tendo as Partes estabelecido qualquer forma de sociedade ou associação, de fato ou de direito, 
        remanescendo cada uma das partes com suas obrigações civis, comerciais, trabalhistas e tributárias, de forma autônoma.
    </p>
    <p>
        <b>10.2.</b> Nenhuma das Partes poderá ceder ou transferir, no todo ou em parte, os direitos e obrigações decorrentes deste Contrato, sem a anuência prévia e expressa da 
        outra Parte.
    </p>
    <p>
        <b>10.3.</b> Qualquer aditamento ou alteração a este Contrato somente será válida se feito por meio de aditivo contratual, escrito e assinado pelas Partes.
    </p>
    <p>
        <b>10.4.</b> Todas as obrigações e condições aqui estipuladas obrigam as Partes e seus sucessores a qualquer título.
    </p>
    <p>
        <b>10.5.</b> Todas as notificações ou comunicações dadas segundo o presente Contrato, de uma Parte à outra, deverão ser endereçadas somente por via postal através de carta 
        registrada, com aviso de recebimento, para os representantes legais nos endereços constantes na qualificação das Partes. Se houver alteração do Representante Legal, deverá ser 
        anexado documento de comprovação.
    </p>
    <p> 
        <b>10.6.</b> A tolerância de uma Parte com a outra, relativamente a qualquer violação ou descumprimento de quaisquer obrigações ora assumidas, não será considerada moratória, 
        novação ou renúncia a qualquer direito, constituindo mera liberalidade, que não impedirá a Parte tolerante de exigir da outra o fiel cumprimento deste Contrato, a qualquer tempo.
    </p>
    <p>
        <b>10.7.</b> O <b>CONTRATANTE</b>, desde já, autoriza a <b>C&M SOFTWARE</b> a incluir o seu nome na sua lista de clientes, assim como sua divulgação, pelos meios de comunicação próprios, 
        juntamente com os nomes de outros clientes, mas não revelará, comunicará ou de qualquer forma fará propaganda a qualquer terceiro de detalhes deste Contrato.
    </p>
    <p>
        <b>10.7.1.</b> Autoriza, também, a divulgação dos projetos e ações de divulgação e marketing relativos aos produtos e Plataforma <b>YELLOW</b> associados à sua marca comercial.
    </p>
    <p>
        <b>10.8.</b> Se qualquer cláusula ou condição deste Contrato vier a ser considerada ilegal, inválida ou inexequível nos termos da legislação brasileira, as demais cláusulas e 
        condições continuarão em pleno vigor e efeitos.
    </p>
    <p>
        <b>10.9.</b> O presente Contrato constitui o acordo final entre as Partes com relação às matérias aqui expressamente tratadas, superando e substituindo todas as propostas, 
        acordos, entendimentos e declarações anteriores, orais ou escritos.
    </p>
    <p>
        <b>10.10.</b> Cada uma das Partes declara, garante e concorda, reciprocamente, que a celebração, outorga e execução deste Contrato foi devidamente autorizada pelos seus legítimos 
        representantes legais, na forma dos seus respectivos documentos societários, sendo que o fornecimento de eventual informação inverídica, incompleta ou inidônea será considerado 
        infração aos princípios da informação e boa-fé contratual, respondendo a parte que assim as prestou civil e criminalmente, restando claro que este contrato constitui obrigação 
        legal, válida e vinculante entre as Partes.
    </p>
    <p>
        <b>10.11.</b> As Partes entendem que nenhum faturamento determinado neste contrato ou seus anexos presentes ou futuros, leva ou levará em consideração algoritmos que contemplem 
        “pro rata die” para construção de seus valores finais.
    </p>
    <p>
        <b>10.12.</b> As Partes elegem o foro da Comarca de Barueri, Estado de São Paulo, para dirimir quaisquer dúvidas ou atos oriundos ou relativos a este contrato, renunciando a 
        qualquer outro por mais privilegiado que seja.
        <br>
        E assim, por estarem justas e contratadas, as partes assinam o presente em 02 (duas) vias de igual teor, na presença das testemunhas abaixo.
    </p>
" ;

?>