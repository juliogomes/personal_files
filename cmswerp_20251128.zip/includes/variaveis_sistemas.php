<?php
	/*
	global $VAR_SYSTEM;
	$VAR_SYSTEM = array(
		'UF'  =>  array(
		      'AC' => 'AC',
		      'AL' => 'AL',
		      'AM' => 'AM',
		      'AP' => 'AP',
		      'BA' => 'BA',
		      'CE' => 'CE',
		      'DF' => 'DF',
		      'ES' => 'ES',
		      'GO' => 'GO',
		      'MA' => 'MA',
		      'MG' => 'MG',
		      'MS' => 'MS',
		      'MT' => 'MT',
		      'PA' => 'PA',
		      'PB' => 'PB',
		      'PE' => 'PE',
		      'PI' => 'PI',
		      'PR' => 'PR',
		      'RJ' => 'RJ',
		      'RN' => 'RN',
		      'RS' => 'RS',
		      'RO' => 'RO',
		      'RR' => 'RR',
		      'SC' => 'SC',
		      'SE' => 'SE',
		      'SP' => 'SP',
		      'TO' => 'TO',
		),

		'SEGMENTO' => array(
			'UTILITIES' => 'UTILITIES',
			'VAREJO'   => 'VAREJO',
			'FINANCEIRO' => 'FINANCEIRO',
			'INDUSTRIA' => 'INDUSTRIA',
			'SERVICOS' => 'SERVIÇOS'
		),

		// 'TIPO_COMISSAO' => array(
		// 	'COMUM' => 'COMUM',
		// 	'INCREMENTAL'   => 'INCREMENTAL',
		// ),

		'COBRANCA' => array(
			'INCREMENTAL-VOLUMETRIA' => 'INCREMENTAL-VOLUMETRIA',     // - Cobrado por pacote mais o volume de uso e direto na faixa correspondente
			'FIXO-INCREMENTAL'       => 'FIXO-INCREMENTAL',    // - cobrado pacote mais incremento de cada faixa excedente
			'FAIXA-FIXA' 	         => 'FAIXA-FIXA',          // - Cobrado um unico valor da faixa correspondente
			'VOLUMETRIA' 		     => 'VOLUMETRIA',          // - Cobrado por pacote ou volume de uso e direto na faixa correspondente 
			'LIQUIDADO-REAL'         => 'LIQUIDADO REAL',      // Cobrado por valor liquidado real
			'LIQUIDADO-RELATIVO'     => 'LIQUIDADO RELATIVO',  // CObrado por porcentagem de valor liquidado
			'VALOR-FIXO'             => 'VALOR FIXO',          // cobrado como valor fixo de uso independemente da quantidade de transações
			'COBRANCA-ELETRONICA'    => 'COBRANCA-ELETRONICA', // - cobrança por dias de atraso do titulo
			'GOCHK'                  => 'GOCHK',               // modo de cobrança especifico para GOCHK
			'KUMRAM'                 => 'KUMRAM',              // modo de cobrança especifico para KUMRAM
		),

		'MODALIDADE' => array(
			'FAIXA'     => 'POR FAIXA',     // - Cobrado por pacote mais o volume de uso e direto na faixa correspondente
			'TRANSACAO' => 'POR TRANSACAO',    // - cobrado pacote mais incremento de cada faixa excedente
		),

		'CODIGO_SERVICO' => array(
			'07003180000104'=> array(
				'010501219' => 'Licenciamento ou cessão de uso de programas de informatica'
			),
			'03215009000108'=> array(
				'010501219' => 'Licenciamento ou cessão de uso de programas de informatica'
			),
			'06076850000150' => array(
				'171201212' => 'ADMINISTRAÇÃO DE BENS',
				'171206217' => 'ADMINISTRAÇÃO DE IMÓVEIS',
				'100502217' => 'AGENCIAMENTO, CORRETAGEM E INTERM. DE BENS IMÓVEIS',
				'100503216' => 'INTERMEDIAÇÃO DE NEGÓCIOS'
			),
			'14289105000117' => array(
				'010101213' => 'ANÁLISE E DESENVOLVIMENTO DE SISTEMAS',
				'010301211' => 'PROCESSAMENTO DE DADOS',
				'010401211' => 'ELABORAÇÃO DE PROGRAMAS DE COMPUTADOR (INCLUS. JOGOS)',
				'010501219' => 'LICENCIAMENTO OU CESSÃO DE USO DE PROGRAMAS DE COMPUTAÇÃO.',
				'010602217' => 'CONSULTORIA EM INFORMÁTICA',
				'010701217' => 'SUPORTE TÉCNICO EM INFORMÁTICA',
				'170101215' => 'ASSESSORIA',
				'170102214' => 'CONSULTORIA',
				'120903211' => 'JOGOS ELETRÔNICOS E VIDEOELETRÔNICOS',
				'170117217' => 'FORNECIMENTO DE DADOS E INFORMAÇÕES',
			),
		),

		'NOLOGIN_EXEC' => array(
			'/run_check_jobs.php'       => true,
			'/run_tarifador.php'        => true,
			'/run_faturamento.php'      => true,
			'/run_jobs.php'             => true,
			'/run_consolida_mensal.php' => true,
			'/webservice.php'           => true,
			'/report/listaMeses'       => true,
			'/pipedrive/graficos'      => true,
			'/despesas/checkRetornoRemessa' => true,
			'/uploads/getRps/' => true,
		),

		#Stagio de pipedrive mmr/closers
		'STAGE_PIPEDRIVE' => array(
			'64' => 'Cliente Entrou em Contato',
			'65' => 'Qualificando Oportunidade',
			'66' => 'Apresentação Agendada',
			'67' => 'Demonstração Agendada',
			'68' => 'Pediu Proposta',
			'69' => 'Proposta Enviada',
			'70' => 'Negociando Proposta',
			'71' => 'Contrato Solicitado',
			'72' => 'Negociando Contrato',
			'73' => 'Coletando Assinaturas',
		),
		
		'ESTAGNADOS' => array(
			'64' => array(
				'STATUS_TIME' => '21',
				'NEXT_ACTION' => '5'
			),
			'65' => array(
				'STATUS_TIME' => '14',
				'NEXT_ACTION' => '3'
			),
			'66' => array(
				'STATUS_TIME' => '7',
				'NEXT_ACTION' => '2'
			),
			'67' => array(
				'STATUS_TIME' => '7',
				'NEXT_ACTION' => '2'
			),
			'68' => array(
				'STATUS_TIME' => '5',
				'NEXT_ACTION' => '1'
			),
			'69' => array(
				'STATUS_TIME' => '10',
				'NEXT_ACTION' => '5'
			),
			'70' => array(
				'STATUS_TIME' => '7',
				'NEXT_ACTION' => '3'
			),
			'71' => array(
				'STATUS_TIME' => '5',
				'NEXT_ACTION' => '3'
			),
			'72' => array(
				'STATUS_TIME' => '15',
				'NEXT_ACTION' => '7'
			),
			'73' => array(
				'STATUS_TIME' => '5',
				'NEXT_ACTION' => '3'
			),
		),

		'PRODUTO' => array(
			'1' => 'ROCKET - PLATAFORMA BPM PARA AUTOMAÇÃO DE CRÉDITO, COBRANÇA, PREVENÇÃO A FRAUDE, MARKETING E VENDAS',
			'2' => 'COBRANÇA ELETRONICA - COBRANÇA ELETRONICA DE ATIVOS DE CRÉDITO',
			'3' => 'EXCLUSIVE COLLOCATION SERVICE - SERVIÇO DE COLLOCATION PARA JÁ CLIENTES',
			'4' => 'GOCHK - MEIO DE PAGAMENTOS',
			'5' => 'LIQUIDADO - SISTEMA DE RENEGOCIAÇÃO DE ATIVOS DE CRÉDITO INTEGRADO AO GOCHK E COBRANÇA ESPECIALIZADA',
			'6' => 'POWERDECK - PLATAFORMA DE CONTAS DE PAGAMENTO',
			'7' => 'SKINBD - DRIVER ODBC PARA CAPTURA DE DADOS DE BASES PUBLICAS E PRIVADAS',
			'8' => 'SPB/X - PSTN PARA SISTEMA DE PAGAMENTOS BRASILEIRO BACEN',
			'9' => 'SPB\/x Open Banking Edition',
			'10' => 'SPI\/x PSTI PARA PAGAMENTOS INSTANTANEOS',
			'11' => 'FULL STR WEB & PIX',
			'12' => 'CornerPIX: AntiFraude',
			'13' => 'CornerPIX: Gateway',
			'14' => 'Assessoria Abertura Conta Liquida\u00e7\u00e3o\/Reserva',
			'17' => 'PINE - ANTIFRAUDE',
			
		),
	);
	*/
