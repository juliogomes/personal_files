<?php
	class AgenteComercialModel extends MainModel{
		//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
		public function __construct( $controller = null ){
			$this->setTable('agente_comercial');
			parent::__construct($controller);
		}

		function getAgente( $id = null ){
			$query = "
				select ac.*, pr.nome nome_produto, ev.razao_social empresa_cm from agente_comercial ac 
				inner join produtos pr on(ac.id_produto = pr.id)
				inner join empresa_vendedora ev on(ac.id_empresa = ev.id) 
				where (ac.deleted is null or ac.deleted = 0)
			";
			if( is_numeric( $id ) && !empty( $id ) ){
				$query .= " and ac.id = $id ";
			}
			return $this->db->exec( $query );
		}

		function getAllAgentes( $CnpjCpf ){
			$query = "
				select 
					ac.*, 
					pr.nome nome_produto, 
					ev.razao_social empresa_cm 
				from 
					agente_comercial ac inner join 
					produtos pr on(ac.id_produto = pr.id) inner join 
					empresa_vendedora ev on(ac.id_empresa = ev.id) 
				where 
					(ac.deleted is null or ac.deleted = 0)
			";
			if( $CnpjCpf && is_numeric( $CnpjCpf ) ){
				$query .= " and ac.numero_documento = $CnpjCpf ";			
			}
			return $this->db->exec( $query );
		}

		function getAgenteByCnpj( $CnpjCpf ){
			if( !$CnpjCpf ){
				return false;
			}else{
				$query = "
					select 
						ac.*, 
						pr.nome nome_produto, 
						ev.razao_social empresa_cm 
					from 
						agente_comercial ac inner join 
						produtos pr on(ac.id_produto = pr.id) inner join 
						empresa_vendedora ev on(ac.id_empresa = ev.id) 
					where 
						(ac.deleted is null or ac.deleted = 0)
				";
				if( $CnpjCpf && is_numeric( $CnpjCpf ) ){
					$query .= " and ac.numero_documento = $CnpjCpf ";			
				}
				return $this->db->exec( $query );
			}
		}

		function getfContratoByCnpjProduto( $cnpj_cpf, $codigo_produto = null ){
			if( $cnpj_cpf ){
				$query = "
					select 
						ifco.*,
						pr.codigo codigo_produto,
						pr.nome nome_produto
					from 
						if_contrato ifco inner join
						produtos pr on( pr.id = ifco.id_produto )
					where 
						(ifco.deleted is null or ifco.deleted = 0) and ifco.cnpj = $cnpj_cpf
				";
				if( $codigo_produto ){
					$query .= " and pr.codigo = '$codigo_produto' ";
				}
			}else{
				return false;
			}
			return $this->db->exec( $query );
		}

		function getLastCodigoAgente(){
			$query = "select id, codigo_agente from agente_comercial ac order by codigo_agente desc limit 1";
			return $this->db->exec( $query );
		}

		function getLastContratoAgente(){
			$query = " select id, numero_contrato from agente_comercial order by numero_contrato desc limit 1";
			return $this->db->exec( $query );
		}

		function getEmpresasCMByCnpj( $cnpj ){
			if( is_numeric( $cnpj ) && !empty( $cnpj ) ){
				$query = " select * from empresa_vendedora ev where ev.status = 'ativo' nd ev.cnpj = $cnpj ";
				return $this->db->exec( $query );
			}else{
				return false;
			}
		}

		function getEmpresasCMById( $id ){
			if( is_numeric( $id ) && !empty( $id ) ){
				$query = " select * from empresa_vendedora ev where ev.status = 'ativo' and ev.id = $id ";
				return $this->db->exec( $query );
			}else{
				return false;
			}
		}

		function getClientesPorCnpjProduto( $CnpjCpf, $codigo_produto ){
			if( !$CnpjCpf || !is_numeric( $CnpjCpf ) ){
				return false;
			}

			if( !$codigo_produto ){
				return false;
			}

			$query = "
				SELECT
					co.id, 
					co.cnpj,
					co.cnpj_fantasia,
					co.inscricao_municipal,
					co.inscricao_estadual,
					co.razao_social,
					co.nome_fantasia,
					co.nome_representante,
					co.segmento,
					co.endereco,
					co.numero,
					co.bairro,
					co.cidade,
					co.estado,
					co.data_assinatura,
					pr.codigo codigo_produto,
					pr.nome nome_produto,
					pr.codigo codigo_produto,
					pr.nome nome_produto
				FROM 
					contratos co INNER JOIN
					produtos pr ON( co.id_produto = pr.id ) INNER join
					agente_comercial aco ON(aco.id = co.id_agente_comercial)
				WHERE
					( co.deleted is null or co.deleted = 0 ) and
					co.cnpj = '$CnpjCpf' and 
					pr.codigo = '$codigo_produto'
			";
			return $this->db->exec( $query );
		}

		function getLastCodigoCliente(){
			$query = " select numero_contrato from agente_comercial order by numero_contrato desc limit 1";
			return $this->db->exec( $query );
		}

		function getClientesByCnpjCpfAgente( $CnpjCpf ){
			if( !$CnpjCpf || !is_numeric( $CnpjCpf ) ){
				return false;
			}

			$query = " 
				SELECT 
					co.cnpj,
					co.cnpj_fantasia,
					co.inscricao_municipal,
					co.inscricao_estadual,
					co.razao_social,
					co.nome_fantasia,
					co.nome_representante,
					co.segmento,
					co.endereco,
					co.numero,
					co.bairro,
					co.cidade,
					co.estado,
					co.data_assinatura,
					pr.codigo codigo_produto,
					pr.nome nome_produto,
					pr.codigo codigo_produto,
					pr.nome nome_produto
				FROM 
					contratos co INNER JOIN
					produtos pr ON( co.id_produto = pr.id ) INNER join
					agente_comercial aco ON(aco.id = co.id_agente_comercial)
				WHERE
					( co.deleted is null or co.deleted = 0 ) and
					( aco.deleted is null or aco.deleted = 0 ) and
					aco.numero_documento = '$CnpjCpf'
			";
			return $this->db->exec( $query );
		}

		function getContratosByStep( $step ){
			if( $step && is_numeric( $step ) ){
				$query = "
					SELECT 
						ifco.*,
						pr.codigo codigo_produto,
						pr.nome nome_produto
					FROM 
						if_contrato ifco INNER JOIN
						agente_comercial aco on( ifco.id_agente = aco.id ) inner join
						produtos pr ON( ifco.id_produto = pr.id )
					WHERE
						( ifco.deleted is null or ifco.deleted = 0 ) and ifco.step = $step ";
				return $this->db->exec( $query );
			}else{
				return false;
			}
		}
	}
