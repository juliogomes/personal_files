<?php

/**
 * Luciano Damasceno
 * 21/11/2025
 */
class AprovacoesModel extends MainModel
{
	public function __construct($controller = null)
	{
		$this->setTable('aprovacoes');
		parent::__construct($controller);
	}

	public function getGrupos($id_origem, $id_proposta)
	{
		$query = "
				SELECT DISTINCT
					gu.id_usuario,
					gu.ordem,
					gu.e_ou,
					gu.id_grupo,
					gu.tipo_membro,
					su.nome,
					ga.id as id_aprovacao,
					ga.status,
					ga.justificativa 
				FROM grupos_usuarios gu
				INNER JOIN sistema_usuarios su 
					ON su.id = gu.id_usuario
				INNER JOIN grupos_sistema gs 
					ON gs.id = gu.id_grupo
				LEFT JOIN grupo_aprovacoes ga 
					ON ga.id_item = '$id_proposta'
					AND ga.id_grupo = gu.id_grupo
					AND ga.id_usuario = gu.id_usuario
					AND (ga.deleted IS NULL OR ga.deleted = 0)
				WHERE gs.funcao  = 'aprovacao'
				AND gs.origem  = 'proposta'
				AND gs.id_origem = '$id_origem'
				AND (gs.deleted IS NULL OR gs.deleted = 0)
				ORDER BY gu.ordem;";

		return $this->db->exec($query);
	}

	// public function getAprovacoes($id_grupo)
	// {
	// 	$query = "
	// 		SELECT * FROM grupo_aprovacoes ga
	// 		INNER JOIN grupos_usuarios gu ON gu.id = ga.id_grupo
	// 		WHERE ga.id_grupo = $id_grupo and (ga.deleted = 0 OR ga.deleted is NULL)";

	// 	return $this->db->exec($query);
	// }
}
