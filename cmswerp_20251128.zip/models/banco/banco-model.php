<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class BancoModel extends MainModel{
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	public function __construct( $controller = null ){
		$this->setTable('banco');
		parent::__construct($controller);
	}
	// funcoes abaixo a serem revisadas ou substituidas
	function getBanco($id = null, $deleted = false){
		$query = "
			select 
				tb1.*
			from ".$this->getTable()." tb1 where (tb1.deleted is null or tb1.deleted = 0)
		";

		if($id){
			$query .= " and tb1.id = $id ";
		}
		$query .= " order by tb1.nome_reduzido ";
		return $this->db->exec($query);
	}

	function getBancoByCodigo($codigo){
		$query = "
			select 
				tb1.*
			from ".$this->getTable()." tb1 where (tb1.deleted is null or tb1.deleted = 0)
		";

		if($codigo){
			$query .= " and tb1.codigo_banco = $codigo ";
		}
		$query .= " order by tb1.nome_reduzido ";
		return $this->db->exec($query);
	}

	function getBancoByNome($nome){
		$query = "
			select 
				tb1.*
			from ".$this->getTable()." tb1 where (tb1.deleted is null or tb1.deleted = 0)
		";

		if($nome){
			$query .= " and tb1.nome_reduzido like '%$nome%'";
		}
		$query .= " order by tb1.nome_reduzido ";
		return $this->db->exec($query);
	}
}
