<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class BoletoModel extends MainModel{
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	public function __construct( $controller = null ){
		$this->table = 'remessa_boletos';		
		parent::__construct($controller);
	}

	function getBoleto($id = null, $id_remessa = null){
		$query = " select 
						tb1.*, 
						tb2.id id_remessa,
						tb2.codigo_arquivo, 
						tb2.nome_arquivo,
						tb2.tipo_inscricao,
						tb2.numero_inscricao,
						tb2.codigo_empresa,
						tb2.nome_empresa,
						tb2.codigo_convenio,
						tb2.agencia,
						tb2.agencia_dv,
						tb2.conta,
						tb2.conta_dv,
						tb2.nome_banco,
						tb2.data_gravacao,
						tb2.id_sistema,
						tb2.num_seq_remessa,
						tb2.status status_remessa
					from $this->table tb1 inner join remessa_arquivo tb2 on (tb1.id_remessa = tb2.id) where (tb1.deleted = 0 or tb1.deleted is null)";
		if(is_array($id)){
			$query .= " and tb1.id in(".implode(',',$id).");";
		}elseif($id){
			$query .= " and tb1.id = $id;";
		}

		if(is_array($id_remessa)){
			$query .= " and tb1.id_remessa in(".implode(',',$id_remessa).");";
		}elseif($id_remessa){
			$query .= " and tb1.id_remessa = $id_remessa;";
		}
		//echo $query;
		return $this->db->exec($query);
	}

	function getBoletosByRemessa($id_remessa){
		$query = " select * from $this->table tb1 inner join remessa_arquivo tb2 on (tb1.id_remessa = tb2.id) where (tb1.deleted = 0 or tb1.deleted is null) and (tb2.deleted = 0 or tb2.deleted is null) ";
		if(is_array($id_remessa)){
			$query .= " and tb1.id_remessa in(".implode(',',$id_remessa).");";
		}elseif($id_remessa){
			$query .= " and tb1.id_remessa = $id_remessa;";
		}
		//echo $query;
		return $this->db->exec($query);
	}

	function getBoletosByEmissao($data_emissao =  null){
		$query = " select tb1.*, tb2.codigo_convenio, tb2.agencia from $this->table tb1 inner join
		 remessa_arquivo tb2 on (tb1.id_remessa = tb2.id) where (tb1.deleted = 0 or tb1.deleted is null) and (tb2.deleted = 0 or tb2.deleted is null) ";
		if(is_array($data_emissao)){
			$query .= " and tb1.emitido_em in(".implode(',',$data_emissao).");";
		}elseif($data_emissao){
			$query .= " and tb1.emitido_em = '$data_emissao';";
		}
		// echo $query;
		// exit;
		return $this->db->exec($query);
	}

	function getBoletoAndNota($id = null){
		$query = " select * from $this->table tb1 inner join remessa_arquivo tb2  where (deleted = 0 or deleted is null) ";
		if(is_array($id)){
			$query .= " and id in(".implode(',',$id).");";
		}elseif($id){
			$query .= " and id = $id;";
		}
		//echo $query;
		return $this->db->exec($query);
	}

	function getRemessa($id = null){
		$query = " select * from remessa_arquivo where (deleted = 0 or deleted is null)";
		if(is_array($id)){
			$query .= " and id in(".implode(',',$id).");";
		}elseif($id){
			$query .= " and id = $id;";
		}
		//echo $query;
		return $this->db->exec($query);
	}

	

	function getLastBoleto($status = null){
		$query = " select * from remessa_boletos where (deleted = 0 or deleted is null)";
		if($status){
			$query .= " and status = '$status'";
		}
		$query .= " order by id desc limit 1";
		return $this->db->exec($query);
	}

	function getLotesByArquivo($id_arquivo){
		$query = " select * from remessa_lote where (deleted = 0 or deleted is null)";
		if(is_array($id_arquivo)){
			$query .= " and id_arquivo in(".implode(',',$id_arquivo).");";
		}elseif($id_arquivo){
			$query .= " and id_arquivo = $id_arquivo;";
		}
		//echo $query;
		return $this->db->exec($query);
	}

	function getBoletosByArquivo($id_arquivo){
		$query = " SELECT
			arb.id id_arquivo,
			bol.*
		FROM
			remessa_boletos bol INNER join
			remessa_lote lb ON(bol.id_lote = lb.id) INNER join
			remessa_arquivo arb ON(arb.id = lb.id_arquivo)
		WHERE 
			(bol.deleted = 0 OR bol.deleted IS NULL)
		";

		if(is_array($id_arquivo)){
			$query .= " and arb.id in(".implode(',',$id_arquivo).");";
		}elseif($id_arquivo){
			$query .= " and arb.id = $id_arquivo;";
		}
		//echo $query;
		return $this->db->exec($query);
	}
}
