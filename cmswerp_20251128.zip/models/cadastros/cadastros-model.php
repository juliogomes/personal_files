<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class CadastrosModel extends MainModel{
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	public function __construct( $controller){
		parent::__construct($controller);
	}

	function getRecords($id = null){
		$query = " select * from $this->table  where (deleted is null or deleted = 0) ";
		if(isset($id) && is_numeric($id)){
			$query .= " and id = $id ";
		}
		return $this->controller->Db->exec($query);
	}


	function getVendedoresByEmail($email){
		$query = " select * from vendedores	where (deleted = 0 or deleted is null) and status='ativo' ";
		if($email){
			$query .= " and email = '$email'";
		}
		$exec = $this->controller->Db->query($query);
		if($exec)
		{
			// Retorna
			$result = $exec->fetchAll();
			return json_encode($result);
		}
		else
		{
			return false;
		}
	}

	function getComissionadosPorContrato($id_comercial = null, $cargo = null, $upselling = false){
		$query = "
			select distinct
				comissao_devida_ate,
				id_contrato
			from
				comissoes com inner join
				contratos co on(co.id = com.id_contrato)
			where
				(co.deleted = 0 or co.deleted is null) and
				(com.deleted = 0 or com.deleted is null) and
				co.status = 'ativo'
		";

		if($cargo == 'diretor'){
			$query .= " and com.id_diretor = $id_comercial ";
		}

		if($cargo == 'vendedor' && !$upselling){
			$query .= " and com.id_vendedor = $id_comercial ";
		}

		if($upselling){
			$query .= " and (com.id_vendedor = $id_comercial or co.upselling = 1) and (co.upselling = 1 or com.comissao_devida_ate >= now()) ";
		}else{
			$query .= " and com.comissao_devida_ate >= now() ";
		}
		
		$exec = $this->controller->Db->query($query);
		if($exec){
			// Retorna
			$result = $exec->fetchAll();
			return json_encode($result);
		}else{
			return false;
		}
	}

	function getImplatacao($id_contrato){
		$query = "
		select * from implantacao where id_contrato = ?
		";
		$exec = $this->controller->Db->query($query, array($id_contrato));
		if($exec)
		{
			// Retorna
			return $result = $exec->fetchAll();
		}
		else
		{
			return false;
		}
	}

	function getModuloByField($field, $value){
		$query = "
		select * from modulos_tarifaveis where $field = '$value'
		";
		$exec = $this->controller->Db->query($query);
		if($exec)
		{
			// Retorna
			$return = $exec->fetchAll();
			return json_encode($return);
		}
		else
		{
			return false;
		}
	}

	function saveListaCliente($id_contrato, $param){
		return $this->saveTabelasAuxiliares('lp_clientes', $id_contrato, 'id_contrato', $param, true);
	}

	function customSave($param, $id = null){
		foreach ($param as $key => $value)
		{
			if(!is_array($value))
			{
				$contrato[$key] = $value;
			}
			else
			{
				$tab_auxiliar[$key] = $value;
			}
		}
		if($id)
		{
			$id = (int) $id;
			if(is_numeric($id) && !empty($id))
			{
				$where_field = 'id';
				$where_field_value = $id;
				$this->controller->Db->update('contratos', $where_field, $where_field_value, $contrato);
			}
			else
			{
				$this->controller->Db->error = 'ID do registro invalido';
			}
		}
		else
		{
			$this->controller->Db->insert('contratos', $contrato );
		}
		if(!$this->controller->Db->error)
		{
			if(empty($id)){ $id = $this->controller->Db->last_id; }
			if(!empty($tab_auxiliar['contrato_aniversario']))
			{
				$id_tab_aux = $this->saveTabelasAuxiliares('contrato_aniversario', $id, 'id_contrato', $tab_auxiliar['contrato_aniversario']);
			}
			if(!empty($tab_auxiliar['comissoes']))
			{
				$id_tab_aux = $this->saveTabelasAuxiliares('comissoes', $id, 'id_contrato', $tab_auxiliar['comissoes']);
			}
			if(!empty($contrato['valor_implantacao']))
			{
				$this->saveImplantacao($id, $contrato['parcelado_em'], $contrato['valor_implantacao'], $contrato['primeira_parcela_em']);
			}
			$this->success = 'Registro salvo com sucesso com o ID: '.$id;
			return $id;
		}
		else
		{
			$this->error = 'Erro ao salvar o registro '.$this->controller->Db->error;
			return false;
		}
	}
}