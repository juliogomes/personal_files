<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class LpClienteModel extends MainModel
{
	public function __construct($controller = null ){
		parent::__construct($controller);
		$this->setTable('lp_clientes');
	}
}