<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */

class KumramModel extends MainModel
{
   
}