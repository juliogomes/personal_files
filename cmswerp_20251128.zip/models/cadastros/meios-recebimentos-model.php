<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */

class MeiosRecebimentosModel extends MainModel
{
    //A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
    public $table = 'meios_recebimentos';

    public function __construct( $controller = null )
    {
        parent::__construct($controller);
    }

    function getAllMeiosRecebimentos($id = null){
        if(!empty($id)){
            $query = "select * from $this->table where deleted = 0 or deleted is null and id = $id";
        }elseif($id == null){
            $query = "select * from $this->table where deleted = 0 or deleted is null";
        }
        if(isset($query)){
            $exec = $this->controller->Db->query($query);
            if($exec){
                // Retorna
                $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }else{
            return false;
        }
    }
}