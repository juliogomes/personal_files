<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class CmswModel extends MainModel{
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	public function __construct( $controller = null ){
		$this->table = 'empresa_vendedora';
		parent::__construct($controller);
	}

	public function getSelf($cnpj){
		if($cnpj){
			$query = "
				select 
					*
				from 
					empresa_vendedora ev inner join
					conta_bancaria cb on(cb.id_empresa = ev.id ) inner join 
					banco bco on(cb.id_banco = bco.id)
				where 
					(ev.deleted is null or ev.deleted = 0 ) AND
					(cb.deleted is null or cb.deleted = 0 ) AND
					cb.origem_conta = 'empresa_cm' AND 
					cb.status = 'a' and ev.cnpj = $cnpj
			";
			return $this->db->exec($query);
		}else{
			return false;
		}
	}

	public function getContaDefaultByCpf($cnpj){
		if($cnpj){
			$query = "
				select 
					*
				from 
					empresa_vendedora ev inner join
					conta_bancaria cb on(cb.id_empresa = ev.id ) inner join 
					banco bco on(cb.id_banco = bco.id)
				where 
					(ev.deleted is null or ev.deleted = 0 ) AND
					(cb.deleted is null or cb.deleted = 0 ) AND
					cb.origem_conta = 'empresa_cm' AND
					cb.conta_default = 1 and 
					cb.status = 'a' and ev.cnpj = $cnpj
			";
			return $this->db->exec($query);
		}else{
			return false;
		}
	}
	
	public function getContaDefaultCm($cnpj){
		if($cnpj){
			$query = "
				select 
					*
				from 
					empresa_vendedora ev inner join
					conta_bancaria cb on(cb.id_empresa = ev.id ) inner join 
					banco bco on(cb.id_banco = bco.id)
				where 
					(ev.deleted is null or ev.deleted = 0 ) AND
					(cb.deleted is null or cb.deleted = 0 ) AND
					cb.origem_conta = 'empresa_cm' AND
					cb.conta_default = 1 and 
					cb.status = 'a' and ev.cnpj = $cnpj
			";
			return $this->db->exec($query);
		}else{
			return false;
		}
	}
}
