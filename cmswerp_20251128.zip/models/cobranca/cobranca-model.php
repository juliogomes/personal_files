<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class CobrancaModel extends MainModel{
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	public function __construct( $controller = null ){
		parent::__construct( $controller );
		//seta a tabela padrão de cobranca por cliente
		$this->table = 'lp_clientes';
	}

	function getFaixa( $id_faixa, $return_json = true ){
		$query = "select *, id id_lp_cliente from lp_clientes where (deleted = 0 or deleted is null) and lp_clientes.id = $id_faixa order by qtd_de, qtd_ate, valor_real;";
		return $this->db->exec( $query );
	}

    function getFaixaPadrao( $id_faixa, $return_json = true ){
		$query = "select * from lp_default where (deleted = 0 or deleted is null) and id = $id_faixa order by qtd_de, qtd_ate, valor_real;";
		return $this->db->exec($query);
	}

	function getListaPrecoPadraoIdProduto( $id_produto = null, $id_modulo = null, $codigo_produto = null ){
		$query = " select * from lp_default lp where (lp.deleted = 0 or lp.deleted is null ) and lp.status = 'ativo ' ";
		if($id_produto){
			$query .= " and lp.id_produto = $id_produto ";
		}
		if($id_modulo){
			$query .= " and lp.id_modulo = $id_modulo ";
		}
		$query .= " order by qtd_de ";
		return $this->db->exec($query);
	}

	function getListaPrecoPadraoByCodigo( $codigo_produto = null, $codigo_modulo = null ){
		$query = " select lp.* from lp_default lp inner join produtos pr on(lp.id_produto = pr.id) inner join modulos_tarifaveis mt on(lp.id_modulo = mt.id) where (lp.deleted = 0 or lp.deleted is null ) and lp.status = 'ativo ' ";
		if( $codigo_produto ){
			$query .= " and pr.codigo = '$codigo_produto' ";
		}
		if( $codigo_modulo ){
			$query .= " and mt.codigo = '$codigo_modulo' ";
		}
		$query .= " order by qtd_de ";
		return $this->db->exec( $query );
	}

	function getPacote( $id_contrato, $id_modulo, $ativo = true ){
		$query = "select * from pacote_contratado where (deleted = 0 or deleted is null ) and id_contrato = $id_contrato and id_modulos_tarifaveis = $id_modulo";
		if( $ativo ){
			$query .= " and status = 'ativo' ";
		}
		return $this->db->exec($query);
	}

	function deletar( $id ){
		if(is_numeric($id)){
			$param['deleted'] = 1;
			return $this->save($param, $id);
		}else{
			return false;
		}
	}

	function getLpHistorico( $id_lp ){
		$query = "
			select
				lh.id, lh.id_lp, lh.id_contrato, lh.id_produto, lh.id_modulo, lh.indice, lh.qtd_de, lh.qtd_ate, lh.valor_real, lh.percentual, lh.valor_antigo, 
				lh.valor_reajuste, lh.valor_atualizado, lh.ano_reajuste, lh.mes_reajuste, lh.tipo_atualizacao, lh.alterado_em, lh.alterado_por, u.nome
		 	from 
				lp_historico lh left join
				sistema_usuarios u
			on
				lh.alterado_por = u.id
			where 
				(lh.deleted is null or lh.deleted = 0)";
		if($id_lp){
			$query .= " and lh.id_lp = '$id_lp'";
		}
		$query .= " order by lh.alterado_em desc";
		return $this->db->exec($query);
	}

	function getPacoteHistorico( $id_contrato = null, $id_modulo = null ){
		$query = "
			select
				p.id, 
				p.id_contrato, 
				p.id_pacote, 
				p.qdt_atual, 
				p.qdt_atualizada, 
				p.preco_atual, 
				p.percentual, 
				p.preco_atualizado, 
				p.id_modulos_tarifaveis, 
				p.ano_reajuste, 
				p.mes_reajuste, 
				p.tipo_atualizacao, 
				p.alterado_em, 
				p.alterado_por, 
				u.nome
		 	from 
				pacote_historico p left join
				sistema_usuarios u on p.alterado_por = u.id
			where 
				(p.deleted is null or p.deleted = 0)";

		if( $id_contrato ){
			$query .= " and p.id_contrato = '$id_contrato'";
		}

		if( $id_modulo ){
			$query .= " and p.id_modulos_tarifaveis = '$id_modulo'";
		}
		$query .= " order by p.alterado_em desc";
		return $this->db->exec( $query );
	}
}