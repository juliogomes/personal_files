<?php
    /**
     * Created by PhpStorm.
     * User: caio.freitas
     * Date: 13/07/2022
     */
    class ComissaoModel extends MainModel{
        public function __construct($controller = null ){
            parent::__construct($controller);
            // $this->setTable('configuracoes');
        }

        //By: Caio Freitas 13/07/2022
        function getPerfilComissao($id_comissao){
            $query = "
                SELECT 
                    *
                FROM
                    comissoes_perfil
                WHERE
                    (deleted is null or deleted = 0)
            ";

            if($id_comissao){
                $query .= " and id = '$id_comissao'";
            }
            $query .= " ORDER BY id ASC";
            return $exe = $this->db->exec($query);
        }
        
        //By: Caio Freitas 29/05/2023
        function getPerfilComissaoUsuario( $id_comissao = null, $group = null ){
            $query = "
                SELECT 
                    cp.nome as nome_perfil,
                    cp.objeto,
                    cp.percentual,
                    cp.id as id_perfil,
                    cu.id_usuario,
                    cu.id as id_comissoes,
                    u.nome,
                    u.email,
                    u.id,
                    u.id_empresa
                FROM
                    comissoes_perfil cp INNER JOIN
                    comissoes_usuario cu ON (cp.id = cu.id_perfil) INNER JOIN
                    sistema_usuarios u ON (u.id = cu.id_usuario)
                WHERE
                    (cu.deleted is null or cu.deleted = 0)
            ";

            if( $id_comissao ){
                $query .= " and cu.id = '$id_comissao'";
            }

            if( $group && $group === true ){
                $query .= "GROUP BY cp.id";
            }
            $query .= " ORDER BY cu.id ASC";
            return $this->db->exec( $query );
        }

        //By: Caio Freitas 06/07/2022
        function getComissao($id_comissao = null){
            $query = "
                SELECT 
                    cp.id,
                    cp.nome, 
                    cp.descricao, 
                    cp.objeto,
                    cp.percentual          
                FROM 
                    comissoes_perfil cp               
                WHERE 
                    (cp.deleted is null or cp.deleted = 0)
            ";

            if($id_comissao){
                $query .= " and cp.id = $id_comissao";
            }
            $query .= " ORDER BY cp.id ASC";
            return $exe = $this->db->exec($query);
        }

        function getComissaoUsuario($id_perfil = null, $id_usuario = null, $id_comissao_usuario = null, $nome = null, $nome_perfil = null){
            $query = "
            SELECT 
                c.id as id_comissao,
                c.id_perfil,
                c.id_usuario as id,             
                u.nome,
                cp.nome as nome_perfil,           
                cp.percentual,
                cp.objeto
            FROM
                comissoes_usuario c
            INNER JOIN
                sistema_usuarios u
            ON
                (c.id_usuario = u.id)
            INNER JOIN
                comissoes_perfil cp
            ON
                (c.id_perfil = cp.id)           
            WHERE
                (c.deleted is null or c.deleted = 0)";
        
            if($id_perfil){
                $query .= " and c.id_perfil = $id_perfil";
            }

            if($id_usuario){
                $query .= " and c.id_usuario = $id_usuario";
            }

            if($id_comissao_usuario){
                $query .= " and c.id = $id_comissao_usuario";
            }

            if($nome){
                $query .= " and c.nome = '$nome'";
            }

            if($nome_perfil){
                $contador = 0;
                if(is_array($nome_perfil)){
                    $query .= " and cp.nome in ( ";
                    foreach ($nome_perfil as $key => $value) {
                        if($contador == 0){
                            $query .= "'$value'";
                        }else{
                            $query .= ", '$value'";
                        }
                        $contador++;
                    }
                    $query .= " )";
                }else{
                    $query .= " and cp.nome = '$nome_perfil'";
                }
            }

            $query .= " order by u.nome asc"; 
            return $exe = $this->db->exec($query);
        }

        //By: Caio Freitas - 13/09/2022
        function getFullComissao($id_objeto = null, $id_usuario = null, $id = null){
            $query = "
                SELECT
                    c.id_perfil,
                    c.id_usuario,             
                    u.nome as nome_usuario,
                    cp.nome as nome_perfil,           
                    cp.percentual,
                    cp.objeto,
                    cv.meses_validade,
                    cv.data_criacao,
                    cv.id,
                    cv.perfil,
                    cv.id_objeto
                FROM
                    comissoes_usuario c
                INNER JOIN
                    sistema_usuarios u
                ON
                    (c.id_usuario = u.id)
                INNER JOIN
                    comissoes_perfil cp
                ON
                    (c.id_perfil = cp.id)
                INNER JOIN
                    comissoes_validade cv
                ON
                    (cv.id_comissao_usuario = c.id)
                WHERE
                    (cv.deleted = 0 or cv.deleted is null)
            ";

            if($id_objeto){
                $query .= " and cv.id_objeto = $id_objeto";
            }

            if($id_usuario){
                $query .= " and cv.id_usuario = $id_usuario";
            }

            if($id){
                $query .= " and cv.id = $id";
            }
            $query .= " order by cv.id asc";
            return $this->db->exec($query);
        }

        function getComissoesByObjeto( $id_objeto, $tipo_objeto = 'minuta' ){
            $query = "
                SELECT
                    ico.*,
                    pro.id id_proposta,
                    pro.id_owner,
                    cov.id id_comissao_validade,
                    cov.meses_validade,
                    ut.nome nome_usuario,
                    ut.cargo,
                    cop.id id_perfil,
                    cop.nome perfil,
                    cop.nome nome_perfil
                FROM
                    if_contrato ico INNER join
                    propostas pro ON(ico.id_proposta = pro.id) INNER join
                    comissoes_validade cov ON(cov.id_objeto = ico.id ) INNER join
                    sistema_usuarios ut ON (cov.id_usuario = ut.id )  INNER join
                    comissoes_usuario cou ON( cou.id_usuario = cov.id_usuario ) INNER join
                    comissoes_perfil cop ON(cop.id = cou.id_perfil)
                WHERE
                    ( pro.deleted IS NULL OR pro.deleted = 0) AND 
                    ( cou.deleted IS NULL OR cou.deleted = 0) AND
                    ( cop.deleted IS NULL OR cop.deleted = 0) AND
                    ico.id = $id_objeto;
            ";
            //echo $query.'<br><br>';
            return $this->db->exec($query);
        }
    }
