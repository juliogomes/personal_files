<?php
	/**
	 * Created by PhpStorm.
	 * User: julio.gomes
	 * Date: 14/10/2016
	 * Time: 15:57
	 */
	class ComissoesModel extends MainModel{
		public $table =  'comissoes';
		//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
		public function __construct($controller = null ){
			parent::__construct($controller);
		}

		// function listaComissionados($id = null, $ativos = true){
		// 	$query = " select * from comissionados where (deleted is null or deleted = 0) ";

		// 	if($id){
		// 		$query .= " and id =  $id ";
		// 	}

		// 	if($ativos){
		// 		$query .= " and status = 'A' ";
		// 	}
		// 	$query .= " order by nome ";
		// 	return $this->db->exec($query);
		// }

		// function getComissoes($id = null, $id_comercial = null){
		// 	$query = "
		// 		select
		// 			cm.*,
		// 			cm.id id_comissao,
		// 			co.razao_social,
		// 			co.nome_fantasia,
		// 			co.data_assinatura,
		// 			cm.status status_comissao,
		// 			pr.codigo codigo_produto
		// 		from
		// 			comissoes cm inner join
		// 			contratos co on(co.id = cm.id_contrato) inner join
		// 			produtos pr on(co.id_produto = pr.id)
		// 		where
		// 			(cm.deleted is null or cm.deleted = 0)
		// 	";

		// 	if($id){
		// 		$query .= " and cm.id = $id ";
		// 	}

		// 	if($id_comercial){
		// 		$query .= " and cm.id_comercial = $id_comercial ";
		// 	}
		// 	$query .= " order by co.razao_social ";
		// 	return $this->db->exec($query);
		// }

		// function getComissoesByIdContratoENf($id_nf, $id_comercial, $periodo_ini, $periodo_fim){
		// 	if($id_nf){
		// 		$query = "
		// 			select
		// 				nf.id id_nf,
		// 				cm.id id_comissao,
		// 				co.id id_contrato,
		// 				co.nome_fantasia,
		// 				co.data_assinatura,
		// 				pr.id id_produto,
		// 				pr.codigo codigo_produto,
		// 				com.nome nome_comercial,
		// 				com.email email_vendedor,
		// 				cm.cargo,
		// 				cm.tipo_comissao,
		// 				cm.valida_de,
		// 				cm.valida_ate,
		// 				cm.valor_comissao,
		// 				cm.status comissao_status,
		// 				nf.id id_nf,
		// 				nf.valor_liquido,
		// 				nf.valor_desconto,
		// 				nf.valor_fatura,
		// 				nf.valor_total,
		// 				nf.data_emissao,
		// 				nf.data_vencimento,
		// 				nf.recebido_em,
		// 				nf.status nf_status
		// 			from
		// 				contratos co left join
		// 				comissoes cm on(co.id = cm.id_contrato) left join
		// 				comissionados com on(com.id = cm.id_comercial) left join
		// 				produtos pr on(pr.id = co.id_produto) left join
		// 				notas_fiscais nf on(nf.id_contrato = co.id)
		// 			where
		// 				( cm.deleted is null or cm.deleted = 0 ) and
		// 				cm.status = 'ativo'
		// 		";
				
		// 		if($id_nf){
		// 			if(is_array($id_nf)){
		// 				$query .= " and nf.id in(".implode(",", $id_nf).")";
		// 			}else{
		// 				$query .= " and nf.id = $id_nf ";
		// 			}
		// 		}

		// 		if($id_comercial){
		// 			if(is_array($id_comercial)){
		// 				$query .= "and cm.id_comercial in(".implode(",", $id_comercial).")";
		// 				//$query .= " and ( cm.id_vendedor in(".implode(",", $id_comercial).") or cm.id_diretor in(".implode(",", $id_comercial).") )";
		// 			}else{
		// 				$query .= " and cm.id_comercial = $id_comercial ";
		// 				//$query .= " and (cm.id_vendedor = $id_comercial or cm.id_diretor = $id_comercial)";
		// 			}
		// 		}
		// 		if($periodo_ini){
		// 			$query .= " and cm.valida_de >= '$periodo_ini' ";
		// 		}
		// 		if($periodo_fim){
		// 			$query .= " and cm.valida_ate >= '$periodo_fim' ";
		// 		}
		// 		$query .= " order by nf.cliente, nf.recebido_em ";
		// 		return $this->db->exec($query);
		// 	}else{
		// 		return false;
		// 	}
		// }

		// function getComissionadoByContrato($id_contrato, $id_comercial = null, $nome = null, $cargo = null, $status = null){
		// 	$query = "
		// 		select
		// 			cdo.id,
		// 			cdo.nome,
		// 			cdo.cargo,
		// 			cdo.status status_comissionado,
		// 			cm.status status_comissao,
		// 			cm.id id_comissao,
		// 			cm.valida_ate,
		// 			cm.status status_comissao,
		// 			cm.valor_comissao,
		// 			co.id id_contrato,
		// 			co.razao_social,
		// 			co.nome_fantasia,
		// 			co.data_assinatura,
		// 			pr.codigo codigo_produto
		// 		from
		// 			contratos co left join
		// 			comissoes cm on(co.id = cm.id_contrato) left join
		// 			produtos pr on(co.id_produto = pr.id) left join
		// 			comissionados cdo on(cm.id_comercial = cdo.id)
		// 		where
		// 			(cm.deleted is null or cm.deleted = 0) 
		// 	";

		// 	if($id_contrato){
		// 		$query .= " and co.id = $id_contrato ";
		// 	}

		// 	if($id_comercial){
		// 		$query .= " and cm.id_comercial = $id_comercial ";
		// 	}

		// 	if($status){
		// 		$query .= " and cdo.status = '$status' ";
		// 	}

		// 	if($nome){
		// 		$query .= " and cdo.nome like '%$nome%' ";
		// 	}

		// 	if($cargo){
		// 		$query .= " and cdo.cargo like '%$cargo%' ";
		// 	}
		// 	return $this->db->exec($query);
		// }

		// function cancelaComissaoPorNota($id_nf){
		// 	if(is_numeric($id_nf)){
		// 		$query = "
		// 			update faturamento_comissoes set status = 'cancelado', deleted = 1 where id_nf = $id_nf
		// 		";
		// 		return $this->db->exec($query);
		// 	}
		// }

		// function cancelaMultaJurosPorNota($id_nf){
		// 	if(is_numeric($id_nf)){
		// 		$query = "
		// 			update mov_diario_aux set status = 'cancelado', deleted = 1 where id_nf = $id_nf
		// 		";
		// 		return $this->db->exec($query);
		// 	}
		// }
	}