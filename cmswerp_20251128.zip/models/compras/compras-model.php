<?php
class ComprasModel extends MainModel
{
    public function __construct($controller = null)
    {
        parent::__construct($controller);
        $this->setTable('cotacao');
    }

    function listarCotacoes()
    {
        $query = "SELECT cc.*,ca.etapa, su.nome AS solicitante, co.valor
            FROM compras_cotacao cc
            INNER JOIN sistema_usuarios su ON su.id = cc.id_solicitante
            LEFT JOIN compras_aprovacao ca ON ca.id_cotacao = cc.id AND (ca.deleted = 0 OR ca.deleted IS NULL) AND ca.status = 'andamento'
            LEFT JOIN compras_orcamentos co ON co.id_cotacao = cc.id AND co.ganho = 1 AND (co.deleted = 0 OR co.deleted IS NULL)
            WHERE (cc.deleted = 0 OR cc.deleted IS NULL) ORDER BY cc.id DESC;";
        return $this->db->exec($query);
    }

    function obterCotacaoById($id)
    {
        $query = "SELECT
        cc.*,
        su.nome as solicitante,
        cotacao_contratacoes.id AS contratacao_id,
        cotacao_contratacoes.departamento AS departamento_contratacao,
        cotacao_contratacoes.cargo,
        cotacao_contratacoes.forma_contratacao,
        cotacao_contratacoes.tipo_contrato,
        co.valor
            FROM compras_cotacao cc
            INNER JOIN sistema_usuarios su ON su.id = cc.id_solicitante
            LEFT JOIN compras_aprovacao ca ON ca.id_cotacao = cc.id AND (ca.deleted = 0 OR ca.deleted IS NULL)
            LEFT JOIN compras_orcamentos co ON co.id_cotacao = cc.id AND co.ganho = 1 AND (co.deleted = 0 OR co.deleted IS NULL)
            LEFT JOIN cotacao_contratacoes ON cotacao_contratacoes.id_cotacao = cc.id AND (cotacao_contratacoes.deleted = 0 OR cotacao_contratacoes.deleted IS NULL)
            WHERE cc.id = $id AND (cc.deleted = 0 OR cc.deleted IS NULL) ORDER BY cc.id DESC";
        return $this->db->exec($query);
    }

    function abtemAprovadores($tipo, $id_usuario, $id_item)
    {
        $query = "SELECT 
            gu2.id_usuario,
            gu2.tipo_membro,
            gu2.ordem,
            gu2.obrigatorio,
            gs.id AS id_grupo,
            gs.funcao,
            gs.origem,
            gs.id_origem,
            ga.id as aprovacao_id,
            su.nome,
            ga.status,
            ga.justificativa
        FROM grupos_usuarios gu
        INNER JOIN grupos_sistema gs ON gs.id = gu.id_grupo AND (gs.deleted = 0 OR gs.deleted IS NULL)
        INNER JOIN grupos_usuarios gu2 ON gu2.id_grupo = gs.id AND (gu2.deleted = 0 OR gu2.deleted IS NULL)
        LEFT JOIN grupo_aprovacoes ga ON ga.id_grupo = gs.id AND ga.id_usuario = gu2.id_usuario AND ga.id_item = $id_item AND (ga.deleted = 0 OR ga.deleted IS NULL)
        LEFT JOIN sistema_usuarios su ON su.id = gu2.id_usuario AND su.status = 'ativo'
        WHERE gu.id_usuario = $id_usuario
        AND gs.funcao = 'aprovacao'
        AND gs.origem = 'compras'
        AND gs.id_origem = '$tipo'
        AND (gu.deleted = 0 OR gu.deleted IS NULL)
        ORDER BY gu2.ordem";
        return $this->db->exec($query);
    }

    function obterEtapasCotacao($tipo, $id)
    {
        $query = "SELECT ca.*, su.nome
        FROM compras_aprovacao as ca
        INNER JOIN sistema_usuarios su ON su.id = ca.id_usuario_aprovacao
        WHERE id_cotacao = $id AND (deleted = 0 OR deleted IS NULL) ORDER BY ca.id DESC";
        return $this->db->exec($query);
    }
    //remover
    // function obterItemAquisicaoCompras($tipo, $id)
    // {
    //     $query = "SELECT cp.*";
    //     if ($tipo == 'compra') {
    //         $query .= ", fp.id as id_fornecedor_produtos, fp.nome, fp.valor, fp.marca, fp.modelo, f.id as id_empresa, f.nome_fantasia as empresa
    //             FROM cotacao_produtos cp
    //             INNER JOIN fornecedores_produtos fp ON fp.id = cp.id_produto AND (fp.deleted = 0 OR fp.deleted IS NULL)
    //             INNER JOIN fornecedores f ON f.id = cp.id_fornecedor AND (f.deleted = 0 OR f.deleted IS NULL)
    //             ";
    //     }
    //     if ($tipo == 'serviço') {
    //         $query .= " INNER JOIN compras_servico AS cs ON cs.id = id_cotacao_servico AND (cs.deleted = 0 OR cs.deleted IS NULL)";
    //     }
    //     if ($tipo == 'contratação') {
    //         $query .= " WHERE id_cotacao_contratacao = $id AND (deleted = 0 OR deleted IS NULL)";
    //     }

    //     $query .= " WHERE id_cotacao = $id AND (cp.deleted = 0 OR cp.deleted IS NULL)";
    //     return $this->db->exec($query);
    // }

    function obterFornecedores()
    {
        $query = "SELECT * FROM fornecedores WHERE (deleted = 0 OR deleted IS NULL) AND origem = 'externo' ORDER BY razao_social ASC";
        return $this->db->exec($query);
    }

    function obterContratacoes()
    {
        $query = "SELECT * FROM cotacao_contratacoes WHERE (deleted = 0 OR deleted IS NULL) AND origem = 'externo' ORDER BY razao_social ASC";
        return $this->db->exec($query);
    }

    function obtemProdutosByFornecedor($id)
    {
        $query = "SELECT * FROM fornecedores_produtos WHERE id_fornecedor = $id AND (deleted = 0 OR deleted IS NULL) ORDER BY nome ASC";
        return $this->db->exec($query);
    }

    function obtemProdutosByName($nome)
    {
        $query = "SELECT * FROM fornecedores_produtos WHERE nome = $nome AND (deleted = 0 OR deleted IS NULL) ORDER BY nome ASC";
        return $this->db->exec($query);
    }

    function obterDadosOrcamento($id_cotacao, $id_orcamento, $tipo)
    {
        $query = "SELECT ";

        if ($tipo == 'compra') {
            $query .= "  co.id as orcamento_id, cp.id as cotacao_produto_id, f.id as fornecedor_id, cp.quantidade , fp.id as produto_id, fp.nome as nome_produto, fp.marca, fp.modelo, fp.valor 
                    FROM compras_orcamentos co
                    INNER JOIN cotacao_produtos cp ON cp.id_orcamento = co.id AND (cp.deleted = 0 OR cp.deleted IS NULL)
                    INNER JOIN fornecedores_produtos fp ON fp.id = cp.id_produto AND (fp.deleted = 0 OR fp.deleted IS NULL)
                    INNER JOIN fornecedores f ON f.id = co.id_fornecedor  AND (f.deleted = 0 OR f.deleted IS NULL)
                    ";
        }
        if ($tipo == 'serviço') {
            $query .= "  co.id as orcamento_id, f.id as fornecedor_id, cs.descricao, cs.valor, cs.categoria, cs.id as cotacao_servico_id
                    FROM compras_orcamentos co
                    INNER JOIN cotacao_servicos cs ON cs.id_orcamento = co.id AND (cs.deleted = 0 OR cs.deleted IS NULL)
                    INNER JOIN fornecedores f ON f.id = co.id_fornecedor  AND (f.deleted = 0 OR f.deleted IS NULL)
                    ";
        }

        $query .= " WHERE co.id = $id_orcamento AND co.id_cotacao = $id_cotacao AND (co.deleted = 0 OR co.deleted IS NULL)";

        return $this->db->exec($query);
    }

    function obterOrcamentos($tipo, $id_cotacao)
    {
        $query = "SELECT co.* ,f.id as id_empresa, f.nome_fantasia as empresa, co.valor, co.codigo_orcamento
            FROM compras_orcamentos co
            INNER JOIN fornecedores f ON f.id = co.id_fornecedor  AND (f.deleted = 0 OR f.deleted IS NULL)
            WHERE co.id_cotacao  = $id_cotacao AND (co.deleted = 0 OR co.deleted IS NULL) ORDER BY co.id DESC";
        return $this->db->exec($query);
    }

    function obterOrcamentoGanho($id_cotacao)
    {
        $query = "SELECT * FROM compras_orcamentos WHERE id_cotacao = $id_cotacao AND ganho = 1 AND (deleted = 0 OR deleted IS NULL)";
        return $this->db->exec($query);
    }

    function obterDocumentos($id_cotacao)
    {
        $query = "SELECT gd.id, gd.nome_documento, gd.descricao, ga.path_root, ga.path_objeto, ga.data_criacao as data_documento
            FROM ged_documento gd
            INNER JOIN ged_anexo ga ON ga.id_documento = gd.id AND (ga.deleted = 0 OR ga.deleted IS NULL)
            WHERE id_origem = $id_cotacao AND gd.doc_origem ='cotação' AND gd.tipo ='cotação' AND (gd.deleted = 0 OR gd.deleted IS NULL)
            ORDER BY gd.id DESC";
        return $this->db->exec($query);
    }
    function obterPathDocumentById($id_documento)
    {
        $query = "SELECT ga.path_root, ga.path_objeto, gd.nome_documento
            FROM ged_documento gd
            INNER JOIN ged_anexo ga ON ga.id_documento = gd.id AND (ga.deleted = 0 OR ga.deleted IS NULL)
            WHERE gd.id = $id_documento AND gd.doc_origem ='cotação' AND gd.tipo ='cotação' AND (gd.deleted = 0 OR gd.deleted IS NULL)";
        return $this->db->exec($query);
    }

}