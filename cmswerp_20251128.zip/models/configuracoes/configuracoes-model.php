<?php
	/**
	 * Created by PhpStorm.
	 * User: julio.gomes
	 * Date: 14/10/2016
	 * Time: 15:57
	 */
	class ConfiguracoesModel extends MainModel{
		//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
		public function __construct( $controller = null ){
			parent::__construct($controller);
			$this->setTable('configuracoes');
		}

		function getConfiguracoes( $id = null,$grupo = null ){
			$query = "select * from configuracoes where (deleted is null or deleted = 0) ";
			if($id && is_numeric($id)){
				$query .= " and id = $id ";
			}
			if($grupo){
				$query .= " and grupo = '$grupo'";	
			}
			$query .= " order by id asc";
			return $this->db->exec($query);
		}

		// descontinuar esse metodo
		function getFluxo( $id_usuario = null, $objeto = null, $id_fluxo = null, $group = false, $order_by = false){
			$query = "
				SELECT
					fo.*, 
					ut.nome
				FROM
					fluxo_ordem_aprovacao fo
				INNER JOIN
					sistema_usuarios ut
				ON
					(ut.id = fo.id_usuario)
				WHERE
					(fo.deleted is null or fo.deleted = 0)
			";

			if($id_usuario){
				$query .= " and fo.id_usuario = $id_usuario";
			}

			if($objeto){
				$query .= " and fo.objeto = '$objeto'";
			}

			if($id_fluxo){
				$query .= " and fo.id = '$id_fluxo'";
			}

			if($group == true){
				$query .= " GROUP BY fo.objeto";
			}

			if($order_by == true){
				$query .= " ORDER BY fo.ordem DESC";
			}else{
				$query .= " ORDER BY fo.ordem ASC";
			}
			return $this->db->exec( $query );
		}

		function getAllFluxoConjunto(){
			$query = "
				SELECT 
					fo.objeto, 
					ev.id id_empresa, 
					ev.razao_social nome_empresa 
				FROM 
					fluxo_ordem_aprovacao fo INNER JOIN
					sistema_usuarios ut ON ( ut.id = fo.id_usuario ) INNER join
					empresa_vendedora ev ON( fo.id_empresa = ev.id )
				WHERE 
					(fo.deleted is null or fo.deleted = 0)
				GROUP BY 
					fo.objeto, 
					ev.id, 
					ev.razao_social
			";
			return $this->db->exec( $query );
		}

		function getAprovacoesPorEmpresa( $id_empresa, $objeto ){
			$query = "
				SELECT 
					foa.*, 
					ut.id id_usuario,
					ut.nome nome_usuario,
					ev.razao_social
				FROM 
					fluxo_ordem_aprovacao foa INNER JOIN
					sistema_usuarios ut ON ( ut.id = foa.id_usuario ) INNER join
					empresa_vendedora ev ON( foa.id_empresa = ev.id )
				WHERE 
					(foa.deleted is null or foa.deleted = 0)
			";

			if( $id_empresa ){
				$query .= " and foa.id_empresa = $id_empresa ";
			}

			if( $objeto ){
				$query .= " and foa.objeto = '$objeto' ";
			}
			$query .= " ORDER BY foa.id_empresa, foa.objeto, foa.ordem ";
			return $this->db->exec( $query );
		}

		function getFluxoByEmpresaEUser( $id_empresa, $id_usuario, $objeto ){
			$query = "
				SELECT 
					fo.*, 
					ut.nome ,
					ev.id id_empresa,
					ev.razao_social nome_empresa
				FROM 
					fluxo_ordem_aprovacao fo INNER JOIN
					sistema_usuarios ut ON ( ut.id = fo.id_usuario ) INNER join
					empresa_vendedora ev ON( fo.id_empresa = ev.id )
				WHERE 
					(fo.deleted is null or fo.deleted = 0)
			";

			if($id_usuario){
				$query .= " and fo.id_usuario = $id_usuario";
			}

			if($objeto){
				$query .= " and fo.objeto = '$objeto'";
			}

			if($id_empresa){
				$query .= " and fo.id_empresa = '$id_empresa'";
			}
			
			return $this->db->exec( $query );
		}

		function getEmpresas( $id = null, $empresa_vendedora = false ){
			$query .= "
				SELECT 
					*
				FROM 
					empresa_vendedora
				WHERE
					(deleted = null OR deleted = 0)
			";

			if($id){
				$query .= " and id = $id";
			}

			if($empresa_vendedora === true){
				$query .= " and empresa_vendedora = '0'";
			}		

			$query .= " order by id desc";
			return $this->db->exec($query);
		}
		
		function getAlertas($usuario = null, $objeto = null){
			$query = "
			SELECT
				a.*,
				ut.nome,
				ut.email,
				ut.cargo,
				ut.departamento
			FROM
				alertas a
			INNER JOIN
				sistema_usuarios ut
			ON
				(a.id_usuario = ut.id)
			WHERE
				(a.deleted = 0 OR a.deleted is NULL)";

			if($usuario){
				$query .= " and a.id_usuario = $usuario";
			}

			if($objeto){
				$query .= " and a.objeto = '$objeto'";
			}		

			$query .= " ORDER BY id DESC";
			return $this->db->exec($query);
		}
	}
