<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class ContaBancariaModel extends MainModel{
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	public function __construct( $controller = null ){
		$this->setTable('conta_bancaria');	
		parent::__construct($controller);
	}

	// funcoes abaixo a serem revisadas ou substituidas
	//verificar função abaixo provavel erro
	function getConta($id = null, $deleted = false){
		$query = "
			select 
			tb1.*,
			tb2.nome_reduzido,
			tb2.nome_extenso,
			tb2.codigo_banco,
			tb2.ispb_banco,
			tb2.status status_banco,
			tb3.razao_social, 
			tb3.cnpj cnpj_cm, 
			tb3.id id_cm,
			tb3.endereco,
			tb3.numero,
			tb3.complemento,
			tb3.bairro,
			tb3.cep,
			tb3.cidade,
			tb3.estado,
			tb3.status
			from ".$this->getTable()." tb1 inner join banco tb2 on(tb1.id_banco = tb2.id) inner join empresa_vendedora tb3 on(tb1.id_empresa = tb3.id) where tb1.status = 'a' ";
		if(!$deleted){
			$query .= " and (tb1.deleted is null or tb1.deleted = 0) ";
		}

		if($id){
			$query .= " and tb1.id = $id ";
		}
		$query .= " order by tb2.nome_reduzido ";
		return $this->db->exec($query);
	}

	function getContaBancariaByAgencia($agencia = null, $conta = null){
		$query = "
			select tb1.*, tb2.razao_social from ".$this->getTable()." tb1 inner join banco tb2 on(tb1.id_banco = tb2.id) inner join empresa_vendedora tb3 on(tb1.id_empresa = tb3.id) where (tb1.deleted = 0 or tb1.deleted is null)";
		if($agencia){
			$query .= " and numero_agencia = $agencia ";
		}

		if($conta){
			$query .= " and numero_conta = $conta ";
		}
		return $this->db->exec($query);
	}

	function getContaBancariaByOrigem($origem, $id = null){
		$query = "
			select 
			tb1.*,
			tb2.razao_social, 
			tb2.cnpj cnpj_cm, 
			tb2.id id_cm,
			tb2.endereco,
			tb2.numero,
			tb2.complemento,
			tb2.bairro,
			tb2.cep,
			tb2.cidade,
			tb2.estado,
			tb2.status
			from ".$this->getTable()." tb1 inner join banco tb2 on(tb1.id_banco = tb2.id) inner join empresa_vendedora tb3 on(tb1.id_empresa = tb3.id) where tb1.status = 'ativo' 
		";

		if($origem){
			$query .= " and tb1.origem_conta = '$origem' ";
		}

		if($id){
			$query .= " and tb1.id = $id ";
		}
		$query .= " order by tb1.nome_banco ";
		return $this->db->exec($query);		
	}

	function getContaBancariaDefault($id_empresa, $origem_conta){
		$query = "
			select 
			tb1.*,
			tb2.nome_reduzido,
			tb2.nome_extenso,
			tb2.codigo_banco,
			tb2.ispb_banco
			from 
				".$this->getTable()." tb1 inner join 
				banco tb2 on(tb1.id_banco = tb2.id) ";
			if($origem_conta == 'despesa'){
				$query.= " inner join despesas tb3 on(tb1.id_empresa = tb3.id)";
			}elseif($origem_conta == 'empresa_cm'){
				$query.= " inner join empresa_vendedora tb3 on(tb1.id_empresa = tb3.id)";
			}else{
				$query.= " inner join fornecedores tb3 on(tb1.id_empresa = tb3.id)";
			}	
		$query .= "
			where 
				(tb1.deleted is null or tb1.deleted = 0) and 
				tb1.status = 'a' and 
				tb1.conta_default = 1
		";

		if($id_empresa){
			$query .= " and tb1.id_empresa = $id_empresa ";
		}

		if($origem_conta){
			$query .= " and tb1.origem_conta = '$origem_conta' ";
		}

		$query .= " order by tb2.nome_reduzido ";
		return $this->db->exec($query);
	}

	function getContaBancariaByFornecedor($id_fornecedor, $id_banco, $default = null){
		$query = "
			select 
			tb1.*,
			tb2.nome_reduzido,
			tb2.nome_extenso,
			tb2.codigo_banco,
			tb2.ispb_banco
			from ".$this->getTable()." tb1 inner join banco tb2 on(tb1.id_banco = tb2.id) inner join fornecedores tb3 on(tb1.id_empresa = tb3.id) where (tb1.deleted is null or tb1.deleted = 0) and tb1.status = 'a' and origem_conta = 'fornecedor'";

		if($id_fornecedor){
			$query .= " and tb1.id_empresa = $id_fornecedor ";
		}

		if($id_banco){
			$query .= " and tb1.id_banco = $id_banco ";
		}

		if($default){
			$query .= " and tb1.conta_default = 1 ";
		}
		$query .= " order by tb2.nome_reduzido ";
		return $this->db->exec($query);
	}

	function getContaBancarias($id = null){
		$query = "select * from ".$this->getTable()." tb1 inner join banco tb2 on(tb1.id_banco = tb2.id ) where (tb1.deleted is null or tb1.deleted = 0 ) and tb1.status = 'a' ";
		if($id){
			$query .= " and tb1.id = $id ";
		}
		$query .= " order by tb2.nome_reduzido ";
		return $this->db->exec($query);;
	}

	function getContaBancariaConvenio($id = null){
		$query = "
			SELECT 
				tb1.*,
				tb2.ispb_banco,
				tb2.nome_reduzido,
				tb2.codigo_banco,
				tb2.participa_compe,
				tb2.acesso_principal,
				tb2.nome_extenso,
				tb2.inicio_operacao
			FROM 
				".$this->getTable()." tb1 INNER JOIN 
				banco tb2 ON(tb1.id_banco = tb2.id) 
			WHERE
				(tb1.deleted IS NULL OR tb1.deleted = 0) AND  
				tb1.STATUS = 'a' AND 
				tb1.origem_conta = 'empresa_cm' AND 
				(
					tb1.codigo_convenio_cnab400 IS NOT NULL OR 
					tb1.codigo_convenio_cnab240 IS NOT NULL
				);
		";
		$query .= " order by tb2.nome_reduzido ";
		return $this->db->exec($query);
	}

	function getContaByEmpresa($id_empresa, $id_banco = null, $default = null){
		$query = "
			select 
				tb1.*,
				tb2.nome_reduzido,
				tb2.nome_extenso,
				tb2.codigo_banco,
				tb2.ispb_banco
			from 
				".$this->getTable()." tb1 inner join 
				banco tb2 on(tb1.id_banco = tb2.id) inner join 
				empresa_vendedora tb3 on(tb1.id_empresa = tb3.id) 
			where 
				(tb1.deleted is null or tb1.deleted = 0) and 
				tb1.status = 'a' and origem_conta = 'empresa_cm'
		";

		if($id_empresa){
			$query .= " and tb1.id_empresa = $id_empresa ";
		}

		if($id_banco){
			$query .= " and tb1.id_banco = $id_banco ";
		}

		if($default){
			$query .= " and tb1.conta_default = 1 ";
		}

		$query .= " order by tb1.conta_default desc, tb2.nome_reduzido ";
		return $this->db->exec($query);
	}

	function getContaByIdConta($id_conta, $id_banco = null, $default = null){
		$query = "
			select 
			tb1.*,
			tb2.nome_reduzido,
			tb2.nome_extenso,
			tb2.codigo_banco,
			tb2.ispb_banco
			from ".$this->getTable()." tb1 inner join banco tb2 on(tb1.id_banco = tb2.id) inner join empresa_vendedora tb3 on(tb1.id_empresa = tb3.id) where (tb1.deleted is null or tb1.deleted = 0) and  tb1.status = 'a' and origem_conta = 'empresa_cm'";

		if($id_conta){
			$query .= " and tb1.id = $id_conta ";
		}

		if($id_banco){
			$query .= " and tb1.id_banco = $id_banco ";
		}

		if($default){
			$query .= " and tb1.conta_default = 1 ";
		}

		$query .= " order by tb1.conta_default desc, tb2.nome_reduzido ";
		return $this->db->exec($query);
	}

	
	function getContaByDespesa($id_despesa, $id_banco = null, $default = null){
		$query = "
			select 
			tb1.*,
			tb2.nome_reduzido,
			tb2.nome_extenso,
			tb2.codigo_banco,
			tb2.ispb_banco
			from ".$this->getTable()." tb1 inner join banco tb2 on(tb1.id_banco = tb2.id) inner join despesas tb3 on(tb1.id_empresa = tb3.id) where (tb1.deleted is null or tb1.deleted = 0) and  tb1.status = 'a' and origem_conta = 'despesa'";

		if($id_despesa){
			$query .= " and tb1.id_empresa = $id_despesa ";
		}

		if($id_banco){
			$query .= " and tb1.id_banco = $id_banco ";
		}

		if($default){
			$query .= " and tb1.conta_default = 1 ";
		}

		$query .= " order by tb1.conta_default desc, tb2.nome_reduzido ";
		return $this->db->exec($query);
	}

	function getContaByFornecedor($id_fornecedor, $id_banco = null, $default = null){
		$query = "
			select 
				tb1.*,
				tb2.nome_reduzido,
				tb2.nome_extenso,
				tb2.codigo_banco,
				tb2.ispb_banco
			from 
				".$this->getTable()." tb1 inner join 
				banco tb2 on(tb1.id_banco = tb2.id) inner join 
				fornecedores tb3 on(tb1.id_empresa = tb3.id) 
			where 
				(tb1.deleted is null or tb1.deleted = 0) and 
				tb1.status = 'a' and 
				origem_conta in ('fornecedor', 'despesa')";

		if($id_fornecedor){
			$query .= " and tb1.id_empresa = $id_fornecedor ";
		}

		if($id_banco){
			$query .= " and tb1.id_banco = $id_banco ";
		}

		if($default){
			$query .= " and tb1.conta_default = 1 ";
		}
		$query .= " order by tb1.conta_default desc, tb2.nome_reduzido ";
		return $this->db->exec($query);
	}

	function getContaConvenio($id = null){
		$query = "
			SELECT 
				tb1.*,
				tb2.ispb_banco,
				tb2.nome_reduzido,
				tb2.codigo_banco,
				tb2.participa_compe,
				tb2.acesso_principal,
				tb2.nome_extenso,
				tb2.inicio_operacao
			FROM 
				".$this->getTable()." tb1 INNER JOIN 
				banco tb2 ON(tb1.id_banco = tb2.id) 
			WHERE
				(tb1.deleted IS NULL OR tb1.deleted = 0) AND  
				tb1.STATUS = 'a' AND 
				tb1.origem_conta = 'empresa_cm' AND 
				(
					tb1.codigo_convenio_cnab400 IS NOT NULL OR 
					tb1.codigo_convenio_cnab240 IS NOT NULL
				);
		";
		$query .= " order by tb2.nome_reduzido ";
		return $this->db->exec($query);
	}

}
