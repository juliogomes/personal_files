<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class ContratosModel extends MainModel
{
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	public function __construct($controller = null)
	{
		$this->setTable('contratos');
		parent::__construct($controller);
	}

	function getUltimoCodigoContrato($codigo_contrato)
	{
		$query = " SELECT * FROM contratos con  WHERE  con.codigo_contrato = ? ";
		return $this->db->exec($query, [$codigo_contrato]);
	}

	function get($id = null, $codigo_cliente = null)
	{
		$query = " select *	from $this->table co where 1=1 ";

		if ($id) {
			$query .= " and co.id = '$id' ";
		}

		if ($codigo_cliente) {
			$query .= " and co.codigo_cliente = '$codigo_cliente' ";
		}
		return $this->db->exec($query);
	}

	function getTodosContratosEModulos($id_contrato = null)
	{
		$query = "
    			select
    				co.id id_contrato,
    				co.status,
    				co.codigo_cliente,
    				co.nome_fantasia,
    				pr.id id_produto,
    				pr.codigo codigo_produto,
    				mt.id id_modulo,
    				mt.codigo codigo_modulo,
    				mt.empacotavel,
    				mt.tipo_cobranca
    				from
    				contratos co left join
    				produtos pr on(pr.id = co.id_produto ) left join
    				modulos_tarifaveis mt on(mt.id_produto = pr.id )
    			where
    				(co.deleted = '0' or co.deleted is null) and
                    (mt.deleted = '0' or mt.deleted is null)
    			";
		if ($id_contrato) {
			$query .= " and co.id = $id_contrato ";
		}
		$exec = $this->db->query($query);
		if ($exec) {
			// Retorna
			$return = $exec->fetchAll();
			return json_encode($return);
		} else {
			return false;
		}
	}

	function getAllContratos($ativo = false)
	{
		$query = "
				select 
					co.*,
					pr.nome nome_produto, 
					pr.codigo codigo_produto	
				from 
					$this->table co inner join
					produtos pr on(co.id_produto = pr.id)
				where 
					( co.deleted = 0 and co.deleted IS NOT null ) 
			";
		if ($ativo) {
			$query .= " and co.status = 'ativo' ";
		}
		return $this->db->exec($query);
	}

	// funcoes abaixo a serem revisadas ou substituidas
	function customGetRecordsAtivos($id_contrato = null)
	{
		$where = null;
		$produtos = array('SPB0001', 'COB0001', 'RCK0001', 'GCK0001', 'ADM0001');
		$query = "
				SELECT distinct
					co.id id_contrato,
					co.numero_contrato,
					co.id_empresa empresa_vendedora,
					ev.razao_social razao_social_cm,
					co.`status`,
					co.razao_social,
					co.nome_fantasia,
					co.codigo_cliente,
					pr.id id_produto,
					pr.nome nome_produto,
					pr.codigo codigo_produto,
					mt.id id_modulo,
					mt.codigo codigo_modulo,
					mt.descricao nome_modulo,
					co.data_corte_faturamento,
					co.numero_dias_apos_corte,
					coa.tipo_indice
					FROM
					contratos co 
					inner join
					empresa_vendedora ev on(ev.id = co.id_empresa)
					LEFT JOIN
					contrato_aniversario coa ON(co.id = coa.id_contrato)
					LEFT JOIN
					indices_reajuste ir ON(coa.id_indice = ir.id)
					LEFT JOIN
					produtos pr ON(co.id_produto = pr.id)
					LEFT JOIN
					pacote_contratado pc ON(pc.id_contrato = co.id)
					LEFT JOIN
					comissoes com on(com.id_contrato = co.id)
					LEFT JOIN
					modulos_tarifaveis mt on(mt.id_produto = pr.id)
				WHERE
					co.`status` = 'ativo'  and
					co.codigo_cliente != '33333333' and
					(co.deleted = '0' or co.deleted is null)
			";

		if (!$id_contrato) {
			if ($produtos) {
				if (count($produtos) > 1) {
					$where .= ' and ( ';
					foreach ($produtos as $key => $value) {
						if ($key == end(array_keys($produtos))) {
							$where .= " pr.codigo = '$value' ";
						} else {
							$where .= " pr.codigo = '$value' or ";
						}
					}
					$where .= ' ) ';
				} else {
					$where .= " and pr.codigo = '$codigo_produto[0]' ";
				}
				$query .= $where;
			}
		} else {
			$query .= " and co.id = $id_contrato ";
		}
		$query .= ' order by co.nome_fantasia, pr.codigo, mt.codigo; ';
		$exec = $this->db->query($query);
		if ($exec) {
			// Retorna
			$return = $exec->fetchAll();
			return json_encode($return);
		} else {
			return false;
		}
	}

	function getListaPrecoAno($id_contrato, $ano, $json = false)
	{
		$query = "select id from lp_clientes lpc where lpc.id_contrato = '$id_contrato' and lpc.ano_reajuste = '$ano' and `status` = 'ativo';";

		$exec = $this->db->query($query);
		if ($exec) {
			// Retorna
			if ($json) {
				$result = $exec->fetchAll();
				return json_encode($result);
			} else {
				return $result = $exec->fetchAll();
			}
		} else {
			return false;
		}
	}

	function getComercial($id_contrato)
	{
		$query = "
				select
					*
				from
					comissoes co inner join
					vendedores ven on(co.id_comercial = ven.id)
				where
					co.id_contrato = $id_contrato;
			";
		$exec = $this->db->query($query);
		if ($exec) {
			// Retorna
			$return = $exec->fetchAll();
			return json_encode($return);
		} else {
			return false;
		}
	}

	function getModulo($id, $codigo)
	{
		$query = " select * from modulos_tarifaveis mt where (deleted is null or deleted = 0) ";
		if ($id) {
			$param[] = $id;
			$query .= " and id = ? ";
		}
		if ($codigo) {
			$param[] = $codigo;
			$query .= " and codigo = ? ";
		}
		return $this->db->exec($query, $param);
	}

	function getModulesByProduto($id_produto, $json = false)
	{
		$query = "
			select distinct
			pro.id id_produto,
			pro.codigo codigo_produto,
			pro.nome nome_produto,
			mt.id modulo_id,
			mt.codigo modulo_codigo,
			mt.descricao,
			mt.empacotavel,
			mt.tipo_cobranca
			from
			produtos pro left join
			modulos_tarifaveis mt on(mt.id_produto = pro.id)
			where allow_lp_default= 1
			";
		if (!empty($id_produto)) {
			$query .= " and pro.status = 'ativo' and mt.status = 'ativo' and pro.id = $id_produto order by pro.nome, mt.codigo ";
		}
		//$query;
		// return false;
		$exec = $this->db->query($query);
		if ($exec) {
			if ($json) {
				$result = $exec->fetchAll();
				return json_encode($result);
			} else {
				return $result = $exec->fetchAll();
			}
		} else {
			return false;
		}
	}

	function getListaClienteResume($id_contrato, $id_produto = null, $id_modulo = null, $json = false)
	{
		$query = "
				select
					id_contrato,
					id_produto,
					id_modulo
				from
					lp_clientes lpc
				where
					`status` = 'ativo' and
					lpc.id_contrato = '$id_contrato'
				";

		if ($id_produto) {
			$query .= " and lpc.id_produto = '$id_produto' ";
		}

		if ($id_modulo) {
			$query .= " and lpc.id_modulo = '$id_modulo' ";
		}

		$query .= " group by id_contrato, id_produto, id_modulo; ";
		$exec = $this->db->query($query);
		if ($exec) {
			// Retorna
			if ($json) {
				$result = $exec->fetchAll();
				return json_encode($result);
			} else {
				return $result = $exec->fetchAll();
			}
		} else {
			return false;
		}
	}

	function getListaPrecosDefaultResume($table_name, $id_modulo, $fields, $groupby)
	{
		$query = "
				select $fields from $table_name where id_modulos_tarifaveis = $id_modulo $groupby
			";
		$exec = $this->db->query($query, array($id_modulo));
		if ($exec) {
			$result = $exec->fetchAll();
			if (count($result) > 0) {
				return $result;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	function getCustomListaPreco($id_contrato, $id_modulo = null, $where = null, $json = false)
	{
		if (!$where) {
			if ($id_modulo) {
				$query = "select * from lp_clientes lpc where `status` = 'ativo' and lpc.id_contrato = '$id_contrato' and lpc.id_modulo = '$id_modulo';";
			} else {
				$query = "select * from lp_clientes lpc where `status` = 'ativo' and lpc.id_contrato = '$id_contrato';";
			}
		} else {
			$query = "
					select * from lp_clientes lpc where `status` = 'ativo' and lpc.id_contrato = '$id_contrato' and lpc.id_modulo = '$id_modulo' and  $where;";
		}
		$exec = $this->db->query($query);
		if ($exec) {
			// Retorna
			if ($json) {
				$result = $exec->fetchAll();
				return json_encode($result);
			} else {
				return $result = $exec->fetchAll();
			}
		} else {
			return false;
		}
	}

	function getJustContratos($id_contrato = null, $indice = null, $mes_reajuste = null)
	{
		$query = " 
				select 
					con.id id_contrato,
					con.*, 
					MONTH(con.data_reajuste) mes_reajuste,
					pr.codigo codigo_produto, 
					pr.nome nome_produto,
					con.data_assinatura,
					con.data_reajuste,
					con.indice_reajuste
				from 
					contratos con inner join 
					produtos pr on(pr.id = con.id_produto) 
				where  
					con.status = 'ativo' and 
					(con.deleted = 0 or con.deleted is null)
			";

		if ($indice) {
			$query .= " and indice_reajuste = '$indice' ";
		}

		if ($mes_reajuste) {
			$query .= " and MONTH(con.data_reajuste) = $mes_reajuste ";
		}

		if ($id_contrato) {
			$query .= " and con.id in( $id_contrato )";
		}

		$query .= " order by con.razao_social ";
		return $this->db->exec($query);
	}

	// funcoes acima a serem revisadas ou substituidas
	///
	///	Metodos abaixo usados na tarifação cuidado ao mexer!!!!
	///

	function getContratosAndProdutos($codigo_cliente, $codigo_produto = null, $ativo = false)
	{
		$query = "
				select
				co.id id_contrato,
				co.cnpj,
				co.nome_fantasia,
				co.razao_social,
				co.endereco,
				co.complemento,
				co.numero,
				co.bairro,
				co.cep,
				co.cidade,
				co.estado,
				co.status,
				co.nome_representante,
				co.cpf_representante,
				co.email_representante,
				co.telefone_representante,
				co.codigo_cliente,
				co.id_empresa,
				pr.id id_produto,
				co.data_corte_faturamento,
				pr.codigo codigo_produto
				from contratos co, produtos pr
				where
				co.codigo_cliente = '$codigo_cliente' and
				pr.id = co.id_produto
			";

		if ($ativo) {
			$query .= " and co.status = 'ativo' ";
		}

		if (is_array($codigo_produto)) {
			$query .= " and pr.codigo in('" . implode("','", $codigo_produto) . "') ";
		} elseif ($codigo_produto) {
			$query .= " and pr.codigo = '$codigo_produto'";
		}
		return $this->db->exec($query);
	}

	function getContratosAndProdutosAndModulos($cod_cliente, $cod_produto = null, $cod_modulo = null, $codigo_pais = null)
	{
		$query = "
			select
				co.id id_contrato,
				co.status,
				co.codigo_cliente,
				co.nome_fantasia,
				pr.id id_produto,
				pr.codigo codigo_produto,
				mt.id id_modulo,
				mt.codigo codigo_modulo,
				mt.empacotavel,
				mt.tipo_cobranca
				from
				contratos co left join
				produtos pr on(pr.id = co.id_produto ) left join
				modulos_tarifaveis mt on(mt.id_produto = pr.id )
			where
				(co.deleted = '0' or co.deleted is null) and
                (mt.deleted = '0' or mt.deleted is null)
			";
		if ($cod_cliente) {
			$query .= " and co.codigo_cliente = '$cod_cliente' ";
		}

		if ($cod_produto) {
			$query .= " and pr.codigo = '$cod_produto' ";
		}

		if ($cod_modulo) {
			$query .= " and mt.codigo = '$cod_modulo' ";
		}

		if ($codigo_pais) {
			$query .= " and co.codigo_pais= '$codigo_pais' ";
		}

		$exec = $this->db->query($query);
		if ($exec) {
			// Retorna
			$return = $exec->fetchAll();
			return json_encode($return);
		} else {
			return false;
		}
	}

	function getContratosPorProdutos($id_produto, $codigo_cliente = null)
	{
		$query = " select *	from contratos co where (co.deleted is null or co.deleted = 0) and co.`status` = 'ativo' and co.id_produto = '$id_produto' ";
		if ($codigo_cliente) {
			$query .= " and co.codigo_cliente = '$codigo_cliente' ";
		}
		$exec = $this->db->query($query);
		if ($exec) {
			// Retorna
			$return = $exec->fetchAll();
			return json_encode($return);
		} else {
			return false;
		}
	}

	///
	///	Metodos acima usados na tarifação cuidado ao mexer!!!!
	///

	//funcoes novas para atualização de versão
	function getContratosPorCodigoProduto($codigo_produto)
	{
		$query = " 
				select
					co.*,
					pr.codigo codigo_produto,
					pr.nome nome_produto 
				from 
					contratos co inner join 
					produtos pr on(co.id_produto = pr.id)
				where 
					(co.deleted is null or co.deleted = 0) and 
					co.`status` = 'ativo' and 
					pr.codigo = '$codigo_produto' 
			";
		return $this->db->exec($query);
	}

	function getContratosPorParamentro($id_contrato = null, $empresa_cm = null, $cliente = null, $produto = null, $dt_corte_ini = null, $dt_corte_fim = null, $ignore_adm = false)
	{
		$query = "
				select
					co.id id_contrato,
					co.codigo_cliente,
					co.razao_social razao_social,
					co.nome_fantasia,
					co.data_corte_faturamento,
					co.data_assinatura,
					co.numero_dias_apos_corte,
					co.status status_contrato,
					co.taxa_inatividade,
					co.prazo_inatividade,
					co.data_primeiro_faturamento,
					co.isento_de,
					co.isento_ate,
					co.carencia_de_uso,
					co.nf_automatica,
					ev.id id_empresa,
					ev.razao_social razao_social_cm,
					pr.id id_produto,
					pr.codigo codigo_produto,
					pr.nome nome_produto
				from
					contratos co inner JOIN
					produtos pr on(pr.id = co.id_produto) inner JOIN
					empresa_vendedora ev on(ev.id = co.id_empresa)
				WHERE
					(co.deleted = 0 or co.deleted is null) and
					co.status = 'ativo' AND
					pr.status = 'ativo'
			";

		if ($id_contrato) {
			$query .= " and co.id = $id_contrato";
		}

		if ($empresa_cm) {
			$query .= " and (ev.nome_fantasia like '%$empresa_cm%' or ev.razao_social like '%$empresa_cm%') ";
		}

		if ($cliente) {
			$query .= " and (co.nome_fantasia like '%$cliente%' or co.razao_social like '%$cliente%') ";
		}

		if ($produto) {
			$query .= " and pr.nome like '%$produto%' ";
		}

		if ($dt_corte_ini) {
			$query .= " and co.data_corte_faturamento >= $dt_corte_ini";
		}

		if ($dt_corte_fim) {
			$query .= " and co.data_corte_faturamento <= $dt_corte_fim";
		}

		if ($ignore_adm) {
			$query .= " and pr.codigo != 'ADM0001' ";
		}
		return $this->db->exec($query);
	}

	//essa funcao ira ser substituida por a nova no fim do arquivo  chamada getPacotesPorContrato
	function getPacotesByContrato($id_contrato, $id_modulo = null, $json = false)
	{
		$query = "  select distinct * from 	pacote_contratado where status = 'ativo' and id_contrato = $id_contrato ";
		if (!empty($id_modulo)) {
			$query .= " and  id_modulos_tarifaveis = $id_modulo ";
		}
		return $this->db->exec($query);
	}

	function getPacotesPorContrato($id_contrato, $codigo_modulo = null)
	{
		$query = "
				select
					co.razao_social,
					co.nome_fantasia,
					pc.id,
					pc.id_modulos_tarifaveis,
					pc.id_contrato,
					pc.preco_pkt,
					pc.qdt_garantido,
					pc.ultimo_reajuste,
					pc.status status_pacote,
					pc.flag,
					ev.id id_empresa,
					ev.razao_social,
					mt.id id_modulo,
					mt.codigo codigo_modulo,
					mt.descricao nome_modulo,
					mt.tipo_cobranca,
					pr.id id_produto,
					pr.codigo codigo_produto,
					pr.nome nome_produto
				from
					contratos co inner JOIN
					produtos pr on(pr.id = co.id_produto) inner JOIN
					modulos_tarifaveis mt on (mt.id_produto = pr.id) inner JOIN
					pacote_contratado pc on(pc.id_contrato = co.id and mt.id = pc.id_modulos_tarifaveis) inner join
					empresa_vendedora ev on(ev.id = co.id_empresa)
				WHERE
					(co.deleted = 0 or co.deleted is null) and
					(pc.deleted = 0 or pc.deleted is null) and
					pc.status = 'ativo' and
					co.status = 'ativo' AND
					pr.status = 'ativo' and
					co.id = $id_contrato
			";

		if ($codigo_modulo) {
			$query .= " and mt.codigo = '$codigo_modulo' ";
		}
		return $this->db->exec($query);
	}

	function getEmpresasCM($id_empresa = null, $cnpj = null)
	{
		$query = "
				select
					*
				from
					empresa_vendedora ev
				where
					ev.status = 'ativo'
			";

		if ($id_empresa) {
			$query .= " and ev.id = $id_empresa";
		}

		if ($cnpj) {
			$query .= " and ev.cnpj = $cnpj";
		}
		return $this->db->exec($query);
	}

	function getContratosPorEmpresa($cnpj_cm = null, $id_empresa = null, $include_adm = true)
	{
		$query = "
				select
					con.*,
					con.id id_contrato,
					con.status status_contrato,
					pr.nome nome_produto,
					pr.codigo codigo_produto,
					ev.razao_social razao_social_cm,
					ev.cnpj cnpj_cm,
					ev.endereco endereco_cm,
					ev.numero numero_cm,
					ev.complemento complemento_cm,
					ev.bairro bairro_cm,
					ev.cidade cidade_cm,
					ev.estado estado_cm,
					ev.cep cep_cm,
					ev.inscricao_estadual inscricao_estadual_cm,
					ev.inscricao_municipal inscricao_municipal_cm,
					MONTH(con.data_assinatura) mes_reajuste,
					con.indice_reajuste tipo_indice
				from
					contratos con LEFT JOIN
					produtos pr ON(con.id_produto = pr.id) LEFT JOIN
					empresa_vendedora ev on(ev.id = con.id_empresa)
				where
					(con.deleted = 0 or con.deleted is null) and
					con.codigo_cliente != '99999999' and
					con.status = 'ativo'
			";

		if ($cnpj_cm) {
			$query .= " and ev.cnpj = $cnpj_cm";
		}

		if (!$include_adm) {
			$query .= " and pr.codigo != 'ADM0001' ";
		}

		if ($id_empresa) {
			$query .= " and ev.id = $id_empresa";
		}
		$query .= " order by razao_social asc ";
		return $this->db->exec($query);
	}

	function getContratosByPagamento($meio_pagamento, $id_banco = null, $codigo_produto = null, $dia_corte)
	{
		$query = "
				SELECT 
					con.*,
					con.id id_contrato,
					pr.nome nome_produto,
					pr.codigo codigo_produto
				FROM 
					contratos con INNER join
					banco ban ON(ban.id = con.id_banco) INNER join
					empresa_vendedora ev ON(ev.id = ban.id_empresa) inner join
					produtos pr on(pr.id = con.id_produto)
				WHERE 
					(con.deleted = 0 OR con.deleted IS null) and 
					con.status = 'ativo'
			";
		if ($meio_pagamento) {
			$query .= " and con.meio_pagamento = '$meio_pagamento'";
		}

		if ($id_banco) {
			$query .= " and con.id_banco = $id_banco ";
		}

		if ($codigo_produto) {
			$query .= " and pr.codigo = '$codigo_produto' ";
		}

		if ($dia_corte) {
			$query .= " and con.data_corte_faturamento = $dia_corte ";
		}

		return $this->db->exec($query);
	}

	function getContratosPorAnoAssinatura($ano_assinatura)
	{
		if (isset($ano_assinatura) && !empty($ano_assinatura) && is_numeric($ano_assinatura)) {
			$query = "select id id_contrato, razao_social, nome_fantasia, data_assinatura from contratos where (deleted is null or deleted = 0) and data_assinatura >= '$ano_assinatura-01-01' and data_assinatura <= '$ano_assinatura-12-31'";
			return $this->db->exec($query);
		} else {
			return false;
		}
	}

	function contratosAtivos($id_contrato = null, $ativos = true, $adm = false)
	{
		$query = "
				select
					con.*,
					DATE_FORMAT(con.data_reajuste, '%m')mes_reajuste,
					con.id id_contrato,
					con.id_conta,
					pr.nome nome_produto,
					pr.codigo codigo_produto,
					ev.razao_social razao_social_cm,
					ev.id id_empresa,
					ev.cnpj cnpj_cm,
					ev.endereco endereco_cm,
					ev.numero numero_cm,
					ev.complemento complemento_cm,
					ev.bairro bairro_cm,
					ev.cidade cidade_cm,
					ev.estado estado_cm,
					ev.cep cep_cm,
					ev.inscricao_estadual inscricao_estadual_cm,
					ev.inscricao_municipal inscricao_municipal_cm,
					ic.id as id_if_contrato
				from
					contratos con LEFT JOIN
					contrato_aniversario coa ON(con.id = coa.id_contrato) LEFT JOIN
					produtos pr ON(con.id_produto = pr.id) LEFT JOIN
					empresa_vendedora ev on(ev.id = con.id_empresa)
					LEFT JOIN if_contrato ic
					ON (con.id = ic.id_contrato)
				where
					(con.deleted = 0 or con.deleted is null) and
					con.codigo_cliente != '99999999'
			";

		if ($adm == false) {
			$query .= " and pr.codigo != 'ADM0001'";
		}

		if ($ativos) {
			$query .= " and con.status = 'ativo'";
		}

		if ($id_contrato) {
			$query .= " and con.id = $id_contrato";
		}
		$query .= " order by con.razao_social";
		return $this->db->exec($query);
	}

	function clientes($codigo_cliente = null)
	{
		$query = "
				select distinct
					codigo_cliente,
					nome_fantasia
				from
					contratos con
				where
					(con.deleted = 0 or con.deleted is null) and
					con.codigo_cliente != '99999999'
			";

		if ($codigo_cliente) {
			$query .= " and con.codigo_cliente = $codigo_cliente";
		}
		$query .= ' order by nome_fantasia ';
		return $this->db->exec($query);
	}

	function clientesAtivos($codigo_cliente = null, $ativos = true)
	{
		$query = "
				select distinct
					codigo_cliente,
					nome_fantasia,
					status
				from
					contratos con
				where
					(con.deleted = 0 or con.deleted is null) and
					con.codigo_cliente != '99999999'
			";

		if ($ativos) {
			$query .= " and con.status = 'ativo'";
		}

		if ($codigo_cliente) {
			$query .= " and con.codigo_cliente = $codigo_cliente";
		}
		$query .= ' order by nome_fantasia ';
		return $this->db->exec($query);
	}

	function clientesPorCodigo($codigo_cliente = null, $codigo_produto = null, $ativos = true, $adm = true, $id_contrato = null)
	{
		$query = "
				select distinct
					con.*,
					con.id id_contrato,
					pr.id id_produto,
					pr.nome nome_produto,
					pr.codigo codigo_produto,
					ev.cnpj cnpj_cm
				from
					contratos con left join 
					produtos pr on(pr.id = con.id_produto) inner join
					empresa_vendedora ev on(ev.id = con.id_empresa)
				where
					(con.deleted = 0 or con.deleted is null) and
					con.codigo_cliente != '99999999'
			";

		if ($ativos) {
			$query .= " and con.status = 'ativo'";
		}

		if (!$adm) {
			$query .= " and pr.codigo != 'ADM0001'";
		}

		if ($codigo_cliente) {
			$query .= " and con.codigo_cliente = '$codigo_cliente'";
		}

		if ($codigo_produto) {
			$query .= " and pr.codigo = '$codigo_produto'";
		}

		if ($id_contrato) {
			$query .= " and con.id = $id_contrato";
		}
		$query .= ' order by con.nome_fantasia ';
		return $this->db->exec($query);
	}

	function getModulosByContrato($id_contrato, $id_modulo = null, $order_by = false, $manual = false, $ativos = true)
	{
		$query = "
				select
					co.id id_contrato,
					co.status,
					co.codigo_cliente,
					co.nome_fantasia,
					co.razao_social,
					pr.id id_produto,
					pr.codigo codigo_produto,
					pr.nome nome_produto,
					mt.id id_modulo,
					mt.descricao nome_modulo,
					mt.codigo codigo_modulo,
					mt.empacotavel,
					mt.tipo_cobranca,
					mt.descricao,
					pct.id id_pacote,
					pct.id_modulos_tarifaveis,
					pct.qdt_garantido,
					pct.preco_pkt,
					pct.ultimo_reajuste,
					pct.flag flag_pacote
				from
					contratos co inner join
					produtos pr on(pr.id = co.id_produto) inner join
					modulos_tarifaveis mt on(mt.id_produto = pr.id) left join 
					pacote_contratado pct on( pct.id_contrato = co.id and pct.id_modulos_tarifaveis = mt.id and ( pct.status = 'ativo' or pct.status is null ) )
				where
					co.id = '$id_contrato' and 
					(co.deleted = '0' or co.deleted is null) and
					(pct.deleted = '0' or pct.deleted is null) and
					(mt.deleted = '0' or mt.deleted is null)
					
			";

		if ($ativos) {
			$query .= " and co.status = 'ativo' ";
		}

		if ($id_modulo) {
			$query .= " and mt.id = $id_modulo ";
		}

		if ($manual) {
			$query .= " and mt.permite_entrada_manual = 1 ";
		}

		if (!$order_by) {
			$query .= ' order by mt.descricao ';
		} else {
			$query .= ' order by mt.codigo';
		}
		return $this->db->exec($query);
	}

	function getListaPrecoCliente($id_contrato, $id_produto, $id_modulo, $quantidade, $tipo_tarifacao = 'degrau', $tipo_cobranca = 'VOLUMETRIA')
	{
		$query = "
				select
					lpc.*,
					(lpc.qtd_ate - lpc.qtd_de) AS intervalo_faixa
				from
					lp_clientes lpc
				where
					(lpc.deleted = 0 or lpc.deleted is null) and
					lpc.status = 'ativo'
			";

		if ($id_contrato) {
			$query .= " and lpc.id_contrato = $id_contrato ";
		}

		if ($id_produto) {
			$query .= " and lpc.id_produto = $id_produto ";
		}

		if ($id_modulo) {
			$query .= " and lpc.id_modulo = $id_modulo ";
		}

		if ($tipo_tarifacao == 'linear' && $tipo_cobranca == 'VOLUMETRIA') {
			$query .= " and lpc.qtd_de <= $quantidade and lpc.qtd_ate >= $quantidade ";
		}

		$query .= " order by lpc.qtd_de, lpc.qtd_ate";
		$exec = $this->db->query($query);
		if ($exec) {
			// Retorna
			$return = $exec->fetchAll();
			return json_encode($return);
		} else {
			return false;
		}
	}

	function getListaPrecoCodigoCliente($id_contrato, $codigo_produto = null)
	{
		$query = "
				select id_contrato, pr.nome nome_produto, mt.codigo codigo_modulo, mt.descricao nome_modulo, qtd_de, qtd_ate, valor_real, lpc.mes_reajuste, lpc.ano_reajuste, lpc.status from lp_clientes lpc inner join modulos_tarifaveis mt on(mt.id = lpc.id_modulo) inner join produtos pr on(pr.id = mt.id_produto) where (lpc.deleted = 0 or lpc.deleted is null) and lpc.status = 'ativo' and mt.tipo_cobranca = 'VOLUMETRIA'
			";
		if ($id_contrato) {
			$query .= " and lpc.id_contrato = $id_contrato ";
		}

		if (is_array($codigo_produto)) {
			$query .= " and pr.codigo in('" . implode("','", $codigo_produto) . "') ";
		} elseif ($id) {
			$query .= " and pr.codigo = '$codigo_produto'";
		}

		$query .= " order by mt.descricao, qtd_de";
		return $this->db->exec($query);
	}

	function getLpCliente($id_contrato, $codigo_produto = null)
	{
		$query = "
				select lpc.id id_lp, lpc.id_contrato,con.nome_fantasia, pr.nome nome_produto, mt.codigo codigo_modulo, mt.descricao nome_modulo, qtd_de, qtd_ate, valor_real, lpc.mes_reajuste, lpc.ano_reajuste, lpc.status, lpc.tipo_cobranca from lp_clientes lpc inner join modulos_tarifaveis mt on(mt.id = lpc.id_modulo) inner join produtos pr on(pr.id = mt.id_produto) inner join contratos con on(con.id = lpc.id_contrato) where (lpc.deleted = 0 or lpc.deleted is null) and lpc.status = 'ativo'
			";
		if ($id_contrato) {
			$query .= " and lpc.id_contrato = $id_contrato ";
		}

		if ($codigo_produto) {
			$query .= " and pr.codigo = '$codigo_produto' ";
		}
		$query .= " order by mt.descricao, qtd_de";

		return $this->db->exec($query);
	}

	function getListaPrecoContrato($id_contrato = null, $id_modulo = null)
	{
		$query = "
				select
					*
				from
					lp_clientes lpc
				where
					(lpc.deleted = 0 or lpc.deleted is null) and
					lpc.status = 'ativo'
			";
		if ($id_contrato) {
			$query .= " and lpc.id_contrato = $id_contrato ";
		}
		if ($id_modulo) {
			$query .= " and lpc.id_modulo = $id_modulo ";
		}

		$query .= " order by lpc.qtd_de, lpc.qtd_ate";

		return $this->db->exec($query);
	}

	function contratosAtivosDataAssinatura($id_contrato = null, $codigo_produto = null, $ativos = true, $now = null)
	{
		$query = "
			select
				con.id id_contrato,
				con.data_assinatura
			from
				contratos con inner JOIN
				produtos pr ON(con.id_produto = pr.id)
			where
				(con.deleted = 0 or con.deleted is null) and
				pr.codigo != 'ADM0001' and
				con.codigo_cliente != '99999999'
			";

		if ($ativos) {
			$query .= " and con.status = 'ativo'";
		}

		if ($id_contrato) {
			$query .= " and con.id = $id_contrato";
		}

		if ($codigo_produto) {
			$query .= " and pr.codigo = '$codigo_produto' ";
		}

		if ($now) {
			$ultimo_dia_mes = cal_days_in_month(CAL_GREGORIAN, $now->format('m'), $now->format('Y'));
			$dt_fim = $now->format('Y-m-' . $ultimo_dia_mes);
			$query .= " and con.data_assinatura <= '$dt_fim' ";
		}

		$query .= " order by con.data_assinatura asc";

		return $this->db->exec($query);
	}

	function getLastDataPagamento()
	{
		$query = "select data_corte_faturamento from contratos where (deleted = 0 or deleted is null) order by data_corte_faturamento desc limit 1";
		return $this->db->exec($query);
	}

	//metodo temporario apagar quando não mas necessario
	function getLpCodigoCliente($id_contrato)
	{
		$query = "
				select id_contrato, pr.nome nome_produto, mt.codigo codigo_modulo, mt.descricao nome_modulo, qtd_de, qtd_ate, valor_real, lpc.mes_reajuste, lpc.ano_reajuste, lpc.status, lpc.deleted, lpc.alterado_em from lp_clientes lpc inner join modulos_tarifaveis mt on(mt.id = lpc.id_modulo) inner join produtos pr on(pr.id = mt.id_produto) 
			";
		if ($id_contrato) {
			$query .= " where lpc.id_contrato = $id_contrato ";
		}

		$query .= " order by mt.descricao, qtd_de";

		return $this->db->exec($query);
	}

	function getPctCodigoCliente($id_contrato)
	{
		$query = "
				select 
					con.data_assinatura,
					con.nome_fantasia,
					mt.descricao nome_modulo,
					coa.mes_reajuste,
					pct.qdt_garantido,
					pct.preco_pkt,
					pct.status,
					pct.flag	
				from 
					pacote_contratado pct inner join 
					contratos con on(con.id = pct.id_contrato) inner join
					contrato_aniversario coa on(coa.id_contrato = con.id) inner join
					modulos_tarifaveis mt on(mt.id = pct.id_modulos_tarifaveis)
				WHERE
					(con.deleted is null or con.deleted = 0) and
					(pct.deleted is null or pct.deleted = 0) and
					con.status = 'ativo' AND
					con.data_assinatura <= '2017-10-01'			
			";
		if ($id_contrato) {
			$query .= " and con.id_contrato = $id_contrato ";
		}

		$query .= " order by con.razao_social, mt.descricao ";

		return $this->db->exec($query);
	}

	function getCustomContratos()
	{
		$query = "
				select
					con.id id_contrato,
					con.codigo_cliente,
					con.razao_social,
					con.nome_fantasia,
					con.data_corte_faturamento,
					pro.id id_produto,
					pro.nome nome_produto,
					pro.codigo codigo_produto,
					mt.codigo codigo_modulo,
					mt.descricao
				from
					contratos con left join
					produtos pro on (pro.id = con.id_produto) left join
					modulos_tarifaveis mt on(mt.id_produto = pro.id)
				where 
					(con.deleted = 0 or con.deleted is null)
				";
		$exec = $this->db->query($query);
		if ($exec) {
			// Retorna
			$return = $exec->fetchAll();
			return json_encode($return);
		} else {
			return false;
		}
	}

	//By: Caio Freitas 06/07/2022
	function getIfContrato($id_contrato = null)
	{
		$query = "
			SELECT 
				*
			FROM
				if_contrato
			WHERE
				(deleted is null or deleted = 0)
			";

		if ($id_contrato) {
			$query .= " and id_contrato = $id_contrato";
		}

		$query .= " ORDER BY id ASC";

		return $exe = $this->db->exec($query);
	}

	//By: Caio Freitas - 13/09/2022
	function getFullComissao($id_objeto = null, $id_usuario = null, $id = null)
	{
		$query = "
			SELECT            
				c.id_perfil,
				c.id_usuario,             
				u.nome as nome_usuario,
				cp.nome as nome_perfil,           
				cp.percentual,
				cp.objeto,
				cv.meses_validade,
				cv.data_criacao,
				cv.id,
				cv.perfil,
				cv.id_objeto
			FROM
				comissoes_usuario c
			INNER JOIN
				sistema_usuarios u
			ON
				(c.id_usuario = u.id)
			INNER JOIN
				comissoes_perfil cp
			ON
				(c.id_perfil = cp.id)
			INNER JOIN
				comissoes_validade cv
			ON
				(cv.id_comissao_usuario = c.id)
			WHERE
				(cv.deleted = 0 or cv.deleted is null)";

		if ($id_objeto) {
			$query .= " and cv.id_objeto = $id_objeto";
		}

		if ($id_usuario) {
			$query .= " and cv.id_usuario = $id_usuario";
		}

		if ($id) {
			$query .= " and cv.id = $id";
		}
		$query .= " order by cv.id asc";
		return $exe = $this->db->exec($query);
	}

	function getContratoByCodigo($codigo_cliente = null, $codigo_produto = null)
	{
		$query = "
				SELECT
					c.id id_contrato,
					c.data_assinatura,
					c.razao_social,
					c.nome_fantasia,
					c.status,
					c.numero_contrato,
					c.cnpj,
					c.taxa_inatividade,
					c.status status_contrato,
					p.nome as nome_produto,
					p.descricao,
					p.codigo
				FROM
					contratos c
				INNER JOIN
					produtos p
				ON
					(c.id_produto = p.id)
				WHERE
					(c.deleted = 0 OR c.deleted is null)
			";

		if ($codigo_cliente) {
			$query .= " and c.codigo_cliente = $codigo_cliente";
		}

		if ($codigo_produto) {
			$query .= " and p.codigo = '$codigo_produto'";
		}
		$query .= " ORDER BY c.id DESC";
		return $exe = $this->db->exec($query);
	}

	function getMetaDados($id_contrato_md)
	{
		$query = "
				SELECT 
					* 
				FROM 
					meta_dados md 
				WHERE 
					(deleted IS NULL OR deleted = 0) AND md.meta_campo = 'info_contratos'";

		if ($id_contrato_md) {
			$query .= " and md.meta_id_origem = $id_contrato_md ";
		}

		return $this->db->exec($query);
	}

	function contratosByCnpjeProduto($CnpjCpf, $codigo_produto = null)
	{
		$query = "
				select 
					con.*,
					pr.nome nome_produto,
					pr.codigo codigo_produto
				from
					contratos con inner join
					produtos pr on(con.id_produto = pr.id)
				where
					(con.deleted = 0 or con.deleted is null)
			";

		if ($CnpjCpf) {
			$query .= " and con.cnpj = $CnpjCpf ";
		}

		if ($codigo_produto) {
			$query .= " and pr.codigo = '$codigo_produto' ";
		}
		$query .= ' order by nome_fantasia ';
		return $this->db->exec($query);
	}


	function getMetaDadosStatus($id_contrato_md)
	{
		$query = "
				SELECT DISTINCT
				md.*,
				md.meta_tipo AS tipo,
				md.meta_classificacao AS classificacao,
				md.meta_valor AS status,
				md2.meta_valor AS meta_status,
				md2.meta_info AS observ,
				md2.id AS id_status,
				md2.meta_default as pendente,
				su.nome AS criado_por,
				su2.nome AS confirmado_por
				FROM
				meta_dados md
				LEFT JOIN meta_dados md2 ON md.id = md2.meta_id_origem AND md2.meta_campo = 'observacao' AND md2.deleted = 0
				LEFT JOIN sistema_usuarios su  ON md.id_owner = su.id
				LEFT JOIN sistema_usuarios su2 ON md2.alterado_por = su2.id
				WHERE md.meta_campo = 'observacao' AND md.meta_id_origem = " . $id_contrato_md . " 
				ORDER BY md.id DESC;";
		return $this->db->exec($query);
	}

	function getMetaDadosStatusById($id_meta_dado)
	{
		$query = "
				SELECT md.meta_valor, md.id, md2.meta_info, md2.id as pendencia_id, md2.meta_default as pendente_validacao
				FROM
				meta_dados md
				LEFT JOIN meta_dados md2 ON md.id = md2.meta_id_origem AND md2.deleted = 0
				WHERE  md.id = $id_meta_dado
			";
		return $this->db->exec($query);
	}

}