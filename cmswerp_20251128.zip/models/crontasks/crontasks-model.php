<?php
    class CronTasksModel extends MainModel{
        protected $table = "crontasks";
        public function listarAtivas(){
            $query = " SELECT * FROM crontasks WHERE ativo = 1 AND deleted = 0 ";
            return $this->db->exec($query);
        }

        public function atualizarExecucao($id, $ultima, $proxima){
            $query = " UPDATE crontasks SET ultima_execucao = ?, proxima_execucao= ?, alterado_em = NOW()  WHERE id = ? ";
            return $this->db->exec($query, [$ultima, $proxima, $id]);
        }

        public function setLock($id){
            $query = " UPDATE crontasks SET locked_at = NOW() WHERE id = ? AND locked_at IS NULL ";
            return $this->db->exec($query, [$id]);
        }

        public function releaseLock($id){
            $query = " UPDATE crontasks SET locked_at = NULL WHERE id = ? ";
            return $this->db->exec($query, [$id]);
        }
    }