<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */

class DescontosModel extends MainModel{
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	public function __construct($controller = null ){
		$this->table = 'descontos';
		parent::__construct($controller);
	}

	function getDescontos($id = null){

	}

	function getDescontosCliente($codigo_cliente = null, $usuario_alvo){
		$query = " select * from descontos where (deleted is null or deleted = 0) and status = 'ativo'";
		if($codigo_cliente){
			$query .= " and codigo_cliente = '$codigo_cliente'";
		}

		if($usuario_alvo){
			$query .= " and usuario_alvo = '$usuario_alvo'";
		}

		return $this->db->exec($query);
	}
}