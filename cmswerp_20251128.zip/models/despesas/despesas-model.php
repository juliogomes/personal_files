<?php
    class DespesasModel extends MainModel{
    	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
    	public function __construct( $controller = null ){
    		$this->table = 'despesas';
    		parent::__construct($controller);
    	}
    	
		function getById( $id ){
			if( !isset( $id ) || empty( $id ) || !is_numeric( $id ) ){
				return false;
			}
			$query = " select * from despesas where ( deleted = 0 or deleted is null ) and id = $id ";
			return $this->db->exec($query);
		}
		
    	function getDespesas( $id = null, $dt_ini = null, $dt_fim = null, $valor = null, $status = null, $autorizado = null, $id_cm = null, $meio_pagamento = null, $tipo_data = 'vencimento'){
    		$query = "
    			SELECT
    				desp.id id_despesa,
    				desp.id_cm,
    				desp.id_doc,
    				desp.id_fornecedor,
    				desp.historico,
    				desp.parcelado,
    				desp.numero_documento,
    				periodo_apuracao,
    				desp.numero_parcelas,
    				desp.email_contato,
    				desp.data_pagamento,
    				desp.descricao,
    				desp.status,
    				desp.meio_pagamento,
    				desp.prioridade,
    				desp.tipo_cobranca,
    				desp.tipo,
    				desp.valor,
    				desp.data_vencimento,
    				desp.status_autorizacao,
    				desp.status_remessa,
    				desp.codigo_barra, 
    				desp.tipo_despesa,
    				desp.abatimento,
    				desp.desconto,
    				desp.juros,
    				desp.multa,
    				desp.descricao,
    				desp.codigo_receita,
    				desp.numero_referencia,
    				desp.atualizacao_monetaria,
    				desp.percentual_receita,
    				desp.codigo_tributo,
    				desp.competencia,
    				desp.outros_valores,
    				desp.divida_ativa,
    				desp.numero_parcelas,
    				desp.parcela_numero,
    				desp.identificacao_contribuinte,
    				ev.cnpj cnpj_cm,
    				ev.razao_social nome_cm,
    				ev.inscricao_estadual ie_cm,
    				ev.inscricao_municipal im_cm,
    				frd.cnpj_cpf,
    				frd.tipo tipo_empresa_fornecedor,
    				frd.inscricao_estadual ie_fornecedor,
    				frd.razao_social nome_fornecedor,
    				frd.nome_fantasia,
    				frd.endereco,
    				frd.numero,
    				frd.complemento,
    				frd.bairro,
    				frd.cidade,
    				frd.estado,
    				frd.cep,
    				desp.id_grupo,
    				desp.id_conta,
    				desp.id_subconta,
    				desp.id_centro_custo,
    				grp.nome nome_grupo,
    				con.nome nome_conta,
    				sub.nome nome_subconta,
    				occ.nome nome_centro_custo
    			FROM 
    				despesas desp LEFT join
    				empresa_vendedora ev ON(ev.id = desp.id_cm) LEFT join
    				fornecedores frd ON(frd.id = desp.id_fornecedor) left join
    				orc_centro_custo occ on(desp.id_centro_custo = occ.id) left join
    				orc_grupo grp on(grp.id = desp.id_grupo) left join
    				orc_conta con on(con.id = desp.id_conta) left join
    				orc_conta sub on(sub.id = desp.id_subconta)
    			where
    					(desp.deleted = 0 or desp.deleted is null)
    		";
    		if($status == 'aberto'){
    			$query .= " and (desp.status = '$status' or desp.status is null) ";
    		}elseif($status){
    			$query .= " and desp.status = '$status' ";
    		}
    
    		if($autorizado){
    			$query .= " and desp.status_autorizacao = '$autorizado' ";
    		}
    
    		if(is_array($id)){
    			$query .= " and desp.id in(".implode(',', $id).") ";
    		}elseif($id){
    			$query .= " and desp.id = $id ";
    		}
    
    		if($dt_ini){
    			if($tipo_data == 'pagamento'){
    				$query .= " and desp.data_pagamento >= '$dt_ini' ";
    			}else{
    				$query .= " and desp.data_vencimento >= '$dt_ini' ";
    			}
    		}
    
    		if($dt_fim){
    			if($tipo_data == 'pagamento'){
    				$query .= " and desp.data_pagamento <= '$dt_fim' ";
    			}else{
    				$query .= " and desp.data_vencimento <= '$dt_fim' ";
    			}
    		}
    
    		if($valor){
    			$query .= " and valor = $valor ";
    		}
    
    		if($id_cm){
    			$query .= " and id_cm = $id_cm ";
    		}
    
    		if($meio_pagamento){
    			$query .= " and meio_pagamento = '$meio_pagamento' ";
    		}
    		$query .= ' order by frd.razao_social ';
    		
    		return $this->db->exec($query);
    	}
    
    	function getDespesaByIdDoc( $id_doc = null ){
    		$query = "select d.*, frn.razao_social nome_fornecedor from despesas d inner join fornecedores frn on(d.id_fornecedor = frn.id) where (d.deleted  is null or d.deleted = 0)";
    		if($id_doc){
    			$query .= " and d.id_doc = $id_doc ";
    		}
            
    		return $this->db->exec($query);
    	}
    
    	function getDespesasComConta($id = null){
    		$query = "
    			SELECT
    				desp.id id_despesa,
    				desp.id_cm,
    				desp.id_doc,
    				desp.id_fornecedor,
    				desp.historico,
    				desp.parcelado,
    				desp.numero_parcelas,
    				desp.email_contato,
    				desp.data_pagamento,
    				desp.descricao,
    				desp.status,
    				desp.meio_pagamento,
    				desp.prioridade,
    				desp.tipo_cobranca,
    				desp.tipo,
    				desp.valor,
    				desp.data_vencimento,
    				desp.status_autorizacao,
    				desp.codigo_barra, 
    				desp.tipo_despesa,
    				desp.abatimento,
    				desp.desconto,
    				desp.juros,
    				desp.multa,
    				desp.descricao,
    				desp.codigo_receita,
    				desp.numero_referencia,
    				desp.atualizacao_monetaria,
    				desp.percentual_receita,
    				desp.codigo_tributo,
    				desp.competencia,
    				desp.outros_valores,
    				desp.divida_ativa,
    				desp.numero_parcelas,
    				desp.parcela_numero,
    				desp.identificacao_contribuinte,
    				b1.ispb_banco ispb_banco_cm,
    				b1.codigo_banco codigo_banco_cm,
    				b1.nome_reduzido nome_banco_cm,
    				c1.id id_conta_cm,
    				c1.tipo_conta tipo_conta_cm,
    				c1.numero_agencia agencia_cm,
    				c1.digito_agencia agencia_div_cm,
    				c1.numero_conta numero_conta_cm,
    				c1.digito_conta digito_conta_cm,
    				c1.codigo_convenio_cnab400,
    				c1.codigo_convenio_cnab240,
    				c1.conta_default conta_default_cm,
    				c1.email email_conta,
    				ev.cnpj cnpj_cm,
    				ev.razao_social nome_cm,
    				ev.inscricao_estadual ie_cm,
    				ev.inscricao_municipal im_cm,
    				frd.cnpj_cpf,
    				frd.tipo tipo_empresa_fornecedor,
    				frd.inscricao_estadual ie_fornecedor,
    				frd.razao_social nome_fornecedor,
    				frd.nome_fantasia,
    				frd.endereco,
    				frd.numero,
    				frd.complemento,
    				frd.bairro,
    				frd.cidade,
    				frd.estado,
    				frd.cep,
    				b2.ispb_banco ispb_banco_fornecedor,
    				b2.codigo_banco codigo_banco_fornecedor,
    				b2.nome_reduzido nome_banco_fornecedor,
    				c2.id id_conta_fornecedor,
    				c2.id_empresa id_empresa_conta,
    				c2.tipo_conta tipo_conta_fornecedor,
    				c2.numero_agencia agencia_fornecedor,
    				c2.digito_agencia agencia_div_fornecedor,
    				c2.numero_conta numero_conta_fornecedor,
    				c2.digito_conta digito_conta_fornecedor,
    				c2.conta_default conta_default_fornecedor,
    				desp.id_grupo,
    				desp.id_conta,
    				desp.id_subconta,
    				desp.id_centro_custo,
    				grp.nome nome_grupo,
    				con.nome nome_conta,
    				sub.nome nome_subconta,
    				occ.nome nome_centro_custo
    			FROM 
    				despesas desp LEFT join
    				empresa_vendedora ev ON(ev.id = desp.id_cm) LEFT join
    				fornecedores frd ON(frd.id = desp.id_fornecedor) left join
    				conta_bancaria c1 ON(c1.id_empresa = ev.id AND c1.origem_conta = 'empresa_cm' AND (c1.conta_default = 1 OR c1.conta_default IS null)) LEFT join
    				conta_bancaria c2 ON(c2.id_empresa = desp.id AND (c2.origem_conta = 'despesa') AND (c2.conta_default = 1 OR c2.conta_default IS null)) LEFT join
    				banco b1 ON(b1.id = c1.id_banco) LEFT join
    				banco b2 ON(b2.id = c2.id_banco) LEFT JOIN
    				orc_centro_custo occ on(desp.id_centro_custo = occ.id) left join
    				orc_grupo grp on(grp.id = desp.id_grupo) left join
    				orc_conta con on(con.id = desp.id_conta) left join
    				orc_conta sub on(sub.id = desp.id_subconta)
    			WHERE
        			(desp.deleted = 0 or desp.deleted is null) and
        			(c1.deleted = 0 OR c1.deleted IS NULL) and
        			(c2.deleted = 0 OR c2.deleted IS NULL) and
        			c2.numero_conta IS NOT NULL and
        			c2.numero_conta <> ''
    		";
    		if(is_array($id)){
    			$query .= " and desp.id in(".implode(',', $id).") ";
    		}elseif($id){
    			$query .= " and desp.id = $id ";
    		}
    		$query .= ' order by frd.razao_social ';
    		return $this->db->exec($query);
    	}
    	
    	function getDespesasCbDefault($default = true, $id = null){
    		$query = "
    			SELECT
    				desp.id id_despesa,
    				desp.id_cm,
    				desp.id_doc,
    				desp.id_fornecedor,
    				desp.numero_documento,
    				desp.historico,
    				desp.parcelado,
    				desp.numero_parcelas,
    				desp.email_contato,
    				desp.data_pagamento,
    				desp.descricao,
    				desp.status,
    				desp.meio_pagamento,
    				desp.prioridade,
    				desp.tipo_cobranca,
    				desp.tipo,
    				desp.valor,
    				desp.periodo_apuracao,
    				desp.data_vencimento,
    				desp.status_autorizacao,
    				desp.codigo_barra, 
    				desp.tipo_despesa,
    				desp.abatimento,
    				desp.desconto,
    				desp.juros,
    				desp.multa,
    				desp.descricao,
    				desp.codigo_receita,
    				desp.numero_referencia,
    				desp.atualizacao_monetaria,
    				desp.percentual_receita,
    				desp.codigo_tributo,
    				desp.competencia,
    				desp.outros_valores,
    				desp.divida_ativa,
    				desp.numero_parcelas,
    				desp.parcela_numero,
    				desp.identificacao_contribuinte,
    				b1.ispb_banco ispb_banco_cm,
    				b1.codigo_banco codigo_banco_cm,
    				b1.nome_reduzido nome_banco_cm,
    				c1.id id_conta_cm,
    				c1.tipo_conta tipo_conta_cm,
    				c1.numero_agencia agencia_cm,
    				c1.digito_agencia agencia_div_cm,
    				c1.numero_conta numero_conta_cm,
    				c1.digito_conta digito_conta_cm,
    				c1.codigo_convenio_cnab400,
    				c1.codigo_convenio_cnab240,
    				c1.conta_default conta_default_cm,
    				c1.email email_conta,
    				ev.cnpj cnpj_cm,
    				ev.razao_social nome_cm,
    				ev.inscricao_estadual ie_cm,
    				ev.inscricao_municipal im_cm,
    				frd.cnpj_cpf,
    				frd.tipo tipo_empresa_fornecedor,
    				frd.inscricao_estadual ie_fornecedor,
    				frd.razao_social nome_fornecedor,
    				frd.nome_fantasia,
    				frd.endereco,
    				frd.numero,
    				frd.complemento,
    				frd.bairro,
    				frd.cidade,
    				frd.estado,
    				frd.cep,
    				b2.ispb_banco ispb_banco_fornecedor,
    				b2.codigo_banco codigo_banco_fornecedor,
    				b2.nome_reduzido nome_banco_fornecedor,
    				c2.id id_conta_fornecedor,
    				c2.tipo_conta tipo_conta_fornecedor,
    				c2.numero_agencia agencia_fornecedor,
    				c2.digito_agencia agencia_div_fornecedor,
    				c2.numero_conta numero_conta_fornecedor,
    				c2.digito_conta digito_conta_fornecedor,
    				c2.conta_default conta_default_fornecedor,
    				desp.id_grupo,
    				desp.id_conta,
    				desp.id_subconta,
    				desp.id_centro_custo,
    				grp.nome nome_grupo,
    				con.nome nome_conta,
    				sub.nome nome_subconta,
    				occ.nome nome_centro_custo
    			FROM 
    				despesas desp LEFT join
    				empresa_vendedora ev ON(ev.id = desp.id_cm) LEFT join
    				fornecedores frd ON(frd.id = desp.id_fornecedor) left join
    				conta_bancaria c1 ON(c1.id_empresa = ev.id AND c1.origem_conta = 'empresa_cm' AND (c1.conta_default = 1 OR c1.conta_default IS null)) LEFT join
    				conta_bancaria c2 ON(c2.id_empresa = frd.id AND c2.origem_conta = 'fornecedor' AND (c2.conta_default = 1 OR c2.conta_default IS null)) LEFT join
    				banco b1 ON(b1.id = c1.id_banco) LEFT join
    				banco b2 ON(b2.id = c2.id_banco) LEFT JOIN
    				orc_centro_custo occ on(desp.id_centro_custo = occ.id) left join
    				orc_grupo grp on(grp.id = desp.id_grupo) left join
    				orc_conta con on(con.id = desp.id_conta) left join
    				orc_conta sub on(sub.id = desp.id_subconta)
    			WHERE
					(desp.deleted = 0 or desp.deleted is null) and
					(c1.deleted = 0 OR c1.deleted IS NULL) and
					(c2.deleted = 0 OR c2.deleted IS NULL)
    		";
    		if(is_array($id)){
    			$query .= " and desp.id in(".implode(',', $id).") ";
    		}elseif($id){
    			$query .= " and desp.id = $id ";
    		}
    		//$query .= ' order by frd.razao_social ';
    		return $this->db->exec($query);
    	}
    
    	function getDadosSaldo(){
    		$args = func_get_args();
    		$query = "
    			select 
    				sum(d.valor) valor_total,
    				d.data_vencimento,
    				d.id_cm,
    				d.status,
    				d.status_autorizacao
    			from 
    				despesas d
    			WHERE 
    				(d.deleted = 0 or d.deleted is null)
    	
    		";
    		if(isset($args[0]) && !empty($args[0])){
    			$query .= " and status = '".$args[0]."'";		
    		}
    		if(isset($args[1]) && !empty($args[1])){
    			$query .= " and status_autorizacao = '".$args[1]."'";		
    		}
    		$query .= "
    			group BY 
    				d.data_vencimento,
    				d.id_cm,
    				d.status,
    				d.status_autorizacao
    			order BY 
    				d.data_vencimento
    		";
    		return $this->db->exec($query);
    	}
    
    	function getDespesaPorExtrato( $id_extrato ){
    		$query = "select * from despesas desp where (desp.deleted = 0 or desp.deleted is null)";
    		if($id_extrato){
    			$query .= " and id_extrato = '$id_extrato'";
    		}
    		return $this->db->exec($query);
    	}
    
    	function getDespesasPorCentroCustoAno( $ano = null, $view ){
    		$dt_ini = $ano.'-01-01';
    		$dt_fim = $ano.'-12-31';
    		$query = "
    			select
    				sum(valor) valor,
    				DATE_FORMAT(desp.data_vencimento,'%Y') ano,
    				DATE_FORMAT(desp.data_vencimento,'%m') mes,
    				occ.nome
    			from
    				despesas desp
    			inner join
    				empresa_vendedora ev on(ev.id = desp.id_cm) inner join
    				fornecedores frd on(frd.id = desp.id_fornecedor) inner join
    				orc_centro_custo occ on(desp.id_centro_custo = occ.id) inner join
    				orc_grupo grp on(grp.id = desp.id_grupo) inner join
    				orc_conta con on(con.id = desp.id_conta) inner join
    				orc_conta sub on(sub.id = desp.id_subconta)
    			where
    				(desp.deleted = 0 or desp.deleted is null)
    		";
    		if($ano){
    			$query .= " and desp.data_vencimento >= '$dt_ini' and desp.data_vencimento <= '$dt_fim'";
    		}
    		if($view != 'todos'){
    	    	$query .= " and desp.tipo = '$view' ";
        	}
    		$query .= " group by occ.nome,  ano, mes order by ano, mes asc";
    		$exec = $this->db->query($query);
    		return $this->db->exec($query);
    	}
    
    	function getDespesasPorContaAno( $ano = null, $view ){
    		$dt_ini = $ano.'-01-01';
    		$dt_fim = $ano.'-12-31';
    		$query = "
				select
					sum(valor) valor,
					DATE_FORMAT(desp.data_vencimento,'%Y') ano,
					DATE_FORMAT(desp.data_vencimento,'%m') mes,
					oco.nome
				from
					despesas desp
				inner join
					empresa_vendedora ev on(ev.id = desp.id_cm) inner join
					fornecedores frd on(frd.id = desp.id_fornecedor) inner join
					orc_centro_custo occ on(desp.id_centro_custo = occ.id) inner join
					orc_grupo grp on(grp.id = desp.id_grupo) inner join
					orc_conta con on(con.id = desp.id_conta) inner join
					orc_conta sub on(sub.id = desp.id_subconta)
				where
					(desp.deleted = 0 or desp.deleted is null)
    		";
    		
    		if($ano){
    			$query .= " and desp.data_vencimento >= '$dt_ini' and desp.data_vencimento <= '$dt_fim'";
    		}
    
    		if($view != 'todos'){
    	    	$query .= " and desp.tipo = '$view' ";
        	}
    		$query .= " group by oco.nome,  desp.data_vencimento order by desp.data_vencimento asc";
    		$exec = $this->db->query($query);
    		return $this->db->exec($query);
    	}
    
    	function getDespesasPorGrupoAno($ano = null, $view){
    		$dt_ini = $ano.'-01-01';
    		$dt_fim = $ano.'-12-31';
    		$query = "
				select
					sum(valor) valor,
					DATE_FORMAT(desp.data_vencimento,'%Y') ano,
					DATE_FORMAT(desp.data_vencimento,'%m') mes,
					grp.nome
				from
					despesas desp
				inner join
					empresa_vendedora ev on(ev.id = desp.id_cm) inner join
					fornecedores frd on(frd.id = desp.id_fornecedor) inner join
					orc_centro_custo occ on(desp.id_centro_custo = occ.id) inner join
					orc_grupo grp on(grp.id = desp.id_grupo) inner join
					orc_conta con on(con.id = desp.id_conta) inner join
					orc_conta sub on(sub.id = desp.id_subconta)
				where
					(desp.deleted = 0 or desp.deleted is null)
    		";

    		if($ano){
    			$query .= " and desp.data_vencimento >= '$dt_ini' and desp.data_vencimento <= '$dt_fim'";
    		}
			
    		if($view != 'todos'){
    	    	$query .= " and desp.tipo = '$view' ";
        	}
    		$query .= " group by grp.nome, desp.data_vencimento order by desp.data_vencimento asc";
    		$exec = $this->db->query($query);
    		return $this->db->exec($query);
    	}
    
    	function getDespesasByParam($id_despesa = null, $id_centro_custo = null, $id_grupo = null, $id_conta = null, $id_subconta = null, $dt_ini =  null, $dt_fim =  null, $tipo= null, $status = null){
    		$query = "select sum(tb1.valor) valor_total, MONTH(data_vencimento) mes, YEAR(data_vencimento) ano from despesas tb1 where (tb1.deleted = 0  or tb1.deleted is null) ";
    		if($id_despesa){
    			$query .= " and tb1.id = $id_despesa ";
    		}
    
    		if($id_centro_custo){
    			$query .= " and tb1.id_centro_custo = $id_centro_custo ";
    		}
    
    		if($id_grupo){
    			$query .= " and tb1.id_grupo = $id_grupo ";
    		}
    
    		if($id_conta){
    			$query .= " and tb1.id_conta = $id_conta ";
    		}
    
    		if($id_subconta){
    			$query .= " and tb1.id_subconta = $id_subconta ";
    		}
    
    		if($dt_ini && !$dt_fim){
    			$ultimo_dia = cal_days_in_month(CAL_GREGORIAN, $dt_ini->format('m'), $dt_ini->format('Y'));
    			$start = $dt_ini->format('Y-m-01');
    			$end   = $dt_ini->format('Y-m-'.$ultimo_dia);
    			$query .= " and tb1.data_vencimento >= '$start' ";
    			$query .= " and tb1.data_vencimento <= '$end' ";
    		}elseif($dt_ini && $dt_fim){
    			$ultimo_dia = cal_days_in_month(CAL_GREGORIAN, $dt_ini->format('m'), $dt_ini->format('Y'));
    			$start = $dt_ini->format('Y-m-01');
    			$end   = $dt_ini->format('Y-m-'.$ultimo_dia);
    			
    			$query .= " and tb1.data_vencimento >= '".$dt_ini->format('Y-m-d')."' ";
    			$query .= " and tb1.data_vencimento <= '".$dt_fim->format('Y-m-d')."' ";
    		}
    
    		if($tipo){
    			$query .= " and tb1.tipo = '$tipo' ";
    		}
    
    		if($status){
    			$query .= " and tb1.status = '$status'";
    		}
    		return $this->db->exec($query);
    	}
    
    	function getDespesasParametro($param = null, $view = null, $agrupar_data = true){
    		$groupby = null;
    		$where = null;
    		$query = null;
    		
    		if($param['dt_ini']){
    			$where .= " and desp.data_vencimento >= '".$param['dt_ini']->format('Y-m-d')."'";
    		}
    
    		if($param['dt_fim']){
    			$where .= " and desp.data_vencimento <= '".$param['dt_fim']->format('Y-m-d')."'";
    		}
    		
    		if($view){
    			$where .= " and desp.tipo = '$view' ";
    		}
    
    		foreach ($param as $key => $value){
    			
    			// if($key == 'ano' ){
    			// 	$dt_ini = $value.'-01-01';
    			// 	$dt_fim = $value.'-12-31';
    			// 	$where .= " and desp.data_vencimento >= '$dt_ini' and desp.data_vencimento <= '$dt_fim'";
    			// }elseif($key == 'ano_mes' ){
    			// 	$arr_data = explode('-', $value);
    			// 	$ultimo_dia = cal_days_in_month(CAL_GREGORIAN, $arr_data[1], $arr_data[0]);
    			// 	$dt_ini = $value.'-01';
    			// 	$dt_fim = $value."-$ultimo_dia";
    			// 	$where .= " and desp.data_vencimento >= '$dt_ini' and desp.data_vencimento <= '$dt_fim'";
    			// }
    			
    			if($key == 'filtro_centro_custo'){
    				$where .= " and desp.id_centro_custo = $value ";
    			}
    
    			if($key == 'filtro_grupo'){
    				$where .= " and desp.id_grupo = $value ";
    			}
    
    			if($key == 'filtro_conta'){
    				$where .= " and desp.id_conta = $value ";
    			}
    
    			if($key == 'filtro_subconta'){
    				$where .= " and desp.id_subconta = $value ";
    			}
    
    			
    			if($key == 'agrupar'){
    				if(is_array($value)){
    					foreach ($value as $k1 => $v1) {
    						if($v1== 'centro_custo'){
    							$field   .= 'occ.alias nome, ';
    							$groupby .= 'occ.nome ';
    						}elseif($v1== 'grupo'){
    							$field   .= 'ocg.nome, ';
    							$groupby .= 'ocg.nome ';
    						}elseif($v1== 'conta'){
    							$field   .= 'oco.nome nome, ';
    							$groupby .= 'oco.nome ';
    						}elseif($v1== 'subconta'){
    							$field   .= 'ocs.nome nome, ';
    							$groupby .= 'ocs.nome ';
    						}elseif($v1== 'status'){
    							$field   .= 'desp.status, desp.status_autorizacao, ';
    							$groupby .= 'desp.status, desp.status_autorizacao ';
    						}
    						
    						if(end(array_keys($value)) != $k1){
    							$groupby  .= ', ';
    						}
    					}
    				}else{
    					//trecho será removido futuramento codigo V0001
    					if($value == 'centro_custo'){
    						$field = 'occ.alias nome, ';
    						$groupby = 'occ.nome ';
    					}elseif($value == 'grupo'){
    						$field = 'ocg.nome, ';
    						$groupby = 'ocg.nome ';
    					}elseif($value == 'conta'){
    						$field = 'oco.nome nome, ';
    						$groupby = 'oco.nome ';
    					}elseif($value == 'subconta'){
    						$field = 'ocs.nome nome ';
    						$groupby = 'ocs.nome ';
    					}elseif($value == 'status'){
    						$field = 'desp.status, desp.status_autorizacao, ';
    						$groupby = 'desp.status, desp.status_autorizacao ';
    					}
    				}
    			}
    			
    			if($key == 'filtro'){
    				foreach ($value as $k1 => $v1) {
    					if($v1['nome'] == 'centro_custo'){
    						$where .= " and desp.id_centro_custo = '".$v1['id']."' ";
    					}
    					
    					if($v1['nome'] == 'grupo'){
    						$where .= " and desp.id_grupo = '".$v1['id']."' ";
    					}
    					
    					if($v1['nome'] == 'conta'){
    						$where .= " and desp.id_conta = '".$v1['id']."' ";
    					}
    					
    					if($v1['nome'] == 'subconta'){
    						$where .= " and desp.id_subconta = '".$v1['id']."' ";
    					}
    					
    					if(isset($v1['status'])){
    						$where .= " and desp.status = '".$v1['status']."' ";
    					}
    
    					if(isset($v1['status_autorizacao'])){
    						$where .= " and desp.status_autorizacao = '".$v1['status_autorizacao']."' ";
    					}
    				}
    			}
    	    }
    
    	   	$query = "
    	        SELECT distinct
    	            $field
    	            DATE_FORMAT(desp.data_vencimento,'%Y') ano,
    				DATE_FORMAT(desp.data_vencimento,'%m') mes,
    	            sum(desp.valor) valor,
    				desp.tipo
    	        FROM
    	            despesas desp inner join
    	            orc_centro_custo occ on(desp.id_centro_custo = occ.id) inner join
    	            orc_grupo ocg on(desp.id_grupo = ocg.id) inner join
    	            orc_conta oco on (desp.id_conta = oco.id) inner join
    	            orc_conta ocs on(desp.id_subconta = ocs.id)
    	        where
    	            (desp.deleted = 0 or desp.deleted is null ) and
    	            (occ.deleted = 0 or occ.deleted is null ) and
    	            (ocg.deleted = 0 or ocg.deleted is null ) and
    	            (oco.deleted = 0 or oco.deleted is null ) and
    	            (ocs.deleted = 0 or ocs.deleted is null )
    	    ";
    
    	    $query .= $where;
    
    		if($agrupar_data){
                $query .= " group by ano, mes ";
                $query .= ' , '.$groupby;
            }else{
                $query .= ' group by '.$groupby;
    		}
    		$query .= " order by ano, mes ";
    		return $this->db->exec($query);
     	}
    
      	function getSomaDespesasAnoMes($ano = null, $mes = null){
    		$dt_vencimento = new DateTime($ano.'-'.$mes.'-'.'01');
    		$ultimo_dia = cal_days_in_month(CAL_GREGORIAN, $mes, $ano);
    		$dt_ini = $dt_vencimento->format('Y-m-01');
    		$dt_fim = $dt_vencimento->format('Y-m-'.$ultimo_dia);
    		$query = "
    			SELECT distinct
    				sum(valor) valor_total
    			FROM
    				despesas desp
    			where
    				(desp.deleted = 0 or desp.deleted is null )";
    		$query .= " and desp.data_vencimento >= '$dt_ini' and desp.data_vencimento <= '$dt_fim'";
    		return $this->db->exec($query);
     	}
    
    	function getSomaDespesasAnoMesByPagamento($ano, $status = null){
    		$query = null;
    		$dt_ini = $ano.'-01-01';
    		$dt_fim = $ano.'-12-31';
    		$query = "
    			SELECT
    				sum(valor) valor_total,
    				sum(juros) juros_total,
    				sum(multa) multa_total,
    				sum(desconto) desconto_total,
    				sum(abatimento) abatimento_total,
    				sum(atualizacao_monetaria) atmon_total,
    				sum(outros_valores) outros_total,
    				DATE_FORMAT(data_pagamento, '%m') mes,
    				DATE_FORMAT(data_pagamento, '%Y') ano
    			FROM
    				despesas desp
    			where
    				(desp.deleted = 0 or desp.deleted is null )";
    		if($status){
    			$query .= " and status = '$status'";
    		}
    		$query .= " and desp.data_pagamento >= '$dt_ini' and desp.data_pagamento <= '$dt_fim' GROUP BY ano, mes order by mes, ano";
    		$query.'<br><br>';
    		return $this->db->exec($query);
    	}
    
      	function checkTotalLancamentos($id_occ, $id_ocg, $id_oco, $id_ocs, $ano, $mes){
          $dt_vencimento = new DateTime($ano.$mes.'01');
          $ultimo_dia = cal_days_in_month(CAL_GREGORIAN, $mes, $ano);
          $dt_ini = $dt_vencimento->format('Ym01');
          $dt_fim = $dt_vencimento->format('Ym'.$ultimo_dia);
          $query = "
              SELECT distinct
                  sum(valor) total_lancamentos
              FROM
                  despesas desp
              where
                  (desp.deleted = 0 or desp.deleted is null )";
    
          $query .= " and desp.id_centro_custo = $id_occ and desp.id_grupo = $id_ocg and desp.id_conta = $id_oco and desp.data_vencimento > '$dt_ini' and desp.data_vencimento <= '$dt_fim'";
          $query .= " order by desp.data_vencimento";
          return $this->db->exec($query);
      	}
    
      	function getDadosCalendario(){
    		$query = "SELECT REPLACE(REPLACE(REPLACE(FORMAT(sum(valor), 2),'.',';'),',','.'),';',',') valor_total, count(1) quantidade, status_autorizacao, data_vencimento FROM despesas where (deleted = 0 or deleted is null)  group by status_autorizacao, data_vencimento ";
    		return $this->db->exec($query);
    	}
    
    	function getCountFornecedorSoma($ano, $mes){
    		$query = " select distinct count(id_fornecedor) count_fornecedor, sum(valor) valor from despesas where (deleted = 0 or deleted is null) and status = 'pago' ";
    
    		if($ano && !$mes){
    			$dt_ini = $ano.'-01-01';
    			$dt_fim = $ano.'-12-31';
    		}elseif($ano && $mes){
    			$ultimo_dia = cal_days_in_month(CAL_GREGORIAN, $mes, $ano);
    			$dt_ini = $ano.'-'.$mes.'-01';
    			$dt_fim = $ano.'-'.$mes.'-'.$ultimo_dia;
    		}
    
    		if($ano || $mes){
    			$query .= " and data_vencimento >= '$dt_ini' and data_vencimento <= '$dt_fim' ";
    		}
    		return $this->db->exec($query);
    	}
    
    	function getDespesasPeriodo($tipo, $periodo_ini, $periodo_fim, $status = null){
    		$query = " select desp.*, occ.nome, occ.alias from despesas desp inner join orc_centro_custo occ on(desp.id_centro_custo = occ.id) where (desp.deleted = 0 or desp.deleted is null) ";
    		if('vencimento' == $tipo){
    			$query .= " and desp.data_vencimento >= '".$periodo_ini->format('Y-m-d')."' and desp.data_vencimento <= '".$periodo_fim->format('Y-m-d')."'";
    		}elseif('pagamento' == $tipo){
    			$query .= " and desp.data_pagamento >= '".$periodo_ini->format('Y-m-d')."' and desp.data_pagamento <= '".$periodo_fim->format('Y-m-d')."'";
    		}
    
    		if($status){
    			$query .= " and desp.status = '$status' ";
    		}
       		return $this->db->exec($query);
    	}
    
        function getDespesasEOrcamento($tipo, $periodo_ini, $periodo_fim, $status = null){
    		$query = " 
    			select 
    				desp.id,
    				desp.data_pagamento, 
    				desp.data_vencimento,
    				desp.valor,
    				occ.id id_diretoria,
    				occ.nome nome_diretoria,
    				ocg.id id_grupo,
    				ocg.nome nome_grupo,
    				oco.id id_conta,
    				oco.nome nome_conta
    			from 
    				despesas desp inner join 
    				orc_centro_custo occ on(desp.id_centro_custo = occ.id) inner join
    				orc_grupo ocg on(desp.id_grupo = ocg.id) left join
    				orc_conta oco on(desp.id_conta = oco.id)
    			where 
    				(desp.deleted = 0 or desp.deleted is null) 
    		";
    
    		if('vencimento' == $tipo){
    			$query .= " and desp.data_vencimento >= '".$periodo_ini->format('Y-m-d')."' and desp.data_vencimento <= '".$periodo_fim->format('Y-m-d')."'";
    		}elseif('pagamento' == $tipo){
    			$query .= " and desp.data_pagamento >= '".$periodo_ini->format('Y-m-d')."' and desp.data_pagamento <= '".$periodo_fim->format('Y-m-d')."'";
    		}
    
    		if($status){
    			$query .= " and desp.status = '$status' ";
    		}
    		$query .= " order by occ.nome, desp.data_vencimento asc ";
    		return $this->db->exec($query);
    	}
    
    	function getLastDespesa(){
    		$query = "select * from despesas where (deleted is null or deleted = 0) order by id desc limit 1";
    		return $this->db->exec($query);
    	}
    
    	function getLastIdDoc(){
    		$query = "select * from despesas d order by d.id_doc desc limit 1";
    		return $this->db->exec($query);
    	}
    
    	function getDespesasToRemessa(){
    		$args = func_get_args();
    		$query = "
    			SELECT
    				desp.id id_despesa,
    				desp.id_cm,
    				desp.id_doc,
    				desp.id_fornecedor,
    				desp.historico,
    				desp.parcelado,
    				desp.numero_parcelas,
    				desp.email_contato,
    				desp.data_pagamento,
    				desp.descricao,
    				desp.status,
    				desp.meio_pagamento,
    				desp.prioridade,
    				desp.tipo_cobranca,
    				desp.tipo,
    				desp.valor,
    				desp.data_vencimento,
    				desp.status_autorizacao,
    				desp.codigo_barra, 
    				desp.tipo_despesa,
    				desp.abatimento,
    				desp.desconto,
    				desp.juros,
    				desp.multa,
    				desp.descricao,
    				desp.codigo_receita,
    				desp.numero_referencia,
    				desp.atualizacao_monetaria,
    				desp.percentual_receita,
    				desp.codigo_tributo,
    				desp.competencia,
    				desp.outros_valores,
    				desp.divida_ativa,
    				desp.numero_parcelas,
    				desp.parcela_numero,
    				desp.identificacao_contribuinte,
    				ev.cnpj cnpj_cm,
    				ev.razao_social nome_cm,
    				ev.inscricao_estadual ie_cm,
    				ev.inscricao_municipal im_cm,
    				frd.cnpj_cpf,
    				frd.tipo tipo_empresa_fornecedor,
    				frd.inscricao_estadual ie_fornecedor,
    				frd.razao_social nome_fornecedor,
    				frd.nome_fantasia,
    				frd.endereco,
    				frd.numero,
    				frd.complemento,
    				frd.bairro,
    				frd.cidade,
    				frd.estado,
    				frd.cep,
    				desp.id_grupo,
    				desp.id_conta,
    				desp.id_subconta,
    				desp.id_centro_custo,
    				grp.nome nome_grupo,
    				con.nome nome_conta,
    				sub.nome nome_subconta,
    				occ.nome nome_centro_custo
    			FROM 
    				despesas desp LEFT join
    				empresa_vendedora ev ON(ev.id = desp.id_cm) LEFT join
    				fornecedores frd ON(frd.id = desp.id_fornecedor) left join
    				orc_centro_custo occ on(desp.id_centro_custo = occ.id) left join
    				orc_grupo grp on(grp.id = desp.id_grupo) left join
    				orc_conta con on(con.id = desp.id_conta) left join
    				orc_conta sub on(sub.id = desp.id_subconta)
    			where
    					(desp.deleted = 0 or desp.deleted is null)
    		";
    
    		if(is_array($args[0])){
    			$query .= " and desp.id in(".implode(',', $args[0]).") ";
    		}elseif(!is_array($args[0]) && !empty($args[0])){
    			$query .= " and desp.id = ".$args[0];
    		}
    
    		if(isset($args[1]) && !empty($args[1])){
    			$query .= " and desp.data_vencimento >= '".$args[1]."'";
    		}
    		
    		if(isset($args[2]) && !empty($args[2])){
    			$query .= " and desp.data_vencimento <= '".$args[2]."'";
    		}
    		
    		if(isset($args[3]) && !empty($args[3])){
    			$query .= " and desp.status_autorizacao = '".$args[3]."'";
    		}
    		
    		if(isset($args[4]) && is_array($args[4])){
    			$query .= " and desp.status_remessa in('".implode("','", $args[4])."') ";
    		}elseif(isset($args[4]) && !empty($args[4])){
    			$query .= " and desp.status_remessa = '".$args[4]."'";
    		}
    
    		if(isset($args[5]) && !empty($args[5])){
    			$query .= " and desp.status = '".$args[5]."'";
    		}
    		return $this->db->exec($query);
    	}
    
    	function getDespesasRemessaIdDoc(){
    		$args = func_get_args();
    		$query = "
    			select 
    
    				ra.id id_remessa,
    				ra.data_gravacao,
    				ra.codigo_arquivo,
    				ra.codigo_banco,
    				ra.codigo_empresa,
    				ra.modalidade,
    				ra.nome_arquivo,
    				ra.nome_empresa,
    				d.id id_despesa,
    				d.data_vencimento,
    				d.data_vencimento,
    				d.data_vencimento,
    				d.status,
    				d.status_autorizacao,
    				d.status_remessa,
    				d.arquivo_retorno,
    				d.ocorrencias_cnab
    			FROM 
    				remessa_arquivo ra left join
    				remessa_detalhe rd on(ra.id  = rd.id_remessa) left join 
    				despesas d on(d.id = rd.id_despesa)
    			WHERE 
    				(ra.deleted is null or ra.deleted = 0)
    		";
    
    		if(is_array($args[0])){
    			$query .= " and d.id_doc in(".implode(',', $args[0]).") ";
    		}elseif($args[0]){
    			$query .= " and d.id_doc = ".$args[0];
    		}
    		$query .= " limit 1 ";
    		return $this->db->exec($query);
    	}
    
    	function getRemessasEDespesas(){
    		$args = func_get_args();
    		$query = "
    			select 
    				ra.id id_remessa,
    				ra.data_gravacao,
    				ra.codigo_arquivo,
    				ra.codigo_banco,
    				ra.codigo_empresa,
    				ra.modalidade,
    				ra.nome_arquivo,
    				ra.nome_empresa,
    				d.id id_despesa,
    				d.data_vencimento,
    				d.data_vencimento,
    				d.data_vencimento,
    				d.status,
    				d.status_autorizacao,
    				d.status_remessa,
    				d.arquivo_retorno,
    				d.ocorrencias_cnab
    			FROM 
    				remessa_arquivo ra inner join
    				remessa_detalhe rd on(ra.id  = rd.id_remessa) inner join 
    				despesas d on(d.id = rd.id_despesa)
    			WHERE 
    				(ra.deleted is null or ra.deleted = 0) and
    				d.status = 'aberto'
    		";
    
    		if(isset($args[0])){
    			$query .= " and ra.id = ". $args[0];
    		}
    
    		if(isset($args[1])){
    			$query .= " and ra.codigo_arquivo = ". $args[1];
    		}
    
    		if(isset($args[2])){
    			$query .= " and ra.codigo_banco = ". $args[2];
    		}
    		return $this->db->exec($query);
    	}
    
    	function getRemessaByCodigoArquivo(){
    		$args = func_get_args();
    		$query = "
    			select 
    				*
    			FROM 
    				remessa_arquivo ra
    			WHERE 
    				(ra.deleted is null or ra.deleted = 0)
    		";
    
    		if(isset($args[0])){
    			$query .= " and ra.codigo_arquivo = ". $args[0];
    		}
    		return $this->db->exec($query);
    	}
    
    	function getDespesaByOrcamento(){
    		$args = func_get_args();
    		/*
    			$args[0] = data inicial
    			$args[1] = data final
    			$args[2] = id do centro de custo
    			$args[3] = id do grupo
    			$args[4] = id da conta
    			$args[5] = id da subconta
    		*/
    		$query = "
    			select 
    				desp.data_vencimento,
    				desp.valor,
    				ev.razao_social,
    				occ.nome centro_custo,
    				grp.nome grupo,
    				con.nome conta,
    				sub.nome subconta,
    				desp.status_autorizacao
    			from 
    				despesas desp inner join
    				empresa_vendedora ev on(ev.id = desp.id_cm) inner join
    				fornecedores frd on(frd.id = desp.id_fornecedor) inner join
    				orc_centro_custo occ on(desp.id_centro_custo = occ.id) inner join
    				orc_grupo grp on(grp.id = desp.id_grupo) inner join
    				orc_conta con on(con.id = desp.id_conta) inner join
    				orc_conta sub on(sub.id = desp.id_subconta)
    			where
    				(desp.deleted is null or desp.deleted = 0)
    		";
    
    		if($args[0]){
    			$query .= " and desp.data_vencimento >= '".$args[0]."' ";
    		}
    
    		if($args[1]){
    			$query .= " and desp.data_vencimento <= '".$args[1]."' ";
    		}
    		$query .= " order by desp.data_vencimento ";
    		return $this->db->exec($query);
    	}
    
    	function getDespesaByFornecedor($id_fornecedor, $data_vencimento, $valor){
    		$query = "
    			SELECT 
    				*
    			FROM 
    				despesas
    			WHERE
    				(deleted is null or deleted = 0)
    		";
    
    		if($id_fornecedor){
    			$query .= " and id_fornecedor = $id_fornecedor ";
    		}
    
    		if($data_vencimento){
    			$query .= " and data_vencimento = '$data_vencimento' ";
    		}
    
    		if($valor){
    			$query .= " and valor = $valor ";
    		}
    		return $this->db->exec($query);
    	}
    
    	function getDespesasAnoResume($dt_ini, $dt_fim, $status, $autorizacao, $tipo_data = 'vencimento'){
    		$query = "
    			SELECT
    				sum(valor) valor_total,
    				sum(atualizacao_monetaria) atmon_total,
    				sum(juros) juros_total,
    				sum(multa) multa_total,
    				sum(outros_valores) outros_total,
    				sum(desconto) desconto_total,
    				sum(abatimento) abatimento_total,
    		";
    
    		if('vencimento' == $tipo_data){
    			$query .= "
    				DATE_FORMAT(data_vencimento, '%m') mes,
    				DATE_FORMAT(data_vencimento, '%Y') ano
    			";
    		}
    
    		if('pagamento' == $tipo_data){
    			$query .= "
    				DATE_FORMAT(data_pagamento, '%m') mes,
    				DATE_FORMAT(data_pagamento, '%Y') ano
    			";
    		}
    
    		$query .="  FROM
    						despesas desp
    					where
    						(desp.deleted = 0 or desp.deleted is null )
    		";
    
    		if($dt_ini){
    			if('vencimento' == $tipo_data){
    				$query .= " and desp.data_vencimento >= '$dt_ini' ";
    			}elseif('pagamento' == $tipo_data){
    				$query .= " and desp.data_pagamento >= '$dt_ini' ";
    			}
    		}
    
    		if($dt_fim){
    			if('vencimento' == $tipo_data){
    				$query .= " and desp.data_vencimento <= '$dt_fim' ";
    			}elseif('pagamento' == $tipo_data){
    				$query .= " and desp.data_pagamento <= '$dt_fim' ";
    			}
    		}
    		
    		if($status){
    			$query .= " and status = '$status' ";
    		}
    
    		if($autorizacao){
    			$query .= " and status_autorizacao = '$autorizacao' ";
    		}
    		
    		$query .= "
    			GROUP BY 
    				ano, 
    				mes 
    			order by 
    				mes, ano
    		";
    		return $this->db->exec($query);
    	}
    
    	function getSomaDespesaByPeriodo($dt_ini, $dt_fim, $status, $autorizacao, $tipo_data = 'vencimento'){
    		$query = "
    			SELECT
    				sum(valor) valor_total,
    				sum(atualizacao_monetaria) atmon_total,
    				sum(juros) juros_total,
    				sum(multa) multa_total,
    				sum(outros_valores) outros_total,
    				sum(desconto) desconto_total,
    				sum(abatimento) abatimento_total
    			FROM 
    				despesas desp 
    			where
    				(desp.deleted = 0 or desp.deleted is null)
    		";
    
    		if($status){
    			$query .= " and desp.status = '$status' ";
    		}
    
    		if($autorizacao){
    			$query .= " and desp.status_autorizacao = '$autorizacao' ";
    		}
    
    		if($dt_ini){
    			if('vencimento' == $tipo_data){
    				$query .= " and desp.data_vencimento >= '$dt_ini' ";
    			}elseif('pagamento' == $tipo_data){
    				$query .= " and desp.data_pagamento >= '$dt_ini' ";
    			}
    		}
    
    		if($dt_fim){
    			if('vencimento' == $tipo_data){
    				$query .= " and desp.data_vencimento <= '$dt_fim' ";
    			}elseif('pagamento' == $tipo_data){
    				$query .= " and desp.data_pagamento <= '$dt_fim' ";
    			}
    		}
    		return $this->db->exec($query);
    	}
    	
    	function getDespesasAbertas($ano){
    		$query = "
    			SELECT 
    				desp.*,
    				fr.razao_social nome_fornecedor
    			FROM 
    				despesas desp inner join
    				fornecedores fr on(desp.id_fornecedor = fr.id)
    			WHERE
    				(desp.deleted is null or desp.deleted = 0) and
    				desp.status = 'aberto' and
    				YEAR(desp.data_vencimento) = $ano AND 
    				MONTH(desp.data_vencimento) <= MONTH(CURRENT_DATE - INTERVAL 1 MONTH)
    				order by desp.data_vencimento ASC
    		";
    		return $this->db->exec($query);
    	}
    }
