<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */

class EmpresasModel extends MainModel{
    public function __construct($controller = null ){
        $this->table = 'empresa_vendedora';
        parent::__construct($controller);
    }

    function getEmpresa($id = null){
        $query = " select * from empresa_vendedora where (deleted is null or deleted = 0) and status = 'ativo' ";
        if($id){
            $query .= " and id = $id ";
        }
        $query .= " order by razao_social ";
        return $this->db->exec($query);
    }
}