<?php
	/**
	 * Created by PhpStorm.
	 * User: julio.gomes
	 * Date: 14/10/2016
	 * Time: 15:57
	 */
	class FaturamentoModel extends MainModel{
		//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
		public $table;
		public function __construct( $controller = null ){
			$this->table = 'faturamento';
			parent::__construct($controller);
		}

		function getFaturamentoPeriodo($tipo, $periodo_ini, $periodo_fim, $status = null){
			$query = " select * from notas_fiscais nf inner join contratos co on(co.id = nf.id_contrato) where (nf.deleted = 0 or nf.deleted is null) ";

			if(!$status){
				$query .= " and nf.status != 'cancelado' and nf.status != 'descartado'";
			}

			if('vencimento' == $tipo){
				$query .= " and nf.data_vencimento >= '".$periodo_ini->format('Y-m-d')."' and nf.data_vencimento <= '".$periodo_fim->format('Y-m-d')."'";
			}elseif('emissao' == $tipo){
				$query .= " and nf.data_emissao >= '".$periodo_ini->format('Y-m-d')."' and nf.data_emissao <= '".$periodo_fim->format('Y-m-d')."'";
			}elseif('recebimento' == $tipo){
				$query .= " and nf.recebido_em >= '".$periodo_ini->format('Y-m-d')."' and nf.recebido_em <= '".$periodo_fim->format('Y-m-d')."'";
			}
			return $this->db->exec($query);
		}

		function getFaturamentoPorId($id_faturamento){
			$query = "
				select
					t1.id id_faturamento,
					t1.id_contrato,
					t1.id_empresa_vendedora,
					t4.razao_social empresa_vendedora,
					t4.cnpj cnpj_cm,
					t4.inscricao_estadual ie_cm,
					t4.inscricao_municipal im_cm,
					t4.endereco endereco_cm,
					t4.numero numero_cm,
					t4.complemento complemento_cm,
					t4.cep cep_cm,
					t4.bairro bairro_cm,
					t4.cidade cidade_cm,
					t4.estado estado_cm,
					t2.razao_social cliente,
					t2.cnpj cnpj_cliente,
					t2.endereco endereco_cliente,
					t2.numero numero_cliente,
					t2.complemento complemento_cliente,
					t2.bairro bairro_cliente,
					t2.email_nf,
					t2.cep cep_cliente,
					t2.cidade cidade_cliente,
					t2.estado estado_cliente,
					t3.codigo codigo_produto,
					t3.nome nome_produto,
					t5.id id_modulo,
					t5.descricao nome_modulo,
					t5.codigo codigo_modulo,
					t1.ano_mes_referencia,
					t1.data_vencimento,
					t2.data_corte_faturamento,
					t2.numero_dias_apos_corte,
					t2.codigo_cliente,
					t1.periodo_de,
					t1.periodo_ate,
					t1.data_vencimento,
					t1.ultimo_reajuste,
					t1.data_faturamento,
					t1.qtd_transacoes,
					t1.valor_liquido,
					t1.valor_total,
					t1.qtd_horas total_horas,
					t1.tipo
				from
					$this->table t1 inner join
					contratos t2 on(t1.id_contrato = t2.id)  inner join
					produtos t3 on(t1.id_produto = t3.id) inner join
					empresa_vendedora t4 on(t1.id_empresa_vendedora = t4.id) inner join
					modulos_tarifaveis t5 on(t1.id_modulo = t5.id)
				where
					t1.deleted = 0 and
					t2.status = 'ativo' and
					t1.id = $id_faturamento
			";
			$exec = $this->db->query($query);
			if($exec){
			// Retorna
			$return = $exec->fetchAll();
				return json_encode($return);
			}else{
				return false;
			}
		}

		function getFaturamentoResume( 
			$id_contrato = null, 
			$status = 'faturar', 
			$group = true, 
			$codigo_produto = null, 
			$codigo_modulo = null, 
			$ano_mes_referencia = null, 
			$tipo = null
		){
			$query = "
				select
					t2.cnpj cnpj_cliente,
					t1.id_contrato,
					t1.data_faturamento,
					t4.id id_empresa_vendedora,
					t4.cnpj cnpj_cm,
					t4.razao_social razao_social_cm,
					t4.inscricao_estadual ie_cm,
					t4.inscricao_municipal im_cm,
					t4.endereco endereco_cm,
					t4.numero numero_cm,
					t4.complemento complemento_cm,
					t4.bairro bairro_cm,
					t4.cep cep_cm,
					t4.cidade cidade_cm,
					t4.estado uf_cm,
					t2.cnpj cnpj_cliente,
					t2.codigo_cliente,
					t2.razao_social razao_social_cliente,
					t2.inscricao_estadual ie_cliente,
					t2.endereco endereco_cliente,
					t2.numero numero_cliente,
					t2.complemento complemento_cliente,
					t2.bairro bairro_cliente,
					t2.cep cep_cliente,
					t5.mes_reajuste,
					t2.cidade cidade_cliente,
					t2.estado uf_cliente,
					t2.email_nf,
					t2.vencimento_todo_dia,
					t3.codigo codigo_produto,
					t3.nome nome_produto,
					t1.ano_mes_referencia,
					t1.data_vencimento,
					t1.periodo_de,
					t1.periodo_ate,
					t5.tipo_indice,
					t1.observacoes,
					tipo,
			";

			if(!$group){
				$query .= "
				t1.valor_total,
				t1.qtd_transacoes qtd_transacoes,
				t1.qtd_horas,
				t1.codigo_modulo,
				t1.id_modulo,
				t1.id id_faturamento ";
			}else{
				$query .= "
					sum(t1.valor_total) valor_total,
					sum(t1.qtd_transacoes) qtd_transacoes,
					sum(t1.qtd_horas) qtd_horas";
			}

			$query .= "
				from
					$this->table t1 inner join
					contratos t2 on(t1.id_contrato = t2.id)  inner join
					produtos t3 on(t1.id_produto = t3.id) inner join
					empresa_vendedora t4 on(t1.id_empresa_vendedora = t4.id) inner join
					contrato_aniversario t5 on(t5.id_contrato = t2.id)
				where
					t1.deleted = 0 and
					t2.status = 'ativo' and
					t1.status = '$status'
			";

			if($tipo){
				$query .= " and t1.tipo = '$tipo' ";
			}

			if($id_contrato){
				$query .= " and t1.id_contrato = $id_contrato ";
			}

			if($codigo_produto){
				$query .= " and t1.codigo_produto = '$codigo_produto' ";
			}

			if($codigo_modulo){
				$query .= " and t1.codigo_modulo = '$codigo_modulo' ";
			}

			if($ano_mes_referencia){
				$query .= " and t1.ano_mes_referencia = '$ano_mes_referencia' ";
			}

			if($tipo){
				$query .= " and t1.tipo = '$tipo' ";
			}

			if($group){
				$query .= "
					group by
					t1.id_contrato,
					t4.razao_social,
					t2.razao_social,
					t3.nome,
					t1.ano_mes_referencia,
					t1.data_vencimento,
					t1.tipo
				";
			}
			$exec = $this->db->query($query);
			if($exec){
			// Retorna
			$return = $exec->fetchAll();
				return json_encode($return);
			}else{
				return false;
			}
		}

		function getFaturamentoComissoes($filter = null){
			$query = "
				SELECT distinct
					nf.numero_fatura,
					nf.cliente,
					nf.codigo_produto,
					fc.id_contrato,
					fc.id id_comissao,
					fc.id_nf,
					tipo_comissao,
					fc.percentual_comissao,
					fc.valor_nota,
					fc.valor_comissao,
					fc.status,
					fc.pago_em,
					fc.id_diretor,
					fc.id_vendedor,
					ven.nome nome_vendedor,
					dc.nome nome_diretor,
					nf.data_vencimento,
					pr.nome nome_produto
				FROM
					faturamento_comissoes fc left join 
					vendedores ven on(fc.id_vendedor = ven.id) left join
					diretor_comercial dc on(fc.id_diretor = dc.id) left join
					notas_fiscais nf on(fc.id_nf = nf.id) left join
					produtos pr on(pr.codigo =  nf.codigo_produto)
				where
				(fc.deleted = 0 or fc.deleted is null) and
				(ven.deleted = 0 or ven.deleted is null) and
				(dc.deleted = 0 or dc.deleted is null)	and
				(nf.deleted = 0 or nf.deleted is null) and 
				nf.id is not null and 
				nf.status = 'recebido'
			";

			if($filter){
				$query.= " and fc.status = '$filter' ";
			}
			$query .= ' order by nf.data_vencimento ';
			$exec = $this->db->query($query);
			if($exec){
			// Retorna
			$return = $exec->fetchAll();
				return json_encode($return);
			}else{
				return false;
			}
		}

		function getFaturamentoPorCliente($id_contrato, $ano_mes = null, $status = null, $tipo = null){
			$query = "
				select
					t1.id id_faturamento,
					t1.id_contrato,
					t1.id_empresa_vendedora,
					t4.razao_social empresa_vendedora,
					t4.cnpj cnpj_cm,
					t4.inscricao_estadual ie_cm,
					t4.inscricao_municipal im_cm,
					t4.endereco endereco_cm,
					t4.numero numero_cm,
					t4.complemento complemento_cm,
					t4.cep cep_cm,
					t4.bairro bairro_cm,
					t4.cidade cidade_cm,
					t4.estado estado_cm,
					t2.razao_social cliente,
					t2.cnpj cnpj_cliente,
					t2.endereco endereco_cliente,
					t2.numero numero_cliente,
					t2.complemento complemento_cliente,
					t2.bairro bairro_cliente,
					t2.email_nf,
					t2.cep cep_cliente,
					t2.cidade cidade_cliente,
					t2.estado estado_cliente,
					t3.codigo codigo_produto,
					t3.nome nome_produto,
					t5.id id_modulo,
					t5.descricao nome_modulo,
					t5.codigo codigo_modulo,
					t1.ano_mes_referencia,
					t1.data_vencimento,
					t2.data_corte_faturamento,
					t2.numero_dias_apos_corte,
					t2.codigo_cliente,
					t1.periodo_de,
					t1.periodo_ate,
					t1.data_vencimento,
					t1.ultimo_reajuste,
					t1.data_faturamento,
					t1.qtd_transacoes,
					t1.valor_liquido,
					t1.valor_total,
					t1.qtd_horas total_horas,
					t1.tipo
				from
					$this->table t1 inner join
					contratos t2 on(t1.id_contrato = t2.id)  inner join
					produtos t3 on(t1.id_produto = t3.id) inner join
					empresa_vendedora t4 on(t1.id_empresa_vendedora = t4.id) inner join
					modulos_tarifaveis t5 on(t1.id_modulo = t5.id)
				where
					t1.deleted = 0 and
					t2.status = 'ativo' and
					t1.id_contrato = $id_contrato
			";

			if($ano_mes){
				$query .= " and t1.ano_mes_referencia = '$ano_mes'";
			}

			if($status){
				$query .= " and t1.status = '$status'";
			}

			if($tipo){
				$query .= " and t1.tipo = '$tipo'";
			}

			$exec = $this->db->query($query);
			if($exec){
			// Retorna
			$return = $exec->fetchAll();
				return json_encode($return);
			}else{
				return false;
			}
		}

		// funcoes novas inclusas em 2017-11-06
		function getContratosPorFaturamento($id_contrato = null, $id_produto = null, $codigo_produto = null, $dia_corte_de = null, $dia_corte_ate = null, $ignore_adm = 0){
			$query = "
				select
					co.id id_contrato,
					co.cnpj,
					co.nome_fantasia,
					co.razao_social,
					co.data_corte_faturamento,
					co.vencimento_todo_dia,
					co.numero_dias_apos_corte,
					co.tipo_tarifacao,
					co.codigo_cliente,
					co.isento_de ,
					co.isento_ate,
					co.carencia_de_uso,
					co.ultima_data_demo,
					co.data_primeiro_faturamento,
					ev.razao_social empresa_cm,
					pr.id id_produto,
					pr.codigo codigo_produto,
					pr.nome nome_produto,
					nf.data_vencimento,
					nf.numero,
					nf.numero_fatura,
					nf.periodo_de,
					nf.periodo_ate,
					nf.ano_mes_referencia,
					nf.quantidade,
					nf.valor_total,
					nf.total_horas
				from
					contratos co inner join
					produtos pr on(co.id_produto = pr.id) inner JOIN
					empresa_vendedora ev on(ev.id = co.id_empresa) left join
					contrato_aniversario coa on(coa.id_contrato = co.id) left JOIN
					(
						select
							nf.id_contrato,
							nf.numero,
							nf.numero_fatura,
							nf.periodo_ate,
							nf.periodo_de,
							nf.ano_mes_referencia,
							nf.data_vencimento,
							nf.valor_total,
							nf.quantidade,
							nf.total_horas
						from
							notas_fiscais nf
						where
							(nf.deleted = 0 or nf.deleted is NULL) AND
							nf.status != 'cancelado' and
							nf.status != 'cancelada'
						group by
							nf.id_contrato
					) nf on(nf.id_contrato = co.id)
				where
					(co.deleted = 0 or co.deleted is null) and
					co.status = 'ativo' 
				";

			if($id_contrato){
				$query .= " and co.id = $id_contrato";
			}

			if($dia_corte_de){
				$query .= " and co.data_corte_faturamento >= $dia_corte_de";
			}

			if($dia_corte_ate){
				$query .= " and co.data_corte_faturamento <= $dia_corte_ate";
			}

			if($ignore_adm == 0){
				$query .= " and pr.codigo != 'ADM0001'";
			}

			$query .= " order BY
				co.nome_fantasia,
				pr.nome,
				nf.periodo_ate desc,
				nf.periodo_de desc,
				nf.ano_mes_referencia desc,
				nf.data_vencimento desc
			";
			$exec = $this->db->query($query);
			if($exec){
				// Retorna
				$return = $exec->fetchAll();
					return json_encode($return);
			}else{
					return false;
			}
		}

		function getFaturamentoPorPeriodo($dt_ini, $dt_fim, $id_contrato = null, $codigo_produto = null, $codigo_modulo = null, $status = null){
			$query = "
				select
					*
				from
					faturamento fat
				where
					(fat.deleted is null or fat.deleted = 0) and
					fat.periodo_de  >= '$dt_ini' and
					fat.periodo_ate <= '$dt_fim'
			";

			if(!$status){
				$query .= " and fat.status != 'cancelado' ";
			}

			if($id_contrato){
				$query .= " and fat.id_contrato = $id_contrato ";
			}

			if($codigo_produto){
				$query .= " and fat.codigo_produto = '$codigo_produto' ";
			}

			if($codigo_modulo){
				$query .= " and fat.codigo_modulo = '$codigo_modulo' ";
			}
			return $this->db->exec($query);
		}

		//Obtem o faturamento do periodo de com valores calculados;
		function faturamentoByPeriodo($id_contrato = null, $dt_ini, $dt_fim){
			$query = " select * from faturamento fat where (fat.deleted = 0 or fat.deleted is null) and fat.status != 'cancelado' and fat.status != 'descartado' ";
			if($id_contrato){
				$query .= " and id_contrato = '$id_contrato' ";
			}
			$query .= " and periodo_de  >= '$dt_ini' ";
			$query .= " and periodo_ate <= '$dt_fim' ";
			return $this->db->exec($query);
		}

		function getSomaPorDataFaturamento($id_contrato = null, $dt_ini, $dt_fim){
			$query = " select sum(valor_total) valor_total from faturamento fat where (fat.deleted = 0 or fat.deleted is null) and fat.status != 'cancelado' and fat.status != 'descartado' ";
			if($id_contrato){
				$query .= " and id_contrato = '$id_contrato' ";
			}
			$query .= " and data_faturamento >= '$dt_ini' ";
			$query .= " and data_faturamento <= '$dt_fim' ";
			return $this->db->exec($query);
		}


		function getFaturamentoPorAno($ano, $view = null, $id_contrato = null, $ativos = false, $mes = null){
			
			// alterado por julio
			// correção feita para corrigir o calculo exibido no faturamento mensal do bugdet
			// sum(valor_total)+sum(valor_desconto)valor_total,
			
			$dt_ini = $ano.'-01-01';
			$dt_fim = $ano.'-12-31';
			$query = "
				select
					sum(valor_total) valor_total,
					DATE_FORMAT(nf.data_emissao,'%Y') ano,
					DATE_FORMAT(nf.data_emissao,'%m') mes
				from
					notas_fiscais nf inner join
					contratos co on(co.id = nf.id_contrato)
				where (nf.deleted = 0 or nf.deleted is null) and
					nf.status != 'cancelado' and
					nf.status != 'descartado' and
					(co.deleted = 0 or co.deleted is null)
			";

			if($id_contrato){
				$query .= " and co.id = $id_contrato ";
			}

			if($ativos){
				//$query .= " and co.status = 'ativo' ";
			}

			$query .= " and nf.data_emissao >= '$dt_ini' ";
			$query .= " and nf.data_emissao <= '$dt_fim' ";

			if($view == 'global'){
				$query .= " and co.data_assinatura < '$dt_ini' ";
			}elseif($view == 'comercial'){
				$query .= " and co.data_assinatura >= '$dt_ini' ";
				$query .= " and co.data_assinatura <= '$dt_fim' ";
			}elseif($view == 'upselling'){
				$query .= " and co.upselling	= 1 ";
			}

			$query .= " group by ano, mes order by ano, mes asc ";
			$exec  = $this->db->query($query);
			if($exec){
				// Retorna
				$return = $exec->fetchAll();
				return json_encode($return);
			}else{
				return false;
			}
		}

		function getFaturamentoClientePorAno($ano, $view = null, $codigo_cliente = null, $ativos = false){
			$dt_ini = $ano.'-01-01';
			$dt_fim = $ano.'-12-31';
			$query = "
				select
					sum(valor_total) valor_total,
					DATE_FORMAT(nf.data_emissao,'%Y') ano,
					DATE_FORMAT(nf.data_emissao,'%m') mes
				from
					notas_fiscais nf inner join
					contratos co on(co.codigo_cliente = nf.codigo_cliente)
				where (nf.deleted = 0 or nf.deleted is null) and nf.status = 'recebido'
			";

			if($codigo_cliente){
				$query .= " and co.codigo_cliente = '$codigo_cliente' ";
			}

			if($ativos){
				$query .= " and co.status = 'ativo' ";
			}

			$query .= " and nf.data_emissao >= '$dt_ini' ";
			$query .= " and nf.data_emissao <= '$dt_fim' ";

			if($view == 'global'){
				$query .= " and co.data_assinatura <= '$dt_ini' ";
			}elseif($view == 'comercial'){
				$query .= " and co.data_assinatura >= '$dt_ini' ";
				$query .= " and co.data_assinatura <= '$dt_fim' ";
			}elseif($view == 'upselling'){
				$query .= " and co.upselling	= 1 ";
			}

			$query .= " group by ano, mes ";
			$query .= " order by ano, mes asc";
			return $this->db->exec($query);
		}

		function getFaturamentoUpsellingPorAno($ano, $view = null, $id_contrato = null){
			$dt_ini = $ano.'-01-01';
			$dt_fim = $ano.'-12-31';
			$query = "
				select
					nf.id_contrato,
					sum(valor_total) valor_total,
					DATE_FORMAT(nf.data_emissao,'%Y') ano,
					DATE_FORMAT(nf.data_emissao,'%m') mes
				from
					notas_fiscais nf inner join
					contratos co on(co.id = nf.id_contrato)
				where (nf.deleted = 0 or nf.deleted is null) and nf.status != 'cancelado' and nf.status != 'descartado'
			";

			if($id_contrato){
				$query .= " and id_contrato = $id_contrato ";
			}

			$query .= " and nf.data_emissao >= '$dt_ini' ";
			$query .= " and nf.data_emissao <= '$dt_fim' ";

			if($view == 'global'){
				$query .= " and co.data_assinatura <= '$dt_ini' ";
			}elseif($view == 'comercial'){
				$query .= " and co.data_assinatura >= '$dt_ini' ";
				$query .= " and co.data_assinatura <= '$dt_fim' ";
			}elseif($view == 'upselling'){
				$query .= " and co.upselling = 1 ";
			}

			$query .= "group by ano, mes order by ano, mes";
			return $this->db->exec($query);
		}

		function getFaturamentoPorAnoVendedor($ano){
			$dt_ini = $ano.'-01-01';
			$dt_fim = $ano.'-12-31';
			$query = "
				select
					sum(valor_total) valor,
					DATE_FORMAT(nf.data_emissao,'%Y') ano,
					DATE_FORMAT(nf.data_emissao,'%m') mes,
					ven.nome nome_vendedor
				from
					notas_fiscais nf inner join comissoes com on
					(
						com.id_contrato = nf.id_contrato
					) inner join vendedores ven on
					(
						ven.id = com.id_vendedor
					) inner join contratos co on
					(
						co.id = nf.id_contrato
					)
				where
					(nf.deleted = 0 or nf.deleted is null) and
					nf.status = 'recebido' and
					ven.status = 'ativo' and
					co.data_assinatura >= '$dt_ini'	and
					co.data_assinatura <= '$dt_fim'
				group by
					ano,
					mes,
					ven.nome
				order by
					ven.nome asc,
					ano asc,
					mes asc
			";
			return $this->db->exec($query);
		}

		function getMulta( $id_contrato = null , $status = 'pendente'){
			$query = "select * from mov_diario_aux where (deleted = 0 or deleted is null) ";
			if($id_contrato){
				$query .= " and id_contrato = $id_contrato ";
			}
			
			if($status){
				$query .= " and status = 'pendente' ";
			}
			return $this->db->exec($query);
		}

		function getRestSumPacote($dt_ini, $dt_fim){
			$query = "
				select sum( preco_pkt ) valor from pacote_contratado pc inner join contratos co on(co.id = pc.id_contrato) where co.status = 'ativo' and co.codigo_cliente != 99999999 and (pc.deleted is null or pc.deleted = 0) and pc.status = 'ativo' and id_contrato not in(
					select DISTINCT id_contrato from notas_fiscais where data_emissao >= '$dt_ini' and data_emissao <= '$dt_fim' and status != 'cancelado' and status != 'descartado' and (deleted = 0 or deleted is null)
				);
			";
			return $this->db->exec($query);
		}

		function getSomaPacote($id_contrato = null, $view = null){
			$dt = new DateTime();
			$dt->setTimezone(new DateTimeZone('America/Sao_Paulo'));
			$ano_atual = $dt->format('Y');
			$query = "
				select
					sum( preco_pkt ) valor
				from
					pacote_contratado pc	inner join
					contratos co on(co.id = pc.id_contrato)
				where
					( pc.deleted = 0 or pc.deleted is null ) and
					( co.deleted = 0 or co.deleted is null ) and
					pc.status = 'ativo' and
					co.status = 'ativo'
			";

			if($id_contrato){
				$query .= " and id_contrato = $id_contrato";
			}

			if($view == 'comercial'){
				$query .= " and co.data_assinatura >= '".$ano_atual."-01-01' and co.data_assinatura <= '".$ano_atual."-12-31' ";
			}

			if($view == 'upselling'){
				$query .= " and co.upselling = 1";
			}
			$exec = $this->db->query($query);
			if($exec){
				// Retorna
				$return = $exec->fetchAll();
				return json_encode($return);
			}else{
				return false;
			}
		}
	}