<?php
	/**
	 * Created by PhpStorm.
	 * User: julio.gomes
	 * Date: 14/10/2016
	 * Time: 15:57
	*/
	class FaturasModel extends MainModel{
		public $table;
		public function __construct( $controller = null ){
			$this->table = 'nf_remessas';
			parent::__construct($controller);
		}

		function getGrupoRemessasByStep( $dt_ini, $dt_fim, $status, $cnpj_prestador = null ){
			$query = "
				SELECT
					rem.id id_remessa, 
					rem.cnpj_prestador, 
					rem.numero_remessa, 
					rem.status status_remessa, 
					rem.criado_em, 
					nf.prestador_servico, 
					nf.ano_mes_referencia, 
					nf.inscricao_municipal_prestador, 
					rem.data_remessa 
				FROM 
					nf_remessas rem inner join 
					notas_fiscais nf on(rem.id_nf = nf.id) 
				where 
					(rem.deleted is null or rem.deleted = 0) and
					rem.status = '$status'
			";
			
			if( $dt_ini ){
				$query .= " and rem.data_remessa >= '".$dt_ini->format('Y-m-d')."'";
			}

			if( $dt_fim ){
				$query .= " and rem.data_remessa <= '".$dt_fim->format('Y-m-d')."'";
			}

			if( $cnpj_prestador ){
				$query .= " and cnpj_prestador = '$cnpj_prestador' ";
			}

			$query .= " group by cnpj_prestador, numero_remessa, rem.criado_em, nf.prestador_servico, rem.data_remessa order by rem.numero_remessa desc,  rem.status ";
			return $this->db->exec( $query );
		}

		function getGrupoRemessas( $dt_ini = null, $dt_fim = null, $cnpj_prestador = null, $status = 'aberto' ){
			$query = "
				SELECT
					rem.id id_remessa, 
					rem.cnpj_prestador, 
					rem.numero_remessa, 
					rem.status status_remessa, 
					rem.criado_em, 
					nf.prestador_servico, 
					nf.ano_mes_referencia, 
					nf.inscricao_municipal_prestador, 
					rem.data_remessa 
				FROM 
					nf_remessas rem inner join 
					notas_fiscais nf on(rem.id_nf = nf.id) 
				where 
					(rem.deleted is null or rem.deleted = 0) 
			";

			if($status == 'check'){
				$query .= " and rem.status != 'error'";	
			}elseif($status != false && $status != 'todos'){
				$query .= " and rem.status = '$status' ";
			}
			
			if($dt_ini){
				$query .= " and rem.data_remessa >= '".$dt_ini->format('Y-m-d')."'";
			}

			if($dt_fim){
				$query .= " and rem.data_remessa <= '".$dt_fim->format('Y-m-d')."'";
			}

			if($cnpj_prestador){
				$query .= " and cnpj_prestador = '$cnpj_prestador' ";
			}

			$query .= " group by cnpj_prestador, numero_remessa, rem.criado_em, nf.prestador_servico, rem.data_remessa order by rem.numero_remessa desc,  rem.status ";
			return $this->db->exec( $query );
		}

		function getGrupoRemessasByPrestador( $cnpj_prestador, $numero_remessa){
			$query = "
				SELECT
					rem.cnpj_prestador, 
					rem.numero_remessa, 
					rem.status, 
					nf.prestador_servico, 
					nf.inscricao_municipal_prestador
				FROM 
					nf_remessas rem inner join 
					notas_fiscais nf on(rem.id_nf = nf.id) 
				where 
					(rem.deleted is null or rem.deleted = 0) 
			";

			if($cnpj_prestador){
				$query .= " and cnpj_prestador = '$cnpj_prestador' ";
			}

			if($numero_remessa){
				$query .= " and numero_remessa = '$numero_remessa' ";
			}
			$query .= " group by cnpj_prestador, numero_remessa, rem.status, nf.prestador_servico ";
			return $this->db->exec($query);
		}

		function getRemessa( $numero_remessa = null ){
			$query = "SELECT * FROM nf_remessas where deleted = 0 ";
			if( $numero_remessa ){ 
				$query .= " and numero_remessa = $numero_remessa ";
			}
			return $this->db->exec($query);
		}

		function getLastRemessa( $cnpj_prestador = null, $data_remessa = null){
			$query = "SELECT *  FROM nf_remessas where deleted = 0 ";
			if($cnpj_prestador){
				$query .= " and cnpj_prestador = $cnpj_prestador ";
			}

			if($data_remessa){
				$query .= " and data_remessa = '$data_remessa' ";
			}
			$query .= ' order by numero_remessa desc limit 1 ';
			return $this->db->exec($query);
		}

		function getLastRps( $cnpj_prestador = null, $ano = null ){
			$query = " SELECT *  FROM nf_remessas ";
			if($cnpj_prestador){
				$query .= " where cnpj_prestador = $cnpj_prestador ";
			}
			$query .= ' order by numero_rps desc limit 1 ';
			return $this->db->exec( $query );
		}

		function getRps( $cnpj_prestador = null, $data_remessa = null, $numero_rps = null ){
			$query = " SELECT * FROM nf_remessas where (deleted = 0 or deleted is null) ";
			if($cnpj_prestador){
				$query .= " and cnpj_prestador = $cnpj_prestador ";
			}

			if($data_remessa){
				$query .= " and data_remessa = '$data_remessa' ";
			}

			if($numero_rps){
				$query .= " and numero_rps = $numero_rps ";
			}
			return $this->db->exec( $query );
		}

		function customSave( $set_param, $where_fields, $where_values ){
			return $this->db->update( 'nf_remessas', $where_fields, $where_values, $set_param );
		}

		function infoEnvios( $empresa_origem, $id_origem ){
			if( !is_numeric( $empresa_origem ) || !is_numeric( $id_origem ) ){
				return false;
			}
			$query .= " select * from envios_arquivos where ( deleted is null or deleted = 0 ) and empresa_origem = $empresa_origem and id_origem = $id_origem ";
			return $this->db->exec( $query );
		}
		
		function getNfByRps( $cnpj_prestador, $numero_remessa, $numero_rps ){
			$param[0] = $cnpj_prestador;
			$param[1] = $numero_remessa;
			$param[2] = $numero_rps;
			$query = "
				SELECT
					*
				FROM
					notas_fiscais nf INNER join
					nf_remessas nr ON(nr.id_nf = nf.id )
				WHERE 
					( nf.deleted IS NULL OR nf.deleted = 0 ) and
					nf.cnpj_cpf_prestador = ? and
					nr.numero_remessa 	  = ? and
					nr.numero_rps 		  = ?
			";
			return $this->db->exec( $query, $param );
		}
	}