<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class FornecedoresModel extends MainModel{
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	public function __construct( $controller = null ){
		$this->table = 'fornecedores';
		parent::__construct($controller);
	}

	function getFornecedores($id = null){
		$query = " select * from fornecedores where (deleted = 0 or deleted is null) ";
		if($id){
			$query .= " and id = $id ";
		}
		$query.= " order by razao_social ";
		$exec = $this->db->query($query);
		if($exec){
		// Retorna
		$return = $exec->fetchAll();
			return json_encode($return);
		}else{
			return false;
		}
	}

	function chkRelationShip($id_fornecedor, $id_conta = null, $id_subconta = null){
		$query .= " select * from fornecedores_contas where (deleted = 0 or deleted is null) and id_fornecedor = $id_fornecedor ";
		if($id_conta){
			$query .= " and id_conta = $id_conta ";
		}
		if($id_subconta){
			$query .= " and id_subconta = $id_subconta ";
		}
		$exec = $this->db->query($query);
		if($exec){
		// Retorna
		$return = $exec->fetchAll();
			return json_encode($return);
		}else{
			return false;
		}
	}

	function getRelationShip($id_fornecedor, $id_conta = null, $id_subconta = null){
		$query = null;
		
		$query .= "
		
		select
			fc.id id_relationship,
			fcs.id id_fornecedor,
			occ.id id_conta,
			osc.id id_subconta,
			fcs.razao_social,
			occ.nome nome_conta,
			osc.nome nome_subconta
		from
			fornecedores_contas fc inner join
			fornecedores fcs on(fc.id_fornecedor = fcs.id) inner join
			orc_conta occ on(fc.id_conta = occ.id) inner join
			orc_conta osc on(fc.id_subconta = osc.id)
	 	where
	 		(fc.deleted = 0 or fc.deleted is null) and
			(occ.deleted = 0 or occ.deleted is null) and
			fc.id_fornecedor = $id_fornecedor
	 	";
		
		 if($id_conta){
			$query .= " and fc.id_conta = $id_conta ";
		}

		if($id_subconta){
			$query .= " and fc.id_subconta = $id_subconta ";
		}

		$query .= "
			order by
			occ.nome,
			osc.nome
		";

		$exec = $this->db->query($query);
		if($exec){
		// Retorna
		$return = $exec->fetchAll();
			return json_encode($return);
		}else{
			return false;
		}
	}

	function getFornecedoresByCpfCnpj($cpfCnpj){
		$query = " select * from fornecedores where (deleted = 0 or deleted is null) ";
		if($cpfCnpj){
			$query .= " and cnpj_cpf = '$cpfCnpj' "; 
		}else{
			return false;
		}
		return $this->db->exec($query);
	}
}
