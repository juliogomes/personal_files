<?php

/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class GedModel extends MainModel
{
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	public function __construct($controller = null)
	{
		$this->table = 'ged';
		parent::__construct($controller);
	}

	function getDocumentByCliente($codigo_cliente = null, $nome_fantasia = null, $owner = null)
	{
		$query = " select ged.*, pr.nome nome_produto from ged ged left join produtos pr on(pr.id = ged.codigo_produto) where (ged.deleted = 0 or ged.deleted is null) and ged.status = 'ativo' ";
		if ($codigo_cliente) {
			$query .= " and ged.codigo_cliente = $codigo_cliente ";
		}

		if ($nome_fantasia) {
			$query .= " and ged.nome_fantasia = '$nome_fantasia' ";
		}

		if ($owner) {
			$query .= " and ged.owner = '$owner' ";
		}
		return $this->db->exec($query);
	}

	function getDocument($id = null)
	{
		$query = " select * from ged where (deleted = 0 or deleted is null)";
		if ($id) {
			$query .= " and id = $id ";
		}
		return $this->db->exec($query);
	}

	function getDocumentByD4singId($uuid)
	{
		$query = " select * from ged where (deleted = 0 or deleted is null) and uuid_d4sign = '$uuid' ";
		return $this->db->exec($query);
	}

	function getDocumentclickSign($key, $doc_origem = null)
	{
		if ($key) {
			$query = "select 
				gcd.*,
				gc.doc_origem
			from 
				ged_clicksign_documento gcd inner join
				ged_anexo ga on(gcd.id_ged_anexo = ga.id) inner join
				ged_documento gc on(gc.id = ga.id_documento) 
			where 
				(gcd.deleted is null or gcd.deleted = 0) and
				gcd.document_key = '$key'
			";

			if ($doc_origem) {
				$query .= " and gc.doc_origem = '$doc_origem' ";
			}
			return $this->db->exec($query);
		} else {
			return false;
		}
	}

	function saveDocAssinado($param, $id)
	{
		if ($id && is_numeric($id)) {
			$this->setTable('ged_clicksign_documento');
			return $this->save($param, $id);
		} else {
			return false;
		}
	}

	function obtemModeloContratoAtivo($produto, $documento)
	{
		$query = "
		SELECT gd.id as gd_id, gd.alterado_em as atualizado_data, gd.*, ga.id as ga_id, ga.*, su.nome
		FROM ged_documento gd
		INNER JOIN 
		ged_anexo ga ON (gd.id = ga.id_documento)
		INNER JOIN sistema_usuarios su ON (su.id = gd.alterado_por)
			 WHERE
			 (ga.deleted = 0 OR ga.deleted IS null)
			 AND tipo = 'contrato'
			 AND subtipo = 'modelo de contrato'";

		if ($documento) {
			$query .= " AND gd.nome_documento = '$documento'";
		}

		$query .= "AND doc_origem = '$produto'
			 AND gd.deleted = 0
			 ORDER BY ga.id DESC";
		return $this->db->exec($query);
	}
}
