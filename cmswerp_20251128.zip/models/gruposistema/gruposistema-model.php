<?php

/**
 * User: luciano.silva
 * Date: 04/08/2025
 */
class GrupoSistemaModel extends MainModel
{
    public function __construct($controller = null)
    {
        parent::__construct($controller);
    }

    public function getAgrupamento($parametros)
    {
        $param[0] = $parametros['origem'];
        $param[1] = $parametros['id_origem'];
        $query = "
            select 
                gs.*,
                ge.id_elemento,
                ge.elemento_mestre 
            from
                grupos_sistema gs INNER join
                grupos_elementos ge ON(gs.id = ge.id_grupo)
            where
                (gs.deleted is null or gs.deleted = 0) and
                (ge.deleted is null or ge.deleted = 0) and
                gs.funcao = 'agrupamento' and
                gs.origem = ? and
                gs.id_origem = ?
        ";
        return $this->db->exec($query, $param);
    }

    public function getAgrupamentoOrigem($parametros)
    {
        $param[0] = $parametros['origem'];
        $param[1] = $parametros['id_origem'];
        $param[2] = $parametros['modulo_origem'];
        $param[3] = $parametros['id_objeto'];
        $query = "
            select 
                gs.*,
                ge.id id_elemento,
                ge.origem_elemento,
                ge.elemento_mestre,
			    go.id_objeto,
                go.modulo_origem,
                gr.campo,
                gr.operador,
                gr.valor_limite,
                gr.fonte_valor,
                gr.calculo,
                gr.acao,
                gr.comentario,
                gr.ativo
            from
                grupos_sistema gs INNER join
                grupos_elementos ge ON(gs.id = ge.id_grupo) INNER join
                grupos_objeto go ON(go.id_grupo = gs.id) inner join
                grupos_regras gr on(gr.id_grupo = gs.id)
            where
                (gs.deleted is null or gs.deleted = 0) and
                (ge.deleted is null or ge.deleted = 0) and
                gs.funcao = 'agrupamento' and
                gs.origem = ? and
                gs.id_origem = ? and
                go.modulo_origem = ? and
                go.id_objeto = ?
        ";
        return $this->db->exec($query, $param);
    }
}
