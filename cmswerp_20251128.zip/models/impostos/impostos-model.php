<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class ImpostosModel extends MainModel{
	public $table;
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	public function __construct( $controller = null ){
		$this->table = 'impostos';
		parent::__construct($controller);
	}

	function getImpostos($id = null, $incidente = null){

		$query = "select t1.id id_imposto, t1.id_empresa_vendedora, aliquota, nome_imposto, descricao, tipo, imposto_incidente, t2.razao_social from impostos t1 inner join empresa_vendedora t2 on(t1.id_empresa_vendedora = t2.id) where (t1.deleted = 0 or t1.deleted is null)";

		if($id){
			$query .= " and t1.id= $id ";
		}

		if($tipo){
			$query .= " and t1.imposto_incidente = '$incidente' ";
		}

		$exec = $this->db->query($query);
		if($exec){
		// Retorna
		$return = $exec->fetchAll();
			return json_encode($return);
		}else{
			return false;
		}
	}

	function getImpostoByEmpresa($id_empresa,  $incidente = null){
		$query = "select * from impostos where (deleted = 0 or deleted is null) and id_empresa_vendedora = $id_empresa";
		if($incidente){
			$query .= " and (imposto_incidente = '$incidente' or imposto_incidente = 'nao incidente') ";
		}
		return $this->db->exec($query);
	}

	function getImpostoSumarizado($id_empresa,  $incidente = null){
		$query = "select SUM(aliquota)  total_aliquota from impostos where (deleted = 0 or deleted is null) and id_empresa_vendedora = $id_empresa";
		if($incidente){
			$query .= " and imposto_incidente = '$incidente' ";
		}
		return $this->db->exec($query);
	}
}
