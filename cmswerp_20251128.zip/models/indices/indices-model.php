<?php
    /**
     * Created by PhpStorm.
     * User: julio.gomes
     * Date: 14/10/2016
     * Time: 15:57
     */

    class IndicesModel extends MainModel{
        public function __construct( $controller = null ){
            parent::__construct($controller);
            //define a tabela principal desse modulo
            $this->table = 'indices_reajuste';
        }

        function getIndiceById( $id ){
            $query = '
                select
                    *
                from
                    indices_reajuste where (deleted = 0 or deleted is null)
            ';
            if( !empty( $id ) && is_numeric( $id ) ){
                $query .= " and id =  $id ";
            }
            $query .= ' order by ano desc, mes desc, indice desc';
            return $this->db->exec($query);
        }

        function getHistoricoContratosByIndice( $indice, $ano, $mes ){
            $query = "
                SELECT DISTINCT 
                    co.id id_contrato,
                    co.razao_social,
                    pr.nome nome_produto,
                    co.indice_reajuste
                FROM
                    contratos co inner join
                    produtos pr on(pr.id = co.id_produto) left join
                    pacote_historico ph ON( co.id = ph.id_contrato ) LEFT join
                    lp_historico lh ON( co.id = lh.id_contrato )
                where
                    (co.deleted is null or co.deleted = 0) and
                    ph.id IS NOT NULL and
	                lh.id IS NOT NULL
            ";

            if( !empty( $indice ) ){
                $query .= " and co.indice_reajuste = '$indice' ";
            }

            if( !empty( $ano ) && is_numeric( $ano ) && !empty( $mes ) && is_numeric( $mes )){
                $query .= " and ( (ph.ano_reajuste = $ano and ph.mes_reajuste = $mes ) || (lh.ano_reajuste = $ano and lh.mes_reajuste = $mes) )";
            }elseif( !empty( $ano ) && is_numeric( $ano ) ){
                $query .= " and ( ph.ano_reajuste = $ano || lh.ano_reajuste = $ano )  ";
            }elseif( !empty( $mes ) && is_numeric( $mes ) ){
                $query .= " and ( ph.mes_reajuste = $mes || lh.mes_reajuste = $mes )  ";
            }

            $query .= ' order by co.razao_social';
            return $this->db->exec($query);
        }

        function getRecords( $id = NULL, $orderby = NULL ){
            $query = '
                select
                    *
                from
                    indices_reajuste where  (deleted = 0 or deleted is null)
            ';
            if($id || $id == '0'){
                $query .= " and id =  $id ";
            }

            $query .= ' order by ano desc, mes desc, indice desc';
            return $this->db->exec($query);
        }

        function getIndicesPorAnoMes( $ano, $mes, $indice = null ){
            $query = "
                    select
                        *
                    from
                        indices_reajuste
                    where
                        (deleted = 0 or deleted is null) and
                        ano = '$ano'  and
                        mes = '".str_pad($mes, 2, 0, STR_PAD_LEFT)."'
                ";
            if($indice){
                $query .= " and indice = '$indice' ";
            }
            return $this->db->exec($query);
        }

        function getLastIndice( $ano, $indice ){
            $query = " select  max(mes) mes from indices_reajuste where (deleted = 0 or deleted is null) and ano = '$ano'  and indice = '$indice' ";
            return $this->db->exec($query);
        }

        function ultimoIndice( $mes, $tipo ){
            $query = "select * from indices_reajuste ir where (ir.deleted = 0 or ir.deleted is null) and mes = $mes and indice = '$tipo' order by ir.ano desc limit 1;";
            return $this->db->exec($query);
        }

        function getContratosByIndice( $indice, $mes, $adm = false, $ativo = true ){
            $query = "
                select 
                    con.*,
                    pr.id id_produto,
                    pr.nome nome_produto
                from
                    contratos con inner join
                    produtos pr on(con.id_produto = pr.id )
                where
                    (con.deleted is null or con.deleted = 0)"
            ;
            
            if( $ativo ){
                $query .= " and con.status = 'ativo' ";    
            }

            if($mes){
                $query .= " and MONTH(con.data_assinatura) = '$mes' ";    
            }

            if($indice){
                $query .= " and con.indice_reajuste = '$indice'";
            }

            if(!$adm){
                $query .= " and con.id_produto != 20";   
            }
            return $this->db->exec($query);
        }

        function getGedDocumento( $id_origem = null, $indice = null, $subtipo = null ){
            $query = "
                SELECT
                    gd.*,
                    ga.id as id_ged_anexo,
                    ga.nome_amigavel,
                    ga.path_root,
                    ga.path_objeto,
                    ga.nome_hash,
                    ga.hash_arquivo,
                    ga.data_criacao
                FROM
                    ged_documento gd INNER JOIN
                    ged_anexo ga ON (gd.id = ga.id_documento)
                WHERE
                (gd.deleted = 0 && ga.deleted = 0)";

            
                if($id_origem){
                $query .= " and gd.id_origem = $id_origem";
            }

            if($indice){
                $query .= " and gd.doc_origem = '$indice'";
            }

            if($subtipo){
                $query .= " and gd.subtipo = '$subtipo'";
            }

            $query .= " ORDER BY gd.id DESC";
            return $this->db->exec($query);
        }

        function getHistoricoPacoteContratoIndice(){
            $query ="
            SELECT distinct
                con.id id_contrato,
                ph.tipo_pacote, 
                ph.tipo_atualizacao,
                ph.flag,
                ph.indice,
                ph.id id_historico,
                ph.id_modulos_tarifaveis id_modulo,
                ph.alterado_em,
                ph.alterado_por,
                con.indice_reajuste,
                mt.id id_modulo
            FROM
                pacote_contratado pc INNER join
                pacote_historico ph ON(pc.id = ph.id_pacote) INNER join
                modulos_tarifaveis mt ON(mt.id = ph.id_modulos_tarifaveis) INNER join
                contratos con ON(con.id = ph.id_contrato) INNER join
                indices_reajuste ir ON(con.indice_reajuste = ir.indice)
            WHERE
                ( ph.deleted IS NULL OR ph.deleted = 0 ) and
                ph.tipo_pacote = 'cliente' and
	            ph.indice IS null
            ORDER BY 
                ph.id
            ";
            return $this->db->exec($query);
        }
        
        function getHistoricoPacoteEIndice(){
            $query ="
            SELECT
                con.id id_contrato,  
                ir.id id_indice,
                ir.indice,
                ir.ano ano_reajuste,
                ir.mes mes_reajuste,
                ph.id id_historico,
                ph.alterado_em,
                ph.alterado_por
            FROM
                pacote_historico ph INNER join
                pacote_contratado pc ON(ph.id_pacote = pc.id) INNER join
                contratos con ON(con.id = pc.id_contrato ) INNER join
                indices_reajuste ir ON(ir.ano = ph.ano_reajuste AND ir.mes = ph.mes_reajuste AND ir.indice = ph.indice)
            WHERE
                (ph.deleted IS NULL OR ph.deleted = 0 ) AND 
                ph.id_indice IS null
            ORDER BY
	            ir.id
            ";
            return $this->db->exec($query);
        }
        
        function getHistoricoELp(){
            $query ="
            SELECT
                lh.id_lp,
                lc.id_contrato,
                con.indice_reajuste,
                lh.id id_historico,
                lc.id_produto, 
                lc.id_modulo,
                lc.qtd_de,
                lh.alterado_em,
                lh.alterado_por
            FROM
                lp_historico lh INNER join
                lp_clientes lc ON(lh.id_lp = lc.id) INNER join
                contratos con ON(con.id = lc.id_contrato)
            WHERE
                (lh.deleted IS NULL OR lh.deleted = 0) and
                tipo_lista = 'cliente' and
	            lh.indice IS null
            ORDER BY
                lh.id
            ";
            return $this->db->exec( $query );
        }

        function getHistoricoELista(){
            $query = "
                SELECT
                    lh.id_lp,
                    lc.id_contrato,
                    ir.id id_indice,
                    ir.indice,
                    con.indice_reajuste,
                    lh.id id_historico,
                    lc.id_produto,
                    lc.id_modulo,
                    lh.alterado_em,
                    lh.alterado_por
                FROM
                    lp_historico lh INNER join
                    lp_clientes lc ON(lc.id = lh.id_lp) INNER join
                    contratos con ON(con.id = lc.id_contrato) INNER join
                    indices_reajuste ir ON(ir.ano = lh.ano_reajuste AND ir.mes = lh.mes_reajuste AND ir.indice = lh.indice)
                WHERE
                    (lh.deleted IS NULL OR lh.deleted = 0) and
                    lh.tipo_lista = 'cliente' and 
                    lh.id_indice is null
                ORDER BY
                lh.id asc
            ";
            return $this->db->exec($query);
        }

        function getContratosReajustePacoteByIndice( $id_indice, Array $contratos = null ){
            if( !empty( $id_indice ) && is_numeric( $id_indice ) ){
                $query = "
                    SELECT distinct
                        ir.id id_indice,
                        ir.indice,
                        ir.percentual,
                        con.id id_contrato,
                        con.razao_social,
                        ir.ano ano_reajuste,
                        ir.mes mes_reajuste,
                        pr.nome nome_produto,
                        con.status
                    FROM
                        indices_reajuste ir INNER join
                        pacote_historico ph ON( ir.id = ph.id_indice ) INNER join
                        contratos con ON( ph.id_contrato = con.id ) INNER join
                        produtos pr ON( con.id_produto = pr.id )
                    WHERE 
                        ( ir.deleted IS NULL OR ir.deleted = 0 ) and
                        ir.id = $id_indice
                ";

                if( $contratos ){
                    $query .= " and ph.id_contrato in(".implode(',',$contratos).")";
                }
                return $this->db->exec($query);
            }else{
                return false;
            }
        }

        function getContratosReajusteListaByIndice( $id_indice, Array $contratos = null ){
            if( !empty( $id_indice ) && is_numeric( $id_indice ) ){
                $query = "
                    SELECT distinct
                        ir.id id_indice,
                        ir.indice,
                        ir.percentual,
                        con.id id_contrato,
                        con.razao_social,
                        ir.ano ano_reajuste,
                        ir.mes mes_reajuste,
                        pr.nome nome_produto,
                        con.status
                    FROM
                        indices_reajuste ir INNER join
                        lp_historico lh ON( ir.id = lh.id_indice ) INNER join
                        contratos con ON( lh.id_contrato = con.id ) INNER join
                        produtos pr ON( con.id_produto = pr.id )
                    WHERE 
                        ( ir.deleted IS NULL OR ir.deleted = 0 ) and
                        ir.id = $id_indice
                ";

                if( $contratos ){
                    $query .= " and lh.id_contrato in(".implode(',',$contratos).")";
                }
                return $this->db->exec($query);
            }else{
                return false;
            }
        }
    }