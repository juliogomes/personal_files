<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */

class IntegracoesModel extends MainModel{
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	public function __construct( $controller = null ){
		parent::__construct($controller);
		$this->table = 'integracoes';
	}

	function getAllIntegracao(){
		$query = "
			select
				*
			from
				integracoes
			where
				(deleted is null or deleted = 0 )
			order by
				nome
		";
		return $this->db->exec($query);
	}

	function getIntegracaoById($id){
		if($id){
			$query = "
				select
					*
				from
					integracoes
				where
					(deleted is null or deleted = 0 )
			";
			$query .= " and id = $id ";
			$query .= "order by nome";
			return $this->db->exec($query);
		}else{
			return false;
		}
	}
	
	function getIntegracaoByTokenCallBack($token){
		if($token){
			$query = "
				select
					*
				from
					integracoes
				where
					(deleted is null or deleted = 0 ) and
					allow_calback = 1
			";
			$query .= " and token_callback = ? ";
			$query .= "order by nome";
			return $this->db->exec($query, array($token));
		}else{
			return false;
		}
	}

	function getIntegracaoByCodigo( $codigo ){
		if( $codigo ){
			$query = "
				select
					*
				from
					integracoes
				where
					(deleted is null or deleted = 0 )
			";
			$query .= " and codigo = '$codigo' ";
			$query .= "order by nome";
			return $this->db->exec($query);
		}else{
			return false;
		}
	}

	function saveTransacao($param, $id = null){
		$this->setTable('integracoes_transacoes');
		return $this->save($param, $id);
	}
}