
<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */

class ListaPrecosModel extends MainModel{
    public function __construct( $controller = null ){
        parent::__construct($controller);
        //define a tabela principal desse modulo
        $this->table = 'lp_clientes';
    }

    function getLpByCustomer( $id_contrato, $id_modulo = null, $id_produto = null ){
		$query = "
			select 
				lp.*, 
				lp.id id_lp_cliente,
				co.data_assinatura,
				co.data_reajuste,
				co.status status_contrato,
				co.razao_social,
				p.id id_produto,
				p.nome nome_produto,
				p.codigo codigo_produto,
				mt.codigo codigo_modulo,
				mt.descricao nome_modulo
			from 
				$this->table lp inner join 
				contratos co on(lp.id_contrato = co.id) inner JOIN 
				produtos p on(lp.id_produto = p.id) inner join 
				modulos_tarifaveis mt on(mt.id = lp.id_modulo)
			where 
				lp.`status` = 'ativo' and (lp.deleted = 0 or lp.deleted is null)
		";

		if( $id_contrato && !is_array( $id_contrato ) ){
			$query .= " and lp.id_contrato = $id_contrato ";
		}elseif( is_array( $id_contrato ) ){
			$query .= " and lp.id_contrato in(".implode(',', $id_contrato).")"; 
		}

		if( $id_modulo ){
			$query .= " and lp.id_modulo = $id_modulo ";
		}

		if( $id_produto ){
			$query .= " and lp.id_produto = $id_produto ";
		}
		
		$query .= " order by qtd_de, qtd_ate, valor_real ";
		return $this->db->exec($query);
	}
	
	function getLpContratosByModulo( $id_contrato, $codigo_modulo ){
		$query = "
			select
				lp.*, 
				lp.id id_lp_cliente,
				co.data_assinatura,
				co.data_reajuste,
				co.status status_contrato,
				co.razao_social,
				p.id id_produto,
				p.nome nome_produto,
				p.codigo codigo_produto,
				mt.codigo codigo_modulo,
				mt.descricao nome_modulo
			from
				$this->table lp inner join 
				contratos co on(lp.id_contrato = co.id) inner JOIN 
				produtos p on(lp.id_produto = p.id) inner join 
				modulos_tarifaveis mt on(mt.id = lp.id_modulo)
			where
				lp.`status` = 'ativo' and (lp.deleted = 0 or lp.deleted is null)
		";

		if( $id_contrato && !is_array( $id_contrato ) ){
			$query .= " and lp.id_contrato = $id_contrato ";
		}elseif( is_array( $id_contrato ) ){
			$query .= " and lp.id_contrato in(".implode(',', $id_contrato).")"; 
		}

		if( $codigo_modulo ){
			$query .= " and mt.codigo = '$codigo_modulo' ";
		}
		$query .= " order by qtd_de, qtd_ate, valor_real ";
		return $this->db->exec($query);
	}

    function getLpdefault( $id_produto = null, $id_modulo = null, $qtd_de = null, $qtd_ate = null){
		$query = "
			select 
				lp.*
			from 
				lp_default lp inner join 
				produtos p on(lp.id_produto = p.id) inner join 
				modulos_tarifaveis mt on(mt.id = lp.id_modulo)
			where 
				lp.`status` = 'ativo' and (lp.deleted = 0 or lp.deleted is null)
		";

		if($id_modulo){
			$query .= " and lp.id_modulo = $id_modulo ";
		}

		if($id_produto){
			$query .= " and lp.id_produto = $id_produto ";
		}
		
		if($qtd_de){
			$query .= " and lp.qtd_de = $qtd_de ";
		}

		if($qtd_ate){
			$query .= " and lp.qtd_ate = $qtd_ate ";
		}
		
		$query .= " order by qtd_de, qtd_ate, valor_real ";
		return $this->db->exec($query);
	}
	
	function getPacotesByContratos( $id_contratos, $id_modulo = null ){
		$query = "
			select 
				pct.*,
				co.data_assinatura,
				co.data_reajuste,
				co.status status_contrato,
				co.razao_social,
				p.id id_produto,
				p.nome nome_produto,
				p.codigo codigo_produto,
				mt.codigo codigo_modulo,
				mt.descricao nome_modulo
			from 
				pacote_contratado pct inner join 
				contratos co on(pct.id_contrato = co.id) inner JOIN 
				produtos p on(co.id_produto = p.id) inner join 
				modulos_tarifaveis mt on(mt.id = pct.id_modulos_tarifaveis)
			where 
				pct.`status` = 'ativo' and (pct.deleted = 0 or pct.deleted is null)
		";

		if($id_contratos && !is_array($id_contratos)){
			$query .= " and pct.id_contrato = $id_contratos ";
		}elseif(is_array($id_contratos)){
			$query .= " and pct.id_contrato in(".implode(',', $id_contratos).")"; 
		}
		
		if($id_modulo){
		    $query .= " and pct.id_modulos_tarifaveis = '$id_modulo' "; 
		}
        return $this->db->exec($query);
	}
	
	function saveLPDefault( $param, $id = null ){
		$this->table = 'lp_default';
		return $this->save($param, $id);
	}

	function saveLPHistorico( $param, $id = null){
		$this->table = 'lp_historico';
		return $this->save($param, $id);
	}

	function getLpHistoricoByAnoMes( $ano, $mes, $indice, $contrato = null ){
		$query = "
			SELECT
				lpc.id id_lp,
				co.id id_contrato,
				co.razao_social,
				lh.id id_historico,
				lh.indice,
				lh.valor_real,
				lh.ano_reajuste,
				lh.mes_reajuste,
				lh.valor_antigo,
				lh.valor_reajuste,
				lh.percentual,
				lh.valor_atualizado,
				lh.tipo_atualizacao,
				lh.alterado_em,
				lh.alterado_por,
				pr.id id_produto,
				pr.nome nome_produto,
				mt.descricao nome_modulo,
				mt.id id_modulo,
				mt.codigo codigo_modulo
			FROM
				lp_clientes lpc inner join
				contratos co on( lpc.id_contrato = co.id) inner join
				produtos pr ON(co.id_produto = pr.id) inner join
				modulos_tarifaveis mt on( mt.id = lpc.id_modulo ) left join 
				lp_historico lh ON( lpc.id = lh.id_lp )
			WHERE
				( lpc.deleted IS NULL OR lpc.deleted = 0 )
		";

		if( !empty( $ano ) && is_numeric( $ano ) ){
			$query .= " and ( lh.ano_reajuste = $ano OR lh.ano_reajuste IS NULL ) and lpc.ano_reajuste = $ano ";
		}

		if( !empty( $mes ) && is_numeric( $mes ) ){
			$query .= " and ( lh.mes_reajuste = $mes OR lh.mes_reajuste IS NULL) and lpc.mes_reajuste = $mes ";
		}

		if( !empty( $indice ) ){
			$query .= " and ( lh.indice = '$indice' OR lh.indice IS NULL) ";
		}

		if( !is_array( $contrato ) && !empty( $contrato ) && is_numeric( $contrato ) ){
			$query .= " and lpc.id_contrato = $contrato ";
		}elseif( is_array( $contrato ) && !empty( $contrato ) ){
			$query .= " and lh.id_contrato in('".implode("','", $contrato)."')";
		}
		$query .= " order by lh.id_contrato ";
		return $this->db->exec( $query );
	}

	function getPacoteHistoricoByAnoMes( $ano, $mes, $indice, $contrato = null ){
		$query = "
			SELECT
				pc.id id_pacote,
				co.razao_social,
				pr.nome produto,
				mt.descricao modulo,
				ph.id id_historico,
				co.indice_reajuste indice,
				ph.tipo_pacote,
				ph.id_contrato,
				ph.id_modulos_tarifaveis,
				ph.qdt_atual,
				ph.qdt_atualizada,
				ph.preco_atual,
				ph.preco_atualizado,
				ph.percentual,
				ph.ano_reajuste,
				ph.mes_reajuste,
				ph.flag,
				ph.tipo_atualizacao,
				ph.alterado_em,
				ph.alterado_por,
				mt.codigo codigo_modulo
			FROM
				pacote_contratado pc LEFT JOIN 
				pacote_historico ph ON(pc.id = ph.id_pacote) LEFT JOIN 
				contratos co ON(co.id = pc.id_contrato)INNER join
				produtos pr ON(co.id_produto = pr.id) INNER JOIN
				modulos_tarifaveis mt ON(mt.id = ph.id_modulos_tarifaveis)
			WHERE
				( pc.deleted IS NULL OR pc.deleted  = 0 )
		";

		if( !empty( $ano ) && is_numeric( $ano ) ){
			$query .= " and ( ph.ano_reajuste = $ano OR ph.ano_reajuste IS NULL ) ";
		}

		if( !empty( $mes ) && is_numeric( $mes ) ){
			$query .= " and ( ph.mes_reajuste = $mes OR ph.mes_reajuste IS NULL) ";
		}

		if( !empty( $indice ) ){
			$query .= " and co.indice_reajuste = '$indice' ";
		}

		if( !is_array( $contrato ) && !empty( $contrato ) && is_numeric( $contrato ) ){
			$query .= " and ph.id_contrato = $contrato ";
		}elseif( is_array( $contrato ) && !empty( $contrato ) ){
			$query .= " and ph.id_contrato in('".implode("','", $contrato)."')";
		}
		$query .= " order by ph.id_contrato ";
		return $this->db->exec( $query );
	}

	function getLpHistoricoClienteById( $ids ){
		$query .= " select * from lp_historico where (deleted is null or deleted = 0) and tipo_lista = 'cliente' ";
		if( is_array( $ids ) ){
			$query .= " and id in('".implode("','", $ids)."') ";
		}else{
			if( !empty( $ids ) && is_numeric( $ids ) ){
				$query .= " and id =  $ids ";
			}
		}
		return $this->db->exec( $query );
	}

	function getPacoteHistoricoClienteById( $ids ){
		$query .= "
			SELECT 
				ph.*,
				pc.id id_pacote,
				pc.frenquencia,
				pc.valor_garantido
			FROM 
				pacote_historico ph INNER join
				pacote_contratado pc ON(ph.id_pacote = pc.id)
			WHERE 
				( ph.deleted is null or ph.deleted = 0 ) and 
				ph.tipo_pacote = 'cliente'
		";
		if( is_array( $ids ) ){
			$query .= " and ph.id in('".implode("','", $ids)."') ";
		}else{
			if( !empty( $ids ) && is_numeric( $ids ) ){
				$query .= " and ph.id =  $ids ";
			}
		}
		return $this->db->exec( $query );
	}
	
	//By: Caio Freitas - 07/02/2023
	function getLpByCodigo( $codigo_produto = null, $codigo_modulo = null ){
		$query ="
			select 
				p.id, p.nome, p.codigo, ld.qtd_de, ld.qtd_ate, ld.valor_real, 
				ld.id_modulo, mt.codigo as codigo_modulo, mt.descricao 
			from 
				produtos as p
			inner join 
				lp_default as ld
			on 
				p.id = ld.id_produto 
			INNER JOIN 
				modulos_tarifaveis as mt
			on 
				ld.id_modulo = mt.id
			where 
				(p.deleted = 0 or p.deleted is NULL) 
			AND 
				(ld.deleted = 0 or ld.deleted is NULL)
		";

		if($codigo_produto){
			$query .= " and p.codigo = '$codigo_produto'";
		}

		if($codigo_modulo){
			$query .= " and mt.codigo = '$codigo_modulo'";
		}
		
		if($codigo_modulo){
			$query .= " order by ld.qtd_de asc";
		}else{
			$query .= " order by ld.id_modulo asc";
		}
		return $this->db->exec( $query );
	}
}