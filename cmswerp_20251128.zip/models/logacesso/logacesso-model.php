<?php

class LogAcessoModel extends MainModel {
    
    protected
        $table = 'log_acesso_site',
        $parametros = array('db_name' => IPLOC_NAME, 'host' => IPLOC_HOST, 'port' => IPLOC_PORT, 'user' => IPLOC_USER, 'password' => IPLOC_PASSWORD);

    public function __construct($controller = null){                 
        parent::__construct($controller, $this->parametros);
    }


    function getLog($id){
        $query = " 
            select 
                * 
            from 
                ".$this->table."
            where 
                (deleted is null or deleted = 0)";

        if($id){
            $query .= " and id = '$id'";
        }
        $query .= " order by id desc";       
        return $this->db->exec($query);
    }
    
    function getlogByIp($ip = null, $data = null, $site = null, $pagina = null, $url = null, $referer = null){
        $query = "
            select 
                * 
            from 
                ".$this->table." 
            where 
                (deleted is null or deleted = 0)";        
        
        if($ip){
            $query .= " and ip = '$ip'";
        }
        if($data){
            $query .= " and data_acesso = '$data'";
        }
        if($site){
            $query .= " and site = '$site'";
        }
        if($pagina){
            $query .= " and pagina = '$pagina'";
        }
        if($url){
            $query .= " and url = '$url'";
        }
        if($referer){
            $query .= " and referer = '$referer'";
        }
        $query .= " order by id desc";
        return $this->db->exec($query);
    }
    
    function contadorAcesso($data, $site){
        $query = "
            select
            	sum(contador_log) contador_log,
            	site,
            	data_acesso
            from
            	log_acesso_site las
            where
                (deleted is null or deleted = 0)
        ";
        
        if($data){
            $query .= " and data_acesso = '$data'";
        }
        
        if($site){
            $query .= " and site = '$site'";
        }
        
        $query .= "
            group by
            	site,
            	data_acesso
            order by
            	site,
            	data_acesso
        ";
        return $this->db->exec($query);
    }

    function getEmpresaPorVertical($vertical, $empresa = null, $limit = null){
        $query = "
            select
                *            
            from 
                empresa e
            where 
                (e.deleted is null or e.deleted = 0)
        ";

        if(!empty($vertical)){
            $query .= " and vertical = '$vertical'";
        }
        
        if(!empty($empresa)){
            $query .= " and nome like'%$empresa%'";
        }

        if($limit){
            $query .= " LIMIT $limit";
        }
        return $this->db->exec($query);
    }

    function getLogIntervalo($data = null, $site = null, $empresa = null, $vertical = null){
        $query = "
        select
            *
        from "
            .$this->table."
        where 
            (deleted is null or deleted = 0)";
        
        if($data){
            $query .= " and data_acesso = '$data'";
        }
       
        if($site){
            $query .= " and site = '$site'";
        }
        $query .= " order by id desc";
        return $this->db->exec($query);   
    }
    
    function getLogCount($data = null, $site = null, $empresa = null, $vertical = null){
        $query = "select count(1) qtd_acessos, site from log_acesso_site where (deleted is null or deleted = 0) GROUP BY site";
        return $this->db->exec($query);   
    }

    function getIp2Location($ip){
        $query = "
        SELECT 
           *
        FROM 
            iptolocation
        WHERE
            '$ip'
        BETWEEN ip_from and ip_to";
        
        $query .= " order by id asc";

        return $this->db->exec($query);
    }
    
    function getEmpresa($blocked = null, $id_empresa = null, $vertical = null, $limit = null, $order_by = false, $nome_empresa = null){
        $query = "
            select
                *            
            from 
                empresa e
            where 
                (e.deleted is null or e.deleted = 0)
        ";    
        
        if(isset($blocked)){
            $query .= " and e.blocked = $blocked";
        }

        if($id_empresa){
            $query .= " and e.id = '$id_empresa'";
        }

        if($vertical){
            $query .= " and e.vertical = '$vertical'";
        }

        if($nome_empresa){
            $query .= " and e.nome like '%$nome_empresa%'";
        }

        if($order_by == true){
            $query .= " order by e.nome asc";
        }else{
            $query .= " order by e.id asc";
        }

        if($limit){
            $query .= " LIMIT $limit";
        }
        return $this->db->exec($query);   
    }

    function groupVertical(){
        $query = "
            select
                e.vertical            
            from 
                empresa e
            where 
                (e.deleted is null or e.deleted = 0)
            group by e.vertical;
        ";
        return $this->db->exec($query);
    }
    
    function getEmpresaByNome($nome = null, $blocked = null){
        $query = "
            SELECT
               *
            FROM
                empresa
            WHERE
                (deleted is null or deleted = 0)
        ";
        if($nome){
           $query .= ' and nome = "'.$nome.'"';
        }
        if($blocked){
            $query .= " and blocked = '$blocked'";
        }
        $query .= " order by id asc";
        return $this->db->exec($query);
    }
    
    function getLogIpEmpresa($data = null, $site = null, $empresa = null, $vertical = null, $ip = null, $limit_ini = null, $limit = null){
        $query = "
            SELECT distinct
                la.id,
                la.data_acesso,
                la.hora,
                i.ipv4, 
                la.pagina, 
                la.url, 
                la.referer, 
                la.site, 
                la.othersips, 
                la.`language`,
                la.contador_log, 
                i.id_empresa, 
                e.nome, 
                e.vertical, 
                e.blocked,
                i.contador contador_ip,
                i.deleted
            FROM 
                log_acesso_site la
            INNER JOIN 
                tab_ipv4 i
            ON 
                (la.id_ip = i.id)
            INNER JOIN 
                empresa e
            ON 
                (i.id_empresa = e.id)
            WHERE 
                (i.deleted IS NULL OR i.deleted = 0)
        ";

        if($data){
            $query .= " and la.data_acesso = '$data'";
        }
       
        if($site){
            $query .= " and la.site = '$site'";
        }

        if($ip){
            $query .= " and i.ipv4 like '%$ip%'";
        }
        
        if($empresa){
            $query .= " and e.nome like '%$empresa%'";
        }

        if($vertical){
            $query .= " and e.vertical like '%$vertical%'";
        }
        $query .= " order by la.data_acesso, la.hora desc";
        if($limit > 0){
            if($limit_ini && $limit){
                $query .= " LIMIT $limit_ini, $limit";
            }elseif(!$limit_ini && $limit){
                $query .= " LIMIT $limit";
            }    
        }
        $exec = $this->db->exec($query); 
        return $exec;
    }

    function getIpByIp($ip = null){
        $query = "
            select
                tb1.*,
                e.nome
            from 
                tab_ipv4 tb1 inner join
                empresa e on(e.id = tb1.id_empresa )
            where 
                (tb1.deleted is null or tb1.deleted = 0)";    
        
        if($ip){
            $query .= " and tb1.ipv4 = '$ip'";
        }
        $query .= " order by tb1.id desc";
        return $this->db->exec($query);   
    }

    function getIp($id_ip = null, $id_empresa = null){
        $query = "
        select 
            *
        from 
            tab_ipv4
        where 
            (deleted is null or deleted = 0)";
        
        if($id_ip){
            $query .= " and id = '$id_ip'";
        }

        if($id_empresa){
            $query .= " and id_empresa = '$id_empresa'";
        }
        $query .= " order by id desc";   
        return $this->db->exec($query);    
    } 
    
    function IpBloqueados($blocked){
        $query = "
        SELECT             
            i.ipv4            
        FROM
            empresa e
        INNER JOIN 
            tab_ipv4 i
        ON
            (i.id_empresa = e.id)
        WHERE
            (i.deleted is null or i.deleted = 0)";

        if($blocked){
            $query .= " and e.blocked = $blocked";
        }
        return $this->db->exec($query);
    }

    function deleteLogAcesso() {
		
		// Inicia a declaração
		$query = "
            delete from ".$this->table;
			
		return $this->db->exec($query);
	} 

    function updateLogPipedrive($id){
        $query = "
            UPDATE 
                log_acesso_empresa
            SET
                check_acesso = 1
            WHERE
                (deleted is null or deleted = 0)";    

		if( isset($id) && is_array($id) ){
            $query .= " and id in('".implode("','", $id)."') ";
        }
		return $this->db->exec($query);
    }

    function logPipedrive(){
        $query = "
        SELECT distinct 
            e.nome,   
            e.id as id_empresa,          
            la.id_ip, 
            la.data_acesso, 
            la.check_pipedrive,
            la.hora,
            la.pagina,
            la.url,
            la.site,
            i.ipv4,           
            la.contador_log, 
            i.id_empresa,             
            e.vertical, 
            e.blocked,
            i.deleted
        FROM 
            log_acesso_site la
        INNER JOIN 
            tab_ipv4 i
        ON 
            (la.id_ip = i.id)
        INNER JOIN 
            empresa e
        ON 
            (i.id_empresa = e.id)
        WHERE 
            (i.deleted is null OR i.deleted = 0)
        ";
        return $this->db->exec($query); 
    }

    function acessoEmpresa($id_empresa = null, $site = null){
        $query = "
        SELECT 
            le.id,
            le.id_empresa,
            le.site,
            le.check_acesso,
            e.nome,
            le.deleted
        FROM
            log_acesso_empresa le
        INNER JOIN
            empresa e
        ON
            (le.id_empresa = e.id)
        WHERE
            (le.deleted is null or le.deleted = 0)";

        if($id_empresa){
            $query .= " and le.id_empresa = '$id_empresa'";
        }

        if($site){
            $query .= " and le.site = '$site'";
        }

        $query .= " and le.check_acesso = 0";

        return $this->db->exec($query);
    }

    
}