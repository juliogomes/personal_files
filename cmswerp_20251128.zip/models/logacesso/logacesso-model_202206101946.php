<?php

class LogAcessoModel extends MainModel {
    
    protected
        $table = 'log_acesso_site',
        $parametros = array('db_name' => IPLOC_NAME, 'host' => IPLOC_HOST, 'port' => IPLOC_PORT, 'user' => IPLOC_USER, 'password' => IPLOC_PASSWORD);

    public function __construct($controller = null){                 
        parent::__construct($controller, $this->parametros);
    }


    function getLog($id){
        $query = " select * from ".$this->table." where (deleted is null or deleted = 0)";
        if($id){
            $query .= " and id = '$id'";
        }
        $query .= " order by id desc";       
        return $this->db->exec($query);        
    }
    
    function getlogByIp($ip = null, $data = null, $site = null, $pagina = null, $url = null, $referer = null){
        $query = "select *  from ".$this->table." where (deleted is null or deleted = 0)";
        if($ip){
            $query .= " and ip = '$ip'";
        }
        if($data){
            $query .= " and data_acesso = '$data'";
        }
        if($site){
            $query .= " and site = '$site'";
        }
        if($pagina){
            $query .= " and pagina = '$pagina'";
        }
        if($url){
            $query .= " and url = '$url'";
        }
        if($referer){
            $query .= " and referer = '$referer'";
        }
        $query .= " order by id desc";
        // echo $query;
        return $this->db->exec($query);
    }

    function contadorAcesso($data, $site){
        $query = "
            select
            	sum(contador_log) contador_log,
            	site,
            	data_acesso
            from
            	log_acesso_site las
            where
                (deleted is null or deleted = 0)
        ";
        
        if($data){
            $query .= " and data_acesso = '$data'";
        }
        
        if($site){
            $query .= " and site = '$site'";
        }
        
        $query .= "
            group by
            	site,
            	data_acesso
            order by
            	site,
            	data_acesso
        ";
        return $this->db->exec($query);
    }

    function getLogIntervalo($data = null, $site = null, $empresa = null, $vertical = null){
        $query = "
        select
            *
        from "
            .$this->table."
        where 
            (deleted is null or deleted = 0)";
        
        if($data){
            $query .= " and data_acesso = '$data'";
        }
       
        if($site){
            $query .= " and site = '$site'";
        }

        $query .= " order by id desc";

        // echo $query;

        return $this->db->exec($query);   
    }

    function getIp2Location($ip){
        $query = "
        SELECT 
           *
        FROM 
            iptolocation
        WHERE
            '$ip'
        BETWEEN ip_from and ip_to";
        
        $query .= " order by id asc";

        return $this->db->exec($query);
    }
    
    function getEmpresa($blocked = null, $id_empresa = null, $vertical = null, $limit = null, $order_by = false, $nome_empresa = null){
        $query = "
            select
                *            
            from 
                empresa e
            where 
                (e.deleted is null or e.deleted = 0)
        ";    
        
        if(isset($blocked)){
            $query .= " and e.blocked = $blocked";
        }

        if($id_empresa){
            $query .= " and e.id = '$id_empresa'";
        }

        if($vertical){
            $query .= " and e.vertical = '$vertical'";
        }

        if($nome_empresa){
            $query .= " and e.nome like '%$nome_empresa%'";
        }

        if($order_by == true){
            $query .= " order by e.nome asc";
        }else{
            $query .= " order by e.id asc";
        }

        if($limit){
            $query .= " LIMIT $limit";
        }
        
        // echo $query;

        return $this->db->exec($query);   
    }

    function getEmpresaByNome($nome = null, $blocked = null){
        $query = "
            SELECT
               *
            FROM
                empresa
            WHERE
                (deleted is null or deleted = 0)
        ";
        if($nome){
           $query .= " and nome = '$nome'";
        }
        if($blocked){
            $query .= " and blocked = '$blocked'";
        }
        $query .= " order by id asc";
        // echo $query;
        return $this->db->exec($query);
    }
    
    function getLogIpEmpresa($data = null, $site = null, $empresa = null, $vertical = null, $ip = null){
        $query = "
            SELECT distinct
                la.id,
                la.data_acesso,
                la.hora,
                i.ip, 
                la.pagina, 
                la.url, 
                la.referer, 
                la.site, 
                la.othersips, 
                la.`language`,
                la.contador_log, 
                i.id_empresa, 
                e.nome, 
                e.vertical, 
                e.blocked,
                i.contador contador_ip,
                i.deleted
            FROM 
                log_acesso_site la
            INNER JOIN 
                ip i
            ON 
                (la.id_ip = i.id)
            INNER JOIN 
                empresa e
            ON 
                (i.id_empresa = e.id)
            WHERE 
                (i.deleted IS NULL OR i.deleted = 0)
        ";

        if($data){
            $query .= " and la.data_acesso = '$data'";
        }
       
        if($site){
            $query .= " and la.site = '$site'";
        }

        if($ip){
            $query .= " and i.ip like '%$ip%'";
        }
        
        if($empresa){
            $query .= " and e.nome like '%$empresa%'";
        }

        if($vertical){
            $query .= " and e.vertical = '$vertical'";
        }

        $query .= " order by la.data_acesso desc";

        // echo $query;

        return $this->db->exec($query); 
        
    }

    function getIpByIp($ip = null){
        $query = "
            select
                *
            from 
                ip
            where 
                (deleted is null or deleted = 0)";    
        
        if($ip){
            $query .= " and ip = '$ip'";
        }
        $query .= " order by id desc";
        return $this->db->exec($query);   
    }

    function getIp($id_ip = null, $id_empresa = null){
        $query = "
        select 
            *
        from 
            ip
        where 
            (deleted is null or deleted = 0)";
        
        if($id_ip){
            $query .= " and id = '$id_ip'";
        }

        if($id_empresa){
            $query .= " and id_empresa = '$id_empresa'";
        }

        $query .= " order by id desc";   
        
        // echo $query;

        return $this->db->exec($query);    
    } 
    
    function IpBloqueados($blocked){
        $query = "
        SELECT             
            i.ip            
        FROM
            empresa e
        INNER JOIN 
            ip i
        ON
            (i.id_empresa = e.id)
        WHERE
            (i.deleted is null or i.deleted = 0)";

        if($blocked){
            $query .= " and e.blocked = $blocked";
        }

        // echo $query;

        return $this->db->exec($query);
    }

    function deleteLogAcesso() {
		
		// Inicia a declaração
		$query = "
            delete from ".$this->table;
			
		return $this->db->exec($query);
	} 

    function updateLogPipedrive($id = null){
        $query = "
            UPDATE "
                .$this->table."
            SET
                check_pipedrive = 1
            WHERE
                (deleted is null or deleted = 0)";    

		if( isset($id) && is_array($id) ){
            $query .= " and id_ip in('".implode("','", $id)."') ";
        }
        // echo $query;
		return $this->db->exec($query);
    }

    function logPipedrive(){
        $query = "
        SELECT distinct 
            e.nome,             
            la.id_ip, 
            la.data_acesso,
            la.hora,
            la.pagina,
            la.url,
            la.site,
            la.check_pipedrive,
            i.ip,           
            la.contador_log, 
            i.id_empresa,             
            e.vertical, 
            e.blocked,
            i.deleted
        FROM 
            log_acesso_site la
        INNER JOIN 
            ip i
        ON 
            (la.id_ip = i.id)
        INNER JOIN 
            empresa e
        ON 
            (i.id_empresa = e.id)
        WHERE 
            (i.deleted IS NULL OR i.deleted = 0)
        AND
            la.check_pipedrive = 0";      

        // echo $query;

        return $this->db->exec($query); 
    }

    
}