<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class MensagensModel extends MainModel
{
	public $table;
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	public function __construct($controller = null ){
		$this->table = 'mensagens';
		parent::__construct($controller);
	}

	function getMessage($id = null){
		$query = " select * from mensagens where (deleted = 0 or deleted is  null) ";
		if($id){
			$query .= " and id = $id ";
		}

		$exec = $this->db->query($query);
		if($exec){
		// Retorna
		$return = $exec->fetchAll();
			return json_encode($return);
		}else{
			return false;
		}
	}

	function getMessageAtivas($id = null){
		$query = " select distinct msg.id, msg.codigo_cliente, msg.id_produto, msg.id_modulo, msg.tipo, msg.intervalo_tipo, msg.intervalo_periodo, msg.alvo, msg.gatilho, msg.titulo, msg.mensagem, msg.metodo_envio, msg.ativo_de, msg.ativo_ate, msg.status, co.razao_social, pr.nome nome_produto, mt.descricao nome_modulo from mensagens msg left join contratos co on(msg.codigo_cliente = co.codigo_cliente) left join produtos pr on(msg.id_produto = pr.id) left join modulos_tarifaveis mt on(msg.id_modulo = mt.id) where (msg.deleted = 0 or msg.deleted is null) and (co.deleted = 0 or co.deleted is null) and msg.status = 'ativo' ";

		if($id){
			$query .= " and msg.id=$id ";
		}
		$exec = $this->db->query($query);
		if($exec){
		// Retorna
		$return = $exec->fetchAll();
			return json_encode($return);
		}else{
			return false;
		}
	}

	function getAllMessages($id = null){
		$query = " select distinct msg.id, msg.codigo_cliente, msg.id_produto, msg.id_modulo, msg.tipo, msg.intervalo_tipo, msg.intervalo_periodo, msg.alvo, msg.gatilho, msg.titulo, msg.mensagem, msg.metodo_envio, msg.ativo_de, msg.ativo_ate, msg.status, co.razao_social, pr.nome nome_produto, mt.descricao nome_modulo from mensagens msg left join contratos co on(msg.codigo_cliente = co.codigo_cliente) left join produtos pr on(msg.id_produto = pr.id) left join modulos_tarifaveis mt on(msg.id_modulo = mt.id) where (msg.deleted = 0 or msg.deleted is null) and (co.deleted = 0 or co.deleted is null) ";

		if($id){
			$query .= " and msg.id=$id ";
		}
		$exec = $this->db->query($query);
		if($exec){
		// Retorna
		$return = $exec->fetchAll();
			return json_encode($return);
		}else{
			return false;
		}
	}

	function getMensagemByParam($codigo_cliente = null, $id_produto, $id_modulo = null, $alvo = null, $gatilho = null, $periodo){
		$query = "SELECT * FROM mensagens where (deleted = 0 or deleted is null)";
		if($codigo_cliente){
			$query .= " and (codigo_cliente = '$codigo_cliente' or codigo_cliente = 'all' )";
		}

		if($id_produto){
			$query .= " and (id_produto = '$id_produto' or id_produto = 'all' )";
		}

		if($id_modulo){
			$query .= " and (id_modulo = '$id_modulo' )";
		}

		if($alvo){
			$query .= " and (alvo = '$alvo' )";
		}

		if($gatilho){
			$query .= " and (gatilho = '$gatilho' )";
		}

		if($periodo){
			$query .= " and (ativo_de <= '$periodo' and ativo_ate >= '$periodo' )";
		}
		$exec = $this->db->query($query);
		if($exec){
		// Retorna
		$return = $exec->fetchAll();
			return json_encode($return);
		}else{
			return false;
		}
	}

	function getMsgNotaVencida(){
		$query = "select * from mensagens msg where (msg.deleted is null or msg.deleted = 0) and gatilho = 'apos_vencimento' and alvo = 'nota_fiscal' and status = 'ativo' and ativo_de <= now() and ativo_ate >= now()";
		return $this->db->exec($query);
	}

	function getLastSentMessage($id_nota){
		$query = "select * from mensagens_enviadas me where (me.deleted is null or me.deleted = 0) and objeto_tipo = 'nota_fiscal' ";
		if($id_nota){
			$query .= " and objeto_id = $id_nota";
		}
		$query .= " order by id desc limit 1 ";
		return $this->db->exec($query);
	}

	function saveSentMessage($param){
		$this->table = 'mensagens_enviadas';
		$this->save($param);
		$this->table = 'mensagens';
	}
}
