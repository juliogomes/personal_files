<?php
	class MetaDadosModel extends MainModel {
		public $table = 'meta_dados';
		public function __construct($controller = null ){
			$this->setTable('meta_dados');
			parent::__construct($controller);
		}

		function getMetaDados( $meta_origem, $id_origem, $meta_tipo = null ){
			$query = "
				SELECT
					*
				FROM
					".$this->table."
				WHERE 
					(deleted is null or deleted = 0)
			";

			if( $meta_tipo ){
				$query .= " and meta_tipo = '$meta_tipo'";
			}

			if( $meta_origem ){
				$query .= " and meta_origem = '$meta_origem'";
			}

			if( $id_origem ){
				$query .= " and meta_id_origem  = $id_origem ";
			}
			$query .= 'order by meta_tipo';
			return $this->db->exec($query);
		}

		function getMetaDadosByCampo( $meta_origem, $id_origem, $meta_campo = null ){
			$query = "
				SELECT
					*
				FROM
					".$this->table."
				WHERE 
					(deleted is null or deleted = 0)
			";

			if( $meta_campo ){
				$query .= " and meta_campo = '$meta_campo'";
			}

			if( $meta_origem ){
				$query .= " and meta_origem = '$meta_origem'";
			}

			if( $id_origem ){
				$query .= " and meta_id_origem  = $id_origem ";
			}
			$query .= 'order by meta_tipo';
			return $this->db->exec($query);
		}
	}