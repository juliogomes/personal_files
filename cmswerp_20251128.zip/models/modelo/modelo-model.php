<?php
	class ModeloModel extends MainModel {
		public $table =  'modelo_contrato_default';
		public function __construct($controller = null ){
			$this->setTable('modelo_contrato_default');
			parent::__construct($controller);
		}

		function getModelo( $cod_produto = null ){
			$query = "
				SELECT
					*
				FROM
					".$this->table."
				WHERE 
					(deleted is null or deleted = 0)
			";

			if($cod_produto){
				$query .= " and codigo_produto = '$cod_produto'";
			}
			$query .= " order by codigo_produto, pagina asc";
			return $this->db->exec($query);
		}
		
		function getPacoteDefault($codigo_produto = null, $codigo_modulo = null){
			$query = "
				SELECT 
					pd.id,			
					pd.id_modulos_tarifaveis, 
					pd.qdt_garantido, 
					pd.preco_pkt, 
					pd.status, 
					mt.descricao,
					mt.codigo as codigo_modulo,
					p.codigo as codigo_produto
				FROM 
					pacote_default as pd 
				INNER JOIN 
					modulos_tarifaveis AS mt 
				ON 
					(pd.id_modulos_tarifaveis = mt.id) 
				INNER JOIN
					produtos p
				ON
					(mt.id_produto = p.id)
				WHERE 
					pd.id_produto = mt.id_produto
				AND
					pd.deleted = 0
			";

			if($codigo_produto){
				$query .= " and p.codigo = '$codigo_produto'";
			}	

			if($codigo_modulo){
				$query .= " and mt.codigo = '$codigo_modulo'";
			}	
			$query .= " order by pd.id desc";		
			return $this->db->exec($query);
		}
	}