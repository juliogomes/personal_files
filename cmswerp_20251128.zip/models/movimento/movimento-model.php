<?php
    /**
     * Created by PhpStorm.
     * User: julio.gomes
     * Date: 14/10/2016
     * Time: 15:57
     */
    class MovimentoModel extends MainModel{
        //A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
        public function __construct($controller = null ){
            parent::__construct($controller);
            $this->table = 'tarifacoes';
        }

        function getMov( $codigo_cliente, $codigo_produto, $codigo_modulo, $data_tarifacao, $submodulo = null ){
            $query = "select * from $this->table where codigo_cliente = '$codigo_cliente' and codigo_produto = '$codigo_produto' and codigo_modulo  = '$codigo_modulo' and data_tarifacao = '$data_tarifacao'";
            if($submodulo){
                $query .= " and submodulo = '$submodulo '";
            }     
            $exec = $this->db->query($query);
            if($exec){
                // Retorna
                $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }

        function getlastTarifacao( $codigo_cliente, $codigo_produto, $codigo_modulo = null ){
            $query = "
                select 
                    * 
                from 
                    $this->table 
                where codigo_cliente = '$codigo_cliente' and 
                codigo_produto       = '$codigo_produto'
            ";
            if( $codigo_modulo ){
                $query .= " and codigo_modulo  = '$codigo_modulo' ";
            }
            $query .= " ORDER BY data_tarifacao desc limit 1 ";
            return $this->db->exec( $query );
        }

        function getMovPorComercial( $id_contrato, $dt_ini, $dt_fim, $cliente = null, $produto = null){
            $db_cadastros = DB_NAME;
            $db_movimento = DB_NAME_MOVIMENTO;
            $query ="
                select distinct
                    mov.id_contrato,
                    nome_fantasia,
                    codigo_produto,
                    pr.nome nome_produto,
                    codigo_modulo,
                    mt.descricao nome_modulo,
                    sum(qtd_transacoes) transacoes
                from
                    $db_movimento.$this->table mov inner join
                    $db_cadastros.contratos co on (mov.id_contrato = co.id) inner join
                    $db_cadastros.produtos pr on(pr.codigo = mov.codigo_produto) inner join
                    $db_cadastros.modulos_tarifaveis mt on(mt.codigo = mov.codigo_modulo)F
                where
                    (mov.deleted = 0 or mov.deleted is null) and
                    mov.codigo_produto != 'ADM0001'
            ";

            if(is_array($id_contrato)){
                $ids = implode(',', $id_contrato);
                $query .= " and co.id in($ids) ";
            }elseif($id_contrato){
                $query .= " and co.id = $id_contrato";
            }

            if($dt_ini){
                $query .= " and data_tarifacao >= '$dt_ini'";
            }

            if($dt_fim){
                $query .= " and data_tarifacao <= '$dt_fim'";
            }

            if($cliente){
                $query .= " and (
                                razao_social like '%$cliente%' or
                                nome_fantasia like '%$cliente%' or
                                cnpj like '%$cliente%'
                            ) ";
            }

            if($produto){
                $query .= " and (
                                pr.nome like '%$produto%' or
                                pr.codigo like '%$produto%'
                            )
                ";
            }

            echo $query .= "
                group by
                    mov.id_contrato,
                    nome_fantasia,
                    codigo_produto,
                    codigo_modulo
                order by
                    pr.nome,
                    co.nome_fantasia,
                    mt.descricao
            ";
            $exec = $this->db->query($query);
            if($exec){
                // Retorna
                $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }

        function getRel($codigo_cliente,  $codigo_modulo, $login = null, $centro_custo = null, $data_tarifacao = null){
            $query = "select * from $this->table where data_tarifacao = '$data_tarifacao' and codigo_cliente = '$codigo_cliente' and  codigo_modulo  = '$codigo_modulo' and login = '$login' ";
            if($centro_custo){
                $query .= " and centro_custo = '$centro_custo'";
            }

            $exec = $this->db->query($query);
            if($exec){
                // Retorna
                $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }

        function getMovManual( $codigo_cliente, $codigo_produto ){
            $query = " select * from $this->table where (deleted  is null or deleted = 0) and codigo_cliente = '$codigo_cliente' and codigo_produto = '$codigo_produto' and tipo_tarifacao = 'manual' ";
            return $this->db->exec($query);
        }

        function getRelUsuario($codigo_cliente, $codigo_produto){
            $query = " select * from $this->table where (deleted  is null or deleted = 0) and codigo_cliente = '$codigo_cliente' and codigo_produto = '$codigo_produto' and flag = 'manual' ";
            return $this->db->exec($query);
        }

        function getMesesFat(){
            $query = " select DISTINCT YEAR(data_tarifacao) ano, MONTH(data_tarifacao) mes from $this->table where data_tarifacao >= '2017-01-01' and data_tarifacao <= now() group by data_tarifacao order by data_tarifacao desc ";
            $exec = $this->db->query($query);
            if($exec){
                // Retorna
                $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }

        function getConsolidadoMensal($ano, $mes, $codigo_cliente = null, $codigo_modulo = null, $json = false){
            $query ="
                SELECT
                    *
                FROM
                    consolidado_mensal
                WHERE
                    deleted = 0 and
                    ano = $ano and
                    mes = $mes
            ";

            if($codigo_cliente){
                $query .= " and codigo_cliente = '$codigo_cliente' ";
            }

            if($codigo_modulo){
                $query .= " and codigo_modulo = '$codigo_modulo' ";
            }
            $exec = $this->db->query($query);
            if($exec){
                // Retorna
                $return = $exec->fetchAll();
                if($json){
                    return json_encode($return);
                }else{
                    return $return;
                }
            }else{
                return false;
            }
        }

        function getConsolidadoProduto($ano, $mes, $codigo_modulo = null, $json = false){
            $query ="
                SELECT
                    *
                FROM
                    consolidado_produto
                WHERE
                    deleted = 0 and
                    ano = $ano and
                    mes = $mes
            ";

            if($codigo_modulo){
                $query .= " and codigo_modulo = '$codigo_modulo' ";
            }

            $exec = $this->db->query($query);
            if($exec){
                // Retorna
                $return = $exec->fetchAll();
                if($json){
                    return json_encode($return);
                }else{
                    return $return;
                }
            }else{
                return false;
            }
        }

        // metodos novo ira substituir o metodo antigo abaixo
        function getMovPorContratoEPeriodo($date_ini, $date_fim, $id_contrato = null){
            $db_cadastros = DB_NAME;
            $db_movimento = DB_NAME_MOVIMENTO;
            $query = "
                select
                    md.id_contrato,
                    md.codigo_cliente,
                    ev.id id_empresa_vendedora,
                    md.codigo_produto,
                    prod.id id_produto,
                    prod.nome nome_produto,
                    md.codigo_modulo,
                    mt.id id_modulo,
                    f_tipo,
                    mt.descricao nome_modulo,
                    sum(qtd_transacoes) contador_trx,
                    sum(valor) contador_fin
                from
                    $db_movimento.$this->table md inner join
                    $db_cadastros.contratos co on(co.id = md.id_contrato) inner join
                    $db_cadastros.empresa_vendedora ev on(co.id_empresa = ev.id) inner join
                    $db_cadastros.produtos prod on(prod.codigo = md.codigo_produto) inner join
                    $db_cadastros.modulos_tarifaveis mt on(mt.codigo = md.codigo_modulo) left join
                    $db_cadastros.$this->table_aux mda on(mda.id_$this->table = md.id_$this->table)
                where
                    (md.deleted = 0 or md.deleted is null) and
                    (mda.deleted = 0 or mda.deleted is null) and
                    md.status_trans = 'ativo'        and
                    md.data_tarifacao >= '$date_ini' and
                    md.data_tarifacao <= '$date_fim'
            ";
            if($id_contrato){
                $query .= " and md.id_contrato = $id_contrato ";
            }
            $query .= "
                group by
                    id_contrato,
                    codigo_cliente,
                    codigo_produto,
                    codigo_modulo
                order by
                    codigo_cliente,
                    codigo_produto,
                    codigo_modulo
            ";
            $exec = $this->db->query($query);
            if($exec){
                $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }

        //metodo antigo será substituido pelo metodo acima
        function getMovByDateIntervalPorModulo($date_ini, $date_fim, $codigo_modulo = null, $codigo_cliente = null){
            $query = "
                select
                    sum(qtd_transacoes) total_transacoes,
                    sum(valor) total_valor,
                    codigo_cliente,
                    codigo_produto,
                    codigo_modulo
                from
                    $this->table
                where
                    (deleted = 0 or deleted is null) and
                    data_tarifacao >= '$date_ini' and
                    data_tarifacao <= '$date_fim 23:59:59'
            ";

            if($codigo_modulo){
                $query .= " and codigo_modulo = '$codigo_modulo' ";
            }

            if($codigo_cliente){
                $query .= " and codigo_cliente = '$codigo_cliente' ";
            }

            $query .= "
            group by
                codigo_cliente,
                codigo_produto,
                codigo_modulo
            order by
                codigo_cliente,
                codigo_produto,
                codigo_modulo
            ";
            $exec = $this->db->query($query);
            if($exec){
                // Retorna
                $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }

        function getMovByPorModuloCliente($date, $codigo_modulo, $codigo_cliente){
            $query = "
                select
                    id_$this->table,
                    qtd_transacoes total_transacoes,
                    valor total_valor,
                    codigo_cliente,
                    codigo_produto,
                    codigo_modulo
                from
                    $this->table
                where
                    (deleted = 0 or deleted is null) and
                    data_tarifacao = '$date'
            ";

            if($codigo_modulo){
                $query .= " and codigo_modulo = '$codigo_modulo' ";
            }

            if($codigo_cliente){
                $query .= " and codigo_cliente = '$codigo_cliente' ";
            }

            $query .= "
            group by
                codigo_cliente,
                codigo_produto,
                codigo_modulo
            order by
                codigo_cliente,
                codigo_produto,
                codigo_modulo
            ";
            $exec = $this->db->query($query);
            if($exec){
                // Retorna
                $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }

        function getMovPeriodo($dt_ini, $dt_fim, $codigo_cliente = null, $codigo_produto = null, $codigo_modulo = null){
            $db_cadastros = DB_NAME;
            $db_movimento = DB_NAME_MOVIMENTO;
            $query = "
                select
                    ru.id_contrato, 
                    ru.codigo_cliente, 
                    ru.codigo_produto, 
                    ru.codigo_modulo, 
                    co.nome_fantasia,
                    mt.descricao nome_modulo, 
                    SUM(ru.valor) valor, 
                    SUM(ru.qtd_transacoes) qtd_transacoes
                from
                    $db_movimento.$this->table ru inner join
                    $db_cadastros.modulos_tarifaveis mt on(mt.codigo = ru.codigo_modulo) inner join
                    $db_cadastros.contratos co on(co.id = ru.id_contrato)
                where
                    (ru.deleted = 0 or ru.deleted is null) and
                    (mt.deleted is null or mt.deleted = 0)
            ";

            if(isset($id_contrato) && is_numeric($id_contrato)){
                $query .= " and ru.id_contrato = '".$id_contrato."'";
            }

            if($codigo_cliente){
                $query .= " and (ru.codigo_cliente = '".$codigo_cliente."' OR ru.codigo_cliente IS null)";
            }
            
            if($codigo_produto){
                $query .= " and (ru.codigo_produto = '".$codigo_produto."' OR ru.codigo_produto IS null)";
            }

            if($codigo_modulo){
                $query .= " and (ru.codigo_modulo = '".$codigo_modulo."' OR ru.codigo_modulo IS null)";
            }

            if($dt_ini){
                $query .= " and (ru.data_tarifacao >= '".$dt_ini."' OR ru.data_tarifacao IS null)";
            }

            if($dt_fim){
                $query .= " and (ru.data_tarifacao <= '".$dt_fim."' OR ru.data_tarifacao IS null)";
            }

            $query .="
                group BY
                    co.razao_social,
                    co.nome_fantasia,
                    ru.codigo_cliente,
                    ru.codigo_produto,
                    ru.codigo_modulo,
                    mt.descricao
                order by
                    ru.codigo_cliente,
                    ru.codigo_produto,
                    ru.codigo_modulo;
            ";
            return $this->db->exec($query);
        }
        
        //By Caio Freitas - 07/02/2023
        function newGetMovPeriodo($dt_ini, $dt_fim, $codigo_cliente = null, $codigo_produto = null, $codigo_modulo = null){
            $db_cadastros = DB_NAME;
            $db_movimento = DB_NAME_MOVIMENTO;
            $query = "
                select
                    ru.id_contrato, 
                    ru.codigo_cliente, 
                    ru.codigo_produto, 
                    ru.codigo_modulo, 
                    mt.descricao nome_modulo, 
                    p.nome,
                    co.nome_fantasia,
                    SUM(ru.valor) valor, 
                    SUM(ru.qtd_transacoes) qtd_transacoes
                from
                    $db_movimento.$this->table ru inner join
                    $db_cadastros.modulos_tarifaveis mt on(mt.codigo = ru.codigo_modulo) inner join
                    $db_cadastros.contratos co on(co.id = ru.id_contrato) inner join
                    $db_cadastros.produtos p on(p.codigo = ru.codigo_produto)
                where
                    (ru.deleted = 0 or ru.deleted is null)
            ";

            if(isset($id_contrato) && is_numeric($id_contrato)){
                $query .= " and ru.id_contrato = '".$id_contrato."'";
            }

            if($codigo_cliente){
                $query .= " and (ru.codigo_cliente = '".$codigo_cliente."' OR ru.codigo_cliente IS null)";
            }
            
            if($codigo_produto){
                $query .= " and (ru.codigo_produto = '".$codigo_produto."' OR ru.codigo_produto IS null)";
            }

            if($codigo_modulo){
                $query .= " and (ru.codigo_modulo = '".$codigo_modulo."' OR ru.codigo_modulo IS null)";
            }

            if($dt_ini){
                $query .= " and (ru.data_tarifacao >= '".$dt_ini."' OR ru.data_tarifacao IS null)";
            }

            if($dt_fim){
                $query .= " and (ru.data_tarifacao <= '".$dt_fim."' OR ru.data_tarifacao IS null)";
            }

            $query .="
                group BY
                    co.razao_social,
                    co.nome_fantasia,
                    ru.codigo_cliente,
                    ru.codigo_produto,
                    ru.codigo_modulo,
                    mt.descricao
                order by
                    ru.codigo_cliente,
                    ru.codigo_produto,
                    ru.codigo_modulo;
            ";
            return $this->db->exec($query);
        }
        
        function getMovPeriodoContrato($dt_ini, $dt_fim, $codigo_cliente = null, $codigo_produto = null, $codigo_modulo = null){
            $db_cadastros = DB_NAME;
            $db_movimento = DB_NAME_MOVIMENTO;
            $query = "
            select
                sum(ru.qtd_transacoes) transacoes,
                sum(ru.valor) valor,
                ru.id_contrato,
                con.nome_fantasia,
                ru.codigo_cliente,
                ru.codigo_produto,
                ru.codigo_modulo,
                pr.id id_produto,
                pr.nome nome_produto,
                mt.id id_modulo,
                mt.descricao nome_modulo,
                mt.tipo_cobranca,
                ru.flag
            from
                $db_movimento.$this->table ru inner join
                $db_cadastros.contratos con on(con.id = ru.id_contrato) inner join
                $db_cadastros.produtos pr on(pr.codigo = ru.codigo_produto) inner join
                $db_cadastros.modulos_tarifaveis mt on(mt.codigo = ru.codigo_modulo)
            where
                (ru.deleted = 0 or ru.deleted is null)
            ";

            if(isset($id_contrato) && is_numeric($id_contrato)){
                $query .= " and ru.id_contrato = '".$id_contrato."'";
            }

            if($codigo_cliente){
                $query .= " and ru.codigo_cliente = '".$codigo_cliente."'";
            }
            
            if($codigo_produto){
                $query .= " and pr.codigo = '".$codigo_produto."'";
            }

            if($codigo_modulo){
                $query .= " and mt.codigo = '".$codigo_modulo."'";
            }

            if($dt_ini){
                $query .= " and ru.data_tarifacao >= '".$dt_ini."'";
            }

            if($dt_fim){
                $query .= " and ru.data_tarifacao <= '".$dt_fim."'";
            }

            $query .="
                group BY
                    ru.codigo_cliente,
                    ru.codigo_produto,
                    codigo_modulo
                order by
                    con.nome_fantasia,
                    pr.nome,
                    mt.descricao;
            ";
            return $this->db->exec($query);
        }

        function saveTarifacao($dados, $id = null){
            if($id){
                $is_save = $this->db->insert('tarifacoes', $dados );
            }else{
                $where_field = 'id';
                $where_field_value = $id;
                $is_save = $this->db->update('tarifacoes', $where_field, $where_field_value, $dados);
            }
            return $is_save;
        }

        function insertRel($param){
            $this->db->insert($this->table, $param );
            return $this->db->last_id;
        }

        function updateRel($id, $param){
            $where_field = 'id';
            $where_field_value = $id;
            return $this->db->update($this->table, $where_field, $where_field_value, $param);
        }

        function insertMov($param){
            $this->db->insert($this->table, $param );
            return $this->db->last_id;
        }

        function updateMov($id, $param){
            $where_field = 'id';
            $where_field_value = $id;
            $this->db->update($this->table, $where_field, $where_field_value, $param);
        }

        function insertConsolidadoMensal($param){
            $this->db->insert('consolidado_mensal', $param );
        }

        function updateConsolidadoMensal($id_consolidado, $param){
            $where_field = 'id';
            $where_field_value = $id;
            $this->db->update('consolidado_mensal', $where_field, $where_field_value, $param);
        }

        function insertConsolidadoProduto($dados){
            $this->db->insert('consolidado_produto', $dados);
        }

        function deleteRecords($table, $id, $param = null){
            if($id && $table){
                $this->table = $table;
                return $this->save($param, $id);
            }else{
                return false;
            }
        }

        function getListaMeses($codigo_cliente, $codigo_produto){
            $query = " select DATE_FORMAT(data_tarifacao, '%Y') ano, DATE_FORMAT(data_tarifacao, '%m') mes from $this->table where codigo_cliente = $codigo_cliente and codigo_produto = '$codigo_produto'  group by ano, mes ";
            $exec = $this->db->query($query);
            if($exec){
            // Retorna
            $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }

        function getExtrato($dt_ini, $dt_fim, $codigo_cliente, $codigo_produto){
        $query = "
                select
                    ru.codigo_cliente,
                    ru.codigo_produto,
                    pr.nome nome_produto,
                    ru.codigo_modulo,
                    mt.descricao nome_modulo,
                    ru.data_tarifacao,
                    sum(ru.qtd_transacoes) qtd_transacoes,
                    ru.login
                from
                    ".DB_NAME_MOVIMENTO.".$this->table ru  inner join
                    ".DB_NAME.".produtos pr on(pr.codigo = ru.codigo_produto) inner join
                    ".DB_NAME.".modulos_tarifaveis mt on(mt.codigo = ru.codigo_modulo)
                where
                    (ru.deleted is null or ru.deleted = 0) and
                    (mt.deleted IS NULL OR mt.deleted = 0) and
                    codigo_cliente = '$codigo_cliente' and
                    data_tarifacao >= '$dt_ini' and data_tarifacao <= '$dt_fim'
            ";

            if(is_array($codigo_produto)){
                $query .= " and pr.codigo in('".implode("','", $codigo_produto)."') ";
            }elseif($codigo_produto){
                $query .= " and pr.codigo = '$codigo_produto'";
            }

            $query .= "
                group by 
                    ru.codigo_cliente, 
                    ru.codigo_produto, 
                    pr.nome, 
                    ru.codigo_modulo, 
                    mt.descricao, 
                    ru.data_tarifacao, 
                    ru.login 
                order by
                    ru.data_tarifacao,
                    ru.codigo_produto,
                    ru.login
            ";
            $exec = $this->db->query($query);
            if($exec){
                // Retorna
            $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }

        function getDadosGrafico(){
            $query = "select sum(qtd_transacoes) quantidade, codigo_produto, data_tarifacao from $this->table where codigo_cliente != 33333333 and codigo_cliente != 99999999 and (codigo_produto = 'COB0001' or codigo_produto = 'SPB0001' or codigo_produto = 'RCK0001') group by data_tarifacao, codigo_produto order by data_tarifacao";
            return $this->db->exec($query);
        }

        function getMovAux($id = null, $produto = null, $modulo = null, $tipo = null){
            //falta implementar
        }

        //funcoes novas a substituir as antigas apos ser implementada
        function getMovRelPorContrato($dt_ini, $dt_fim, $id_contrato = null, $codigo_produto = null, $codigo_modulo = null){
            $db_cadastros = DB_NAME;
            $db_movimento = DB_NAME_MOVIMENTO;
            $query = "
                select
                    sum(ru.qtd_transacoes) transacoes,
                    sum(ru.valor) valor,
                    ru.id_contrato,
                    ru.codigo_cliente,
                    ru.codigo_produto,
                    ru.codigo_modulo,
                    pr.id id_produto,
                    pr.nome nome_produto,
                    mt.id id_modulo,
                    mt.descricao nome_modulo,
                    mt.tipo_cobranca,
                    ru.flag
                from
                    $db_movimento.$this->table ru inner join
                    $db_cadastros.produtos pr on(pr.codigo = ru.codigo_produto) inner join
                    $db_cadastros.modulos_tarifaveis mt on( mt.codigo = ru.codigo_modulo AND pr.id = mt.id_produto )
                where
                    (ru.deleted = 0 or ru.deleted is null) and
                    (mt.deleted = 0 OR mt.deleted IS NULL) AND
                    ru.tarifavel = 1
            ";

            if($codigo_produto == 'GCK0001'){
                $query .= " and pr.codigo = '$codigo_produto' and mt.codigo != 'GCK0018' ";
            }elseif($codigo_produto){
                $query .= " and pr.codigo = '$codigo_produto' ";
            }

            if($codigo_modulo){
                $query .= " and mt.codigo = '$codigo_modulo' ";
            }

            if($id_contrato){
                $query .= "
                    and ru.id_contrato = $id_contrato
                ";
            }

            if($dt_ini){
                $query .= "
                    and ru.data_tarifacao >= '$dt_ini'
                ";
            }

            if($dt_fim){
                $query .= " and ru.data_tarifacao <= '$dt_fim'";
            }

            $query .="
                group BY
                    ru.id_contrato,
                    ru.codigo_cliente,
                    ru.codigo_produto,
                    ru.codigo_modulo
            ";
            return $this->db->exec($query);
        }

        function getMovRelPorContratoAno($id_contrato = null, $dt_ini = null, $dt_fim = null){
            $db_cadastros = DB_NAME;
            $db_movimento = DB_NAME_MOVIMENTO;
            $query = "
                select
                    sum(ru.qtd_transacoes) transacoes,
                    sum(ru.valor) valor,
                    ru.id_contrato,
                    ru.codigo_cliente,
                    ru.codigo_produto,
                    ru.codigo_modulo,
                    pr.id id_produto,
                    pr.nome nome_produto,
                    mt.id id_modulo,
                    mt.descricao nome_modulo,
                    mt.tipo_cobranca
                from
                    $db_movimento.$this->table ru inner join
                    $db_cadastros.produtos pr on(pr.codigo = ru.codigo_produto) inner join
                    $db_cadastros.modulos_tarifaveis mt on(mt.codigo = ru.codigo_modulo)
                where
                    (ru.deleted = 0 or ru.deleted is null)
            ";

            if($id_contrato){
                $query .= "
                    and ru.id_contrato = $id_contrato
                ";
            }

            if($dt_ini){
                $query .= "
                    and ru.data_tarifacao >= '$dt_ini'
                ";
            }

            if($dt_fim){
                $query .= "
                    and ru.data_tarifacao <= '$dt_fim'
                ";
            }

            $query .="
                group BY
                    ru.id_contrato,
                    ru.codigo_cliente,
                    ru.codigo_produto,
                    codigo_modulo
            ";
            $query.'<br><br>';
            $exec = $this->db->query($query);
            if($exec){
                // Retorna
            $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }

        function getMovTotal($id_contrato = null, $codigo_cliente = null, $codigo_produto = null, $ativos = false ){
            $query = "
                SELECT
                    c.id id_contrato,
                    c.razao_social,
                    c.nome_fantasia,
                    pr.nome nome_produto,
                    pr.codigo codigo_produto,
                    c.data_assinatura,
                    c.status status_contrato,
                    c.data_corte_faturamento,
                    SUM(tf.qtd_transacoes) transacoes 
                FROM
                    ".DB_NAME.".contratos c LEFT join
                    ".DB_NAME.".produtos pr ON(c.id_produto = pr.id)LEFT JOIN
                    ".DB_NAME_MOVIMENTO.".tarifacoes tf ON(c.id = tf.id_contrato)
                WHERE 
                    (c.deleted IS NULL OR c.deleted = 0)
            ";

            if($id_contrato){
                $query .= " and c.id = '$id_contrato' ";
            }
            
            if($codigo_cliente){
                $query .= " and c.codigo_cliente = '$codigo_cliente' ";
            }

            if($codigo_produto){
                $query .= " and pr.codigo = '$codigo_produto' ";
            }

            if($ativos){
                $query .= " and c.status = 'ativo' ";
            }

            $query .= "
                GROUP BY
                    c.id,
                    c.razao_social,
                    pr.nome,
                    pr.codigo,
                    c.data_assinatura,
                    c.data_corte_faturamento
            ";
            return $this->db->exec($query);
        }

        function getMovAllModulos($dt_ini, $dt_fim, $id_contrato = null, $codigo_produto = null, $codigo_modulo = null, $ativos = true, $tarifavel = false){
            $query = "
                select 
                    c.razao_social,
                    c.nome_fantasia,
                    p.nome nome_produto,
                    mt.codigo codigo_modulo,
                    mt.descricao nome_modulo,
                    t.data_tarifacao,
                    sum(t.qtd_transacoes) transacoes,
                    sum(t.valor) valor
                FROM 
                    ".DB_NAME.".contratos c inner join
                    ".DB_NAME.".produtos p on(c.id_produto = p.id) inner JOIN 
                    ".DB_NAME.".modulos_tarifaveis mt on(p.id = mt.id_produto) left JOIN 
                    ".DB_NAME_MOVIMENTO.".tarifacoes t on(mt.codigo = t.codigo_modulo)
                where
                    (c.deleted is null or c.deleted = 0) and
                    (t.deleted = 0 or t.deleted is null)
                ";
            
            if($tarifavel){
                $query .= " and t.tarifavel = 1 ";
            }

            if($ativos){
                $query .= " and c.status = 'ativo' ";
            }

            if($codigo_produto == 'GCK0001'){
                $query .= " and p.codigo = '$codigo_produto' and mt.codigo != 'GCK0018' ";
            }elseif($codigo_produto){
                $query .= " and p.codigo = '$codigo_produto' ";
            }

            if(is_array($codigo_modulo)){
                $query .= " and mt.codigo in('".implode("','", $codigo_modulo)."') ";
            }elseif($codigo_modulo){
                $query .= " and mt.codigo = '$codigo_modulo'";
            }

            if($id_contrato){
                $query .= " and (c.id = $id_contrato) ";
            }

            if($dt_ini){
                $query .= "
                    and (t.data_tarifacao is null or t.data_tarifacao >= '$dt_ini')
                ";
            }

            if($dt_fim){
                $query .= " and (t.data_tarifacao is null or t.data_tarifacao <= '$dt_fim')";
            }
            
            $query .="
                group BY
                    c.razao_social,
                    c.nome_fantasia,
                    p.nome,
                    mt.descricao,
                    t.data_tarifacao
            ";
            return $this->db->exec($query);
        }

        function countTransacoesPorAnoProduto($ano = null, $mes = null,  $codigo_produto = null){
            $query = "
                select
                    sum( qtd_transacoes ) transacoes,
                    DATE_FORMAT( data_tarifacao, '%Y' ) ano,
                    DATE_FORMAT( data_tarifacao, '%m' ) mes
                from
                    $this->table ru
                where
                    (
                        ru.deleted is null
                        or ru.deleted = 0
                    )
                and tarifavel = 1
            ";

            if($ano && !$mes){
                $dt_ini = $ano.'-01-01';
                $dt_fim = $ano.'-12-31';
            }elseif($ano && $mes){
                $ultimo_dia = cal_days_in_month(CAL_GREGORIAN, $mes, $ano);
                $dt_ini = $ano.'-'.$mes.'-01';
                $dt_fim = $ano.'-'.$mes.'-'.$ultimo_dia;
            }

            if($codigo_produto){
                $query .= " and codigo_produto = '$codigo_produto' ";
            }
            $query .= " and ru.data_tarifacao >= '$dt_ini' and ru.data_tarifacao <= '$dt_fim'";
            $query .= " group by ano,  mes order by ano, mes";
            return $this->db->exec($query);
        }

        //funcao temporaria para usar em run_tasks.php é preciso unir essa e a de cima futuramente e tambem em class-Report.php
        function countTransacoesTask($ano = null, $mes = null,  $codigo_produto = null){
            $query = "
                select
                    sum( qtd_transacoes ) transacoes,
                    DATE_FORMAT( data_tarifacao, '%Y' ) ano,
                    DATE_FORMAT( data_tarifacao, '%m' ) mes
                from
                    $this->table ru
                where
                    (
                        ru.deleted is null
                        or ru.deleted = 0
                    )
            ";

            if($codigo_produto){
                $query .= " and codigo_produto = '$codigo_produto' ";
            }

            $query .= " and DATE_FORMAT( data_tarifacao, '%Y' ) = $ano and DATE_FORMAT( data_tarifacao, '%m' ) <= $mes";
            $query .= " group by ano,  mes order by ano, mes";
            return $this->db->exec($query);
        }

        function countModulosporAnoMes($ano = null, $mes = null){
            $query = "
                select distinct
                    codigo_modulo,
                    DATE_FORMAT( data_tarifacao, '%Y' ) ano,
                    DATE_FORMAT( data_tarifacao, '%m' ) mes
                from
                    $this->table ru
                where
                    (
                        ru.deleted is null
                        or ru.deleted = 0
                    )
            ";

            if($ano && !$mes){
                $dt_ini = $ano.'-01-01';
                $dt_fim = $ano.'-12-31';
            }elseif($ano && $mes){
                $ultimo_dia = cal_days_in_month(CAL_GREGORIAN, $mes, $ano);
                $dt_ini = $ano.'-'.$mes.'-01';
                $dt_fim = $ano.'-'.$mes.'-'.$ultimo_dia;
            }
            $query .= " and ru.data_tarifacao >= '$dt_ini' and ru.data_tarifacao <= '$dt_fim'";
            $query .= " group by codigo_modulo, ano, mes order by ano, mes";
            return $this->db->exec($query);
        }

        function getTotalTransacoesByDia($codigo_produto, $data_limite){
            $query = "select sum(qtd_transacoes) total_transacoes, codigo_produto from $this->table where (deleted is null or deleted = 0) and (tarifavel = 1) and data_tarifacao = '".$data_limite->format('Y-m-d')."' and codigo_produto = '$codigo_produto' ";
            return $this->db->exec($query);
        }

        function getAllTransacoesByDiaMes($dia, $codigo_produto, $data_limite){
        $dt_ini = clone $data_limite;
        $dt_ini->sub(new DateInterval('P1Y'));
        $query = "select sum(qtd_transacoes) total_transacoes, data_tarifacao, codigo_produto from $this->table where (deleted is null or deleted = 0) and (tarifavel = 1) and data_tarifacao >= '".$dt_ini->format('Y-m-d')."' and data_tarifacao <'".$data_limite->format('Y-m-d')."' and codigo_produto = '$codigo_produto' and DATE_FORMAT(data_tarifacao, '%d') = $dia GROUP BY data_tarifacao, codigo_produto order by data_tarifacao desc";
            return $this->db->exec($query);
        }

        function getAllTransacoesByDiaSemana($dia, $codigo_produto, $data_limite){
            $dt_ini = clone $data_limite;
            $dt_ini->sub(new DateInterval('P1Y'));
            $query = " select sum(qtd_transacoes) total_transacoes, data_tarifacao, codigo_produto from $this->table where (deleted is null or deleted = 0) and (tarifavel = 1) and data_tarifacao >= '".$dt_ini->format('Y-m-d')."' and data_tarifacao <'".$data_limite->format('Y-m-d')."' and codigo_produto = '$codigo_produto' and DAYOFWEEK(data_tarifacao) = $dia GROUP BY data_tarifacao, codigo_produto order by data_tarifacao desc";
            return $this->db->exec($query);
        }

    function ReportGeral($param){
            $db_cadastros = DB_NAME;
            $db_movimento = DB_NAME_MOVIMENTO;
            $query = "
                select
                    sum(ru.qtd_transacoes) transacoes,
                    sum(ru.valor) valor,
                    ru.id_contrato,
                    con.nome_fantasia,
                    con.cnpj,
                    ru.codigo_cliente,
                    ru.codigo_produto,
                    ru.codigo_modulo,
                    ru.data_tarifacao,
                    DATE_FORMAT(ru.data_tarifacao, '%Y') ano,
                    DATE_FORMAT(ru.data_tarifacao, '%m') mes,
                    pr.id id_produto,
                    pr.nome nome_produto,
                    mt.id id_modulo,
                    mt.descricao nome_modulo,
                    mt.tipo_cobranca,
                    ru.flag
                from
                    $this->table ru inner join
                    $db_cadastros.contratos con on(con.id = ru.id_contrato) inner join
                    $db_cadastros.produtos pr on(pr.codigo = ru.codigo_produto) inner join
                    $db_cadastros.modulos_tarifaveis mt on(mt.codigo = ru.codigo_modulo AND mt.id_produto = pr.id )
                where
                    (ru.deleted = 0 or ru.deleted is null) and
                    (mt.deleted = 0 OR mt.deleted IS NULL)
            ";

            if(isset($param['id_contrato']) && is_numeric($param['id_contrato'])){
                $query .= " and ru.id_contrato = '".$param['id_contrato']."'";
            }

            if($param['codigo_cliente']){
                $query .= " and ru.codigo_cliente = '".$param['codigo_cliente']."'";
            }
            
            if($param['codigo_produto']){
                $query .= " and pr.codigo = '".$param['codigo_produto']."'";
            }

            if($param['codigo_modulo']){
                $query .= " and mt.codigo = '".$param['codigo_modulo']."'";
            }

            if($param['dt_ini']){
                $query .= " and ru.data_tarifacao >= '".$param['dt_ini']."'";
            }

            if($param['dt_fim']){
                $query .= " and ru.data_tarifacao <= '".$param['dt_fim']."'";
            }        

            $query .="
                group BY
                    ru.codigo_cliente,
                    ru.codigo_produto,
                    codigo_modulo,
                    ano, 
                    mes
                order by
                    con.nome_fantasia,
                    pr.nome,
                    mt.descricao    
            ";
            return $this->db->exec($query);
        }
    
        function getLastTransacao($id_contrato){
            $db_movimento = DB_NAME_MOVIMENTO;
            if($id_contrato && is_numeric($id_contrato)){
                $query = "
                    select
                        *
                    from
                        $db_movimento.$this->table ru 
                    where
                        (ru.deleted = 0 or ru.deleted is null) and
                        ru.id_contrato = $id_contrato and 
                        ru.data_tarifacao < curdate()
                    order by 
                        ru.data_tarifacao desc
                    limit 1
                ";
                return $this->db->exec($query);
            }else{
                return false;
            }
        }

    function getMovPeriodoResume($dt_ini, $dt_fim, $tarifavel = true){
            $db_cadastros = DB_NAME;
            $db_movimento = DB_NAME_MOVIMENTO;
            $query = "
                select
                    DATE_FORMAT(ru.data_tarifacao, '%Y') ano,
                    DATE_FORMAT(ru.data_tarifacao, '%m') mes,
                    DATE_FORMAT(ru.data_tarifacao, '%Y-%m') ano_mes, 
                    SUM(ru.valor) valor, 
                    SUM(ru.qtd_transacoes) qtd_transacoes
                from
                    $db_movimento.$this->table ru
                where
                    (ru.deleted = 0 or ru.deleted is null)
            ";

            if($tarifavel){
                $query .= " and tarifavel = 1 ";
            }

            if($dt_ini){
                $query .= " and (ru.data_tarifacao >= '".$dt_ini."' OR ru.data_tarifacao IS null)";
            }

            if($dt_fim){
                $query .= " and (ru.data_tarifacao <= '".$dt_fim."' OR ru.data_tarifacao IS null)";
            }

            $query .="
                GROUP BY
                    ano_mes
                ORDER BY
                    data_tarifacao asc;
            ";
            return $this->db->exec($query);
        }

        function getMovPeriodoResumeByProduto($dt_ini, $dt_fim, $tarifavel = true){
            $db_cadastros = DB_NAME;
            $db_movimento = DB_NAME_MOVIMENTO;
            $query = "
                select
                    codigo_produto,
                    DATE_FORMAT(ru.data_tarifacao, '%Y') ano,
                    DATE_FORMAT(ru.data_tarifacao, '%m') mes,
                    DATE_FORMAT(ru.data_tarifacao, '%Y-%m') ano_mes, 
                    SUM(ru.valor) valor, 
                    SUM(ru.qtd_transacoes) qtd_transacoes
                from
                    $db_movimento.$this->table ru
                where
                    (ru.deleted = 0 or ru.deleted is null)
            ";

            if($tarifavel){
                $query .= " and tarifavel = 1 ";
            }

            if($dt_ini){
                $query .= " and (ru.data_tarifacao >= '".$dt_ini."' OR ru.data_tarifacao IS null)";
            }

            if($dt_fim){
                $query .= " and (ru.data_tarifacao <= '".$dt_fim."' OR ru.data_tarifacao IS null)";
            }

            $query .="
                GROUP BY
                    codigo_produto,
                    ano_mes
                ORDER BY
                    data_tarifacao asc;
            ";
            return $this->db->exec($query);
        }

        function getModuloTarifador($dt_ini, $dt_fim, $codigo_modulo = null){
            $query = "
                select distinct
                    codigo_modulo,
                    DATE_FORMAT( data_tarifacao, '%Y' ) ano,
                    DATE_FORMAT( data_tarifacao, '%m' ) mes
                from
                    $this->table ru
                where
                    (
                        ru.deleted is null
                        or ru.deleted = 0
                    )
            ";
            $query .= " and ru.data_tarifacao >= '$dt_ini' and ru.data_tarifacao <= '$dt_fim'";
            $query .= " group by codigo_modulo, ano, mes order by ano, mes";
            return $this->db->exec($query);
        }
    }