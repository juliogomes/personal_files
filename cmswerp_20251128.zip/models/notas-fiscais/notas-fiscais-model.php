<?php
	/**
	 * Created by PhpStorm.
	 * User: julio.gomes
	 * Date: 14/10/2016
	 * Time: 15:57
	 */
	class NotasFiscaisModel extends MainModel{
		//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
		public function __construct($controller = null ){
			$this->setTable('notas_fiscais');
			parent::__construct($controller);
		}

		function getNota($id = null, $dt_vencimento = null, $valor = null, $status = null, $cnpj_cm = null){
			$query = " select * from $this->table where (deleted = 0 or deleted is null) ";
			if($id){
				if(is_array($id)){
					$query .= " and id in(".implode(",", $id).")";
				}else{
					$query .= " and id = $id ";	
				}
			}

			if($dt_vencimento){
				$query .= " and data_vencimento = '$dt_vencimento' ";
			}

			if($valor){
				$query .= " and valor_total = $valor ";
			}

			if($status){
				$query .= " and status = '$status' ";
			}

			if($cnpj_cm){
				$query .= " and cnpj_cpf_prestador	= '$cnpj_cm' ";
			}
			$query .= " order by cliente ";
			return $this->db->exec($query);
		}

		function getNotaByParametros($param){

			$query = " select * from notas_fiscais nf where (nf.deleted is null or nf.deleted = 0) and nf.status != 'cancelado' ";

			if('data_emissao' == $param['tipo_data']){
				$query .= " and nf.data_emissao >= '".$param['data_de']."' and nf.data_emissao <= '".$param['data_ate']."' ";
			}elseif('data_vencimento' == $param['tipo_data']){
				$query .= " and nf.data_vencimento >= '".$param['data_de']."' and nf.data_vencimento <= '".$param['data_ate']."' ";
			}elseif('data_recebimento' == $param['tipo_data']){
				$query .= " and nf.recebido_em >= '".$param['data_de']."' and nf.recebido_em <= '".$param['data_ate']."' ";
			}

			if('receber' == $param['status']){
				$query .= " and nf.status = 'receber'";
			}elseif('recebido' == $param['status']){
				$query .= " and nf.status = 'recebido'";
			}

			if(isset($param['codigo_cliente']) && isset($param['codigo_cliente'])){
				$query .= " and nf.codigo_cliente = '".$param['codigo_cliente']."'";
			}

			if(isset($param['codigo_produto']) && isset($param['codigo_produto'])){
				$query .= " and nf.codigo_produto = '".$param['codigo_produto']."'";
			}
			return $this->db->exec($query);
		}

		function getNotaPorIdExtrato($id_extrato){
			$query = " select * from $this->table where (deleted = 0 or deleted is null) and status != 'cancelado' and status != 'descartado' ";
			$exec = $this->db->query($query);
			if($id_extrato){
				$query .= " and id_extrato = '$id_extrato' ";
			}
			$query .= " order by cliente ";
			return $this->db->exec($query);
		}

		function getNotaByEmissao($emissao_de, $emissao_ate = null, $id_contrato = null, $cnpj_cpf_prestador = null, $adm = true){
			
			$query = null;
			$query .= " select * from $this->table where (deleted = 0 or deleted is null) and status != 'cancelado' and status != 'descartado' ";
			if($emissao_de){
				$query .= " and data_emissao >= '$emissao_de' ";
			}

			if($emissao_ate){
				$query .= " and data_emissao <= '$emissao_ate' ";
			}

			if($id_contrato){
				$query .= " and id_contrato = $id_contrato ";	
			}

			if($cnpj_cpf_prestador){
				$query .= " and cnpj_cpf_prestador = $cnpj_cpf_prestador ";	
			}

			if(!$adm){
				$query .= " and codigo_produto != 'ADM0001' ";	
			}
			return $this->db->exec($query);
		}

		function getMovAux( ){
			$args = func_get_args();
			if( !$args ){
				return false;
			}else{
				$param = $args[0];
			}
			
			$query = " select * from mov_diario_aux mda WHERE ( mda.deleted IS NULL OR mda.deleted = 0 ) ";

			if( isset( $param['origem'] ) && !empty( $param['origem'] ) ){
				$query .= " and mda.origem = '$param[origem]'";
			}

			if( isset( $param['tipo'] ) && !empty( $param['tipo'] ) ){
				$query .= " and mda.tipo = '$param[tipo]'";
			}

			if( isset( $param['id_contrato'] ) && !empty( $param['id_contrato'] ) ){
				$query .= " and mda.id_contrato = $param[id_contrato]";
			}
			return $this->db->exec( $query );
		}

		function getLastMovAux( ){
			$args = func_get_args();
			if( !$args ){
				return false;
			}else{
				$param = $args[0];
			}
			
			$query = " select * from mov_diario_aux mda WHERE ( mda.deleted IS NULL OR mda.deleted = 0 ) ";
			if( isset( $param['origem'] ) && !empty( $param['origem'] ) ){
				$query .= " and mda.origem = '$param[origem]'";
			}

			if( isset( $param['tipo'] ) && !empty( $param['tipo'] ) ){
				$query .= " and mda.tipo = '$param[tipo]'";
			}

			if( isset( $param['id_contrato'] ) && !empty( $param['id_contrato'] ) ){
				$query .= " and mda.id_contrato = $param[id_contrato]";
			}

			if( isset( $param['status'] ) && !empty( $param['status'] ) ){
				$query .= " and mda.status = '$param[status]' ";
			}

			$query .= " order by mda.data_tarifacao desc limit 1 ";
			return $this->db->exec( $query );
		}

		function getNotasComMD($emissao_de, $emissao_ate = null, $id_contrato = null, $adm = true){
			$query = null;
			$query .= " 
				select 
					nf.*,
					mda.id_nf_origem
				from 
					$this->table nf left join
					mov_diario_aux mda on(nf.id = id_nf_origem)
				where 
					(nf.deleted = 0 or nf.deleted is null) and 
					nf.status != 'cancelado' and 
					nf.status != 'descartado' 
				";
			if($emissao_de){
				$query .= " and nf.data_emissao >= '$emissao_de' ";
			}

			if($emissao_ate){
				$query .= " and nf.data_emissao <= '$emissao_ate' ";
			}

			if($id_contrato){
				$query .= " and nf.id_contrato = $id_contrato ";	
			}

			if(!$adm){
				$query .= " and nf.codigo_produto != 'ADM0001' ";	
			}
			return $this->db->exec($query);
		}

		function getNotaByPeriodoCorte($periodo_de, $periodo_ate = null, array $id_contrato = null, $cnpj_cpf_prestador = null, $adm = true){
			
			$query = null;
			$query .= " select * from $this->table where (deleted = 0 or deleted is null) and status != 'cancelado' and status != 'descartado' ";
			if($periodo_de){
				$query .= " and periodo_de >= '$periodo_de' ";
			}

			if($periodo_ate){
				$query .= " and periodo_ate <= '$periodo_ate' ";
			}

			if($id_contrato){
				$query .= " and id_contrato = $id_contrato ";	
			}

			if($cnpj_cpf_prestador){
				$query .= " and cnpj_cpf_prestador = $cnpj_cpf_prestador ";	
			}

			if(!$adm){
				$query .= " and codigo_produto != 'ADM0001' ";	
			}
			return $this->db->exec($query);
		}

		function getNotaByCobrancaReajuste(array $dados){
			$where = null;
			if($dados){
				$query = null;
				foreach ($dados as $key => $value) {
					if (end(array_keys($dados)) == $key){
						$where .= "(nf.id_contrato = ".$value['id_contrato']." and nf.periodo_de >= '".$value['periodo_de']."')";	
					}else{
						$where .= "(nf.id_contrato = ".$value['id_contrato']." and nf.periodo_de >= '".$value['periodo_de']."') or ";	
					}
				}
				$query .= " select con.data_assinatura, nf.* from $this->table nf inner join contratos con on(con.id = nf.id_contrato) where (nf.deleted = 0 or nf.deleted is null) and nf.status != 'cancelado' and nf.status != 'descartado' ";
				$query .= ' and ('.$where.') order by nf.cliente, nf.data_emissao';
				return $this->db->exec($query);
			}else{
				return false;
			}
			
		}

		function getNotaPorPeriodo($vencimento_de = null, $vencimento_ate = null, $id = null, $status = null, $rps = null, $tipo_data = null, $contrato_ativo = false){
			$query = " select tb1.*, tb1.status status_nf, tb2.id_produto, tb2.status status_contrato, tb2.enviar_email_cobranca from $this->table tb1 inner join contratos tb2 on(tb1.id_contrato = tb2.id) where (tb1.deleted = 0 or tb1.deleted is null) and tb1.status != 'cancelado' and tb1.status != 'descartado' ";
			if($id){
				$query .= " and tb1.id = $id ";
			}

			if($tipo_data == 'emissao'){
				if($vencimento_de){
					$query .= " and tb1.data_emissao >= '$vencimento_de' ";
				}

				if($vencimento_ate){
					$query .= " and tb1.data_emissao <= '$vencimento_ate' ";
				}
			}elseif($tipo_data == 'pagamento'){
				if($vencimento_de){
					$query .= " and tb1.recebido_em >= '$vencimento_de' ";
				}

				if($vencimento_ate){
					$query .= " and tb1.recebido_em <= '$vencimento_ate' ";
				}
			}else{
				if($vencimento_de){
					$query .= " and tb1.data_vencimento >= '$vencimento_de' ";
				}

				if($vencimento_ate){
					$query .= " and tb1.data_vencimento <= '$vencimento_ate' ";
				}
			}

			if($status){
				$query .= " and tb1.status = '$status' ";
			}

			if($contrato_ativo){
				$query .= " and tb2.status = 'ativo' ";
			}

			if($rps == '1'){
				$query .= " and tb1.gerar_rps = 1 ";
			}

			if($rps == '0'){
				$query .= " and tb1.gerar_rps = 0 ";
			}

			$query .= " order by tb1.data_vencimento ";
			return $this->db->exec($query);
		}

		function getNotasPorStatusOuAno($ano, $status = null){
			$query = " select distinct cliente, codigo_produto, ano_mes_referencia, valor_fatura, valor_total  from $this->table where (deleted = 0 or deleted is null)";
			if($status){
				$query .= " and status = '$status' ";
			}else{
				$query .= " and status != 'cancelado' && status != 'descartado'";
			}

			if($ano){
				$dt_ini = $ano.'-01-01';
				$dt_fim = $ano.'-12-31';
				$query .= " and data_emissao >= '$dt_ini' ";
				$query .= " and data_emissao <= '$dt_fim' ";
			}

			$query .= " order by data_vencimento asc";
			$exec = $this->db->query($query);
			if($exec){
			// Retorna
			$return = $exec->fetchAll();
				return json_encode($return);
			}else{
				return false;
			}
		}

		function getNotasPorStatusOuVencimento($status = null, $dt_vencimento = null, $id_contrato = null, $codigo_produto = null){
			$query = " select * from $this->table where (deleted = 0 or deleted is null)";
			if($status){
				$query .= " and status = '$status' ";
			}else{
				$query .= " and status != 'cancelado' ";
			}

			if($dt_vencimento){
				$query .= " and data_vencimento = '$dt_vencimento' ";
			}

			if($id_contrato){
				$query .= " and id_contrato = $id_contrato ";
			}

			if($id_contrato){
				$query .= " and codigo_produto = '$codigo_produto' ";
			}

			$query .= " order by data_vencimento asc";
			$exec = $this->db->query($query);
			if($exec){
				// Retorna
				$return = $exec->fetchAll();
				return json_encode($return);
			}else{
				return false;
			}
		}

		function getNotasVencidas(){
			$query = "
				select 
				nf.id id_nf,
				nf.id_contrato,
				nf.numero_fatura,
				nf.data_emissao,
				nf.data_vencimento,
				nf.cliente,
				nf.prestador_servico,
				nf.valor_total,
				CURDATE() data_atual, 
				DATEDIFF(CURDATE(), nf.data_vencimento) dias_atraso,
				co.codigo_pais,
				co.email_contato,
				co.status 
			from 
				notas_fiscais nf inner join 
				contratos co on(co.id = nf.id_contrato) 
			where 
				(nf.deleted is null or nf.deleted = 0) and 
				co.enviar_email_cobranca = 1 and 
				nf.status = 'receber' and 
				co.status = 'ativo' and
				nf.data_vencimento < CURDATE()
			";
			return $this->db->exec($query);
		}

		function getDadosCalendario(){
			$query = "SELECT REPLACE(REPLACE(REPLACE(FORMAT(sum(valor_total), 2),'.',';'),',','.'),';',',') valor_total, data_vencimento, recebido_em, status FROM notas_fiscais where (deleted = 0 or deleted is null) and status != 'cancelado' and status != 'descartado' group by data_vencimento, status ";
			return $this->db->exec($query);
		}

		function getNotasRps($id_nota = null, $cnpj_empresa_vendedora = null){
			$query = " select * from $this->table where (deleted = 0 or deleted is null)  and gerar_rps = 1  ";

			if($id_nota){
				$query .= " and id = $id_nota ";
			}

			if($cnpj_empresa_vendedora){
				$query .= " and cnpj_cpf_prestador = '$cnpj_empresa_vendedora' ";
			}
			$exec = $this->db->query($query);
			if($exec){
			// Retorna
			$return = $exec->fetchAll();
				return json_encode($return);
			}else{
				return false;
			}
		}

		function insertMovAux($param){
			return $this->db->insert('mov_diario_aux', $param);
		}

		function getTotalMovAuxPorProduto( $codigo_produto = null, $ano = null, $mes = null ){
			
			if($ano && !$mes){
				$dt_ini = $ano.'-01-01';
				$dt_fim = $ano.'-12-31';
			}elseif($ano && $mes){
				$ultimo_dia = cal_days_in_month(CAL_GREGORIAN, $mes, $ano);
				$dt_ini = $ano.'-'.$mes.'-01';
				$dt_fim = $ano.'-'.$mes.'-'.$ultimo_dia;
			}

			$query = "select sum(qtd_transacoes) transacoes, DATE_FORMAT( mda.data_tarifacao, '%Y' ) ano, DATE_FORMAT( mda.data_tarifacao, '%m' ) mes from mov_diario_aux mda where (mda.deleted = 0 or mda.deleted is null) ";
			if($codigo_produto){
				$query .= " and codigo_produto = '$codigo_produto'";
			}
			
			$query .= " and mda.data_tarifacao >= '$dt_ini' and mda.data_tarifacao <= '$dt_fim'";
			$query .= " group by ano, mes order by ano, mes ";
			return $this->db->exec($query);
		}
		
		function getTotalNFPorProduto($codigo_produto = null, $ano = null, $mes = null){
			if($ano && !$mes){
				$dt_ini = $ano.'-01-01';
				$dt_fim = $ano.'-12-31';
			}elseif($ano && $mes){
				$ultimo_dia = cal_days_in_month(CAL_GREGORIAN, $mes, $ano);
				$dt_ini = $ano.'-'.$mes.'-01';
				$dt_fim = $ano.'-'.$mes.'-'.$ultimo_dia;
			}
			$query = "select count(1) transacoes, DATE_FORMAT( nf.data_emissao, '%Y' ) ano, DATE_FORMAT( nf.data_emissao, '%m' ) mes from notas_fiscais nf where (nf.deleted = 0 or nf.deleted is null) and nf.status != 'cancelado' and status != 'descartado' ";
			if($codigo_produto){
				$query .= " and codigo_produto = '$codigo_produto'";
			}
			$query .= " and nf.data_emissao >= '$dt_ini' and nf.data_emissao <= '$dt_fim'";
			return $this->db->exec($query);
		}
		
		function getTotalNFPorProdutoResume($periodo_ini, $periodo_fim, $codigo_produto = null){
			$query = "
				SELECT
					codigo_produto, 
					COUNT(1) transacoes, 
					DATE_FORMAT(nf.data_emissao, '%Y') ano, 
					DATE_FORMAT(nf.data_emissao, '%m') mes
				FROM 
					notas_fiscais nf
				where 
					(deleted is null or deleted = 0)AND
					nf.status != 'cancelado' AND STATUS != 'descartado'
			";
			
			if($codigo_produto){
				$query .= " and codigo_produto = '$codigo_produto'";
			}
			
			$query .= " and nf.data_emissao >= '$periodo_ini' and nf.data_emissao <= '$periodo_fim'";
			$query .= "
			GROUP BY
				codigo_produto,
				ano,
				mes
			order by 
				ano, mes, codigo_produto
			";
			return $this->db->exec($query);
		}

		function checkMovAuxiliar($id_contrato = null, $de = null, $ate = null, $codigo_produto = null, $codigo_modulo = null, $status = 'pendente'){
			$query = " select distinct con.id id_contrato, con.nome_fantasia, pr.nome nome_produto, ev.razao_social razao_social_cm, con.data_corte_faturamento from mov_diario_aux mda inner join contratos con on( mda.id_contrato = con.id) inner join produtos pr on(pr.id = con.id_produto) inner join empresa_vendedora ev on(ev.id = con.id_empresa) where (mda.deleted = 0 or mda.deleted is null)";
			if( $id_contrato ){
				$query .= " and mda.id_contrato = '$id_contrato' ";
			}

			if( $de ){
				$query .= " and mda.data_tarifacao >= '$de' ";
			}

			if( $ate ){
				$query .= " and mda.data_tarifacao <= '$ate' ";
			}

			if($codigo_produto){
				$query .= " and mda.codigo_produto = '$codigo_produto' ";
			}

			if($codigo_modulo){
				$query .= " and mda.codigo_modulo = '$codigo_modulo' ";
			}
			if($status){
				$query .= " and mda.status = '$status' ";
			}
			return $this->db->exec($query);
		}

		function getMovAuxiliar($status = null, $origem, $tipo,  $descricao = null, $id_nota_origem = null, $id_contrato = null){
			$query = "
				select 
					mda.id   id_mov_aux,
					mda.tipo tipo_mov_aux,
					mda.id_nf,
					mda.id_nf_origem,
					mda.origem,
					mda.descricao,
					mda.qtd_transacoes transacoes,
					mda.valor_base,
					mda.valor_calculado,
					mda.data_tarifacao,
					mda.vencimento_em,
					mda.recebido_em,
					mda.status,
					mda.data_tarifacao,
					mda.data_tarifacao
				from 
					mov_diario_aux mda left join 
					notas_fiscais nf on(nf.id = mda.id_nf_origem)
				where 
					(mda.deleted = 0 or mda.deleted is null)
			";

			if($status){
				$query .= " and mda.`status` = '$status' ";
			}

			if($origem){
				$query .= " and mda.origem = '$origem' ";
			}

			if($tipo){
				$query .= " and mda.tipo = '$tipo' ";
			}

			if($descricao){
				$query .= " and mda.descricao = '$descricao' ";
			}

			if($id_nota_origem){
				$query .= " and mda.id_nf_origem = '$id_nota_origem' ";
			}

			if($id_contrato){
				$query .= " and mda.id_contrato = '$id_contrato' ";
			}
			return $this->db->exec($query);
		}

		//verificar funcao no lugar errado
		function getLancamentoManual($id_contrato = null, $origem = null, $tipo = null,  $descricao = null, $status = null){
			$query = " select * from mov_diario_aux mda where (mda.deleted = 0 or mda.deleted is null)";

			if($status){
				$query .= " and mda.`status` = '$status' ";
			}

			if($origem){
				$query .= " and mda.origem = '$origem' ";
			}

			if($tipo){
				$query .= " and mda.tipo = '$tipo' ";
			}

			if($descricao){
				$query .= " and mda.descricao = '$descricao' ";
			}

			if($id_contrato){
				$query .= " and mda.id_contrato = '$id_contrato' ";
			}
			$exec = $this->db->query($query);
			if($exec){
				// Retorna
				$return = $exec->fetchAll();
				return json_encode($return);
			}else{
				return false;
			}
		}

		function updateMovAux($id, $param){
			if($id && $param){
				$table = 'mov_diario_aux';
				$where_field = 'id';
				$where_field_value = $id;
				$values = $param;
				return $this->db->update($table, $where_field, $where_field_value, $values );
			}else{
				return false;
			}
		}

		function countStatus(){
			$query = "SELECT REPLACE(REPLACE(REPLACE(FORMAT(sum(valor_total), 2),'.',';'),',','.'),';',',') valor_total, count(1) quantidade, `status`, data_vencimento FROM notas_fiscais where deleted = 0  and status != 'descartado' and status != 'cancelado' group by `status`, data_vencimento;";
			$exec = $this->db->query($query);
			if($exec){
				// Retorna
				$return = $exec->fetchAll();
				return json_encode($return);
			}else{
				return false;
			}
		}

		//funcoes novas para substituir as atuais
		function getNotasPorRemessa( $numero_remessa, $cnpj_prestador = null, $inc_adm = true ){
			$query = "select nfr.id id_remessa, nf.numero numero_fatura, nf.id id_nf, nf.cliente, nf.codigo_produto, nf.data_emissao, nf.valor_total, nf.data_vencimento, nf.status from nf_remessas nfr inner join notas_fiscais nf on(nf.id = nfr.id_nf) where (nf.deleted = 0 or nf.deleted is null) and (nfr.deleted = 0 or nfr.deleted is null)";
			if($numero_remessa){
				$query .= " and nfr.numero_remessa = $numero_remessa";
			}

			if($cnpj_prestador){
				$query .= " and nfr.cnpj_prestador = $cnpj_prestador";
			}
			return $this->db->exec($query);
		}

		function getLastNota( $id_contrato = null, $codigo_produto = null, $codigo_modulo = null, $cnpj_cpf_prestador = null, $inc_adm = true, $tipo = null ){
			$query = "select * from notas_fiscais nf where (nf.deleted = 0 or nf.deleted is null) and nf.status != 'cancelado' and nf.status != 'descartado' ";

			if( $tipo ){
				$query .= " and nf.tipo = '$tipo' ";
			}

			if( $id_contrato ){
				$query .= " and nf.id_contrato = $id_contrato ";
			}

			if( $codigo_produto ){
				$query .= " and nf.codigo_produto = '$codigo_produto' ";
			}

			if( $codigo_modulo ){
				$query .= " and nf.codigo_modulo = '$codigo_modulo' ";
			}

			if( $cnpj_cpf_prestador ){
				$query .= " and nf.cnpj_cpf_prestador = '$cnpj_cpf_prestador' ";
			}

			if( $inc_adm == false ){
				$query .= " and nf.codigo_produto != 'ADM0001' ";
			}

			$query .= 'order by nf.numero desc, id desc limit 1';
			return $this->db->exec($query);
		}

		function getFirstNota( $id_contrato = null, $codigo_produto = null, $codigo_modulo = null, $cnpj_cpf_prestador = null, $inc_adm = true, $tipo = null ){
			$query = "select * from notas_fiscais nf where (nf.deleted = 0 or nf.deleted is null) and nf.status != 'cancelado' and nf.status != 'descartado' ";

			if($id_contrato){
				$query .= " and nf.id_contrato = $id_contrato ";
			}

			if($codigo_produto){
				$query .= " and nf.codigo_produto = '$codigo_produto' ";
			}

			if($codigo_modulo){
				$query .= " and nf.codigo_modulo = '$codigo_modulo' ";
			}

			if($cnpj_cpf_prestador){
				$query .= " and nf.cnpj_cpf_prestador = '$cnpj_cpf_prestador' ";
			}

			if($inc_adm == false){
				$query .= " and nf.codigo_produto != 'ADM0001' ";
			}
			
			if($tipo){
				$query .= " and nf.tipo = '$tipo' ";
			}

			$query .= 'order by nf.numero asc, id asc limit 1';
			return $this->db->exec($query);
		}

		function getNotaEcontrato($id_nota = null){
			$query = "
				select
					nf.*,
					co.data_assinatura,
					co.multa,
					co.juros
				from
					notas_fiscais nf left join
					contratos co on (co.id = nf.id_contrato)
				where
					(nf.deleted = 0 or nf.deleted is null) AND
					nf.status != 'descartado' AND
					nf.status != 'cancelado'
			";

			if(is_array($id_nota)){
				$query .= " and nf.id in(".implode(",", $id_nota).")";
			}else{
				$query .= " and nf.id = $id_nota ";
			}
			return $this->db->exec($query);
		}

		function mediaSomaNotas($ano  = null, $mes = null){
			$query = null;
			$query .= " select count(1) contador_notas, sum(valor_total) valor_total from notas_fiscais where (deleted = 0 or deleted is null) and status != 'cancelado' and status != 'descartado' ";

			if($ano && !$mes){
				$dt_ini = $ano.'-01-01';
				$dt_fim = $ano.'-12-31';
			}elseif($ano && $mes){
				$ultimo_dia = cal_days_in_month(CAL_GREGORIAN, $mes, $ano);
				$dt_ini = $ano.'-'.$mes.'-01';
				$dt_fim = $ano.'-'.$mes.'-'.$ultimo_dia;
			}

			if($ano || $mes){
				$query .= " and data_emissao >= '$dt_ini' and data_emissao <= '$dt_fim' ";
			}
			return $this->db->exec($query);
		}

		function update($table, $where_field, $where_field_value, $values){
			if(!$table){
				$table = 'notas_fiscais';
			}
			return $this->db->update($table, $where_field, $where_field_value, $values);
		}

		function getNfRelacionamento($ano, $tipo = 'upselling'){
			if(!empty($ano) && is_numeric($ano)){
				
				$dt_ini = $ano.'-01-01';
				$dt_fim = $ano.'-12-31';
				
				$query = "
					SELECT 
						con.razao_social,
						con.data_assinatura,
						con.nome_fantasia,
						con.codigo_cliente,
						nf.id id_nf,
						nf.valor_fatura,
						nf.codigo_produto,
						DATE_FORMAT(nf.data_emissao, '%Y') ano,
						DATE_FORMAT(nf.data_emissao, '%m') mes,
						sum(nf.valor_liquido) valor_liquido,
						sum(nf.valor_total) valor_total
					FROM
						notas_fiscais nf LEFT JOIN
						contratos con ON(con.id = nf.id_contrato)
					WHERE
						(nf.deleted = 0 OR nf.deleted IS NULL) and
						(nf.STATUS  = 'receber' OR nf.status = 'recebido') and
						nf.data_emissao >= '$dt_ini' AND 
						nf.data_emissao <= '$dt_fim'
				";

				if($tipo == 'upselling'){
					$query .= " and con.data_assinatura < '$dt_ini' and con.upselling = 1";
				}

				$query .= "
					GROUP BY
						con.razao_social,
						con.nome_fantasia,
						con.codigo_cliente,
						nf.codigo_produto,
						ano,
						mes
					ORDER	BY	
						mes,
						con.nome_fantasia,
						nf.codigo_produto,
						con.data_assinatura 
				";
				return $this->db->exec($query);
			}else{
				return false;
			}
		}

		function getNfRecebimento($ano){
			if(!empty($ano) && is_numeric($ano)){
				
				$dt_ini = $ano.'-01-01';
				$dt_fim = $ano.'-12-31';
				
				$query = "
					SELECT 
						con.razao_social,
						con.data_assinatura,
						con.nome_fantasia,
						con.codigo_cliente,
						nf.id id_nf,
						nf.codigo_produto,
						DATE_FORMAT(nf.recebido_em, '%Y') ano,
						DATE_FORMAT(nf.recebido_em, '%m') mes,
						sum(nf.valor_fatura) valor_fatura,
						sum(nf.valor_liquido) valor_liquido,
						sum(nf.valor_total) valor_total
					FROM
						notas_fiscais nf LEFT JOIN
						contratos con ON(con.id = nf.id_contrato)
					WHERE
						(nf.deleted = 0 OR nf.deleted IS NULL) and
						nf.status = 'recebido' and
						nf.recebido_em >= '$dt_ini' AND 
						nf.recebido_em <= '$dt_fim' and
						nf.recebido_em is not null
				";

				$query .= "
					GROUP BY
						con.razao_social,
						con.nome_fantasia,
						con.codigo_cliente,
						nf.codigo_produto,
						ano,
						mes
					ORDER	BY	
						mes,
						con.nome_fantasia,
						nf.codigo_produto,
						con.data_assinatura 
				";
				return $this->db->exec($query);
			}else{
				return false;
			}
		}
		
		function getNotaByCodigo($codigo_acesso, $cnpj_cliente = null){
			$query = " select * from $this->table where (deleted = 0 or deleted is null) and status != 'cancelado' and status != 'descartado' ";
			if($codigo_acesso){
				$query .= " and codigo_acesso = '$codigo_acesso' ";
			}

			if($cnpj_cliente){
				$query .= " and cnpj_cpf_cliente = '$cnpj_cliente' ";
			}
			
			$query .= " order by cliente ";
			
			return $this->db->exec($query);
		}

		function getNotaResumeGroup($tipo, $periodo_ini, $periodo_fim, $status = null){
			$query = " select ";

			if('vencimento' == $tipo){
				$query .= "
					DATE_FORMAT(nf.data_vencimento, '%Y') ano_vencimento,
					DATE_FORMAT(nf.data_vencimento, '%m') mes_vencimento,
				";
			}elseif('emissao' == $tipo){
				$query .= "
					DATE_FORMAT(nf.data_emissao, '%Y') ano_emissao,
					DATE_FORMAT(nf.data_emissao, '%m') mes_emissao,
				";
			}elseif('recebimento' == $tipo){
				$query .= "
					DATE_FORMAT(nf.recebido_em, '%Y') ano_recebimento,
					DATE_FORMAT(nf.recebido_em, '%m') mes_recebimento,
				";
			}

			$query .= "
					SUM(nf.valor_liquido)  total_liquido,
					SUM(nf.valor_impostos)  total_impostos,
					SUM(nf.valor_impostos_retidos)  total_impostos_retidos,
					SUM(nf.valor_desconto) total_desconto,
					SUM(nf.valor_fatura)   total_fatura,
					SUM(nf.valor_total)    total_final	
				from 
					notas_fiscais nf 
				where 
					(nf.deleted = 0 or nf.deleted is null)
			";


			if($status){
				$query .= " and nf.status = '$status' ";
			}else{
				$query .= " and nf.status != 'cancelado' and nf.status != 'descartado' and nf.status != 'perdido' ";
			}

			if('vencimento' == $tipo){
				$query .= " and nf.data_vencimento >= '".$periodo_ini."' and nf.data_vencimento <= '".$periodo_fim."'";
			}elseif('emissao' == $tipo){
				$query .= " and nf.data_emissao >= '".$periodo_ini."' and nf.data_emissao <= '".$periodo_fim."'";
			}elseif('recebimento' == $tipo){
				$query .= " and nf.recebido_em >= '".$periodo_ini."' and nf.recebido_em <= '".$periodo_fim."'";
			}

			if('vencimento' == $tipo){
				$query .= "
					group by
						ano_vencimento,
						mes_vencimento
				";
			}elseif('emissao' == $tipo){
				$query .= "
					group by
						ano_emissao,
						mes_emissao
				";
			}elseif('recebimento' == $tipo){
				$query .= "
					group by
						ano_recebimento,
						mes_recebimento
				";
			}
			return $this->db->exec($query);

		}

		function getNotaResume($tipo, $periodo_ini, $periodo_fim, $status = null){
			$query = "
				select
					SUM(nf.valor_liquido)  total_liquido,
					SUM(nf.valor_impostos)  total_impostos,
					SUM(nf.valor_impostos_retidos)  total_impostos_retidos,
					SUM(nf.valor_desconto) total_desconto,
					SUM(nf.valor_fatura)   total_fatura,
					SUM(nf.valor_total)    total_final	
				from 
					notas_fiscais nf 
				where 
					(nf.deleted = 0 or nf.deleted is null)
			";


			if($status){
				$query .= " and nf.status = '$status' ";
			}else{
				$query .= " and nf.status != 'cancelado' and nf.status != 'descartado' and nf.status != 'perdido' ";
			}

			if('vencimento' == $tipo){
				$query .= " and nf.data_vencimento >= '".$periodo_ini."' and nf.data_vencimento <= '".$periodo_fim."'";
			}elseif('emissao' == $tipo){
				$query .= " and nf.data_emissao >= '".$periodo_ini."' and nf.data_emissao <= '".$periodo_fim."'";
			}elseif('recebimento' == $tipo){
				$query .= " and nf.recebido_em >= '".$periodo_ini."' and nf.recebido_em <= '".$periodo_fim."'";
			}
			return $this->db->exec($query);
		}
		
		function getSomaNotaByPeriodo($tipo = 'vencimento', $periodo_ini, $periodo_fim, $status){
			$query = "
				select		
					SUM(nf.valor_liquido)  total_liquido,
					SUM(nf.valor_impostos) total_impostos,
					SUM(nf.valor_impostos_retidos)  total_impostos_retidos,
					SUM(nf.valor_desconto) total_desconto,
					SUM(nf.valor_fatura)   total_fatura,
					SUM(nf.valor_total)    total_final
				from 
					notas_fiscais nf 
				where 
					(nf.deleted = 0 or nf.deleted is null)
			";

			if($status){
				$query .= " and nf.status = '$status' ";
			}else{
				$query .= " and nf.status != 'cancelado' and nf.status != 'descartado' and nf.status != 'perdido' ";
			}

			if('vencimento' == $tipo){
				$query .= " and nf.data_vencimento >= '".$periodo_ini."' and nf.data_vencimento <= '".$periodo_fim."'";
			}elseif('emissao' == $tipo){
				$query .= " and nf.data_emissao >= '".$periodo_ini."' and nf.data_emissao <= '".$periodo_fim."'";
			}elseif('recebimento' == $tipo){
				$query .= " and nf.recebido_em >= '".$periodo_ini."' and nf.recebido_em <= '".$periodo_fim."'";
			}
			return $this->db->exec($query);
		}
		
		function getNfMovAux($dt_ini, $dt_fim, $tipo_data = 'vencimento', $codigo_cliente = null, $codigo_produto  = null){
			$query = "
				SELECT 
					con.multa percentual_multa,
					con.multa percentual_juros,
					con.nome_fantasia,
					con.data_reajuste,
					con.data_assinatura,
					con.indice_reajuste,
					pr.nome produto_nome,
					nf.id nf_id,
					nf.id_contrato,
					nf.data_emissao,
					nf.data_vencimento,
					nf.recebido_em,
					nf.valor_liquido,
					mva.id mva_id,
					mva.id_nf_origem,
					mva.origem,
					mva.valor_base,
					mva.valor_calculado,
					mva.status status_lancamento,
					mva.data_tarifacao,
					DATEDIFF(nf.recebido_em, nf.data_vencimento) dias_atraso
				FROM 
					notas_fiscais nf inner join
					contratos con on(nf.id_contrato = con.id) inner join
					produtos pr on(con.id_produto = pr.id)LEFT join
					mov_diario_aux mva ON(nf.id = mva.id_nf_origem) 
				WHERE 
					(mva.deleted is null or mva.deleted = 0) AND
					nf.recebido_em is not null
			";

			if($dt_ini){
				switch ($tipo_data) {
					case 'vencimento':
						$query.= " and nf.data_vencimento >= '$dt_ini'";
					break;
					case 'pagamento':
						$query.= " and nf.recebido_em >= '$dt_ini'";
					break;
					case 'emissao':
						$query.= " and nf.data_emissao >= '$dt_ini'";
					break;
				}
			}

			if($dt_fim){
				switch ($tipo_data) {
					case 'vencimento':
						$query.= " and nf.data_vencimento <= '$dt_fim'";
					break;
					case 'pagamento':
						$query.= " and nf.recebido_em <= '$dt_fim'";
					break;
					case 'emissao':
						$query.= " and nf.data_emissao <= '$dt_fim'";
					break;
				}
			}

			if($codigo_cliente){
				$query.= " and nf.codigo_cliente = '$codigo_cliente' ";
			}

			if($codigo_produto){
				$query.= " and nf.codigo_produto = '$codigo_produto' ";
			}

			$query .= "order by nf.data_vencimento desc";
			return $this->db->exec($query);
		}
		
		function getNfPagaEmAtraso($dias = null){
			$query = "
				SELECT
					nf.id id_nota,
					nf.id_contrato,
					co.razao_social,
					co.codigo_cliente,
					co.multa percentual_multa,
					co.juros percentual_juros,
					pr.id id_produto,
					pr.codigo codigo_produto,
					nf.valor_liquido,
					valor_total,
					nf.data_emissao,
					nf.data_vencimento,
					nf.recebido_em,
					DATEDIFF(nf.recebido_em, nf.data_vencimento) diff,
					mda.id id_mda
				FROM
					notas_fiscais nf inner join
					contratos co on(nf.id_contrato = co.id)	inner join
					produtos pr on(co.id_produto = pr.id) LEFT join
					mov_diario_aux mda ON(nf.id = mda.id_nf_origem)
				WHERE
					(nf.deleted IS NULL OR nf.deleted = 0) and
					nf.status = 'recebido' AND nf.data_vencimento < nf.recebido_em and
					mda.id IS NULL
					
			";
			if($dias){
				$query .= " AND diff > $dias ";
			}
			return $this->db->exec($query);
		}
		
		function getSomaNotaByPeriodoEcontrato($periodo_ini, $periodo_fim, $id_contrato, $tipo_data = 'emissao', $status = null){
			$query = "
				select		
					nf.id_contrato,
					nf.cliente,
					pr.nome produto, 
					COUNT(1) total_notas,
					SUM(nf.valor_liquido)  total_liquido,
					SUM(nf.valor_impostos) total_impostos,
					SUM(nf.valor_impostos_retidos)  total_impostos_retidos,
					SUM(nf.valor_desconto) total_desconto,
					SUM(nf.valor_fatura)   total_fatura,
					SUM(nf.valor_total)    total_final
				from 
					notas_fiscais nf INNER JOIN
					contratos con ON(nf.id_contrato = con.id) INNER JOIN 
					produtos pr ON(con.id_produto = pr.id)
				where 
					(nf.deleted = 0 or nf.deleted is null)
			";

			if(is_array($id_contrato)){
				$query .= " and nf.id_contrato in(".implode(",", $id_contrato).")";
			}else{
				$query .= " and nf.id_contrato = $id_contrato ";	
			}

			if($status){
				$query .= " and nf.status = '$status' ";
			}else{
				$query .= " and nf.status != 'cancelado' and nf.status != 'descartado' and nf.status != 'perdido' ";
			}

			if('vencimento' == $tipo_data){
				$query .= " and nf.data_vencimento >= '".$periodo_ini."' and nf.data_vencimento <= '".$periodo_fim."'";
			}elseif('emissao' == $tipo_data){
				$query .= " and nf.data_emissao >= '".$periodo_ini."' and nf.data_emissao <= '".$periodo_fim."'";
			}elseif('recebimento' == $tipo_data){
				$query .= " and nf.recebido_em >= '".$periodo_ini."' and nf.recebido_em <= '".$periodo_fim."'";
			}
			$query .= " group by nf.id_contrato, pr.nome order by nf.cliente ";
			return $this->db->exec($query);
		}
	}