<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class OrcamentoModel extends MainModel{
    //A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
    public function __construct( $controller = null ){
        $this->table = 'orc_lancamento';
        parent::__construct($controller);
    }

    /* funções abaixo serão desativadas futuramente */

    function getLancamentos(){
        $args = func_get_args();
        //$args[0] = Ano
        //$args[1] = Mes inicial
        //$args[2] = Mes final
        //$args[3] = id do centro de custo
        //$args[4] = id do grupo
        //$args[5] = id da conta
        //$args[6] = id da subconta

        $query = "
            select
                ol.ano,
                ol.mes,
                ol.valor,
                ol.operacao,
                ol.tipo,
                occ.id id_centro_custo,
                occ.nome centro_custo,
                grp.id id_grupo,
                grp.nome grupo,
                con.id id_conta,
                con.nome conta,
                sub.nome subconta
            FROM 
                orc_lancamento ol left join
                orc_centro_custo occ on(ol.id_cc = occ.id) left join
				orc_grupo grp on(grp.id = ol.id_grupo) left join
				orc_conta con on(con.id = ol.id_conta) left join
				orc_conta sub on(sub.id = ol.id_subconta)
            WHERE 
                (ol.deleted is null or ol.deleted = 0)
        ";

        if($args[0]){
			$query .= " and ol.ano = '".$args[0]."' ";
		}

        if($args[1] && $args[2]){
            $query .= " and ol.mes >= '".$args[1]."' and ol.mes <= '".$args[2]."'";
        }elseif($args[1]){
            $query .= " and ol.mes = '".$args[1]."' ";
        }elseif($args[2]){
            $query .= " and ol.mes <= '".$args[2]."' ";
        }
        $query .= " order by occ.nome, ol.ano, ol.mes ";
        return $this->db->exec($query);
    }

    function getDefault($tipo){
        if('grupo' == $tipo){
            $query = " select * from orc_grupo where (deleted = 0 or deleted is null) and nome = 'Default' ";    
        }elseif('conta' == $tipo ){
            $query = " select * from orc_conta where (deleted = 0 or deleted is null) and nome = 'Default' ";
        }
        return $this->db->exec($query);
    }

    function getCentroCusto($id = null, $nome = null){
        $query = " select * from orc_centro_custo where (deleted = 0 or deleted is null) ";
        
        if($id){
            $query .= " and id= $id ";
        }

        if($nome){
            $query .= " and nome = '$nome' ";
        }

        $query .= " order by nome";
        return $this->db->exec($query);
    }

    function getConta($id = null, $nome = null){
        
        $query = " select * from orc_conta where (deleted = 0 or deleted is null) and tipo = 'conta' and id != 1000004 ";
        
        if($id){
            $query .= " and id= $id ";
        }
        
        if($nome){
            $query .= " and nome = '$nome' ";
        }    

        $query .= " order by nome";
        return $this->db->exec($query);
    }

    function getGrupo($id = null, $nome = null){
        $query = " select * from orc_grupo where (deleted = 0 or deleted is null) and id != '1000000' ";
        if($id){
            $query .= " and id= $id ";
        }
        
        if($nome){
            $query .= " and nome = '$nome' ";
        }        

        $query .= " order by nome";
        return $this->db->exec($query);
    }

    function getSubConta($id = null, $nome = null){
        
        $query = " select * from orc_conta where (deleted = 0 or deleted is null) and tipo = 'subconta' and id != 1000004";
        
        if($id){
            $query .= " and id = $id ";
        }
            
        if($nome){
            $query .= " and nome = '$nome' ";
        }

        $query .= " order by nome";
        return $this->db->exec($query);
    }

    function getSubContaByConta($id = null, $nome = null){
        
        $query = " select * from orc_conta where (deleted = 0 or deleted is null) and tipo = 'subconta' ";
        
        if($id){
            $query .= " and id_conta = $id ";
        }

        if($nome){
            $query .= " and nome = '$nome' ";
        }

        $query .= " order by nome";

        return $this->db->exec($query);
    }

    function getLancamento($id=null){
        $query = " SELECT distinct
                occ.id id_occ,
                ocg.id id_ocg,
                oco.id id_oco,
                ocs.id id_ocs,
                occ.nome occ_nome,
                ocg.nome ocg_nome,
                oco.nome oco_nome,
                ocs.nome ocs_nome,
                lc.ano,
                lc.tipo
            FROM
                orc_lancamento lc inner join
                orc_centro_custo occ on(lc.id_cc = occ.id) inner join
                orc_grupo ocg on(lc.id_grupo = ocg.id) inner join
                orc_conta oco on (lc.id_conta = oco.id) inner join
                orc_conta ocs on(lc.id_subconta = ocs.id)
            where
                (lc.deleted = 0 or lc.deleted is null ) and
                (occ.deleted = 0 or occ.deleted is null ) and
                (ocg.deleted = 0 or ocg.deleted is null ) and
                (oco.deleted = 0 or oco.deleted is null ) and
                (ocs.deleted = 0 or ocs.deleted is null )
            ";
        if($id){
            $query .= " and lc.id= $id ";
        }
        $query .= " order by lc.ano, lc.mes";
        return $this->db->exec($query);
    }

    function getLancamentoByParam($id_occ, $id_ocg, $ano){
        $query = " SELECT distinct
                lc.id id_lc,
                occ.id id_occ,
                ocg.id id_ocg,
                oco.id id_oco,
                ocs.id id_ocs,
                occ.nome occ_nome,
                ocg.nome ocg_nome,
                oco.nome oco_nome,
                ocs.nome ocs_nome,
                lc.ano,
                lc.mes,
                lc.valor,
                lc.tipo
            FROM
                orc_lancamento lc inner join
                orc_centro_custo occ on(lc.id_cc = occ.id) inner join
                orc_grupo ocg on(lc.id_grupo = ocg.id) inner join
                orc_conta oco on (lc.id_conta = oco.id) inner join
                orc_conta ocs on(lc.id_subconta = ocs.id)
            where
                (lc.deleted = 0 or lc.deleted is null ) and
                (occ.deleted = 0 or occ.deleted is null ) and
                (ocg.deleted = 0 or ocg.deleted is null ) and
                (oco.deleted = 0 or oco.deleted is null ) and
                (ocs.deleted = 0 or ocs.deleted is null )";

        $query .= " and lc.id_cc = $id_occ and lc.id_grupo = $id_ocg and lc.ano = '$ano' ";
        $query .= " order by lc.ano, lc.mes";
        return $this->db->exec($query);
    }

    function checkTotalLancamentos($id_occ, $id_ocg, $id_oco, $id_ocs, $ano, $mes){
        $query = "
            SELECT distinct
                sum(valor) total_lancamentos
            FROM
                orc_lancamento lc
            where
                (lc.deleted = 0 or lc.deleted is null )";

        $query .= " and lc.id_cc = $id_occ and lc.id_grupo = $id_ocg and lc.id_conta = $id_oco and lc.ano = '$ano' and lc.mes = '$mes'";
        $query .= " order by lc.ano, lc.mes";
        return $this->db->exec($query);
    }

    function checkTotalOrcamento($id_occ, $id_ocg, $id_oco, $id_ocs, $ano, $mes){
        $query = "
        select
            sum(valor) total_orcamento
        from
            orc_lancamento
        where
            (deleted = 0 or deleted is null) and
            id_cc = $id_occ and
            id_grupo = $id_ocg and
            id_conta = $id_oco and
            id_subconta = $id_ocs and
            ano = $ano and
            mes = $mes
        ";
        return $this->db->exec($query);
    }

    function getSaldo($param){
       
        $query = "select sum(valor) valor_orcamento, tb1.ano, tb1.mes from orc_lancamento tb1 where (tb1.deleted = 0 or tb1.deleted is null) ";

        if($param['id_cc']){
            $query .= " and tb1.id_cc = ".$param['id_cc'];
        }

        if($param['dt_ini']){
            $query .= " and tb1.ano >= '".$param['dt_ini']->format('Y')."'";
            $query .= " and tb1.mes >= '".$param['dt_ini']->format('m')."'";
        }

        if($param['dt_fim']){
            $query .= " and tb1.ano <= '".$param['dt_fim']->format('Y')."'";
            $query .= " and tb1.mes <= '".$param['dt_fim']->format('m')."'";
        }
        $query .= ' group by tb1.ano, tb1.mes ';
        return $this->db->exec($query);
    }

    
    function getSaldoNew(array $param, $agrupar_mes = false){
        
        if('conta' == $param['join']){
            $query = "select sum(valor) valor_total, tb1.id_cc, tb2.nome centro_custo, tb1.ano, tb1.mes from orc_lancamento tb1 inner join orc_conta tb2 on(tb1.id_conta = tb2.id) where (tb1.deleted = 0 or tb1.deleted is null) ";
        }elseif('grupo' == $param['join']){
            $query = "select sum(valor) valor_total, tb1.id_cc, tb2.nome centro_custo, tb1.ano, tb1.mes from orc_lancamento tb1 inner join orc_grupo tb2 on(tb1.id_grupo = tb2.id) where (tb1.deleted = 0 or tb1.deleted is null) ";
        }else{
            $query = "select sum(valor) valor_total, tb1.id_cc, tb2.nome centro_custo, tb1.ano, tb1.mes from orc_lancamento tb1 inner join orc_centro_custo tb2 on(tb1.id_cc = tb2.id) where (tb1.deleted = 0 or tb1.deleted is null) ";
        }

        if(isset($param['centro_custo']) && is_array($param['centro_custo'])){
            $query .= " and tb1.id_cc in(".implode(',', $param['centro_custo']).")";
        }elseif(isset($param['centro_custo'])){
            $query .= " and tb1.id_cc = ".$param['centro_custo'];
        }

        if(isset($param['grupo']) && is_array($param['grupo'])){
            $query .= " and tb1.id_grupo in(".implode(',', $param['grupo']).")";
        }elseif(isset($param['grupo'])){
            $query .= " and tb1.id_grupo = ".$param['grupo'];
        }

        if(isset($param['conta']) && is_array($param['conta'])){
            $query .= " and tb1.id_conta in(".implode(',', $param['conta']).")";
        }elseif(isset($param['conta'])){
            $query .= " and tb1.id_conta = ".$param['conta'];
        }

        if(isset($param['subconta']) && is_array($param['subconta'])){
            $query .= " and tb1.id_conta in(".implode(',', $param['subconta']).")";
        }elseif(isset($param['subconta'])){
            $query .= " and tb1.id_conta = ".$param['subconta'];
        }

        if(isset($param['meses']) && is_array($param['meses'])){
            $query .= " and tb1.mes in(".implode(',', $param['meses']).")";
        }elseif(isset($param['meses'])){
            $query .= " and tb1.mes = ".$param['meses'];
        }

        if(isset($param['ano']) && is_array($param['ano'])){
            $query .= " and tb1.ano in(".implode(',', $param['ano']).")";
        }elseif(isset($param['ano'])){
            $query .= " and tb1.ano = ".$param['ano'];
        }

        if(isset($param['tipo']) && is_array($param['tipo'])){
            $query .= " and tb1.tipo in(".implode(',', $param['tipo']).")";
        }elseif(isset($param['tipo'])){
            $query .= " and tb1.tipo = '".$param['tipo']."'";
        }

        if($agrupar_mes){
            $query .= ' group by tb2.nome, tb1.ano, tb1.mes ';
        }else{
            $query .= ' group by tb2.nome, tb1.ano ';
        }
        return $this->db->exec($query);
    }


    //apagar essa funcao depois que estiver totalmente migrado
    function getSaldoCentroCusto($id = null, $dt_vencimento = null, $tipo = null){
        $query = "select sum(valor) valor_total, tb1.id_cc, tb2.nome centro_custo, tb1.ano, tb1.mes from orc_lancamento tb1 inner join orc_centro_custo tb2 on(tb1.id_cc = tb2.id) where (tb1.deleted = 0 or tb1.deleted is null) ";
        
        if(is_array($id)){
            $query .= " and tb1.id_cc in(".implode(',', $id).")";
        }elseif($id){
            $query .= " and tb1.id_cc = $id ";
        }
        
        if($tipo){
            $query .= " and tb1.tipo = '$tipo' ";
        }

        if($dt_vencimento){
            $query .= " and tb1.ano = '".$dt_vencimento->format('Y')."'";
            $query .= " and tb1.mes = '".$dt_vencimento->format('m')."'";
        }
        $query .= ' group by tb1.id_cc, tb2.nome, tb1.ano, tb1.mes ';
        return $this->db->exec($query);
    }

    function getSaldoGrupo($id_grupo = null, $id_centro_custo = null, $dt_vencimento, $tipo = null){
        $query = "select sum(valor) valor_total, tb1.id_grupo, tb2.nome nome_grupo, tb1.ano, tb1.mes from orc_lancamento tb1 inner join orc_grupo tb2 on(tb1.id_grupo = tb2.id) where (tb1.deleted = 0 or tb1.deleted is null) ";
        if($id_grupo){
            $query .= " and id_grupo = $id_grupo ";
        }

        if($id_centro_custo){
            $query .= " and tb1.id_cc = $id_centro_custo ";
        }
        if($tipo){
            $query .= " and tb1.tipo = '$tipo' ";
        }
        if($dt_vencimento){
            $query .= " and tb1.ano = '".$dt_vencimento->format('Y')."'";
            $query .= " and tb1.mes = '".$dt_vencimento->format('m')."'";
        }
        return $this->db->exec($query);
    }

    function getSaldoConta($id_conta = null, $id_grupo = null, $id_centro_custo = null,  $dt_vencimento = null, $tipo = null){
        $query = "select sum(valor) valor_total, tb1.id_conta, tb2.nome nome_conta, tb1.ano, tb1.mes from orc_lancamento tb1 inner join orc_conta tb2 on(tb1.id_conta = tb2.id) where (tb1.deleted = 0 or tb1.deleted is null) and tb2.tipo = 'conta' ";
        $exec = $this->db->query($query);
        if($id_conta){
            $query .= " and tb1.id_conta = $id_conta ";
        }
        if($id_centro_custo){
            $query .= " and tb1.id_cc = $id_centro_custo ";
        }
        if($id_grupo){
            $query .= " and tb1.id_grupo = $id_grupo ";
        }
        if($tipo){
            $query .= " and tb1.tipo = '$tipo' ";
        }
        if($dt_vencimento){
            $query .= " and tb1.ano = '".$dt_vencimento->format('Y')."'";
            $query .= " and tb1.mes = '".$dt_vencimento->format('m')."'";
        }
        return $this->db->exec($query);
    }

    function getSaldoSubConta($id_subconta = null, $id_conta = null, $id_grupo = null, $id_centro_custo = null, $dt_vencimento, $tipo = null){
        $query = "select sum(valor) valor_total, tb1.id_subconta, tb2.nome nome_subconta, tb1.ano, tb1.mes from orc_lancamento tb1 inner join orc_conta tb2 on(tb1.id_subconta = tb2.id)  where (tb1.deleted = 0 or tb1.deleted is null) and tb2.tipo = 'subconta' ";
        $exec = $this->db->query($query);
        if($id_conta){
            $query .= " and tb1.id_conta = $id_conta ";
        }

        if($id_subconta){
            $query .= " and tb1.id_subconta = $id_subconta ";
        }
        if($id_centro_custo){
            $query .= " and tb1.id_cc = $id_centro_custo ";
        }
        if($id_grupo){
            $query .= " and tb1.id_grupo = $id_grupo ";
        }
        if($dt_vencimento){
            $query .= " and tb1.ano = '".$dt_vencimento->format('Y')."'";
            $query .= " and tb1.mes = '".$dt_vencimento->format('m')."'";
        }
        if($tipo){
            $query .= " and tb1.tipo = '$tipo' ";
        }
        return $this->db->exec($query);
    }

    //funcoes novas inseridas 2017-11-30
    function getSomaLancamentoPorPeriodo($ano, $mes){
        $query = " select sum(valor) valor_total from orc_lancamento where (deleted is null or deleted = 0) and ano = $ano and mes = $mes ";
        return $this->db->exec($query);
    }

    function getLancamentosAgrupado($ano = null, $centro_custo = null, $grupo = null){
        $query = "
        select
            sum(ocl.valor) valor,
            occ.id id_cc,
            ocg.id id_grupo,
            occ.nome centro_custo,
            ocg.nome grupo,
            ocl.tipo,
            ocl.ano
        from
            orc_lancamento ocl inner join orc_centro_custo occ on
            (
                occ.id = ocl.id_cc
            ) inner join orc_grupo ocg on
            (
                ocg.id = ocl.id_grupo
            )
        where
            (ocl.deleted is null or ocl.deleted = 0)
        ";

        if($ano){
            $query .= " and ocl.ano = $ano ";
        }

        if($centro_custo){
            $query .= " and occ.nome like '%$centro_custo%' ";
        }

        if($grupo){
            $query .= " and ocg.nome like '%$grupo%' ";
        }
        $query .= " GROUP BY occ.id, ocg.id, occ.nome, ocg.nome, ocl.tipo, ocl.ano ";
        return $this->db->exec($query);
    }

 
    function getOrcamentoByParametro($param = null, $agrupar_data = true){
        $query   = null;
        $groupby = null;
        $where   = null;
        
        foreach ($param as $key => $value) {
           
            if($key == 'ano'){
                $where .= "and lc.ano = $value ";
            }

            if($key == 'mes' && is_array($value)){
                $where .= " and lc.mes BETWEEN ".$value['ini']." AND ".$value['fim'];
            }elseif($key == 'mes' && $value){
                $where .= "and lc.mes = $value ";
            }

            
            if(!isset($param['filtro'])){
                $name  = 'occ.nome centro_custo ';
                $groupby = 'occ.nome';
            }else{
                if($key == 'filtro'){
                    foreach ($value as $k1 => $v1) {
                        if($v1['nome'] == 'centro_custo'){
                            $name  = 'occ.nome centro_custo ';
                            $groupby = 'occ.nome';
                            $where .= "and lc.id_cc = $v1[id] ";
                        }elseif($v1['nome'] == 'grupo'){
                            $name  = 'occ.nome centro_custo, ocg.nome grupo ';
                            $groupby = 'occ.nome, ocg.nome';
                            $where .= "and lc.id_grupo = $v1[id] ";
                        }elseif($v1['nome'] == 'conta'){
                            $name  = 'occ.nome centro_custo, ocg.nome grupo, oco.nome conta ';
                            $groupby = 'occ.nome, ocg.nome, oco.nome';
                            $where .= "and lc.id_conta = $v1[id] ";
                        }elseif($v1['nome'] == 'subconta'){
                            $name  = 'occ.nome centro_custo, ocg.nome grupo, oco.nome conta, ocs.nome subconta ';
                            $groupby = 'occ.nome, ocg.nome, oco.nome, ocs.nome';
                            $where .= "and lc.id_subconta = $v1[id] ";
                        }
                    }
                }
            }
        }
        
        if(isset($param['view'])){
            $where .= "and lc.tipo = '".$param['view']."' ";
        }

        if($name){
            $query .= ' SELECT distinct '.$name.',';
        }else{
            $query .= ' SELECT distinct ';
        }
        
        if($param['mes'] || $agrupar_data){
            $query .= ' lc.mes, ';
        }
        
        $query .= "
                occ.alias alias_centro_custo,
                lc.ano,
                sum(lc.valor) valor
            FROM
                orc_lancamento lc left join
                orc_centro_custo occ on(lc.id_cc = occ.id) left join
                orc_grupo ocg on(lc.id_grupo = ocg.id) left join
                orc_conta oco on (lc.id_conta = oco.id) left join
                orc_conta ocs on(lc.id_subconta = ocs.id)
            where
                (lc.deleted = 0 or lc.deleted is null ) and
                (occ.deleted = 0 or occ.deleted is null ) and
                (ocg.deleted = 0 or ocg.deleted is null ) and
                (oco.deleted = 0 or oco.deleted is null ) and
                (ocs.deleted = 0 or ocs.deleted is null )
        ";
       
        $query .= $where;

        if($agrupar_data){
            $query .= "group by lc.ano, lc.mes";
            if($groupby){
                $query .= ','.$groupby;
            }
        }else{
            $query .= ' group by '.$groupby;
        }
        $query.'<br><br>';
        return $this->db->exec($query);
    }

    function getOrcamentoPorAno($ano = null){
        $query = " SELECT distinct
                occ.id id_occ,
                ocg.id id_ocg,
                oco.id id_oco,
                ocs.id id_ocs,
                occ.nome occ_nome,
                ocg.nome ocg_nome,
                oco.nome oco_nome,
                ocs.nome ocs_nome,
                lc.ano,
                lc.tipo,
                lc.valor
            FROM
                orc_lancamento lc inner join
                orc_centro_custo occ on(lc.id_cc = occ.id) inner join
                orc_grupo ocg on(lc.id_grupo = ocg.id) inner join
                orc_conta oco on (lc.id_conta = oco.id) inner join
                orc_conta ocs on(lc.id_subconta = ocs.id)
            where
                (lc.deleted = 0 or lc.deleted is null ) and
                (occ.deleted = 0 or occ.deleted is null ) and
                (ocg.deleted = 0 or ocg.deleted is null ) and
                (oco.deleted = 0 or oco.deleted is null ) and
                (ocs.deleted = 0 or ocs.deleted is null )
            ";

        if($ano){
            $query .= " and lc.ano = $ano ";
        }
        $query .= " order by lc.ano, lc.mes";
        return $this->db->exec($query);
    }

    function getOrcamentoPorCentroCustoAno($ano = null, $view){
        $query = " SELECT distinct
                occ.id id,
                occ.nome nome,
                sum(lc.valor)valor,
                lc.ano,
                lc.mes
            FROM
                orc_lancamento lc inner join
                orc_centro_custo occ on(lc.id_cc = occ.id) inner join
                orc_grupo ocg on(lc.id_grupo = ocg.id) inner join
                orc_conta oco on (lc.id_conta = oco.id) inner join
                orc_conta ocs on(lc.id_subconta = ocs.id)
            where
                (lc.deleted = 0 or lc.deleted is null ) and
                (occ.deleted = 0 or occ.deleted is null ) and
                (ocg.deleted = 0 or ocg.deleted is null ) and
                (oco.deleted = 0 or oco.deleted is null ) and
                (ocs.deleted = 0 or ocs.deleted is null )
            ";

        if($ano){
            $query .= " and lc.ano = $ano ";
        }

        if($view != 'todos'){
            $query .= " and lc.tipo = '$view' ";
        }

        $query .= "
            group by
                occ.id,
                occ.nome,
                lc.ano,
                lc.mes
            order by
                lc.ano,
                lc.mes
        ";
        return $this->db->exec($query);
    }

    function getOrcamentoPorContaAno($ano = null, $view){
        $query = " SELECT distinct
                oco.id,
                oco.nome,
                sum(lc.valor)valor,
                lc.ano,
                lc.mes
            FROM
                orc_lancamento lc inner join
                orc_centro_custo occ on(lc.id_cc = occ.id) inner join
                orc_grupo ocg on(lc.id_grupo = ocg.id) inner join
                orc_conta oco on (lc.id_conta = oco.id) inner join
                orc_conta ocs on(lc.id_subconta = ocs.id)
            where
                (lc.deleted = 0 or lc.deleted is null ) and
                (occ.deleted = 0 or occ.deleted is null ) and
                (ocg.deleted = 0 or ocg.deleted is null ) and
                (oco.deleted = 0 or oco.deleted is null ) and
                (ocs.deleted = 0 or ocs.deleted is null )
            ";

        if($ano){
            $query .= " and lc.ano = $ano ";
        }
        if($view != 'todos'){
            $query .= " and lc.tipo = '$view' ";
        }
        $query .= "
            group by
                oco.id,
                oco.nome,
                lc.tipo,
                lc.ano,
                lc.mes
            order by
                lc.ano,
                lc.mes
        ";
        return $this->db->exec($query);
    }

    function getOrcamentoPorGrupoAno($ano = null, $view){
        $query = " SELECT distinct
                grp.id,
                grp.nome,
                sum(lc.valor)valor,
                lc.ano,
                lc.mes
            FROM
                orc_lancamento lc inner join
                orc_centro_custo occ on(lc.id_cc = occ.id) inner join
                orc_grupo ocg on(lc.id_grupo = ocg.id) inner join
                orc_conta oco on (lc.id_conta = oco.id) inner join
                orc_conta ocs on(lc.id_subconta = ocs.id)
            where
                (lc.deleted = 0 or lc.deleted is null ) and
                (occ.deleted = 0 or occ.deleted is null ) and
                (ocg.deleted = 0 or ocg.deleted is null ) and
                (oco.deleted = 0 or oco.deleted is null ) and
                (ocs.deleted = 0 or ocs.deleted is null )
            ";

        if($ano){
            $query .= " and lc.ano = $ano ";
        }
        if($view != 'todos'){
            $query .= " and lc.tipo = '$view' ";
        }
        $query .= "
            group by
                grp.id,
                grp.nome,
                lc.ano,
                lc.mes
            order by
                lc.ano,
                lc.mes
        ";
        return $this->db->exec($query);
    }
}