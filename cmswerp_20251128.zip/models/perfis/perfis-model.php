<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */

class PerfisModel extends MainModel
{
    public function __construct($controller = null ){
        $this->setTable('perfis');
        parent::__construct($controller);
    }

    function getPerfis($id = null){
        $query = "select * from perfis where (deleted is null or deleted = 0)";
        if($id && is_numeric($id)){
            $query .= " and id = $id ";
        }
        $query .= " order by nome ";
        return $this->db->exec($query);
    }

    function getPerfilByUserId($id_usuario){
        $query = "
            select 
                *
            FROM 
                perfis p inner join
                sistema_usuarios ut on(p.id = ut.id_perfil)
            WHERE 
                (p.deleted is null or p.deleted = 0) AND 
                p.status = 'a'
        ";

        if($id_usuario){
            $query .= " and ut.id = $id_usuario ";
            return $this->db->exec($query);    
        }else{
            return false;
        }
    }

    function getModulos($id = null){
        $query = "select * from modulos_sistema where (deleted is null or deleted = 0)";
        if($id && is_numeric($id)){
            $query .= " and id = $id ";
        }
        $query .= " order by nome ";
        return $this->db->exec($query);
    }
}