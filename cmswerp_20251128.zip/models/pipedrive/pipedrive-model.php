<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class PipedriveModel extends MainModel{
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	public function __construct( $controller = null ){
		$this->table = 'pipedrive';
		parent::__construct($controller);
	}
	
	function getPipedrive($id_pipedrive = null){   #Forcando a não informar parametros
        $query = "
            SELECT
				*
            FROM
                pipedrive
            where (deleted is null or deleted = 0) 
		";
        if($id_pipedrive){
            $query .= " and id_pipedrive = $id_pipedrive "; 
        }
        $exec = $this->db->query($query);
        if($exec){
            // Retorna
            $return = $exec->fetchAll();
            return json_encode($return);
        }else{
            return false;
        }
    }
    
    function getPipeLineRecords($pipeline_id = null, $status = null){   #Forcando a não informar parametros
        $query = "
            SELECT
				*
            FROM
                pipedrive
            where (deleted is null or deleted = 0) 
		";
        if($pipeline_id){
            $query .= " and pipeline_id = $pipeline_id "; 
        }
        if($status){
            $query .= " and pipedrive_status = '$status' "; 
        }
        $exec = $this->db->query($query);
        if($exec){
            // Retorna
            $return = $exec->fetchAll();
            return json_encode($return);
        }else{
            return false;
        }
    }
    
    function getRel_Pipedrive($id_pipedrive = null){  #Forcando a não informar parametros 
        $query = "
            SELECT 
                rel_p.*, 
                pdri.* 
            FROM  
                pipedrive pdri inner join 
                rel_pipedrive rel_p  on pdri.id_pipedrive = rel_p.id_pipedrive 
            WHERE (pdri.deleted is null or pdri.deleted = 0)
        ";
        if($id_pipedrive){
            $query .= " and rel_p.id_pipedrive = $id_pipedrive ";
        }
        $exec = $this->db->query($query);
        if($exec){
            // Retorna
            $return = $exec->fetchAll();
            return json_encode($return);
        }else{
            return false;
        }
    }

    function relPeriodo($dt_ini, $dt_fim){ #Forcando a não informar parametros
        $query = "
            SELECT 
                * 
            from 
                pipedrive 
            where 
                (deleted = 0 or deleted is null ) 
        ";
        if($dt_ini && $dt_fim){
            $query .= " and add_time >= '$dt_ini' and add_time <= '$dt_fim' ";           
            return $this->db->exec($query);
        }else{
            return false;
        }
    }
    
    function getLastUpdate(){
      $query = "
        SELECT 
            rp.id_pipeline,
            rp.id_pipedrive,
            max(rp.data_atualizacao) data_atualizacao,
            rp.estagio_atual
        FROM
            rel_pipedrive rp
        WHERE
            (rp.deleted IS NULL or rp.deleted = 0) and
            rp.id_pipeline = 11
        group BY
            rp.id_pipeline,
            rp.id_pipedrive,
            rp.estagio_atual
        ORDER BY
            rp.id_pipedrive,
            rp.data_atualizacao desc
      ";
      return $this->db->exec($query);
    }

    function getOppsByStage($stage_id, $open = true, $active = true){
        $query = "
            SELECT 
                *
            FROM 
                pipedrive pd
            WHERE 
                (pd.deleted IS NULL OR pd.deleted = 0)
        ";

        if($open){
            $query .= " and pipedrive_status = 'open' ";
        }
        
        if($active){
            $query .= " and active = 1 ";
        }

        if($stage_id){
            $query .= " and stage_id = $stage_id ";
            return $this->db->exec($query);
        }else {
            return false;
        }
    }
    
    function getOppsStage69(){
        $query = "SELECT 
            p.pipeline_id, 
            p.id_pipedrive, 
            p.title, 
            p.stage_id, 
            p.prop_owner_name, 
            p.name_organiz, 
            rp.id_pipeline, 
            rp.estagio_atual,
            MAX(rp.data_atualizacao) data_atualizacao 
        FROM pipedrive p
        INNER JOIN rel_pipedrive rp ON(rp.id_pipedrive = p.id_pipedrive)
        WHERE 
            (p.deleted IS NULL OR p.deleted = 0) AND 
            p.active = 1 AND 
            p.pipeline_id = 11 AND 
            p.pipedrive_status = 'open' AND
            rp.estagio_atual = 69
        GROUP BY
            p.pipeline_id, 
            p.id_pipedrive, 
            p.title, 
            p.stage_id, 
            p.prop_owner_name, 
            p.name_organiz, 
            rp.id_pipeline, 
            rp.estagio_atual
        ORDER BY 
            p.id_pipedrive, rp.data_atualizacao	
        ";
        return $this->db->exec($query);
    }

    function getPipeDelet($pipeline_id){   #Forcando a não informar parametros
        $query = "
            SELECT
				*
            FROM
                pipedrive
            where (deleted is null or deleted = 0) 
		";
        if($pipeline_id){
            $query .= " and pipeline_id = $pipeline_id "; 
        }
        $exec = $this->db->query($query);
        if($exec){
            // Retorna
            $return = $exec->fetchAll();
            return json_encode($return);
        }else{
            return false;
        }
    }

}
