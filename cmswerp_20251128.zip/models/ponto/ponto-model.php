<?php
class PontoModel extends MainModel
{
    public $table = 'rh_registro_ponto';
    public function __construct($controller = null)
    {
        $this->setTable('rh_registro_ponto');
        parent::__construct($controller);
    }

    public function getFeriados($validade_ini, $validade_fim = null)
    {
        if (!$validade_ini) {
            return false;
        }

        $query = "
                select 
                    *
                from 
                    rh_lancamentos t1
                where
                    ( t1.deleted is null or t1.deleted = 0) and
                    t1.status = 'a' AND 
                    tipo in ('F01', 'F03')
            ";

        if ($validade_ini && $validade_fim) {
            $query .= "OR (t1.valido_ate >= '$validade_ini' and t1.valido_ate <= '$validade_fim')";
        }
        $query .=  " order by dia, mes";
        return $this->db->exec($query);
    }

    public function getLancamentos($id_usuario)
    {
        $query = "
                select 
                    t1.*,
                    ut.nome nome_usuario
                from 
                    rh_lancamentos t1 left join 
                    sistema_usuarios ut on( t1.id_usuario = ut.id)
                where
                    ( t1.deleted is null or t1.deleted = 0) and 
                    t1.status = 'a'
            ";

        if ($id_usuario) {
            $query .= " and  (t1.id_usuario = $id_usuario or tipo = 'F01' )";
        }

        if ($validade) {
            $query .= " and t1.valido_ate <= '$validade'";
        }

        $query .=  " order by dia, mes";
        return $this->db->exec($query);
    }

    public function getUsuarios($id_usuario = null, $id_boss = null, $cpf = null, $departamento = false)
    {
        $query = "select * from sistema_usuarios  where status = 'ativo'";

        if ($id_usuario) {
            $query .= " and id = '$id_usuario'";
        }
        if ($id_boss) {
            $query .= " and (boss = '$id_boss' or id = '$id_boss')";
        }
        if ($cpf) {
            $query .= " and cpf = '$cpf'";
        }
        if ($departamento === true) {
            $query .= " group by departamento";
        }
        $query .= " order by nome asc";
        return $this->db->exec($query);
    }

    public function getSaldoAnterior($user_id)
    {
        $query = "
                select 
                    *
                from 
                    rh_lancamentos t1
                where
                    ( t1.deleted is null or t1.deleted = 0) and 
                    t1.status = 'a' and
                    t1.tipo = 'S01'
            ";
        if ($user_id) {
            $query .= "and id_usuario = $user_id ";
        }
        $query .=  " order by dia, mes";
        return $this->db->exec($query);
    }

    function getPonto($dt_ini, $dt_fim, $id_usuario, $tipo_marcacao = null)
    {
        $query = "
                select
                    t1.id,
                    t1.id id_registro,
                    t1.id_usuario,
                    t1.tipo_marcacao,
                    t1.data_marcacao,
                    t1.hora_marcacao,
                    DATE_FORMAT(t1.hora_marcacao, '%H:%i:%s') hora_marcacao,
                    t1.ocorrencia,
                    t1.status,
                    t1.alterado_em,
                    t1.alterado_por,
                    t1.deleted
                from
                    $this->table t1 INNER JOIN
                    sistema_usuarios t2 on(t1.id_usuario = t2.id)
                where
                    (t1.deleted is null or t1.deleted = 0)
            ";

        if ($dt_ini) {
            $query .= " and t1.data_marcacao >= '$dt_ini' ";
        }

        if ($dt_fim) {
            $query .= " and t1.data_marcacao <= '$dt_fim' ";
        }

        if ($id_usuario) {
            $query .= " and t1.id_usuario = '$id_usuario'";
        }

        if ($tipo_marcacao) {
            if (is_array($tipo_marcacao)) {
                $query .= " and t1.tipo_marcacao in ('" . implode("','", $tipo_marcacao) . "')";
            } else {
                $query .= " and t1.tipo_marcacao = '$tipo_marcacao'";
            }
        }
        $query .= " order by t1.data_marcacao asc, t1.hora_marcacao asc, t1.tipo_marcacao asc";
        // echo $query.'<br><br><br>';
        return $this->db->exec($query);
    }

    function getPontoAcimaDe($dt_ini, $id_usuario, $tipo_marcacao = null)
    {
        $query = "
                select
                    t1.*
                from
                    $this->table t1 INNER JOIN
                    sistema_usuarios t2 on(t1.id_usuario = t2.id)
                where
                    (t1.deleted is null or t1.deleted = 0)
            ";

        if ($dt_ini) {
            $query .= " and t1.data_marcacao > '$dt_ini' ";
        }

        if ($id_usuario) {
            $query .= " and t1.id_usuario = '$id_usuario'";
        }

        if ($tipo_marcacao) {
            if (is_array($tipo_marcacao)) {
                $query .= " and t1.tipo_marcacao in ('" . implode("','", $tipo_marcacao) . "')";
            } else {
                $query .= " and t1.tipo_marcacao = '$tipo_marcacao'";
            }
        }
        $query .= " order by t1.data_marcacao asc, t1.hora_marcacao asc, t1.tipo_marcacao asc";
        return $this->db->exec($query);
    }

    public function getOcorrenciaByUser($id_usuario = null, $dt_ini = null, $dt_fim = null)
    {
        if (is_object($dt_ini)) {
            $dt_ini = $dt_ini->format('Y-m-d');
        }

        if (is_object($dt_fim)) {
            $dt_fim = $dt_fim->format('Y-m-d');
        }

        $query = " 
            select 
                jo.id,
                jo.id_registro,
                jo.id_usuario,
                jo.permissivo,
                jo.fonte,
                jo.tipo,
                jo.classe,
                jo.texto,
                jo.data,
                jo.data_lancamento,
                DATE_FORMAT(jo.hora, '%H:%i') hora,
                DATE_FORMAT(jo.periodo_ini, '%Y-%m-%d %H:%i') periodo_ini,
                DATE_FORMAT(jo.periodo_fim, '%Y-%m-%d %H:%i') periodo_fim,
                jo.minutos,
                jo.status,
                jo.id_autorizado,
                jo.alterado_por,
                jo.alterado_em,
                jo.deleted,
                rrp.id id_ponto,
                ut.nome as nome_usuario,
                ut.cpf,
                ut.email,
                rrp.id id_ponto,
                ut.nome as nome_usuario,
                ut.cpf,
                ut.email
            from
                rh_jornada_ocorrencia AS jo LEFT JOIN
                rh_registro_ponto AS rrp ON(jo.id_registro = rrp.id) INNER JOIN
                sistema_usuarios AS ut ON jo.id_usuario = ut.id      
            where 
                (jo.deleted is null or jo.deleted = 0) and 
                ( 
                    (jo.periodo_ini >= '$dt_ini' && jo.periodo_fim <= '$dt_fim') OR                
                    (jo.periodo_ini <= '$dt_ini' && jo.periodo_fim >= '$dt_fim') OR               
                    (jo.periodo_fim >= '$dt_ini' && jo.periodo_fim <= '$dt_fim') OR 
                    (jo.periodo_ini >= '$dt_ini' && jo.periodo_ini <= '$dt_fim') OR
                    (jo.periodo_ini = '$dt_ini'  OR jo.periodo_fim  = '$dt_fim') OR
                    (jo.data = '$dt_ini' OR jo.data = '$dt_fim')	
                )
        ";

        if ($id_usuario) {
            $query .= " and jo.id_usuario IN('$id_usuario')";
        }
        $query .= " order by jo.data asc, jo.id asc";
        return $this->db->exec($query);
    }

    public function getOcorrenciaByBoss($id_boss, $dt_ini = null, $dt_fim = null)
    {
        if (is_object($dt_ini)) {
            $dt_ini = $dt_ini->format('Y-m-d');
        }

        if (is_object($dt_fim)) {
            $dt_fim = $dt_fim->format('Y-m-d');
        }

        $query = " select 
                    jo.id,
                    jo.id_registro,
                    jo.id_usuario,
                    jo.permissivo,
                    jo.fonte,
                    jo.tipo,
                    jo.classe,
                    jo.texto,
                    jo.data,
                    jo.data_lancamento,
                    DATE_FORMAT(jo.hora, '%H:%i') hora,
                    DATE_FORMAT(jo.periodo_ini, '%Y-%m-%d %H:%i') periodo_ini,
                    DATE_FORMAT(jo.periodo_fim, '%Y-%m-%d %H:%i') periodo_fim,
                    jo.minutos,
                    jo.status,
                    jo.id_autorizado,
                    jo.alterado_por,
                    jo.alterado_em,
                    jo.deleted,
                    rrp.id id_ponto,
                    ut.nome as nome_usuario,
                    ut.cpf,
                    ut.email,
                    rrp.id id_ponto,
                    ut.nome as nome_usuario,
                    ut.cpf,
                    ut.email
                from
                    rh_jornada_ocorrencia AS jo LEFT JOIN
                    rh_registro_ponto AS rrp ON(jo.id_registro = rrp.id) INNER JOIN
                    sistema_usuarios AS ut ON jo.id_usuario = ut.id      
                where 
                    (jo.deleted is null or jo.deleted = 0) and 
                    ( 
                        (jo.periodo_ini >= '$dt_ini' && jo.periodo_fim <= '$dt_fim') OR                
                        (jo.periodo_ini <= '$dt_ini' && jo.periodo_fim >= '$dt_fim') OR               
                        (jo.periodo_fim >= '$dt_ini' && jo.periodo_fim <= '$dt_fim') OR 
                        (jo.periodo_ini >= '$dt_ini' && jo.periodo_ini <= '$dt_fim') OR
                        (jo.periodo_ini = '$dt_ini'  OR jo.periodo_fim  = '$dt_fim') OR
                        (jo.data = '$dt_ini' OR jo.data = '$dt_fim')	
                    )
            ";

        if ($id_boss) {
            $query .= " and ( ut.boss = $id_boss or ut.id = $id_boss ) ";
        }
        $query .= " order by jo.data asc, jo.id asc";
        return $this->db->exec($query);
    }

    function getOcorrenciasPontoAcimaDe($dt_ini, $id_usuario, $tipo_marcacao = null)
    {
        $query = "
                select
                    t1.*
                from
                    $this->table t1 LEFT JOIN
                    rh_jornada_ocorrencia AS rjo ON(rjo.id_registro = t1.id) INNER JOIN
                    sistema_usuarios t2 on(t1.id_usuario = t2.id)
                where
                    (t1.deleted is null or t1.deleted = 0) and
                    (rjo.deleted IS NULL OR rjo.deleted = 0)
            ";

        if ($dt_ini) {
            $query .= " and t1.data_marcacao > '$dt_ini' ";
        }

        if ($tipo_marcacao) {
            if (is_array($tipo_marcacao)) {
                $query .= " and t1.tipo_marcacao in ('" . implode("','", $tipo_marcacao) . "')";
            } else {
                $query .= " and t1.tipo_marcacao = '$tipo_marcacao'";
            }
        }

        if ($id_usuario) {
            $query .= " and t1.id_usuario = '$id_usuario'";
        }

        if ($tipo_marcacao) {
            if (is_array($tipo_marcacao)) {
                $query .= " and t1.tipo_marcacao in ('" . implode("','", $tipo_marcacao) . "')";
            } else {
                $query .= " and t1.tipo_marcacao = '$tipo_marcacao'";
            }
        }

        $query .= " order by t1.data_marcacao asc, t1.hora_marcacao asc, t1.tipo_marcacao asc";
        return $this->db->exec($query);
    }

    public function getJornadaByUsuarioArray($id_usuario)
    {
        $query = "
                select 
                    jt.nome AS nome_jornada, 
                    jt.id AS id_jornada, 
                    ju.id id_rel, 
                    ju.data_inicio, 
                    ju.data_fim, 
                    ut.nome, 
                    ut.email, 
                    jd.dia_semana,
                    jd.entrada, 
                    jd.saida,
                    jd.entrada_min,
                    jd.entrada_max,
                    jd.saida_min,
                    jd.saida_max,
                    jd.saida_almoco,
                    jd.retorno_almoco,
                    jd.extra_maximo,
                    jd.extra_minimo,
                    jd.tempo_almoco_min,
                    jd.tempo_almoco_max,
                    jt.aderir_add_noturno, 
                    jt.desconto, 
                    jt.aderir_feriado, 
                    jt.`status`, 
                    ut.departamento, 
                    ut.id id_usuario
                from 
                    rh_jornada_trabalho jt INNER JOIN
                    rh_jornada_dias jd on(jt.id = jd.id_jornada) inner join 
                    rh_jornada_usuario ju ON ju.id_jornada = jt.id INNER JOIN 
                    sistema_usuarios ut ON ju.id_usuario = ut.id
                where
                    ( ju.deleted is null or ju.deleted = 0) and 
                    ju.status = 'ativo' 
            ";

        if ($id_usuario) {
            $query .= " and ju.id_usuario = $id_usuario";
        } else {
            return false;
        }
        $query .=  " order by ju.data_inicio asc";
        return $this->db->exec($query, null, 'array');
    }

    public function getPrimeiraJornadaByUsuario($id_usuario)
    {
        if (!$id_usuario || !is_numeric($id_usuario)) {
            return false;
        }

        $query = "
                SELECT 
                    rju.*,
                    ut.nome nome_usuario
                FROM 
                    rh_jornada_usuario rju inner join
                    sistema_usuarios ut on(ut.id = rju.id_usuario)
                WHERE 
                    ( rju.deleted IS NULL OR rju.deleted = 0) AND
                    rju.id_usuario = $id_usuario
                ORDER BY
                    data_inicio ASC LIMIT 1;
            ";
        return $this->db->exec($query);
    }

    function getJornadaUsuarioById($usuario)
    {
        $query = "
                SELECT 
                    jo.*,
                    ut.nome,
                    ut.departamento
                FROM
                    rh_jornada_usuario jo     
                INNER JOIN
                    sistema_usuarios ut    
                ON
                    (jo.id_usuario = ut.id)
                WHERE
                    (jo.deleted is null OR jo.deleted = 0) 
                AND 
                    jo.status = 'ativo'
                AND
                    ut.status = 'ativo'
            ";

        if ($usuario) {
            $query .= " and ut.id = '$usuario'";
        }
        $query .=  " group by ut.id order by ut.nome asc";
        return $this->db->exec($query);
    }

    function getJornadaUsuarioByDepartamento($departamento)
    {
        $query = "
                SELECT 
                    jo.*,
                    ut.nome,
                    ut.departamento,
                    ut.mostrar_relatorio
                FROM
                    rh_jornada_usuario jo     
                INNER JOIN
                    sistema_usuarios ut    
                ON
                    (jo.id_usuario = ut.id)
                WHERE
                    (jo.deleted is null OR jo.deleted = 0) 
                AND 
                    jo.status = 'ativo'
                AND
                    ut.status = 'ativo'
                AND 
                    ut.mostrar_relatorio = 1
            ";

        if ($departamento) {
            $query .= " and ut.departamento = '$departamento'";
        }
        $query .=  " group by ut.id order by ut.nome asc";
        return $this->db->exec($query);
    }

    public function getOcorrenciaById($id)
    {
        $query = " 
                select 
                    jo.*,
                    ut.nome as nome_usuario,
                    ut.cpf,
                    ut.email
                from
                    rh_jornada_ocorrencia as jo
                inner join 
                    sistema_usuarios as ut 
                on 
                    jo.id_usuario = ut.id         
                where 
                    (jo.deleted is null or jo.deleted = 0)
            ";

        if ($id) {
            $query .= " and jo.id = $id ";
        }
        return $this->db->exec($query);
    }

    public function getOcorrenciaByIdRegsitro($id_registro)
    {
        $query = " select 
                    jo.*,
                    ut.nome as nome_usuario,
                    ut.cpf,
                    ut.email
                from
                    rh_jornada_ocorrencia as jo
                inner join 
                    sistema_usuarios as ut 
                on 
                    jo.id_usuario = ut.id         
                where 
                    (jo.deleted is null or jo.deleted = 0)
            ";

        if ($id_registro) {
            $query .= " and jo.id_registro = '$id_registro'";
        }
        $query .= " order by jo.data asc, jo.id asc";
        return $this->db->exec($query);
    }

    public function getOcorrenciaIntervalo($data_ini, $data_fim, $classe = null, $id_usuario = null, $status = null, $fonte = null, $tipo = null)
    {
        $query = " select 
                    jo.*,
                    ut.nome as nome_usuario,
                    ut.cpf,
                    ut.email
                from
                    rh_jornada_ocorrencia as jo
                inner join 
                    sistema_usuarios as ut 
                on 
                    jo.id_usuario = ut.id         
                where 
                    (jo.deleted is null or jo.deleted = 0)
                and 
                ( 
                    (jo.periodo_ini >= '$data_ini' && jo.periodo_fim <= '$data_fim') OR                
                    (jo.periodo_ini <= '$data_ini' && jo.periodo_fim >= '$data_fim') OR               
                    (jo.periodo_fim >= '$data_ini' && jo.periodo_fim <= '$data_fim') OR 
                    (jo.periodo_ini >= '$data_ini' && jo.periodo_ini <= '$data_fim') OR
                    (jo.periodo_ini = '$data_ini'  OR jo.periodo_fim  = '$data_fim') OR
                    (jo.data = '$data_ini' OR jo.data = '$data_fim')	
                )
            ";

        if ($classe) {
            $query .= " and jo.classe = '$classe'";
        }

        if ($id_usuario) {
            $query .= " and jo.id_usuario IN('$id_usuario')";
        }

        if ($status) {
            $query .= " and jo.status = '$status'";
        }

        if ($fonte) {
            $query .= " and jo.fonte = '$fonte'";
        }

        if ($tipo) {
            $query .= " and jo.tipo = '$tipo'";
        }
        $query .= " order by jo.data asc, jo.id asc";
        return $this->db->exec($query);
    }

    public function getOcorrenciaIntervaloByUser($data_ini, $data_fim, $id_usuario = null, $classe = null)
    {
        $query = " select 
                    jo.*,
                    ut.nome as nome_usuario,
                    ut.cpf,
                    ut.email
                from
                    rh_jornada_ocorrencia as jo
                inner join 
                    sistema_usuarios as ut 
                on 
                    jo.id_usuario = ut.id         
                where 
                    (jo.deleted is null or jo.deleted = 0)
                and 
                ( 
                    (jo.periodo_ini >= '$data_ini' && jo.periodo_fim <= '$data_fim') OR                
                    (jo.periodo_ini <= '$data_ini' && jo.periodo_fim >= '$data_fim') OR               
                    (jo.periodo_fim >= '$data_ini' && jo.periodo_fim <= '$data_fim') OR 
                    (jo.periodo_ini >= '$data_ini' && jo.periodo_ini <= '$data_fim') OR
                    (jo.periodo_ini = '$data_ini'  OR jo.periodo_fim  = '$data_fim') OR
                    (jo.data = '$data_ini' OR jo.data = '$data_fim')	
                )
            ";

        if ($classe) {
            $query .= " and jo.classe = '$classe'";
        }

        if ($id_usuario) {
            $query .= " and jo.id_usuario IN($id_usuario)";
        }
        $query .= " order by jo.data asc, jo.id asc";
        return $this->db->exec($query);
    }

    function getOcorrenciaToken($id_ocorrencia = null, $id_registro = null, $id_token = null, $status = null)
    {
        $query =
            "select 
                jo.id, 
                jo.id_registro, 
                jo.id_usuario, 
                jo.permissivo, 
                jo.fonte, 
                jo.tipo, 
                jo.classe, 
                jo.texto,
                jo.data, 
                jo.periodo_ini, 
                jo.periodo_fim, 
                jo.status, 
                jo.id_autorizado, 
                jo.hora,
                t.id as id_token, 
                t.token,
                t.id_registro as id_ocorrencia, 
                t.id_responsavel, 
                t.status as status_token, 
                t.validade 
            from
                rh_jornada_ocorrencia jo
            inner join 
                rh_token t
            on
                jo.id = t.id_registro
            where
                (jo.deleted is null or jo.deleted = 0)
            ";
        if ($id_ocorrencia) {
            $query .= " and jo.id = '$id_ocorrencia'";
        }
        if ($id_registro) {
            $query .= " and jo.id_registro = '$id_registro'";
        }
        if ($id_token) {
            $query .= " and t.id = '$id_token'";
        }
        if ($status) {
            $query .= " and jo.status = '$status' and t.status = '$status'";
        }
        return $this->db->exec($query);
    }

    public function getRhJornadaUsuario($id_usuario = null, $id_jornada = null, $status = null, $id_jornada_usuario = null, $limit = null)
    {
        $query = "
                select 
                    ju.id, 
                    ju.id_usuario, 
                    ju.id_jornada, 
                    ju.data_inicio,
                    data_fim, 
                    ju.status, 
                    jt.nome as nome_jornada, 
                    jt.desconto, 
                    ut.nome, 
                    ut.departamento
                from 
                    rh_jornada_usuario ju
                inner join 
                    rh_jornada_trabalho jt
                on 
                    ju.id_jornada = jt.id  
                inner join 
                    sistema_usuarios ut
                on 
                    ju.id_usuario = ut.id        
                where 
                    (ju.deleted is null or ju.deleted = 0)
            ";

        if ($id_usuario) {
            $query .= " and ju.id_usuario = '$id_usuario'";
        }

        if ($id_jornada) {
            $query .= " and ju.id_jornada = '$id_jornada'";
        }

        if ($status) {
            $query .= " and ju.status = '$status'";
        }

        if ($id_jornada_usuario) {
            $query .= " and ju.id = '$id_jornada_usuario'";
        }

        if ($limit == true) {
            $query .= " order by ju.data_inicio desc LIMIT 1";
        } else {
            $query .= " order by ju.data_inicio asc";
        }
        return $this->db->exec($query);
    }

    function gedDocumentoById($id)
    {
        $query =
            "select 
                    * 
                from 
                    ged_documento
                where
                    (deleted is null or deleted = 0)";

        if ($id) {
            $query .= " and id = '$id'";
        }
        return $this->db->exec($query);
    }

    function gedDocumento($id_origem, $tipo = null, $id_ged = null)
    {
        $query =
            "select 
                    * 
                from 
                    ged_documento
                where
                    (deleted is null or deleted = 0)";

        if ($id_origem) {
            $query .= " and id_origem = '$id_origem'";
        }

        if ($tipo) {
            $query .= " and tipo = '$tipo'";
        }

        if ($id_ged) {
            $query .= " and id = '$id_ged'";
        }
        $exe = $this->db->exec($query);
        if ($exe) {
            return $exe;
        } else {
            return false;
        }
    }

    public function getRegistro($tipo_marcacao = null, $data = null, $ocorrencia = null, $id_usuario = null, $deleted = false, $status = null, $id_registro = null)
    {

        if ($deleted == false) {
            $query = "select * from rh_registro_ponto where (deleted is null or deleted = 0) ";
        } else {
            $query = "select * from rh_registro_ponto where (deleted is null or deleted = 0 or deleted = 1) ";
        }

        if ($tipo_marcacao) {
            $query .= " and tipo_marcacao = '$tipo_marcacao'";
        }

        if ($data) {
            $query .= " and data_marcacao = '$data'";
        }

        if ($ocorrencia) {
            if ($ocorrencia == 'token') {
                $query .= " and (ocorrencia = 'Registro fora da jornada.' OR ocorrencia = 'Registro no feriado.' OR ocorrencia = 'Registro fora do horario nucleo.' OR ocorrencia = 'Registro extra.' )";
            } else {
                $query .= " and ocorrencia = '$ocorrencia'";
            }
        }

        if ($id_usuario) {
            $query .= " and id_usuario = '$id_usuario'";
        }

        if ($status) {
            $query .= " and status = '$status'";
        }

        if ($id_registro) {
            $query .= " and id = '$id_registro'";
        }
        $query .= " order by data_marcacao, hora_marcacao asc, tipo_marcacao asc";
        $exe = $this->db->exec($query);
        if ($exe) {
            return $exe;
        } else {
            return false;
        }
    }

    function getOcorrenciaRegistroToken($id_registro, $id_usuario, $data, $tipo, $fonte, $status)
    {
        $query =
            "select 
                jo.id, 
                jo.id_registro, 
                jo.id_usuario, 
                jo.permissivo, 
                jo.fonte, 
                jo.tipo, 
                jo.classe, 
                jo.texto,
                jo.data, 
                jo.periodo_ini, 
                jo.periodo_fim, 
                jo.status, 
                jo.id_autorizado, 
                rp.hora_marcacao, 
                rp.status as registro_status,
                t.token,
                t.validade,
                t.id_registro,
                t.id as id_token,
                t.status as status_token
            from
                rh_jornada_ocorrencia jo
            inner join 
                rh_registro_ponto rp
            on
                jo.id_registro = rp.id
            inner join 
                rh_token t
            on
                jo.id = t.id_registro
            where
                (jo.deleted is null or jo.deleted = 0) 
            ";

        if ($id_registro) {
            $query .= " and jo.id_registro = '$id_registro'";
        }
        if ($id_usuario) {
            $query .= " and jo.id_usuario = '$id_usuario'";
        }
        if ($data) {
            $query .= " and jo.data = '$data'";
        }
        if ($tipo) {
            $query .= " and jo.tipo = '$tipo'";
        }
        if ($fonte) {
            $query .= " and jo.fonte = '$fonte'";
        }
        if ($status) {
            $query .= " and jo.status = '$status' and t.status = '$status'";
        }
        $query .= " order by jo.id asc LIMIT 1";
        return $this->db->exec($query);
    }

    public function getJornadaDias($id_jornada = null, $dia_semana = null)
    {
        $query = " 
                select 
                    jd.*,
                    jt.nome,
                    jt.`status` status_jornada,
                    jt.aderir_feriado,
                    jt.aderir_jornada,
                    jt.aderir_add_noturno
                from 
                    rh_jornada_dias jd inner join 
                    rh_jornada_trabalho jt on jd.id_jornada = jt.id        
                where 
                    (jd.deleted is null or jd.deleted = 0) and
	                (jt.deleted is null or jt.deleted = 0)
            ";

        if ($id_jornada) {
            $query .= " and jd.id_jornada = '$id_jornada'";
        }

        if ($dia_semana) {
            $query .= " and jd.dia_semana = '$dia_semana'";
        }
        $query .= " order by jd.id_jornada, jd.dia_semana asc";
        return $this->db->exec($query);
    }

    function getLastJornada($id_user, $id_jornanda_dias = null)
    {
        if ($id_user && is_numeric($id_user)) {
            $query = "
                    select 
                        tb1.*,
                        tb3.entrada,
                        tb3.saida, 
                        tb3.nucleo_ini,
                        tb3.nucleo_fim,
                        tb3.dia_semana,
                        tb3.almoco_min,
                        tb3.almoco_max,
                        tb3.entrada_min,
                        tb3.saida_max, 
                        tb4.id id_usuario,
                        tb4.nome nome_usuario,
                        tb5.id id_chefe,
                        tb5.nome nome_chefe,
                        tb5.email email_chefe,
                        tb5.id_slack id_slack_chefe
                    from 
                        rh_jornada_trabalho tb1 INNER join
                        rh_jornada_usuario tb2 ON(tb1.id = tb2.id_jornada) INNER join
                        rh_jornada_dias tb3 ON(tb1.id = tb3.id_jornada) inner join
                        sistema_usuarios tb4 on(tb4.id = tb2.id_usuario) inner join
                        sistema_usuarios tb5 on(tb5.id = tb4.boss)
                    where
                        (tb1.deleted is null or tb1.deleted = 0)
                ";
            $query .= " and tb2.id_usuario = $id_user ";

            if ($id_jornanda_dias) {
                $query .= " and tb3.id_jornada = '$id_jornanda_dias'";
            }
            $query .= " order by data_inicio desc, tb3.dia_semana";
            return $this->db->exec($query);
        } else {
            return false;
        }
    }

    public function getJornada($id_jornada = null)
    {
        $query = "
                select 
                    jt.*
                from 
                    rh_jornada_trabalho jt           
                where 
                    (jt.deleted is null or jt.deleted = 0)            
            ";

        if ($id_jornada) {
            $query .= " and jt.id = '$id_jornada'";
        }
        $query .= " order by jt.id asc";
        return $this->db->exec($query);
    }

    public function getOcorrencia($id_registro = null, $classe = null, $data = null, $tipo = null, $status = null, $id_usuario = null, $id_ocorrencia = null, $fonte = null)
    {
        $query = "
            SELECT 
                * 
            FROM 
                rh_jornada_ocorrencia 
            WHERE 
                (deleted is null or deleted = 0)";

        if ($id_registro) {
            $query .= " and id_registro = '$id_registro'";
        }

        if ($classe) {
            if ($classe == "ocorrencia_tipo") {
                $query .= " and (classe = 'D1' OR classe = 'D2' OR classe = 'A5' )";
            } else {
                $query .= " and classe = '$classe'";
            }
        }

        if ($data) {
            $query .= " and data = '$data'";
        }

        if ($tipo) {
            $query .= " and tipo = '$tipo'";
        }

        if ($status) {
            $query .= " and status = '$status'";
        }

        if ($id_usuario) {
            $query .= " and id_usuario = '$id_usuario'";
        }

        if ($id_ocorrencia) {
            $query .= " and id = '$id_ocorrencia'";
        }

        if ($fonte) {
            $query .= " and fonte = '$fonte'";
        }
        $query .= " order by id";
        $exe = $this->db->exec($query);
        if ($exe) {
            return $exe;
        } else {
            return false;
        }
    }

    function gedDocumentoAnexo($id_origem = null, $doc_origem = null, $id_owner = null, $data_ini = null, $data_fim = null, $id_ged = null)
    {
        $query =
            "select 
                gd.id as id_ged_documento, gd.nome_documento, gd.data_documento, gd.doc_origem, gd.id_origem, 
                gd.produto, gd.tipo, gd.subtipo, gd.owner, gd.data_criacao as data_criacao_documento,
                ga.id as id_ged_anexo, ga.id_documento, ga.nome_amigavel, ga.path_root, ga.path_objeto, 
                ga.nome_hash, ga.hash_arquivo, ga.data_criacao as data_criacao_anexo
            from 
                ged_documento as gd
            INNER JOIN 
                ged_anexo AS ga
            ON 
                (gd.id = ga.id_documento )
            where 
                (gd.deleted is null or gd.deleted = 0)";


        if ($id_origem) {
            $query .= " and gd.id_origem = '$id_origem'";
        }

        if ($doc_origem) {
            $query .= " and gd.doc_origem = '$doc_origem'";
        }

        if ($id_owner) {
            $query .= " and gd.owner = '$id_owner'";
        }

        if ($data_ini) {
            $query .= " and gd.data_documento >= '$data_ini'";
        }

        if ($data_fim) {
            $query .= " and gd.data_documento <= '$data_fim'";
        }

        if ($id_ged) {
            $query .= " and ga.id = '$id_ged'";
        }
        $query .= " order by gd.id desc";
        $exe = $this->db->exec($query);
        if ($exe) {
            return $exe;
        } else {
            return false;
        }
    }

    public function getUsuarioOcorrencia($usuario = null, $data_ini = null, $data_fim = null, $status = null, $data = null, $tipo = null, $fonte = null, $id_ocorrencia = null)
    {
        if ($tipo == "validacao_token") {
            $query =
                "select 
                        ut.nome as nome_usuario, ut.cpf, jo.tipo, jo.classe, jo.id, jo.data, jo.periodo_ini, jo.periodo_fim, jo.texto, 
                        jo.status, jo.fonte, rp.hora_marcacao, jo.id_usuario, jo.id_registro, jo.data_lancamento
                    from 
                        rh_jornada_ocorrencia as jo
                    inner join 
                        sistema_usuarios as ut 
                    on 
                        jo.id_usuario = ut.id  
                    inner join 
                        rh_registro_ponto as rp 
                    on 
                        jo.id_registro = rp.id 
                    where 
                        (jo.deleted is null or jo.deleted = 0)";
        } else {
            if ($usuario == null && $id_ocorrencia == null) {
                $query = "
                    select 
                        *
                    from 
                        rh_jornada_ocorrencia as jo              
                    where 
                        (deleted is null or deleted = 0)";
            } else {
                $query =
                    "select 
                        ut.nome as nome_usuario, 
                        ut.cpf, 
                        jo.tipo, 
                        jo.classe, 
                        jo.id, 
                        jo.data, 
                        jo.periodo_ini, 
                        jo.periodo_fim, 
                        jo.texto, 
                        jo.status, 
                        jo.fonte, 
                        jo.id_usuario, 
                        jo.id_registro,
                        jo.hora,
                        jo.data_lancamento
                    from 
                        rh_jornada_ocorrencia as jo
                    inner join 
                        sistema_usuarios as ut 
                    on 
                        jo.id_usuario = ut.id             
                    where 
                        (jo.deleted is null or jo.deleted = 0)";
            }
        }

        if ($usuario) {
            if (is_array($usuario)) {
                foreach ($usuario as $key => $value) {
                    $array[] = $value;
                    $string_id = implode(",", $array);
                }
                $query .= " and jo.id_usuario in($string_id)";
            } else {
                $query .= " and jo.id_usuario = '$usuario'";
            }
        }

        if ($data_ini) {
            $query .= " and jo.data >= '$data_ini'";
        }

        if ($data_fim) {
            $query .= " and jo.data <= '$data_fim'";
        }

        if ($status) {
            $query .= " and jo.status = '$status'";
        }

        if ($data) {
            $query .= " and jo.data = '$data'";
        }

        if ($tipo) {
            $query .= " and jo.tipo = '$tipo'";
        }

        if ($fonte) {
            $query .= " and jo.fonte = '$fonte'";
        }

        if ($id_ocorrencia) {
            $query .= " and jo.id = '$id_ocorrencia'";
        }

        $query .= " order by jo.data, jo.id desc";
        $exe = $this->db->exec($query);
        if ($exe) {
            return $exe;
        } else {
            return false;
        }
    }

    public function getUsuarioJornada($id_jornada = null, $id_usuario = null)
    {
        $query = "
                SELECT
                    jt.id,
                    jt.nome as nome_jornada, 
                    jt.id as id_jornada, 
                    ju.data_inicio, 
                    ju.id_jornada,
                    ju.id_usuario,
                    jt.nome, 
                    ut.email, 
                    jt.entrada, 
                    jt.saida,            
                    jt.dia_semana,
                    jt.horas_maxima, 
                    jt.horas_almoco, 
                    jt.desconto, 
                    jt.aderir_feriado, 
                    jt.`status`, 
                    ut.departamento            
                FROM
                    rh_jornada_trabalho jt INNER JOIN 
                    rh_jornada_usuario ju ON ju.id_jornada = jt.id INNER JOIN 
                    sistema_usuarios ut ON ju.id_usuario = ut.id
                WHERE
                    (ju.deleted is null or ju.deleted = 0) 
                AND
                    ju.status = 'ativo'
            ";

        if ($id_jornada) {
            $query .= " and ju.id_jornada = '$id_jornada'";
        }

        if ($id_usuario) {
            $query .= " and ju.id_usuario = '$id_usuario'";
        }
        $query .= " order by nome asc";
        return $this->db->exec($query);
    }

    function getToken($id_token = null, $id_registro = null, $status = null)
    {
        $query =
            "select
                rt.id,
                rt.token,
                rt.id_registro,
                rt.id_usuario,
                rt.id_responsavel,
                rt.validade,
                rt.status,
                jo.data,
                jo.texto
            from
                rh_token rt
            inner join
                rh_jornada_ocorrencia jo
            on
                rt.id_registro = jo.id
            where
                (rt.deleted is null or rt.deleted = 0)";
        if ($id_token) {
            $query .= " and rt.id = '$id_token'";
        }
        if ($id_registro) {
            $query .= " and rt.id_registro = '$id_registro'";
        }
        if ($status) {
            $query .= " and rt.status = '$status'";
        }
        $exe = $this->db->exec($query);
        if ($exe) {
            return $exe;
        } else {
            return false;
        }
    }

    public function gedFullView($doc_origem, $tipo = null, $id_owner = null, $data_ini = null, $data_fim = null, $subtipo = null)
    {
        $query =
            "select 
                gd.id as id_ged_documento, 
                gd.nome_documento, 
                gd.data_documento, 
                gd.doc_origem, 
                gd.id_origem, 
                gd.produto, 
                gd.tipo, 
                gd.subtipo, 
                gd.owner, 
                gd.data_criacao as data_criacao_documento,
                ga.id as id_ged_anexo, 
                ga.id_documento, 
                ga.nome_amigavel, 
                ga.path_root, 
                ga.path_objeto, 
                ga.nome_hash, 
                ga.hash_arquivo, 
                ga.data_criacao as data_criacao_anexo, 
                u.nome as nome_usuario,
                u.cpf, gcd.document_key, 
                gcd.status status_assinatura,
                gcd.link_doc_original, 
                gcd.link_doc_assinado
            from 
                ged_documento as gd
            INNER JOIN 
                ged_anexo AS ga
            ON 
                (gd.id = ga.id_documento )
            INNER JOIN
                sistema_usuarios as u
            ON 
                (u.id = gd.owner)
            LEFT JOIN   
                ged_clicksign_documento gcd
            ON 
                (gcd.id_ged_anexo = ga.id)
                
            where 
                (gd.deleted is null or gd.deleted = 0)";

        if ($doc_origem) {
            $query .= " and gd.doc_origem = '$doc_origem'";
        }

        if ($tipo) {
            $query .= " and gd.tipo = '$tipo'";
        }

        if ($id_owner) {
            $query .= " and gd.owner = '$id_owner'";
        }

        if ($data_ini) {
            $query .= " and gd.data_documento >= '$data_ini'";
        }

        if ($data_fim) {
            $query .= " and gd.data_documento <= '$data_fim'";
        }

        if ($subtipo) {
            $query .= " and gd.subtipo = '$subtipo'";
        }

        $query .= " order by gd.id desc";
        // echo $query;
        return $exe = $this->db->exec($query);
    }

    public function gedFull($id_ged = null, $tipo = null, $id_owner = null, $data_ini = null, $data_fim = null)
    {
        $query =
            "select 
                gd.id as id_ged_documento, gd.nome_documento, gd.data_documento, gd.doc_origem, gd.id_origem, 
                gd.produto, gd.tipo, gd.subtipo, gd.owner, gd.data_criacao as data_criacao_documento,
                ga.id as id_ged_anexo, ga.id_documento, ga.nome_amigavel, ga.path_root, ga.path_objeto, 
                ga.nome_hash, ga.hash_arquivo, ga.data_criacao as data_criacao_anexo, u.nome as nome_usuario,
                u.cpf, gca.id_usuario, gca.ordem_assinatura, gca.request_signature_key, gcd.document_key, gcd.status
            from 
                ged_documento as gd
            INNER JOIN 
                ged_anexo AS ga
            ON 
                (gd.id = ga.id_documento )
            INNER JOIN
                sistema_usuarios as u
            ON 
                (u.id = gd.owner)
            LEFT JOIN   
                ged_clicksign_documento gcd
            ON 
                (gcd.id_ged_anexo = ga.id)
            LEFT JOIN   
                ged_clicksign_assinatura gca
            ON 
                (gca.id_ged_anexo = ga.id)      
            where 
                (gd.deleted is null or gd.deleted = 0)";

        if ($id_ged) {
            $query .= " and gd.id = '$id_ged'";
        }

        if ($tipo) {
            $query .= " and gd.tipo = '$tipo'";
        }

        if ($id_owner) {
            $query .= " and gd.owner = '$id_owner'";
        }

        if ($data_ini) {
            $query .= " and gd.data_documento >= '$data_ini'";
        }

        if ($data_fim) {
            $query .= " and gd.data_documento <= '$data_fim'";
        }
        $query .= " order by gd.id desc";
        return $exe = $this->db->exec($query);
    }

    function gedAnexosToAssinatura($id_documento)
    {
        $query = "
                SELECT
                    gd.*,
                    ga.id id_ged_anexo,
                    ga.path_root,
                    ga.path_objeto,
                    ga.nome_hash,
                    ga.hash_arquivo,
                    gcd.document_key,
                    gca.key_documento document_key,
                    gcd.link_doc_original,
                    gcd.link_doc_assinado,
                    gcd.data_upload,
                    gca.request_signature_key,
                    gca.tipo_assinatura,
                    gca.metodo_assinatura,
                    gca.ordem_assinatura,
                    gca.assinado,
                    gca.data_assinatura,
                    gca.prazo_assinatura,
                    gca.status status_anexo,
                    us.id id_assinante,
                    us.cpf cpf_assinante,
                    us.nome nome_assinante,
                    us2.id id_owner,
                    us2.cpf cpf_owner,
                    us2.nome nome_owner
                FROM
                    ged_documento gd LEFT join
                    ged_anexo ga ON(gd.id = ga.id_documento) left join
                    ged_clicksign_documento gcd ON (ga.id = gcd.id_ged_anexo) LEFT join
                    ged_clicksign_assinatura gca ON (ga.id = gca.id_ged_anexo) LEFT join
                    sistema_usuarios us ON(gca.id_usuario = us.id) LEFT join
                    sistema_usuarios us2 ON(us2.id = gd.owner)	
                WHERE
                    (gd.deleted IS NULL OR gd.deleted = 0)
            ";
        if ($id_documento) {
            $query .= " and gd.id = $id_documento ";
        }
        return $this->db->exec($query);
    }

    function gedAnexosToAssinaturaByKey($document_key)
    {
        $query = "
                SELECT
                    gca.*,
                    ga.id id_ged_anexo,
                    ga.path_root,
                    ga.path_objeto,
                    ga.nome_hash,
                    ga.hash_arquivo,
                    gcd.document_key,
                    gcd.link_doc_original,
                    gcd.link_doc_assinado,
                    gcd.data_upload,
                    us.id id_assinante,
                    us.cpf cpf_assinante,
                    us.nome nome_assinante,
                    us2.id id_owner,
                    us2.cpf cpf_owner,
                    us2.nome nome_owner
                FROM
                    ged_documento gd LEFT join
                    ged_anexo ga ON(gd.id = ga.id_documento) left join
                    ged_clicksign_documento gcd ON (ga.id = gcd.id_ged_anexo) LEFT join
                    ged_clicksign_assinatura gca ON (ga.id = gca.id_ged_anexo) LEFT join
                    sistema_usuarios us ON(gca.id_usuario = us.id) LEFT join
                    sistema_usuarios us2 ON(us2.id = gd.owner)	
                WHERE
                    (gca.deleted IS NULL OR gca.deleted = 0)
            ";
        if ($document_key) {
            $query .= " and ( gca.key_documento = '$document_key' )";
        }
        return $this->db->exec($query);
    }

    function gedDocsToAssinaturaByKey($document_key)
    {
        $query = "
                SELECT
                    gd.*,
                    ga.id id_ged_anexo,
                    ga.path_root,
                    ga.path_objeto,
                    ga.nome_hash,
                    ga.hash_arquivo,
                    gcd.document_key,
                    gcd.link_doc_original,
                    gcd.link_doc_assinado,
                    gcd.data_upload,
                    gca.request_signature_key,
                    gca.tipo_assinatura,
                    gca.metodo_assinatura,
                    gca.ordem_assinatura,
                    gca.assinado,
                    gca.data_assinatura,
                    gca.prazo_assinatura,
                    gca.status status_anexo,
                    us.id id_assinante,
                    us.cpf cpf_assinante,
                    us.nome nome_assinante,
                    us2.id id_owner,
                    us2.cpf cpf_owner,
                    us2.nome nome_owner
                FROM
                    ged_documento gd LEFT join
                    ged_anexo ga ON(gd.id = ga.id_documento) left join
                    ged_clicksign_documento gcd ON (ga.id = gcd.id_ged_anexo) LEFT join
                    ged_clicksign_assinatura gca ON (ga.id = gca.id_ged_anexo) LEFT join
                    sistema_usuarios us ON(gca.id_usuario = us.id) LEFT join
                    sistema_usuarios us2 ON(us2.id = gd.owner)	
                WHERE
                    (gd.deleted IS NULL OR gd.deleted = 0)
            ";
        if ($document_key) {
            $query .= " and ( gcd.document_key = '$document_key' or gca.key_documento = '$document_key' )";
        }
        return $this->db->exec($query);
    }

    function gedAnexoByIdDocumento($id)
    {
        $query =
            "select 
                    * 
                from 
                    ged_documento gd inner join
                    ged_anexo ga on(gd.id = ga.id_documento) left join
                    ged_clicksign_documento gcd on(ga.id = gcd.id_ged_anexo) left join
                    ged_clicksign_assinatura gca on(ga.id = gca.id_ged_anexo)
                where
                    (gd.deleted is null or gd.deleted = 0)";
        if ($id) {
            $query .= " and gd.id = '$id'";
        }
        return $this->db->exec($query);
    }

    function getSignatarios($document_key)
    {
        $query = "
                SELECT
                    gd.*,
                    ga.id id_ged_anexo,
                    ga.path_root,
                    ga.path_objeto,
                    ga.nome_hash,
                    ga.hash_arquivo,
                    gcd.document_key,
                    gcd.link_doc_original,
                    gcd.link_doc_assinado,
                    gcd.data_upload,
                    gca.id id_assinatura,
                    gca.request_signature_key,
                    gca.tipo_assinatura,
                    gca.metodo_assinatura,
                    gca.ordem_assinatura,
                    gca.assinado,
                    gca.data_assinatura,
                    gca.prazo_assinatura,
                    gca.status status_anexo,
                    us.id id_assinante,
                    us.email_pessoal email_assinante,
                    us.cpf cpf_assinante,
                    us.nome nome_assinante,
                    us2.id id_owner,
                    us2.cpf cpf_owner,
                    us2.nome nome_owner
                FROM
                    ged_documento gd LEFT join
                    ged_anexo ga ON(gd.id = ga.id_documento) left join
                    ged_clicksign_documento gcd ON (ga.id = gcd.id_ged_anexo) LEFT join
                    ged_clicksign_assinatura gca ON (ga.id = gca.id_ged_anexo) LEFT join
                    sistema_usuarios us ON(gca.id_usuario = us.id) LEFT join
                    sistema_usuarios us2 ON(us2.id = gd.owner)	
                WHERE
                    (gd.deleted IS NULL OR gd.deleted = 0)
            ";
        if ($document_key) {
            $query .= " and gca.key_documento = '$document_key' ";
        }
        return $this->db->exec($query);
    }

    function getUltimoFechamento($id_usuario)
    {
        if (!$id_usuario || !is_numeric($id_usuario)) {
            return false;
        }
        $query = "
                select 
                    rfp.*,
                    usu.nome nome_usuario,
                    gd.id id_documento,
                    ga.id id_anexo
                from 
                    rh_fechamento_ponto rfp inner join
                    sistema_usuarios usu on (usu.id = rfp.id_usuario) left join
                    ged_documento gd on(gd.id_origem = rfp.id) left join
                    ged_anexo ga on (ga.id_documento = gd.id)
                where 
                    ( rfp.deleted is null or rfp.deleted = 0) and
                    ( gd.deleted is null or gd.deleted = 0) and 
                    classificacao = 'espelho' and 
                    rfp.id_usuario = $id_usuario 
                    order by 
                        rfp.periodo_fim desc 
                limit 1
            ";
        return $this->db->exec($query);
    }

    function getFechamentoByUsuario($id_usuario)
    {
        if (!$id_usuario || !is_numeric($id_usuario)) {
            return false;
        }

        $query = "
                select 
                    rfp.*,
                    usu.nome nome_usuario,
                    usu.departamento,
                    usu.id id_usuario,
                    usu.cpf,
                    ged.id id_documento
                from 
                    rh_fechamento_ponto rfp inner join
                    sistema_usuarios usu on (usu.id = rfp.id_usuario) left join
                    ged_documento ged ON( ged.id_origem =  rfp.id and ged.subtipo = 'fechamento' )
                where 
                    ( rfp.deleted is null or rfp.deleted = 0) and
                    (ged.deleted IS NULL OR ged.deleted = 0) AND
                    rfp.id_usuario = $id_usuario order by rfp.periodo_fim desc
            ";
        return $this->db->exec($query);
    }

    function getFechamentoById($id)
    {
        $query = "
                select 
                    rfp.*
                from 
                    rh_fechamento_ponto rfp
                where 
                    ( rfp.deleted is null or rfp.deleted = 0)
            ";
        if ($id && is_numeric($id)) {
            $query .= " and rfp.id = $id ";
        } else {
            return false;
        }
        return $this->db->exec($query);
    }

    // function ultimaJornada( $id_usuario ){
    //     if( !validaId( $id_usuario ) ){
    //         return false;
    //     }

    //     $query = "
    //         SELECT 
    //             *
    //         FROM 
    //             rh_jornada_usuario ju INNER JOIN 
    //             rh_jornada_trabalho jt ON ju.id_jornada = jt.id INNER JOIN 
    //             sistema_usuarios ut ON ju.id_usuario = ut.id
    //         WHERE 
    //             (ju.deleted IS NULL OR ju.deleted = 0) AND 
    //             ju.id_usuario = $id_usuario AND 
    //             ju.status = 'ativo'
    //         ORDER BY 
    //             ju.data_inicio DESC
    //         LIMIT 1;
    //     ";
    //     return $this->db->exec( $query );
    // }

    function ultima_marcacao($id_user)
    {
        if (!validaId($id_user)) {
            return false;
        }
        $query = "
            SELECT 
                * 
            FROM 
                rh_registro_ponto rrp 
            WHERE 
                ( rrp.deleted IS NULL OR rrp.deleted = 0 ) and 
                id_usuario = $id_user 
            ORDER BY 
                data_marcacao DESC, 
                hora_marcacao DESC LIMIT 1;
        ";
        return $this->db->exec($query);
    }

    function getUltimaOcorrenciaRegistro($id_user)
    {
        if (!validaId($id_user)) {
            return false;
        }

        $param[] = $id_user;
        $query = "
            SELECT
                *
            FROM	
                rh_jornada_ocorrencia rjo
            WHERE
                (rjo.deleted IS NULL OR rjo.deleted = 0) and
                rjo.fonte = 'R' and
                rjo.id_usuario = ?
            ORDER BY
                rjo.data DESC, rjo.hora desc
            LIMIT 1;
        ";
        return $this->db->exec($query, $param);
    }

    function getOcorrenciaByClasse($id_user, $classe, $data_ini = null, $data_fim = null)
    {
        if (!validaId($id_user)) {
            return false;
        }

        $query = "
                SELECT 
                    * 
                FROM 
                    rh_jornada_ocorrencia rjo 
                WHERE 
                    ( rjo.deleted IS NULL OR rjo.deleted = 0 ) AND 
                    rjo.id_usuario = $id_user and 
                    rjo.classe = '$classe'
            ";

        if ($data_ini) {
            $query .= " and rjo.`data` >= '$data_ini' ";
        }

        if ($data_fim) {
            $query .= " and rjo.`data` <= '$data_fim' ";
        }

        $query .= "
                order BY
                    rjo.`data` DESC, 
                    rjo.hora desc;
            ";
        return $this->db->exec($query);
    }
    
    public function obtemContratosComObs(){
        $query = "SELECT id, alterado_por,obs_contrato FROM contratos WHERE obs_contrato != ''";
        return $this->db->exec($query);
    }

    function getDataHora($id_usuario, $data_marcacao, $hora_marcacao){
        if(!validaId($id_usuario)){
            return false;
        }
        
        $query = "
            select
                t1.*
            from
                $this->table t1 INNER JOIN
                sistema_usuarios t2 on(t1.id_usuario = t2.id)
            where
                (t1.deleted is null or t1.deleted = 0)
        ";

        if ($data_marcacao) {
            $query .= " and t1.data_marcacao = '$data_marcacao' ";
        }

        if ($id_usuario) {
            $query .= " and t1.id_usuario = '$id_usuario'";
        }

        if ($hora_marcacao) {
            $query .= " and TIME_FORMAT(t1.hora_marcacao, '%H:%i') = '$hora_marcacao' ";
        }
        return $this->db->exec($query);
    }
}
