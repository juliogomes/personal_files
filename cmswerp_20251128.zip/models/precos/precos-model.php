<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class PrecosModel extends MainModel{
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	public function __construct($controller = null ){
		$this->table = 'lp_default';
		parent::__construct($controller);
	}
	
	function getPacoteDefaultHistorico($id_pacote){
		$query = "
			select
				p.*,
				u.id id_usuario,
				u.nome nome_usuario
		 	from 
				pacote_historico p
			inner join
				sistema_usuarios u
			on
				p.alterado_por = u.id
			where 
				(p.deleted is null or p.deleted = 0) and
				tipo_pacote = 'default' ";

		if($id_pacote){
			$query .= " and p.id_pacote = '$id_pacote'";
		}
		$query .= " order by p.alterado_em desc";
		return $this->db->exec($query);
	}
	
    function getLpDefaultHistorico($id_lp){
		$query = "
			select
				lh.*,
				u.id id_usuario,
				u.nome nome_usuario
		 	from 
				lp_historico lh
			inner join
				sistema_usuarios u
			on
				lh.alterado_por = u.id
			where 
				(lh.deleted is null or lh.deleted = 0) and
				tipo_lista = 'default'
			";

		if($id_lp){
			$query .= " and lh.id_lp = '$id_lp'";
		}
		$query .= " order by lh.alterado_em desc";
		return $this->db->exec($query);
	}

    function getLpdefaultByProduto($id_produto = null, $id_modulo = null, $qtd_de = null, $qtd_ate = null){
		$query = "
			select 
				lp.*,
				mt.codigo codigo_modulo,
				mt.descricao nome_modulo
			from 
				lp_default lp inner join 
				produtos p on(lp.id_produto = p.id) inner join 
				modulos_tarifaveis mt on(mt.id = lp.id_modulo)
			where 
				lp.`status` = 'ativo' and (lp.deleted = 0 or lp.deleted is null)
		";

		if($id_modulo){
			$query .= " and lp.id_modulo = $id_modulo ";
		}

		if($id_produto){
			$query .= " and lp.id_produto = $id_produto ";
		}
		
		if($qtd_de){
			$query .= " and lp.qtd_de = $qtd_de ";
		}

		if($qtd_ate){
			$query .= " and lp.qtd_ate = $qtd_ate ";
		}
		
		$query .= " order by qtd_de, qtd_ate, valor_real ";
		return $this->db->exec($query);
	}
	
	function getPacoteDefaultByProduto($id_produto){
		$query = " 
			select 
				pd.*,
				mt.codigo codigo_modulo,
				mt.descricao nome_modulo 
			from 
				pacote_default pd inner join
				modulos_tarifaveis mt on(mt.id = pd.id_modulos_tarifaveis)
			where 
				(pd.deleted is null or pd.deleted = 0) and 
				pd.status = 'ativo' 
			";
		if($id_produto){
			$query .= " and pd.id_produto = $id_produto ";
		}
		return $this->db->exec($query);
	}

	function getPacoteDefaultById($id_pacote){
		$query = " 
		SELECT 
			* 
		FROM 
			pacote_default pd 
		where (pd.deleted is null or pd.deleted = 0) and pd.status = 'ativo' ";
		if($id_pacote){
			$query .= " and pd.id = $id_pacote ";
		}
		return $this->db->exec($query);
	}

	function getPacoteDefaultByModulo($id_produto, $id_modulo, $qtd_transacoes = null){
		$query = " select * from pacote_default pd where (pd.deleted is null or pd.deleted = 0) and pd.status = 'ativo' ";
		if($id_produto){
			$query .= " and pd.id_produto = $id_produto ";
		}
		if($id_modulo){
			$query .= " and pd.id_modulos_tarifaveis = $id_modulo ";
		}
		if($qtd_transacoes){
			$query .= " and pd.qdt_garantido = $qtd_transacoes ";
		}
		return $this->db->exec($query);
	}
}
