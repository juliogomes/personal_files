<?php
    /**
     * Created by PhpStorm.
     * User: julio.gomes
     * Date: 14/10/2016
     * Time: 15:57
     */

    class ProdutosModel extends MainModel{
        public function __construct($controller = null ){
            $this->setTable('produtos');
            parent::__construct($controller);
        }

        function getAllProdutosAtivos(){
            $query = " select * from $this->table where (deleted is null or deleted = 0) and `status` = 'ativo' ";
            return $this->db->exec( $query );
        }

        function getModulosByProduto($id_produto){
            $query = "select * from modulos_tarifaveis mt where (mt.deleted is null or mt.deleted = 0) ";
            if($id_produto){
                $query .= " and mt.id_produto = '$id_produto'";
            }
            return $this->db->exec($query);
        }

        function getProduto( $id = null, $codigo_produto = null ){
            $query = "select * from $this->table where (deleted is null or deleted = 0) ";
            if($id){
                $query .= " and id = $id";
            }
            
            if($codigo_produto){
                $query .= " and codigo = '$codigo_produto'";
            }
            $exec = $this->db->query($query);
            if($exec){
                // Retorna
                $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }

        function getProdutoEmodulo( $codigo_produto = null, $codigo_modulo = null ){
            $query = "select mt.*, pr.codigo codigo_produto from produtos pr inner join modulos_tarifaveis mt on(pr.id = mt.id_produto) where (pr.deleted is null or pr.deleted = 0) ";
            if($codigo_produto){
                $query .= " and pr.codigo = '$codigo_produto'";
            }

            if($codigo_modulo){
                $query .= " and mt.codigo = '$codigo_modulo'";
            }
            return $this->db->exec($query);
        }

        function getProdutosPorCliente($codigo_cliente = null){
            $query = "select distinct pr.* from $this->table pr inner join contratos con on(con.id_produto = pr.id) where (pr.deleted is null or pr.deleted = 0) ";
            
            if($codigo_cliente){
                $query .= " and con.codigo_cliente = $codigo_cliente ";
            }
            return $this->db->exec($query);
        }

        function getAllCodigoProdutosAtivos(){
            $query = "select id id_produto, codigo codigo_produto, descricao, nome nome_produto from $this->table where `status` = 'ativo'";
            $exec = $this->db->query($query);
            if($exec){
                // Retorna
                $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }

        function getAllCodigoModulosAtivos($id_produto = null, $id_modulo = null, $codigo_produto = null){
            $query = "
            SELECT
                mt.id id_modulo, 
                mt.codigo codigo_modulo, 
                mt.descricao nome_modulo, 
                mt.tipo_cobranca, 
                pr.codigo codigo_produto, 
                pr.nome nome_produto,
                pr.id as id_produto
            FROM 
                produtos pr 
            INNER JOIN 
                modulos_tarifaveis mt 
            on
                (pr.id = mt.id_produto)  
            WHERE
                (mt.deleted is null or mt.deleted = 0 ) and
                pr.status = 'ativo' and mt.status= 'ativo'";
            
            if($id_modulo){
                $query .= " and mt.id = $id_modulo";
            }

            if($id_produto){
                $query .= " and pr.id = $id_produto";
            }

            if($codigo_produto){
                $query .= " and pr.codigo = '$codigo_produto'";
            }
            $exec = $this->db->query($query);
            if($exec){
                // Retorna
                $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }

        function getAllModulosAtivos(){
            $query = "select id id_modulo, codigo codigo_modulo, descricao, `status`, id_produto,empacotavel, 
            tipo_cobranca, permite_entrada_manual, allow_lp_default from modulos_tarifaveis mt where mt.status = 'ativo' ";
            $exec = $this->db->query($query);
            if($exec){
                // Retorna
                $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }

        function getLpByDefaultProduto($id_produto = null, $codigo_produto = null, $codigo_modulo = null){
            $query = "select 
                            lpd.*,
                            mt.descricao nome_modulo,
                            mt.codigo codigo_modulo,
                            pr.codigo codigo_produto,
                            pr.nome nome_produto  
                    FROM
                        lp_default lpd inner join 
                        modulos_tarifaveis mt on(mt.id = lpd.id_modulo) inner join
                        produtos pr on(pr.id = lpd.id_produto) 
                    where 
                        (lpd.deleted is null or lpd.deleted = 0 ) and 
                        lpd.status = 'ativo'
                    ";
            if($id_produto){
                $query .= " and lpd.id_produto = $id_produto ";
            }

            if($codigo_produto){
                $query .= " and pr.codigo = '$codigo_produto' ";
            }

            if($codigo_modulo){
                $query .= " and mt.codigo = '$codigo_modulo' ";
            }

            $query .= " order by lpd.qtd_de ";
            $exec = $this->db->query($query);
            if($exec){
                // Retorna
                $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }

        function getLpByDefaultModulo($id_modulo = null, $codigo_modulo = null){
            $query = "select 
                            lpd.*,
                            mt.descricao nome_modulo  
                    FROM
                        lp_default lpd inner join 
                        modulos_tarifaveis mt on(mt.id = lpd.id_modulo)
                    where 
                        (lpd.deleted is null or lpd.deleted = 0 ) and 
                        lpd.status = 'ativo'
                    ";

            if($id_modulo){
                $query .= " and lpd.id_modulo = $id_modulo ";
            }

            if($codigo_modulo){
                $query .= " and mt.codigo = '$codigo_modulo' ";
            }        

            $query .= " order by mt.codigo, lpd.qtd_de ";
            $exec = $this->db->query($query);
            if($exec){
                // Retorna
                $return = $exec->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }
        
        //FUNÇAO CRIADO POR: CAIO FREITAS
        function getModulosEmpacotavel($id_produto = null, $empacotavel = null, $id_modulo = null){
            $query = "select * from modulos_tarifaveis";
            if($id_produto){
                $query .= " where id_produto = '$id_produto'";
            }
            if($empacotavel === true){
                $query .= " and empacotavel = 1";
            }
            if($id_modulo){
                $query .= " and id = '$id_modulo'";
            }
            $query .= " order by codigo";
            $exe = $this->db->query($query);
            if($exe){
                $return = $exe->fetchAll();
                return json_encode($return);
            }else{
                return false;
            }
        }
    }