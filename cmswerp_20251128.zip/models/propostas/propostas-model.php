<?php
	class PropostasModel extends MainModel {
		public $table =  'propostas';
		
		public function __construct($controller = null )
		{
			$this->setTable('propostas');
			parent::__construct($controller);
		}

		function getNomeProdutoProposta(){
			
			$query = "
			select p.id, p.id_produto, p.cliente, pro.nome, p.data_criacao 
			from 
				propostas AS p
			inner join 
				produtos AS pro
			ON pro.id = p.id_produto
			WHERE (p.deleted = 0 OR p.deleted = NULL)
			";

			$query .= " order by p.data_criacao, p.id desc ";
			return $exe = $this->db->exec($query);
			if( $exe ){
				return $exe;
			}else{
				return false;
			}
		}

		function getPropostasAlçada($id_proposta = null,  $alcada = null){
			$query = "
			SELECT 
				p.id, p.empresa, ut.nome, p.id_owner, p.id_produto, ut.nome as nome_usuario, ut.email as email_usuario, ut.telefone as telefone_usuario,  
				pf.id_propostas, p.cnpj_cpf, p.cliente, p.data_criacao, p.email, p.telefone, p.celular, p.cep, p.endereco, p.numero, p.complemento, p.bairro, 
				p.estado, p.cidade, p.status, p.propostas_finalizada, p.alterado_por, p.criado_por, pf.valor_implantacao, pf.numero_parcelas, pf.data_pagamento, 
				pf.data_segundo_pagamento, pf.data_terceiro_pagamento, pf.custo_hora_homem, pro.nome as nome_produto
			from
				propostas AS p 
			INNER JOIN 
				propostas_faturamento AS pf
			ON 
				(p.id = pf.id_propostas)
			INNER JOIN 
				sistema_usuarios AS ut
			ON 
				(p.id_owner = ut.id)	
			INNER JOIN 
				produtos AS pro
			ON 
				(pro.id = p.id_produto)
			WHERE 
				(p.deleted = 0 OR p.deleted = NULL) 
			AND 
				(pf.deleted = 0 OR pf.deleted = NULL) 
			";
			
			if($id_proposta){
				$query .= " and p.id = $id_proposta"; 
			}
			
			if($alcada){
				$query .= " and p.id_owner = '$alcada' ";
			}

			$query .= " order by p.id desc ";
			
			
			$exe = $this->db->exec($query);
			
			if($exe){
				return $exe;
			}else{
				return false;
			}
			
		}

	function getPropostas($id_proposta = null, $data_ini = null, $data_fim = null, $owner = null, $status = null)
	{
		$query = "
				SELECT
					p.id, p.empresa, 
					p.id_cm, 
					ev.cnpj cnpj_cm,
					ev.nome_fantasia nome_cm, 
					ut.nome, 
					p.id_owner, 
					p.id_produto, 
					ut.nome as nome_usuario, 
					ut.email as email_usuario, 
					ut.telefone as telefone_usuario, 
					pf.id_propostas, 
					p.cnpj_cpf, 
					p.cliente, 
					p.data_criacao, 
					p.email, 
					p.telefone, 
					p.celular, 
					p.cep, 
					p.endereco, 
					p.numero, 
					p.complemento, 
					p.bairro, 
					p.estado, 
					p.cidade, 
					p.status, 
					p.propostas_finalizada, 
					p.alterado_por, 
					p.criado_por, 
					pf.valor_implantacao, 
					pf.numero_parcelas, 
					pf.data_pagamento, 
					pf.data_segundo_pagamento, 
					pf.data_terceiro_pagamento, 
					pf.custo_hora_homem, 
					pro.nome as nome_produto, 
					p.proposta_fora_padrao, 
					pro.codigo, 
					ut.id as id_usuario, 
					ic.finalizado as finalizado_minuta,
					ic.id as id_contrato
				from
					propostas AS p INNER JOIN
					empresa_vendedora ev on (ev.id = p.id_cm) inner join
					propostas_faturamento AS pf ON(p.id = pf.id_propostas) INNER JOIN
					sistema_usuarios AS ut ON (p.id_owner = ut.id) INNER JOIN
					produtos AS pro ON (pro.id = p.id_produto) LEFT JOIN
					if_contrato ic ON (ic.id_proposta = p.id)
				WHERE
					(p.deleted = 0 OR p.deleted = NULL) ";
					// AND
					// 	p.propostas_finalizada = 'sim'		 

		if ($id_proposta) {
			$query .= " and p.id = $id_proposta";
		}

		if ($data_ini) {
			$query .= " and p.data_criacao >= '$data_ini' ";
		}

		if ($data_fim) {
			$query .= " and p.data_criacao <= '$data_fim' ";
		}

		if ($owner) {
			$query .= " and p.id_owner = $owner ";
		}

		if ($status) {
			if ($status == "pendente") {
				$query .= " and p.status in('aprovada_orli', 'aberta', 'aprovada_comercial')";
			} else {
				$query .= " and p.status = '$status' ";
			}
		}
		$query .= " order by p.id desc ";
		return $exe = $this->db->exec($query);
	}
	
		function getPropostasByBoss( $data_ini, $data_fim, $boss, $owner ){
			$query = "
				SELECT
					p.id, p.empresa, ut.nome, p.id_owner, p.id_produto, ut.nome as nome_usuario, ut.email as email_usuario, ut.telefone as telefone_usuario, pf.id_propostas, 
					p.cnpj_cpf, p.cliente, p.data_criacao, p.email, p.telefone, p.celular, p.cep, p.endereco, p.numero, p.complemento, p.bairro, p.estado, p.cidade, p.status, 
					p.propostas_finalizada, p.alterado_por, p.criado_por, pf.valor_implantacao, pf.numero_parcelas, pf.data_pagamento, pf.data_segundo_pagamento, 
					pf.data_terceiro_pagamento, pf.custo_hora_homem, pro.nome as nome_produto, p.proposta_fora_padrao, pro.codigo, ut.id as id_usuario, ut.boss AS id_boss, ic.finalizado as finalizado_minuta,
					ic.id as id_contrato
				from
					propostas AS p 
				INNER JOIN
					propostas_faturamento AS pf
				ON
					(p.id = pf.id_propostas)
				INNER JOIN
					sistema_usuarios AS ut
				ON
					(p.id_owner = ut.id)	
				INNER JOIN
					produtos AS pro
				ON
					(pro.id = p.id_produto)
				LEFT JOIN
					if_contrato ic
				ON
					(ic.id_proposta = p.id)		
				WHERE
					(p.deleted = 0 OR p.deleted = NULL) 
				AND
					p.propostas_finalizada = 'sim'		 
			";

			if($data_ini){
				$query .= " and p.data_criacao >= '$data_ini' ";
			}
			
			if($data_fim){
				$query .= " and p.data_criacao <= '$data_fim' ";
			}
			
			if($boss){
				$query .= " and ut.boss = $boss ";
			}

			if($owner){
				$query .= " and p.id_owner = $owner ";
			}
			$query .= " order by p.id desc ";
			return $exe = $this->db->exec($query);		
		}

		//by Caio Freitas - 08/12/2022
		function newGetProposta($id_proposta){
			$query = "
			SELECT 
				p.*, ut.nome as nome_usuario, ut.email as email_usuario, ut.telefone as telefone_usuario, 
				pf.valor_implantacao, pf.numero_parcelas, pf.custo_hora_homem, pro.nome as nome_produto, pro.codigo
			FROM
				propostas AS p 
			INNER JOIN 
				propostas_faturamento AS pf
			ON 
				(p.id = pf.id_propostas)
			INNER JOIN 
				sistema_usuarios AS ut
			ON 
				(p.id_owner = ut.id)	
			INNER JOIN 
				produtos AS pro
			ON 
				(pro.id = p.id_produto)
			WHERE 
				(p.deleted is null OR p.deleted = 0)";

			if($id_proposta){
				$query .= " and p.id = $id_proposta"; 
			}
			$query .= " order by p.id desc ";
			return $this->db->exec($query);
		}

		function getPropostasPendentesAprovadas($status = null, $id_owner = null){
			$query = " SELECT * from propostas where (deleted is null or deleted = 0) and propostas_finalizada = 'sim' ";
			if($status == "pendente"){
				$query .= " and status in('aberta','aprovada_orli', 'aprovada_comercial')";
			}else{
				$query .= " and status = 'fechada'";
			}

			if($id_owner){
				$query .= " and id_owner = $id_owner ";
			}

			$query .= " order by data_criacao asc ";
			$exe = $this->db->exec($query);
			if($exe){
				return $exe;
			}else{
				return false;
			}
		}

		function getPropostasByMesesAnteriores($status = null,  $id_owner = null, $meses = 6){
			$data_hoje = clone $this->controller->data_hora_atual;
			if($meses == 0){
				$data_hoje->modify('First day of this month');
			}else{
				$data_hoje->sub(new DateInterval('P'.$meses.'M'));
			}
			
			$query = " select 
						pro.*,
						usr.nome nome_usuario 
					from 
						propostas pro inner join
						sistema_usuarios usr on(pro.id_owner = usr.id) 
					WHERE 
						(pro.deleted is null or pro.deleted = 0) and  pro.propostas_finalizada = 'sim' and ";
			$query .= " pro.data_criacao >= '".$data_hoje->format('Y-m-d')."'";

			if($status){
				$query .= " and pro.status = '$status' ";
			}

			if($id_owner){
				$query .= " and pro.id_owner = $id_owner ";
			}

			$query .= " order by data_criacao asc ";
			

			$exe = $this->db->exec($query);

			if($exe){
				return $exe;
			}else{
				return false;
			}
		}

		function getPropostasNaoFinalizada($id_proposta = null, $data_ini = null, $data_fim = null, $owner = null ){
			$query = "
				SELECT 
					p.id, p.empresa, ut.nome, p.id_owner, p.id_produto, ut.nome as nome_usuario, ut.email as email_usuario, ut.telefone as telefone_usuario, pf.id_propostas, 
					p.cnpj_cpf, p.cliente, p.data_criacao, p.email, p.telefone, p.celular, p.cep, p.endereco, p.numero, p.complemento, p.bairro, p.estado, p.cidade, p.status, 
					p.propostas_finalizada,	pf.valor_implantacao, pf.numero_parcelas, pf.data_pagamento, pf.data_segundo_pagamento, pf.data_terceiro_pagamento, pf.custo_hora_homem, 
					pro.nome as nome_produto, p.proposta_fora_padrao, pro.codigo, ut.id as id_usuario
				from
					propostas AS p 
				INNER JOIN 
					propostas_faturamento AS pf
				ON p.id = pf.id_propostas
				INNER JOIN 
					sistema_usuarios AS ut
				ON p.id_owner = ut.id	
				INNER JOIN 
					produtos AS pro
				ON pro.id = p.id_produto
				WHERE (p.deleted = 0 OR p.deleted = NULL) AND (pf.deleted = 0 OR pf.deleted = NULL) 
			";
			
			if($id_proposta){
				$query .= " and p.id = $id_proposta"; 
			}

			if($data_ini){
				$query .= " and p.data_criacao >= '$data_ini' ";
			}
			if($data_fim){
				$query .= " and p.data_criacao <= '$data_fim' ";
			}
			if($owner){
				$query .= " and ut.nome = '$owner' ";
			}

			$query .= " order by p.id desc ";

			return $this->db->exec($query);		
		}

		function getPropostasTexto( $id_proposta = null, $proposta_fora_padrao = false, $condicao = false, $id_owner = null, $tipo_fora_padrao = null ){
			$query = "
				SELECT 
					p.id, 
					p.empresa, 
					ut.nome, 
					p.id_owner, 
					p.id_produto, ut.nome as nome_usuario, ut.telefone as telefone_usuario, ut.email as email_usuario, ut.telefone as telefone_usuario,  
					pf.id_propostas, p.cnpj_cpf, p.cliente, p.data_criacao, p.email, p.email_enviado,
					p.telefone, p.celular, p.cep, p.endereco, p.numero, p.complemento, p.bairro, p.estado, p.cidade, p.status, p.propostas_finalizada, p.proposta_fora_padrao, 
					pf.valor_implantacao, pf.numero_parcelas, pf.data_pagamento, pf.data_segundo_pagamento, 
					pf.data_terceiro_pagamento, pf.custo_hora_homem,  pro.nome as nome_produto, p.descricao, pro.codigo
				from
					propostas AS p 
				INNER JOIN 
					propostas_faturamento AS pf
				ON p.id = pf.id_propostas
				INNER JOIN 
					sistema_usuarios AS ut
				ON p.id_owner = ut.id	
				INNER JOIN 
					produtos AS pro
				ON pro.id = p.id_produto
				WHERE 
					(p.deleted = 0 OR p.deleted is null) AND (pf.deleted = 0 OR pf.deleted is null)
			";
			
			if($id_proposta){
				$query .= " and p.id = $id_proposta"; 
			}

			if($proposta_fora_padrao == true){
				if($tipo_fora_padrao == null || empty($tipo_fora_padrao)){
					$query .= " and propostas_finalizada = 'sim' and p.proposta_fora_padrao = 1";
				}elseif($tipo_fora_padrao == 2){
					$query .= " and propostas_finalizada = 'sim' and p.proposta_fora_padrao = 2";
				}
			}

			if($condicao == true){
				$query .= " and p.status NOT IN('fechada')";
			}

			if($id_owner){
				$query .= " and p.id_owner = $id_owner ";
			}
			
			$query .= " order by p.id desc ";
			$exe = $this->db->exec($query);
			if($exe){
				return $exe;
			}else{
				return false;
			}
		}

		function getProdutosProposta($id_proposta = null){

			$query = "
			SELECT 
				p.id, p.empresa, ut.nome, p.id_owner, p.id_produto, ut.nome as nome_usuario, ut.telefone as telefone_usuario, ut.email as email_usuario, ut.telefone as telefone_usuario,  pf.id_propostas, p.cnpj_cpf, p.cliente, p.data_criacao, p.email, 
				p.telefone, p.celular, p.cep, p.endereco, p.numero, p.complemento, p.bairro, p.estado, p.cidade, p.status, p.propostas_finalizada,
				pf.valor_implantacao, pf.numero_parcelas, pf.data_pagamento, pf.data_segundo_pagamento, 
				pf.data_terceiro_pagamento, pf.custo_hora_homem,  pro.nome as nome_produto, pro.codigo as codigo_produto
			from
				propostas AS p 
			INNER JOIN 
				propostas_faturamento AS pf
			ON p.id = pf.id_propostas
			INNER JOIN 
				sistema_usuarios AS ut
			ON p.id_owner = ut.id	
			INNER JOIN 
				produtos AS pro
			ON pro.id = p.id_produto
			WHERE (p.deleted = 0 OR p.deleted = NULL) AND (pf.deleted = 0 OR pf.deleted = NULL) 
					
			";
			
			if($id_proposta){
				$query .= " and p.id = $id_proposta"; 
			}
			
			$query .= " order by p.id desc ";
					
			$exe = $this->db->exec($query);

			if($exe){
				return $exe;
			}else{
				return false;
			}

		}

		function getPropostasID($id_proposta = null){
			$query = "
				select 
					p.id, ut.nome, p.id_owner, p.id_produto, p.cnpj_cpf, p.cliente, 
					p.data_criacao, p.email, p.telefone, p.celular, p.cep,
					p.endereco, p.numero, p.complemento, p.bairro, p.estado, p.cidade, p.status 
				from 
					propostas as p
				inner join 
					sistema_usuarios as ut
				on p.id_owner = ut.id
				where (p.deleted = 0 OR p.deleted = null)		 
			";
			if ($id_proposta){
				$query .= " and p.id = '$id_proposta'";
			}
			$query .= " order by p.id desc";
			return $qr = $this->db->exec($query);
		}
		
		
		function getIdPropostasFaturamento($id_propostas_faturamento){
			$query = "
				select 
					pf.id, pf.id_owner, pf.id_propostas, pf.valor_implantacao, pf.numero_parcelas, pf.data_pagamento, 
					pf.data_segundo_pagamento, pf.data_terceiro_pagamento, pf.custo_hora_homem
				from 
					propostas_faturamento AS pf
				INNER JOIN 
					propostas AS p
				ON pf.id_propostas = p.id

				where (pf.deleted = 0 OR pf.deleted = null)		 
			";
			
			if($id_propostas_faturamento){
				$query .= " and pf.id_propostas = '$id_propostas_faturamento'"; 
			}

			$query .= " order by id desc ";
			return $qr = $this->db->exec($query);
		}

		function getLpEditavel($id_modulo = null){
			$query = " SELECT * FROM lp_propostas WHERE editavel = 1 ";
			if($id_modulo){
				$query .= " and id_modulo = ' $id_modulo'"; 
			}
			$query .= "order by id desc";
			return $this->db->exec($query);
		}

		function obtemMensalidade($codigo_produto){
			$query = "";
		}
		
		function getLpPropostasId($id_propostas = null, $codigo_produto = null){
			$query = "
				SELECT 
					lp.id, lp.qtd_de, lp.qtd_ate, lp.valor_real, lp.id_propostas, lp.id_produto, lp.id_modulo, mt.codigo as codigo_modulo, p.codigo
				FROM 
					lp_propostas AS lp
				INNER JOIN 
					modulos_tarifaveis AS mt
				ON 
					lp.id_modulo = mt.id
				INNER JOIN 
					produtos AS p
				ON 
					mt.id_produto = p.id	
				WHERE 
					(lp.deleted is null or lp.deleted = 0)
			";

			if($id_propostas){
				$query .= " and lp.id_propostas = '$id_propostas'";
			}

			if($codigo_produto){
				$query .= " and p.codigo = '$codigo_produto'";
			}
			$query .= " ORDER BY lp.id DESC";
			$exe = $this->db->exec($query);
			if($exe){
				return $exe;
			}else{
				return false;
			}
		}

		function getLpId($id_lp = null, $id_propostas = null, $cod_produto = null, $cod_modulo = null){
			$query = "
			SELECT
				* 
			FROM 
				lp_propostas 
			WHERE 
				(deleted is null OR deleted = 0)";

			if($id_lp){
				$query .= " and id = $id_lp";
			}

			if($id_propostas){
				$query .= " and id_propostas = $id_propostas";
			}

			if($cod_produto){
				$query .= " and cod_produto = '$cod_produto'";
			}

			if($cod_modulo){
				$query .= " and cod_modulo = '$cod_modulo'";
			}

			$query .= " ORDER BY id DESC";
			return $this->db->exec($query);
		}

		function getLpPadraoExcluida($id_proposta = null){
			$query = " select * from lp_propostas as lp";
			$query .=	" INNER JOIN modulos_tarifaveis AS mt ON (lp.id_produto = mt.id_produto) where lp.id_modulo = mt.id";
			$query .= " and lp.id_propostas = '$id_proposta'";
			$query .= " and lp.editavel = 1 and lp.padrao = 0 and lp.deleted = 1";
			$query .= " and lp.id_produto = 22 and lp.id_modulo in(103, 107)";
			$exe = $this->db->exec($query);
			if($exe){
				return $exe;
			}else{
				return false;
			}
		}

		function getLpPropostaByModuloProposta($id_propostas = null, $id_modulo = null){
			$query = "select * from lp_propostas"; 
			if($id_propostas){
				$query .= " where id_propostas = '$id_propostas'";
			}
			if($id_modulo){
				
				$query .= " and id_modulo = '$id_modulo'";
			
			}
			$query .= " order by qtd_de";

			$exe = $this->db->exec($query);
			if($exe){
				return $exe;
			}else{
				return false;
			}
		}
		
		function getFullModulo($id_propostas = null, $id_modulo = null){
			$query = "select * from lp_propostas"; 
			if($id_propostas){
				$query .= " where id_propostas = '$id_propostas'";
			}

			if($id_modulo){
				$query .= " and id_modulo = '$id_modulo'";
			}
			$query .= " and deleted = 0";
			$query .= " order by qtd_de";

			$exe = $this->db->exec($query);
			if($exe){
				return $exe;
			}else{
				return false;
			}
		}

		function getLpProposta($id_propostas = null, $id_modulo = null){
			$query = "
			SELECT
				* 
			FROM 
				lp_propostas lp 
			INNER JOIN 
				modulos_tarifaveis mt 
			ON 
				(lp.id_modulo = mt.id)
			WHERE 
				(lp.deleted is null OR lp.deleted = 0)";
			
			if($id_propostas){
				$query .= " and lp.id_propostas = '$id_propostas'";
			}
			if($id_modulo){			
				$query .= " and lp.id_modulo = '$id_modulo'";          
			}
			$query .= " and lp.deleted = 0";
			$query .= " order by lp.qtd_de";
			$exe = $this->db->exec($query);
			if($exe){
				return $exe;
			}else{
				return false;
			}
		}

		function getLpBoletoHibrido($id_produto, $id_modulo){
			$query = "select * from lp_default";

			if($id_produto){
				$query .= " where id_produto = '$id_produto'";
			}

			if($id_modulo){
				$query .= " and id_modulo = '$id_modulo'";
			}

			$query .= " and deleted = 0";
			$query .= " order by id desc";

			
			$exe = $this->db->exec($query);

			if($exe){
				return $exe;
			}else{
				
				return false;
			}

		}

		function getLpByCodigo($codigo_produto = null, $codigo_modulo = null){

			$query = 
			"select 
				p.id, p.nome, p.codigo, ld.qtd_de, ld.qtd_ate, ld.valor_real, 
				ld.id_modulo, mt.codigo as codigo_modulo, mt.descricao 
			from 
				produtos as p
			inner join 
				lp_default as ld
			on 
				p.id = ld.id_produto 
			INNER JOIN 
				modulos_tarifaveis as mt
			on 
				ld.id_modulo = mt.id
			where 
				(p.deleted = 0 or p.deleted is NULL) 
			AND 
				(ld.deleted = 0 or ld.deleted is NULL)";

			if($codigo_produto){
				$query .= " and p.codigo = '$codigo_produto'";
			}

			if($codigo_modulo){
				$query .= " and mt.codigo = '$codigo_modulo'";
			}
			
			if($codigo_modulo){
				$query .= " order by ld.qtd_de asc";
			}else{
				$query .= " order by ld.id_modulo asc";
			}
			return $exe = $this->db->exec($query);;
		}

		function getLpPropostaByCodigo($codigo_produto = null, $codigo_modulo = null, $id_proposta){
			$query = 
			"select 
				p.id, 
				p.nome, 
				p.codigo, 
				lp.qtd_de, 
				lp.qtd_ate, 
				lp.valor_real, 
				lp.id_modulo,
				lp.id_propostas, 
				lp.percentual,
				lp.valor_de,
				lp.valor_ate,
				lp.idade_de,
				lp.idade_ate,
				lp.qtd_licencas,
				lp.frequencia,
				lp.valor_relativo,
				lp.valor_total,
				mt.codigo as codigo_modulo, 
				mt.descricao 
			from 
				produtos as p
			inner join 
				lp_propostas as lp
			on 
				p.id = lp.id_produto 
			INNER JOIN 
				modulos_tarifaveis as mt
			on 
				lp.id_modulo = mt.id
			where 
				(p.deleted = 0 or p.deleted is NULL) 
			AND 
				(lp.deleted = 0 or lp.deleted is NULL)";

			if($codigo_produto){
				$query .= " and p.codigo = '$codigo_produto'";
			}

			if($codigo_modulo){
				$query .= " and mt.codigo = '$codigo_modulo'";
			}

			if($id_proposta){
				$query .= " and lp.id_propostas = '$id_proposta'";
			}		
			
			$query .= " order by lp.qtd_de asc";				
			
			return $exe = $this->db->exec($query);
		}

		function getLpDefault($id_produto, $id_modulo){
			$query = "select * from lp_default where(deleted is null or deleted = 0)";

			if($id_produto){
				$query .= " and id_produto = '$id_produto'";
			}
			if($id_modulo){
				$query .= " and id_modulo = '$id_modulo'";
			}

			$query .= " order by id desc";
			
			$exe = $this->db->exec($query);

			if($exe){
				return $exe;
			}else{
				return false;
			}
		}

		function getLpPropostaByModuloPropostaArray($id_propostas = null, $id_modulo = []){
			$query = "select * from lp_propostas"; 
			if($id_propostas){
				$query .= " where id_propostas = '$id_propostas'";
			}

			if($id_modulo){
				if(count($id_modulo) == 1){
					$id_modulo[0] = str_replace(",", "", $id_modulo[0]);
					$query .= " and id_modulo =" . $id_modulo[0];
				}else{
					$id_modulo = implode($id_modulo);
					$query .= " and id_modulo in($id_modulo)";
				}
			}

			$query .= " order by id_modulo, qtd_de";
			$exe = $this->db->exec($query);
			if($exe){
				return $exe;
			}else{
				return false;
			}
		}

		function getLpPropostaByModuloPropostaArrayZero($id_propostas = null, $id_modulo = []){
			$query = "select * from lp_propostas"; 
			if($id_propostas){
				$query .= " where id_propostas = '$id_propostas'";
			}

			if($id_modulo){
				if(count($id_modulo) == 1){
					$id_modulo[0] = str_replace(",", "", $id_modulo[0]);
					$query .= " and id_modulo !=" . $id_modulo[0];

				}else{

					
					$id_modulo = implode($id_modulo);
												
					$query .= " and id_modulo not in($id_modulo)";
					
				}
			}

			$query .= " order by id_modulo, qtd_de";
			$exe = $this->db->exec($query);
			if($exe){
				return $exe;
			}else{
				return false;
			}
		}

		function getPropostasProdutoModulo($id_propostas = null, $id_produto = null, $id_modulo = null, $order_by = null){
			
			$query = "select * from lp_propostas where (deleted is null or deleted = 0)";

			if($id_propostas){
				$query .= "  and id_propostas = '$id_propostas'";
			}

			if($id_produto){
				$query .= " and id_produto = '$id_produto'";
			}

			if($id_modulo){
				$query .= " and id_modulo = '$id_modulo'";
			}
						
			$query .= " and deleted = 0";
			if($order_by){
				$query .= " order by id_modulo, qtd_de";
			}else{
				$query .= " order by qtd_de";
			}
					
			$exe = $this->db->exec($query);

			if($exe){
				return $exe;
			}else{
				
				return false;
			}

		}

		function getPropostasTextoOk($id_propostas = null, $id_produto = null, $id_modulo = null){
			
			$query = "select * from lp_propostas ";

			if($id_propostas){
				$query .= " where id_propostas = '$id_propostas'";
			}

			if($id_produto){
				$query .= " and id_produto = '$id_produto'";
			}

			if($id_modulo){
				$query .= " and id_modulo = '$id_modulo'";
			}
			
			$query .= " and deleted = 0 and texto_proposta = 1 order by qtd_de, id ";
			$exe = $this->db->exec($query);
			if($exe){
				return $exe;
			}else{
				
				return false;
			}
		}

		function getPropostasTextoOkProdutoNome($id_propostas = null, $id_produto = null, $id_modulo = null){
			
			$query = "select * from lp_propostas as lp 
			inner join modulos_tarifaveis as mt
			on mt.id = lp.id_modulo";

			if($id_propostas){
				$query .= " where lp.id_propostas = '$id_propostas'";
			}

			if($id_produto){
				$query .= " and lp.id_produto = '$id_produto'";
			}

			if($id_modulo){
				$query .= " and lp.id_modulo = '$id_modulo'";
			}
			
			$query .= " and lp.deleted = 0 and lp.texto_proposta = 1 order by lp.qtd_de, lp.id ";
			$exe = $this->db->exec($query);

			if($exe){
				return $exe;
			}else{
				
				return false;
			}

		}

		function getPacoteDefault($id_produto = null, $id_modulo = null, $qtd_garantido = null, $order_by = null, $codigo_modulo = null){
			$query = "
			SELECT 
				pd.id,			
				pd.id_modulos_tarifaveis, 
				pd.qdt_garantido, 
				pd.preco_pkt, 
				pd.status, 
				mt.descricao,
				mt.codigo
			FROM 
				pacote_default as pd 
			INNER JOIN 
				modulos_tarifaveis AS mt 
			ON 
				(pd.id_modulos_tarifaveis = mt.id) 
			where 
				pd.id_produto = mt.id_produto
			and
				pd.deleted = 0";

			if($id_produto){
				$query .= " and pd.id_produto = '$id_produto'";
			}
			if($id_modulo){
				$query .= " and pd.id_modulos_tarifaveis = '$id_modulo'";
			}
			if($qtd_garantido){
				$query .= " and pd.qdt_garantido = '$qtd_garantido'"; 
			}

			if($codigo_modulo){
				$query .= " and mt.codigo = '$codigo_modulo'";
			}	
					
			if($order_by === true){
				$query .=  "order by pd.id desc ";
			}else{
				$query .= " order by pd.qdt_garantido ";
			}

			$exe = $this->db->exec($query);

			if($exe){
				return $exe;
			}else{
				return false;
			}


		}

		function getPacoteById($id_pacote = null){

			$query = " select pd.id, pd.id_produto, pd.id_modulos_tarifaveis, pd.qdt_garantido, pd.preco_pkt, pd.status, mt.descricao 
			from pacote_default as pd 
			INNER JOIN modulos_tarifaveis AS mt 
			ON pd.id_modulos_tarifaveis = mt.id AND pd.id_produto = mt.id_produto";

			if($id_pacote){
				$query .= " where pd.id = '$id_pacote'"; 
			}

			$exe = $this->db->exec($query);

			if($exe){
				return $exe;
			}else{
				return false;
			}

		}	

		function getLpPropostasDefault($id_propostas = null, $id_produto = null, $id_modulo = null){

			$query = "select * from lp_propostas ";

			if($id_propostas){
				$query .= " where id_propostas = '$id_propostas'";
			}
			if($id_produto){
				$query .= " and id_produto = '$id_produto'";
			}
			if($id_modulo){
				$query .= " and id_modulo = '$id_modulo'";
			}
			
			$query .= " and deleted = 0";
			$query .= " and padrao = 1";

			$query .= " order by id desc";

			$exe = $this->db->exec($query);

			if($exe){
				return $exe;
			}else{
				
				return false;
				
			}

		}

		function getLpForaPadrao($id_proposta){

			$query = "select * from lp_propostas AS lp
			INNER JOIN modulos_tarifaveis AS mt 
			ON (lp.id_produto = mt.id_produto)
			where lp.id_modulo = mt.id and lp.padrao = 1";

			if($id_proposta){

				$query .= " and lp.id_propostas = '$id_proposta'";

			}

			$query .= " and lp.deleted = 0";
			$query .= " and lp.padrao = 1";
			
			$exe = $this->db->exec($query);

			if($exe){
				return $exe;
			}else{
				
				return false;
				
			}


		}

		function getLpPropostasDefaultDeletada($id_propostas = null, $id_produto = null, $id_modulo = null){

			$query = "select * from lp_propostas ";

			if($id_propostas){
				$query .= " where id_propostas = '$id_propostas'";
			}
			if($id_produto){
				$query .= " and id_produto = '$id_produto'";
			}
			if($id_modulo){
				$query .= " and id_modulo = '$id_modulo'";
			}
			
			$query .= " and deleted = 1";
			$query .= " and padrao = 0";

			$query .= " order by id desc";

			$exe = $this->db->exec($query);

			if($exe){
				return $exe;
			}else{
				
				return false;
				
			}

		}

		function getPacotePropostas($id_propostas = null, $id_produto = null, $id_modulo = null, $id_pacote_proposta = null, $not_modulo = null){		
			$query = "
			SELECT 
				* 
			FROM 
				pacote_propostas
			WHERE
				(deleted is null OR deleted = 0)";

			if($id_propostas){
				$query .= " and id_propostas = '$id_propostas'";
			}
			if($id_produto){
				$query .= " and id_produto = '$id_produto'";
			}
			if($id_modulo){

				if($not_modulo === true){
					$query .= " and id_modulos_tarifaveis != '$id_modulo'";
				}else{
					$query .= " and id_modulos_tarifaveis = '$id_modulo'";
				}
				
			}
			if($id_pacote_proposta){
				$query .= " and id = '$id_pacote_proposta'";
			}
			
			if($not_modulo === true){
				$query .= " order by modulo desc";
			}else{
				if($not_modulo === "ASC"){
					$query .= " order by id asc";
				}else{
					$query .= " order by id desc";
				}
			}
			return $this->db->exec($query);
		}

		function getPacotePropostasEditada($id_propostas = null){
			$query = "
			SELECT 
			* 
			FROM 
				pacote_propostas
			WHERE
				(deleted is null OR deleted = 0)
			AND
				flag = 1";

			if($id_propostas){
				$query .= " and id_propostas = '$id_propostas'";
			}				
			$query .= " order by id desc";
			
			return $this->db->exec($query);
		}

		function getPacotePropostasPadrao($id_proposta = null, $deleted = false){
			
			$query = "select * from pacote_propostas ";

			if($id_proposta){
				$query .= " where id_propostas = '$id_proposta'";
			}
			
			if($deleted == false){
				$query .= " and deleted = 0";
			}else{
				$query .= " and deleted = 1";
			}
			
			$query .= " and flag = 'SD' order by id desc ";
			$exe = $this->db->exec($query);
			if($exe){
				return $exe;
			}else{
				return false;
			}

		}

		function getPacoteOpcional($codigo_produto){
			$query = "select * from pacote_opcional where (deleted is null or deleted = 0 )";

			if($codigo_modulo){
				$query .= " and cod_produto = '$codigo_modulo'";
			}

			$query .= " order by id asc";

			return $exe = $this->db->exec($query);

		}

		function getIdModulo($descricao = null){
			
			$query = "select * from modulos_tarifaveis";

			if($descricao){
				$query .= " where descricao = '$descricao'";
			}

			$query .= " and empacotavel = 1";

			$exe = $this->db->exec($query);

			if($exe){
				return $exe;
			}else{
				return false;
			}

		}

		function getModuloByProduto($id_produto = null){
			
			$query = "select * from modulos_tarifaveis where (deleted is null or deleted = 0) and status = 'ativo'";

			if($id_produto){
				$query .= " and id_produto = '$id_produto'";
			}

			//$query .= " and empacotavel = 1";

			$exe = $this->db->exec($query);

			if($exe){
				return $exe;
			}else{
				return false;
			}

		}

		function empresaVendedora($id_empresa = null,$empresa_vendedora = true){
			$query = "
			SELECT 
				* 
			FROM 
				empresa_vendedora
			WHERE
				(deleted = 0 OR deleted = null)";

			if($id_empresa){
				$query .= " and id = $id_empresa";
			}

			if($empresa_vendedora){
				$query .= " and empresa_vendedora = '0'";
			}


			
			return $this->db->exec($query);
		}

		function produtos($id_produto){

			$query = "select * from produtos";

			if($id_produto){
				$query .= " where id = '$id_produto'";
			}

			$exe = $this->db->exec($query);

			if($exe){
				return $exe;
			}else{
				return false;
			}

		}

		function getPropostasModuloByIdProposta($id_proposta = null, $cod_modulo = null, $deleted = null){
			$query = "
				SELECT 
					* 
				FROM 
					propostas_modulo
				WHERE
					(deleted is null OR deleted = 0 OR deleted = 1)
			";

			if($id_proposta){
				$query .= " and id_propostas = '$id_proposta'";
			}

			if($cod_modulo){
				$query .= "and cod_modulo = '$cod_modulo'";
			}

			if($deleted){
				$query .= "and deleted = '$deleted'";
			}
			return $this->db->exec($query);		
		}

		function gedDocumento($id_origem){		
			$query = "select * from ged_documento  where (deleted is null or deleted = 0) and doc_origem = 'proposta'";
			if($id_origem){
				$query .= " and id_origem = '$id_origem'";
			}
			
			$exe = $this->db->exec($query);

			if($exe){
				return $exe;
			}else{
				return false;
			}

		}

		function gedDocumentoAnexo($id_origem){
			
			$query = "select gd.id as id_ged_documento, gd.nome_documento, gd.data_documento, gd.doc_origem, gd.id_origem , gd.produto, gd.tipo, gd.subtipo, gd.owner, gd.data_criacao as data_criacao_documento,
			ga.id as id_ged_anexo, ga.id_documento, ga.nome_amigavel, ga.path_root, ga.path_objeto, ga.nome_hash, ga.hash_arquivo, ga.data_criacao as data_criacao_anexo
					
			from ged_documento as gd
			INNER JOIN ged_anexo AS ga
			ON (gd.id = ga.id_documento ) where (gd.deleted is null or gd.deleted = 0) and gd.doc_origem = 'proposta'";

			if($id_origem){
				$query .= " and gd.id_origem = '$id_origem'";
			}		

			return $this->db->exec($query);
		}

		function getPropostaProduto($id_proposta){
			$query = 
				"select 
					p.id, p.cnpj_cpf, p.cliente, p.empresa, p.email, p.data_criacao, p.status, p.id_owner, p.id_produto, 
					p.propostas_finalizada, p.proposta_fora_padrao, pro.codigo, pro.descricao, pro.status
				from 
					propostas AS p
				INNER JOIN 
					produtos AS pro
				ON 
					p.id_produto = pro.id
				WHERE 
					(p.deleted IS NULL OR p.deleted = 0)";
			if($id_proposta){
				$query .= " and p.id = '$id_proposta'";
			}
			return $exe = $this->db->exec($query);
		}

		function getProduto( $id_produto = null ){
			$query = "
				SELECT
					*
				FROM
					produtos
				WHERE
					(deleted is null or deleted = 0)
			";
			if( !empty( $id_produto) && is_numeric( $id_produto ) ){
				$query .= " and id = $id_produto ";
			}
			return $exe = $this->db->exec($query);
		}
		
		//By: Caio Freitas 01/07/2022
		function getContato($id = null, $id_contrato = null, $tipo_contato = null, $origem = null){
			$query = "
				SELECT
					*			
				FROM
					if_contato
				WHERE
					(deleted is null or deleted = 0)
			";

			if($id){
				$query .= " and id = '$id'";
			}

			if($id_contrato){
				$query .= " and id_contrato = '$id_contrato'";
			}

			if($tipo_contato){
				$query .= " and tipo_contato = '$tipo_contato'";
			}

			if($origem){
				$query .= " and origem = '$origem'";
			}

			$query .= " order by id asc";
			
			return $exe = $this->db->exec($query);
		}

		//By: Caio Freitas 06/07/2022
		function getIfContrato($id_contrato = null, $id_proposta = null){
			$query = "
				SELECT 
					ico.*,
					pro.id_cm id_empresa
				FROM
					if_contrato ico inner join 
					propostas pro on( pro.id = ico.id_proposta ) inner join
					empresa_vendedora ev on( pro.id_cm = ev.id ) 
				WHERE
					( ico.deleted is null or ico.deleted = 0 )
			";

			if($id_contrato){
				$query .= " and ico.id = $id_contrato";
			}

			if($id_proposta){
				$query .= " and ico.id_proposta = $id_proposta";
			}
			$query .= " ORDER BY ico.id ASC";
			return $exe = $this->db->exec($query);
		}

		//By: Caio Freitas 06/07/2022
		function getIfEndereco($id_contrato = null, $id_endereco = null){
			$query = "
				SELECT 
					*
				FROM
					if_endereco
				WHERE
					(deleted is null or deleted = 0)
			";

			if($id_contrato){
				$query .= " and id_contrato = $id_contrato";
			}

			if($id_endereco){
				$query .= " and id = $id_endereco";
			}

			$query .= " ORDER BY id ASC";

			return $exe = $this->db->exec($query);
		}
		
		function getIfContato( $id_contrato = null, $origem) {
			$query = "
				SELECT 
					*
				FROM
					if_contato
				WHERE
					(deleted is null or deleted = 0)
			";

			if( $id_contrato ){
				$query .= " and id_contrato = $id_contrato";
			}

			if( $origem ){
				$query .= " and origem = '$origem'";
			}

			$query .= " ORDER BY id ASC";
			return $exe = $this->db->exec($query);
		}

		function getInstrucaofaturamento($id_contrato = null){
			$query = "
				SELECT 
					iff.*
				FROM
					if_faturamento iff
				WHERE
					(deleted is null or deleted = 0)";

			if($id_contrato){
				$query .= " and id_contrato = $id_contrato";
			}
			$query .= " ORDER BY id ASC";
			return $exe = $this->db->exec($query);
		}
		
		function getIfComissao($id_contrato = null, $perfil_usuario = null, $id_usuario = null){
			$query = "
				SELECT 
					cp.nome, 
					cp.descricao,
					cpus.id_perfil, 
					cpus.id_usuario, 
					cpus.id as id_perfil_usuario, 
					cpus.id_contrato, 
					cpus.data_criacao,
					cpus.data_validade,
					cr.id as id_regra,
					cr.objeto_regra,
					cr.comparador,
					cr.valor,
					cc.objeto,
					cc.tipo_valor,
					cc.valor_comissao,
					cc.id as id_comissao_cadastro,
					ut.nome as nome_usuario 
				FROM 
					comissoes_perfil cp 
				INNER JOIN 
					comissoes_perfil_usuario cpus 
				ON 
					(cpus.id_perfil = cp.id) 
				INNER JOIN 
					comissoes_regras cr 
				ON 
					(cr.id_perfil = cp.id) 
				INNER JOIN 
					comissoes_cadastro cc 
				ON 
					(cc.id_regra = cr.id) 
				INNER JOIN 
					sistema_usuarios ut 
				ON 
					(cpus.id_usuario = ut.id) 
				WHERE 
					(cpus.deleted is null or cpus.deleted = 0)
			";

			if($id_contrato){
				$query .= " and cpus.id_contrato = $id_contrato";
			}

			if($perfil_usuario){
				$query .= " and cpus.id = $perfil_usuario";
			}

			if($id_usuario){
				$query .= " and cpus.id_usuario = $id_usuario";
			}
			$query .= " ORDER BY cpus.id ASC";
			return $exe = $this->db->exec($query);
		}

		//By: Caio Freitas 06/07/2022
		function getPerfilComissao(){
			$query = "
			SELECT 
				*
			FROM
				comissoes_perfil
			WHERE
				(deleted is null or deleted = 0)
			";

			$query .= " ORDER BY id ASC";

			return $exe = $this->db->exec($query);
		}

		//By: Caio Freitas 19/07/2022

		function fluxoOrdemAprovacao( $id_usuario = null, $objeto = null, $id_empresa = null ){
			$query = "
				SELECT
					fo.*,
					ut.nome,
					p.nome as nome_perfil
				FROM
					fluxo_ordem_aprovacao fo INNER JOIN 
					sistema_usuarios ut ON (ut.id = fo.id_usuario) INNER JOIN
					perfis p ON (ut.id_perfil = p.id)
				WHERE
					(fo.deleted is null or fo.deleted = 0) 
			";
			
			if( $id_usuario ){
				$query .= " and fo.id_usuario = $id_usuario";
			}

			if( $objeto ){
				$query .= " and fo.objeto = '$objeto'";
			}

			if( $id_empresa ){
				$query .= " and fo.id_empresa = '$id_empresa'";
			}
			$query .= " ORDER BY fo.ordem ASC";
			return $exe = $this->db->exec($query);
		}

		//By: Caio Freitas 19/07/2022
		function fluxoStatusAprovacao($objeto = null, $id_objeto = null, $id_ordem_aprovacao = null, $status = null){
			$query = "
				SELECT 
					fs.*,
					fo.ordem		
				FROM
					fluxo_status_aprovacao fs	
				INNER JOIN
					fluxo_ordem_aprovacao fo
				ON
					(fo.id = fs.id_ordem_aprovacao)	
				WHERE
					(fs.deleted is null or fs.deleted = 0)
				AND
					(fo.deleted is NULL OR fo.deleted = 0)
			";

			if($objeto){
				$query .= " and fs.objeto = '$objeto'";
			}

			if($id_objeto){
				$query .= " and fs.id_objeto = $id_objeto";
			}

			if($id_ordem_aprovacao){
				$query .= " and fs.id_ordem_aprovacao = $id_ordem_aprovacao";
			}

			if($status){
				$query .= " and fs.status = $status";
			}
			$query .= " ORDER BY fs.id ASC";
			return $exe = $this->db->exec($query);
		}
		
		//By: Caio Freitas 19/07/2022
		function allFluxoAprovacao($objeto = null, $id_objeto = null, $id_ordem_aprovacao = null, $order = false, $ordem_aprovacao = null){
			$query = "
				SELECT
					fs.id, 
					fs.id_ordem_aprovacao,
					fs.id_objeto,
					fs.objeto,
					fs.status,
					fo.id_usuario,
					fo.ordem,
					ut.nome,
					p.nome as nome_perfil
				FROM
					fluxo_status_aprovacao fs
				INNER JOIN
					fluxo_ordem_aprovacao fo
				ON
					(fs.id_ordem_aprovacao = fo.id)		
				INNER JOIN
					sistema_usuarios ut
				ON
					(fo.id_usuario = ut.id)	
				INNER JOIN
					perfis p
				ON
					(ut.id_perfil = p.id)			
				WHERE
					(fs.deleted is null or fs.deleted = 0)
			";

			if($objeto){
				$query .= " and fs.objeto = '$objeto'";
			}

			if($id_objeto){
				$query .= " and fs.id_objeto = $id_objeto";
			}
			
			if($id_ordem_aprovacao){
				$query .= " and fs.id_ordem_aprovacao = $id_ordem_aprovacao";
			}

			if($ordem_aprovacao){
				$query .= " and fo.ordem = $ordem_aprovacao";
			}

			if($order === false){
				$query .= " ORDER BY fo.ordem ASC";
			}else{
				$query .= " ORDER BY fo.ordem DESC";
			}
			return $exe = $this->db->exec($query);
		}
		
		//By: Caio Freitas 02/08/2022
		function getTextoMinuta($id_contrato){
			$query = "
				SELECT 
					*
				FROM
					minuta_contrato				
				WHERE
					(deleted is null or deleted = 0)
			";

			if($id_contrato){
				$query .= " and id_contrato = $id_contrato";
			}
			$query .= " order by pagina asc";
			return $exe = $this->db->exec($query);
		}
		
		function gedClicksign($id_ged = null, $id_doc = null, $plataforma = null, $origem = null, $key_documento = null){
			$query = "
			SELECT 
				gc.*,
				ga.nome_amigavel,
				ga.id as id_ged_anexo,
				gd.id_origem,
				ga.data_criacao
			FROM
				ged_clicksign_documento gc
			INNER JOIN
				ged_anexo ga
			ON
				(gc.id_ged_anexo = ga.id)		
			INNER JOIN
				ged_documento gd
			ON
				(ga.id_documento = gd.id)	
			WHERE 
				(gc.deleted is null OR gc.deleted = 0)";

			if($id_ged){
				$query .= " and gc.id_ged_anexo = '$id_ged'";
			}		
			if($id_doc){
				$query .= " and gd.id_origem = $id_doc";
			}
			if($plataforma){
				$query .= " and gc.plataforma = '$plataforma'";
			}
			if($origem){
				$query .= " and gd.doc_origem = '$origem'";
			}
			if($key_documento){
				$query .= " and gc.document_key = '$key_documento'";
			}
			$query .= " order by gc.id desc";
			return $this->db->exec($query);
		}

		function gedClicksignCliente($key_documento = null){
			$query = "
				SELECT 
					gc.*,
					ga.nome_amigavel,
					ga.id as id_ged_anexo,
					gd.id_origem,
					ga.data_criacao,
					ic.razao_social,
					ic.nome_fantasia,
					ic.cnpj,
					ic.id as id_contrato,
					ic.id_proposta
				FROM
					ged_clicksign_documento gc
				INNER JOIN
					ged_anexo ga
				ON
					(gc.id_ged_anexo = ga.id)		
				INNER JOIN
					ged_documento gd
				ON
					(ga.id_documento = gd.id)	
				INNER JOIN
					if_contrato ic
				ON
					(gd.id_origem = ic.id)
				WHERE 
					(gc.deleted is null OR gc.deleted = 0)
			";
			if($key_documento){
				$query .= " and gc.document_key = '$key_documento'";
			}
			$query .= " order by gc.id desc";
			return $this->db->exec($query);
		}

		function gedClicksignAssinaturaWebhook($key_documento = null, $status = null){
			$query = "
			SELECT 
				gca.*,		
				c.email AS email_contato,
				c.nome,
				c.tipo_contato,
				c.id_contrato,
				ic.id_proposta
			FROM
				ged_clicksign_assinatura gca	
			INNER JOIN
				if_contato c
			ON
				(gca.id_usuario = c.id)	
			INNER JOIN
				if_contrato ic
			ON
				(ic.id = c.id_contrato)
			WHERE 
				(gca.deleted is null OR gca.deleted = 0)";
			
			if($key_documento){
				$query .= " and gca.key_documento = '$key_documento'";
			}

			if($status){
				$query .= " and gca.status = '$status'";
			}
			$query .= " order by gca.ordem_assinatura asc";
			return $this->db->exec($query);
		}

		function gedClicksignAssinatura($plataforma = null, $key_usuario = null, $id_anexo = null){
			$query = "
			SELECT 
				*
			FROM
				ged_clicksign_assinatura 		
			WHERE 
				(deleted is null OR deleted = 0)";

			if($plataforma){
				$query .= " and plataforma = '$plataforma'";
			}	
			
			if($key_usuario){
				$query .= " and key_usuario = '$key_usuario'";
			}
			
			if($id_anexo){
				$query .= " and id_ged_anexo = $id_anexo";
			}

			$query .= " order by ordem_assinatura asc";
			return $this->db->exec($query);
		}

		function gedUserClicksignAssinatura($plataforma = null, $key_usuario = null, $id_anexo = null){
			$query = "
			SELECT 
				gca.*,
				c.nome,
				c.email,
				c.telefone,
				c.cargo_setor,
				c.tipo_contato
			FROM
				ged_clicksign_assinatura gca
			INNER JOIN
				if_contato c
			ON
				(gca.id_usuario = c.id)
			WHERE 
				(gca.deleted is null OR gca.deleted = 0)";

			if($plataforma){
				$query .= " and gca.plataforma = '$plataforma'";
			}	
			
			if($key_usuario){
				$query .= " and gca.key_usuario = '$key_usuario'";
			}
			
			if($id_anexo){
				$query .= " and gca.id_ged_anexo = $id_anexo";
			}

			$query .= " order by gca.ordem_assinatura asc";
			return $this->db->exec($query);
		}

		function getOrdemAssinaturaClicksign($id_ged_anexo = null){
			$query = "
			SELECT
				gca.id_ged_anexo,
				gca.id_usuario,
				gca.plataforma,
				gca.key_usuario,
				gca.key_documento,
				gca.assinar_como,
				gca.ordem_assinatura,
				gca.assinado,
				gca.status,
				c.id_contrato,
				c.origem,
				c.cpf,
				c.nome,
				c.email,
				c.telefone,
				c.cargo_setor,
				c.tipo_contato		
			FROM
				ged_clicksign_assinatura gca
			INNER JOIN
				if_contato c
			ON
				(gca.id_usuario = c.id)
			WHERE
				(gca.deleted is null OR gca.deleted = 0)";

			if($id_ged_anexo){
				$query .= " and gca.id_ged_anexo = $id_ged_anexo";
			}
			$query .= " order by gca.ordem_assinatura ASC";
			return $this->db->exec($query);
		}

		function getFullMinuta($id_contrato = null, $codigo_produto = null){
			$query = "
			SELECT
				ctt.id,
				ctt.id_proposta,
				ctt.numero_contrato,
				ctt.status,
				ctt.razao_social,
				ctt.nome_fantasia,
				ctt.cnpj,
				ctt.segmento,
				ctt.id_produto,
				ctt.codigo_cliente,
				ctt.site,
				ctt.obs_contrato,
				ctt.finalizado,
				ctt.id_contrato,			
				e.cep,
				e.endereco,
				e.numero,
				e.bairro,
				e.cidade,
				e.estado,
				e.complemento,
				e.tipo_endereco,
				con.nome,
				con.email,
				con.telefone,
				con.cargo_setor,
				con.tipo_contato,
				con.cpf,
				f.id as id_faturamento,
				f.empresa_vendedora,
				f.data_assinatura,
				f.data_reajuste,
				f.duracao_contrato,
				f.renovacao_automatica,
				f.indeterminado,
				f.reajuste,
				f.moeda,
				f.preco_imposto,
				f.implantacao,
				f.parcelas,
				f.primeira_parcela,
				f.faturamento_todo_dia,
				f.tipo_data_faturamento,
				f.vencimento_todo_dia,
				f.dias_apos_faturamento,
				f.data_primeiro_faturamento,
				f.data_producao,
				f.vinculado_producao,
				f.hospedagem,
				f.licenca,
				f.percentual_multa,
				f.percentual_juros,
				p.codigo,
				p.nome as nome_produto
			FROM
				if_contrato ctt
			INNER JOIN
				if_endereco e
			ON
				(ctt.id = e.id_contrato)
			INNER JOIN
				if_contato con
			ON
				(ctt.id = con.id_contrato)
			INNER JOIN
				if_faturamento f
			ON
				(ctt.id = f.id_contrato)
			INNER JOIN
				produtos p
			ON
				(ctt.id_produto = p.id)
			WHERE
				(ctt.deleted is null OR ctt.deleted = 0)";

			if($id_contrato){
				$query .= " and ctt.id = $id_contrato";
			}

			if($codigo_produto){
				$query .= " and p.codigo = '$codigo_produto'";
			}
			return $exe = $this->db->exec($query);
		}

		function getMinuta($id_contrato = null, $codigo_produto = null){
			$query = "
				SELECT
					ctt.id,
					ctt.id_proposta,
					ctt.numero_contrato,
					ctt.status,
					ctt.razao_social,
					ctt.nome_fantasia,
					ctt.cnpj,
					ctt.segmento,
					ctt.id_produto,
					ctt.codigo_cliente,
					ctt.site,
					ctt.obs_contrato,
					ctt.finalizado,
					ctt.id_contrato,			
					e.cep,
					e.endereco,
					e.numero,
					e.bairro,
					e.cidade,
					e.estado,
					e.complemento,
					e.tipo_endereco,			
					f.id as id_faturamento,
					f.empresa_vendedora,
					f.data_assinatura,
					f.data_reajuste,
					f.duracao_contrato,
					f.renovacao_automatica,
					f.indeterminado,
					f.reajuste,
					f.moeda,
					f.preco_imposto,
					f.implantacao,
					f.parcelas,
					f.primeira_parcela,
					f.faturamento_todo_dia,
					f.tipo_data_faturamento,
					f.vencimento_todo_dia,
					f.dias_apos_faturamento,
					f.data_primeiro_faturamento,
					f.data_producao,
					f.vinculado_producao,
					f.hospedagem,
					f.licenca,
					f.percentual_multa,
					f.percentual_juros,
					p.codigo,
					p.nome as nome_produto
				FROM
					if_contrato ctt
				INNER JOIN
					if_endereco e
				ON
					(ctt.id = e.id_contrato)		
				INNER JOIN
					if_faturamento f
				ON
					(ctt.id = f.id_contrato)
				INNER JOIN
					produtos p
				ON
					(ctt.id_produto = p.id)
				WHERE
					(ctt.deleted is null OR ctt.deleted = 0)
			";

			if($id_contrato){
				$query .= " and ctt.id = $id_contrato";
			}

			if($codigo_produto){
				$query .= " and p.codigo = '$codigo_produto'";
			}
			return $exe = $this->db->exec($query);
		}

		//By: Caio Freitas 06/07/2022
		function getContratoProposta( $id_contrato = null, $id_proposta = null ){
			$query = "
				SELECT 
					c.*,
					p.id_cm,
					p.id as id_proposta,
					p.cnpj_cpf,
					p.cliente,
					p.empresa,
					p.email,
					p.data_criacao,
					p.status,
					p.id_owner,
					p.proposta_fora_padrao,
					pr.codigo,
					pr.codigo codigo_produto,
					ut.email as email_owner 
				FROM
					if_contrato c
				INNER JOIN
					propostas p
				ON
					(p.id = c.id_proposta)
				INNER JOIN
					produtos pr
				ON
					(pr.id = p.id_produto)	
				INNER JOIN
					sistema_usuarios ut
				ON
					(ut.id = p.id_owner)		
				WHERE
					(c.deleted is null or c.deleted = 0)
			";

			if($id_contrato){
				$query .= " and c.id = $id_contrato";
			}

			if($id_proposta){
				$query .= " and c.id_proposta = $id_proposta";
			}

			$query .= " ORDER BY c.id ASC";
			return $exe = $this->db->exec($query);
		}

		function getIfContratoCrystal( $id_contrato = null, $cnpj = null ){
			$query = "
				SELECT 
					c.*,
					c.cnpj as cnpj_cpf,
					c.razao_social as cliente,
					pr.codigo			
				FROM
					if_contrato c		
				INNER JOIN
					produtos pr
				ON
					(pr.id = c.id_produto)				
				WHERE
					(c.deleted is null or c.deleted = 0)
			";

			if($id_contrato){
				$query .= " and c.id = $id_contrato";
			}

			if($cnpj){
				$query .= " and c.cnpj = '$cnpj'";
			}
			$query .= " ORDER BY c.id ASC";
			return $exe = $this->db->exec($query);
		}

		function getContatoSign( $origem = null, $id_objeto = null, $id_contato = null, $status = null ){
			$query = "
				SELECT 
					ico.*,
					ev.id id_cm,
					ev.razao_social nome_cm
				FROM
					if_contato ico inner join
					empresa_vendedora ev on(ev.id = ico.id_cm )
				WHERE 
					( ico.deleted is null OR ico.deleted = 0)
			";

			if($origem){
				$query .= " and origem = '$origem'";
			}

			if($id_objeto){
				$query .= " and id_contrato = $id_objeto";
			}

			if($id_contato){
				$query .= " and id = $id_contato";
			}

			if( isset( $status ) && $status == true ){
				$query .= " and ico.status = 0";
			}else if( $status && $status == false ){
				$query .= " and ico.status = 1";
			}
			$query .= " order by ico.id asc";
			return $this->db->exec($query);
		}

		public function getUsuarios($id_usuario = null, $id_boss = null, $cpf = null, $departamento = null){
			$query ="
			select 
				* 
			from 
				sistema_usuarios  
			where status = 'ativo'";
			if($id_usuario){
				$query .= " and id = '$id_usuario'";
			}
			if($id_boss){
				$query .= " and (boss = '$id_boss' or id = '$id_boss')";
			}
			if($cpf){
				$query .= " and cpf = '$cpf'";
			}
			if($departamento){
				$query .= "and departamento = '$departamento'";
			}
			$query .= " order by nome asc";
			return $this->db->exec($query);        
		}

		//By Caio Freitas - 04/08/2022
		function gedDocumento2($doc_origem, $id_origem){
			$query = "
			SELECT 
				* 
			FROM 
				ged_documento  
			WHERE
				(deleted is null or deleted = 0)"; 
			
			if($doc_origem){
				$query .= " and doc_origem = '$doc_origem'";
			}

			if($id_origem){
				$query .= " and id_origem = $id_origem";
			}
			return $exe = $this->db->exec($query);	
		}

		function gedDocumentoAnexo2($id_origem = null, $doc_origem = null){
			$query = "
			SELECT 
				gd.id as id_ged_documento, 
				gd.nome_documento, 
				gd.data_documento, 
				gd.doc_origem, 
				gd.id_origem , 
				gd.produto, 
				gd.tipo, 
				gd.subtipo, 
				gd.owner, 
				gd.data_criacao as data_criacao_documento,
				ga.id as id_ged_anexo, 
				ga.id_documento, 
				ga.nome_amigavel, 
				ga.path_root, 
				ga.path_objeto, 
				ga.nome_hash, 
				ga.hash_arquivo, 
				ga.data_criacao as data_criacao_anexo				
			FROM
				ged_documento as gd
			INNER JOIN 
				ged_anexo AS ga
			ON 
				(gd.id = ga.id_documento ) 
			WHERE
				(gd.deleted is null or gd.deleted = 0)"; 
			

			if($id_origem){
				$query .= " and gd.id_origem = $id_origem";
			}	

			if($doc_origem){
				$query .= " and gd.doc_origem = '$doc_origem'";
			}
			return $this->db->exec($query);		
		}

		function gedDocumentoAnexoIf($id_origem, $doc_origem){
			$query = "
			SELECT 
				gd.id as id_ged_documento, 
				gd.nome_documento, 
				gd.data_documento, 
				gd.doc_origem, 
				gd.id_origem , 
				gd.produto, 
				gd.tipo, 
				gd.subtipo, 
				gd.owner, 
				gd.data_criacao as data_criacao_documento,
				ga.id as id_ged_anexo, 
				ga.id_documento, 
				ga.nome_amigavel, 
				ga.path_root, 
				ga.path_objeto, 
				ga.nome_hash, 
				ga.hash_arquivo, 
				ga.data_criacao as data_criacao_anexo,
				c.cnpj as cpf_owner		
			FROM
				ged_documento as gd
			INNER JOIN 
				ged_anexo AS ga
			ON 
				(gd.id = ga.id_documento) 
			INNER JOIN 
				if_contrato c
			ON
				(c.id = gd.id_origem)
			"; 		

			if($id_origem){
				$query .= " and gd.id_origem = '$id_origem'";
			}	

			if($doc_origem){
				$query .= " and gd.doc_origem = '$doc_origem'";
			}

			return $this->db->exec($query);		

		}

		//By Caio Freitas - 04/08/2022
		function getEmpresaVendedora($id_empresa = null, $nome_fantasia = null){
			$query = "
			SELECT
				*
			FROM
				empresa_vendedora
			WHERE 
				(deleted = 0 or deleted is null)";

			if($id_empresa){
				$query .= " and id = $id_empresa";
			}
			if($nome_fantasia){
				$query .= " and nome_fantasia = '$nome_fantasia'";
			}

			return $this->db->exec($query);
		}

		function getContratos($codigo_cliente = null, $id_contrato = null){
			$query = "
			SELECT
				*
			FROM
				contratos
			WHERE 
				(deleted = 0 or deleted is null)";

			if($codigo_cliente){
				$query .= " and numero_contrato = $codigo_cliente";
			}
			if($id_contrato){
				$query .= " and id = $id_contrato";
			}
			// if($id_contrato){
			// 	$query .= " and id_contrato = $id_contrato";
			// }		

			return $this->db->exec($query);
		}

		function getContaBancaria($id_empresa = null){
			$query = "
			SELECT
				*
			FROM
				conta_bancaria
			WHERE 
				(deleted = 0 or deleted is null)";

			if($id_empresa){
				$query .= " and id_empresa = $id_empresa";
			}	

			return $this->db->exec($query);
		}

		//By Caio Freitas - 21/10/2022
		public function getUsuariosPerfil($id_usuario = null, $perfil = null){
			$query ="
				select
					u.*,
					p.nome as perfil,
					p.permissoes,
					p.owner,
					p.status as status_perfil
				from 
					sistema_usuarios u
				inner join
					perfis p
				on
					(u.id_perfil = p.id)
				where 
					u.status = 'ativo'
			";
			if($id_usuario){
				$query .= " and u.id = '$id_usuario'";
			}        
			if($perfil){
				$contador = 0;
				if(is_array($perfil)){				
					$query .= " and p.nome in ( ";
					foreach ($perfil as $key => $value) {
						if($contador == 0){
							$query .= "'$value'";
						}else{
							$query .= ", '$value'";
						}
						$contador++;
					}
					$query .= " )";
				}else{
					$query .= " and p.nome = '$perfil'";
				}
			}
			$query .= " order by u.nome asc";
			return $this->db->exec($query);        
		}

		public function getPropostasContrato($id_proposta = null, $id_contrato = null){
			$query = "
				SELECT 
					p.id, p.empresa, ut.nome, p.id_owner, p.id_produto, ut.nome as nome_usuario, ut.email as email_usuario, ut.telefone as telefone_usuario,  pf.id_propostas, 
					p.cnpj_cpf, p.cliente, p.data_criacao, p.email,	p.telefone, p.celular, p.cep, p.endereco, p.numero, p.complemento, p.bairro, p.estado, p.cidade, p.status, 
					p.propostas_finalizada, p.alterado_por, p.criado_por, pf.valor_implantacao, pf.numero_parcelas, pf.data_pagamento, pf.data_segundo_pagamento, pf.data_terceiro_pagamento, 
					pf.custo_hora_homem, pro.nome as nome_produto, p.proposta_fora_padrao, pro.codigo, ut.id as id_usuario, ic.id as id_contrato
				from
					propostas AS p 
				INNER JOIN 
					propostas_faturamento AS pf
				ON 
					(p.id = pf.id_propostas)
				INNER JOIN 
					sistema_usuarios AS ut
				ON 
					(p.id_owner = ut.id)	
				INNER JOIN 
					produtos AS pro
				ON 
					(pro.id = p.id_produto)
				INNER JOIN
					if_contrato ic
				ON
					(ic.id_proposta = p.id)		
				WHERE 
					(p.deleted = 0 OR p.deleted = NULL) 
				AND 
					p.propostas_finalizada = 'sim'		 
			";
			
			if($id_proposta){
				$query .= " and p.id = $id_proposta"; 
			}	
			
			if($id_contrato){
				$query .= " and ic.id = $id_contrato"; 
			}
		
			$query .= " and p.propostas_finalizada = 'sim' order by p.id desc";						
			return $exe = $this->db->exec($query);		
		}

		//By Caio Freitas - 29/11/2022
		function getNotaFiscal($id_nota = null){
			$query = "
			SELECT
				*
			FROM
				notas_fiscais
			WHERE
				(deleted is null OR deleted = 0)";
			
			if($id_nota){
				$query .= " and id = $id_nota";
			}
			$query .= " order by id desc";
			return $this->db->exec($query);
		}

		//By Caio Freitas - 29/11/2022
		function getGed($id_contrato = null){
			$query = "
				SELECT
					*
				FROM
					ged
				WHERE
					(deleted is null OR deleted = 0)
			";
			
			if($id_contrato){
				$query .= " and id_contrato = $id_contrato";
			}
			$query .= " order by id desc";
			return $this->db->exec($query);
		}
		
		//By Caio Freitas - 16/12/2022
		function getLpCliente($id_contrato = null){
			$query = "
				SELECT
					*
				FROM
					lp_clientes
				WHERE
					(deleted is null OR deleted = 0)
			";

			if($id_contrato){
				$query .= " and id_contrato = $id_contrato";
			}
			$query .= " order by id desc";
			return $this->db->exec($query);
		}

		function getPacoteCliente($id_contrato = null){
			$query = "
			SELECT
				*
			FROM
				pacote_contratado
			WHERE
				(deleted is null OR deleted = 0)";

			if($id_contrato){
				$query .= " and id_contrato = $id_contrato";
			}

			$query .= " order by id desc";
			return $this->db->exec($query);
		}

		function fluxoMinutaAprovado($ordem){
			$query = "
			SELECT
				ic.id,
				ic.id_proposta,
				ic.id_contrato,
				ic.nome_fantasia,
				ic.cnpj,
				ic.id_produto,
				ic.finalizado,
				iff.id as id_faturamento,
				p.id_owner,			
				ut.nome,
				ut.email,
				fs.objeto,
				fs.status as status_aprovacao,
				fo.ordem,
				gd.doc_origem,
				ga.nome_amigavel,
				ga.path_root,
				ga.path_objeto,
				gcd.id as id_doc,
				gcd.id_ged_anexo,
				gcd.plataforma,
				gcd.document_key,
				gcd.data_upload,
				gcd.status as status_documento,
				gcd.finalizado_em,
				pro.codigo
			FROM
				if_contrato ic
			INNER JOIN 
				produtos AS pro
			ON 
				(pro.id = ic.id_produto)
			INNER JOIN 
				if_faturamento iff
			ON
				(ic.id = iff.id_contrato)
			INNER JOIN
				propostas p
			ON
				(ic.id_proposta = p.id)
			INNER JOIN
				sistema_usuarios ut
			ON
				(p.id_owner = ut.id)
			INNER JOIN
				fluxo_status_aprovacao fs
			ON
				(ic.id = fs.id_objeto)
			INNER JOIN
				fluxo_ordem_aprovacao fo	
			ON
				(fo.id = fs.id_ordem_aprovacao)
			INNER JOIN
				ged_documento gd
			ON
				(ic.id = gd.id_origem)
			INNER JOIN
				ged_anexo ga
			ON
				(gd.id = ga.id_documento)
			INNER JOIN
				ged_clicksign_documento gcd
			ON
				(ga.id = gcd.id_ged_anexo)
			WHERE
				(ic.deleted = 0 OR ic.deleted is NULL)
			AND
				gd.doc_origem = 'minuta' 
			AND
				gcd.status != 'cancelado'
			AND
				(gcd.deleted = 0 OR gcd.deleted is NULL)";
			
			if($ordem){
				$query .= " and fo.ordem = $ordem";
			}

			$query .= " ORDER BY ic.id DESC";
			return $this->db->exec($query);
		}

		function gedClicksignDocumento($document_key = null){
			$query .= "
				SELECT
					*
				FROM
					ged_clicksign_documento
				WHERE 
					(deleted = 0 OR deleted is null)
			";

			if($document_key){
				$query .= " and document_key = '$document_key'";
			}
			
			$query .= " order by id desc";
			return $this->db->exec($query);		
		}
		
		function newPacoteDefault($codigo_produto = null, $codigo_modulo = null){
			$query = "
			SELECT 
				pd.id,
				pd.id_produto,
				pd.id_modulos_tarifaveis
				pd.qdt_garantido
				pd.valor_garantido,
				pd.preco_pkt,
				pd.status,
				mt.descricao,
				mt.codigo as codigo_modulo,
				p.nome as nome_produto,
				p.codigo as codigo_produto
			FROM
				pacote_default as pd
			INNER JOIN
				modulos_tarifaveis as mt
			ON
				(pd.id_modulos_tarifaveis = mt.id)
			INNER JOIN
				produtos p
			ON
				(p.id = mt.id_produto)
			WHERE
				(mt.deleted = 0 OR mt.deleted is null)";

			if($codigo_produto){
				$query .= " and p.codigo = '$codigo_produto'";
			}

			if($codigo_modulo){
				$query .= " and mt.codigo = '$codigo_modulo'";
			}
			return $this->db->exec($query);
		}
		
		function propostaAssinaturaById( $id_proposta ){
			$query = "
				SELECT
					ic.id,
					ic.id_proposta,
					ic.id_contrato,
					ic.nome_fantasia,
					ic.cnpj,
					ic.id_produto,
					ic.finalizado,
					iff.id as id_faturamento,
					p.id_owner,			
					ut.nome,
					ut.email,
					fs.objeto,
					fs.status as status_aprovacao,
					fo.ordem,
					gd.doc_origem,
					ga.nome_amigavel,
					ga.path_root,
					ga.path_objeto,
					gcd.id as id_doc,
					gcd.id_ged_anexo,
					gcd.plataforma,
					gcd.document_key,
					gcd.data_upload,
					gcd.status as status_documento,
					gcd.finalizado_em,
					pro.codigo
				FROM 
					if_contrato ic INNER JOIN 
					produtos AS pro ON (pro.id = ic.id_produto) INNER JOIN 
					if_faturamento iff ON (ic.id = iff.id_contrato) INNER JOIN
					propostas p ON (ic.id_proposta = p.id) INNER JOIN
					sistema_usuarios ut ON (p.id_owner = ut.id) INNER JOIN
					fluxo_status_aprovacao fs ON (ic.id = fs.id_objeto) INNER JOIN
					fluxo_ordem_aprovacao fo ON (fo.id = fs.id_ordem_aprovacao) INNER JOIN 
					ged_documento gd ON (ic.id = gd.id_origem) INNER JOIN
					ged_anexo ga ON (gd.id = ga.id_documento) INNER JOIN
					ged_clicksign_documento gcd ON (ga.id = gcd.id_ged_anexo)
				WHERE
					(ic.deleted = 0 OR ic.deleted is NULL) AND
					gd.doc_origem = 'minuta' AND
					gcd.status != 'cancelado' AND
					(gcd.deleted = 0 OR gcd.deleted is NULL)
			";
			
			if( $id_proposta ){
				$query .= " and p.id = $id_proposta ";
			}
			$query .= " ORDER BY ic.id DESC ";
			return $this->db->exec( $query );
		}
	}