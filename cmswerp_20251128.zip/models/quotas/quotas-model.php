<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class QuotasModel extends MainModel{
    //A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
    public function __construct($controller = null ){
        $this->table = 'quotas';
        parent::__construct($controller);
    }

    function getQuotas($id = null, $orderby = null){
        $query = "
            SELECT
                ven.id id_vendedor,
                ven.nome nome_vendedor,
                quo.tipo,
                quo.classe,
                quo.ano,
                sum(quo.valor) valor,
                quo.tipo
            FROM
                quotas quo left join
                vendedores ven on(quo.atribuido_a = ven.id)
            where
                (quo.deleted = 0 or quo.deleted is null ) and
                (ven.deleted = 0 or ven.deleted is null )
        ";
        if($id){
            $query .= " and quo.id = $id ";
        }
        $query .= " group by ven.id, quo.tipo, quo.ano, ven.nome ";
        $query .= " order by quo.ano, quo.mes, ven.nome ";
        $exec   = $this->db->query($query);
        if($exec){
            // Retorna
            $return = $exec->fetchAll();
            return json_encode($return);
        }else{
            return false;
        }
    }

    function getQuotasByAnoEvendedor($ano = null, $id_vendedor = null, $tipo = null, $classe = null){
        $query = "
            SELECT
                quo.id id_quota,
                ven.id id_vendedor,
                ven.nome nome_vendedor,
                quo.ano,
                quo.mes,
                quo.valor,
                quo.faturamento_minimo,
                quo.tipo,
                quo.classe
            FROM
                quotas quo left join
                vendedores ven on(quo.atribuido_a = ven.id)
            where
                (quo.deleted = 0 or quo.deleted is null ) and
                (ven.deleted = 0 or ven.deleted is null )
        ";
        if($ano){
            $query .= " and quo.ano = $ano ";
        }

        if($id_vendedor){
            $query .= " and quo.atribuido_a = $id_vendedor ";
        }

        if($tipo){
            $query .= " and quo.tipo = '$tipo' ";
        }

        if($classe){
            $query .= " and quo.classe = '$classe' ";
        }

        $query .= " order by quo.ano, quo.mes, ven.nome ";
        $exec = $this->db->query($query);
        if($exec){
            // Retorna
            $return = $exec->fetchAll();
            return json_encode($return);
        }else{
            return false;
        }
    }

    function quotasUpSelling($ano){
        $query = "
            SELECT
                quo.mes,
                quo.faturamento_minimo,
                sum(quo.faturamento_minimo) valor,
                ven.nome nome_vendedor
            FROM
                quotas quo left join 
                vendedores ven on(ven.id = quo.atribuido_a)
            where
                (quo.deleted = 0 or quo.deleted is null ) and
                quo.classe = 'Up Selling' and
                ven.status = 'ativo'
        ";
        if($ano){
            $query .= " and quo.ano = $ano ";
        }
        $query .= " group by quo.mes ";
        $query .= " order by quo.ano, quo.mes ";
        $exec  = $this->db->query($query);
        if($exec){
            // Retorna
            $return = $exec->fetchAll();
            return json_encode($return);
        }else{
            return false;
        }
    }

    function getSumCotasAnoTipo($ano){
        $query = "
            SELECT
                quo.mes,
                sum(quo.valor) valor,
                quo.tipo,
                ven.nome nome_vendedor
            FROM
                quotas quo inner join 
                vendedores ven on(ven.id = quo.atribuido_a)
            where
                (quo.deleted = 0 or quo.deleted is null ) and
                ven.status = 'ativo'
        ";
        if($ano){
            $query .= " and quo.ano = $ano ";
        }
        $query .= " group by quo.mes, quo.tipo, ven.nome ";
        $query .= " order by quo.ano, quo.mes ";
        $exec = $this->db->query($query);
        if($exec){
            // Retorna
            $return = $exec->fetchAll();
            return json_encode($return);
        }else{
            return false;
        }
    }

    function getQuotasByTipo($ano){
        
        if($ano){
            $dt_ini = $ano.'-01-01';
            $dt_fim = $ano.'-12-31';
        }else{
            echo 'Erro ano';
            exit;
        }

        $query = "
            SELECT 
                con.id id_contrato, 
                con.razao_social, 
                con.nome_fantasia, 
                con.codigo_cliente, 
                nf.id id_nf, 
                nf.codigo_produto, 
                nf.valor_total vr_nf_total, 
                nf.valor_liquido vr_nf_liquido, 
                nf.data_emissao dt_nf_emissao, 
                DATE_FORMAT(nf.data_emissao, '%m') nf_mes_emissao, 
                DATE_FORMAT(nf.data_emissao, '%Y') nf_ano_emissao, 
                ven.id id_vendedor, 
                ven.nome nome_vendedor, 
                quo.id id_quota, 
                quo.tipo quota_tipo, 
                quo.ano quota_ano, 
                quo.mes quota_mes, 
                quo.valor quota_valor, 
                quo.classe quota_classe, 
                quo.faturamento_minimo
            FROM
                contratos con
            LEFT JOIN
                notas_fiscais nf ON(con.id = nf.id_contrato)
            LEFT JOIN
                comissoes com ON(con.id = com.id_contrato)
            LEFT JOIN
                vendedores ven ON(ven.id = com.id_vendedor)
            LEFT JOIN 
                quotas quo ON(ven.id = quo.atribuido_a AND quo.tipo = 'vendedor' AND quo.ano = 2019)
            WHERE 
                (con.deleted IS NULL OR con.deleted = 0) AND
                con.data_assinatura >= '$dt_ini' AND
                con.data_assinatura <= '$dt_fim' AND
                (nf.status = 'recebido' OR nf.status = 'receber') AND
                nf.data_emissao >= '$dt_ini' AND
                nf.data_emissao <= '$dt_fim' AND
                (com.deleted IS NULL OR com.deleted = 0) AND 
                (quo.deleted IS NULL OR quo.deleted = 0)
            ORDER BY
                nf.data_emissao
        ";
        return $this->db->exec($query);
    }

    function save($param, $id = NULL, $field = 'id'){
        return parent::save($param, $id);
    }
}