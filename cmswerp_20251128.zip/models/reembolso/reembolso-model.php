<?php

/**
 * Created by VsCode.
 * User: Gabriel Santos
 * Date: 21/02/2024
 */
class ReembolsoModel extends MainModel
{
	public function __construct($db = false, $controller = null)
	{
		$this->table = 'reembolso';
		$this->db = $db;
		parent::__construct($controller);
	}

	public function getSolicitacao($id = null, $periodo_de = null, $periodo_ate = null)
	{
		$query = "
				SELECT
					rem.*,
					md.id id_meta,
					md.meta_valor,
					md.meta_classificacao,
					md.meta_info,
					md.meta_campo,
					ut.id id_owner,
					ut.nome nome_owner,
					boss.id id_boss,
					boss.nome nome_boss
				FROM 
					reembolso rem LEFT join
					meta_dados md ON md.meta_id_origem = rem.id AND meta_origem = 'reembolso' AND (md.deleted IS NULL OR md.deleted = 0) inner join
					sistema_usuarios ut ON( rem.owner = ut.id ) inner join
					sistema_usuarios boss on( boss.id = ut.boss ) 
				WHERE
					( rem.deleted IS NULL OR rem.deleted = 0 )";

		if ($id) {
			$query .= " and rem.id = $id ";
		}

		if (!empty($periodo_de) && !empty($periodo_ate)) {
			$query .= " and ( rem.data_ini >= '$periodo_de' and rem.data_fim <= '$periodo_ate' ) ";
		}
		// echo $query;
		return $this->db->exec($query);
	}

	public function getSolicitacaoArray(array $id_reembolso)
	{
		$query = "
				SELECT
					rem.*,
					md.id id_meta,
					md.meta_id_origem id_reembolso,
					md.meta_classificacao,
					md.meta_info
				FROM 
					reembolso rem LEFT join
					meta_dados md ON( md.meta_id_origem = rem.id AND meta_origem = 'reembolso' )
				WHERE
					( rem.deleted IS NULL OR rem.deleted = 0 ) AND
					( md.deleted IS NULL OR md.deleted = 0 )
					and md.meta_classificacao <> 'status'
					and md.meta_classificacao <> 'obs_recebivel'
			";

		if ($id_reembolso) {
			$query .= " and md.meta_id_origem in('" . implode("','", $id_reembolso) . "') ";
		}

		return $this->db->exec($query);
	}

	public function getVerificaStatus(array $id_reembolso)
	{
		$query = "
				SELECT
					rem.*,
					md.id id_meta,
					md.meta_id_origem id_reembolso,
					md.meta_classificacao,
					md.meta_info
				FROM 
					reembolso rem LEFT join
					meta_dados md ON( md.meta_id_origem = rem.id AND meta_origem = 'reembolso' )
				WHERE
					( rem.deleted IS NULL OR rem.deleted = 0 ) AND
					( md.deleted IS NULL OR md.deleted = 0 )
					and md.meta_classificacao = 'status'
			";

		if ($id_reembolso) {
			$query .= " and md.meta_id_origem in('" . implode("','", $id_reembolso) . "') ";
		}

		return $this->db->exec($query);
	}

	public function getMetaDadosAprovacao(array $id_reembolso)
	{
		$query = "
				SELECT
					md.*,
					rem.*,
					us1.nome nome_owner,
					us1.email email_owner,
					us2.nome nome_chefe,
					us2.email email_chefe
				FROM 
					meta_dados md  INNER JOIN
					reembolso rem ON( md.meta_id_origem = rem.id AND meta_origem = 'reembolso' ) INNER JOIN
					sistema_usuarios us1 ON( rem.owner = us1.id ) LEFT JOIN
					sistema_usuarios us2 ON( us1.boss = us2.id )
				WHERE
				( rem.deleted IS NULL OR rem.deleted = 0 )
				and md.meta_campo = 'status'
			";

		if ($id_reembolso) {
			$query .= " and md.meta_id_origem in('" . implode("','", $id_reembolso) . "') ";
		}

		return $this->db->exec($query);
	}

	public function getMetaDadosByStatus(array $ids_reembolso)
	{
		$query = "
			SELECT
				rem.*,
				md.id id_meta_dados,
				md.id_conjunto,
				md.meta_campo,
				md.meta_classificacao,
				md.meta_valor,
				md.meta_origem,
				md.meta_info,
				md.meta_id_origem,
				md.meta_default,
				md.alterado_por meta_alterado_por,
				md.alterado_em meta_alterado_em,
				md.deleted meta_deleted
			FROM 
				reembolso rem left join 
				meta_dados md ON(
					rem.id = md.meta_id_origem AND 
					md.meta_origem = 'reembolso' AND 
					(md.meta_campo = 'status' OR md.meta_campo IS null) and
					(md.deleted IS NULL OR md.deleted = 0)
				)
			WHERE
				( rem.deleted IS NULL OR rem.deleted = 0 )
			";

		if ($ids_reembolso) {
			$query .= " and rem.id in('" . implode("','", $ids_reembolso) . "') ";
		}
		//echo $query;
		return $this->db->exec($query);
	}

	public function getSolicitacaoByOwner($id_owner, $periodo_de, $periodo_ate)
	{
		$query = "
				SELECT
					rem.*,
					md.id id_meta,
					md.meta_valor,
					md.meta_classificacao,
					md.meta_info,
					md.meta_campo,
					ut.nome nome_owner,
					ut.id id_owner
				FROM 
					reembolso rem left join
					meta_dados md ON( md.meta_id_origem = rem.id AND meta_origem = 'reembolso' ) inner join
					sistema_usuarios ut ON(rem.owner = ut.id)
				WHERE
					( rem.deleted IS NULL OR rem.deleted = 0 ) AND
					( md.deleted IS NULL OR md.deleted = 0 )
			";

		if (!empty($periodo_de) && !empty($periodo_ate)) {
			$query .= " and ( rem.data_ini >= '$periodo_de' and rem.data_fim <= '$periodo_ate' ) ";
		}

		if ($id_owner) {
			$query .= " and rem.owner = $id_owner ";
		}

		return $this->db->exec($query);
	}

	public function getSolicitacaoByBoss($id_usuario, $periodo_de, $periodo_ate)
	{
		$query = "
				SELECT
					rem.*,
					md.id id_meta,
					md.meta_valor,
					md.meta_classificacao,
					md.meta_info,
					md.meta_campo,
					ut.nome nome_owner,
					ut.boss id_boss
				FROM 
					reembolso rem left join
					meta_dados md ON( md.meta_id_origem = rem.id AND meta_origem = 'reembolso' ) inner join
					sistema_usuarios ut ON(rem.owner = ut.id)
				WHERE
					( rem.deleted IS NULL OR rem.deleted = 0 ) AND
					( md.deleted IS NULL OR md.deleted = 0 )
			";

		if (!empty($periodo_de) && !empty($periodo_ate)) {
			$query .= " and ( rem.data_ini >= '$periodo_de' and rem.data_fim <= '$periodo_ate' ) ";
		}

		if ($id_usuario) {
			$query .= "  and  ( rem.owner = $id_usuario or ut.boss = $id_usuario )";
		} else {
			return false;
		}
		return $this->db->exec($query);
	}

	public function getMetaDados($id = null, $id_reem = null, $meta_campo = null)
	{
		$query = "
				SELECT
					*
				FROM 
					meta_dados md
				WHERE
					( md.deleted IS NULL OR md.deleted = 0 )
			";

		if ($id) {
			$query .= " and md.id = $id ";
		}
		if ($id_reem) {
			$query .= " and md.meta_id_origem = $id_reem ";
		}
		if ($meta_campo) {
			$query .= " and md.meta_campo = '$meta_campo' ";
		}

		return $this->db->exec($query);
	}

	public function getMetaDadosPorReembolso($id_reembolso)
	{
		$query = "
				SELECT 
					md.*, 
					geddoc.nome_documento, 
					geddoc.id id_doc,
					geda.path_root,
					geda.path_objeto,
					geda.nome_hash
				FROM 
					meta_dados md left join 
					ged_documento geddoc on( md.id = geddoc.id_origem and geddoc.doc_origem = 'meta_dados' ) left join
					ged_anexo geda ON(geda.id_documento = geddoc.id) 
				WHERE
					( md.deleted IS NULL OR md.deleted = 0 ) 
			";

		if ($id_reembolso) {
			$query .= " and md.meta_origem = 'reembolso' and md.meta_id_origem = $id_reembolso ";
		}
		return $this->db->exec($query);
	}

	public function getMetaDadosByStatusAprovado($id = null)
	{
		$query = "
				SELECT 
					* 
				FROM 
					meta_dados md 
				WHERE 
					( md.deleted IS NULL OR md.deleted = 0 ) AND 
					md.meta_campo = 'status'
			";

		if ($id) {
			$query .= " and md.meta_id_origem = $id ";
		}
		return $this->db->exec($query);
	}

	public function getMetaDadosStatus()
	{
		$query = "
				SELECT 
					md.meta_info
				FROM 
					meta_dados md
					INNER JOIN reembolso rem ON ( md.meta_id_origem = rem.id )
				WHERE 
					( rem.deleted IS NULL OR rem.deleted = 0 )
					AND md.meta_campo = 'status'
			";

		return $this->db->exec($query);
	}

	public function getObservacao($id)
	{
		$query = "
				SELECT
					md.id id_despesa,
					md.meta_info observacao
				FROM 
					meta_dados md  INNER JOIN
					reembolso rem ON( md.meta_id_origem = rem.id AND meta_origem = 'reembolso' ) 
				WHERE
				( rem.deleted IS NULL OR rem.deleted = 0 ) 
				and md.meta_campo = 'observacao'
			";

		if ($id) {
			$query .= "and md.meta_id_origem = $id ";
		}
		return $this->db->exec($query);
	}

	public function getReembolso(array $id_reembolso)
	{
		$query = "
				SELECT
					*
				FROM
					reembolso rem
				WHERE
					( rem.deleted IS NULL OR rem.deleted = 0 )
			";

		if ($id_reembolso) {
			$query .= " and rem.id in('" . implode("','", $id_reembolso) . "') ";
		}

		return $this->db->exec($query);
	}

	public function getUsersRh()
	{
		$query = "
				SELECT
					*
				FROM
					grupos_usuarios gu
					INNER JOIN grupos g ON ( gu.id_grupo = g.id )
				WHERE
					( g.deleted IS NULL OR g.deleted = 0 )
					AND g.modulo_mestre = 'reembolso'
			";

		return $this->db->exec($query);
	}
}
