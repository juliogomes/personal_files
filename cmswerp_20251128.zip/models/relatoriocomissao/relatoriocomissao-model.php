<?php
/**
 * User: caio.freitas
 * Date: 07/11/2022
 * Time: 11:42
 */
class RelatorioComissaoModel extends MainModel{
    
    public function __construct($controller = null ){
		parent::__construct($controller);
	}

    function getUserComissao($status = null, $perfil = null, $id_comissao = null, $id_usuario = null, $order_by = null){
        $query = "
            SELECT 
                c.*,
                u.nome,
                u.status,
                cc.id_comissao_usuario,
                cp.nome as nome_perfil,
                cp.percentual
            FROM
                comissoes_usuario c
            INNER JOIN
                sistema_usuarios u
            ON
                (c.id_usuario = u.id)
            INNER JOIN
                comissoes_perfil cp
            ON
                (c.id_perfil = cp.id)
            LEFT JOIN
            carteira_cadastro cc
            ON
                (cc.id_comissao_usuario = c.id)
            WHERE
                (c.deleted is null or c.deleted = 0)
        ";

        if($status){
            $query .= " and u.status = '$status'";
        }

        if($perfil){
            $query .= " and cp.nome = '$perfil'";
        }

        if($id_comissao){
            $query .= " and c.id = $id_comissao";
        }

        if($id_usuario){
            $query .= " and c.id_usuario = $id_usuario";
        }

        if(isset($order_by) && $order_by == "nome"){
            $query .= " ORDER BY u.nome ASC";
        }else{
            $query .= " ORDER BY c.id DESC";
        }
        return $this->db->exec($query);
    } 
    //By Caio Freitas - 02/02/2022
    function getUserComissaoCarteira($perfil = null, $ano = null, $status = null){
        $query = "
        SELECT 
            c.*,           
            u.status,
            cc.id_comissao_usuario,
            cc.nome_usuario,
            cp.nome as nome_perfil,
            cp.percentual,           
            ch.ano,
            ch.status,
            ch.id_carteira
        FROM
            comissoes_usuario c
        INNER JOIN
            sistema_usuarios u
        ON
            (c.id_usuario = u.id)
        INNER JOIN
            comissoes_perfil cp
        ON
            (c.id_perfil = cp.id)      
        INNER JOIN
           carteira_cadastro cc
        ON
            (cc.id_comissao_usuario = c.id)
        INNER JOIN
            carteira_historico ch
        ON
            (cc.id = ch.id_carteira)
        WHERE
            (c.deleted is null or c.deleted = 0)
        ";

        if($perfil){
            $query .= " and cp.nome = '$perfil'";
        }

        if($ano){
            $query .= " and ch.ano = '$ano'";
        }

        if($status){
            $query .= " and ch.status = '$status'";
        } 
        $query .= " ORDER BY cc.nome_usuario ASC";
        return $this->db->exec($query);
    } 

    //By Caio Freitas - 26/01/2023
    function getComissaoContratoCarteira($id_comissao_usuario,$id_objeto){
        $query .= "
        SELECT
            cv.*,
            cc.id as id_carteira,
            cc.nome_carteira,
            ic.id_contrato,
            ic.razao_social,
            c.data_assinatura,
            c.data_reajuste,
            c.duracao_contrato
        FROM
            comissoes_validade cv
        INNER JOIN
            carteira_cadastro cc
        ON 
           (cv.id_comissao_usuario = cc.id_comissao_usuario) 
        INNER JOIN
            if_contrato ic
        ON
            (cv.id_objeto = ic.id)
        INNER JOIN
            contratos c
        ON
            (ic.id_contrato = c.id)
        WHERE
            (cv.deleted = 0 OR cv.deleted is null)";

        if($id_comissao_usuario){
            $query .= " and cv.id_comissao_usuario = $id_comissao_usuario";
        }

        if($id_objeto){
            $query .= " and cv.id_objeto = $id_objeto";
        }
        $query .= " ORDER BY cv.id DESC";
        return $this->db->exec($query);
    }
      

    function getContrato($id_contrato = null, $cnpj = null){
        $query = "
        SELECT 
            c.*,
            p.codigo
        FROM
            contratos c 
        INNER JOIN
            produtos p    
        ON
            (c.id_produto = p.id)
        WHERE
            (c.deleted is null or c.deleted = 0)
        ";

        if($id_contrato){
            $query .= " and c.id = $id_contrato";
        }

        if($cnpj){
            $query .= " and c.cnpj = '$cnpj'";
        }

        $query .= " ORDER BY c.id DESC";

        return $this->db->exec($query); 
    }

    function getNota($status = null, $periodo_de = null, $periodo_ate = null, $id_comissionado = null, $id_contrato = null, $tipo = "nota"){
        $query = "
        SELECT 
           con.data_assinatura, 
           con.numero_contrato,
           nf.id as id_nota,
           nf.numero,
           cus.id as id_comissao_usuario,
           nf.numero_fatura,
           nf.tipo,
           nf.data_emissao,
           nf.data_vencimento,
           nf.data_faturamento,
           nf.hora_emissao,
           nf.cliente,
           nf.codigo_produto,
           nf.status,           
           nf.ano_mes_referencia,
           nf.instrucao_pagamento_nome,
           nf.periodo_de,
           nf.periodo_ate,
           nf.recebido_em,
           nf.parcelas as numero_parcela,
           nf.valor_liquido,
           c.id,
           c.id_contrato,                  
           c.razao_social,
           c.cnpj,
           c.segmento,
           c.site,
           cv.id as id_comissao,
           cv.id_usuario,        
           cv.meses_validade,
           p.nome as nome_produto,
           p.id as id_produto,
           f.parcelas,
           f.implantacao,
           f.faturamento_todo_dia,
           f.duracao_contrato,           
           f.id_contrato as if_contrato,
           cp.percentual,
           ut.nome                    
        FROM
            notas_fiscais nf        
        INNER JOIN
            if_contrato c
        ON
            (c.id_contrato = nf.id_contrato)
        INNER JOIN
            comissoes_validade cv
        ON 
            (cv.id_objeto = c.id)
        INNER JOIN
            produtos p
        ON
            (p.id = c.id_produto)
        INNER JOIN
            if_faturamento f
        ON
            (c.id = f.id_contrato)  
        INNER JOIN
            comissoes_usuario cus
        ON
            (cv.id_usuario = cus.id_usuario)      
        INNER JOIN
            comissoes_perfil cp
        ON
            (cus.id_perfil = cp.id)  
        INNER JOIN
            contratos con
        ON
            (nf.id_contrato = con.id)
        INNER JOIN
            sistema_usuarios ut
        ON
            (cv.id_usuario = ut.id) 
             
        WHERE
            (c.deleted is null OR c.deleted = 0)
        AND 
            cv.deleted = 0 AND cus.deleted = 0";

        if($status){
            $query .= " and nf.status = '$status'";
        }

        if($tipo == "nota"){
            if($periodo_de){
                $query .= " and nf.data_emissao >= '$periodo_de'";
            }

            if($periodo_ate){
                $query .= " and nf.data_emissao <= '$periodo_ate'";
            }
        }else if($tipo == "recebido"){
            if($periodo_de){
                $query .= " and nf.recebido_em >= '$periodo_de'";
            }

            if($periodo_ate){
                $query .= " and nf.recebido_em <= '$periodo_ate'";
            }
        }
        

        if($id_comissionado){
            $query .= " and cv.id_comissao_usuario = $id_comissionado";
        }

        if($id_contrato){
            $query .= " and c.id_contrato = $id_contrato";
        }
        $query .= " ORDER BY nf.id DESC";
        return $this->db->exec($query); 
    }

    function getContratoMinutaProdutoNota($id_contrato = null, $id_nota = null, $status = null, $tipo = null){
        $query = "
        SELECT
            c.*,
            ic.id,
            ic.id_proposta,
            ic.status,
            ic.razao_social,
            ic.nome_fantasia,
            ic.cnpj,
            ic.segmento,
            ic.id_produto,
            ic.codigo_cliente,
            p.nome as nome_produto,
            p.descricao as descricao_produto,
            p.codigo,
            nf.valor_liquido,
            nf.valor_fatura,
            nf.valor_impostos,
            nf.tipo_desconto,
            nf.porcentagem_desconto,
            nf.valor_desconto,
            nf.valor_total,
            nf.recebido_em,
            nf.id as id_nota,
            nf.tipo,
            nf.parcelas,
            nf.status as status_nota,
            f.parcelas as parcelas_faturamento
        FROM
            contratos c
        INNER JOIN
            if_contrato ic
        ON
            (c.id = ic.id_contrato)
        INNER JOIN
            produtos p
        ON
            (ic.id_produto = p.id)
        INNER JOIN
            notas_fiscais nf
        ON
            (c.id = nf.id_contrato)
        INNER JOIN
            if_faturamento f
        ON
            (ic.id = f.id_contrato)
        WHERE
            (c.deleted = 0 OR c.deleted is null)";
        
        if($id_contrato){
            $query .= " and ic.id = $id_contrato";
        }
        if($id_nota){
            $query .= " and nf.id = $id_nota";
        }
        if($status){
            $query .= " and nf.status = '$status'";
        }
        if($tipo){
            $query .= " and nf.tipo = '$tipo'";
        }
        $query .= " ORDER BY ic.id DESC";
        return $this->db->exec($query);        
    }

    function allComissao($id_objeto = null, $id_usuario = null, $id_comissao = null){
        $query = "
        SELECT 
            cu.id,
            cu.id_perfil,
            cu.id_usuario,
            cv.id_objeto,
            cv.perfil,
            cv.data_criacao,
            cv.meses_validade,
            cp.nome as nome_perfil,
            cp.descricao,
            cp.objeto,
            cp.percentual,
            ut.nome as nome_usuario
        FROM
            comissoes_usuario cu 
        INNER JOIN
            comissoes_validade cv   
        ON
            (cu.id = cv.id_comissao_usuario)
        INNER JOIN
            comissoes_perfil cp
        ON
            (cu.id_perfil = cp.id)
        INNER JOIN
            sistema_usuarios ut
        ON
            (cu.id_usuario = ut.id)        
        WHERE
            (cv.deleted is null or cv.deleted = 0)
        ";

        if($id_objeto){
            $query .= " and cv.id_objeto = $id_objeto";
        }

        if($id_usuario){
            $query .= " and cu.id_usuario = $id_usuario";
        }

        if($id_comissao){
            $query .= " and cu.id = $id_comissao";
        }
        $query .= " ORDER BY cv.id DESC";  
        return $this->db->exec($query); 
    }

    function getComissaoPagamentoFull($id_objeto = null, $id_nota = null){
        $query = "
        SELECT 
            cu.id,
            cu.id_perfil,
            cu.id_usuario,
            cv.id_objeto,
            cv.perfil,
            cv.data_criacao,
            cv.meses_validade,
            cp.nome as nome_perfil,
            cp.descricao,
            cp.objeto,
            cp.percentual,
            ut.nome as nome_usuario,
            cop.status,
            cop.data_pagamento,
            cop.id_nota
        FROM
            comissoes_usuario cu 
        INNER JOIN
            comissoes_validade cv   
        ON
            (cu.id = cv.id_comissao_usuario)
        INNER JOIN
            comissoes_perfil cp
        ON
            (cu.id_perfil = cp.id)
        INNER JOIN
            sistema_usuarios ut
        ON
            (cu.id_usuario = ut.id) 
        LEFT JOIN
            comissoes_pagamento cop
        ON
            (cu.id = cop.id_comissao)     
        WHERE
            (cv.deleted is null or cv.deleted = 0)
        ";

        if($id_objeto){
            $query .= " and cv.id_objeto = $id_objeto";
        }
        if($id_nota){
            $query .= " and cop.id_nota = $id_nota";
        }
        $query .= " ORDER BY cv.id DESC";  
        return $this->db->exec($query); 
    }

    function getComissoesPagamento($id_nota = null, $id_comissionado = null, $id = null){
        $query = "
        SELECT
            *
        FROM
            comissoes_pagamento
        WHERE
            (deleted is null or deleted = 0)
        ";

        if($id_nota){
            $query .= " and id_nota = $id_nota";
        }
        if($id_comissionado){
            $query .= " and id_comissao = $id_comissionado";
        }
        if($id){
            $query .= " and id = $id";
        }
        $query .= " ORDER BY id DESC";
        return $this->db->exec($query);
    }

    function getNotaContratoComissao(){
        $query = "
        SELECT 
           nf.id as id_nota,
           nf.numero,
           nf.numero_fatura,
           nf.tipo,
           nf.data_emissao,
           nf.data_vencimento,
           nf.data_faturamento,
           nf.hora_emissao,
           nf.cliente,
           nf.codigo_produto,
           nf.status,
           nf.recebido_em,
           nf.ano_mes_referencia,
           nf.instrucao_pagamento_nome,
           nf.periodo_de,
           nf.periodo_ate,        
           nf.tipo,
           c.id,
           c.id_contrato,                  
           c.razao_social,
           c.cnpj,
           c.segmento,
           c.site,
           cv.id as id_comissao,
           cv.id_usuario,
           cv.id_comissao_usuario,
           cv.meses_validade,
           cp.percentual,
           cp.descricao,
           ut.nome,
           f.implantacao,
           f.parcelas             
        FROM
            notas_fiscais nf        
        INNER JOIN
            if_contrato c
        ON
            (c.id_contrato = nf.id_contrato)
        INNER JOIN
            comissoes_validade cv
        ON 
            (cv.id_objeto = c.id)
        INNER JOIN
            comissoes_usuario cu
        ON 
            (cu.id = cv.id_comissao_usuario)
        INNER JOIN
            comissoes_perfil cp
        ON 
            (cp.id = cu.id_perfil)
        INNER JOIN
            if_faturamento f
        ON
            (c.id = f.id_contrato)
        INNER JOIN
            sistema_usuarios ut
        ON
            (cv.id_usuario = ut.id)
        WHERE
            (c.deleted is null OR c.deleted = 0)
        ";
        return $this->db->exec($query); 
    }

     //By Caio Freitas - 30/11/2022
    function getCarteira($id_carteira = null, $id_usuario = null){
        $query = "
        SELECT 
           *
        FROM
            carteira_cadastro        
        WHERE
            (deleted is null OR deleted = 0)
        ";

        if($id_carteira){
            $query .= " and id = $id_carteira";
        }
        if($id_usuario){
            $query .= " and id_usuario = $id_usuario";
        }
        $query .= " ORDER BY id DESC";
        return $this->db->exec($query); 
    }

     //By Caio Freitas - 02/02/2023
     function getCarteiraUser($id_carteira = null, $id_usuario = null){
        $query = "
            SELECT 
            cc.*,
            ut.nome
            FROM
                carteira_cadastro cc     
            INNER JOIN
                sistema_usuarios ut  
            ON
                (cc.id_usuario = ut.id)
            WHERE
                (cc.deleted is null OR cc.deleted = 0)
        ";

        if($id_carteira){
            $query .= " and cc.id = $id_carteira";
        }
        if($id_usuario){
            $query .= " and cc.id_usuario = $id_usuario";
        }
        $query .= " ORDER BY cc.id DESC";   
        return $this->db->exec($query); 
    }

    //By Caio Freitas - 30/11/2022
    function getComissaoUser($id_comissao = null){
        $query = "
        SELECT 
            c.*,
            u.nome as nome_usuario
        FROM
            comissoes_usuario c
        INNER JOIN
            sistema_usuarios u
        ON
            (c.id_usuario = u.id)
        WHERE
            (c.deleted is null OR c.deleted = 0)";

        if($id_comissao){
            $query .= " and c.id = $id_comissao";
        }

        $query .= " ORDER BY c.id DESC";

        return $this->db->exec($query);
    }

    //By Caio Freitas - 30/11/2022
    function getComissaoContrato($id_comissao_usuario = null){
        $query = "
        SELECT 
            cv.id,
            cv.id_comissao_usuario,
            cv.id_usuario,
            cv.id_objeto,
            cv.perfil,
            cv.data_criacao,
            cv.meses_validade,
            ic.id_proposta,
            ic.id_contrato,
            ic.status,
            ic.id_produto,
            ic.codigo_cliente,
            ic.finalizado,
            c.id as id_contrato,
            c.numero_contrato,
            c.razao_social,
            c.cnpj,
            c.duracao_contrato,
            c.data_assinatura,
            c.data_reajuste
        FROM
            comissoes_validade cv
        INNER JOIN
            if_contrato ic
        ON
            (cv.id_objeto = ic.id)
        INNER JOIN
            contratos c
        ON
            (ic.id_contrato = c.id)
        WHERE
            (c.deleted is null OR c.deleted = 0)";

        if($id_comissao_usuario){
            $query .= " and cv.id_comissao_usuario = $id_comissao_usuario";
        }
        $query .= " ORDER BY c.id DESC";
        return $this->db->exec($query);
    }

    //By Caio Freitas Feat: Julio Gomes / 30/11/2022
    function getCarteiraContrato($id_produto = null, $order_by = null, $cnpj = null, $id_carteira = null){
        $query = "
        SELECT 
            con.*,
            ifcon.id id_fat,
            ccon.id_contrato contrato_carteira,
            p.nome as nome_produto,
            p.codigo,
            ccon.id_carteira,
            ccon.deleted as deleted_carteira,
            cc.nome_carteira
        FROM
            contratos con 
        LEFT JOIN
            carteira_contratos ccon 
        ON
            (con.id = ccon.id_contrato) 
        LEFT JOIN
            if_contrato ifcon 
        ON(
            con.id = ifcon.id_contrato) 
        LEFT JOIN
            produtos p
        ON
            (p.id = con.id_produto)
        LEFT JOIN
            carteira_cadastro cc
        ON 
            (cc.id = ccon.id_carteira)
        WHERE
            (con.deleted IS NULL OR con.deleted = 0)        
        AND
            con.`status` = 'ativo'" ;

        if($id_produto){
            $query .= " and con.id_produto = $id_produto";
        }

        if($cnpj){
            $query .= " and con.cnpj = '$cnpj'";
        }

        if($id_carteira){
            $query .= " and ccon.id_carteira = $id_carteira";
        }

        if($order_by){
            $query .= " ORDER BY con.razao_social ASC";
        }else{
            $query .= " ORDER BY con.id DESC";
        }
        return $this->db->exec($query);
    }

    function getContratos(){
        $query = "
        SELECT 
            *
        FROM
            contratos
        WHERE
            (deleted is null OR deleted = 0)
        AND
            status = 'ativo'";
        $query .= " ORDER BY id DESC";
        return $this->db->exec($query);
    }

    function getProduto(){
        $query = "
        SELECT 
            *
        FROM
            produtos
        WHERE
            (deleted is null OR deleted = 0)
        AND
            status = 'ativo'";

        $query .= " ORDER BY id ASC";
        return $this->db->exec($query);
    }

    //By ulio Gomes / 01/12/2022
    function getTarifacoesPorContrato($dt_ini, $dt_fim, $contrato){
        $query = "
            select
                sum(md.qtd_transacoes) total_transacoes,
                co.razao_social,
                co.id
            from
                ".DB_NAME_MOVIMENTO.".tarifacoes md inner join
                ".DB_NAME.".contratos co on(co.id = md.id_contrato)
            where
                (md.deleted = 0 or md.deleted is null) and
                md.data_tarifacao >= '$dt_ini' and
                md.data_tarifacao <= '$dt_fim'
        ";

        if($contrato){
            if(is_array($contrato)){
                $query .= " and ( md.id_contrato in( '".implode("','", $contrato)."') )";
            }else{
                $query .= " and md.id_contrato = '".$contrato."'";
            }
        }
        $query .= " group by co.id ";
        return $this->db->exec($query);
    }

    function getContratoCarteira($id_contrato = null, $id_carteira = null, $cnpj = null){
        $query = "
        SELECT 
            *
        FROM
            carteira_contratos
        WHERE
            (deleted is null OR deleted = 0 OR deleted = 1)";       

        if($id_contrato){
            $query .= " and id_contrato = $id_contrato";
        }
        if($id_carteira){
            $query .= " and id_carteira = $id_carteira";
        }
        if($cnpj){
            $query .= " and cnpj = '$cnpj'";
        }
        $query .= " ORDER BY id DESC";
        return $this->db->exec($query);    
    }

    function lastTransacao($id = null, $ano = null, $status = null){
        $query = "
        SELECT
            *
        FROM
            carteira_historico
        WHERE
            (deleted is null OR deleted = 0)";

        if($id){
            $query .= " and id_carteira = $id";
        }

        if($ano){
            $query .= " and ano = '$ano'";
        }

        if($status){
            $query .= " and status = '$status'";
        }        
        $query .= " ORDER BY id DESC limit 1";
        return $this->db->exec($query); 
    }

    function usuarioPerfil($id_user = null){
        $query = "
        SELECT 
            ut.*,
            p.nome as nome_perfil
        FROM
            sistema_usuarios ut
        INNER JOIN
            perfis p
        ON
            (ut.id_perfil = p.id)
        WHERE
            (ut.status = 'ativo')";

        if($id_user){
            $query .= " and ut.id = $id_user";
        }
        $query .= " ORDER BY ut.id DESC";
        return $this->db->exec($query); 
    }
    
    function getHistorico($id = null, $ano = null, $status = null){
        $query = "
        SELECT
            ch.*,
            cc.id_usuario,
            cc.nome_usuario
        FROM
            carteira_historico ch
        INNER JOIN
            carteira_cadastro cc
        ON
            (ch.id_carteira = cc.id)        
        WHERE
            (ch.deleted is null OR ch.deleted = 0)";

        if($id){
            $query .= " and ch.id_carteira = $id";
        }

        if($ano){
            $query .= " and ch.ano = '$ano'";
        }

        if($status){
            $query .= " and ch.status = '$status'";
        }        

        $query .= " ORDER BY ch.id DESC";
        return $this->db->exec($query); 
    }
    

    //By Caio Freitas - 10/01/2023
    function notaComissaoPagamento($ano_mes = null, $id_comissionado = null, $status = null, $pago_em_ini = null, $pago_em_fim = null){
        $query = "
        SELECT        
            nf.id, 
            nf.numero, 
            nf.tipo, 
            nf.data_emissao, 
            nf.data_vencimento, 
            nf.data_faturamento, 
            nf.cliente, 
            nf.codigo_produto, 
            nf.valor_liquido, 
            nf.valor_total,
            nf.ano_mes_referencia,
            nf.status as status_nota,
            nf.recebido_em,
            cp.id_comissao,
            cp.status,
            cp.data_pagamento,
            cp.observacao,
            ut.id as id_usuario,
            ut.nome,
            cpe.percentual,
            cus.id as id_comissao_usuario,
            ic.id as id_if_contrato,
            c.data_assinatura
        FROM
            notas_fiscais nf
        INNER JOIN 
            comissoes_pagamento cp
        ON
            (cp.id_nota = nf.id)
        INNER JOIN 
            comissoes_usuario cus
        ON
            (cp.id_comissao = cus.id)
        INNER JOIN
            comissoes_perfil cpe
        ON
            (cus.id_perfil = cpe.id)
        INNER JOIN
            if_contrato ic
        ON
            (nf.id_contrato = ic.id_contrato)        
        INNER JOIN
            sistema_usuarios ut
        ON
            (cus.id_usuario = ut.id)
        INNER JOIN
            contratos c
        ON
            (ic.id_contrato = c.id)
        WHERE
            (nf.deleted is null OR nf.deleted = 0)
        AND
            (cp.deleted is null OR cp.deleted = 0)
        AND
            (ut.status = 'ativo')";

        if($ano_mes){
            $query .= " and nf.ano_mes_referencia = '$ano_mes'";
        }

        if(isset($id_comissionado)){
            $query .= " and cus.id = $id_comissionado";
        }

        if($status){
            $query .= " and nf.status = '$status'";
        }

        if($pago_em_ini){
            $query .= " and nf.recebido_em >= '$pago_em_ini'";
        }

        if($pago_em_fim){
            $query .= " and nf.recebido_em <= '$pago_em_fim'";
        }
        $query .= " ORDER BY nf.id DESC";
        return $this->db->exec($query); 
    }

    function notaComissaoContrato($ano_mes = null, $id_comissionado = null, $pago_ini = null, $pago_fim = null){
        $query = "
        SELECT          
            nf.id, 
            nf.numero, 
            nf.tipo, 
            nf.data_emissao, 
            nf.data_vencimento, 
            nf.data_faturamento, 
            nf.cliente, 
            nf.codigo_produto, 
            nf.valor_liquido, 
            nf.valor_total,
            nf.ano_mes_referencia,
            cp.id_comissao,
            cp.status,
            cp.data_pagamento,
            cp.observacao,
            ut.id as id_usuario,
            ut.nome,
            c.razao_social,
            cpe.percentual,
            ic.id as id_if_contrato
        FROM
            notas_fiscais nf
        INNER JOIN 
            comissoes_pagamento cp
        ON
            (cp.id_nota = nf.id)
        INNER JOIN 
            comissoes_usuario cus
        ON
            (cp.id_comissao = cus.id)
        INNER JOIN
            comissoes_perfil cpe
        ON
            (cus.id_perfil = cpe.id)
        INNER JOIN
            sistema_usuarios ut
        ON
            (cus.id_usuario = ut.id)
        INNER JOIN
            contratos c
        ON
            (c.id = nf.id_contrato)
        INNER JOIN
            if_contrato ic
        ON
            (c.id = ic.id_contrato)
        WHERE
            (nf.deleted is null OR nf.deleted = 0)
        AND
            (cp.deleted is null OR cp.deleted = 0)
        AND
            (ut.status = 'ativo')";

        if($ano_mes){
            $query .= " and nf.ano_mes_referencia = '$ano_mes'";
        }

        if(isset($id_comissionado)){
            $query .= " and cus.id = $id_comissionado";
        }

        if($pago_ini){
            $query .= " and cp.data_pagamento >= '$pago_ini'";
        }

        if($pago_fim){
            $query .= " and cp.data_pagamento <= '$pago_fim'";
        }
        $query .= " ORDER BY nf.data_emissao DESC";      
        return $this->db->exec($query);         
    }

    function comissaoUsuarioPerfil($id_comissionado = null){
        $query .= "
        SELECT
            cus.*,
            cp.nome,
            cp.objeto,
            cp.percentual
        FROM
            comissoes_usuario cus
        INNER JOIN 
            comissoes_perfil cp
        ON
            (cp.id = cus.id_perfil)
        WHERE
            (cus.deleted = 0 OR cus.deleted is null)
        AND
            (cp.deleted = 0 OR cp.deleted is null)";

        if($id_comissionado){
            $query .= " and cus.id = $id_comissionado";
        }

        $query .= " ORDER BY cus.id DESC";
        return $this->db->exec($query); 
    }
    //By: Caio Freitas - 27/01/2023 
    function comissoesProgressiva($id_carteira = null, $ano = null, $mes = null){
        $query .= "
        SELECT 
            cp.*
        FROM
            comissoes_progressiva cp
        WHERE
            (cp.deleted = 0 OR cp.deleted is null)";

        if($id_carteira){
            $query .= " and cp.id_carteira = $id_carteira";
        }

        if($ano){
            $query .= " and cp.ano = $ano";
        }

        if($mes){
            $query .= " and cp.mes = $mes";
        }
        $query .= " ORDER BY cp.id DESC";
        return $this->db->exec($query); 
    }

    //By: Caio Freitas - 02/02/2023
    function comissoesProgressivaUser($id_carteira = null, $ano = null, $mes = null, $order_by = null){
        $query .= "
        SELECT 
            cp.*,
            cc.nome_carteira,
            cc.id_comissao_usuario,
            cc.id_usuario,
            cc.nome_usuario
        FROM
            comissoes_progressiva cp
        INNER JOIN
            carteira_cadastro cc
        ON
            (cp.id_carteira = cc.id)
        WHERE
            (cp.deleted = 0 OR cp.deleted is null)";

        if($id_carteira){
            $query .= " and cp.id_carteira = $id_carteira";
        }

        if($ano){
            $query .= " and cp.ano = $ano";
        }

        if($mes){
            $query .= " and cp.mes = $mes";
        }

        if(isset($order_by) && $order_by == "nome"){
            $query .= " ORDER BY cc.nome_usuario ASC";
        }else{
            $query .= " ORDER BY cp.id DESC";
        }
        return $this->db->exec($query); 
    }
}