<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class ReportModel extends MainModel{
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	protected $obj_movimento;
	public function __construct($controller = null ){
		parent::__construct($controller);
	}

	function getIndicadoresPorAnoMes($codigo = null, $ano = null, $mes = null){
		$query = " select * from indicadores where (deleted = 0 or deleted is null ) ";

		if($codigo){
			$query .= " and codigo = '$codigo' ";
		}

		if($ano){
			$query .= " and ano = $ano ";
		}

		if($mes){
			$query .= " and mes = $mes ";
		}
		//echo '<br><br>'.$query.'<br><br>';
		return $this->db->exec($query);
	}

	function getContratosAtivos($data_limite){
		$query = " select count(1) contratos_ativos from contratos where (deleted is null or deleted = 0) and data_assinatura <= '$data_limite' and (inativado_em is null or inativado_em >= '$data_limite') ";
		return $this->db->exec($query);
	}

	function getClientesAtivos($data_limite){
		$query = " select count(DISTINCT codigo_cliente) clientes_ativos from contratos where (deleted is null or deleted = 0) and data_assinatura <= '$data_limite' and (inativado_em is null or inativado_em >= '$data_limite')";
		return $this->db->exec($query);
	}

	function saveIndicador($param, $id = null){
		$this->table = 'indicadores';
		return $this->save($param, $id);
	}

	function getRoi(){
		$query = "
			SELECT 
				pr.nome nome_produto,
				mt.descricao nome_modulo,
				DATE_FORMAT(tf.data_tarifacao, '%Y') ano,
				DATE_FORMAT(tf.data_tarifacao, '%m') mes,
				SUM(tf.qtd_transacoes) total_transacoes
			FROM
				".DB_NAME_MOVIMENTO.".tarifacoes tf INNER join
				".DB_NAME.".produtos pr ON(tf.codigo_produto = pr.codigo) INNER join
				".DB_NAME.".modulos_tarifaveis mt ON(tf.codigo_modulo = mt.codigo)
			WHERE
				(tf.deleted IS NULL OR tf.deleted = 0) AND 
				tf.data_tarifacao >= '2019-01-01' and
				pr.codigo = 'RCK0001'
			GROUP BY
				pr.nome,
				mt.descricao,
				ano,
				mes
			ORDER BY
				pr.nome,
				mt.descricao,
				tf.data_tarifacao asc
			;
		";
		return $this->db->exec($query);
	}
	
	function getTopDespesasByAno($dt_ini, $dt_fim, $id_fornecedor = null, $tipo_fornecedor = null, $tipo_despesa = null, $limit = 10){
		$query ="
			SELECT
				fo.id id_fornecedor,
				fo.tipo tipo_fornecedor,
				date_format(desp.data_pagamento, '%Y') ano,
				fo.nome_fantasia,
				SUM(valor) total_despesas
			FROM
				despesas desp INNER join
				fornecedores fo ON(desp.id_fornecedor = fo.id)
			WHERE
				(desp.deleted IS NULL OR desp.deleted = 0) and
				desp.status ='pago'  and
				desp.data_pagamento <= '2022-12-31'
			
		";

		if(is_array($id_fornecedor)){
			$query .= " and fo.id in('".implode("','", $id_fornecedor)."') ";
		}elseif($id_fornecedor){
			$query .= " and fo.id = '$id_fornecedor'";
		}

		if($dt_ini){
			$query .= "and desp.data_pagamento >= '$dt_ini' ";
		}

		if($dt_fim){
			$query .= "and desp.data_pagamento <= '$dt_fim' ";
		}

		if($tipo_fornecedor){
			$query .= "and fo.tipo = '$tipo_fornecedor' ";
		}

		if(is_array($tipo_despesa)){
			$query .= " and desp.tipo_despesa in('".implode("','", $tipo_despesa)."') ";
		}elseif($tipo_despesa){
			$query .= " and desp.tipo_despesa = '$tipo_despesa'";
		}

		$query .= "
			GROUP BY
				fo.id,
				fo.tipo,
				ano,
				fo.nome_fantasia
			ORDER BY
				total_despesas desc
			
		";

		if($limit){
			$query .= " Limit $limit ";
		}
		return $this->db->exec($query, null, 'array');
	}

	function getTopDespesasByMes($dt_ini, $dt_fim, $id_fornecedor = null, $tipo_fornecedor = null, $tipo_despesa = null, $limit = 10){
		$query ="
			SELECT
				fo.id id_fornecedor,
				fo.tipo tipo_fornecedor,
				date_format(desp.data_pagamento, '%Y') ano,
				date_format(desp.data_pagamento, '%m') mes,
				fo.nome_fantasia,
				SUM(valor) total_despesas
			FROM
				despesas desp INNER join
				fornecedores fo ON(desp.id_fornecedor = fo.id)
			WHERE
				(desp.deleted IS NULL OR desp.deleted = 0) and
				desp.status ='pago'
			
		";

		if(is_array($id_fornecedor)){
			$query .= " and fo.id in('".implode("','", $id_fornecedor)."') ";
		}elseif($id_fornecedor){
			$query .= " and fo.id = '$id_fornecedor'";
		}

		if($dt_ini){
			$query .= "and desp.data_pagamento >= '$dt_ini' ";
		}

		if($dt_fim){
			$query .= "and desp.data_pagamento <= '$dt_fim' ";
		}

		if($tipo_fornecedor){
			$query .= "and fo.tipo = '$tipo_fornecedor' ";
		}

		if(is_array($tipo_despesa)){
			$query .= " and desp.tipo_despesa in('".implode("','", $tipo_despesa)."') ";
		}elseif($tipo_despesa){
			$query .= " and desp.tipo_despesa = '$tipo_despesa'";
		}

		$query .= "
			GROUP BY
				fo.id,
				fo.tipo,
				ano,
				mes,
				fo.nome_fantasia
			ORDER BY
				total_despesas desc
		";

		if($limit){
			$query .= " Limit $limit ";
		}
		return $this->db->exec($query);
	}
	
	function getOrcamentoByDiretoriaMes($ano){
		if($ano && is_numeric($ano)){
			$query ="
				SELECT
					occ.nome,
					ol.mes,
					sum(ol.valor) total_lancamentos
				FROM
					orc_lancamento ol INNER join
					orc_centro_custo occ ON(ol.id_cc = occ.id)
				WHERE
					(ol.deleted IS NULL OR ol.deleted = 0) and
					ol.ano = $ano
				GROUP BY
					ol.mes,
					occ.nome
				ORDER BY
					ol.mes,
					occ.nome
				
			";
			return $this->db->exec($query);
		}else{
			return false;
		}
	}

	function getDespesasByDiretoriaMes($dt_ini, $dt_fim){
		$query ="
			SELECT
				occ.nome,
				date_format(desp.data_pagamento, '%Y') ano,
				date_format(desp.data_pagamento, '%m') mes,
				SUM(valor) total_despesas
			FROM
				despesas desp INNER join
				orc_centro_custo occ ON(desp.id_centro_custo = occ.id)
			WHERE
				(desp.deleted IS NULL OR desp.deleted = 0) and
				desp.status ='pago'
		";

		if($dt_ini){
			$query .= "and desp.data_pagamento >= '$dt_ini' ";
		}

		if($dt_fim){
			$query .= "and desp.data_pagamento <= '$dt_fim' ";
		}

		$query .= "
			GROUP BY
				occ.nome,
				ano,
				mes
			ORDER BY
				total_despesas desc
		";
		return $this->db->exec($query);
	}
	
	function getRecebimentosByAno($dt_ini, $dt_fim, $limit = 10){
		$query ="
			SELECT 
				nf.codigo_cliente,
				co.razao_social,
				SUM(nf.valor_fatura) total_recebimentos
			FROM 
				notas_fiscais nf INNER join
				contratos co ON(nf.id_contrato = co.id)
			WHERE
				(nf.deleted IS NULL OR nf.deleted = 0) AND
				nf.status = 'recebido'
		";

		if($dt_ini){
			$query .= "and nf.recebido_em >= '$dt_ini' ";
		}

		if($dt_fim){
			$query .= "and nf.recebido_em <= '$dt_fim' ";
		}

		$query .= "
			GROUP BY
			    nf.codigo_cliente,
				co.razao_social
			ORDER BY
				total_recebimentos desc
		";

		if($limit){
			$query .= " limit $limit ";
		}
		return $this->db->exec($query, null, 'array');
	}

	function getRecebimentosByMes($dt_ini, $dt_fim, $contratos = null){
		$query ="
			SELECT 
				co.razao_social,
				nf.codigo_cliente,
				DATE_FORMAT(nf.recebido_em, '%m') mes,
				SUM(nf.valor_fatura) total_recebimentos
			FROM 
				notas_fiscais nf INNER join
				contratos co ON(nf.codigo_cliente = co.codigo_cliente)
			WHERE
				(nf.deleted IS NULL OR nf.deleted = 0) AND
				nf.status = 'recebido'
		";

		if($dt_ini){
			$query .= "and nf.recebido_em >= '$dt_ini' ";
		}

		if($dt_fim){
			$query .= "and nf.recebido_em <= '$dt_fim' ";
		}

		if(is_array($contratos)){
			$query .= " and nf.codigo_cliente in('".implode("','", $contratos)."') ";
		}elseif($contratos){
			$query .= " and nf.codigo_cliente = '$contratos'";
		}

		$query .= "
			GROUP BY
				co.razao_social,
				nf.codigo_cliente,
				mes
			ORDER BY
				total_recebimentos desc
		";
		return $this->db->exec($query);
	}
	
	function getOrcamentoByGrupoMes($ano){
		if($ano && is_numeric($ano)){
			$query ="
				SELECT
					ocg.nome,
					ol.mes,
					sum(ol.valor) total_lancamentos
				FROM
					orc_lancamento ol INNER join
					orc_grupo ocg ON(ol.id_grupo = ocg.id)
				WHERE
					(ol.deleted IS NULL OR ol.deleted = 0) and
					ol.ano = $ano
				GROUP BY
					ol.mes,
					ocg.nome
				ORDER BY
					ol.mes,
					ocg.nome
				
			";
			return $this->db->exec($query);
		}else{
			return false;
		}
	}

	function getDespesasByGrupoMes($dt_ini, $dt_fim){
		$query ="
			SELECT
				ocg.nome,
				date_format(desp.data_pagamento, '%Y') ano,
				date_format(desp.data_pagamento, '%m') mes,
				SUM(valor) total_despesas
			FROM
				despesas desp INNER join
				orc_grupo ocg ON(desp.id_grupo = ocg.id)
			WHERE
				(desp.deleted IS NULL OR desp.deleted = 0) and
				desp.status ='pago'
		";

		if($dt_ini){
			$query .= "and desp.data_pagamento >= '$dt_ini' ";
		}

		if($dt_fim){
			$query .= "and desp.data_pagamento <= '$dt_fim' ";
		}

		$query .= "
			GROUP BY
				ocg.nome,
				ano,
				mes
			ORDER BY
				total_despesas desc
		";
		return $this->db->exec($query);
	}
}
