<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */
class TarifadorModel extends MainModel
{
	//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
	public function __construct($controller = null ){
		parent::__construct($controller);
		$this->table = 'tarifacoes';
	}
	
	function getMovDiario($date = null){
		$query = " select sum(qtd_transacoes) qtd_transacoes, codigo_cliente, codigo_produto, codigo_modulo, data_tarifacao from tarifacoes where (deleted = 0 or deleted is null) ";
		if($date){
			$query .= " and data_tarifacao = '$date' ";
		}
		$query .= "group by codigo_cliente, codigo_produto, codigo_modulo, data_tarifacao order by codigo_cliente, codigo_produto, codigo_modulo, data_tarifacao desc";
		return $this->db->exec($query);
	}

	function getSumarizeMovDiario($start = null, $end = null, $id_contrato = null){
		$query = " select sum(qtd_transacoes) qtd_transacoes, codigo_cliente, codigo_produto, codigo_modulo from tarifacoes ";
		if($start && $end){
			$query .= " where data_tarifacao >= '$start' and data_tarifacao <= '$end 23:59:59' ";
		}

		if($id_contrato){
			$query .= " and id_contrato = $id_contrato ";
		}
		$query .= " group by codigo_cliente, codigo_produto, codigo_modulo";
		if($id_contrato){
			$query .= " ,id_contrato ";
		}
		$query .= " order by codigo_cliente, codigo_produto, codigo_modulo desc";
		$exec = $this->db->query($query);
		if($exec){
		// Retorna
			$return = $exec->fetchAll();
			return json_encode($return);
		}else{
			return false;
		}
	}
}