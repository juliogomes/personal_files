<?php
	/**
	 * Created by VScode.
	 * User: gabriel.santos
	 * Date: 14/06/2024
	 * Time: 12:20
	 */
	class TasksModel extends MainModel{
		//A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão. 
		public function __construct( $controller = null ){
			$this->setTable('tasks');
			parent::__construct( $controller );
		}

		function getTasksHoje( $dia, $task ){
			$dia_ini = $dia.' 00:00:00';
			$dia_fim = $dia.' 23:59:59';
			$query = " SELECT * FROM $this->table WHERE ( deleted is null or deleted = 0) and ativo = 1 AND ( ( '$dia_ini' >= periodo_ini AND '$dia_fim' <= periodo_fim ) OR tempo_indeterminado = 1 ) ";
			if( $task ){
				$query .= " and codigo = '$task' ";
			}
			$query .= " order by grupo asc, ordem asc ";
			return $this->db->exec( $query ); 
		}

		function getTasksByCode( $task ){
			$query = " select * from $this->table where ( deleted is null or deleted = 0 ) and ativo = 1 ";
			if( is_array( $task ) ){
				$query .= " and codigo in( '".implode( "','", $task )."' ) ";
			}elseif( !is_array( $task ) && !empty( $task ) ){
				$query .= " and codigo in( '".$task."' ) ";
			}
			$query .= " ORDER BY grupo, ordem ";
			return $this->db->exec( $query ); 
		}

		function getTasks( $id = null ){
			$query = "
				SELECT
					*
				FROM
					tasks tk
				WHERE
					( tk.deleted IS NULL OR tk.deleted = 0 )
			";

			if ( $id ) {
				$query .= " and tk.id = $id ";
			}

			return $this->db->exec($query);
		}
	}