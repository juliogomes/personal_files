<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 15:57
 */

class UsuariosModel extends MainModel
{
    public function __construct($controller = null ){
        $this->setTable('sistema_usuarios');
        parent::__construct($controller);
    }

    function updateStatus($status, $id){
        $param['status'] = $status;
        return $this->save($param, $id);
    }

    function getUser( $id = null ){
        $query = " 
            SELECT 
                usr.*,
                pr.nome nome_perfil,
                pr.permissoes,
                pr.owner,
                usr2.nome as nome_chefe,
                usr2.email as email_chefe
            FROM 
                sistema_usuarios usr left join 
                perfis pr on(usr.id_perfil = pr.id)
            LEFT JOIN
                sistema_usuarios usr2
            ON
                (usr.boss = usr2.id)
            WHERE 
                usr.status = 'ativo' ";
        if($id){
            $query .= " and usr.id = $id ";
        }
        return $this->db->exec($query);
    }

    function getUserByBoss( $id_boss ){
        $query = " 
            SELECT 
                usr.*,
                pr.nome nome_perfil,
                pr.permissoes,
                pr.owner,
                usr2.nome as nome_chefe,
                usr2.email as email_chefe
            FROM 
                sistema_usuarios usr left join 
                perfis pr on(usr.id_perfil = pr.id)
            LEFT JOIN
                sistema_usuarios usr2
            ON
                (usr.boss = usr2.id)
            WHERE 
                usr.status = 'ativo' ";
        if( $id_boss ){
            $query .= " and ( usr.boss = $id_boss or usr.id = $id_boss )";
        }
        return $this->db->exec($query);
    }

    function getUserByEmail( $email, $senha = null ){
        $query = " 
            SELECT 
                usr.*,
                pr.nome nome_perfil,
                pr.permissoes,
                ev.razao_social,
                ev.cnpj
            FROM 
                sistema_usuarios usr left join 
                perfis pr on(usr.id_perfil = pr.id) inner join
                empresa_vendedora ev on(ev.id = usr.id_empresa)
            WHERE 
                usr.status = 'ativo' and 
                usr.email_hash = '".md5($email)."' ";
        if( $senha ){
            $query .= " and usr.senha = '".md5($senha)."'";
        }

        $query .= " LIMIT 1";
        $exec = $this->db->query($query);
        // Verifica a consulta
        if ($exec){
            $fetch = $exec->fetch(PDO::FETCH_ASSOC);
            if($fetch['id']){
                $return = json_encode($fetch);
            }else{
                return false;
            }
            return $return;
        }else{
            $this->logged_in = false;
            $this->login_error = 'Internal error.';
            // Desconfigura qualquer sessão que possa existir sobre o usuário
            return false;
        }
    }

    function getUserBySenha($senha){
        $query = " SELECT * FROM sistema_usuarios WHERE status = 'ativo' and senha = '".md5($senha)."' limit 1 ";
        return $this->db->exec($query);
    }

    function getAllUser($id_user){
        $query = " 
        select 
            usu.*, 
            prf.nome nome_perfil                     
        FROM 
            sistema_usuarios usu 
        INNER JOIN 
            perfis prf 
        ON
            (usu.id_perfil = prf.id)
        ";
        
        if($id_user){
            $query .= " where usu.id = $id_user";
        }            
        
        $query .= " ORDER by usu.nome ";  
        return $this->db->exec($query);
    }

    function getUserByNomeDepartamento($nome_departamento = null, $id_user = null, $cargo = null){
        $query = "
            SELECT 
                * 
            FROM 
                sistema_usuarios 
            WHERE 
                status = 'ativo'
        ";

        if($nome_departamento){
            $query .= " and departamento = '$nome_departamento' ";
        }
        if($id_user){
            $query .= " and id = $id_user ";
        }
        if($cargo){
            $query .= " and cargo = '$cargo'";
        }
        $query .= " order by nome asc";
        return $exe = $this->db->exec($query);     
    }

    function getUsuarioClientePorCodigo($codigo){
        $query = "SELECT * FROM usuario_cliente WHERE code_validation = '$codigo' ";
        return $this->db->exec($query);
    }

    function getUsuarioClientePorEmail($email, $senha = null){
        $query = "SELECT uc.*, co.razao_social, co.nome_fantasia, co.codigo_cliente, co.data_assinatura, pr.codigo codigo_produto FROM usuario_cliente uc inner join contratos co on(co.id = uc.id_contrato) inner join produtos pr on(pr.id = co.id_produto) WHERE (uc.deleted is null or uc.deleted = 0) ";
        
        if($email){
            $query .= " and email_hash = '".md5($email)."'";
        }

        if($senha){
            $query .= " and senha = '".md5($senha)."'";
        }
        
        return $query;
        //return $this->db->exec($query);
    }

    function validaUsuario($param, $id){
        $this->table = 'usuario_cliente';
        return $this->save($param, $id);
        $this->table = 'sistema_usuarios';
    }
    
    function getUserByCnpf($cpf){
        if($cpf){
            $cpf = removeCaracteres($cpf, 'char');
            $query = " SELECT 
                * 
                FROM 
                    sistema_usuarios 
                WHERE 
                    status = 'ativo'
            ";
            if($cpf){
                $query .= " and cpf = '$cpf' ";   
            }
            return $this->db->exec($query);
        }else{
            return false;
        }
    }
    
    //By: Caio Freitas - 31/05/2023
    function getUserByPerfil($perfil = null){
        $query = " 
            SELECT 
                usr.*,
                pr.nome nome_perfil,
                pr.permissoes,
                pr.owner
            FROM 
                sistema_usuarios usr left join 
                perfis pr on(usr.id_perfil = pr.id)
            WHERE 
                usr.status = 'ativo' ";
        if($perfil){
            $query .= " and pr.nome = '$perfil'";
        }
        return $this->db->exec($query);
    }
    
    function getAlertas($usuario = null, $objeto = null){
		$query = "
            SELECT
                ut.email,
                ut.id
            FROM
                alertas a
            INNER JOIN
                sistema_usuarios ut
            ON
                (a.id_usuario = ut.id)
            WHERE
                (a.deleted = 0 OR a.deleted is NULL)
        ";

		if($usuario){
			$query .= " and a.id_usuario = $usuario";
		}

		if($objeto){
			$query .= " and a.objeto = '$objeto'";
		}		

		$query .= " ORDER BY id DESC";
		return $this->db->exec($query);
	}
	
	function getEmpresasCm( $id = null ){
        $query = "
        SELECT
            *
        FROM
            empresa_vendedora
        WHERE
            (deleted = 0 OR deleted is NULL)
        AND
            status = 'ativo'";

        if($id){
            $query .= " and id = $id";
        }

        $query .= " ORDER BY id ASC";
        return $this->db->exec($query);
    }

    public function getUsuarioJornada($id_usuario = null){
        $query = "
        SELECT
            jt.id,
            jt.nome as nome_jornada, 
            jt.id as id_jornada, 
            ju.data_inicio, 
            ju.id_jornada,
            ju.id_usuario,
            jt.nome, 
            ut.email, 
            jt.entrada, 
            jt.saida,            
            jt.dias_semana,
            jt.horas_maxima, 
            jt.horas_almoco, 
            jt.desconto, 
            jt.aderir_feriado, 
            jt.`status`, 
            ut.departamento            
        FROM
            rh_jornada_trabalho jt   
        INNER JOIN 
            rh_jornada_usuario ju
        ON 
            ju.id_jornada = jt.id       
        INNER JOIN 
            sistema_usuarios ut
        ON 
            ju.id_usuario = ut.id
        WHERE
            (ju.deleted is null or ju.deleted = 0) 
        AND
            ju.status = 'ativo' ";
       
        if($id_usuario){
            $query .= " and ju.id_usuario = '$id_usuario'";
        }
        $query .= " order by nome asc";
        return $this->db->exec($query);
    }
}
