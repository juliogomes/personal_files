<?php

	/**
	 * Created by VsCode.
	 * User: Gabriel Santos
	 * Date: 22/04/2024
	 */

    class UsuariosGrupoModel extends MainModel{
        public function __construct( $db = false, $controller = null ){
            $this->table = 'sistema_grupo';
            $this->db = $db;
            parent:: __construct( $controller );
        }

        public function getSistemaGrupo( ){
            $query = "
                SELECT
                    *
                FROM
                    sistema_grupo sg
                WHERE
                    ( sg.deleted IS NULL OR sg.deleted = 0 )
                ";

            return $this->db->exec($query);
        }
    }