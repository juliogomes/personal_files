<?php
    /**
     * Created by PhpStorm.
     * User: julio.gomes
     * Date: 14/10/2016
     * Time: 15:57
     */
    class webserviceModel extends MainModel{
        //A classe cadastro funciona como model padrão e carrega as funções do modulo de contratos que funciona como modulo padrão.
        public function __construct( $controller = null ){
            $this->table = 'ws_cadastro';
            parent::__construct($controller);
        }

        function getLogin( $id_cadastro, $usuario, $senha ){
            $param[] = $id_cadastro;
            $param[] = $usuario;
            $param[] = $senha;
            $query = "
                SELECT 
                    wsl.*,
                    wsc.id id_cadastro,
                    wsc.codigo
                FROM
                    $this->table wsc INNER join
                    ws_login wsl on ( wsc.id = wsl.id_cadastro )
                WHERE	
                    ( wsc.deleted IS NOT NULL OR wsc.deleted = 0 ) and
                    ( wsl.deleted IS NOT NULL OR wsl.deleted = 0 ) and
                    wsc.`status` = 'a' AND 
                    wsl.`status` = 'a' and
                    wsc.id       = ? and
                    wsl.usuario  = ? and
	                wsl.senha    = ?
            ";
            return $this->db->exec( $query, $param );
        }

        function getWsByCod( $codigo ){
            $param[] = $codigo;
            $query = "
                SELECT
                    wsc.*,
                    wsl.id id_login,
                    wse.id id_endpoint,
                    wse.nome nome_endpoint,
                    wse.identificador,
                    wse.descricao,
                    wse.url,
                    wse.tipo,
                    wse.auth
                FROM
                    ws_cadastro wsc INNER JOIN
                    ws_login wsl ON( wsl.id_cadastro = wsc.id ) INNER JOIN
                    ws_acesso wsa ON( wsa.id_origem = wsl.id ) INNER JOIN
                    ws_rel_endpoint wrel ON( wrel.id_acesso = wsa.id )  INNER join
                    ws_endpoint wse ON( wse.id = wrel.id_endpoint )
                WHERE
                    ( wsc.deleted  IS NULL OR  wsc.deleted = 0 ) and
                    ( wrel.deleted IS NULL OR wrel.deleted = 0 ) and
                    ( wsl.deleted  IS NULL OR  wsl.deleted = 0 ) and
                    ( wsa.deleted  IS NULL OR  wsa.deleted = 0 ) and
                    wsc.`status` = 'a' and
                    wsl.`status` = 'a' and
                    wse.`status` = 'a' and
                    wsc.codigo  = ?
            ";
            return $this->db->exec( $query, $param );
        }

        function getLastToken( $id_login ){
            if( $id_login && is_numeric( $id_login ) ){
                $param[] = $id_login;
                $query = "
                    SELECT 
                        * 
                    FROM 
                        ws_token wst 
                    WHERE
                        (wst.deleted is null or wst.deleted = 0 ) and
                        wst.id_login = ? 
                ";
                $query .= " ORDER BY wst.validade DESC LIMIT 1  ";
                return $this->db->exec( $query, $param );
            }else{
                return false;
            }
        }

        function getToken( $token ){
            $param[] = $token;
            $query = "
                SELECT 
                    * 
                FROM 
                    ws_token wst 
                WHERE
                    (wst.deleted is null or wst.deleted = 0 ) and
                    wst.token_acesso = ? 
            ";
            return $this->db->exec( $query, $param );
        }

        function getRequestByKey( $chave, $tipo = null ){
            $param[] = $chave;
            $query = "
                SELECT 
                    * 
                FROM 
                    ws_request wreq
                WHERE
                    ( wreq.deleted is null or wreq.deleted = 0 ) and
                    wreq.chave_request = ? 
            ";

            if( $tipo ){
                $param[] = $tipo;
                $query   .= " and wreq.tipo = ? ";
            }
            return $this->db->exec( $query, $param );
        }

        function getRequestByCpf( $cpf, $tipo = null ){
            $param[] = $cpf;
            $query = "
                SELECT 
                    * 
                FROM 
                    ws_request wreq
                WHERE
                    ( wreq.deleted is null or wreq.deleted = 0 ) and
                    wreq.numero_request = ? 
            ";
            
            if( $tipo ){
                $param[] = $tipo;
                $query   .= " and wreq.tipo = ? ";
            }
            return $this->db->exec( $query, $param );
        }
        
        function getRequestChaveRequest( $chave, $tipo = null ){
            $param[] = trim( $chave );
            $query = "
                SELECT 
                    * 
                FROM 
                    ws_request wreq
                WHERE
                    ( wreq.deleted is null or wreq.deleted = 0 ) and
                    wreq.chave_request = ? 
            ";

            if( $tipo ){
                $param[] = trim( $tipo );
                $query   .= " and wreq.tipo = ? ";
            }
            return $this->db->exec( $query, $param );
        }

        function getRequestNumeroRequest( $cpf, $tipo = null ){
            $param[] = $cpf;
            $query = "
                SELECT 
                    * 
                FROM 
                    ws_request wreq
                WHERE
                    ( wreq.deleted is null or wreq.deleted = 0 ) and
                    wreq.numero_request = ? 
            ";
            
            if( $tipo ){
                $param[] = $tipo;
                $query   .= " and wreq.tipo = ? ";
            }
            return $this->db->exec( $query, $param );
        }
    }