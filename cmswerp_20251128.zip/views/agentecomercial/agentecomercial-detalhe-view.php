<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
    <!--<![endif]-->
    <head>
        <!-- INCLUDE DEFAULT HEAD CSS & METAS -->
        <?php include 'template/head-css.inc' ?>
        <!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
        <!-- PAGE STYLES -->
        <script type="text/javascript">
            var sidebarItem = "agente comercial";
        </script>
        <!-- /PAGE STYLES -->
    </head>
    <body>
        <!-- MENU + WRAPPER -->
        <?php include "template/menu-wrapper.php" ?>
        <!-- /MENU + WRAPPER -->
        <!-- HEADER -->
        <ol class="breadcrumb">
            <li>TARIFA.CMSW.COM</li>
            <li>Agente Comercial</li>
        </ol>
        <h4 class="page-title">
            <?php
                if(empty($this->parametros[1])){
                    echo '<i class="fa fa-plus"></i> Novo Agente Comercial';
                }else{
                    echo '<i class="fa fa-edit"></i> Editar Agente Comercial';
                }
            ?>
        </h4>
        <!-- /HEADER -->
        <!-- CONTENT -->
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="col-md-12">
                        <form id="form_agente" action="" method="POST">
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="text-center">
                                        <a class="form-control btn btn-warning" href="/agentecomercial/index"><i class="fa fa-retweet"></i> VOLTAR </a>	
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="text-center">
                                        <button type="button" id="sync_crystal" class="btn btn-default" style="width:100%"><i class="fa fa-refresh"></i> SYNC CRYSTAL </button>	
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-success" style="width:100%"><i class="fa fa-file-o"></i> GRAVAR AGENTE </button>	
                                    </div>
                                </div>
                            </div>
                            <br />
                            <legend><i class="fa fa-address-card"></i> CADASTRO</legend>
                            
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="tipo_documento">TIPO PESSOA</label>
                                        <select class="form-control select" name="tipo_documento" id="tipo_documento">
                                            <option <?= (isset($records[0]) && $records[0]->tipo_documento == 'cnpj')?'selected':'' ?> value="cnpj">CNPJ</option>
                                            <option <?= (isset($records[0]) && $records[0]->tipo_documento == 'cpf')?'selected':'' ?> value="cpf">CPF</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="cnpj">CNPJ / CPF</label>
                                        <input type="text" class="form-control mascara" id="numero_documento" placeholder="99.999.999/9999-99" value="<?= isset($records[0])?$records[0]->numero_documento:null ?>" name="numero_documento"/>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="insc_municipal">INSCRIÇÃO MUNICIPAL </label>
                                        <input type="text" class="form-control" id="numero_documento" value="<?= isset($records[0])?$records[0]->insc_municipal:null ?>" name="insc_municipal"/>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="insc_estadual">INSCRIÇÃO ESTADUAL</label>
                                        <input type="text" maxlength="150" class="form-control" value="<?= isset($records[0])?$records[0]->insc_estadual:null ?>" name="insc_estadual" />
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="razao_social">NOME / NOME FANTASIA</label>
                                        <input type="text" maxlength="150" class="form-control" value="<?= isset($records[0])?$records[0]->nome:null ?>" name="nome" />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="nome_fantasia">RAZÃO SOCIAL</label>
                                        <input type="text" maxlength="150" class="form-control" value="<?= isset($records[0])?$records[0]->razao_social:null ?>" name="razao_social"/>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="codigo_agente">CÓDIGO AGENTE</label>
                                        <input type="text" class="form-control" placeholder="PREENCHIMENTO AUTOMATICO" value="<?= isset($records[0])?$records[0]->codigo_agente:null ?>" id="codigo_agente" name="codigo_agente" readonly  disabled />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="numero_contrato">ID CONTRATO</label>
                                        <input type="text" class="form-control" placeholder="PREENCHIMENTO AUTOMATICO" value="<?= isset($records[0])?$records[0]->numero_contrato:null ?>" id="numero_contrato" name="numero_contrato" readonly />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="id_empresa">EMPRESA</label>
                                        <select name='id_empresa' class="form-control select">              
                                            <?php
                                                foreach( $empresa as $key=>$value ){
                                                    if( $value->id == $records[0]->id_empresa ){
                                                        echo '<option value ="'.$value->id.'" selected>'.strtoupper( $value->nome_fantasia ).'</option>';
                                                    }else{
                                                        echo '<option value ="'.$value->id.'" selected>'.strtoupper( $value->nome_fantasia ).'</option>';
                                                    }
                                                }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="id_produto">PRODUTO</label>
                                        <?php
                                            if(!empty( $this->parametros[1]) ){
                                                echo "<select disabled name='id_produto' class='form-control select'>";
                                            }else{
                                                echo "<select name='id_produto' class='form-control select'>";
                                            }
                                        ?>
                                            <option value=''>Selecione</option>
                                        <?php
                                            foreach( $produto as $key=>$value ){                                               
                                                echo '<option value ="'.$value->id.'" selected>'.strtoupper( $value->nome ).'</option>';                                               
                                            }
                                        ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="data_assinatura">DATA DE ASSINATURA</label>
                                        <input type="text" class="form-control datepast2" id="data_assinatura" placeholder="Dia/Mês/Ano" value="<?= isset($records[0])?convertDate($records[0]->data_assinatura):null ?>" name="data_assinatura"/>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="duracao_contrato">DURAÇÃO DE CONTRATO</label>
                                        <input type="text" class="form-control" placeholder="Número de meses" value="<?= isset($records[0])?$records[0]->duracao_contrato:null ?>" name="duracao_contrato"/>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="renovacao_automatica">RENOVAÇÃO AUTOMATICA</label>
                                        <select name="renovacao_automatica" class="form-control select">
                                            <option value=''>Selecione</option>
                                            <option <?= (isset($records[0]) && $records[0]->renovacao_automatica == '0')?'selected':'' ?> value="0">NÃO</option>
                                            <option <?= (isset($records[0]) && $records[0]->renovacao_automatica == '1')?'selected':'' ?> value="1">SIM</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <legend><i class="fa fa-plus"></i> INFORMAÇÕES ADICIONAIS</legend>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="id_empresa">PERCENTUAL DE COMISSÃO (%)</label>
                                        <input type="text" class="form-control mask-money" id="percentual_comissao" name="percentual_comissao" placeholder="10" value="<?= ( isset( $records[0]->percentual_comissao ) )?$records[0]->percentual_comissao:null; ?>" />
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <label for="status">STATUS</label>
                                    <select name='status' class="form-control select">
                                        <option value=''>Selecione</option>
                                        <option value='inativo' <?= (isset($records[0]) && $records[0]->status == 'inativo')?'selected':'' ?> >INATIVO</option>
                                        <option value='ativo' <?= (isset($records[0]) && $records[0]->status == 'ativo')?'selected':'' ?> >ATIVO</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <br>
                                    <label for="info">OBSERVAÇÕES</label>
                                    <textarea name="info" id="info" rows="7" class="form-control"><?= ( isset( $records[0]->info ) )?$records[0]->info:null; ?></textarea>	
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-md-8">
                                    <legend> <i class="fa fa-envelope"></i> ENDEREÇOS </legend>
                                    <button type="button" id="btn_modal_endereco" class="btn btn-success"><i class="fa fa-plus"></i> NOVO ENDEREÇO</button>
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>TIPO</th>
                                                <th>CEP</th>
                                                <th>LOGRADOURO</th>
                                                <th>BAIRRO</th>
                                                <th>COMPLEMENTO.</th>
                                                <th>CIDADE</th>
                                                <th>ESTADO</th>
                                                <th>PAIS</th>
                                                <th>AÇÕES</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if( isset( $meta_endereco ) ){ ?>
                                                <?php foreach( $meta_endereco as $key => $value){ ?>
                                                    <tr>
                                                        <td><?= strtoupper($value->tipo_logradouro); ?></td>
                                                        <td><?= $value->cep; ?></td>
                                                        <td><?= $value->logradouro.' '.$value->numero_logradouro; ?></td>
                                                        <td><?= $value->bairro; ?></td>
                                                        <td><?= $value->complemento; ?></td>
                                                        <td><?= $value->cidade; ?></td>
                                                        <td><?= $value->uf; ?></td>
                                                        <td><?= $value->pais; ?></td>
                                                        <td><button type="button" class="btn btn-danger deletar_metadado" data-id_agente="<?= $value->id_agente; ?>" value="<?= $value->uniq_id; ?>" ><i class="fa fa-trash"></i></button></td>
                                                    </tr>
                                                <?php } ?>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-md-4">
                                    <legend> <i class="fa fa-phone"></i> CONTATOS</legend>
                                    <button type="button" id="btn_modal_contato" class="btn btn-success"><i class="fa fa-plus"></i> NOVO CONTATO</button>
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>TIPO CONTATO</th>
                                                <th>CLASS.</th>
                                                <th>NUMERO/EMAIL</th>
                                                <th>AÇÕES</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if( isset( $meta_contatos ) ){ ?>
                                                <?php foreach( $meta_contatos as $key => $value){ ?>
                                                    <?php if( $value->tipo_contato == 'email' ){ ?>
                                                    <tr>
                                                        <td><?= strtoupper( $value->tipo_contato ); ?></td>
                                                        <td><?= strtoupper( $value->tipo_classificacao ); ?></td>
                                                        <td><?= strtoupper( $value->email ); ?> </td>
                                                        <td><button type="button" class="deletar_metadado btn btn-danger" data-id_agente="<?= $value->id_agente; ?>" value="<?= $value->uniq_id; ?>" ><i class="fa fa-trash"></i></button></td>
                                                    </tr>
                                                    <?php }else{ ?>
                                                        <tr>
                                                        <td><?= strtoupper( $value->tipo_contato ); ?></td>
                                                        <td><?= strtoupper( $value->tipo_classificacao ); ?></td>
                                                        <td><?= $value->numero_telefone; ?> </td>
                                                        <td><button type="button" class="deletar_metadado btn btn-danger" data-id_agente="<?= $value->id_agente; ?>" value="<?= $value->uniq_id; ?>" ><i class="fa fa-trash"></i></button></td>
                                                    </tr>
                                                    <?php } ?>
                                                <?php } ?>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- INICIO MODAL -->
        <div class="modal fade" tabindex="-1" role="dialog" id="contatoModal">
			<div class="modal-dialog " role="document">
				<div class="modal-content">
					<div class="modal-header">
                        <i class="fa fa-plus"></i> <span class="modal-title" id="header_arquivo"><b> NOVO CONTATO</b></span>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					</div>
					<form method="post" name="form_contato" id="form_contato" >
						<div class="modal-body">
							<div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="tipo_contato">TIPO DE CONTATO</label>
                                        <input type="hidden" name="meta_id_origem" id="meta_id_origem" class="form-control" value=" <?= $this->parametros[1] ?>" />
                                        <select class="form-control select" name="tipo_contato" id="tipo_contato">
                                            <option value="email">EMAIL</option>
                                            <option value="telefone">TELEFONE</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="tipo_classificacao">CLASSIFICAÇÃO DO CONTATO</label>
                                        <select class="form-control select" name="tipo_classificacao" id="tipo_classificacao">
                                            <option value="pessoal">PESSOAL</option>
                                            <option value="comercial">COMERCIAL</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4 bloco_telefone">
                                    <div class="form-group">
                                        <label for="tipo_telefone">TIPO TELEFONE</label>
                                        <select class="form-control select" name="tipo_telefone" id="tipo_telefone">
                                            <option value="celular">CELULAR</option>
                                            <option value="fixo">FIXO</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row bloco_telefone ">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="numero_telefone">TELEFONE</label>
                                        <input type="text" name="numero_telefone" id="numero_telefone" class="form-control" value="" placeholder="(xx) xxxx-xxxxx" />
                                    </div>
                                </div>
                            </div>
                            <div class="row bloco_email">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="email">EMAIL</label>
                                        <input type="text" name="email" id="endereco_email" class="form-control" value="" placeholder="abcd@abcd.com" />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-large btn-block btn-success"><i class="fa fa-save"></i> GRAVAR</button>
                                    </div>
                                </div>
                            </div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
						</div>
					</form>
				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>
        <div class="modal fade" tabindex="-1" role="dialog" id="enderecoModal">
			<div class="modal-dialog " role="document">
				<div class="modal-content">
					<div class="modal-header">
                        <i class="fa fa-plus"></i> <span class="modal-title" id="header_arquivo"><b> NOVO ENDEREÇO</b></span>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					</div>
					<form method="post" name="form_endereco" id="form_endereco" >
						<div class="modal-body">
							<div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <input type="hidden" name="meta_id_origem" id="meta_id_origem" class="form-control" value=" <?= $this->parametros[1] ?>" />
                                        <label for="tipo_logradouro">ORIGEM DO CONTATO</label>
                                        <select class="form-control select" name="tipo_logradouro" id="tipo_logradouro">
                                            <option <?= (isset($records[0]) && $records[0]->tipo_contato == 'pessoal')?'selected':'' ?> value="pessoal">PESSOAL</option>
                                            <option <?= (isset($records[0]) && $records[0]->tipo_contato == 'comercial')?'selected':'' ?> value="comercial">COMERCIAL</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="cep">CEP</label>
                                        <input type="text" class="form-control cep" name="cep" id="cep" class="form-control" value="" placeholder="XXXXX-XXX" />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="logradouro">LOGRADOURO</label>
                                        <input type="text" name="logradouro" id="logradouro" class="form-control" value="" />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="numero_logradouro">NUMERO</label>
                                        <input type="text" name="numero_logradouro" id="numero_logradouro" class="form-control" value="" />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="complemento">COMPLEMENTO</label>
                                        <input type="text" name="complemento" id="complemento" class="form-control" value="" />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="bairro">BAIRRO</label>
                                        <input type="text" name="bairro" id="bairro" class="form-control" value="" />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="cidade">CIDADE</label>
                                        <select name="cidade" maxlength="40" id="cidade" class="form-control cidade-uf" data-autocep-select="localidade">
                                            <option value=""></option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="uf">ESTADO</label>
                                        <select name="uf" id="uf" class="form-control uf-cidade" data-pair="cidade" data-autocep-select="uf" >
                                            <option value=""></option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="pais">Pais</label>
                                        <select class="form-control" name="pais_codigo" id="pais_codigo" required="required" >
                                            <option>SELECIONE O PAIS...</option>
                                            <?php foreach ( getDadosPaises() as $key => $value ){ ?>
                                                <option value="<?= $value->codigo ?>" <?= ( $records[0]->pais_codigo == $value->codigo )?'selected':null; ?> ><?= $value->nome ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button type="submit" id="btn_gravar_endereco" class="btn btn-large btn-block btn-success"><i class="fa fa-save"></i> GRAVAR</button>
                                    </div>
                                </div>
                            </div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
						</div>
					</form>
				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>
        <!-- END MODAL -->
        <!-- INICIO WRAPPER -->
        <?php include "template/end-menu-wrapper.html" ?>
        <!-- /END WRAPPER -->
        <!-- INCLUDE DEFAULT SCRIPTS -->
        <?php include 'template/scripts.inc' ?>
        <?php include "template/modal_sistema.php" ?>
        <!-- /INCLUDE DEFAULT SCRIPTS -->
        <!-- PAGE SCRIPTS -->
        <script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
        <!-- <script type="text/javascript" src="/libs/ckeditor/ckeditor.js"></script>
        <script type="text/javascript" src="/libs/ckeditor/adapters/jquery.js"></script> -->
        <!-- <script src="//cdn.ckeditor.com/4.4.5/standard-all/ckeditor.js"></script> -->
        <script type="text/javascript">
            $(document).ready(function(){
                $('.bloco_telefone').hide();
                $("#numero_telefone").mask('(00) 00000-0000');
                $('.mascara').mask('00.000.000/0000-00');
                $('#tipo_documento').on('change', function(){
                    var tipo_documento = $(this).val();
                    console.log( tipo_documento );
                    switch ( tipo_documento ) {
                        case 'cpf':
                            $('.mascara').mask('000.000.000-00');
                        break;
                        case 'cnpj':
                            $('.mascara').mask('00.000.000/0000-00');
                        break;
                    }
                });

                $('#cep').on('change', function(){
                    var cep = $('#cep').val();
                    var url = "https://viacep.com.br/ws/"+cep.replace(/[^0-9]/g, '')+"/json/";
                    $.ajax({
                        url : url,
                        type : "get",
                        dataType: 'json',
                        success: function(dados){
                            console.log(dados);           
                            $('#logradouro').val(dados.logradouro);
                            $('#complemento').val(dados.complemento);
                            $('#bairro').val(dados.bairro);
                            $('#uf').selectpicker('val', dados.uf);
                            $('#uf').trigger("change");
                            $('#cidade').selectpicker('val', dados.localidade);
                            $('#cidade').trigger("change");                      
                        }
                    });
                });

                $('#btn_modal_contato').click(function(){
                    $('#contatoModal').modal('show');
                });

                $('#btn_modal_endereco').click(function(){
                    $('#enderecoModal').modal('show');
                });

                $('#tipo_contato').change( function(){
                    var valor = $(this).val();
                    switch ( valor ) {
                        case 'telefone':
                            $('#endereco_email').val('');
                            $('.bloco_telefone').show();
                            $('.bloco_email').hide();
                        break;
                        case 'email':
                            $('#numero_telefone').val('');
                            $('.bloco_email').show();
                            $('.bloco_telefone').hide();
                        break;
                    }
                    console.log( valor );
                });
                
                $('.deletar_metadado').click( function(e){
                    var id        = $(this).val();
                    var id_agente = $(this).data('id_agente');
                    var url = "<?= HOME_URI.$this->nome_modulo.'/apagarMetaDados/'; ?>";
                    console.log( id, url );
                    $.ajax({
                        url: url,
                        data: {id:id, id_agente:id_agente},
                        type: 'POST',
                        success: function ( data ){
                            var obj_json = JSON.parse( data );
                            console.log(obj_json);
                            if(obj_json.codigo == 0){
                                var info = '<p>Ir Para: </p><p><a class="form-control btn btn-primary" href="/contratos/index">Lista de contratos </a> <a class="form-control btn btn-warning" href="/cobranca/ListaPrecoCliente/id/<?= $this->parametros[1]?>/order/1">Lista de preços </a></p>';
                                $('#painel_success_msg').text( obj_json.mensagem );
                                $('#modal_sucesso_sistema').modal('show');
                                location.reload();
                            }else{
                                $('#painel_error_msg').text(obj_json.mensagem);
                                $('#modal_erro_sistema').modal('show');
                            }
                        },
                        error: function (error){
                            alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
                        }
                    });
                });

                $('#form_endereco').submit(function(e){
                    e.preventDefault();
                    var url_form   = "<?= HOME_URI.$this->nome_modulo.'/saveEndereco/id/'.$this->parametros[1]; ?>";
                    var dados_form = $(this).serialize();
                    console.log( dados_form );
                    $.ajax({
                        url: url_form,
                        data: dados_form,
                        type: 'POST',
                        success: function ( data ){
                            var obj_json = JSON.parse( data );
                            console.log(obj_json);
                            if(obj_json.codigo == 0){
                                $('#painel_success_msg').text( obj_json.mensagem );
                                $('#modal_sucesso_sistema').modal('show');			
                                location.reload();
                            }else{
                                $('#painel_error_msg').text(obj_json.mensagem);
                                $('#modal_erro_sistema').modal('show');
                            }
                        },
                        error: function (error){
                            alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
                        }
                    });
                });

                $('#form_contato').submit(function(e){
                    e.preventDefault();
                    var url_form   = "<?= HOME_URI.$this->nome_modulo.'/saveContato/id/'.$this->parametros[1]; ?>";
                    var dados_form = $(this).serialize();
                    console.log( dados_form );
                    $.ajax({
                        url: url_form,
                        data: dados_form,
                        type: 'POST',
                        success: function ( data ){
                            var obj_json = JSON.parse( data );
                            console.log(obj_json);
                            if(obj_json.codigo == 0){
                                $('#painel_success_msg').text( obj_json.mensagem );
                                $('#modal_sucesso_sistema').modal('show');			
                                location.reload();
                            }else{
                                $('#painel_error_msg').text(obj_json.mensagem);
                                $('#modal_erro_sistema').modal('show');
                            }
                        },
                        error: function (error){
                            alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
                        }
                    });
                });

                $('#form_agente').submit(function(e){
                    e.preventDefault();
                    var url_form   = "<?= HOME_URI.$this->nome_modulo.'/save/id/'.$this->parametros[1].''; ?>";
                    var dados_form = $(this).serialize(); 
                    $.ajax({
                        url: url_form,
                        data: dados_form,
                        type: 'POST',
                        success: function ( data ){
                            var obj_json = JSON.parse( data );
                            console.log(obj_json);
                            if( obj_json.codigo == 0 ){
                                $('#painel_success_msg').text( obj_json.mensagem );
                                $('#modal_sucesso_sistema').modal('show');			
                                $('#modal_sucesso_sistema').on('hidden.bs.modal', function () {
                                    window.location.href = '/agentecomercial/detalhe/id/'+obj_json.output;
                                });
                            }else{
                                $('#painel_error_msg').text(obj_json.mensagem);
                                $('#modal_erro_sistema').modal('show');
                            }
                        },
                        error: function (error){
                            alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
                        }
                    });
                });

                $('#sync_crystal').click( function( e ){
                    var url_form   = "<?= HOME_URI.$this->nome_modulo.'/syncCrystal/id/'.$this->parametros[1].''; ?>";
                    $.ajax({
                        url: url_form,
                        type: 'POST',
                        success: function ( data ){
                            var obj_json = JSON.parse( data );
                            console.log(obj_json);
                            if(obj_json.codigo == 0){
                                var info = '<p>Ir Para: </p><p><a class="form-control btn btn-primary" href="/contratos/index">Lista de contratos </a> <a class="form-control btn btn-warning" href="/cobranca/ListaPrecoCliente/id/<?= $this->parametros[1]?>/order/1">Lista de preços </a></p>';
                                $('#btn_ok').hide();
                                $('#modal_info').html( info );
                                $('#painel_success_msg').text( obj_json.mensagem );
                                $('#modal_sucesso_sistema').modal('show');			
                                $('#modal_sucesso_sistema').on('hidden.bs.modal', function () {
                                    window.location.href = '/agentecomercial/index';
                                });
                            }else{
                                $('#painel_error_msg').text(obj_json.mensagem);
                                $('#modal_erro_sistema').modal('show');
                            }
                        },
                        error: function (error){						
                            alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
                        }
                    });
                });

                <?php if (isset($records[0])){ ?>
                    function justNumber(string){
                        var numsStr = string.replace(/[^0-9]/g,'');
                        return parseInt(numsStr);
                    }

                    $(function(){
                        var estado = '<?= $records[0]->estado ?>';
                        var cidade = '<?= $records[0]->cidade ?>';
                        setTimeout(function(){
                        $('#uf').selectpicker('val', estado);
                        if (estado) {
                            $('#uf').trigger("change");
                        }
                        $('#cidade').selectpicker('val', cidade);
                        if (cidade) {
                            $('#cidade').trigger("change");
                        }
                        },1000);
                    });
                <?php } ?> 
            });
        </script>
        <!-- /PAGE SCRIPTS -->
    </body>
</html>