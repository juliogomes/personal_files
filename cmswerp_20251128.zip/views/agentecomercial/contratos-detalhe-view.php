<?php
	echo 'Apagar 14/11/2023';
	exit;
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "contratos";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
        <li>Agente Comercial</li>
		<li>Contratos</li>
	</ol>
	<h4 class="page-title">
		<?php
            if( isset( $agente_comercial[0]->nome_fantasia ) ){
			    echo '<i class="fa fa-plus"></i> Novo Contrato Crystal - '.$agente_comercial[0]->nome_fantasia;	
            }else{
                echo '<i class="fa fa-plus"></i> Novo Contrato Crystal';
            }
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-11" style="margin-left:1%;margin-right:5%">
				<form id="form_contrato" action="#" name="save" method="POST">
                    <!-- <legend>AGENTE COMERCIAL</legend> -->
					<!-- <div class="row">
                        <div class='col-md-12'>
                            <div class="form-group">
                                <label for="agente_comercial">AGENTE COMERCIAL</label>
                                <input type="text" class="form-control" id="agente_comercial" value="<?php //isset($agente_comercial[0])?$agente_comercial[0]->nome_fantasia:null?>" readonly disabled />
                            </div>
                        </div>
                    </div> -->
					<fieldset>
						<legend>Cliente</legend>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="codigo_cliente">Codigo do Cliente</label>
									<input type="text" class="form-control" id="codigo_cliente" placeholder="preenchimento automatico" maxlength="8" minlength="8" value="<?= isset($records[0])?$records[0]->codigo_cliente:'preenchimento automatico' ?>" name="codigo_cliente" readonly  disabled >
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="cnpj">CNPJ</label>
									<input type="text" class="form-control masked" id="cnpj" placeholder="99.999.999/9999-99" value="<?= isset($records[0])?$records[0]->cnpj:null ?>" name="cnpj" data-masked="00.000.000/0000-00"/>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="cnpj_fantasia">CNPJ FANTASIA</label>
									<input type="text" class="form-control masked" id="cnpj_fantasia" placeholder="99.999.999/9999-99" value="<?= isset($records[0])?$records[0]->cnpj_fantasia:null ?>" name="cnpj_fantasia" data-masked="00.000.000/0000-00"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="razao_social">Razao Social</label>
									<input type="text" maxlength="150" class="form-control" value="<?= isset($records[0])?$records[0]->razao_social:null ?>" name="razao_social" required/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="nome_fantasia">Nome Fantasia</label>
									<input type="text" maxlength="150" class="form-control" value="<?= isset($records[0])?$records[0]->nome_fantasia:null ?>" name="nome_fantasia"/>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Contrato</legend>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="numero_contrato">Número Contrato</label>
									<input type="text" class="form-control" placeholder="preenchimento automatico" value="<?= isset($records[0])?$records[0]->numero_contrato:null ?>" id="numero_contato" name="numero_contrato" readonly  disabled />
								</div>
							</div>
							<div class="col-md-8">
								<div class="form-group">
									<label for="id_produto">Produto</label>									
									<select name='id_produto' class='form-control'>									
										<?php
                                            foreach($this->produtos_list as $key=>$value){
                                                if($value->id_produto == 4000001){
                                                    echo '<option value ="'.$value->id_produto.'" selected>'.strtoupper($value->nome_produto).'</option>';
                                                }
                                            }
									    ?>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="segmento">Segmento</label>
									<select name="segmento" class="form-control select">
										<option value="">Selecione</option>
										<?php
										foreach ($this->globals['SEGMENTO'] as $key => $value) {
											if(strtoupper($key) == strtoupper($records[0]->segmento)){
												echo '<option value="'.$key.'" selected>'.strtoupper($value).'</option>';
											}else{
												echo '<option value="'.$key.'" >'.$value.'</option>';
											}
										}
										?>
									</select>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="moeda">Moeda</label>
									<select name="moeda" class="form-control select">
										<option value=''>Selecione</option>
										<option <?= (isset($records[0]) && strtolower($records[0]->moeda) == 'real')?'selected':'' ?>  value="real">REAL</option>
										<option <?= (isset($records[0]) && strtolower($records[0]->moeda) == 'dolar')?'selected':'' ?> value="dolar">DOLAR</option>
										<option <?= (isset($records[0]) && strtolower($records[0]->moeda) == 'euro')?'selected':'' ?> value="euro">EURO</option>
									</select>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="preco_com_imposto">Preço Com Imposto</label>
									<select class="form-control select" name="preco_com_imposto" id="preco_com_imposto">
										<!-- <option value=''>Selecione</option> -->
										<option <?= (isset($records[0]) && $records[0]->preco_com_imposto == '0')?'selected':'' ?> value="0">NÃO</option>
										<option <?= (isset($records[0]) && $records[0]->preco_com_imposto == '1')?'selected':'' ?> value="1">SIM</option>
									</select>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Endereço</legend>
						<div class="row">
							<div class="col-md-2">
								<div class="form-group">
									<label for="cep">CEP</label>
									<input type="text" maxlength="9" class="form-control cep" id="cep" placeholder="99999-999"value="<?= isset($records[0])?$records[0]->cep:null ?>" name="cep"/>
								</div>
							</div>
							<div class="col-md-8">
								<div class="form-group">
									<label for="endereco">Endereço</label>
									<input type="text" maxlength="75" class="form-control" value="<?= isset($records[0])?$records[0]->endereco:null ?>" name="endereco" data-autocep-input="logradouro" required />
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="numero">Numero</label>
									<input type="text" maxlength="9" class="form-control" value="<?= isset($records[0])?$records[0]->numero:null ?>" name="numero" data-autocep-input="numero" required/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label for="complemento">Complemento</label>
									<input type="text" maxlength="30" class="form-control" value="<?= isset($records[0])?$records[0]->complemento:null ?>" name="complemento" data-autocep-input="complemento"/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="bairro">Bairro</label>
									<input type="text" maxlength="40" class="form-control" value="<?= isset($records[0])?$records[0]->bairro:null ?>" name="bairro" data-autocep-input="bairro"/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="cidade">Cidade</label>
										<select name="cidade" maxlength="40" id="cidade" class="form-control cidade-uf" data-autocep-select="localidade">
											<option value=""></option>
										</select>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="estado">Estado</label>
									<select name="estado" id="estado" class="form-control uf-cidade" data-pair="cidade" data-autocep-select="uf" >
										<option value=""></option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="url">Site</label>
									<input type="text" class="form-control" id="url" placeholder="http://www.site.com.br" value="<?= isset($records[0])?$records[0]->url:null ?>" name="url"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="emal_nf">Email para envio da Nota Fiscal (maximo de 3 emails separados por ; e sem espaços)</label>
									<input type="text" maxlength="151" class="form-control" id="email_nf" placeholder="email@email.com" value="<?= isset($records[0])?$records[0]->email_nf:null ?>" name="email_nf"/>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Assinatura</legend>
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label for="data_assinatura">Data da Assinatura</label>
									<input type="text" class="form-control datepast2" id="data_assinatura" placeholder="Dia/Mês/Ano" value="<?= isset($records[0])?convertDate($records[0]->data_assinatura):null ?>" name="data_assinatura"/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="data_reajuste">Data de rejuste</label>
									<input type="text" class="form-control datepast2" id="data_reajuste" placeholder="Dia/Mês/Ano" value="<?= isset($records[0])?convertDate($records[0]->data_reajuste):null ?>" name="data_reajuste"/>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="duracao_contrato">Duração do Contrato</label>
									<input type="text" class="form-control" placeholder="Número de meses" value="<?= isset($records[0])?$records[0]->duracao_contrato:null ?>" name="duracao_contrato"/>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="renovacao_automatica">Renovação Automatica</label>
									<select name="renovacao_automatica" class="form-control select">
										<option value=''>Selecione</option>
										<option <?= (isset($records[0]) && $records[0]->renovacao_automatica == '0')?'selected':'' ?> value="0">NÃO</option>
										<option <?= (isset($records[0]) && $records[0]->renovacao_automatica == '1')?'selected':'' ?> value="1">SIM</option>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="contrato_indeterminado">Indeterminado</label>
									<select name="contrato_indeterminado" class="form-control select">
										<option value=''>Selecione</option>
										<option <?= (isset($records[0]) && $records[0]->contrato_indeterminado == '1')?'selected':'' ?> value="1">SIM</option>
										<option <?= (isset($records[0]) && $records[0]->contrato_indeterminado == '0')?'selected':'' ?> value="0">NÃO</option>
									</select>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Comissão</legend>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="id_empresa">Empresa Vendedora</label>
									<select name='id_empresa' class="form-control">										
										<?php
                                            foreach($this->empresa_cm as $key=>$value){
                                                if($value->id == 1000003){
                                                    echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome_fantasia).'</option>';
                                                }											
                                            }
										?>
									</select>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Reajuste</legend>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="data_reajuste">Mes de reajuste</label>
									<input type="text" class="form-control" maxlength="2" minlength="2" value="<?= isset($mes_reajuste)?$mes_reajuste:'preencimento automatico' ?>" disabled="disabled" />
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="indice_reajuste">Indice de Reajuste</label>
									<select name='indice_reajuste' class="form-control select">
										<option value=''>Selecione</option>
										<option value='igpm' <?= (isset($records[0]) && $records[0]->indice_reajuste == 'igpm')?'selected':null; ?> >IGPM</option>
										<option value='ipca' <?= (isset($records[0]) && $records[0]->indice_reajuste == 'ipca')?'selected':null; ?>>IPCA</option>
									</select>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Implantação</legend>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="valor_implantacao">Valor de Implantação</label>
									<input type="text" class="form-control mask-money" placeholder="R$" value="<?= isset($records[0])?$records[0]->valor_implantacao:null ?>" name="valor_implantacao"/>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="parcelado_em">Parcelado Em</label>
									<select name="parcelado_em" class="form-control select">
										<option value="">Selecione</option>
										<option <?= (isset($records[0]) && $records[0]->parcelado_em == '1')?'selected':'' ?> value="1">1</option>
										<option <?= (isset($records[0]) && $records[0]->parcelado_em == '2')?'selected':'' ?> value="2">2</option>
										<option <?= (isset($records[0]) && $records[0]->parcelado_em == '3')?'selected':'' ?> value="3">3</option>									
									</select>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="primeira_parcela_em">Primeira Parcela Em</label>
									<input type="text" class="form-control datepast" placeholder="Dia/Mês/Ano" value="<?= isset($records[0])?convertDate($records[0]->primeira_parcela_em):null ?>" name="primeira_parcela_em"/>
								</div>
							</div>
						</div>
					</fieldset>
					<!-- <fieldset>
						<legend>Isenção</legend>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="isento_de">Isento de:</label>
									<input type="text" class="form-control datepast" placeholder="Dia/Mês/Ano" value="<?= isset($records[0])?convertDate($records[0]->isento_de):null ?>" name="isento_de" id= "isento_de"/>
								</div>
							</div>
								<div class="col-md-4">
								<div class="form-group">
									<label for="isento_ate">Isento até:</label>
									<input type="text" class="form-control datepast" placeholder="Dia/Mês/Ano" value="<?= isset($records[0])?convertDate($records[0]->isento_ate):null ?>" name="isento_ate" id= "isento_ate"/>
								</div>
							</div>
						</div>
					</fieldset> -->
					<fieldset>
						<legend>Faturamento</legend>
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label for="data_corte_faturamento"> Tipo de Tarifação </label>
									<select name="tipo_tarifacao" class="form-control select">
										<option <?= (isset($records[0]) && $records[0]->tipo_tarifacao == 'degrau')?'selected':'' ?> value="degrau">Degrau tarifario</option>
										<option <?= (isset($records[0]) && $records[0]->tipo_tarifacao == 'linear')?'selected':'' ?> value="linear">Linear</option>
									</select>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="data_corte_faturamento"> Faturamento dia </label>
									<input type="text" class="form-control " placeholder=" Faturamento todo dia" value="<?= isset($records[0])?$records[0]->data_corte_faturamento:null ?>" name="data_corte_faturamento"/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="vencimento_todo_dia"> Vencimento todo dia </label>
									<input type="text" class="form-control " placeholder=" Vencimento todo dia " value="<?= isset($records[0])?$records[0]->vencimento_todo_dia:null ?>" name="vencimento_todo_dia"/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="numero_dias_apos_corte">dias faturamento </label>
									<input type="number" class="form-control" placeholder="Vencimento em x dias " value="<?= isset($records[0])?$records[0]->numero_dias_apos_corte:null ?>" name="numero_dias_apos_corte"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label for="data_primeiro_faturamento">Primeiro faturamento</label>
									<input type="text" class="form-control datepast" placeholder="Dia/Mês/Ano" value="<?= isset($records[0])?convertDate($records[0]->data_primeiro_faturamento):null ?>" name="data_primeiro_faturamento" id=""/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="inicio_producao_em">Entra em produção em:</label>
									<input type="text" class="form-control datepast" placeholder="Dia/Mês/Ano" value="<?= isset($records[0])?convertDate($records[0]->inicio_producao_em):null ?>" name="inicio_producao_em" id=""/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="vinculado_faturamento">Vinculado a produção</label>
									<select name="vinculado_producao" class="form-control select">
										<option value=''>Selecione</option>
										<option <?= (isset($records[0]) && $records[0]->vinculado_producao == '1')?'selected':'' ?> value="1">SIM</option>
										<option <?= (isset($records[0]) && $records[0]->vinculado_producao == '0')?'selected':'' ?> value="0">NÃO</option>
									</select>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="vinculado_faturamento">Up Selling</label>
									<select name="upselling" class="form-control select">
										<option <?= (isset($records[0]) && $records[0]->upselling == '1')?'selected':'' ?> value="1">SIM</option>
										<option <?= (isset($records[0]) && $records[0]->upselling == '0')?'selected':'' ?> value="0">NÃO</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="meio_pagamento">Por meio de</label>
									<select name="meio_pagamento" class="form-control" required class="form-control">
										<option value="boleto"<?= (isset($records[0]) && $records[0]->meio_pagamento == 'boleto')?'selected':null; ?> >BOLETO</option>
										<option value="doc" <?= (isset($records[0]) && $records[0]->meio_pagamento == 'doc')?'selected':null; ?> >DOC</option>
										<option value="ted" <?= (isset($records[0]) && $records[0]->meio_pagamento == 'ted')?'selected':null; ?> >TED</option>
										<option value="outros" <?= (isset($records[0]) && $records[0]->meio_pagamento == 'outros')?'selected':null; ?> >OUTROS</option>
									</select>
								</div>
							</div>	
						</div>
					</fieldset>
					<fieldset>
						<legend>Outros Valores, Juros e Multa</legend>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="hospedagem_mensal">Hospedagem</label>
									<input type="text" class="form-control mask-money" placeholder="R$" value="<?= isset($records[0])?$records[0]->hospedagem_mensal:null ?>" name="hospedagem_mensal"/>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="licenca_uso_mensal">Licença Uso</label>
									<input type="text" class="form-control mask-money" placeholder="R$" value="<?= isset($records[0])?$records[0]->licenca_uso_mensal:null ?>" name="licenca_uso_mensal"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="multa">Percentual da Multa</label>
									<input type="text" class="form-control" placeholder="%" value="<?= isset($records[0])?$records[0]->multa:null ?>" name="multa"/>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="juros">Percentual de Juros</label>
									<input type="text" class="form-control" placeholder="%" value="<?= isset($records[0])?$records[0]->juros:null ?>" name="juros"/>
								</div>
							</div>
						</div>
					</fieldset>
					<!-- <fieldset>
						<legend>Limites</legend>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="ultima_data_demo">Data Limite de Demo</label>
									<input type="text" class="form-control datepast" placeholder="Dia/Mês/Ano" value="<?php// isset($records[0])?convertDate($records[0]->ultima_data_demo):null ?>" name="ultima_data_demo"/>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="carencia_de_uso">Data Limite de Carência </label>
									<input type="text" class="form-control datepast" placeholder="Dia/Mês/Ano" value="<?php // isset($records[0])?convertDate($records[0]->carencia_de_uso):null ?>" name="carencia_de_uso"/>
								</div>
							</div>
						</div>
					</fieldset> -->
					<fieldset>
						<legend>Contato</legend>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="contato">Responsável</label>
									<input type="text" class="form-control" placeholder="Nome" value="<?= isset($records[0])?$records[0]->contato:null ?>" name="contato"/>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="telefone_representante">Telefone</label>
									<input type="text" class="form-control" placeholder="Nome" value="<?= isset($records[0])?$records[0]->telefone_representante:null ?>" name="telefone_representante"/>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="email_contato">Email Responsável</label>
									<input type="text" class="form-control" placeholder="email@dominio.com.br" value="<?= isset($records[0])?$records[0]->email_contato:null ?>" name="email_contato"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="contato_tecnico">Responsavél Técnico</label>
									<input type="text" class="form-control" placeholder="Nome" value="<?= isset($records[0])?$records[0]->contato_tecnico:null ?>" name="contato_tecnico"/>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="email_contato_tecnico">Email Responsavél Técnico</label>
									<input type="text" class="form-control" placeholder="email@dominio.com.br" value="<?= isset($records[0])?$records[0]->email_contato_tecnico:null ?>" name="email_contato_tecnico"/>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Outras informações</legend>
						<div class="row">
							<div class="col-md-4">
								<label for="status">Status</label>
								<select name='status' class="form-control select">
									<option value=''>Selecione</option>
									<option value='inativo' <?= (isset($records[0]) && $records[0]->status == 'inativo')?'selected':'' ?> >INATIVO</option>
									<option value='ativo' <?= (isset($records[0]) && $records[0]->status == 'ativo')?'selected':'' ?> >ATIVO</option>
									<option value='suspenso' <?= (isset($records[0]) && $records[0]->status == 'suspenso')?'selected':'' ?> >SUSPENSO</option>
								</select>
							</div>
							<div class="col-md-4">
								<label for="enviar_email_cobranca">Enviar email de cobrança</label>
								<select name='enviar_email_cobranca' class="form-control select">
									<option value='1' <?= (isset($records[0]) && $records[0]->enviar_email_cobranca == 1)?'selected':'' ?> >SIM</option>
									<option value='0' <?= (isset($records[0]) && $records[0]->enviar_email_cobranca == 0)?'selected':'' ?> >NÃO</option>							
								</select>
							</div>
							<div class="col-md-4">
								<label for="nf_automatica">Gerar Nota fiscal automaticamente?</label>
								<select name='nf_automatica' class="form-control select">
									<option value='1' <?= (isset($records[0]) && $records[0]->nf_automatica == 1)?'selected':'' ?> >SIM</option>
									<option value='0' <?= (isset($records[0]) && $records[0]->nf_automatica == 0)?'selected':'' ?> >NÃO</option>							
								</select>
							</div>                            
						</div>
						<div class="row">
                            <br>
							<div class="col-md-12">
								<label for="alerta_inatividade">Alerta Inatividade(Em dias)</label>
								<input name="alerta_inatividade" id="alerta_inatividade" class="form-control" value="<?= ( isset( $records[0]->alerta_inatividade ) )?$records[0]->alerta_inatividade:null; ?>" />
							</div>
						</div>
						<div class="row">
                            <br>
							<div class="col-md-12">
								<label for="obs_nf">Observações nota fiscal (Maximo de 3 linhas e 300 caracteres no total )</label>
								<textarea name="obs_nf" id="obs_nf" rows="7" class="form-control"><?= ( isset( $records[0]->obs_nf ) )?$records[0]->obs_nf:null; ?></textarea>	
							</div>
						</div>
						<div class="row">
                            <br>
							<div class="col-md-12">
								<label for="obs_contrato">Observações do contrato</label>
								<textarea name="obs_contrato" id="obs_contrato" rows="7" class="form-control"><?= ( isset( $records[0]->obs_contrato ) )?$records[0]->obs_contrato:null; ?></textarea>	
							</div>
						</div>
					</fieldset>
					<br />
					<br />
					<fieldset>
						<div class="row">
							<div class="col-md-12">
								<button id="gravar_contrato" class="form-control btn btn-primary"><i class="fa fa-file-o"></i> GRAVAR </button>	
							</div>
						</div>
					</fieldset>
					<?php if(isset($this->parametros[1]) && $this->parametros[1] > 0){ ?>
						<fieldset>
							<div class="row">
								<div class="col-md-12">
									<a href="/cobranca/ListaPrecoCliente/id/<?= $this->parametros[1]; ?>/order/1" class="form-control btn btn-warning"><i class="fa fa-money"></i> IR PARA LISTA DE PREÇOS</a>	
								</div>
							</div>
						</fieldset>
					<?php } ?>
				</form>
			</div>
		</div>
	</div>

	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<?php include "template/modal_sistema.php" ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript" src="/libs/ckeditor/ckeditor.js"></script>
	<script type="text/javascript" src="/libs/ckeditor/adapters/jquery.js"></script>
	<script src="//cdn.ckeditor.com/4.4.5/standard-all/ckeditor.js"></script>
	<script type="text/javascript">

		$('.mask-money').maskMoney({allowNegative: false, thousands:'.', decimal:','});

		$('.mask-money').each(function(){ // function to apply mask on load!
		    $(this).maskMoney('mask', $(this).val());
		})

		$(function(){
			var editor1 = $("#obs_nf").ckeditor({customConfig: "/libs/ckeditor/config_specific.js"});
			var editor2 = $("#obs_contrato").ckeditor({customConfig: "/libs/ckeditor/config.js"});
			$form = $('#form');
		});
		
		$('#form_contrato').submit(function(e){
			e.preventDefault();
			var url_form   = "<?= HOME_URI.$this->nome_modulo.'/saveContrato/agente/'.$this->parametros[1].''; ?>";
			var dados_form = $(this).serialize(); 
			$.ajax({
				url: url_form,
				data: dados_form,
				type: 'POST',
				success: function (data){
					var obj_json = JSON.parse(data);				
					if(obj_json.codigo == 0){				
						$('#painel_success_msg').text(obj_json.mensagem);
						$('#modal_sucesso_sistema').modal('show');
						$('#modal_sucesso_sistema').on('hidden.bs.modal', function () {
							window.location.href = '/agentecomercial/index';
						});
					}else{
						$('#painel_error_msg').text(obj_json.mensagem);
						$('#modal_erro_sistema').modal('show');
					}
				},
				error: function (error){	
					console.log(error);
					alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
				}
			});
		});
	</script>
	<?php if (isset($records[0])){ ?>
		<script type="text/javascript">
			function justNumber(string){
				var numsStr = string.replace(/[^0-9]/g,'');
				return parseInt(numsStr);
			}

			$(function(){
				var estado = '<?= $records[0]->estado ?>';
				var cidade = '<?= $records[0]->cidade ?>';
				setTimeout(function(){
				$('#estado').selectpicker('val', estado);
				if (estado) {
					$('#estado').trigger("change");
				}
				$('#cidade').selectpicker('val', cidade);
				if (cidade) {
					$('#cidade').trigger("change");
				}
				},1000);
			});
		</script>
	<?php } ?>
<!-- /PAGE SCRIPTS -->
</body>
</html>