<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "Banco";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Bancos</li>
	</ol>
	<h4 class="page-title">
		<?php
		if(empty($this->parametros[1])){
			echo '<i class="fa fa-plus"></i> Novo Banco';
		}else{
			echo '<i class="fa fa-edit"></i> Editar Banco';
		}
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-9">
				<form id="form" action="<?= HOME_URI.$this->module.'/save/id/'.$this->parametros[1].''; ?>" name="save" method="post">
					<fieldset>
						<legend>Dados do conta</legend>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="codigo_banco">Código do banco</label>
									<input type="text" maxlength="60" class="form-control" class="form-control" value="<?= isset($records[0])?$records[0]->codigo_banco:null ?>" name="codigo_banco" required />
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="ispb_banco">ISPB</label>
									<input type="text" maxlength="60" class="form-control" value="<?= isset($records[0])?$records[0]->ispb_banco:null ?>" name="ispb_banco" required />
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="nome_extenso">Nome Extenso</label>
									<input type="text" maxlength="60" class="form-control" class="form-control" value="<?= isset($records[0])?$records[0]->nome_extenso:null ?>" name="nome_extenso" required/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="nome_reduzido">Nome Reduzido</label>
									<input type="text" maxlength="60" class="form-control" class="form-control" value="<?= isset($records[0])?$records[0]->nome_reduzido:null ?>" name="nome_reduzido" required/>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="participa_compe">Participa da COMPE ?</label>
									<select name="participa_compe" class="form-control select">
										<option value="0" <?= ($records[0]->participa_compe == 0)?'selected':null ?> >NÃO</option>
										<option value="1" <?= ($records[0]->participa_compe == 1)?'selected':null ?> >SIM</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="acesso_principal">Acesso Principal</label>
									<select name="acesso_principal" class="form-control select">
										<option value="RSFN" <?= ($records[0]->acesso_principal == 'RSFN')?'selected':null ?> >RSFN</option>
										<option value="Internet" <?= ($records[0]->acesso_principal == 'Internet')?'selected':null ?> >Internet</option>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="inicio_operacao">Inicio da operação</label>
									<input type="text" maxlength="60" class="form-control" value="<?= isset($records[0])?convertDate($records[0]->inicio_operacao):null ?>" name="inicio_operacao" required/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="status">Status</label>
									<select name="status" class="form-control select">
										<option value="a" <?= ($records[0]->status == 'a')?'selected':null ?> >ATIVO</option>
										<option value="i" <?= ($records[0]->status == 'i')?'selected':null ?> >INATIVO</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<a href="/banco/detalhe/id/0/" class="form-control btn btn-success"><i class="fa fa-plus"></i> Novo	</a>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<button type="submit" class="form-control btn btn-primary"><i class="fa fa-save"></i> Salvar</button>
								</div>
							</div>
						</div>
					</fieldset>
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$('.mask-money').maskMoney({allowNegative: false, thousands:'.', decimal:','});
		$('.mask-money').each(function(){ // function to apply mask on load!
		    $(this).maskMoney('mask', $(this).val());
		})
		$(function() {
			$form = $('#form');
			$form.formValidation({
				framework: 'bootstrap',
				excluded: ':disabled',
				icon: {
					valid: 'fa fa-check',
					invalid: 'fa fa-times',
					validating: 'fa fa-refresh'
				},
				addOns: {
					mandatoryIcon: {
						icon: 'fa fa-asterisk'
					}
				},
				live: 'enabled',
				fields: {
					'status': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'data_corte_faturamento': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'numero_dias_apos_corte': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'multa': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'juros': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'contato': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'email_contato': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'id_empresa': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'comissoes[id_vendedor]': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'comissoes[id_diretor]': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'comissoes[tipo_comissao]': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'comissoes[comissao_devida_ate]': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'data_assinatura': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'renovacao_automatica': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'contrato_indeterminado': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'email_nf': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'moeda': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'preco_com_imposto': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'numero_contrato': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'segmento': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'id_produto': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'razao_social': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'cnpj':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							},
							regexp: {
								regexp: /^[0-9]{2}\.[0-9]{3}\.[0-9]{3}\/[0-9]{4}\-[0-9]{2}$/i,
								message: 'CNPJ não é Válido'
							}
						}
					},
					'cep':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							},
							regexp: {
								regexp: /^[0-9]{5}\-[0-9]{3}$/i,
								message: 'CEP não é Válido'
							}
						}
					},
					'endereco':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'bairro':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'estado':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'cidade':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					}
				}
			});
});
</script>

<?php if (isset($records[0])){ ?>
<script type="text/javascript">
	function justNumber(string){
	    var numsStr = string.replace(/[^0-9]/g,'');
	    return parseInt(numsStr);
	}

	$(function() {
		var estado = '<?= $records[0]->estado ?>';
		var cidade = '<?= $records[0]->cidade ?>';
		setTimeout(function(){
		$('#estado').selectpicker('val', estado);
		  if (estado) {
		    $('#estado').trigger("change");
		  }
		$('#cidade').selectpicker('val', cidade);
		if (cidade) {
		    $('#cidade').trigger("change");
		  }
		 },1000);
	});
</script>
<?php } ?>
<!-- /PAGE SCRIPTS -->
</body>
</html>