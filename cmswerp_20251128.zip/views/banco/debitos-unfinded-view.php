<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "debitos_unfinded";
	</script>
	<style type="text/css">
	.btn span:nth-of-type(1)  {        		
		display: none;
	}
	.btn span:last-child  {            	
		display: block;		
	}
	.btn.active  span:nth-of-type(1)  {            	
		display: block;		
	}
	.btn.active span:last-child  {            	
		display: none;			
	}
	</style>
	<!-- /PAGE STYLES -->
</head>

<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Gestão</li>
		<li>Conciliamento Bancario</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> Lançar Debitos</h4>
	<!-- <form class="form-inline page-toolbar" id="frm_debitos" name="frm_debitos" method="post" action="#"> -->
	<div class="container-fluid">
		<div id="loading"></div>
		<form name="redirect_post" id = "redirect_post" action="<?php echo HOME_URI.$this->module.'/processarextrato/action/debito/tipo/unfinded' ?>" method="post">
			<input type="hidden" name="extrato[id_banco]" 	value = "<?= $_FILES['extrato']['id_banco'] ?>">
			<input type="hidden" name="extrato[id_empresa]" value = "<?= $_FILES['extrato']['id_empresa'] ?>">
			<input type="hidden" name="extrato[name]" 		value = "<?= $_FILES['extrato']['name'] ?>">
			<input type="hidden" name="extrato[type]" 		value = "<?= $_FILES['extrato']['type'] ?>">
			<input type="hidden" name="extrato[tmp_name]" 	value = "<?= $path_file ?>">
			<input type="hidden" name="extrato[error]" 		value = "<?= $_FILES['extrato']['error'] ?>">
			<input type="hidden" name="extrato[size]" 		value = "<?= $_FILES['extrato']['size'] ?>">
		</form>
	<div class="row">
		<div class="col-md-12">
			<span><h5><b>Empresa:</b> <?= $banco[0]->razao_social ?></h5></span>
			<span><h5><b>Banco:</b> <?= $banco[0]->nome_banco ?></h5></span>
			<span><h5><b>Agência:</b> <?= $banco[0]->numero_agencia ?></h5></span>
			<span><h5><b>Conta:</b> <?= $banco[0]->numero_conta ?></h5></span>
		</div>		
	</div>
	<div class="row">
		<div class="col-md-12">
			<button type="button" id = 'finalizar' class="btn btn-primary btn-block"><i class="fa fa-caret-right-o"></i> Finalizar</button>
		</div>
	</div>
	<div class="row">
			<div class="col-md-12">
				<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
					<thead>
						<tr role="row">
							<th class="text-center">Extrato</th>
							<th class="text-center">Debitado Em</th>
							<th class="text-center">Valor</th>
							<th class="text-center">Status</th>
							<th class="text-center">Autorizacao</th>
							<th class="text-center">Tipo</th>
							<th class="text-center"></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($operacoes['debitos']['unfinded'] as $key => $value) { ?>	
								<tr>
									<td class="text-left"><small class="label-status"><?= $value['CHECKNUM'].' - '.$value['FITID'].' - '.$value['MEMO']; ?></small></td>
									<td class="text-left"><small class="label-status"><?=  convertDate($value['data_operacao']) ?></small></td>
									<td class="text-right"><small class="label-status"><?= number_format($value['valor'], '2', ',', '.'); ?></small></td>
									
									<td class="text-right"><small class="label-status"><?= $value['status'] ?></small></td>
									
									<td class="text-right"><small class="label-status"><?= $value['status_autorizacao'] ?></small></td>
									<td class="text-left"><small class="label-status">Debito</small></td>
									<td>
										<div class="pull-right">
											<button class="btn btn-warning btn-xs" id= "classificar" data-toggle="modal" data-target="#statusModal" data-valor = "<?= $value['valor']; ?>" data-pagamento = "<?= $value['data_operacao']; ?>" data-checknum= "<?= $value['CHECKNUM'] ?>" data-fitid="<?= $value['FITID']; ?>" data-codigo_banco="<?= $value['codigo_banco']; ?>" >
												<i class="fa fa-pause-circle"></i> Classificar
											</button>
										</div>
									</td>
								</tr>
						<?php } ?>			
					</tbody>
				</table>
			</div>
		</div>
	</div>
<!-- 	</form> -->
<!-- Modal -->
	<!-- <div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	    <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
	        <h3 id="myModalLabel">Modal header</h3>
	    </div>
	    <div class="modal-body">
	        <p>One fine body</p>
	    </div>
	    <div class="modal-footer">
	        <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
	        <button class="btn btn-primary">Save changes</button>
	    </div>
	</div> -->
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<div class="modal fade" tabindex="-1" role="dialog" id="statusModal">
		<div class="modal-dialog " role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title"></h4>
				</div>
				<form method="post" id = "save-despesa">
					<div class="modal-body">
						<!-- Empresa -->
						<label for="Empresa">Empresa</label>
						<select name='id_cm' class="form-control select" required>
							<?php
							foreach($this->empresas as $key=>$value){
								echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome_fantasia).'</option>';
							}
							?>
						</select>	
						<!-- Fornecedor -->
						<label for="fornecedor">Fornecedor</label>
						<select name='id_fornecedor' class="form-control select" required>
							<?php
							foreach($fornecedores as $key=>$value)
							{
								echo '<option value ="'.$value->id.'" >'.strtoupper($value->razao_social).'</option>';
							}
							?>
						</select>
						<!-- centro de custo -->
						<label for="centro_custo">Centro de custo</label>
						<select name='id_centro_custo' id='id_centro_custo' class="form-control select" required>
							<?php
							foreach($centro_custo as $key=>$value){
								echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome).'</option>';
							}
							?>
						</select>
						<!-- grupo -->
						<label for="grupo">grupo</label>
						<select name='id_grupo' id='id_grupo' class="form-control select" required>
							<?php
							foreach($grupos as $key=>$value){
								if($value->id == $records[0]->id_grupo){
									echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome).'</option>';
								}else{
									echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome).'</option>';
								}
							}
							?>
						</select>
						<!-- Conta -->
						<label for="conta">Conta</label>
						<select name='id_conta' id='id_conta' class="form-control select" required>
							<?php
								foreach ($contas as $key => $value) {
									if(!isset($records) && $value->id == 3 ){
									?>
										<option value='<?= $value->id ?>' data-prioridade="<?= $value->prioridade ?>" selected><?= $value->nome ?></option>
									<?php
									}elseif($value->id == $records[0]->id_conta){
									?>
										<option value='<?= $value->id ?>' data-prioridade="<?= $value->prioridade ?>" selected><?= $value->nome ?></option>
									<?php
									}else{
									?>
										<option value='<?= $value->id ?>' data-prioridade="<?= $value->prioridade ?>"><?= $value->nome ?></option>
									<?php
									}
								}
							?>
						</select>
						<!--  Subconta -->
						<label for="subconta">Subconta</label>
						<input type="hidden" value="<?php echo isset($records[0])?$records[0]->id_subconta:null ?>" name="subconta" id="subconta"/>
						<input type="hidden" value="" name="data_operacao" id="data_operacao" required/>
						<input type="hidden" value="" name="valor" id="valor" required/>
						<input type="hidden" value="" name="codigo_banco" id="codigo_banco" required/>
						<input type="hidden" value="" name="checknum" id="checknum" required/>
						<input type="hidden" value="" name="fitid" id="fitid"/>
						<select name='id_subconta' id='id_subconta' class="form-control" required>
						</select>
						<!-- Tipo -->
						<label for="tipo">Tipo</label>
						<select name='tipo' class="form-control select" required>
							<option value="global">Global</option>
							<option value="comercial">Comercial</option>
						</select>
						<!-- Tipo cobranca -->
						<label for="tipo_cobranca">Tipo de Cobrança</label>
						<select name='tipo_cobranca' class="form-control select" required>
							<option value="fatura">Fatura</option>
							<option value="nota fiscal">Nota Fiscal</option>
							<option value="recibo" >Recibo</option>
						</select>
						<!-- Prioridade -->
						<label for="prioridade">Prioridade</label>
						<select name='prioridade' class="form-control select" required>
							<option value="primaria">Primaria</option>
							<option value="secundaria">Secundaria</option>	
						</select>
						<!-- Meio de pagamento -->
						<label for="meio_pagamento">Meio de Pagamento</label>
						<select name='meio_pagamento' class="form-control select" required>
							<option value="boleto" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'boleto')?'selected':null ?>>Boleto</option>
							<option value="caixa" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'caixa')?'selected':null ?>>Caixa</option>
							<option value="cheque" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'cheque')?'selected':null ?>>Cheque</option>
							<option value="transferencia" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'transferencia')?'selected':null ?>>Transferência</option>
							<option value="cartao_credito" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'cartao_credito')?'selected':null ?>>Cartão de crédito</option>
						</select>
						<!-- historico-->
						<label for="historico">Historico</label>
						<textarea name="historico" class="form-control select"></textarea>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
						<button type="button" class="submit btn" id="inserir_despesa"></button>
					</div>
					<div id="error">
			
					</div>
				</form>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div>
	<!-- /.modal -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript">

		$('#finalizar').click(function(){
			$(location).attr('href','/contratos/index');
		});

		$('#inserir_despesa').click(function(){
			var datastring = $("#save-despesa").serialize();
			if($('#id_subconta').val() != null){
				$.ajax({
			          url : "/banco/insertDespesa/",
			          type : 'post',
			          data : datastring,
			          beforeSend : function(){
			               $("#loading").html("ENVIANDO...");
			          }
			    })
			    .done(function(msg){
			        var $retorno = JSON.parse(msg);;
	          		console.log(msg);
	      			if($.trim($retorno.tipo) == 'success'){
	      				location.reload();
	      			}else{
	      				alert($retorno.mensagem);
	      			}
			        $("#loading").html($retorno.mensagem);
			    })
			    .fail(function(jqXHR, textStatus, msg){
			        alert(msg);
			    });
			}else{
				alert('Selecione uma Subconta');
			}			
		});

		$('#id_conta').change(function(){
			$('#subconta').val('');
			includeSubContas(this.value);
		});

		$('#id_subconta').change(function(){
			$('#subconta').val(this.value);
		});

		$('#statusModal').on('show.bs.modal', function (event){
			var button = $(event.relatedTarget);
			$('#data_operacao').val(button.data("pagamento"));
		  	$('#valor').val(button.data("valor"));
		  	$('#valor').val(button.data("valor"));
		  	$('#checknum').val(button.data("checknum"));
		  	$('#fitid').val(button.data("fitid"));
		  	$('#codigo_banco').val(button.data("codigo_banco"));
			var id     = button.data('id');
			var nome   = button.data('nome');
			var status = button.data('status');
			var title;
			var style;
			var message;
			title = 'Inserir Despesa';
			style = 'success1';

			var modal = $(this);

			//modal.find('form').attr('action', '/banco/insertDespesa/');
			modal.find('.modal-title').html(title);
			modal.find('.modal-body #status').val(status);
			modal.find('.modal-footer .submit').removeClass().addClass('submit btn btn-'+style);
			modal.find('.modal-footer .submit').html(title);
		});

		function includeSubContas(id_conta){
			var str = '';
			$.ajax({
			        url: '/orcamento/getsubconta/?id_conta='+id_conta,
			        //datatype: 'json',
			        //contentType: 'application/json; charset=utf-8',
			        type: 'POST',
			        success: function (data){
			        	var subcontas = JSON.parse(data);
			        	//console.log(subcontas);
			        	//alert(dados[0].id_conta);
			        	$.each(subcontas,function(i, dados){
			        		if(dados.id == subconta){
			        			str += '<option value=' + dados.id + ' selected>' + dados.nome + '</option>';
			        			//alert(dados.id);
			        			//getSaldos(dados.id);
			        		}else{
			        			//alert(dados.id);
			        			str += '<option value=' + dados.id + '>' + dados.nome + '</option>';
			        		}
			        		$('#id_subconta').html(str);
			        	});
			        	id_subconta = $('#id_subconta').find(":selected").val();
			        },
			        error: function (error){
			        }
			});
			return str;
		}
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
