<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "debitos";
	</script>
	<style type="text/css">
	.btn span:nth-of-type(1)  {        		
		display: none;
	}
	.btn span:last-child  {            	
		display: block;		
	}
	.btn.active  span:nth-of-type(1)  {            	
		display: block;		
	}
	.btn.active span:last-child  {            	
		display: none;			
	}
	</style>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Gestão</li>
		<li>Conciliamento Bancario</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> Conciliar Debitos
	</h4>
	<!-- <form class="form-inline page-toolbar" id="frm_debitos" name="frm_debitos" method="post" action="#"> -->
	<div class="container-fluid">
		<div id="loading"></div>
		<form name="redirect_post" id = "redirect_post" action="<?php echo HOME_URI.$this->module.'/processarextrato/action/debito/tipo/unfinded' ?>" method="post">
			<input type="hidden" name="extrato[id_empresa]" value = "<?= $_FILES['extrato']['id_empresa'] ?>">
			<input type="hidden" name="extrato[id_banco]" 	value = "<?= $_FILES['extrato']['id_banco'] ?>">
			<input type="hidden" name="extrato[name]" 		value = "<?= $_FILES['extrato']['name'] ?>">
			<input type="hidden" name="extrato[type]" 		value = "<?= $_FILES['extrato']['type'] ?>">
			<input type="hidden" name="extrato[tmp_name]" 	value = "<?= $path_file ?>">
			<input type="hidden" name="extrato[error]" 		value = "<?= $_FILES['extrato']['error'] ?>">
			<input type="hidden" name="extrato[size]" 		value = "<?= $_FILES['extrato']['size'] ?>">
		</form>
	<div class="row">
		<div class="col-md-12">
			<span><h5><b>Empresa:</b> <?= $banco[0]->razao_social ?></h5></span>
			<span><h5><b>Banco:</b> <?= $banco[0]->nome_banco ?></h5></span>
			<span><h5><b>Agência:</b> <?= $banco[0]->numero_agencia ?></h5></span>
			<span><h5><b>Conta:</b> <?= $banco[0]->numero_conta ?></h5></span>
		</div>		
	</div>
	<div class="row">
		<div class="col-md-12">
			<button type="button" id = 'proximo' class="btn btn-primary btn-block"><i class="fa fa-caret-right-o"></i> Próximo</button>
		</div>
	</div>
	<div class="row">
			<div class="col-md-12">
				<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
					<thead>
						<tr role="row">
							<th class="text-center">Empresa CM</th>
							<th class="text-center">Fornecedor</th>
							<th class="text-center">Centro de custo</th>
							<th class="text-center">Grupo</th>
							<th class="text-center">Conta</th>
							<th class="text-center">Subconta</th>
							<th class="text-center">Extrato</th>
							<th class="text-center">Vencimento</th>
							<th class="text-center">Valor</th>
							<th class="text-center">Status</th>
							<th class="text-center">Autorizacao</th>
							<th class="text-center">Tipo</th>
							<th class="text-center"></th>
						</tr>
					</thead>
					<tbody>
						<?php
							if($operacoes['debitos']['finded']){
							foreach ($operacoes['debitos']['finded'] as $key => $value) {
								if(isset($value['debito']) && !empty($value['debito'])){
									foreach ($value['debito'] as $k1 => $v1){
						?>			
									<tr>
										<td class="text-left"><small class="label-status"><?= $v1->nome_cm; ?></small></td>
										<td class="text-left"><small class="label-status"><?= $v1->nome_fornecedor; ?></small></td>
										<td class="text-left"><small class="label-status"><?= $v1->nome_centro_custo; ?></small</td>
										<td class="text-left"><small class="label-status"><?= $v1->nome_grupo; ?></small></td>
										<td class="text-left"><small class="label-status"><?= $v1->nome_conta; ?></small></td>
										<td class="text-left"><small class="label-status"><?= $v1->nome_subconta; ?></small></td>
										<td class="text-left"><small class="label-status"><?= $value['CHECKNUM'].' - '.$value['FITID'].' - '.$value['MEMO']; ?></small></td>
										<td class="text-left"><small class="label-status"><?= convertDate($v1->data_vencimento); ?></small></td>
										<td class="text-right"><small class="label-status"><?= number_format($v1->valor, '2', ',', '.'); ?></small></td>
										<td class="text-right"><small class="label-status"><?= $v1->status ?></small></td>
										<td class="text-right"><small class="label-status"><?= $v1->status_autorizacao ?></small></td>
										<td class="text-left"><small class="label-status">Debito</small></td>
										<td>
											<div class="pull-right">
												<span>
												</span>
												<button type="button" class="btn btn-info btn-xs action" name="conciliar_debito"  data-checknum="<?= $value['CHECKNUM'];?>" data-fitid="<?= $value['FITID'];?>" data-tipo="debito" data-data_operacao="<?= $v1->data_operacao;?>" value="<?= $v1->id_despesa;?>" ><!-- <i class="fa fa-gear"></i> --> </span>Conciliar Debito</button>
											</div>
										</td>
									</tr>
						<?php
									}
								}
							}
						}
						?>	
					</tbody>
				</table>
			</div>
		</div>
	</div>
<!-- 	</form> -->
<!-- Modal -->
<div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="myModalLabel">Modal header</h3>
    </div>
    <div class="modal-body">
        <p>One fine body</p>
    </div>
    <div class="modal-footer">
        <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
        <button class="btn btn-primary">Save changes</button>
    </div>
</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript">
		$('#proximo').click(function(){
			$('#redirect_post').submit();
		});
		$('.action').click(function (){
		  $.ajax({
		          url : "/banco/setStatus/",
		          type : 'post',
		          data : {
		               id_record     : this.value,
		               tipo_record   : $(this).data("tipo"),
		               id_extrato    :	$(this).data("checknum"),
		               fitid         : $(this).data("fitid"),
		               data_operacao : $(this).data("data_operacao"),
		          },
		          beforeSend : function(){
		               $("#loading").html("ENVIANDO...");
		          }
		     })
		     .done(function(msg){
		         var $retorno = JSON.parse(msg);;
          		console.log(msg);
      			if($.trim($retorno.tipo) == 'success'){
      				location.reload();
      			}else{
      				alert($retorno.mensagem);
      			}
		        $("#loading").html($retorno.mensagem);
		     })
		     .fail(function(jqXHR, textStatus, msg){
		          alert(msg);
		    }); 
		});
		$(function() {
			oTable = $('#list').DataTable({
				info: false,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				}
			});
			$('#search1').keyup(function(){
				oTable
				.columns( 0 )
				.search( this.value )
				.draw();
			});
			$('#search2').keyup(function(){
				oTable
				.columns( 1 )
				.search( this.value )
				.draw();
			});
			$('#search3').keyup(function(){
				oTable
				.columns( 2 )
				.search( this.value )
				.draw();
			});

			$('#search4').change(function(){
				$('#listar_nf').submit();
			});

			$('#search5').change(function(){
				$('#listar_nf').submit();
			});

			$('#mostrar_notas').change(function(){
				$('#listar_nf').submit();
			});

			$('#show_adm').change(function(){
				$('#listar_nf').submit();
			});
		});
		
		$('#id_conta').change(function(){
			$('#subconta').val('');
			includeSubContas(this.value);
		});

		$('#id_subconta').change(function(){
			$('#subconta').val(this.value);
		});

		$('#statusModal').on('show.bs.modal', function (event){
			var button = $(event.relatedTarget);
			var id     = button.data('id');
			var nome   = button.data('nome');
			var status = button.data('status');
			var title;
			var style;
			var message;
			title = 'Classificar';
			style = 'success1';

			var modal = $(this);

			modal.find('form').attr('action', '/usuarios/updateStatus/id/'+id);
			modal.find('.modal-title').html(title);
			modal.find('.modal-body #status').val(status);
			modal.find('.modal-footer .submit').removeClass().addClass('submit btn btn-'+style);
			modal.find('.modal-footer .submit').html(title);
		});
		function includeSubContas(id_conta){
			var str = '';
			$.ajax({
			        url: '/orcamento/getsubconta/?id_conta='+id_conta,
			        //datatype: 'json',
			        //contentType: 'application/json; charset=utf-8',
			        type: 'POST',
			        success: function (data){
			        	var subcontas = JSON.parse(data);
			        	//console.log(subcontas);
			        	//alert(dados[0].id_conta);
			        	$.each(subcontas,function(i, dados){
			        		if(dados.id == subconta){
			        			str += '<option value=' + dados.id + ' selected>' + dados.nome + '</option>';
			        			//alert(dados.id);
			        			//getSaldos(dados.id);
			        		}else{
			        			//alert(dados.id);
			        			str += '<option value=' + dados.id + '>' + dados.nome + '</option>';
			        		}
			        		$('#id_subconta').html(str);
			        	});
			        	id_subconta = $('#id_subconta').find(":selected").val();
			        },
			        error: function (error){
			        }
			});
			return str;
		}
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
