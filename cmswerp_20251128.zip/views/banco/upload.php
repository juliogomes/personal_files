<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "conciliamento";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Bancos</li>
	</ol>
	<h4 class="page-title">
		<i class="fa fa-file"></i> Processar Extrato
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-9">
				<form id="form" action="<?php echo HOME_URI.$this->module.'/processarextrato/action/credito/tipo/finded' ?>" name="save" method="post" enctype="multipart/form-data">
					<fieldset>
						<legend>Dados do conta</legend>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="razao_social">Conta Bancaria</label>
									<select name='id_banco' class="form-control select">
										<?php
										foreach($this->obj_contas as $key=>$value)
										{
											echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome_banco.' AG: '.$value->numero_agencia.' CC: '.$value->numero_conta).' - '.$value->razao_social.'</option>';
										}
										?>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="nome_banco">Nome</label>
									<input type="file" name="extrato" class="form-control" class="form-control" required/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<span class="text-danger"><h5><b><?= (isset($_GET['msg']))?base64_decode($_GET['msg']):null; ?></b></h5></span>
							</div>
						</div>
					</fieldset>
					<button type="submit" value = "creditos" name = "acao"	 class="btn btn-success"><i class="fa fa-caret-right-o"></i> Processar Arquivo</button>
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
<!-- /PAGE SCRIPTS -->
</body>
</html>