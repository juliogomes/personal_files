<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "Remessas";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Boletos</li>
		<li>Remessas</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> Remessas</h4>
	<form id="frm_boletos" class="form-inline page-toolbar" method="post" action="/boletos/gerarremessa/">
		<!-- /HEADER -->
		<!-- CONTENT -->
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
						<thead>
							<tr role="row">
								<th class="text-center">Numero Remessa</th>	
								<th class="text-center">Empresa</th>
								<th class="text-center">Data</th>
								<th class="text-center">Agencia</td>
								<th class="text-center">Conta</td>
								<th class="text-center">Status</td>
								<th class="text-center"></td>
							</tr>
						</thead>
						<tbody>
							<?php if (is_array($remessas)){ ?>
							<?php foreach($remessas as $key => $value) {
							?>
							<tr>
								<td class="text-right"><span class="label-status"><small><?= $value->id; ?></small></span></td>
								<td class="text-left"><span class="label-status"><small><?= $value->nome_empresa; ?></small></span></td>
								<td class="text-right"><span class="label-status"><small><?= convertDate($value->data_gravacao); ?></small></span></td>
								<td class="text-right"><span class="label-status"><small><?= $value->agencia; ?></small></span></td>
								<td class="text-right"><span class="label-status"><small><?= $value->conta; ?></small></span></td>
								<td class="text-left"><span class="label-status"><small><?=  $value->status ?></small></span></td>
								<td class="text-center">
									<div class="pull-center">
										<a class="btn btn-info" href="/boletos/index/id_remessa/<?= $value->id ?>/"><i class="fa fa-barcode"></i> </span> 
										</a>
										<a class="btn btn-warning" href="/boletos/downloadRemessa/id_remessa/<?= $value->id ?>/"><i class="fa fa-arrow-down"></i> </span> 
										</a>
										<a class="btn btn-danger" href="/boleto/apagar/id/<?= $value->id ?>/"><i class="fa fa-trash"></i> </span> 
										</a>
									</div>
								</td>
							</tr>
							<?php } ?>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</form>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript">
		$(function() {
			oTable = $('#list').DataTable({
				info: false,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				},
				select: true,
				dom: 'Bfrtip',
				lengthMenu: [
					[ 10, 25, 50, -1 ],
					[ '10 rows', '25 rows', '50 rows', 'Show all' ]
				],
				buttons: [
					{
						extend: 'pageLength',
						text: 'PAGINAS',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'print',
						text: 'PRINT',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'copyHtml5',
						text: 'COPY',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'excelHtml5',
						text: 'EXCEL',
						exportOptions: {
							columns: ':visible'
						}
					},
					{
						extend: 'pdfHtml5',
						text: 'PDF',
						exportOptions: {
							columns: ':visible'
							//columns: [ 0, 1, 2, 5 ]
						}
					},
					{
						extend: 'colvis',
						text: 'COLUNAS',
					},
				]
			});
			$("#checkAll").click(function(){
			    $('input:checkbox').not(this).prop('checked', this.checked);
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
