<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "retorno";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Boletos</li>
		<li>Retorno de remessa</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> Remessas</h4>
	<form id="frm_retorno" class="form-inline page-toolbar" method="post" action="/boletos/processarretorno/" enctype="multipart/form-data">
		<!-- /HEADER -->
		<!-- CONTENT -->
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
						<label>Arquivo</label><input type="file"  class="form-control" id="file_retorno" name="file_retorno" />
						<button type="submit" class="btn btn-info">Processar</button>
				</div>
			</div>
		</div>
	</form>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- /PAGE SCRIPTS -->
</body>
</html>
