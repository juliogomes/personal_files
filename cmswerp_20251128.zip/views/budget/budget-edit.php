<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "quotas";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Orçamento</li>
		<li>Detalhe</li>
	</ol>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<form name="save" action="/quotas/save/<?= $this->parametros[0]?>/<?= $quota[0]->ano?>" method="post">
			<div class="row">
				<div class="col-sm-12 col-md-5">
					<legend>Quotas</legend>
					<div class="form-group">
						<label for="id_cc">Vendedor</label>
						<select name="id_vendedor" class="form-control">
						<?php
							if($this->vendedores){
									foreach ($this->vendedores as $key => $value) {
										if($quota[0]->id_vendedor == $value->id){
											echo "<option value='$value->id' selected >$value->nome</option>";
										}else{
											if(!isset($quota)){
												echo "<option value='$value->id'>$value->nome</option>";
											}
										}
									}
								}
						?>
						</select>
					</div>
					<div class="form-group">
						<label for="ano">Ano</label>
						<select name="ano" class="form-control" readonly="readonly"<?= (isset($quota[0]->ano))?'disabled':null; ?>>
							<option value="2018" <?= (($quota[0]->ano == '2018'))?'selected':null ?> >2018</option>
							<option value="2019" <?= (($quota[0]->ano == '2019'))?'selected':null ?>>2019</option>
							<option value="2020" <?= (($quota[0]->ano == '2020'))?'selected':null ?>>2020</option>
							<option value="2021" <?= (($quota[0]->ano == '2021'))?'selected':null ?>>2021</option>
							<option value="2022" <?= (($quota[0]->ano == '2022'))?'selected':null ?>>2022</option>
							<option value="2023" <?= (($quota[0]->ano == '2023'))?'selected':null ?>>2023</option>
							<option value="2024" <?= (($quota[0]->ano == '2024'))?'selected':null ?>>2024</option>
							<option value="2025" <?= (($quota[0]->ano == '2025'))?'selected':null ?>>2025</option>
							<option value="2026" <?= (($quota[0]->ano == '2026'))?'selected':null ?>>2026</option>
							<option value="2027" <?= (($quota[0]->ano == '2027'))?'selected':null ?>>2027</option>
							<option value="2028" <?= (($quota[0]->ano == '2028'))?'selected':null ?>>2028</option>
						</select>
					</div>
					<div class="form-group">
						<label for="mes">Mês</label>
						<select  name="mes" class="form-control">
							<option value="1">Janeiro</option>
							<option value="2">Fevereiro</option>
							<option value="3">Março</option>
							<option value="4">Abril</option>
							<option value="5">Maio</option>
							<option value="6">Junho</option>
							<option value="7">Julho</option>
							<option value="8">Agosto</option>
							<option value="9">Setembro</option>
							<option value="10">Outubro</option>
							<option value="11">Novembro</option>
							<option value="12">Dezembro</option>
						</select>
					</div>
					<div class="form-group">
						<label for="valor">Valor</label>
						<input type="text" name="valor" class="form-control mask-money" placeholder="0.00" />
					</div>
					<div class="form-group">
						<a href="/cobranca/listarcontratos/" class="btn btn-default"><i class="fa fa-caret-left"></i> Voltar</a>
						<button type="submit" class="btn btn-info"><i class="fa fa-edit"></i> Inserir</button>
					</div>
				</div>
				<div class="col-sm-12 col-md-7">
					<h4 class="page-header">Lancamentos</h4>
					<div class="form-group">
					<table d='list' class="table table-default table-striped table-bordered table-hover" width="100%">
						<thead>
							<tr role="row">
								<th class="text-left">Vendedor</th>
								<th class="text-left">Ano</th>
								<th class="text-left">Mes</th>
								<th class="text-left">Valor</th>
								<th width="80" class="text-center"></th>
							</tr>
						</thead>
						<tbody>
						<?php if ($quo_meses){ ?>
						<?php foreach($quo_meses as $key => $value) {
						?>
						<tr>
							<td class="text-left"><span><small><?= $value->nome_vendedor; ?></small></span></td>
							<td class="text-left"><span><small><?= $value->ano ?></small></span></td>
							<td class="text-left"><span><small><?= nomeMes($value->mes) ?></small></span></td>
							<td class="text-right"><span><small><?= number_format($value->valor, '2', ',', '.'); ?></small></span></td>
							<td class="text-center">
								<div class="pull-center">
									<a class="btn btn-warning btn-xs" href="/quotas/delete/id/<?= $value->id_quota ?>"><i class="fa fa-trash"></i> </span></a>
								</div>
							</td>
						</tr>
						<?php } ?>
						<?php } ?>
						</tbody>
					</table>
					</div>
				</div>
			</div>
		</form>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">

	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
