<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "budget trimestral";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Bugdet</li>
		<li>view</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> Budget</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<form class="form-inline page-toolbar" id="filtro" method="post" action="">
		<div class="row">
			<div class="col-md-12">
				<div class="pull-left">
					<div class="form-group">
						<div class="input-group">
							<select class="form-control filtro" name="ano" id="ano">
								<?php foreach (listaAnos() as $key => $value){ ?>
									<option value="<?=$key;?>" <?=($ano == $value)?"selected":"";?>><?= $value; ?></option>    
								<?php } ?>
							</select>
						</div>
					</div>
				</div>
<!-- 				<div class="pull-left">
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon">Agrupar por Centro de custo</div>
							<select class="form-control filtro" name="sl_centro_custo" id="sl_centro_custo">
							</select>
							<div class="input-group-addon">Grupo</div>
							<select class="form-control filtro" name="sl_grupo" id="sl_grupo">
							</select>
							<div class="input-group-addon">Conta</div>
							<select class="form-control filtro" name="sl_conta" id="sl_conta">
							</select>
							<div class="input-group-addon">Subconta</div>
							<select class="form-control filtro" name="sl_subconta" id="sl_subconta">
							</select>
						</div>
					</div>
				</div> -->
			</div>
		</div>
		<br>
	</form>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<table id='list' class="table-default table-striped table-bordered table-hover" width="500px">
					<thead>
						<tr>
							<th colspan="2" class="text-left" width="200px">Centro Custo</th>
							<th class="text-center">1º TRIMESTRE</th>
                            <th class="text-center">2º TRIMESTRE</th>
                            <th class="text-center">3º TRIMESTRE</th>
                            <th class="text-center">4º TRIMESTRE</th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<td class="text-left" colspan="14"><b>Faturamento</b></td>
						</tr>
						<tr>
							<td colspan="2">FATURADO</td>
							<td class="text-right"><small><?= (empty($tabela_faturamento['faturado']['t1']['valor']))?'0,00':$tabela_faturamento['faturado']['t1']['valor']; ?></small></td>
							<td class="text-right"><small> <?= (empty($tabela_faturamento['faturado']['t2']['valor']))?'0,00':$tabela_faturamento['faturado']['t2']['valor']; ?></small></td>
							<td class="text-right"><small> <?= (empty($tabela_faturamento['faturado']['t3']['valor']))?'0,00':$tabela_faturamento['faturado']['t3']['valor']; ?></small></td>
							<td class="text-right"><small> <?= (empty($tabela_faturamento['faturado']['t4']['valor']))?'0,00':$tabela_faturamento['faturado']['t4']['valor']; ?></small></td>
						</tr>
						<tr>
							<td colspan="2">RECEBIDO</td>
							<td class="text-right"><small><?= (empty($tabela_faturamento['recebido']['t1']['valor']))?'0,00':$tabela_faturamento['recebido']['t1']['valor']; ?></small></td>
							<td class="text-right"><small> <?= (empty($tabela_faturamento['recebido']['t2']['valor']))?'0,00':$tabela_faturamento['recebido']['t2']['valor']; ?></small></td>
							<td class="text-right"><small> <?= (empty($tabela_faturamento['recebido']['t3']['valor']))?'0,00':$tabela_faturamento['recebido']['t3']['valor']; ?></small></td>
							<td class="text-right"><small> <?= (empty($tabela_faturamento['recebido']['t4']['valor']))?'0,00':$tabela_faturamento['recebido']['t4']['valor']; ?></small></td>
						</tr>
						<tr>
							<td colspan="2">PAGAMENTO</td>
							<td class="text-right"><small><?= (empty($tabela_budget['despesa']['total']['t1']))?'0,00':number_format((float)$tabela_budget['despesa']['total']['t1'], 0, ',','.')?></small></td>
							<td class="text-right"><small> <?= (empty($tabela_budget['despesa']['total']['t2']))?'0,00':number_format((float)$tabela_budget['despesa']['total']['t2'], 0, ',','.')?></small></td>
							<td class="text-right"><small> <?= (empty($tabela_budget['despesa']['total']['t3']))?'0,00':number_format((float)$tabela_budget['despesa']['total']['t3'], 0, ',','.')?></small></td>
							<td class="text-right"><small> <?= (empty($tabela_budget['despesa']['total']['t4']))?'0,00':number_format((float)$tabela_budget['despesa']['total']['t4'], 0, ',','.')?></small></td>
						</tr>
					</tfoot>
					<?php foreach ($tabela_budget as $key => $value): if($key != 'orcamento' && $key != 'despesa' && $key != 'despesa'){ ?>
						<tr>
							<td width="100px" ><?= $key ?></td>
							<td class="text-left" width="100px">
								Orçamento<br>
								Realizado<br>
								Saldo<br>
							</td>
							<td class="text-right">
								<small>
									<?= (empty($value['orcamento']['t1']))?'0': $value['orcamento']['t1'] ?><br>
									<?= (empty($value['despesa']['t1']))?'0': $value['despesa']['t1'] ?><br>
									<?= $value['saldo']['t1']; ?>
								</small>
							</td>
							<td class="text-right">
								<small>
									<?= (empty($value['orcamento']['t2']))?'0': $value['orcamento']['t2'] ?><br>
									<?= (empty($value['despesa']['t2']))?'0': $value['despesa']['t2'] ?><br>
									<?= $value['saldo']['t2']; ?>
								</small>
							</td>
							<td class="text-right">
								<small>
									<?= (empty($value['orcamento']['t3']))?'0': $value['orcamento']['t3'] ?><br>
									<?= (empty($value['despesa']['t3']))?'0': $value['despesa']['t3'] ?><br>
									<?= $value['saldo']['t3']; ?>
								</small>
							</td>
							<td class="text-right">
								<small>
									<?= (empty($value['orcamento']['t4']))?'0': $value['orcamento']['t4'] ?><br>
									<?= (empty($value['despesa']['t4']))?'0': $value['despesa']['t4'] ?><br>
									<?= $value['saldo']['t4']; ?>
								</small>
							</td>
						</tr>

					<?php } endforeach ?>
						<tr>
							<td>
								Total
							</td>
							<td>
								Orçamento<br>
								Realizado<br>
								Saldo<br>
							</td>
							<td class="text-right">
								<?php $saldo_total = ($tabela_budget['orcamento']['total']['t1'] - $tabela_budget['despesa']['total']['t1']); ?>
								<small>
								<?= (empty($tabela_budget['orcamento']['total']['t1']))?'0': number_format((float)$tabela_budget['orcamento']['total']['t1'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesa']['total']['t1']))?'0': number_format((float)$tabela_budget['despesa']['total']['t1'], 0, ',','.'); ?><br>
								<?= number_format($saldo_total, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<?php $saldo_total = ($tabela_budget['orcamento']['total']['t2'] - $tabela_budget['despesa']['total']['t2']); ?>
								<small>
								<?= (empty($tabela_budget['orcamento']['total']['t2']))?'0': number_format((float)$tabela_budget['orcamento']['total']['t2'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesa']['total']['t2']))?'0': number_format((float)$tabela_budget['despesa']['total']['t2'], 0, ',','.'); ?><br>
								<?= number_format($saldo_total, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<?php $saldo_total = ($tabela_budget['orcamento']['total']['t3'] - $tabela_budget['despesa']['total']['t3']); ?>
								<small>
								<?= (empty($tabela_budget['orcamento']['total']['t3']))?'0': number_format((float)$tabela_budget['orcamento']['total']['t3'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesa']['total']['t3']))?'0': number_format((float)$tabela_budget['despesa']['total']['t3'], 0, ',','.'); ?><br>
								<?= number_format($saldo_total, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<?php $saldo_total = ($tabela_budget['orcamento']['total']['t4'] - $tabela_budget['despesa']['total']['t4']); ?>
								<small>
								<?= (empty($tabela_budget['orcamento']['total']['t4']))?'0': number_format((float)$tabela_budget['orcamento']['total']['t4'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesa']['total']['t4']))?'0': number_format((float)$tabela_budget['despesa']['total']['t4'], 0, ',','.'); ?><br>
								<?= number_format($saldo_total, 0, ',','.') ?>
								</small>
							</td>
						</tr>
				</table>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- <script type="text/javascript" src="/libs/DataTables-1.10.13/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/dataTables.bootstrap.min.js"></script> -->
	<script type="text/javascript">
		$(function() {
			var $url = '/budget/budgetTrimestre/';
			$('.filtro').change(function(){
				$('#filtro').attr('action', $url).submit();
			});

			oTable = $('#list').DataTable({
				info: false,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				}
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
