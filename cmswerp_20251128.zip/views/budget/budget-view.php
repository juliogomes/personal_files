<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "budget";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Bugdet</li>
		<li>view</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> Budget</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<form class="form-inline page-toolbar" id="filtro" method="post" action="">
		<div class="row">
			<div class="col-md-12">
				<div class="pull-left">
					<div class="form-group">
						<div class="input-group">
							<select class="form-control filtro" name="ano" id="ano">
								<?php foreach (returAnos() as $key => $value){ ?>
									<option value="<?=$key;?>" <?=($ano == $value)?"selected":"";?>><?= $value; ?></option>    
								<?php } ?>
							</select>
						</div>
					</div>
				</div>
<!-- 				<div class="pull-left">
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon">Agrupar por Centro de custo</div>
							<select class="form-control filtro" name="sl_centro_custo" id="sl_centro_custo">
							</select>
							<div class="input-group-addon">Grupo</div>
							<select class="form-control filtro" name="sl_grupo" id="sl_grupo">
							</select>
							<div class="input-group-addon">Conta</div>
							<select class="form-control filtro" name="sl_conta" id="sl_conta">
							</select>
							<div class="input-group-addon">Subconta</div>
							<select class="form-control filtro" name="sl_subconta" id="sl_subconta">
							</select>
						</div>
					</div>
				</div> -->
			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-12">
				<div class="pull-left">
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon">Centro de custo</div>
							<select class="form-control filtro" name="centro_custo" id="centro_custo">
							<option value="" selected>Todos</option>
							<?php foreach ($this->centro_custo as $key => $value):
								if($value->id == $centro_custo){
							?>
								<option value="<?= $value->id ?>" selected><?= $value->nome ?></option>
							<?php
								}else{
							?>
								<option value="<?= $value->id ?>"><?= $value->nome ?></option>
							<?php } endforeach ?>
							</select>
						</div>
					</div>
				</div>
				<div class="pull-left">
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon">Grupo</div>
							<select class="form-control filtro" name="grupo" id="grupo">
							<option value="" selected>Todos</option>
							<?php foreach ($this->grupo as $key => $value): 
								if($value->id == $grupo){
							?>
								<option value="<?= $value->id ?>" selected><?= $value->nome ?></option>
							<?php
								}else{
							?>
								<option value="<?= $value->id ?>"><?= $value->nome ?></option>
							<?php } endforeach ?>
							</select>
						</div>
					</div>
				</div>
				<div class="pull-left">
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon">Conta</div>
							<select class="form-control filtro" name="conta" id="conta">
							<option value="" selected>Todos</option>
							<?php foreach ($this->conta as $key => $value): 
								if($value->id == $conta){
							?>
								<option value="<?= $value->id ?>" selected><?= $value->nome ?></option>
							<?php
								}else{
							?>
								<option value="<?= $value->id ?>"><?= $value->nome ?></option>
							<?php } endforeach ?>
							</select>
						</div>
					</div>
				</div>
				<div class="pull-left">
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon">Subconta</div>
							<select class="form-control filtro" name="subconta" id="subconta">
							<option value="" selected>Todos</option>
							<?php foreach ($this->subconta as $key => $value): 
								if($value->id == $subconta){
							?>
								<option value="<?= $value->id ?>" selected><?= $value->nome ?></option>
							<?php
								}else{
							?>
								<option value="<?= $value->id ?>"><?= $value->nome ?></option>
							<?php } endforeach ?>
							</select>
						</div>
					</div>
				</div>
				<div class="pull-left">
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon">View</div>
							<select class="form-control filtro" name="view" id="view">
								<option value="" selected>Todos</option>
								<option value="comercial" <?= ($view == 'comercial')?'selected':null ?> >Comercial</option>
								<option value="global" <?= ($view == 'global')?'selected':null ?> >Global</option>
							</select>
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<table id='list' class="table-default table-striped table-bordered table-hover" width="100%">
					<thead>
						<tr>
							<th colspan="2" class="text-left">Centro Custo</th>
							<th class="text-center">Jan</th>
							<th class="text-center">Fev</th>
							<th class="text-center">Mar</th>
							<th class="text-center">Abr</th>
							<th class="text-center">Mai</th>
							<th class="text-center">Jun</th>
							<th class="text-center">Jul</th>
							<th class="text-center">Ago</th>
							<th class="text-center">Set</th>
							<th class="text-center">Out</th>
							<th class="text-center">Nov</th>
							<th class="text-center">Dez</th>
						</tr>
					</thead>
					<tfoot>
					<tr>
						<td class="text-left" colspan="14"><b>Faturamento</b></td>
					</tr>
					<tr>
						<td colspan="2">Global</td>
						<td class="text-right"><small><?= (empty($tabela_faturamento_global['Janeiro']))?'0,00':$tabela_faturamento_global['Janeiro'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_global['Fevereiro']))?'0,00':$tabela_faturamento_global['Fevereiro'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_global['Março']))?'0,00':$tabela_faturamento_global['Março'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_global['Abril']))?'0,00':$tabela_faturamento_global['Abril'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_global['Maio']))?'0,00':$tabela_faturamento_global['Maio'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_global['Junho']))?'0,00':$tabela_faturamento_global['Junho'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_global['Julho']))?'0,00':$tabela_faturamento_global['Julho'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_global['Agosto']))?'0,00':$tabela_faturamento_global['Agosto'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_global['Setembro']))?'0,00':$tabela_faturamento_global['Setembro'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_global['Outubro']))?'0,00':$tabela_faturamento_global['Outubro'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_global['Novembro']))?'0,00':$tabela_faturamento_global['Novembro'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_global['Dezembro']))?'0,00':$tabela_faturamento_global['Dezembro'] ?></small></td>
					</tr>
					<tr>
						<td colspan="2">Comercial</td>
						<td class="text-right"><small><?= (empty($tabela_faturamento_comercial['Janeiro']))?'0,00':$tabela_faturamento_comercial['Janeiro'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_comercial['Fevereiro']))?'0,00':$tabela_faturamento_comercial['Fevereiro'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_comercial['Março']))?'0,00':$tabela_faturamento_comercial['Março'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_comercial['Abril']))?'0,00':$tabela_faturamento_comercial['Abril'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_comercial['Maio']))?'0,00':$tabela_faturamento_comercial['Maio'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_comercial['Junho']))?'0,00':$tabela_faturamento_comercial['Junho'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_comercial['Julho']))?'0,00':$tabela_faturamento_comercial['Julho'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_comercial['Agosto']))?'0,00':$tabela_faturamento_comercial['Agosto'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_comercial['Setembro']))?'0,00':$tabela_faturamento_comercial['Setembro'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_comercial['Outubro']))?'0,00':$tabela_faturamento_comercial['Outubro'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_comercial['Novembro']))?'0,00':$tabela_faturamento_comercial['Novembro'] ?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_comercial['Dezembro']))?'0,00':$tabela_faturamento_comercial['Dezembro'] ?></small></td>
					</tr>
					<tr>
						<td colspan="2">Total</td>
						<td class="text-right"><small><?= (empty($tabela_faturamento_total['Janeiro']))?'0,00':number_format((float)$tabela_faturamento_total['Janeiro'], 0, ',','.')?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_total['Fevereiro']))?'0,00':number_format((float)$tabela_faturamento_total['Fevereiro'], 0, ',','.')?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_total['Março']))?'0,00':number_format((float)$tabela_faturamento_total['Março'], 0, ',','.')?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_total['Abril']))?'0,00':number_format((float)$tabela_faturamento_total['Abril'], 0, ',','.')?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_total['Maio']))?'0,00':number_format((float)$tabela_faturamento_total['Maio'], 0, ',','.')?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_total['Junho']))?'0,00':number_format((float)$tabela_faturamento_total['Junho'], 0, ',','.')?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_total['Julho']))?'0,00':number_format((float)$tabela_faturamento_total['Julho'], 0, ',','.')?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_total['Agosto']))?'0,00':number_format((float)$tabela_faturamento_total['Agosto'], 0, ',','.')?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_total['Setembro']))?'0,00':number_format((float)$tabela_faturamento_total['Setembro'], 0, ',','.')?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_total['Outubro']))?'0,00':number_format((float)$tabela_faturamento_total['Outubro'], 0, ',','.')?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_total['Novembro']))?'0,00':number_format((float)$tabela_faturamento_total['Novembro'], 0, ',','.')?></small></td>
						<td class="text-right"><small> <?= (empty($tabela_faturamento_total['Dezembro']))?'0,00':number_format((float)$tabela_faturamento_total['Dezembro'], 0, ',','.')?></small></td>
					</tr>
					</tfoot>
					<?php foreach ($tabela_budget as $key => $value): if($key != 'orcamento' && $key != 'despesas' && $key != 'despesa_paga'){ ?>
						<tr>
							<td><?= $key ?></td>
							<td class="text-left">
								Orçamento<br>
								Projetado<br>
								Realizado<br>
								Saldo<br>
							</td>
							<td class="text-right">
								<small>
									<?= (empty($value['orcamento']['Janeiro']))?'0': $value['orcamento']['Janeiro'] ?><br>
									<?= (empty($value['despesas']['Janeiro']))?'0': $value['despesas']['Janeiro'] ?><br>
									<?= (empty($value['despesa_paga']['Janeiro']))?'0': $value['despesa_paga']['Janeiro'] ?><br>
									<?php $saldo = ($value['orcamento']['saldo']['Janeiro'] - $value['despesas']['saldo']['Janeiro']) ?>
									<?= number_format($saldo, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<small>
									<?= (empty($value['orcamento']['Fevereiro']))?'0': $value['orcamento']['Fevereiro'] ?><br>
									<?= (empty($value['despesas']['Fevereiro']))?'0': $value['despesas']['Fevereiro'] ?><br>
									<?= (empty($value['despesa_paga']['Fevereiro']))?'0': $value['despesa_paga']['Fevereiro'] ?><br>
									<?php $saldo = ($value['orcamento']['saldo']['Fevereiro'] - $value['despesas']['saldo']['Fevereiro']) ?>
									<?= number_format($saldo, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<small>
									<?= (empty($value['orcamento']['Março']))?'0': $value['orcamento']['Março'] ?><br>
									<?= (empty($value['despesas']['Março']))?'0': $value['despesas']['Março'] ?><br>
									<?= (empty($value['despesa_paga']['Março']))?'0': $value['despesa_paga']['Março'] ?><br>
									<?php $saldo = ($value['orcamento']['saldo']['Março'] - $value['despesas']['saldo']['Março']) ?>
									<?= number_format($saldo, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<small>
									<?= (empty($value['orcamento']['Abril']))?'0': $value['orcamento']['Abril'] ?><br>
									<?= (empty($value['despesas']['Abril']))?'0': $value['despesas']['Abril'] ?><br>
									<?= (empty($value['despesa_paga']['Abril']))?'0': $value['despesa_paga']['Abril'] ?><br>
									<?php $saldo = ($value['orcamento']['saldo']['Abril'] - $value['despesas']['saldo']['Abril']) ?>
									<?= number_format($saldo, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<small>
									<?= (empty($value['orcamento']['Maio']))?'0': $value['orcamento']['Maio'] ?><br>
									<?= (empty($value['despesas']['Maio']))?'0': $value['despesas']['Maio'] ?><br>
									<?= (empty($value['despesa_paga']['Maio']))?'0': $value['despesa_paga']['Maio'] ?><br>
									<?php $saldo = ($value['orcamento']['saldo']['Maio'] - $value['despesas']['saldo']['Maio']) ?>
									<?= number_format($saldo, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<small>
									<?= (empty($value['orcamento']['Junho']))?'0': $value['orcamento']['Junho'] ?><br>
									<?= (empty($value['despesas']['Junho']))?'0': $value['despesas']['Junho'] ?><br>
									<?= (empty($value['despesa_paga']['Junho']))?'0': $value['despesa_paga']['Junho'] ?><br>
									<?php $saldo = ($value['orcamento']['saldo']['Junho'] - $value['despesas']['saldo']['Junho']) ?>
									<?= number_format($saldo, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<small>
									<?= (empty($value['orcamento']['Julho']))?'0': $value['orcamento']['Julho'] ?><br>
									<?= (empty($value['despesas']['Julho']))?'0': $value['despesas']['Julho'] ?><br>
									<?= (empty($value['despesa_paga']['Julho']))?'0': $value['despesa_paga']['Julho'] ?><br>
									<?php $saldo = ($value['orcamento']['saldo']['Julho'] - $value['despesas']['saldo']['Julho']) ?>
									<?= number_format($saldo, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<small>
									<?= (empty($value['orcamento']['Agosto']))?'0': $value['orcamento']['Agosto'] ?><br>
									<?= (empty($value['despesas']['Agosto']))?'0': $value['despesas']['Agosto'] ?><br>
									<?= (empty($value['despesa_paga']['Agosto']))?'0': $value['despesa_paga']['Agosto'] ?><br>
									<?php $saldo = ($value['orcamento']['saldo']['Agosto'] - $value['despesas']['saldo']['Agosto']) ?>
									<?= number_format($saldo, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<small>
									<?= (empty($value['orcamento']['Setembro']))?'0': $value['orcamento']['Setembro'] ?><br>
									<?= (empty($value['despesas']['Setembro']))?'0': $value['despesas']['Setembro'] ?><br>
									<?= (empty($value['despesa_paga']['Setembro']))?'0': $value['despesa_paga']['Setembro'] ?><br>
									<?php $saldo = ($value['orcamento']['saldo']['Setembro'] - $value['despesas']['saldo']['Setembro']) ?>
									<?= number_format($saldo, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<small>
									<?= (empty($value['orcamento']['Outubro']))?'0': $value['orcamento']['Outubro'] ?><br>
									<?= (empty($value['despesas']['Outubro']))?'0': $value['despesas']['Outubro'] ?><br>
									<?= (empty($value['despesa_paga']['Outubro']))?'0': $value['despesa_paga']['Outubro'] ?><br>
									<?php $saldo = ($value['orcamento']['saldo']['Outubro'] - $value['despesas']['saldo']['Outubro']) ?>
									<?= number_format($saldo, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<small>
									<?= (empty($value['orcamento']['Novembro']))?'0': $value['orcamento']['Novembro'] ?><br>
									<?= (empty($value['despesas']['Novembro']))?'0': $value['despesas']['Novembro'] ?><br>
									<?= (empty($value['despesa_paga']['Novembro']))?'0': $value['despesa_paga']['Novembro'] ?><br>
									<?php $saldo = ($value['orcamento']['saldo']['Novembro'] - $value['despesas']['saldo']['Novembro']) ?>
									<?= number_format($saldo, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<small>
									<?= (empty($value['orcamento']['Dezembro']))?'0': $value['orcamento']['Dezembro'] ?><br>
									<?= (empty($value['despesas']['Dezembro']))?'0': $value['despesas']['Dezembro'] ?><br>
									<?= (empty($value['despesa_paga']['Dezembro']))?'0': $value['despesa_paga']['Dezembro'] ?><br>
									<?php $saldo = ($value['orcamento']['saldo']['Dezembro'] - $value['despesas']['saldo']['Dezembro']) ?>
									<?= number_format($saldo, 0, ',','.') ?>
								</small>
							</td>
						</tr>

					<?php } endforeach ?>
						<tr>
							<td>
								Total
							</td>
							<td>
								Orçamento<br>
								Projetado<br>
								Realizado<br>
								Saldo<br>
							</td>
							<td class="text-right">
								<?php $saldo_total = ($tabela_budget['orcamento']['total']['Janeiro'] - $tabela_budget['despesas']['total']['Janeiro']); ?>
								<small>
								<?= (empty($tabela_budget['orcamento']['total']['Janeiro']))?'0': number_format((float)$tabela_budget['orcamento']['total']['Janeiro'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesas']['total']['Janeiro']))?'0': number_format((float)$tabela_budget['despesas']['total']['Janeiro'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesa_paga']['total']['Janeiro']))?'0': number_format((float)$tabela_budget['despesa_paga']['total']['Janeiro'], 0, ',','.'); ?><br>
								<?= number_format($saldo_total, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<?php $saldo_total = ($tabela_budget['orcamento']['total']['Fevereiro'] - $tabela_budget['despesas']['total']['Fevereiro']); ?>
								<small>
								<?= (empty($tabela_budget['orcamento']['total']['Fevereiro']))?'0': number_format((float)$tabela_budget['orcamento']['total']['Fevereiro'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesas']['total']['Fevereiro']))?'0': number_format((float)$tabela_budget['despesas']['total']['Fevereiro'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesa_paga']['total']['Fevereiro']))?'0': number_format((float)$tabela_budget['despesa_paga']['total']['Fevereiro'], 0, ',','.'); ?><br>
								<?= number_format($saldo_total, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<?php $saldo_total = ($tabela_budget['orcamento']['total']['Março'] - $tabela_budget['despesas']['total']['Março']); ?>
								<small>
								<?= (empty($tabela_budget['orcamento']['total']['Março']))?'0': number_format((float)$tabela_budget['orcamento']['total']['Março'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesas']['total']['Março']))?'0': number_format((float)$tabela_budget['despesas']['total']['Março'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesa_paga']['total']['Março']))?'0': number_format((float)$tabela_budget['despesa_paga']['total']['Março'], 0, ',','.'); ?><br>
								<?= number_format($saldo_total, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<?php $saldo_total = ($tabela_budget['orcamento']['total']['Abril'] - $tabela_budget['despesas']['total']['Abril']); ?>
								<small>
								<?= (empty($tabela_budget['orcamento']['total']['Abril']))?'0': number_format((float)$tabela_budget['orcamento']['total']['Abril'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesas']['total']['Abril']))?'0': number_format((float)$tabela_budget['despesas']['total']['Abril'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesa_paga']['total']['Abril']))?'0': number_format((float)$tabela_budget['despesa_paga']['total']['Abril'], 0, ',','.'); ?><br>
								<?= number_format($saldo_total, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<?php $saldo_total = ($tabela_budget['orcamento']['total']['Maio'] - $tabela_budget['despesas']['total']['Maio']); ?>
								<small>
								<?= (empty($tabela_budget['orcamento']['total']['Maio']))?'0': number_format((float)$tabela_budget['orcamento']['total']['Maio'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesas']['total']['Maio']))?'0': number_format((float)$tabela_budget['despesas']['total']['Maio'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesa_paga']['total']['Maio']))?'0': number_format((float)$tabela_budget['despesa_paga']['total']['Maio'], 0, ',','.'); ?><br>
								<?= number_format($saldo_total, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<?php $saldo_total = ($tabela_budget['orcamento']['total']['Junho'] - $tabela_budget['despesas']['total']['Junho']); ?>
								<small>
								<?= (empty($tabela_budget['orcamento']['total']['Junho']))?'0': number_format((float)$tabela_budget['orcamento']['total']['Junho'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesas']['total']['Junho']))?'0': number_format((float)$tabela_budget['despesas']['total']['Junho'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesa_paga']['total']['Junho']))?'0': number_format((float)$tabela_budget['despesa_paga']['total']['Junho'], 0, ',','.'); ?><br>
								<?= number_format($saldo_total, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<?php $saldo_total = ($tabela_budget['orcamento']['total']['Julho'] - $tabela_budget['despesas']['total']['Julho']); ?>
								<small>
								<?= (empty($tabela_budget['orcamento']['total']['Julho']))?'0': number_format((float)$tabela_budget['orcamento']['total']['Julho'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesas']['total']['Julho']))?'0': number_format((float)$tabela_budget['despesas']['total']['Julho'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesa_paga']['total']['Julho']))?'0': number_format((float)$tabela_budget['despesa_paga']['total']['Julho'], 0, ',','.'); ?><br>
								<?= number_format($saldo_total, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<?php $saldo_total = ($tabela_budget['orcamento']['total']['Agosto'] - $tabela_budget['despesas']['total']['Agosto']); ?>
								<small>
								<?= (empty($tabela_budget['orcamento']['total']['Agosto']))?'0': number_format((float)$tabela_budget['orcamento']['total']['Agosto'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesas']['total']['Agosto']))?'0': number_format((float)$tabela_budget['despesas']['total']['Agosto'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesa_paga']['total']['Agosto']))?'0': number_format((float)$tabela_budget['despesa_paga']['total']['Agosto'], 0, ',','.'); ?><br>
								<?= number_format($saldo_total, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<?php $saldo_total = ($tabela_budget['orcamento']['total']['Setembro'] - $tabela_budget['despesas']['total']['Setembro']); ?>
								<small>
								<?= (empty($tabela_budget['orcamento']['total']['Setembro']))?'0': number_format((float)$tabela_budget['orcamento']['total']['Setembro'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesas']['total']['Setembro']))?'0': number_format((float)$tabela_budget['despesas']['total']['Setembro'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesa_paga']['total']['Setembro']))?'0': number_format((float)$tabela_budget['despesa_paga']['total']['Setembro'], 0, ',','.'); ?><br>
								<?= number_format($saldo_total, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<?php $saldo_total = ($tabela_budget['orcamento']['total']['Outubro'] - $tabela_budget['despesas']['total']['Outubro']); ?>
								<small>
								<?= (empty($tabela_budget['orcamento']['total']['Outubro']))?'0': number_format((float)$tabela_budget['orcamento']['total']['Outubro'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesas']['total']['Outubro']))?'0': number_format((float)$tabela_budget['despesas']['total']['Outubro'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesa_paga']['total']['Outubro']))?'0': number_format((float)$tabela_budget['despesa_paga']['total']['Outubro'], 0, ',','.'); ?><br>
								<?= number_format($saldo_total, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<?php $saldo_total = ($tabela_budget['orcamento']['total']['Novembro'] - $tabela_budget['despesas']['total']['Novembro']); ?>
								<small>
								<?= (empty($tabela_budget['orcamento']['total']['Novembro']))?'0': number_format((float)$tabela_budget['orcamento']['total']['Novembro'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesas']['total']['Novembro']))?'0': number_format((float)$tabela_budget['despesas']['total']['Novembro'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesa_paga']['total']['Novembro']))?'0': number_format((float)$tabela_budget['despesa_paga']['total']['Novembro'], 0, ',','.'); ?><br>
								<?= number_format($saldo_total, 0, ',','.') ?>
								</small>
							</td>
							<td class="text-right">
								<?php $saldo_total = ($tabela_budget['orcamento']['total']['Dezembro'] - $tabela_budget['despesas']['total']['Dezembro']); ?>
								<small>
								<?= (empty($tabela_budget['orcamento']['total']['Dezembro']))?'0': number_format((float)$tabela_budget['orcamento']['total']['Dezembro'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesas']['total']['Dezembro']))?'0': number_format((float)$tabela_budget['despesas']['total']['Dezembro'], 0, ',','.'); ?><br>
								<?= (empty($tabela_budget['despesa_paga']['total']['Dezembro']))?'0': number_format((float)$tabela_budget['despesa_paga']['total']['Dezembro'], 0, ',','.'); ?><br>
								<?= number_format($saldo_total, 0, ',','.') ?>
								</small>
							</td>
						</tr>
				</table>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- <script type="text/javascript" src="/libs/DataTables-1.10.13/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/dataTables.bootstrap.min.js"></script> -->
	<script type="text/javascript">
		$(function() {
			var $url = '/budget/listar/';
			$('.filtro').change(function(){
				$('#filtro').attr('action', $url).submit();
			});

			oTable = $('#list').DataTable({
				info: false,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				}
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
