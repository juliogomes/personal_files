<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "hunter";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Bugdet</li>
		<li>Hunter</li>
	</ol>
		<h4 class="page-title"><i class="fa fa-caret-right"></i> Hunter</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<form class="form-inline page-toolbar" id="filtro" method="post" action="">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-6">
					<div class="pull-left">
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
								<select class="form-control filtro" name="ano" id="ano">
									<option value="2017" <?= ($ano == '2017')?'selected':null ?> >2017</option>
									<option value="2018" <?= ($ano == '2018')?'selected':null ?> >2018</option>
									<option value="2019" <?= ($ano == '2019')?'selected':null ?> >2019</option>
									<option value="2020" <?= ($ano == '2020')?'selected':null ?> >2020</option>
									<option value="2021" <?= ($ano == '2021')?'selected':null ?> >2021</option>
									<option value="2022" <?= ($ano == '2022')?'selected':null ?> >2022</option>
								</select>
							</div>
						</div>
					</div>
					<!-- <div class="pull-left">
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="glyphicon glyphicon-tasks"></i></span>
								<select class="form-control filtro" name="tipo" id="tipo">
									<option value="todos" <?= ($tipo == 'todos')?'selected':null ?> >Todos</option>
									<option value="upselling" <?= ($tipo == 'upselling')?'selected':null ?> >Up Selling</option>
								</select>
							</div>
						</div>
					</div> -->
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<table id='list' class="table-default table-striped table-bordered table-hover" width="100%">
						<thead>
							<tr>
								<th class="text-left">Cliente</th>
								<th class="text-left">Produto</th>
								<th class="text-left">Comercial</th>
								<th class="text-center">Jan</th>
								<th class="text-center">Fev</th>
								<th class="text-center">Mar</th>
								<th class="text-center">Abr</th>
								<th class="text-center">Mai</th>
								<th class="text-center">Jun</th>
								<th class="text-center">Jul</th>
								<th class="text-center">Ago</th>
								<th class="text-center">Set</th>
								<th class="text-center">Out</th>
								<th class="text-center">Nov</th>
								<th class="text-center">Dez</th>
								<th class="text-center">TOTAL</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ($param_rel->lanc as $key => $value){ 
									foreach ($value as $k1 => $v1){
							?>
								<tr>
									<td class="text-left">
										<?= strtoupper($v1->nome_fantasia); ?>
									</td>
									<td class="text-left">
										<?= $v1->codigo_produto; ?>
									</td>
									<td class="text-left">
										<?= $v1->nome_vendedor; ?>
									</td>
									<?php
										for($x = 1; $x <= 12; $x++){
											$mes = nomeMes($x);
											//var_dump($mes, $v1);
									?>			
										<td class="text-right"><?= (isset($v1->mes->$mes->valor))?number_format($v1->mes->$mes->valor, 0, ',','.'):0; ?></td>
									<?php } ?>	
									<td class="text-right"><?= number_format($v1->total_anual, 0, ',','.'); ?></td>
								</tr>
							<?php 
									} 
								} 
							?>	
						</tbody>
						<tfoot>
							<tr>
								<td colspan="3"><b>TOTAL SEM TRIBUTOS</b></td>
								<?php for($x = 1; $x <= 12; $x++){ $mes = nomeMes($x); $tvl += $param_rel->total_mensal->$mes; ?>
									<td class="text-right"><b><?= number_format($param_rel->total_mensal->$mes, 0, ',','.'); ?></b></td>
								<?php } ?>
								<td class="text-right"><b><?= number_format($tvl, 0, ',','.'); ?></b></td>
							</tr>
<!-- 							<tr>
								<td colspan="3"><b>QUOTA MENSAL REALIZADA</b></td>
								<?php for($x = 1; $x <= 12; $x++){ $mes = nomeMes($x); ?>
									<?php if($param_rel->meta_acumulada->$mes >= 0){ ?>
										<td class="text-right" style="color:green"><b><?= number_format($param_rel->meta_acumulada->$mes, 0, ',','.'); ?></b></td>
									<?php }else{ ?>
										<td class="text-right" style="color:red"><b><?= number_format($param_rel->meta_acumulada->$mes, 0, ',','.'); ?></b></td>
									<?php } ?>								
								<?php } ?>
								<?php if(isset($total_meta_acumulada) && $total_meta_acumulada >= 0){ ?>
									<td class="text-right" style="color:green"><b><?= number_format($total_meta_acumulada, 0, ',','.'); ?></b></td>
								<?php }else{ ?>
									<td class="text-right" style="color:red"><b><?= (isset($total_meta_acumulada))?number_format($total_meta_acumulada, 0, ',','.'):0; ?></b></td>
								<?php } ?>
							</tr> -->					
							<tr>
								<td colspan="16"><b>QUOTA MENSAL</b></td>
							</tr>
								<?php if($param_rel->quota_mensal){ ?>
									<?php foreach($param_rel->quota_mensal as $key => $value ){ ?>
										<tr>
											<td colspan="3"><b><?= $value->nome_vendedor; ?></b></td>	
											<?php 
												for($x = 1; $x <= 12; $x++){ 
													$mes = nomeMes($x);
													$tqv[$key] += $value->meses->$mes->valor;
											?>
											<td class="text-right"><?= number_format($value->meses->$mes->valor, 0, ',','.'); ?></td>
											<?php } ?>
											<td class="text-right"><?= number_format($tqv[$key], 0, ',','.'); ?></td>
										</tr>
									<?php } ?>
								<?php } ?>
							<tr>
								<td colspan="3"><b>META MENSAL</b></td>
								<?php if($param_rel->meta_mensal){ ?>
									<?php for($x = 1; $x <= 12; $x++){ $mes = nomeMes($x); $tmm += $param_rel->meta_mensal->$mes ?>
										<td class="text-right"><?= number_format($param_rel->meta_mensal->$mes, 0, ',','.'); ?></td>
									<?php } ?>
								<?php } ?>
								<td class="text-right"><b><?= number_format($tmm, 0, ',','.'); ?></b></td>
							</tr>
						</tfoot>
					</table>
				</div>
			</div>
		</div>
	</form>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript">
		$(function() {
			var $url = '/budget/hunterview/';
			$('.filtro').change(function(){
				$('#filtro').attr('action', $url).submit();
			});

			oTable = $('#list').DataTable({
				info: false,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				}
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
