<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "ebta";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Bugdet</li>
		<li>EBTDA</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> EBTDA</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<form class="form-inline page-toolbar" id="filtro" method="post" action="">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-6">
					<div class="pull-left">
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
								<select class="form-control filtro" name="ano" id="ano">
									<?php foreach (listaAnos() as $key => $value){ ?>
    									<option value="<?=$key;?>" <?=($ano == $value)?"selected":"";?>><?= $value; ?></option>    
    								<?php } ?>
								</select>
							</div>
						</div>
					</div>
					<!-- <div class="pull-left">
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="glyphicon glyphicon-tasks"></i></span>
								<select class="form-control filtro" name="tipo" id="tipo">
									<option value="todos" <?= ($tipo == 'todos')?'selected':null ?> >Todos</option>
									<option value="upselling" <?= ($tipo == 'upselling')?'selected':null ?> >Up Selling</option>
								</select>
							</div>
						</div>
					</div> -->
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<table id='list' class="table-default table-striped table-bordered table-hover" width="100%">
						<thead>
							<tr>
								<th class="text-left">Cliente</th>
								<th class="text-left">Produto</th>
								<th class="text-center">Jan</th>
								<th class="text-center">Fev</th>
								<th class="text-center">Mar</th>
								<th class="text-center">Abr</th>
								<th class="text-center">Mai</th>
								<th class="text-center">Jun</th>
								<th class="text-center">Jul</th>
								<th class="text-center">Ago</th>
								<th class="text-center">Set</th>
								<th class="text-center">Out</th>
								<th class="text-center">Nov</th>
								<th class="text-center">Dez</th>
								<th class="text-center">TOTAL</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ($param_rel->lanc as $key => $value){ 
									foreach ($value as $k1 => $v1){
							?>
								<tr>
									<td class="text-left">
										<?= strtoupper($v1->nome_fantasia); ?>
									</td>
									<td class="text-left">
										<?= $v1->codigo_produto; ?>
									</td>
									<?php
										for($x = 1; $x <= 12; $x++){
											$mes = nomeMes($x);
											//var_dump($mes, $v1);
									?>			
										<td class="text-right"><?= number_format($v1->mes->$mes->valor, 0, ',','.'); ?></td>
									<?php } ?>	
									<td class="text-right"><?= number_format($v1->total_anual, 0, ',','.'); ?></td>
								</tr>
							<?php 
									} 
								} 
							?>
						</tbody>
						<tfoot>
							<tr>
							<td align="left" colspan="2"><b>PAGAMENTOS</b></td>
							<?php foreach ($param['despesas'] as $key => $value){ ?>
								<td align="right"><font color="red"><b><?= number_format($value['total'], 0, ',','.'); ?></b></font></td>
							<?php }	?>
							<td align="right"><font color="red"><b><?= number_format($param['total'], 0, ',','.'); ?></b></font></td>
							</tr>
							<tr>
								<td colspan="2"><b>RECEBIMENTOS</b></td>
								<?php for($x = 1; $x <= 12; $x++){ $mes = nomeMes($x); ?>
									<td class="text-right"><font color="green"><b><?= number_format($param_rel->total_mensal->$mes, 0, ',','.'); ?></b></font></td>
								<?php } ?>
								<td class="text-right"><font color="green"><b><?= number_format($total_anual, 0, ',','.'); ?></b></font></td>
							</tr>
						</tfoot>
					</table>
				</div>
			</div>
		</div>
	</form>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript">
		$(function() {
			var $url = '/budget/recebimento/';
			$('.filtro').change(function(){
				$('#filtro').attr('action', $url).submit();
			});

			oTable = $('#list').DataTable({
				info: false,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				}
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
