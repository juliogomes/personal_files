<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "contratos";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Contratos</li>
		<li><?= $records[0]->numero_contrato ?> - <?= $records[0]->nome_fantasia ?></li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> Modos de Cobrança</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-12">
				<form action="<?php echo HOME_URI.$this->module.'/cobranca/save/id/'.$this->parametros[2]; ?>" name="save" method="post">
					<?php
					if(isset($lista_preco) && !empty($lista_preco)) {
						// echo json_encode($lista_preco);
						foreach($lista_preco as $key=>$value) {
							if(is_array($value)) {?>
							<fieldset>
								<legend><?= $key ?></legend>
								<?php for($x = 0; $x < count($value); $x++) {
									$mod = $value[$x]['id_modulos_tarifaveis'];
									$modulo = $value[$x]['descricao'];
									$tipo = $value[$x]['tipo_cobranca'];
									?>
									<?php if($tipo ==  'VOLUMETRIA') { ?>
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<label for="cobranca[volumetria][$id_modulo][qtd_de]">DE</label>
												<input type="number" class="form-control" placeholder="9999" value="<?php echo $value[$x]['qtd_de'] ?>" name="cobranca[volumetria][<?php echo $mod; ?>][<?php echo $x; ?>][qtd_de]" required />
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<label for="cobranca[volumetria][$key][qtd_ate]">ATÉ</label>
												<input type="number" class="form-control" placeholder="9999" value="<?php echo $value[$x]['qtd_ate'] ?>" name="cobranca[volumetria][<?php echo $mod; ?>][<?php echo $x; ?>][qtd_ate]" required />
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<label for="cobranca[volumetria][$key][valor_real]">VALOR</label>
												<input type="text" class="form-control mask-money" placeholder="0.00" value="<?php echo $value[$x]['valor_real'] ?>" name="cobranca[volumetria][<?php echo $mod; ?>][<?php echo $x; ?>][valor_real]" required />
											</div>
										</div>
									</div>
									<?php } elseif($tipo == 'VALOR-FIXO') { ?>
									<div class="form-group">
										<label for="cobranca[valor_fixo][<?php echo $mod; ?>][<?php echo $x; ?>][valor-total]">VALOR TOTAL</label>
										<input type="text" class="form-control mask-money" placeholder="0.00" value="<?php echo $value[$x]['valor_total'] ?>" name="cobranca[valor-fixo][<?php echo $mod; ?>][<?php echo $x; ?>][valor_total]" required />
									</div>
									<?php } elseif($tipo == 'LIQUIDADO-REAL') { ?>
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<label for="cobranca[liquidado-real][<?php echo $mod; ?>][<?php echo $x; ?>][qtd_de]">QUANTIDADES DE</label>
												<input type="number" class="form-control" placeholder="9999" value="<?php echo $value[$x]['qtd_de'] ?>" name="cobranca[liquidado-real][<?php echo $mod; ?>][<?php echo $x; ?>][qtd_de]" required />
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<label for="cobranca[liquidado-real][<?php echo $mod; ?>][<?php echo $x; ?>][qtd_ate]">QUANTIDADES ATÉ</label>
												<input type="number" class="form-control" placeholder="9999" value="<?php echo $value[$x]['qtd_ate'] ?>" name="cobranca[liquidado-real][<?php echo $mod; ?>][<?php echo $x; ?>][qtd_ate]" required />
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<label for="cobranca[liquidado-real][<?php echo $mod; ?>][<?php echo $x; ?>][valor_real]">VALOR REAL</label>
												<input type="text" class="form-control mask-money" placeholder="0.00" value="<?php echo $value[$x]['valor_real'] ?>" name="cobranca[liquidado-real][<?php echo $mod; ?>][<?php echo $x; ?>][valor_real]" required />
											</div>
										</div>
									</div>
									<?php } elseif($tipo =='LIQUIDADO-RELATIVO') {?>
									<div class="row">
										<div class="col-md-3">
											<div class="form-group">
												<label for="cobranca[liquidado-relativo][<?php echo $mod; ?>][<?php echo $x; ?>][qtd_de]">QUANTIDADES DE</label>
												<input type="number" class="form-control" placeholder="9999" value="<?php  echo $value[$x]['qtd_de'] ?>" name="cobranca[liquidado-relativo][<?php echo $mod; ?>][<?php echo $x; ?>][qtd_de]" required />
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label for="cobranca[liquidado-relativo][<?php echo $mod; ?>][<?php echo $x; ?>][qtd_ate]">QUANTIDADES ATÉ</label>
												<input type="number" class="form-control" placeholder="9999" value="<?php  echo $value[$x]['qtd_ate']; ?>" name="cobranca[liquidado-relativo][<?php echo $mod; ?>][<?php echo $x; ?>][qtd_ate]" required />
											</div>
										</div>
										<div class="col-md-2">
											<div class="form-group">
												<label for="cobranca[liquidado-relativo][<?php echo $mod; ?>][<?php echo $x; ?>][idade_de]">IDADE DE</label>
												<input type="number" class="form-control" placeholder="9999" value="<?php  echo $value[$x]['idade_de']; ?>" name="cobranca[liquidado-relativo][<?php echo $mod; ?>][<?php echo $x; ?>][idade_de]" required />
											</div>
										</div>
										<div class="col-md-2">
											<div class="form-group">
												<label for="cobranca[liquidado-relativo][<?php echo $mod; ?>][<?php echo $x; ?>][idade_ate]">IDADE DE ATÉ</label>
												<input type="number" class="form-control" placeholder="9999" value="<?php  echo $value[$x]['idade_ate']; ?>" name="cobranca[liquidado-relativo][<?php echo $mod; ?>][<?php echo $x; ?>][idade_ate]" required />
											</div>
										</div>
										<div class="col-md-2">
											<div class="form-group">
												<label for="cobranca[liquidado-relativo][<?php echo $mod; ?>][<?php echo $x; ?>][valor_relativo]">VALOR RELATIVO</label>
												<input type="text" class="form-control mask-money" placeholder="0.00%" value="<?php echo $value[$x]['valor_relativo'] ?>" name="cobranca[liquidado-relativo][<?php echo $mod; ?>][<?php echo $x; ?>][valor_relativo]" required />
											</div>
										</div>
									</div>
									<?php } elseif($tipo == 'COBRANCA-ELETRONICA') { ?>
									<div class="row">
										<div class="col-md-4">
											<div class="form-group">
												<label for="cobranca[cobranca-eletronica][<?php echo $mod; ?>][<?php echo $x; ?>][qtd_de]">QUANTIDADES DE</label>
												<input type="number" class="form-control" placeholder="9999" value="<?php  echo $value[$x]['qtd_de'] ?>" name="cobranca['cobranca-eletronica'][<?php echo $mod; ?>][<?php echo $x; ?>][qtd_de]" required />
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<label for="cobranca[cobranca-eletronica][<?php echo $mod; ?>][<?php echo $x; ?>][qtd_ate]">QUANTIDADES ATÉ</label>
												<input type="number" class="form-control" placeholder="9999" value="<?php  echo $value[$x]['qtd_ate'] ?>" name="cobranca['cobranca-eletronica'][<?php echo $mod; ?>][<?php echo $x; ?>][qtd_ate]" required />
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<label for="cobranca[cobranca-eletronica][<?php echo $x; ?>][percentual]">PERCENTUAL</label>
												<input type="text" class="form-control mask-money" placeholder="0.00" value="<?php echo $value[$x]['percentual'] ?>" name="cobranca['cobranca-eletronica'][<?php echo $mod; ?>][<?php echo $x; ?>][percentual]" required />
											</div>
										</div>
									</div>
									<?php } elseif($tipo  == 'GOCHK') { ?>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label for="cobranca[gochk][<?php echo $mod; ?>][<?php echo $x; ?>][valor_relativo]">VALOR RELATIVO</label>
												<input type="text" class="form-control mask-money" placeholder="0.00%" value="<?php $value[$x]['valor_relativo'] ?>" name="cobranca[gochk][<?php echo $mod; ?>][<?php echo $x; ?>][valor_relativo]" required />
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="cobranca[gochk][<?php echo $mod; ?>][<?php echo $x; ?>][valor_real]">VALOR REAL</label>
												<input type="text" class="form-control mask-money" placeholder="0.00" value="<?php echo $value[$x]['valor_real'] ?>" name="cobranca['gochk'][<?php echo $mod; ?>][<?php echo $x; ?>][valor_real]" required />
											</div>
										</div>
									</div>
									<?php } elseif($tipo  == 'KUMRAM') { ?>
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label for="cobranca[gochk][<?php echo $mod; ?>][<?php echo $x; ?>][qtd_licencas]">VALOR RELATIVO</label>
												<input type="text" class="form-control mask-money" placeholder="0.00%" value="<?php $value[$x]['valor_relativo'] ?>" name="cobranca[gochk][<?php echo $mod; ?>][<?php echo $x; ?>][qtd_licencas]" required />
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label for="cobranca[gochk][<?php echo $mod; ?>][<?php echo $x; ?>][valor_real]">VALOR REAL</label>
												<input type="text" class="form-control mask-money" placeholder="0.00" value="<?php echo $value[$x]['valor_real'] ?>" name="cobranca['gochk'][<?php echo $mod; ?>][<?php echo $x; ?>][valor_real]" required />
											</div>
										</div>
									</div>
									<?php } ?>
									<?php } ?>
								</fieldset>
								<?php } else {
								//echo 'NAO È ARRAY';
								}
							} // FOREACH PRINCIPAL
						} // If ISSET
						else
						{
							echo 'NENHUMA LISTA DE PRECO ENCONTRADA!';
						}
						?>
					<button type="submit" class="btn btn-primary"><i class="fa fa-caret-right-o"></i> Próximo</button>
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$(function() {
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>