<div class="container">
    <div class="row">
        <div class="col-md-8">
            <div>PACOTES PERSONALIZADOS PARA O PRODUTO: <?php echo $records[0]->nome_produto ?></div>
            <div class="col-md-10">
            <div class="msg_erro"><?php echo $this->modelo->error; ?></div>
            <div class="msg_sucesso"><?php echo $this->modelo->success; ?></div>
                <form action="<?php echo HOME_URI.$this->module.'/pacotes/save/id/'.$this->parametros[2]; ?>" name="save" method="post">
                <?php 
                    foreach ($modulos as $key => $value)
                    {
                            
                        if($value['empacotavel'] == 1)
                        {
                        ?>
                        <label><?php echo $value['modulo_codigo'] ?></label>
                        <label>QAUNTIDADE DE TRANSAÇÕES</label>
                        <input type="number" name="pacote[<?php echo $value['modulo_id']; ?>][qdt_garantido]" value="">
                        <label>VALOR</label>
                        <input type="text" name="pacote[<?php echo $value['modulo_id']; ?>][preco_pkt]" value="">
                        <br>

                        
                    <?php
                        }
                    }
                    ?>

                <input type="submit" name="" value="PROXIMO">
                </form>
            </div>
        </div>
    </div>
</div>
