<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "contratos";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Contratos</li>
	</ol>
	<h4 class="page-title">
		<?php
		if(empty($this->parametros[2])){
			echo '<i class="fa fa-plus"></i> Novo Contrato';
		}
		else
		{
			echo '<i class="fa fa-edit"></i> Editar Contrato';
		}
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-9">
				<form id="form" action="<?php echo HOME_URI.$this->module.'/contratos/save/id/'.$this->parametros[2].''; ?>" name="save" method="post">
					<fieldset>
						<legend>Cliente</legend>
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label for="codigo_cliente">Codigo do Cliente</label>
									<input type="text" class="form-control masked" id="inscricao_estadual" placeholder="99999999" maxlength="8" minlength="8" value="<?php echo isset($records[0])?$records[0]->codigo_cliente:null ?>" name="codigo_cliente" data-masked="00000000"/>
								</div>
							</div>
							<div class="col-md-5">
								<div class="form-group">
									<label for="cnpj">CNPJ</label>
									<input type="text" class="form-control masked" id="cnpj" placeholder="99.999.999/9999-99" value="<?php echo isset($records[0])?$records[0]->cnpj:null ?>" name="cnpj" data-masked="00.000.000/0000-00"/>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="inscricao_estadual">Inscrição Estadual</label>
									<input type="text" class="form-control" id="inscricao_estadual" placeholder="999.999.999.999" value="<?php echo isset($records[0])?$records[0]->inscricao_estadual:null ?>" name="inscricao_estadual"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="razao_social">Razao Social</label>
									<input type="text" class="form-control" class="form-control" value="<?php echo isset($records[0])?$records[0]->razao_social:null ?>" name="razao_social"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="nome_fantasia">Nome Fantasia</label>
									<input type="text" class="form-control" value="<?php echo isset($records[0])?$records[0]->nome_fantasia:null ?>" name="nome_fantasia"/>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Contrato</legend>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="numero_contrato">Número Contrato</label>
									<input type="text" class="form-control" placeholder="00000000000" value="<?php echo isset($records[0])?$records[0]->numero_contrato:null ?>" id="numero_contato" name="numero_contrato"/>
								</div>
							</div>
							<div class="col-md-8">
								<div class="form-group">
									<label for="id_produto">Produto</label>
									<select name='id_produto' class="form-control select">
										<option value=''>Selecione</option>
										<?php
										foreach($this->produtos as $key=>$value)
										{
											if($value->id == $records[0]->id_produto)
											{
												echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome).'</option>';
											}
											else
											{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome).'</option>';
											}
										}
										?>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="segmento">Segmento</label>
									<select name="segmento" class="form-control select">
										<option value="">Selecione</option>
										<?php
										foreach ($this->globals['SEGMENTO'] as $key => $value) {
											if($key == $records[0]->segmento)
											{
												echo '<option value="'.$key.'" selected>'.strtoupper($value).'</option>';
											}
											else
											{
												echo '<option value="'.$key.'" >'.$value.'</option>';
											}
										}
										?>
									</select>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="moeda">Moeda</label>
									<select name="moeda" class="form-control select">
										<option value=''>Selecione</option>
										<option <?php echo (isset($records[0]) && $records[0]->moeda == 'real')?'selected':'' ?>  value="real">REAL</option>
										<option <?php echo (isset($records[0]) && $records[0]->moeda == 'dolar')?'selected':'' ?> value="dolar">DOLAR</option>
										<option <?php echo (isset($records[0]) && $records[0]->moeda == 'euro')?'selected':'' ?> value="euro">EURO</option>
									</select>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="preco_com_imposto">Preço Com Imposto</label>
									<select class="form-control select" name="preco_com_imposto" id="preco_com_imposto">
										<option value=''>Selecione</option>
										<option <?php echo (isset($records[0]) && $records[0]->preco_com_imposto == '0')?'selected':'' ?> value="0">NÃO</option>
										<option <?php echo (isset($records[0]) && $records[0]->preco_com_imposto == '1')?'selected':'' ?> value="1">SIM</option>
									</select>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Endereço</legend>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="cep">CEP</label>
									<input type="text" class="form-control cep" id="cep" placeholder="99999-999"value="<?php echo isset($records[0])?$records[0]->cep:null ?>" name="cep"/>
								</div>
							</div>
							<div class="col-md-8">
								<div class="form-group">
									<label for="endereco">Endereço</label>
									<input type="text" class="form-control" value="<?php echo isset($records[0])?$records[0]->endereco:null ?>" name="endereco" data-autocep-input="logradouro"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="bairro">Bairro</label>
									<input type="text" class="form-control" value="<?php echo isset($records[0])?$records[0]->bairro:null ?>" name="bairro" data-autocep-input="bairro"/>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="estado">Estado</label>
									<select name="estado" id="estado" class="form-control uf-cidade" data-pair="cidade" data-autocep-select="uf" >
										<option value="">Selecione</option>
									</select>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="cidade">Cidade</label>
									<select name="cidade" id="cidade" class="form-control cidade-uf" data-autocep-select="localidade">
										<option value=""></option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="url">Site</label>
									<input type="text" class="form-control" id="url" placeholder="http://www.site.com.br" value="<?php echo isset($records[0])?$records[0]->url:null ?>" name="url"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="emal_nf">Email para envio da Nota Fiscal</label>
									<input type="text" class="form-control" id="email_nf" placeholder="email@email.com" value="<?php echo isset($records[0])?$records[0]->email_nf:null ?>" name="email_nf"/>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Assinatura</legend>
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label for="data_assinatura">Data da Assinatura</label>
									<input type="text" class="form-control datepast" id="data_assinatura" placeholder="Dia/Mês/Ano" value="<?php echo isset($records[0])?convertDate($records[0]->data_assinatura):null ?>" name="data_assinatura"/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="duracao_contrato">Duração do Contrato</label>
									<input type="text" class="form-control" placeholder="Número de dias" value="<?php echo isset($records[0])?$records[0]->duracao_contrato:null ?>" name="duracao_contrato"/>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="renovacao_automatica">Renovação Automatica</label>
									<select name="renovacao_automatica" class="form-control select">
										<option value=''>Selecione</option>
										<option <?php echo (isset($records[0]) && $records[0]->renovacao_automatica == '0')?'selected':'' ?> value="0">NÃO</option>
										<option <?php echo (isset($records[0]) && $records[0]->renovacao_automatica == '1')?'selected':'' ?> value="1">SIM</option>
									</select>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="contrato_indeterminado">Indeterminado</label>
									<select name="contrato_indeterminado" class="form-control select">
										<option value=''>Selecione</option>
										<option <?php echo (isset($records[0]) && $records[0]->contrato_indeterminado == '1')?'selected':'' ?> value="1">SIM</option>
										<option <?php echo (isset($records[0]) && $records[0]->contrato_indeterminado == '0')?'selected':'' ?> value="0">NÃO</option>
									</select>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Comissão</legend>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="id_empresa">Empresa Vendedora</label>
									<select name='id_empresa' class="form-control select">
										<option value=''>Selecione</option>
										<?php
										foreach($this->empresas as $key=>$value)
										{
											if($value->id == $records[0]->id_empresa)
											{
												echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome_fantasia).'</option>';
											}
											else
											{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome_fantasia).'</option>';
											}
										}
										?>
									</select>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="comissoes[id_vendedor]">Gerente Comercial</label>
									<select name='comissoes[id_vendedor]' class="form-control select">
										<option value=''>Selecione</option>
										<?php
										foreach($this->vendedores as $key=>$value)
										{
											if($value->id == $records[0]->id_vendedor)
											{
												echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome).'</option>';
											}
											else
											{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome).'</option>';
											}
										}
										?>
									</select>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="comissoes[id_diretor]">Diretor Comercial</label>
									<select name='comissoes[id_diretor]' class="form-control select">
										<option value=''>Selecione</option>
										<?php
										foreach($this->diretores as $key=>$value)
										{
											if($value->id == $records[0]->id_diretor)
											{
												echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome).'</option>';
											}
											else
											{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome).'</option>';
											}
										}
										?>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="comissoes[tipo_comissao]">Tipo de Comissão</label>
									<select name="comissoes[tipo_comissao]" class="form-control select">
										<option value="">Selecione</option>
										<?php
										foreach ($this->globals['TIPO_COMISSAO'] as $key => $value) {
											if($key == $records[0]->tipo_comissao)
											{
												echo '<option value="'.$key.'" selected>'.strtoupper($value).'</option>';
											}
											else
											{
												echo '<option value="'.$key.'" >'.$value.'</option>';
											}
										}
										?>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="comissoes[comissao_devida_ate]">Comissão Devida Até</label>
									<input type="text" class="form-control datepast" placeholder="Dia/Mês/Ano" value="<?php echo isset($records[0])?convertDate($records[0]->comissao_devida_ate):null ?>" name="comissoes[comissao_devida_ate]"/>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Reajuste</legend>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="contrato_aniversario[data_reajuste]">Data de Reajuste</label>
									<input type="text" class="form-control datepast" placeholder="Dia/Mês/Ano" value="<?php echo isset($records[0])?convertDate($records[0]->data_reajuste):null ?>" name="contrato_aniversario[data_reajuste]"/>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="contrato_aniversario[id_indice]">Indice de Reajuste</label>
									<select name='contrato_aniversario[id_indice]' class="form-control select">
										<option value=''>Selecione</option>
										<?php
										foreach($this->indices as $key=>$value)
										{
											if($value->id == $records[0]->id_indice)
											{
												echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->indice).'</option>';
											}
											else
											{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->indice).'</option>';
											}
										}
										?>
									</select>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Implantação</legend>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="valor_implantacao">Valor de Implantação</label>
									<input type="text" class="form-control mask-money" placeholder="R$" value="<?php echo isset($records[0])?convertDate($records[0]->valor_implantacao):null ?>" name="valor_implantacao"/>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="parcelado_em">Parcelado Em</label>
									<select name="parcelado_em" class="form-control select">
										<option value="">Selecione</option>
										<option <?php echo (isset($records[0]) && $records[0]->parcelado_em == '1')?'selected':'' ?> value="1">1</option>
										<option <?php echo (isset($records[0]) && $records[0]->parcelado_em == '2')?'selected':'' ?> value="2">2</option>
										<option <?php echo (isset($records[0]) && $records[0]->parcelado_em == '3')?'selected':'' ?> value="3">3</option>
									</select>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="primeira_parcela_em">Primeira Parcela Em</label>
									<input type="text" class="form-control datepast" placeholder="Dia/Mês/Ano" value="<?php echo isset($records[0])?convertDate($records[0]->primeira_parcela_em):null ?>" name="primeira_parcela_em"/>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Faturamento</legend>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="data_corte_faturamento">Data de Corte do Faturamento</label>
									<input type="text" class="form-control datepast" placeholder="Dia/Mês/Ano" value="<?php echo isset($records[0])?convertDate($records[0]->data_corte_faturamento):null ?>" name="data_corte_faturamento"/>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="numero_dias_apos_corte">Dias de Pagamento Faturamento</label>
									<input type="number" class="form-control" placeholder="Dias" value="<?php echo isset($records[0])?$records[0]->numero_dias_apos_corte:null ?>" name="numero_dias_apos_corte"/>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Outros Valores, Juros e Multa</legend>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="hospedagem_mensal">Hospedagem</label>
									<input type="text" class="form-control mask-money" placeholder="R$" value="<?php echo isset($records[0])?$records[0]->hospedagem_mensal:null ?>" name="hospedagem_mensal"/>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="licenca_uso_mensal">Licença Uso</label>
									<input type="text" class="form-control mask-money" placeholder="R$" value="<?php echo isset($records[0])?$records[0]->licenca_uso_mensal:null ?>" name="licenca_uso_mensal"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="multa">Percentual da Multa</label>
									<input type="number" class="form-control" placeholder="%" value="<?php echo isset($records[0])?$records[0]->multa:null ?>" name="multa"/>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="juros">Percentual de Juros</label>
									<input type="number" class="form-control" placeholder="%" value="<?php echo isset($records[0])?$records[0]->juros:null ?>" name="juros"/>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Limites</legend>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="ultima_data_demo">Data Limite de Demo</label>
									<input type="text" class="form-control datepast" placeholder="Dia/Mês/Ano" value="<?php echo isset($records[0])?convertDate($records[0]->ultima_data_demo):null ?>" name="ultima_data_demo"/>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="carencia_de_uso">Data Limite de Carência </label>
									<input type="text" class="form-control datepast" placeholder="Dia/Mês/Ano" value="<?php echo isset($records[0])?convertDate($records[0]->carencia_de_uso):null ?>" name="carencia_de_uso"/>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Contato</legend>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="contato">Responsável</label>
									<input type="text" class="form-control" placeholder="Nome" value="<?php echo isset($records[0])?$records[0]->contato:null ?>" name="contato"/>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="email_contato">Email Responsável</label>
									<input type="text" class="form-control" placeholder="email@dominio.com.br" value="<?php echo isset($records[0])?$records[0]->email_contato:null ?>" name="email_contato"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="contato_tecnico">Contato Tecnico</label>
									<input type="text" class="form-control" placeholder="Nome" value="<?php echo isset($records[0])?$records[0]->contato_tecnico:null ?>" name="contato_tecnico"/>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="email_contato_tecnico">Email Contato Tecnico</label>
									<input type="text" class="form-control" placeholder="email@dominio.com.br" value="<?php echo isset($records[0])?$records[0]->email_contato_tecnico:null ?>" name="email_contato_tecnico"/>
								</div>
							</div>
						</div>
					</fieldset>
					<div class="form-group">
						<label for="status">Status</label>
						<select name='status' class="form-control select">
							<option value=''>Selecione</option>
							<option value='inativo' <?php echo (isset($records[0]) && $records[0]->status == 'inativo')?'selected':'' ?> >INATIVO</option>
							<option value='ativo' <?php echo (isset($records[0]) && $records[0]->status == 'ativo')?'selected':'' ?> >ATIVO</option>
							<option value='suspenso' <?php echo (isset($records[0]) && $records[0]->status == 'suspenso')?'selected':'' ?> >SUSPENSO</option>
						</select>
					</div>
					<button type="submit" class="btn btn-primary"><i class="fa fa-caret-right-o"></i> Próximo</button>
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$(function() {
			$form = $('#form');
			$form.formValidation({
				framework: 'bootstrap',
				excluded: ':disabled',
				icon: {
					valid: 'fa fa-check',
					invalid: 'fa fa-times',
					validating: 'fa fa-refresh'
				},
				addOns: {
					mandatoryIcon: {
						icon: 'fa fa-asterisk'
					}
				},
				live: 'enabled',
				fields: {
					'status': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'valor_implantacao': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'parcelado_em': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'primeira_parcela_em': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'data_corte_faturamento': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'numero_dias_apos_corte': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'hospedagem_mensal': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'licenca_uso_mensal': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'multa': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'juros': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'ultima_data_demo': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'carencia_de_uso': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'contato': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'email_contato': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'contato_tecnico': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'email_contato_tecnico': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'id_empresa': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'comissoes[id_vendedor]': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'comissoes[id_diretor]': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'comissoes[tipo_comissao]': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'comissoes[comissao_devida_ate]': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'contrato_aniversario[data_reajuste]': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'contrato_aniversario[id_indice]': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'data_assinatura': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'duracao_contrato': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'renovacao_automatica': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'contrato_indeterminado': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'url': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'email_nf': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'moeda': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'preco_com_imposto': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'numero_contrato': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'codigo_cliente': { validators:{ notEmpty:{ message:"Campo Obrigatório" }, stringLength: { message: 'Preencha com 8 números' } } },
					'segmento': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'id_produto': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'razao_social': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'nome_fantasia': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'cnpj':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							},
							regexp: {
								regexp: /^[0-9]{2}\.[0-9]{3}\.[0-9]{3}\/[0-9]{4}\-[0-9]{2}$/i,
								message: 'CNPJ não é Válido'
							}
						}
					},
					'inscricao_estadual':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'inscricao_municipal':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'cep':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							},
							regexp: {
								regexp: /^[0-9]{5}\-[0-9]{3}$/i,
								message: 'CEP não é Válido'
							}
						}
					},
					'endereco':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'bairro':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'estado':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'cidade':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					}
				}
			});
});
</script>
<?php if (isset($records[0])){ ?>
<script type="text/javascript">
	$(function() {
		$('#estado').selectpicker('val', '<?= $records[0]->estado ?>').trigger("change").end();
		$('#cidade').selectpicker('val', '<?= $records[0]->cidade ?>').trigger("change").end();
	});
</script>
<?php } ?>
<!-- /PAGE SCRIPTS -->
</body>
</html>