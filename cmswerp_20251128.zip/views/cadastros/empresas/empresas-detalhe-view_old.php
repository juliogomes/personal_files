<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "empresas";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Gestão</li>
		<li>Empresas</li>
	</ol>
	<h4 class="page-title">
		<?php
		if(empty($this->parametros[2])){
			echo '<i class="fa fa-plus"></i> Nova Empresa';
		}
		else
		{
			echo '<i class="fa fa-edit"></i> Editar Empresa';
		}
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-12">
				<form id="form" action="<?php echo HOME_URI.$this->module.'/empresas/save/id/'.$this->parametros[2]; ?>" class="" method="post">
					<fieldset>
						<legend>Dados da Empresa</legend>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="razao_social">Razão Social</label>
									<input type="text" maxlength="75" class="form-control" id="razao_social" name="razao_social" placeholder="Razao Social" value="<?php echo isset($records)?$records->razao_social:null ?>"/>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="nome_fantasia">Nome Fantasia</label>
									<input type="text" maxlength="75" class="form-control" name="nome_fantasia" id="nome_fantasia" placeholder="Nome Fantasia" value="<?php echo isset($records)?$records->nome_fantasia:null ?>"/>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="cnpj">CNPJ</label>
									<input type="text" class="form-control masked" id="cnpj" name="cnpj" placeholder="99.999.999/9999-99" value="<?php echo isset($records)?$records->cnpj:null ?>"
									data-masked="00.000.000/0000-00"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="inscricao_estadual">Inscrição Estadual </label>
									<input type="text" class="form-control" id="inscricao_estadual" name="inscricao_estadual" placeholder="Inscrição Estadual" value="<?php echo isset($records)?$records->inscricao_estadual:null ?>"/>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="inscricao_municipal">Inscrição Municipal</label>
									<input type="text" class="form-control" id="inscricao_municipal" name="inscricao_municipal" placeholder="Inscrição Municipal" value="<?php echo isset($records)?$records->inscricao_municipal:null ?>"/>
								</div>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Endereço</legend>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="cep">CEP</label>
									<input type="text" maxlength="9" class="form-control cep" id="cep" name="cep" placeholder="00000-000" value="<?php echo isset($records)?$records->cep:null ?>"/>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="endereco">Endereço</label>
									<input type="text" maxlength="75" class="form-control" name="endereco" id="endereco" placeholder="Logradouro" value="<?php echo isset($records)?$records->endereco:null ?>" data-autocep-input="logradouro"/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-4">
								<div class="form-group">
									<label for="cidade">Cidade</label>
									<select name="cidade" maxlength="40" id="cidade" class="form-control cidade-uf" data-autocep-select="localidade">
										<option value=""></option>
									</select>
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="estado">Estado</label>
									<select name="estado" id="estado" class="form-control uf-cidade" data-pair="cidade" data-autocep-select="uf" >
										<option value="">Selecione</option>
									</select>
								</div>
							</div>
						</div>
					</fieldset>
					<a href="/cadastros/empresas/list/" class="btn btn-default"><i class="fa fa-times"></i> Cancelar</a>
					<button type="submit" class="btn btn-primary pull-right"><i class="fa fa-floppy-o"></i> Salvar</button>
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
		<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$(function() {
			$form = $('#form');
			$form.formValidation({
				framework: 'bootstrap',
				excluded: ':disabled',
				icon: {
					valid: 'fa fa-check',
					invalid: 'fa fa-times',
					validating: 'fa fa-refresh'
				},
				addOns: {
					mandatoryIcon: {
						icon: 'fa fa-asterisk'
					}
				},
				live: 'enabled',
				fields: {
					'cnpj':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							},
							regexp: {
								regexp: /^[0-9]{2}\.[0-9]{3}\.[0-9]{3}\/[0-9]{4}\-[0-9]{2}$/i,
								message: 'CNPJ não é Válido'
							}
						}
					},
					'cep':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							},
							regexp: {
								regexp: /^[0-9]{5}\-[0-9]{3}$/i,
								message: 'CEP não é Válido'
							}
						}
					},
					'endereco':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'bairro':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'estado':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'cidade':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					}
				}
			});
});
</script>
<?php if (isset($records)){ ?>
<script type="text/javascript">
	function justNumber(string) 
	{
	    var numsStr = string.replace(/[^0-9]/g,'');
	    return parseInt(numsStr);
	}

	$(function() {
		var estado = '<?= $records->estado ?>';
		var cidade = '<?= $records->cidade ?>';
		setTimeout(function(){
		
		$('#estado').selectpicker('val', estado);

		  if (estado) {
		    $('#estado').trigger("change");
		  }

		$('#cidade').selectpicker('val', cidade);
		if (cidade) {
		    $('#cidade').trigger("change");
		  }
		 },0);
	});
</script>
<?php } ?>
<!-- /PAGE SCRIPTS -->
</body>
</html>