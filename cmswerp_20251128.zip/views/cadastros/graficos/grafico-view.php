<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
<meta http-equiv="refresh" content="300">
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<script src='/assets/js/locale/pt-br.js'></script>
	<script src='/assets/js/Chart.bundle.min.js'></script>
	<script src='/assets/js/utils.js'></script>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "graficos";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Gestão</li>
		<li>Gráfico</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i>Grafico
	</h4>
	<a href="/cadastros/showdash/" class="btn btn-success" target="_blank">VER NO DASHBOARD</a>
	<div class="container-fluid">
		<div class="row">
			<div style="width:75%;">
			<canvas id="canvas"></canvas>
			</div>
			<br>
			<br>
			<!--
			<button id="randomizeData">Randomize Data</button>
			<button id="addDataset">Add Dataset</button>
			<button id="removeDataset">Remove Dataset</button>
			<button id="addData">Add Data</button>
			<button id="removeData">Remove Data</button> 
			-->
			<script>
			var MONTHS = <?= $json_dias; ?>;
			var config = {
			type: 'line',
			data: {
			labels: <?= $json_dias; ?>,
			datasets: [{
			label: "ROCKET",
			backgroundColor: window.chartColors.red,
			borderColor: window.chartColors.red,
			data:<?= $json_rck; ?>,
			fill: false,
			}, {
			label: "SPB",
			fill: false,
			backgroundColor: window.chartColors.blue,
			borderColor: window.chartColors.blue,
			data:<?= $json_spb; ?>,
			}]
			},
			options: {
			responsive: true,
			title:{
			display:true,
			text:'Chart.js Line Chart'
			},
			tooltips: {
			mode: 'index',
			intersect: false,
			},
			hover: {
			mode: 'nearest',
			intersect: true
			},
			scales: {
			xAxes: [{
			display: true,
			scaleLabel: {
			display: true,
			labelString: 'Dias'
			}
			}],
			yAxes: [{
			display: true,
			scaleLabel: {
			display: true,
			labelString: 'Transacoes'
			}
			}]
			}
			}
			};

			window.onload = function() {
			var ctx = document.getElementById("canvas").getContext("2d");
			window.myLine = new Chart(ctx, config);
			};

			/*document.getElementById('randomizeData').addEventListener('click', function() {
				config.data.datasets.forEach(function(dataset) {
					dataset.data = dataset.data.map(function() {
						return randomScalingFactor();
					});
				});
				window.myLine.update();
			});*/

			var colorNames = Object.keys(window.chartColors);
			document.getElementById('addDataset').addEventListener('click', function() {
			var colorName = colorNames[config.data.datasets.length % colorNames.length];
			var newColor = window.chartColors[colorName];
			var newDataset = {
			label: 'Dataset ' + config.data.datasets.length,
			backgroundColor: newColor,
			borderColor: newColor,
			data: [],
			fill: false
			};

			for (var index = 0; index < config.data.labels.length; ++index) {
			newDataset.data.push(randomScalingFactor());
			}

			config.data.datasets.push(newDataset);
			window.myLine.update();
			});

			document.getElementById('addData').addEventListener('click', function() {
			if (config.data.datasets.length > 0) {
			var month = MONTHS[config.data.labels.length % MONTHS.length];
			config.data.labels.push(month);

			config.data.datasets.forEach(function(dataset) {
			dataset.data.push(randomScalingFactor());
			});

			window.myLine.update();
			}
			});

			document.getElementById('removeDataset').addEventListener('click', function() {
			config.data.datasets.splice(0, 1);
			window.myLine.update();
			});

			document.getElementById('removeData').addEventListener('click', function() {
			config.data.labels.splice(-1, 1); // remove the label first

			config.data.datasets.forEach(function(dataset, datasetIndex) {
			dataset.data.pop();
			});

			window.myLine.update();
			});
			</script>
		</div>
	</div>
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/dataTables.bootstrap.min.js"></script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
