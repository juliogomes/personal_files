<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "indices";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Indices</li>
		<li>Lista de indices</li>
	</ol>
	<h4 class="page-title">Índices de Reajuste</h4>
	<form class="form-inline page-toolbar">
		<div class="btn-group" role="group">
			<a href="/cadastros/indices/detalhe/id/0" class="btn btn-default"><i class="fa fa-plus"></i> Novo Índice</a>
		</div>
	</form>
		<form class="form-inline page-toolbar">
		<div class="pull-right">
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Indice</div>
					<input class="form-control" placeholder="igpm / ipca" type="text" id="searchIndice" style="width:100px;">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Ano</div>
					<input class="form-control" placeholder="AAAA" type="text" id="searchAno" style="width:155px;" >
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Mes</div>
					<input class="form-control" placeholder="MM" type="text" id="searchMes">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Percentual</div>
					<input class="form-control" placeholder="%" type="text" id="searchPercentual">
				</div>
			</div>
		</div>
	</form>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-sm-12">
				<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
					<thead>
						<tr>
							<th class="text-center">Índice</th>
							<th class="text-center">Mês</th>
							<th class="text-center">Ano</th>
							<th class="text-center">Percentual (%)</th>
							<th class="text-center">Opções</th>
						</tr>
					</thead>
					<tbody>
						<?php if(isset($records)) {?>
						<?php foreach($records as $key => $value) { ?>
							<?php $reajustes   = URL_SISTEMA.'cadastros/indices/historico/'.strtoupper($value->indice).'/'.$value->ano.'/reajustes_'.$value->mes;?>
							<?php $lancamentos = URL_SISTEMA.'cadastros/indices/historico/'.strtoupper($value->indice).'/'.$value->ano.'/lancamentos_'.$value->mes;?>
						<tr>
							<td class="text-center"><?= strtoupper($value->indice); ?></td>
							<td class="text-center"><?= $value->mes; ?></td>
							<td class="text-center"><?= $value->ano; ?></td>
							<td class="text-center"><?= $value->percentual; ?> %</td>
							<td class="text-center">
								<a class="btn btn-warning btn-mg" href="<?= $reajustes; ?>" target="_blank"><i class="fa fa-list"></i> Clientes</a>
								<a class="btn btn-info btn-mg" href="<?= $lancamentos; ?>" target="_blank"><i class="fa fa-money"></i> Lancamentos</a>
							</td>
						</tr>
						<?php } } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS --><!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript">
		$(function() {
			oTable = $('#list').DataTable({
				order:[ [ 2, "desc" ],[ 1, "desc" ] ],
				info: false,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				}
			});
			$('#searchIndice').keyup(function(){
				oTable
				.columns( 0 )
				.search( this.value )
				.draw();
			});
			$('#searchAno').keyup(function(){
				oTable
				.columns( 2 )
				.search( this.value )
				.draw();
			});
			$('#searchMes').keyup(function(){
				oTable
				.columns( 1 )
				.search( this.value )
				.draw();
			});
			$('#searchPercentual').keyup(function(){
				oTable
				.columns( 3 )
				.search( this.value )
				.draw();
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
	<!-- /PAGE SCRIPTS -->	
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
	<script type="text/javascript">
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>