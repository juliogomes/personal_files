<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "indices";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Indices</li>
		<li>Lançamentos de reajuste</li>
	</ol>
	<h4 class="page-title"></h4>

	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-sm-12">
				<a href="/cadastros/indices/list/" class="form-control btn btn-info"> FINALIZAR </a>
			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-sm-12 col-sm-12">
				<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
					<thead>
						<tr>
							<th>ID NF</th>
							<th>EMISSÃo</th>
							<th>CLIENTE</th>
							<th>PRODUTO</th>
							<th>VALOR</th>
							<th>STATUS</th>
							<th>MENSAGEM</th>
						</tr>
					</thead>
					<tbody>
						<?php if(isset($retorno) && $retorno[0] ) { ?>
							<?php 
								foreach ($retorno as $key => $value) {
									foreach ($value->dados as $k1 => $v1) {
										if($value->codigo == 0){
											$class = "alert alert-success";
										}elseif($value->codigo == 1){
											$class = "alert alert-danger";
										}elseif($value->codigo == 2){
											$class = "alert alert-warning";
										}
									?>
									<tr>
										<td><?= str_pad($v1->id_nf_origem, 6, 0, STR_PAD_LEFT); ?></td>
										<td><?= convertDate($v1->data_emissao); ?></td>
										<td><?= strtoupper($v1->cliente); ?></td>
										<td><?= $v1->codigo_produto; ?></td>
										<td><?= number_format($v1->valor_lancamento,'2',',','.'); ?></td>
										<td><div class="<?= $class; ?>" role="alert"><?= strtoupper($value->tipo); ?></div></td>
										<td><div class="<?= $class; ?>" role="alert"><?= $value->mensagem; ?></div></td>
									</tr>
								<?php }	?>
							<?php }	?>
						<?php }	?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
<!-- 	<script type="text/javascript">
		function waitForMsg() {
	        $.ajax({
	            type: 'POST',
	            url: '/cadastros/indices/updatepreco/ids/<?= $ids ?>',
	            async: true,
	            cache: false,
	            success: function(data) {
	                console.log(data);
	                //var json = eval('(' + data + ')');
	                // if (json['msg'] != undefined) {
	                // }
	                //timestamp = json['timestamp'];
	                $('#resultado').append(data);
	                //setTimeout('waitForMsg()' , 1000);
	            },
	            error: function(XMLHttpRequest , textStatus , errorThrow) {
	                //setTimeOut('waitForMsg()' , 15000);
	            }
	        } );
	    }

	</script>
	<script type="text/javascript">waitForMsg();</script> -->
 
 <!-- /PAGE SCRIPTS
</body>
</html>