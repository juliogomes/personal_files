<?php 
	ob_start(); 
	require_once ABSPATH.'/libs/mpdf/vendor/autoload.php';
?>

<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "indices";
	</script>
	
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Indices</li>
		<li>Reajuste de listas de preço</li>
	</ol>
	<h4 class="page-title"></h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-sm-12">
				<a href="/cadastros/indices/cobrar_reajuste/<?= base64_encode(json_encode($pi)); ?>" class=" form-control btn btn-success"> PROXIMO </a>
			</div>
			<br />
		</div>
		<!-- NÃO APAGUE ESSE OS COMENTARIOS TABELA DE REAJUSTES, NECESSARIO PARA GERAR ARQUIVO DE REGISTRO DE REAJUSTES -->
		<!-- TABELA DE REAJUSTES -->
		<div class="row">
			<div class="col-sm-12 col-sm-12">
				<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
					<tbody>
						<?php foreach ($rt['pct'] as $key => $value){ ?>	
							<thead>
								<th colspan="6"><?= $value['nome_fantasia'].' - '.$value['nome_produto'] ?></th>
							</thead>

							<?php foreach ($value['m'] as $k1 => $v1){ ?>
									<thead>
										<th colspan="6"><?= $v1['nome']?> - Pacote</th>
									</thead>
									<thead>
										<th colspan=2>Quantidade</th>
										<th>Valor Atual</th>
										<th>Porcentagem do reajuste</th>
										<th>Valor Atualizado</th>
										<th>Status</th>
									</thead>
								<?php for($x=0; $x < count($v1['qdt_garantido']); $x++){ ?>
									<tr>
										<td colspan="2"><?= $v1['qdt_garantido'][$x];       ?></td>
										<td><?= number_format($v1['valor_atual'][$x], '2', ',', '.');   ?>     </td>
										<td><?= number_format($rt['percentual'], '3', ',', '.').'%'; ?> </td>
										<td><?= number_format($v1['valor_novo'][$x], '2', ',', '.');    ?>     </td>
										<td>
											<?php if($v1['status'][$x] == 'success'){ ?>
												<span style="color:green"><b><?= $v1['status'][$x] ?></b></span>
											<?php }else{ ?>
												<span style="color:red"><b><?= $v1['status'][$x] ?></b></span>
											<?php } ?>
										</td>
									</tr>
								<?php }	?>
							<?php }	?>
						<?php } ?>
						<?php foreach ($rt['lp'] as $key => $value){ ?>	
							<thead>
								<th colspan="6"><?= $value['nome_fantasia'].' - '.$value['nome_produto'] ?></th>
							</thead>
							<?php foreach ($value['m'] as $k1 => $v1){ ?>
									<tr>
										<th colspan="6"><?= $v1['nome']?> Lista de preços 1</th>
									</tr>
									<tr>
										<th>Faixa De</th>
										<th>Faixa Até</th>
										<th>Valor Atual</th>
										<th>Porcentagem do reajuste</th>
										<th>Valor Atualizado</th>
										<th>Status</th>
									</tr>
								<?php for($x=0; $x < count($v1['qtd_de']); $x++){ ?>
									<tr>
										<td><?= $v1['qtd_de'][$x];       ?></td>
										<td><?= $v1['qtd_ate'][$x];      ?></td>
										<td><?= number_format($v1['valor_atual'][$x], '3', ',', '.');   ?>     </td>
										<td><?= number_format($rt['percentual'], '3', ',', '.').'%'; ?> </td>
										<td><?= number_format($v1['valor_novo'][$x], '3', ',', '.');    ?>     </td>
										<td>
											<?php
											if($v1['status'][$x] == 'success'){
											?>
												<span style="color:green"><b><?= $v1['status'][$x] ?></b></span>
											<?php	
											}else{
											?>
												<span style="color:red"><b><?= $v1['status'][$x] ?></b></span>
											<?php	
											}
											?>
										</td>
									</tr>
								<?php }	?>
							<?php }	?>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
		<!-- TABELA DE REAJUSTES -->
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<script type="text/javascript"></script>
	<?php
		// codigo para pegar apenas tabela de reajustes, implementar e testar melhor, tem alguns bugs.
		// $dados_reajuste = json_decode(base64_decode($this->parametros[2]));
		// $file_name_html = 'reajuste_'.$dados_reajuste->indice.'_'.$dados_reajuste->ano.'_'.$dados_reajuste->mes.'.html';
		// preg_match_all('/REAJUSTES -->(.+)<!--/s', ob_get_contents(), $conteudo);
		// file_put_contents($file_name_html, $conteudo[0][0]);
		$dados_reajuste = json_decode(base64_decode($this->parametros[2]));
		$file_name_html = 'reajustes_'.$dados_reajuste->mes.'.html';
		$dir = ABSPATH.DS.'arquivos'.DS.'historicos'.DS.'reajustes'.DS.$dados_reajuste->indice.DS.$dados_reajuste->ano.DS;
		if(!file_exists($dir)){
			echo 'não existe';
			mkdir($dir, 0777, true);
		}
		// array com trechos a serem removidos do conteudo da tela no arquivo
		// $retirar  = array('<a', '</a>');
		// variavel com todo o conteudo da tela
		$conteudo = ob_get_contents();
		//removendo os trechos indesejados da tela para inserir no arquivo
		// $conteudo = str_replace($retirar, '', $conteudo);
		//inserindo conteudo no arquivo html 
		file_put_contents($dir.$file_name_html, $conteudo);
		
		// $file_name_pdf  = $dados_reajuste->mes.'.pdf';
		// $conteudo_pdf = file_get_contents($file_name_html);
		// $mpdf     = new \Mpdf\Mpdf();
		// $mpdf->allow_charset_conversion = true;
		// $mpdf->SetDisplayMode('fullpage');
		// // $mpdf->debug = true;
		// $mpdf->showImageErrors = true;
		// $mpdf->img_dpi = 96;
		// $mpdf->use_kwt = true;
		// $mpdf->SetTitle('BOLETO DE COBRANÇA'); 
		// $mpdf->WriteHTML($conteudo_pdf);
		// $is_create = $mpdf->Output($file_name_pdf);
	?>
</body>
</html>