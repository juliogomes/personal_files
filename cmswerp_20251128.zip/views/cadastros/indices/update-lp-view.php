<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "indices";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Indices</li>
		<li>Listas atualizadas</li>
	</ol>
	<h4 class="page-title"></h4>

	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div id='resultado'></div>	
		</div>
		<div class="row">
			<?php if(isset($contratos) && !empty($contratos)){ ?>
				<div class="col-sm-6">
					<a href="/cadastros/indices/" class="form-control btn btn-warning"> Finalizar ? </a>
				</div>
				<div class="col-sm-6">
					<button class=" form-control btn btn-success" id="continue"> Deseja continuar? </button>
				</div>	
			<?php }?>
		</div>
		<br />
		<?php if(isset($contratos) && !empty($contratos)){ ?>
			<div class="row">
				<div class="col-sm-12 col-sm-12">
					<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
						<thead>
							<tr>
								<th>CLIENTE</th>
								<th>PRODUTO</th>
								<th>ASSINATURA</th>
								<th>REAJUSTE</th>
								<th>REAJUSTE</th>
								<th>MENSAGEM</th>
							</tr>
						</thead>
						<tbody>
							<?php
								//if(isset($array_retorno[0]['tipo_mensagem']) && $array_retorno[0]['tipo_mensagem'] == 'sucesso'){
									foreach ($array_retorno as $key => $value) {
										
										if($value['tipo_mensagem'] == 'sucesso'){
											$class = "alert alert-success";
										}else{
											$class = "alert alert-warning";
										}
							?>
								<tr>	
									<td><?= $value['cliente'] ?></td>
									<td><?= $value['produto'] ?></td>
									<td><?= convertDate($value['data_assinatura']); ?></td>
									<td><?= convertDate($value['data_reajuste']); ?></td>
									<td><div class="<?= $class ?>" role="alert"><?= $value['status'] ?></div></td>
									<td><div class="<?= $class ?>" role="alert"><?= $value['mensagem'] ?></div></td>
								</tr>
							<?php
									}
								// }else{
								// 	if(isset($array_retorno[0]['tipo_mensagem'])){
								// 		echo '<tr>';
								// 		echo '<td colspan="4">';
								// 		echo $array_retorno[0]['mensagem'];
								// 		echo '</td>';
								// 	}else{
								// 		// echo '<tr>';
								// 		// echo '<td colspan="4">';
								// 		// echo 'Nenhum contrato para ser atualizado!';
								// 		// echo '</td>';
								// 	}
								// }
							?>
						</tbody>
					</table>
				</div>
			</div>
		<?php }else{?>
			<div class="row">
				<div class="col-sm-6">
					<span><h4>Nenhum contrato a ser reajustado!</h4></span>
				</div>
			</div>
		<?php } ?>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
 	<script type="text/javascript">
		$(document).ready(function(){
			$('#continue').click(function(){
				var dados   = '<?= $ids ?>';
				$(this).attr("disabled", true);
				$(location).attr('href','/cadastros/indices/updatepreco/ids/'+dados);
			});
		});
	</script>
 <!-- /PAGE SCRIPTS -->
</body>
</html>