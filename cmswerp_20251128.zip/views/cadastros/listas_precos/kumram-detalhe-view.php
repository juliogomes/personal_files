<div class="container lista-preco">
	<div class="row">
		<div class="col-md-12">
			<ol class="breadcrumb">
				<li><a href="/">Lista de Preços</a></li>
				<li class="active">Kumram</li>
				<li class="active">Adicionar Kumram</li>
			</ol>
		</div>
	</div>
	<div class="row info"><!-- conteúdo -->
		<div class="col-md-12">
			<header><!-- /header -->
				<h1 class="page-header titulos">Novo Valor Kumram</h1> <!-- título da sessão -->
				<p class="text-left">Preencha as informações abaixo e clique em salvar.</p> <!-- Instruções -->
			</header><!-- /header -->
			<div class=" mensagem formulario"><!-- inicio do formulário -->
				<div class="msg_erro"><?php echo $this->modelo->error; ?></div><!-- Mensagem de erro - php -->
				<div class="msg_sucesso"><?php echo $this->modelo->success; ?></div><!-- Mensagem de sucesso - php -->
				<div class="col-md-6 col-md-offset-3"><!-- largura do formulário (Cols) -->
					<div class="panel panel-default"><!-- /panel -->
						<div class="panel-heading">Dados do Kumram</div><!-- Tipo do formulário -->
						<div class="panel-body"><!-- panel-body -->
							<!-- incio da form -->
							<form action="<?php echo HOME_URI.$this->module.'/lp/kumram/save/id/'.$this->parametros[3]; ?>" name="save" method="post">
								<label for="qtd_licencas">Quantidade de Licenças</label>
								<input type="text" class="form-control field" placeholder="9999" value="<?php echo isset($records[0])?$records[0]->qtd_licencas:null ?>"  name="qtd_licencas" required />
								<label for="valor_real">Valore Real</label>
								<input type="text" data-mascara = "moeda" class="form-control field" placeholder="0.00" value="<?php echo isset($records[0])?$records[0]->valor_real:null ?>"  name="valor_real" required />
								<label>
									<select id= "id_modulos_tarifaveis" name="id_modulos_tarifaveis">
										<?php
										foreach($modulos_tarifaveis as $key=>$value)
										{
											if($value->id == $records[0]->id_modulos_tarifaveis)
											{
												echo '<option value="'.$value->id.'" selected>'.$value->descricao.'</option>';
											}
											else
											{
												echo '<option value="'.$value->id.'">'.$value->descricao.'</option>';
											}
										}
										?>
									</select>
								</label>
								<button  type="submit" class="btn btn-adicionar botao text-center">
									Salvar &nbsp;<span class="glyphicon glyphicon-hdd"></span>
								</button>
							</form> <!-- /incio da form -->
						</div> <!-- /panel-body -->
					</div> <!-- /panel -->
				</div><!-- /largura do formulário (Cols) -->
			</div><!-- /inicio do formulário -->
		</div>
	</div><!-- /conteúdo -->
</div> <!-- /container -->