<?php
$records = json_decode($this->modelo->getRecords());
?>
<section class="lista-de-precos">
	<div class="container-fluid Kumram">
		<div class="row">
			<div class="col-md-12">
				<ol class="breadcrumb">
					<li><a href="/">Lista de Preços</a></li>
					<li class="active">Kumram</li>
				</ol>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<h1 class="page-header">Kumram</h1>
				<div class="panel panel-default">
					<!-- Default panel contents -->
					<div class="panel-heading">
					</div>
					<div class="panel-body">
						<a href="/cadastros/lp/kumram/detalhe/id/0" class="btn btn-adicionar pull-right">
							Adicionar &nbsp;<span class="glyphicon glyphicon-plus"></span>
						</a>
						<!-- <p>Text goes here...</p> -->
					</div>
					<table border='0' id='list-contratos' class="table table-striped table-bordered table-hover table-responsive">
						<thead>
							<tr>
								<th>Produto</th>
								<th>Módulo</th>
								<th>Quantidade de Licenças</th>
								<th>Valor Real (R$)</th>
								<th>Ações</th>
							</tr>
						</thead>
						<tbody>
							<?php
						
							if(isset($records))
							{
								foreach($records as $key => $value)
								{
									echo '<tr>';
									echo '<td>'.$value->nome.'</td>';
									echo '<td>'.$value->codigo.'</td>';
									echo '<td>'.$value->qtd_licencas.'</td>';
									echo '<td>'.$value->valor_real.'</td>';
									echo '<td><a class="btn btn-success" href="/cadastros/lp/kumram/detalhe/id/'.$value->id.'/">Visualizar</a></td>';
									echo '</tr>';
								}
							}
							?>
						</tbody>
					</table>
					<div class="panel-footer">
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- SCRIPTS -->
<script>
	function detalhe(param)
	{
		window.location="kumram/detalhe/id/"+param['id'];
	}
	$(document).ready(function()
	{
		$('#bt-novo').click(function(){
			window.location="kumram/detalhe/id/0";
		});
		$("#list-contratos").DataTable();
	});
</script>
<!-- /SCRIPTS -->
