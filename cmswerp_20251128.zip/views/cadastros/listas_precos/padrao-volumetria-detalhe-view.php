<div class="container lista-preco">
	<div class="row">
		<div class="col-md-12">
			<ol class="breadcrumb">
				<li><a href="/">Lista de Preços</a></li>
				<li class="active">Padrão Volumetria</li>
				<li class="active">Adicionar Valor Volumetria</li>
			</ol>
		</div>
	</div>
	<div class="row info"><!-- conteúdo -->
		<div class="col-md-12">
			<header><!-- /header -->
				<h1 class="page-header titulos">Novo Padrão Volumetria</h1> <!-- título da sessão -->
				<p class="text-left">Preencha as informações abaixo e clique em salvar.</p> <!-- Instruções -->
			</header><!-- /header -->
			<div class=" mensagem formulario"><!-- inicio do formulário -->
				<div class="msg_erro"><?php echo $this->modelo->error; ?></div><!-- Mensagem de erro - php -->
				<div class="msg_sucesso"><?php echo $this->modelo->success; ?></div><!-- Mensagem de sucesso - php -->
				<div class="col-md-6 col-md-offset-3"><!-- largura do formulário (Cols) -->
					<div class="panel panel-default"><!-- /panel -->
						<div class="panel-heading">Dados do Padrão Volumetria</div><!-- Tipo do formulário -->
						<div class="panel-body"><!-- panel-body -->
							<!-- incio da form -->
							<form action="<?php echo HOME_URI.$this->module.'/lp/padrao-volumetria/save/id/'.$this->parametros[3]; ?>" name="save" method="post">
								<label for="qtd_de">Quantidades de:</label>
								<input type="number" class="form-control field" placeholder="9999" value="<?php echo isset($records[0])?$records[0]->qtd_de:null ?>"  name="qtd_de" required />
								<label for="qtd_ate">Quantidades de até:</label>
								<input type="number" class="form-control field" placeholder="9999" value="<?php echo isset($records[0])?$records[0]->qtd_ate:null ?>" name="qtd_ate" required />
								<label for="valor_real">Valor Real</label>
								<input type="text" data-mascara = "moeda" class="form-control field" placeholder="0.00" value="<?php echo isset($records[0])?$records[0]->valor_real:null ?>" name="valor_real" required />
								<label>
									<select id= "id_modulos_tarifaveis" name="id_modulos_tarifaveis">
										<?php
										foreach($modulos_tarifaveis as $key=>$value)
										{
											if($value->id == $records[0]->id_modulos_tarifaveis)
											{
												echo '<option value="'.$value->id.'" selected>'.$value->codigo.' - '.$value->descricao.'</option>';
											}
											else
											{
												echo '<option value="'.$value->id.'">'.$value->codigo.' - '.$value->descricao.'</option>';
											}
										}
										?>
									</select>
								</label>
								<button  type="submit" class="btn btn-adicionar botao text-center">
									Salvar &nbsp;<span class="glyphicon glyphicon-hdd"></span>
								</button>
							</form> <!-- /incio da form -->
						</div> <!-- /panel-body -->
					</div> <!-- /panel -->
				</div><!-- /largura do formulário (Cols) -->
			</div><!-- /inicio do formulário -->
		</div>
	</div><!-- /conteúdo -->
</div> <!-- /container -->