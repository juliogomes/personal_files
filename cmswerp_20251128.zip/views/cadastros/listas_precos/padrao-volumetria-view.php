<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "padrao-volumetria";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Preços</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> Volumetria</h4>
	<form class="form-inline page-toolbar">
		<div class="btn-group" role="group">
			<a href="/cadastros/lp/padrao-volumetria/detalhe/id/0" class="btn btn-default"><i class="fa fa-plus"></i> Adicionar</a>
		</div>
	</form>
	<form class="form-inline page-toolbar">
		<div class="form-group">
			<div class="input-group">
				<div class="input-group-addon">Produto</div>
				<select class="form-control select" id="searchProduto">
					<option value="">Todos os Produtos</option>
				</select>
			</div>
			<div class="input-group">
				<div class="input-group-addon">Módulo</div>
				<select class="form-control select" id="searchModulo">
					<option value="">Todos os Módulos</option>
				</select>
			</div>
		</div>
	</form>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<table id='list' class="table table-default table-striped table-bordered table-condensed table-hover" width="100%">
					<thead>
						<tr>
							<th class="text-center">Produto</th>
							<th>Módulo</th>
							<th class="text-right">De</th>
							<th class="text-left">Até</th>
							<th class="text-right">Valor (R$)</th>
							<th width="1"></th>
						</tr>
					</thead>
					<tbody>
						<?php if (is_array($records)){ ?>
						<?php foreach($records as $key => $value) { ?>
						<tr>
							<td class="text-center">(<?= $value->produto_codigo ?>) <?= $value->produto_nome ?></td>
							<td>
								(<?= $value->modulo_codigo ?>) <?= $value->modulo_nome ?>
							</td>
							<td class="text-right"><?= $value->qtd_de ?></td>
							<td class="text-left"><?= $value->qtd_ate ?></td>
							<td class="text-right"><?= $value->valor_real ?></td>
							<td><a class="btn btn-info btn-xs" href="/cadastros/lp/padrao-volumetria/detalhe/id/<?= $value->id ?>/"><i class="fa fa-edit"></i> Editar</a></td>
						</tr>
						<?php } ?>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript">
		$(function() {
			oTable = $('#list').DataTable({
				lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
				info: false,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				}
			});
			oTable.column( 0 ).data().unique().sort().each( function ( d, j ) {
				$('#searchProduto').append( '<option value="'+d+'">'+d+'</option>' );
			});
			$('#searchProduto').selectpicker({ liveSearch: true, liveSearchNormalize: true }).change(function(event) {
				oTable.search( this.value ).draw();
				$('#searchModulo').empty().append('<option value="">Todos os Módulos</option>');
				oTable.column( 1, {filter:'applied'} )
				.data()
				.unique()
				.sort()
				.each( function ( d, j ) {
					console.log(d);
					$('#searchModulo').append( '<option value="'+d+'">'+d+'</option>' );
				});
				$('#searchModulo').selectpicker('refresh');
			});
			oTable.column( 1 ).data().unique().sort().each( function ( d, j ) {
				$('#searchModulo').append( '<option value="'+d+'">'+d+'</option>' );
			});
			$('#searchModulo').selectpicker({ liveSearch: true, liveSearchNormalize: true }).change(function(event) {
				oTable
				.search( this.value )
				.draw();
			});
			$('#searchName').keyup(function(){
				oTable
				.search( this.value )
				.draw();
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
</table>
