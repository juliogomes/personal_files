<?php
if ( !$this->logged_in )
{
	echo 'Efetue o login para acessar esse registro, clicando <a href="'.HOME_URI.'login/"> aqui </a>';
	exit;
}
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "meio-pagamento";
	</script>
	<style type="text/css" media="screen">
		input[type="radio"].styled:checked+label:after {
			font-family: 'FontAwesome';
			content: '';
		}
	</style>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Cadastros</li>
		<li>Meios de recebimento</li>
	</ol>
	<h4 class="page-title">
		<?php
		if(empty($this->parametros[2])){
			echo '<i class="fa fa-plus"></i> Novo meio de recebimento';
		}else{
			echo '<i class="fa fa-edit"></i> Editar meio de recebimento';
		}
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-6">
				<form id="form" action="<?php echo HOME_URI.'cadastros/meiosrecebimentos/save/id/'.$this->parametros[2]; ?>" class="" method="post">
					<fieldset>
						<legend>Dados do Imposto</legend>
						<div class="form-group">
							<label for="nome">Nome:</label>
							<input type="text" class="form-control" placeholder="Nome" name="nome" id="nome" value="<?php echo isset($records)?$records[0]->nome:null ?>"/>
						</div>
						<div class="form-group">
							<label for="descricao">Texto na nota:</label>
							<textarea class="form-control" name="descricao" id="descricao"><?php echo isset($records)?$records[0]->descricao:null ?></textarea>
						</div>
					</fieldset>
					<a href="/usuarios/lista/" class="btn btn-default"><i class="fa fa-times"></i> Cancelar</a>
					<button type="submit" class="btn btn-primary pull-right"><i class="fa fa-floppy-o"></i> Salvar</button>
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$(function() {
			$form = $('#form');
			$form.formValidation({
				framework: 'bootstrap',
				excluded: ':disabled',
				icon: {
					valid: 'fa fa-check',
					invalid: 'fa fa-times',
					validating: 'fa fa-refresh'
				},
				addOns: {
					mandatoryIcon: {
						icon: 'fa fa-asterisk'
					}
				},
				live: 'enabled',
				fields: {
					'nome':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'email':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							},
							regexp: {
								regexp: /^([\w\.\-_]+)?\w+@[\w-_]+(\.\w+){1,}$/i,
								message: 'Email mão é válido'
							}
						}
					},
					'perfil':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					}
				}
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>