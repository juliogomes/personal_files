<div class="container modulos">
	<div class="row">
		<div class="col-md-12">
			<ol class="breadcrumb">
				<li><a href="/">Cadastros</a></li>
				<li class="active">Módulos</li>
				<?php
				if(empty($this->parametros[2])){
					echo '<li class="active">Novo Módulo</li>';
				}
				else
				{
					echo '<li class="active">Alterar Módulo</li>';
				}
				?>
			</ol>
		</div>
	</div>
	<div class="row info"><!-- conteúdo -->
		<div class="col-md-12">
			<header><!-- /header -->
				<h1 class="page-header titulos">
					
					<?php
					if(empty($this->parametros[2])){
						echo 'Novo Módulo';
					}
					else
					{
						echo 'Alterar Módulo';
					}
					
					?>

				</h1> <!-- título da sessão -->
				<span class="icones-direcionais glyphicon glyphicon-arrow-left"></span><a  class="btn-back" href="/cadastros/modulos/list/" title="Voltar para lista de vendedores">&nbsp;Voltar</a>
			</header><!-- /header -->
			<div class=" mensagem formulario"><!-- inicio do formulário -->
				<div class="msg_erro"><?php echo $this->modelo->error; ?></div><!-- Mensagem de erro - php -->
				<div class="msg_sucesso"><?php echo $this->modelo->success; ?></div><!-- Mensagem de sucesso - php -->
				<div class="col-md-6"><!-- largura do formulário (Cols) -->
					<div class="panel panel-default"><!-- /panel -->
						<div class="panel-heading">Dados do Módulo</div><!-- Tipo do formulário -->
						<div class="panel-body"><!-- panel-body -->
							<!-- incio da form -->
							<form class="form-inline pull-right" action="<?php echo HOME_URI.$this->module.'/modulos/save/id/'.$this->parametros[2]; ?>" name="save" method="post">
								<div class="form-group">
									<label for="codigo">Código:</label>
									<input type="text" class="form-control field pull-right" maxlength="7" placeholder="Código do Módulo Tarifável" value="<?php echo isset($records)?$records->codigo:null ?>" name="codigo" required />
								</div>
								<!-- Produto -->
								<div class="form-group">
									<label for="id_produto">Produto</label>
									<select name='id_produto' class="form-control field pull-right">
										<option value='' > Selecione </option>
										<?php
										foreach($this->produtos as $key=>$value)
										{
											if(isset($records->id_produto) && $value->id == $records->id_produto)
											{
												echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome).'</option>';
											}
											else
											{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome).'</option>';
											}
										}
										?>
									</select>
									<!-- Empacotável -->
								</div>
								<div class="form-group">
									<label for="empacotavel">Empacotável</label>
									<select name='empacotavel' class="form-control field pull-right">
										<option value='' <?php echo (!isset($records))?'selected':'' ?> > Selecione </option>
										<option value='1' <?php echo (isset($records) && $records->empacotavel )?'selected':'' ?> >Sim</option>
										<option value='0' <?php echo (isset($records) && $records->empacotavel)?'selected':'' ?> >Não</option>
									</select>
								</div>
								<div class="form-group">
									<label for="tipo_cobranca">Tipo de cobrança</label><!-- Tipo de cobrança -->
									<select name="tipo_cobranca" class="form-control field pull-right" >
										<option value="">Selecione</option>
										<?php
										foreach ($this->globals['COBRANCA'] as $key => $value) {
											if($key == $records->tipo_cobranca)
											{
												echo '<option value="'.$key.'" selected>'.strtoupper($value).'</option>';
											}
											else
											{
												echo '<option value="'.$key.'" >'.$value.'</option>';
											}
										}
										echo '</select>';
										?>
									</select>
								</div>
								<!-- Status -->
								<div class="form-group">
									<label for="status">Status</label>
									<select name='status' class="form-control field pull-right">
										<option value='' <?php echo (!isset($records))?'selected':'' ?> > SELECIONE </option>
										<option value='ativo' <?php echo (isset($records) && $records->status == 'ativo')?'selected':'' ?> >Ativo</option>
										<option value='inativo' <?php echo (isset($records) &&  $records->status == 'inativo')?'selected':'' ?> >Inativo</option>
										<option value='suspenso' <?php echo (isset($records) && $records->status == 'suspenso')?'selected':'' ?> >Suspenso</option>
									</select>
								</div>
								<div class="form-group">
									<label for="descricao">Descrição</label><!-- Descrição -->
									<textarea name="descricao" class="form-control field pull-right" rows="3" placeholder="Descrição do produto"></textarea>
								</div>
								<button  type="submit" class="btn btn-adicionar botao text-center">
									Salvar &nbsp;<span class="glyphicon glyphicon-hdd"></span>
								</button>
							</div>
						</form> <!-- /incio da form -->
					</div> <!-- /panel-body -->
				</div> <!-- /panel -->
			</div><!-- /largura do formulário (Cols) -->
		</div><!-- /inicio do formulário -->
	</div>
</div><!-- /conteúdo -->
</div> <!-- /container -->