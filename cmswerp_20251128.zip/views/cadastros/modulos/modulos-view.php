<div class="container">
	<div class="row">
		<!--
		<div class="col-md-12">
			<ol class="breadcrumb">
				<li><a href="/">Cadastros</a></li>
				<li class="active">Módulos</li>
			</ol>
		</div>
		-->
	</div>
	<div class="row info">
		<div class="col-md-12">
			<!-- <h1 class="page-header titulos">Módulos</h1> -->
			
			<div class="panel panel-default">
				
				<!-- Default panel contents -->
				
				<!-- <div class="panel-heading">
					Nessa sessão você encontrará informações referente aos módulos.
				</div> -->

				<div class="panel-body">
					<a href="/cadastros/modulos/detalhe/id/0" class="btn btn-adicionar">
						<span class="glyphicon glyphicon-plus"></span>&nbsp;Adicionar Módulo
					</a>
					<!-- <p>Text goes here...</p> -->
				</div>
				<table border='0' id='list-contratos' class="table table-striped table-bordered table-hover table-responsive">
					<!-- incluir a class "todatables" para inserir o filtro -->
					<thead>
						<tr>
							<th>Código</th>
							<th>Descrição</th>
							<th width="50" class="text-center">Empacotável</th>
							<th width="70" class="text-center">Status</th>
							<th width="270">Ações</th>
						</tr>
					</thead>
					<tbody>
						<?php
						foreach($records as $key => $value)
						{
							echo '<tr>';
							echo '<td>'.$value->codigo.'</td>';
							echo '<td>'.$value->descricao.'</td>';
							echo '<td class="text-center">'.$value->empacotavel.'</td>';
							echo '<td class="text-center">'.$value->status.'</td>';
							echo '<td>';
							if($value->status == 'inativo')
							{
								echo
								'
								<a class="btn btn-ativar" href="/cadastros/modulos/detalhe/id/'.$value->id.'/"><span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span> Ativar</a>
								';
							}
							elseif($value->status == 'suspenso')
							{
							}
							else
							{
								echo
								'<a class="btn btn-visualizar" href="/cadastros/modulos/detalhe/id/'.$value->id.'/id_produto/"'.$value->id_produto.'><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> Editar</a>';
								// echo
								// '<a class="btn btn-cancelar" href="/cadastros/modulos/detalhe/id/'.$value->id.'/"><span class="glyphicon glyphicon-thumbs-down" aria-hidden="true"></span> Inativar</a>';
							}
							echo '</td>';
							echo '</tr>';
						}
						?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<script>
	function detalhe(param)
	{
		window.location="detalhe/id/"+param['id'];
	}
	$(document).ready(function()
	{
		$('#bt-novo').click(function(){
			window.location="detalhe/id/0";
		});
		$("#list-contratos").DataTable();
	});
</script>