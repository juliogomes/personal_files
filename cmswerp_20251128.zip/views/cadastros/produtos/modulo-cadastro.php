<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "produtos";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Cadastros</li>
		<li>Produtos</li>
		<?php
		if(!empty($this->parametros[1])){
			echo '<li>('.$produto->codigo.') '.$produto->nome.'</li>';
		}
		?>
		<?php
		if(!empty($this->parametros[2])){
			echo '<li>('.$modulo->codigo.') '.$modulo->descricao.'</li>';
		}
		?>
	</ol>
	<h4 class="page-title">
		<?php
		if(empty($this->parametros[2])){
			echo '<i class="fa fa-plus"></i> Novo Módulo';
		}
		else
		{
			echo '<i class="fa fa-edit"></i> Editar Módulo';
		}
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-5">
				<form id="form" action="<?php echo HOME_URI.$this->module.'/produtos/modulo-save/'.$this->parametros[1].'/'.$this->parametros[2]; ?>" class="" method="post">
					<input type="hidden" name="id_produto" value="<?php echo $this->parametros[1] ?>"/>
					<input type="hidden" name="status" value="ativo"/>
					<fieldset>
						<legend>Dados do Módulo</legend>
						<div class="form-group">
							<label for="codigo">Código:</label>
							<input type="text" name="codigo" id="codigo" class="form-control uppercase masked" data-masked="SSS9999"" maxlength="7" placeholder="Código do Módulo" value="<?php echo isset($modulo)?$modulo->codigo:null ?>"/>
						</div>
						<div class="form-group">
							<label for="descricao">Nome</label>
							<input type="text" name="descricao" id="descricao" class="form-control" placeholder="Nome do Módulo" value="<?php echo isset($modulo)?$modulo->descricao:null ?>"/>
						</div>
						<div class="form-group">
							<label for="empacotavel">Empacotável</label>
							<select name="empacotavel" id="empacotavel" class="form-control select">
								<option value='' <?php echo (!isset($modulo))?'selected':'' ?> > Selecione </option>
								<option value='1' <?php echo (isset($modulo) && $modulo->empacotavel == 1)?'selected':'' ?> >Sim</option>
								<option value='0' <?php echo (isset($modulo) && $modulo->empacotavel == 0)?'selected':'' ?> >Não</option>
							</select>
						</div>
						<div class="form-group">
							<label for="allow_lp_default">Possui lista de preço</label>
							<select name="allow_lp_default" class="form-control">
								<option value="1" <?= (isset($modulo) && $modulo->allow_lp_default == 1 )?'selected':null ?> >Sim</option>
								<option value="0" <?= (isset($modulo) && $modulo->allow_lp_default == 0 )?'selected':null ?> >Não</option>
							</select>
						</div>
						<div class="form-group">
							<label for="tipo_cobranca">Tipo de cobrança</label>
							<select id = "tipo_cobranca" name="tipo_cobranca" class="form-control select">
								<option value="">Selecione</option>
								<?php foreach ($this->globals['COBRANCA'] as $key => $value) {
									if($key == $modulo->tipo_cobranca) {
										echo '<option value="'.$key.'" selected>'.strtoupper($value).'</option>';
									} else {
										echo '<option value="'.$key.'" >'.$value.'</option>';
									}
								} ?>
							</select>
						</div>
					</fieldset>
					<?php if(empty($this->parametros[2])){ ?>
					<a href="/cadastros/produtos/produto-detalhe/id/<?= $this->parametros[1]; ?>" class="btn btn-default"><i class="fa fa-times"></i> Cancelar </a>
					<?php } else { ?>
					<a href="/cadastros/produtos/modulo-detalhe/<?= $this->parametros[1]; ?>/<?= $this->parametros[2]; ?>" class="btn btn-default"><i class="fa fa-times"></i> Cancelar</a>
					<?php } ?>
					<button type="submit" class="btn btn-primary pull-right"><i class="fa fa-floppy-o"></i> Salvar</button>
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$(function() {
			$form = $('#form');
			$form.formValidation({
				framework: 'bootstrap',
				excluded: ':disabled',
				icon: {
					valid: 'fa fa-check',
					invalid: 'fa fa-times',
					validating: 'fa fa-refresh'
				},
				addOns: {
					mandatoryIcon: {
						icon: 'fa fa-asterisk'
					}
				},
				live: 'enabled',
				fields: {
					'descricao':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'codigo':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							},
							regexp:{
								regexp: /^[A-Z]{3}[0-9]{4}$/,
								message: 'Código não válido'
							}
						}
					},
					'empacotavel':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'tipo_cobranca':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
				}
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>