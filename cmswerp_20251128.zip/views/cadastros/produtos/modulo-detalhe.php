<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "produtos";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Cadastros</li>
		<li>Produtos</li>
		<?php
		if(!empty($this->parametros[1])){
			echo '<li>('.$produto->codigo.') '.$produto->nome.'</li>';
		}
		?>
	</ol>
	<h4 class="page-title">
		<?php
		echo '('.$modulo->codigo.') '.$modulo->descricao;
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-5">
				<form>
					<input type="hidden" name="id_produto" value="<?php echo $this->parametros[1] ?>"/>
					<input type="hidden" name="status" value="ativo"/>
					<fieldset>
						<legend>Dados do Módulo</legend>
						<div class="form-group">
							<label for="codigo">Código:</label>
							<input type="text" disabled class="form-control" value="<?php echo isset($modulo)?$modulo->codigo:null ?>"/>
						</div>
						<div class="form-group">
							<label for="descricao">Nome</label>
							<input type="text" disabled class="form-control" value="<?php echo isset($modulo)?$modulo->descricao:null ?>"/>
						</div>
						<div class="form-group">
							<label for="empacotavel">Empacotável</label>
							<input type="text" disabled class="form-control" value="<?php echo (isset($modulo) && $modulo->empacotavel == 1)?'Sim':'Não' ?>"/>
						</div>
						<div class="form-group">
							<label for="allow_lp_default">Possui lista de preço</label>
							<select name="allow_lp_default" disabled class="form-control">
								<option value="1" <?= (isset($modulo) && $modulo->allow_lp_default == 1 )?'selected':null ?> >Sim</option>
								<option value="0" <?= (isset($modulo) && $modulo->allow_lp_default == 0 )?'selected':null ?> >Não</option>
							</select>
						</div>
						<div class="form-group">
							<label for="tipo_cobranca">Tipo de cobrança</label>
							<input type="text" disabled class="form-control" value="<?php echo $modulo->tipo_cobranca ?>"/>
						</div>
					</fieldset>
					<a href="/cadastros/produtos/produto-detalhe/id/<?= $this->parametros[1]; ?>" class="btn btn-default"><i class="fa fa-caret-left"></i> Voltar</a>
					<a class="btn btn-info" href="/cadastros/produtos/modulo-cadastro/<?= $this->parametros[1]; ?>/<?= $this->parametros[2]; ?>"><i class="fa fa-edit"></i> Editar</a>
					</form>
			</div>
			<!-- O CODIGO ABAIXO IRA SER UTILIZADO PARA LOAD DE TABELAS DEFAUL FUTURAMENTE NÃO APAGAR!!! -->
			<!-- <div class="col-sm-12 col-md-7">
				<?php if ($modulo->tipo_cobranca != 'VALOR-FIXO') { ?>
				<?php if ($modulo->tipo_cobranca == 'VOLUMETRIA') { ?>
				<h4 class="page-header">Faixas de Volumetria</h4>
				<?php } elseif ($modulo->tipo_cobranca == 'FAIXA-FIXA') { ?>
				<h4 class="page-header">Cobrança fixa por faixa de uso</h4>
				<?php } elseif ($modulo->tipo_cobranca == 'FIXO-INCREMENTAL') { ?>
				<h4 class="page-header">Cobrança incremental por mudança de faixa</h4>
				<?php }elseif ($modulo->tipo_cobranca  == 'INCREMENTAL-VOLUMETRIA') { ?>
				<h4 class="page-header">Faixas com valor por volumetria</h4>
				<?php }elseif ($modulo->tipo_cobranca  == 'COBRANCA-ELETRONICA') { ?>
				<h4 class="page-header">Faixas de Cobranca Eletrônica</h4>
				<?php } elseif ($modulo->tipo_cobranca == 'LIQUIDADO-REAL') { ?>
				<h4 class="page-header">Faixas Liquidado</h4>
				<?php } elseif ($modulo->tipo_cobranca == 'LIQUIDADO-RELATIVO') { ?>
				<h4 class="page-header">Faixas Liquidado</h4>
				<?php } elseif ($modulo->tipo_cobranca == 'GOCHK') { ?>
				<h4 class="page-header">Faixas GoCHK</h4>
				<?php } elseif ($modulo->tipo_cobranca == 'KUMRAM') { ?>
				<h4 class="page-header">Faixas Kumram</h4>
				<?php } else { ?>
				Não Implementado 1[<?= $modulo->tipo_cobranca ?>]
				<?php } ?>
				
				<a class="btn btn-info" href="/cadastros/produtos/modulo-faixa-cadastro/<?= $this->parametros[1];?>/<?= $this->parametros[2];?>/0"><i class="fa fa-plus"></i> Nova Faixa</a>

				<table id='list' class="table table-default table-striped table-bordered table-hover table-responsive dt-responsive">
					<thead>
						<?php if ($modulo->tipo_cobranca == 'LIQUIDADO-RELATIVO') { ?>
						<tr>
							<th colspan="2" class="text-center">Quantidade</th>
							<th colspan="2" class="text-center">Raging</th>
							<th colspan="2"></th>
						</tr>
						<?php } ?>
						<tr>
							<?php if ($modulo->tipo_cobranca == 'VOLUMETRIA') { ?>
							<th width="50" class="text-right">De</th>
							<th width="50" class="text-left">Até</th>
							<th width="50" class="text-right">Valor (R$)</th>
							<?php } elseif ($modulo->tipo_cobranca == 'LIQUIDADO-REAL') { ?>
							<th width="50" class="text-right">De</th>
							<th width="50" class="text-left">Até</th>
							<th width="50" class="text-right">Valor (R$)</th>
							<?php } elseif ($modulo->tipo_cobranca == 'LIQUIDADO-RELATIVO') { ?>
							<th width="50" class="text-right">De</th>
							<th width="50" class="text-left">Até</th>
							<th width="50" class="text-center">De</th>
							<th width="50" class="text-center">Até</th>
							<th width="50" class="text-right">Relativo (R$)</th>
							<?php } elseif ($modulo->tipo_cobranca == 'COBRANCA-ELETRONICA') { ?>
							<th width="50" class="text-right">De</th>
							<th width="50" class="text-left">Até</th>
							<th width="50" class="text-right">Percentual (%)</th>
							<?php } elseif ($modulo->tipo_cobranca == 'GOCHK') { ?>
							<th width="50" class="text-right">Real (R$)</th>
							<th width="50" class="text-right">Relativo (R$)</th>
							<?php } elseif ($modulo->tipo_cobranca == 'KUMRAM') { ?>
							<th width="50" class="text-center">Licenças</th>
							<th width="50" class="text-right">Valor (R$)</th>
							<?php } ?>
							<th width="1"></th>
						</tr>
					</thead>
					<tbody>
						<?php if (is_array($precos)){ ?>
						<?php foreach($precos as $key => $value) { ?>
						<tr>
							<?php if ($modulo->tipo_cobranca == 'VOLUMETRIA') { ?>
							<td class="text-right"><?= $value->qtd_de ?></td>
							<td class="text-left"><?= $value->qtd_ate ?></td>
							<td class="text-right">R$ <?= $value->valor_real ?></td>
							<?php } elseif ($modulo->tipo_cobranca == 'FAIXA-FIXA') { ?>
							<td class="text-right"><?= $value->qtd_de ?></td>
							<td class="text-left"><?= $value->qtd_ate ?></td>
							<td class="text-right">R$ <?= $value->valor_real ?></td>
							<?php } elseif ($modulo->tipo_cobranca == 'LIQUIDADO-REAL') { ?>
							<td class="text-right"><?= $value->qtd_de ?></td>
							<td class="text-left"><?= $value->qtd_ate ?></td>
							<td class="text-right">R$ <?= $value->valor_real ?></td>
							<?php } elseif ($modulo->tipo_cobranca == 'LIQUIDADO-RELATIVO') { ?>
							<td class="text-right"><?= $value->qtd_de ?></td>
							<td class="text-left"><?= $value->qtd_ate ?></td>
							<td class="text-center"><?= $value->idade_de ?></td>
							<td class="text-center"><?= $value->idade_ate ?></td>
							<td class="text-right">R$ <?= $value->valor_relativo ?></td>
							<?php } elseif ($modulo->tipo_cobranca == 'COBRANCA-ELETRONICA') { ?>
							<td class="text-right"><?= $value->qtd_de ?></td>
							<td class="text-left"><?= $value->qtd_ate ?></td>
							<td class="text-right"><?= $value->percentual ?>%</td>
							<?php } elseif ($modulo->tipo_cobranca == 'GOCHK') { ?>
							<td class="text-right">R$ <?= $value->valor_real ?></td>
							<td class="text-right">R$ <?= $value->valor_relativo ?></td>
							<?php } elseif ($modulo->tipo_cobranca == 'KUMRAM') { ?>
							<td class="text-center"><?= $value->qtd_licencas ?></td>
							<td class="text-right">R$ <?= $value->valor_real ?></td>
							<?php } ?>
							<td class="text-center"><a href="/cadastros/produtos/modulo-faixa-cadastro/<?= $value->id_produto ?>/<?= $value->id_modulo ?>/<?= $value->id_faixa ?>" class="btn btn-info btn-xs"><i class="fa fa-edit"></i> Editar</a>
							<a href="/cadastros/produtos/modulo-faixa-delete/<?= $value->id_produto ?>/<?= $value->id_modulo ?>/<?= $value->id_faixa ?>" class="btn btn-warning btn-xs"><i class="fa fa-trash"></i> Apagar</a></td>
						</tr>
						<?php } ?>
						<?php } else {?>
						<tr>
							<td colspan="100%" class="text-center">Sem Registros</td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
				<?php } else { ?>
				<form style="margin-left: 0">
					<fieldset>
						<legend>Valor</legend>
						<div class="form-group">
							<label for="valor_total">Valor (R$)</label>
							<input type="text" disabled class="form-control" placeholder="0.00" value="<?php echo isset($precos[0])?$precos[0]->valor_total:null ?>" name="valor_total" id="valor_total"/>
						</div>
						<?php if (is_array($precos)){ ?>
						<a href="/cadastros/produtos/modulo-faixa-cadastro/<?= $precos[0]->id_produto ?>/<?= $precos[0]->id_modulo ?>/<?= $precos[0]->id_faixa ?>" class="btn btn-info"><i class="fa fa-edit"></i> Editar</a>
						<?php } else { ?>
						<a class="btn btn-default" href="/cadastros/produtos/modulo-faixa-cadastro/<?= $this->parametros[1];?>/<?= $this->parametros[2];?>/0"><i class="fa fa-plus"></i> Adicionar Valor</a>
						<?php } ?>
					</fieldset>
				</form>
				
				<?php } ?>
			</div> -->
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>