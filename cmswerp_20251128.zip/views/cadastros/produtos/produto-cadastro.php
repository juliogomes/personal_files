<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "produtos";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Cadastros</li>
		<li>Produtos</li>
		<?php
		if(!empty($this->parametros[2])){
			echo '<li>('.$records->codigo.') '.$records->nome.'</li>';
		}
		?>
	</ol>
	<h4 class="page-title">
		<?php
		if(empty($this->parametros[2])){
			echo '<i class="fa fa-plus"></i> Novo Produto';
		}
		else
		{
			echo '<i class="fa fa-edit"></i> Editar Produto';
		}
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-5">
				<form id="form" action="<?php echo HOME_URI.$this->module.'/produtos/produto-save/id/'.$this->parametros[2]; ?>" class="" method="post">
					<fieldset>
						<legend>Dados do Produto</legend>
						<div class="form-group">
							<label for="codigo">Código</label>
							<input type="text" name="codigo" id="codigo" class="form-control uppercase masked" data-masked="SSS9999" placeholder="Código do produto" value="<?php echo isset($records)?$records->codigo:null ?>"/>
						</div>
						<div class="form-group">
							<label for="nome">Nome</label>
							<input type="text" name="nome" id="nome" class="form-control" placeholder="Nome do produto" value="<?php echo isset($records)?$records->nome:null ?>"/>
						</div>
						<div class="form-group">
							<label for="descricao">Descrição</label>
							<textarea rows="3" name="descricao" id="descricao" class="form-control" placeholder="Descrição"><?php echo isset($records)?$records->descricao:null ?></textarea>
						</div>
					</fieldset>
					<?php if(empty($this->parametros[2])){ ?>
					<a href="/cadastros/produtos/produtos-list/" class="btn btn-default"><i class="fa fa-times"></i> Cancelar</a>
					<?php } else { ?>
					<a href="/cadastros/produtos/produto-detalhe/id/<?= $this->parametros[2]; ?>" class="btn btn-default"><i class="fa fa-times"></i> Cancelar</a>
					<?php } ?>
					<button type="submit" class="btn btn-primary pull-right"><i class="fa fa-floppy-o"></i> Salvar</button>
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$(function() {
			$form = $('#form');
			$form.formValidation({
				framework: 'bootstrap',
				excluded: ':disabled',
				icon: {
					valid: 'fa fa-check',
					invalid: 'fa fa-times',
					validating: 'fa fa-refresh'
				},
				addOns: {
					mandatoryIcon: {
						icon: 'fa fa-asterisk'
					}
				},
				live: 'enabled',
				fields: {
					'nome':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'codigo':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							},
							regexp: {
								regexp: /^[A-Z]{3}[0-9]{4}$/,
								message: 'Código não válido'
							}
						}
					},
					'descricao':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
				}
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>