<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "produtos";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Cadastros</li>
		<li>Produtos</li>
	</ol>
	<h4 class="page-title">
		<?php
		echo '('.$records->codigo.') '.$records->nome;
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-5">
				<form>
					<fieldset>
						<legend>Dados do Produto</legend>
						<div class="form-group">
							<label for="codigo">Código</label>
							<input type="text" disabled name="codigo" id="codigo" class="form-control uppercase" placeholder="Código do produto" value="<?php echo isset($records)?$records->codigo:null ?>"/>
						</div>
						<div class="form-group">
							<label for="nome">Nome</label>
							<input type="text" disabled name="nome" id="nome" class="form-control" placeholder="Nome do produto" value="<?php echo isset($records)?$records->nome:null ?>"/>
						</div>
						<div class="form-group">
							<label for="descricao">Descrição</label>
							<textarea rows="3" disabled name="descricao" id="descricao" class="form-control" placeholder="Descrição"><?php echo isset($records)?$records->descricao:null ?></textarea>
						</div>
					</fieldset>
					<a href="/cadastros/produtos/produtos-list/" class="btn btn-default"><i class="fa fa-caret-left"></i> Voltar</a>
					<a class="btn btn-info" href="/cadastros/produtos/produto-cadastro/id/<?= $this->parametros[2]; ?>"><i class="fa fa-edit"></i> Editar</a>
				</form>
			</div>
			<div class="col-sm-12 col-md-7">
				<h4 class="page-header">Modulos</h4>
				<table id='list' class="table table-default table-striped table-bordered table-hover table-responsive dt-responsive">
					<thead>
						<tr>
							<th width="90" class="text-center">Código</th>
							<th>Nome</th>
							<th width="30"></th>
							<th width="120" class="text-center">Cobrança</th>
							<th width="90" class="text-center">Status</th>
						</tr>
					</thead>
					<tbody>
						<?php if (is_array($modules)){ ?>
						<?php foreach($modules as $key => $value) { ?>
						<tr>
							<td class="text-center"><?= $value->codigo ?></td>
							<td>
								<?= $value->descricao ?>
								<div class="pull-right">
									<a class="btn btn-primary btn-xs" href="/cadastros/produtos/modulo-detalhe/<?= $value->id_produto ?>/<?= $value->id ?>"><i class="fa fa-eye"></i> Detalhes</a>
									<?php if($value->status == 'inativo') { ?>
									<?php } elseif($value->status == 'suspenso') { ?>
									<?php } else { ?>
									<?php } ?>
								</div>
							</td>
							<td class="text-center">
								<?php if ($value->empacotavel == 1) { ?>
								<i class="fa fa-object-group"></i>
								<?php } else {?>
								<i class="fa fa-object-ungroup"></i>
								<?php } ?>
							</td>
							<td class="text-center"><?= $value->tipo_cobranca ?></td>
							<td class="text-center">
								<?php if($value->status == 'inativo') { ?>
								<span class="label label-danger label-status">
									<?= $value->status ?>
								</span>
								<?php } ?>
								<?php if($value->status == 'suspenso') { ?>
								<span class="label label-warning label-status">
									<?= $value->status ?>
								</span>
								<?php } ?>
								<?php if($value->status == 'ativo') { ?>
								<span class="label label-success label-status">
									<?= $value->status ?>
								</span>
								<?php } ?>
							</td>
						</tr>
						<?php } ?>
						<?php } else {?>
						<tr>
							<td colspan="100%" class="text-center">Sem Registros</td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
				<a class="btn btn-default" href="/cadastros/produtos/modulo-cadastro/<?= $this->parametros[2]; ?>/0"><i class="fa fa-plus"></i> Novo Módulo</a>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
