<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 17/10/2016
 * Time: 16:10
 */

?>

<div class="row">

    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 class="panel-title">Recupere sua senha</h3>
        </div>
        <div class="panel-body">
            <span class="label label-warning"><?php echo ($this->success)?$this->success:$this->error; ?></span>
            <div class="clearfix"></div>
            <div class="table-responsive">
                <form method="post">
                <table class="table table-striped table-hover table-bordered ">
                    <tbody>
                        <tr>
                            <td colspan="4">
                                <span class="label label-default">DIGITE O CNPJ OU EMAIL:</span> <input type="text" name="cnpj" id="cnpj" required />
                                <span class="label label-default"> *apenas numeros para o cnpj </span>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="4"> <input type="submit" value="ENVIAR"></td>
                        </tr>
                    </tbody>
                </table>
                </form>
            </div>
        </div>
    </div>
</div>



