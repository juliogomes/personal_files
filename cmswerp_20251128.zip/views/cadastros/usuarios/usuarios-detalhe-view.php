<?php
if ( !$this->logged_in )
{
	echo 'Efetue o login para acessar esse registro, clicando <a href="'.HOME_URI.'login/"> aqui </a>';
	exit;
}
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "usuarios";
	</script>
	<style type="text/css" media="screen">
		input[type="radio"].styled:checked+label:after {
			font-family: 'FontAwesome';
			content: '';
		}
	</style>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Cadastros</li>
		<li>Usuários</li>
	</ol>
	<h4 class="page-title">
		<?php
		if(empty($this->parametros[1])){
			echo '<i class="fa fa-plus"></i> Novo Usuário';
		}
		else
		{
			echo '<i class="fa fa-edit"></i> Editar Usuário';
		}
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-6">
				<form id="form" action="<?php echo HOME_URI.'usuarios/save/id/'.$this->parametros[1]; ?>" class="" method="post">
					<fieldset>
						<legend>Dados do Usuário</legend>
						<div class="form-group">
							<label for="nome">Nome:</label>
							<input type="text" class="form-control" placeholder="Nome" name="nome" id="nome" value="<?php echo isset($records)?$records->nome:null ?>"/>
						</div>
						<div class="form-group">
							<label for="email">E-mail:</label>
							<input type="text" class="form-control" placeholder="E-mail" name="email" id="email" value="<?php echo isset($records)?$records->email:null ?>"/>
						</div>
						<div class="form-group">
							<label>Perfil</label>
							<div class="radio radio-info">
								<input type="radio" name="perfil" id="perfilInfo" value="info" <?php echo (isset($records) && $records->perfil == 'info')?'checked':'' ?>>
								<label for="perfilInfo">Info</label>
							</div>
							<div class="radio radio-info">
								<input type="radio" name="perfil" id="perfilOper" value="oper" <?php echo (isset($records) && $records->perfil == 'oper')?'checked':'' ?>>
								<label for="perfilOper">Oper</label>
							</div>
							<div class="radio radio-info">
								<input type="radio" name="perfil" id="perfilSuper" value="super" <?php echo (isset($records) && $records->perfil == 'super')?'checked':'' ?>>
								<label for="perfilSuper">Super</label>
							</div>
							<div class="radio radio-info">
								<input type="radio" name="perfil" id="perfilVendas" value="vendas" <?php echo (isset($records) && $records->perfil == 'vendas')?'checked':'' ?>>
								<label for="perfilVendas">Vendas</label>
							</div>
						</div>
					</fieldset>
					<fieldset>
						<legend>Permissões</legend>
							<table class="table">
								<tr>
									<th></th>
									<th>NEGADO</th>
									<th>VISUALIZAR</th>
									<th>EDITAR</th>
								</tr>
								<tr>
									<td>CONTRATOS</td>
									<td><input type="radio" name="permissoes[contratos]" value="none" checked></td>
									<td><input type="radio" name="permissoes[contratos]" value="view"></td>
									<td><input type="radio" name="permissoes[contratos]" value="edit"></td>
								</tr>
								<tr>
									<td>TARIFADOR</td>
									<td><input type="radio" name="permissoes[tarifador]" value="none" checked></td>
									<td><input type="radio" name="permissoes[tarifador]" value="view"></td>
									<td><input type="radio" name="permissoes[tarifador]" value="edit"></td>
								</tr>
								<tr>
									<td>PRODUTOS</td>
									<td><input type="radio" name="permissoes[produtos]" value="none" checked></td>
									<td><input type="radio" name="permissoes[produtos]" value="view"></td>
									<td><input type="radio" name="permissoes[produtos]" value="edit"></td>
								</tr>
								<tr>
									<td>EMPRESAS</td>
									<td><input type="radio" name="permissoes[empresas]" value="none" checked></td>
									<td><input type="radio" name="permissoes[empresas]" value="view"></td>
									<td><input type="radio" name="permissoes[empresas]" value="edit"></td>
								</tr>
								<tr>
									<td>DIRETORES</td>
									<td><input type="radio" name="permissoes[diretores]" value="none" checked></td>
									<td><input type="radio" name="permissoes[diretores]" value="view"></td>
									<td><input type="radio" name="permissoes[diretores]" value="edit"></td>
								</tr>
								<tr>
									<td>VENDEDORES</td>
									<td><input type="radio" name="permissoes[vendedores]" value="none" checked></td>
									<td><input type="radio" name="permissoes[vendedores]" value="view"></td>
									<td><input type="radio" name="permissoes[vendedores]" value="edit"></td>
								</tr>
								<tr>
									<td>USUARIOS</td>
									<td><input type="radio" name="permissoes[usuarios]" value="none" checked></td>
									<td><input type="radio" name="permissoes[usuarios]" value="view"></td>
									<td><input type="radio" name="permissoes[usuarios]" value="edit"></td>
								</tr>
								<tr>
									<td>INDICES DE REAJUSTE</td>
									<td><input type="radio" name="permissoes[indices_reajuste]" value="none" checked></td>
									<td><input type="radio" name="permissoes[indices_reajuste]" value="view"></td>
									<td><input type="radio" name="permissoes[indices_reajuste]" value="edit"></td>
								</tr>
							</table>
					</fieldset>
					<a href="/usuarios/lista/" class="btn btn-default"><i class="fa fa-times"></i> Cancelar</a>
					<button type="submit" class="btn btn-primary pull-right"><i class="fa fa-floppy-o"></i> Salvar</button>
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$(function() {
			$form = $('#form');
			$form.formValidation({
				framework: 'bootstrap',
				excluded: ':disabled',
				icon: {
					valid: 'fa fa-check',
					invalid: 'fa fa-times',
					validating: 'fa fa-refresh'
				},
				addOns: {
					mandatoryIcon: {
						icon: 'fa fa-asterisk'
					}
				},
				live: 'enabled',
				fields: {
					'nome':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'email':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							},
							regexp: {
								regexp: /^([\w\.\-_]+)?\w+@[\w-_]+(\.\w+){1,}$/i,
								message: 'Email mão é válido'
							}
						}
					},
					'perfil':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					}
				}
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>