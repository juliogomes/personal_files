<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 17/10/2016
 * Time: 16:10
 */
if ( !$this->logged_in ) {
	echo 'Efetue o login para acessar esse registro, clicando <a href="'.HOME_URI.'login/"> aqui </a>';
	exit;
}
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "usuarios";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Cadastros</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> Usuários</h4>
	<form class="form-inline page-toolbar">
		<div class="btn-group" role="group">
			<a href="/usuarios/detalhe/id/0" class="btn btn-default"><i class="fa fa-plus"></i> Novo Usuário</a>
		</div>
		<div class="pull-right">
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Nome</div>
					<input class="form-control" placeholder="Usuário" type="text" id="searchName">
				</div>
			</div>
		</div>
	</form>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
					<thead>
						<tr>
							<th>Nome</th>
							<th width="280">E-mail</th>
							<th width="90" class="text-center">Status</th>
						</tr>
					</thead>
					<tbody>
						<?php if (is_array($records)){ ?>
						<?php foreach($records as $key => $value) { ?>
						<tr>
							<td>
								<?= $value->nome ?>
								<div class="pull-right">
									<?php if($value->status == 'inativo') { ?>
									<?php } elseif($value->status == 'suspenso') { ?>
									<button class="btn btn-success btn-xs" data-toggle="modal" data-target="#statusModal" data-status="ativo" data-id="<?= $value->id ?>" data-nome="<?= $value->nome ?>">
										<i class="fa fa-check"></i> Ativar
									</button>
									<button class="btn btn-danger btn-xs" data-toggle="modal" data-target="#statusModal" data-status="inativo" data-id="<?= $value->id ?>" data-nome="<?= $value->nome ?>">
										<i class="fa fa-stop-circle"></i> Inativar
									</button>
									<?php } else { ?>
									<a class="btn btn-info btn-xs" href="/usuarios/detalhe/id/<?= $value->id ?>/"><i class="fa fa-edit"></i> Editar</a>
									<button class="btn btn-warning btn-xs" data-toggle="modal" data-target="#statusModal" data-status="suspenso" data-id="<?= $value->id ?>" data-nome="<?= $value->nome ?>">
										<i class="fa fa-pause-circle"></i> Suspender
									</button>
									<?php } ?>
								</div>
							</td>
							<td><?= $value->email ?></td>
							<td class="text-center">
								<?php if($value->status == 'inativo') { ?>
								<span class="label label-danger label-status">
								<?php } elseif($value->status == 'suspenso') { ?>
								<span class="label label-warning label-status">
								<?php } else { ?>
								<span class="label label-success label-status">
								<?php } ?>
								<?= $value->status ?>
								</span>
							</td>
						</tr>
						<?php } ?>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<div class="modal fade" tabindex="-1" role="dialog" id="statusModal">
		<div class="modal-dialog " role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4 class="modal-title"></h4>
				</div>
				<form method="post">
					<div class="modal-body">
						<div class="alert">

						</div>
						<input type="hidden" id="status" name="status" value="suspenso">
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
						<button type="submit" class="submit btn"></button>
					</div>
				</form>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript">
		$(function() {
			oTable = $('#list').DataTable({
				info: false,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				}
			});
			$('#searchName').keyup(function(){
				oTable
				.columns( 0 )
				.search( this.value )
				.draw();
			});
			$('#statusModal').on('show.bs.modal', function (event) {
				var button = $(event.relatedTarget);
				var id = button.data('id');
				var nome = button.data('nome');
				var status = button.data('status');
				var title;
				var style;
				var message;
				if (status === 'suspenso'){
					title = 'Suspender';
					style = 'warning';
					message = 'Você realmente deseja <strong>SUSPENDER</strong> o Usuário <strong>' + nome + '</strong>?';
				}
				else if (status === 'ativo'){
					title = 'Ativar';
					style = 'success';
					message = 'Você realmente deseja <strong>ATIVAR</strong> o Usuário <strong>' + nome + '</strong>?';
				}
				else if (status === 'inativo'){
					title = 'Inativar';
					style = 'danger';
					message = '<h4>Essa opção não poderá ser desfeita</h4>Você realmente deseja <strong>INATIVAR</strong> o Usuário <strong>' + nome + '</strong>?';
				}

				var modal = $(this);

				modal.find('form').attr('action', '/usuarios/updateStatus/id/'+id);
				modal.find('.modal-title').html(title);
				modal.find('.modal-body .alert').html(message);
				modal.find('.modal-body .alert').removeClass().addClass('alert alert-'+style);
				modal.find('.modal-body #status').val(status);
				modal.find('.modal-footer .submit').removeClass().addClass('submit btn btn-'+style);
				modal.find('.modal-footer .submit').html(title);
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>