<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
	<head>
		<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
		<?php include 'template/head-css.inc' ?>
		<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
		<!-- PAGE STYLES -->
		<script type="text/javascript">
			var sidebarItem = "contratos";
		</script>
		<!-- /PAGE STYLES -->
	</head>
	<body>
		<!-- MENU + WRAPPER -->
		<?php include "template/menu-wrapper.php" ?>
		<!-- /MENU + WRAPPER -->
		<!-- HEADER -->
		<ol class="breadcrumb">
			<li>Tarifas.cmsw.com</li>
			<li>Contratos</li>
			<li>( <?= $contrato[0]->numero_contrato ?> )<?= $contrato[0]->razao_social ?></li>
		</ol>
		<h4 class="page-title"><i class="fa fa-caret-right"></i> Preços <?= $contrato[0]->nome_produto?></h4>
		<!-- /HEADER -->
		<!-- CONTENT -->
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12" id="msg">
					<h3><span "class="label label-default""><?= isset($_GET['msg'])?base64_decode($_GET['msg']):null; ?></span></h3>
				</div>
				<div class="col-md-12">
					<?php if (is_array($modulos)){ ?>
						<?php foreach($modulos as $key => $value) {?>
							<div class="panel panel-default">
								<div class="panel-heading">
									<h3 class="panel-title"><?= $value->descricao ?></h3>
								</div>
								<?php $this->cobranca_modulo($this->parametros[1], $value->id, $this->globals['TABELAS_COBRANCA'][$value->tipo_cobranca]); ?>
								<?php if($this->valores) { ?>
									<?php if($value->tipo_cobranca == 'VOLUMETRIA') { ?>
									<!-- Volumetria -->
									<div class="row">
										<!-- Faixas -->
										<div class="col-md-7">
											<form name="metodo_cobranca" id="volumetria" action="/cobranca/processar/id/<?= $contrato[0]->id_contrato?>" method="post">
												<fieldset>
													<legend>Faixas</legend>
													<table id='list' class="table table-default table-striped table-bordered table-hover table-responsive dt-responsive">
														<thead>
															<tr>
																<th class="text-right">De</th>
																<th>Até</th>
																<th class="text-right">Valor (R$)</th>
																<th class="text-right"></th>
															</tr>
														</thead>
														<tbody>
														<?php foreach($this->valores as $chave=>$valor) { ?>
															<tr>
																<td>
																	<input type="hidden" class="form-control"  name="id_lp_cliente-<?= $valor->id_lp_cliente;?>"  value="<?= (isset($valor->id_lp_cliente))?$valor->id_lp_cliente:null; ?>">
																	<input type="hidden" class="form-control"  name="id_produto" id="id_produto" value="<?= $contrato[0]->id_produto ?>">
																	<input type="hidden" class="form-control"  name="id_modulo" id="id_modulo" value="<?= $value->id ?>">
																	<input type="hidden" class="form-control"  name="tipo_cobranca" id="tipo_cobranca" value="<?= $value->tipo_cobranca ?>">
																	<input type="text" class="form-control text-right"  name="qtd_de-<?= $valor->id;?>" id="qtd_de" value="<?= $valor->qtd_de ?>">
																</td>
																<td><input type="text" class="form-control" name="qtd_ate-<?= $valor->id;?>" id="qtd_ate" value="<?= $valor->qtd_ate ?>"></td>
																<td><input type="text" class="form-control text-right" name="valor_real-<?= $valor->id;?>" id="valor_real" value="<?= $valor->valor_real ?>"></td>
																<td><a href="/cobranca/delete/<?= $this->parametros[1]?>/<?= $valor->id ?>/" class="btn btn-warning"><i class="fa fa-trash"></i>Apagar</a></td>
															</tr>
														<?php } ?> <!-- End FOREACH -->
														</tbody>
													</table>
												</fieldset>
												<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Salvar Faixas</button>
											</form>
										</div>
										<!-- /Faixas -->
										<?php if($value->empacotavel) { ?>
										<?php $pacote = json_decode($this->modelo->getPacote($contrato[0]->id_contrato, $value->id)); ?>
										<!-- Pacote -->
										<div class="col-md-5">
											<form name="pacote" action="/cobranca/pacote/save/id/<?= $contrato[0]->id_contrato?>"  method="post" style="margin-left: 0;">
											<input type="hidden" name="id" value="<?= (isset($pacote))?$pacote[0]->id:null; ?>">
											<input type="hidden" name="id_modulos_tarifaveis" value="<?= $value->id; ?>">
												<fieldset>
													<legend>Pacote</legend>
													<div class="form-group">
														<input type="text" class="form-control" placeholder="Quantidade" name="qdt_garantido" value="<?= (isset($pacote))?$pacote[0]->qdt_garantido:null; ?>">
													</div>
													<div class="form-group">
														<input type="text"  class="form-control" placeholder="Valor" name="preco_pkt" id="preco_pkt" value="<?= (isset($pacote))?$pacote[0]->preco_pkt:null; ?>">
													</div>
													<div class="form-group">
														<select name="status" class="form-control select">
															<option value="">Situação</option>
															<option value="ativo" <?= (isset($pacote) && $pacote[0]->status == 'ativo')?'selected':null; ?>>ATIVO</option>
															<option value="inativo" <?= (isset($pacote) && $pacote[0]->status == 'inativo')?'selected':null; ?>>INATIVO</option>
															<option value="suspenso" <?= (isset($pacote) && $pacote[0]->status == 'suspenso')?'selected':null; ?>>SUSPENSO</option>
														</select>
													</div>
												</fieldset>
												<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Salvar Pacote</button>
											</form>
										</div>
										<!-- /Pacote -->
										<?php } ?>
									</div>
									<?php}elseif($value->tipo_cobranca == 'FAIXA-FIXA') { ?>
									<!-- Volumetria -->
									<div class="row">
										<!-- Faixas -->
										<div class="col-md-7">
											<form name="metodo_cobranca" id="volumetria" action="/cobranca/processar/id/<?= $contrato[0]->id_contrato?>" method="post">
												<fieldset>
													<legend>Faixas</legend>
													<table id='list' class="table table-default table-striped table-bordered table-hover table-responsive dt-responsive">
														<thead>
															<tr>
																<th class="text-right">De</th>
																<th>Até</th>
																<th class="text-right">Valor (R$)</th>
																<th class="text-right"></th>
															</tr>
														</thead>
														<tbody>
														<?php foreach($this->valores as $chave=>$valor) { ?>
															<tr>
																<td>
																	<input type="hidden" class="form-control"  name="id_lp_cliente-<?= $valor->id_lp_cliente;?>"  value="<?= (isset($valor->id_lp_cliente))?$valor->id_lp_cliente:null; ?>">
																	<input type="hidden" class="form-control"  name="id_produto" id="id_produto" value="<?= $contrato[0]->id_produto ?>">
																	<input type="hidden" class="form-control"  name="id_modulo" id="id_modulo" value="<?= $value->id ?>">
																	<input type="hidden" class="form-control"  name="tipo_cobranca" id="tipo_cobranca" value="<?= $value->tipo_cobranca ?>">
																	<input type="text" class="form-control text-right"  name="qtd_de-<?= $valor->id;?>" id="qtd_de" value="<?= $valor->qtd_de ?>">
																</td>
																<td><input type="text" class="form-control" name="qtd_ate-<?= $valor->id;?>" id="qtd_ate" value="<?= $valor->qtd_ate ?>"></td>
																<td><input type="text" class="form-control text-right" name="valor_real-<?= $valor->id;?>" id="valor_real" value="<?= $valor->valor_real ?>"></td>
																<td><a href="/cobranca/delete/<?= $this->parametros[1]?>/<?= $valor->id ?>/" class="btn btn-warning"><i class="fa fa-trash"></i>Apagar</a></td>
															</tr>
														<?php } ?> <!-- End FOREACH -->
														</tbody>
													</table>
												</fieldset>
												<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Salvar Faixas</button>
											</form>
										</div>
										<!-- /Faixas -->
										<?php if($value->empacotavel) { ?>
										<?php $pacote = json_decode($this->modelo->getPacote($contrato[0]->id_contrato, $value->id)); ?>
										<!-- Pacote -->
										<div class="col-md-5">
											<form name="pacote" action="/cobranca/pacote/save/id/<?= $contrato[0]->id_contrato?>"  method="post" style="margin-left: 0;">
											<input type="hidden" name="id" value="<?= (isset($pacote))?$pacote[0]->id:null; ?>">
											<input type="hidden" name="id_modulos_tarifaveis" value="<?= $value->id; ?>">
												<fieldset>
													<legend>Pacote</legend>
													<div class="form-group">
														<input type="text" class="form-control" placeholder="Quantidade" name="qdt_garantido" value="<?= (isset($pacote))?$pacote[0]->qdt_garantido:null; ?>">
													</div>
													<div class="form-group">
														<input type="text"  class="form-control" placeholder="Valor" name="preco_pkt" id="preco_pkt" value="<?= (isset($pacote))?$pacote[0]->preco_pkt:null; ?>">
													</div>
													<div class="form-group">
														<select name="status" class="form-control select">
															<option value="">Situação</option>
															<option value="ativo" <?= (isset($pacote) && $pacote[0]->status == 'ativo')?'selected':null; ?>>ATIVO</option>
															<option value="inativo" <?= (isset($pacote) && $pacote[0]->status == 'inativo')?'selected':null; ?>>INATIVO</option>
															<option value="suspenso" <?= (isset($pacote) && $pacote[0]->status == 'suspenso')?'selected':null; ?>>SUSPENSO</option>
														</select>
													</div>
												</fieldset>
												<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Salvar Pacote</button>
											</form>
										</div>
										<!-- /Pacote -->
										<?php } ?>
									</div>
									<!-- /Volumetria -->
									<?php } else if($value->tipo_cobranca == 'LIQUIDADO-REAL') {?>
									<!-- LIQUIDADO-REAL -->
									<div class="row">
										<!-- Faixas -->
										<div class="col-md-7">
											<form name="metodo_cobranca" id="liquidado-real" action="/cobranca/processar/id/<?= $contrato[0]->id_contrato?>" method="post">
												<fieldset>
													<legend>Faixas</legend>
													<table id='list' class="table table-default table-striped table-bordered table-hover table-responsive dt-responsive">
														<thead>
															<tr>
																<th class="text-right">De</th>
																<th>Até</th>
																<th class="text-right">Valor (R$)</th>
															</tr>
														</thead>
														<tbody>
														<?php foreach($this->valores as $chave=>$valor) { ?>
															<tr>
																<td>
																<input type="hidden" class="form-control"  name="id_lp_cliente-<?= $valor->id_lp_cliente;?>"  value="<?= (isset($valor->id_lp_cliente))?$valor->id_lp_cliente:null; ?>">
																<input type="hidden" class="form-control"  name="id_produto" id="id_produto" value="<?= $contrato[0]->id_produto ?>">
																<input type="hidden" class="form-control"  name="id_modulo" id="id_modulo" value="<?= $value->id ?>">
																<input type="hidden" class="form-control"  name="tipo_cobranca" id="tipo_cobranca" value="<?= $value->tipo_cobranca ?>">
																<input type="text" class="form-control text-right"  name="qtd_de-<?= $valor->id;?>" id="qtd_de" value="<?= $valor->qtd_de ?>"></td>
																<td><input type="text" class="form-control" name="qtd_ate-<?= $valor->id;?>" id="qtd_ate" value="<?= $valor->qtd_ate ?>"></td>
																<td><input type="text" class="form-control text-right" name="valor_real-<?= $valor->id;?>" id="valor_real" value="<?= $valor->valor_real ?>"></td>
																	<td><a href="/cobranca/delete/<?= $this->parametros[1]?>/<?= $valor->id ?>/" class="btn btn-warning"><i class="fa fa-trash"></i>Apagar</a></td>
															</tr>
														<?php } ?> <!-- End FOREACH -->
														</tbody>
													</table>
												</fieldset>
												<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Salvar Faixas</button>
											</form>
										</div>
										<!-- /Faixas -->
										<?php if($value->empacotavel) { ?>
										<?php $pacote = json_decode($this->modelo->getPacote($contrato[0]->id, $value->id)); ?>
										<!-- Pacote -->
										<div class="col-md-5">
											<form name="pacote" action="/cobranca/pacote/save/id/<?= $contrato[0]->id_contrato?>"  method="post" style="margin-left: 0;">
											<input type="hidden" name="id" value="<?= (isset($pacote))?$pacote[0]->id:null; ?>">
											<input type="hidden" name="id_modulos_tarifaveis" value="<?= $value->id; ?>">
												<fieldset>
													<legend>Pacote</legend>
													<div class="form-group">
														<input type="text" class="form-control" placeholder="Quantidade" name="qdt_garantido" value="<?= (isset($pacote))?$pacote[0]->qdt_garantido:null; ?>">
													</div>
													<div class="form-group">
														<input type="text"  class="form-control" placeholder="Valor" name="preco_pkt" id="preco_pkt" value="<?= (isset($pacote))?$pacote[0]->preco_pkt:null; ?>">
													</div>
													<div class="form-group">
														<select name="status" class="form-control select">
															<option value="">Situação</option>
															<option value="ativo" <?= (isset($pacote) && $pacote[0]->status == 'ativo')?'selected':null; ?>>ATIVO</option>
															<option value="inativo" <?= (isset($pacote) && $pacote[0]->status == 'inativo')?'selected':null; ?>>INATIVO</option>
															<option value="suspenso" <?= (isset($pacote) && $pacote[0]->status == 'suspenso')?'selected':null; ?>>SUSPENSO</option>
														</select>
													</div>
												</fieldset>
												<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Salvar Pacote</button>
											</form>
										</div>
										<!-- /Pacote -->
										<?php } ?>
									</div>
									<!-- /LIQUIDADO-REAL -->
									<?php } else if($value->tipo_cobranca == 'LIQUIDADO-RELATIVO') {?>
									<!-- LIQUIDADO-RELATIVO -->
									<div class="row">
										<!-- Faixas -->
										<div class="col-md-7">
											<form name="metodo_cobranca" id="liquidado-relativo" action="/cobranca/processar/id/<?= $contrato[0]->id_contrato?>" method="post">
												<fieldset>
													<legend>Faixas</legend>
													<table id='list' class="table table-default table-striped table-bordered table-hover table-responsive dt-responsive">
														<thead>
															<tr>
																<th colspan="2" class="text-center">Quantidade</th>
																<th colspan="2" class="text-center">Aging</th>
																<th colspan="2"></th>
															</tr>
															<tr>
																<th class="text-right">De</th>
																<th>Até</th>
																<th class="text-right">De</th>
																<th>Até</th>
																<th class="text-right">Valor (R$)</th>
															</tr>
														</thead>
														<tbody>
														<?php foreach($this->valores as $chave=>$valor) { ?>
															<tr>
																<td>
																<input type="hidden" class="form-control"  name="id_lp_cliente-<?= $valor->id_lp_cliente;?>"  value="<?= (isset($valor->id_lp_cliente))?$valor->id_lp_cliente:null; ?>">
																<input type="hidden" class="form-control"  name="id_produto" id="id_produto" value="<?= $contrato[0]->id_produto ?>">
																<input type="hidden" class="form-control"  name="id_modulo" id="id_modulo" value="<?= $value->id ?>">
																<input type="hidden" class="form-control"  name="tipo_cobranca" id="tipo_cobranca" value="<?= $value->tipo_cobranca ?>">
																<input type="text" class="form-control text-right" name="qtd_de-<?= $valor->id;?>" id="qtd_de" value="<?= $valor->qtd_de ?>"></td>
																<td><input type="text" class="form-control" name="qtd_ate-<?= $valor->id;?>" id="qtd_ate" value="<?= $valor->qtd_ate ?>"></td>
																<td><input type="text" class="form-control text-right" name="idade_de-<?= $valor->id;?>" id="idade_de" value="<?= $valor->idade_de ?>"></td>
																<td><input type="text" class="form-control" name="idade_ate-<?= $valor->id;?>" id="idade_ate" value="<?= $valor->idade_ate ?>"></td>
																<td><input type="text" class="form-control text-right" name="valor_relativo-<?= $valor->id;?>" id="valor_relativo" value="<?= $valor->valor_relativo ?>"></td>
																<td><a href="/cobranca/delete/<?= $this->parametros[1]?>/<?= $valor->id ?>/" class="btn btn-warning"><i class="fa fa-trash"></i>Apagar</a></td>
															</tr>
														<?php } ?> <!-- End FOREACH -->
														</tbody>
													</table>
												</fieldset>
												<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Salvar Faixas</button>
											</form>
										</div>
										<!-- /Faixas -->
										<?php if($value->empacotavel) { ?>
										<?php $pacote = json_decode($this->modelo->getPacote($contrato[0]->id, $value->id)); ?>
										<!-- Pacote -->
										<div class="col-md-5">
											<form name="pacote" action="/cobranca/pacote/save/id/<?= $contrato[0]->id_contrato?>"  method="post" style="margin-left: 0;">
											<input type="hidden" name="id" value="<?= (isset($pacote))?$pacote[0]->id:null; ?>">
											<input type="hidden" name="id_modulos_tarifaveis" value="<?= $value->id; ?>">
												<fieldset>
													<legend>Pacote</legend>
													<div class="form-group">
														<input type="text" class="form-control" placeholder="Quantidade" name="qdt_garantido" value="<?= (isset($pacote))?$pacote[0]->qdt_garantido:null; ?>">
													</div>
													<div class="form-group">
														<input type="text"  class="form-control" placeholder="Valor" name="preco_pkt" id="preco_pkt" value="<?= (isset($pacote))?$pacote[0]->preco_pkt:null; ?>">
													</div>
													<div class="form-group">
														<select name="status" class="form-control select">
															<option value="">Situação</option>
															<option value="ativo" <?= (isset($pacote) && $pacote[0]->status == 'ativo')?'selected':null; ?>>ATIVO</option>
															<option value="inativo" <?= (isset($pacote) && $pacote[0]->status == 'inativo')?'selected':null; ?>>INATIVO</option>
															<option value="suspenso" <?= (isset($pacote) && $pacote[0]->status == 'suspenso')?'selected':null; ?>>SUSPENSO</option>
														</select>
													</div>
												</fieldset>
												<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Salvar Pacote</button>
											</form>
										</div>
										<!-- /Pacote -->
										<?php } ?>
									</div>
									<!-- /LIQUIDADO-RELATIVO -->
									<?php } else if($value->tipo_cobranca == 'COBRANCA-ELETRONICA') {?>
									<!-- COBRANCA-ELETRONICA -->
									<div class="row">
										<!-- Faixas -->
										<div class="col-md-7">

											<form name="metodo_cobranca" id="cobranca-eletronica" action="/cobranca/processar/id/<?= $contrato[0]->id_contrato?>" method="post">
												<fieldset>
													<legend>Faixas</legend>
													<table id='list' class="table table-default table-striped table-bordered table-hover table-responsive dt-responsive">
														<thead>
															<tr>
																<th width="140" class="text-right">De</th>
																<th width="140" class="text-left">Até</th>
																<th class="text-right">Percentual (%)</th>
															</tr>
														</thead>
														<tbody>
														<?php foreach($this->valores as $chave=>$valor) { ?>
															<tr>
																<td>
																<input type="hidden" class="form-control"  name="id_lp_cliente-<?= $valor->id_lp_cliente;?>"  value="<?= (isset($valor->id_lp_cliente))?$valor->id_lp_cliente:null; ?>">
																<input type="hidden" class="form-control"  name="id_produto" id="id_produto" value="<?= $contrato[0]->id_produto ?>">
																<input type="hidden" class="form-control"  name="id_modulo" id="id_modulo" value="<?= $value->id ?>">
																<input type="hidden" class="form-control"  name="tipo_cobranca" id="tipo_cobranca" value="<?= $value->tipo_cobranca ?>">
																<input type="text" class="form-control text-right"  name="qtd_de-<?= $valor->id;?>" id="qtd_de" value="<?= $valor->qtd_de ?>"></td>
																<td><input type="text" class="form-control" name="qtd_ate-<?= $valor->id;?>" id="qtd_ate" value="<?= $valor->qtd_ate ?>"></td>
																<td><input type="text" class="form-control text-right" name="percentual-<?= $valor->id;?>" id="percentual" value="<?= $valor->percentual ?>"></td>
																<td><a href="/cobranca/delete/<?= $this->parametros[1]?>/<?= $valor->id ?>/" class="btn btn-warning"><i class="fa fa-trash"></i>Apagar</a></td>
															</tr>
														<?php } ?> <!-- End FOREACH -->
														</tbody>
													</table>
												</fieldset>
												<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Salvar Faixas</button>
											</form>
										</div>
										<!-- /Faixas -->
										<?php if($value->empacotavel) { ?>
										<?php $pacote = json_decode($this->modelo->getPacote($contrato[0]->id_contrato, $value->id)); ?>
										<!-- Pacote -->
										<div class="col-md-5">
											<form name="pacote" action="/cobranca/pacote/save/id/<?= $contrato[0]->id_contrato?>"  method="post" style="margin-left: 0;">
											<input type="hidden" name="id" value="<?= (isset($pacote))?$pacote[0]->id:null; ?>">
											<input type="hidden" name="id_modulos_tarifaveis" value="<?= $value->id; ?>">
												<fieldset>
													<legend>Pacote</legend>
													<div class="form-group">
														<input type="text" class="form-control" placeholder="Quantidade" name="qdt_garantido" value="<?= (isset($pacote))?$pacote[0]->qdt_garantido:null; ?>">
													</div>
													<div class="form-group">
														<input type="text"  class="form-control" placeholder="Valor" name="preco_pkt" id="preco_pkt" value="<?= (isset($pacote))?$pacote[0]->preco_pkt:null; ?>">
													</div>
													<div class="form-group">
														<select name="status" class="form-control select">
															<option value="">Situação</option>
															<option value="ativo" <?= (isset($pacote) && $pacote[0]->status == 'ativo')?'selected':null; ?>>ATIVO</option>
															<option value="inativo" <?= (isset($pacote) && $pacote[0]->status == 'inativo')?'selected':null; ?>>INATIVO</option>
															<option value="suspenso" <?= (isset($pacote) && $pacote[0]->status == 'suspenso')?'selected':null; ?>>SUSPENSO</option>
														</select>
													</div>
												</fieldset>
												<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Salvar Pacote</button>
											</form>
										</div>
										<!-- /Pacote -->
										<?php } ?>
									</div>
									<!-- /COBRANCA-ELETRONICA -->
									<?php } else if($value->tipo_cobranca == 'GOCHK') {?>
									<!-- GOCHK -->
									<div class="row">
										<!-- Faixas -->
										<div class="col-md-7">
										<form name="metodo_cobranca" id="gochk" action="/cobranca/processar/id/<?= $contrato[0]->id_contrato?>" method="post">
												<fieldset>
													<legend>Faixas</legend>
													<table id='list' class="table table-default table-striped table-bordered table-hover table-responsive dt-responsive">
														<thead>
															<tr>
																<th class="text-right">Real (R$)</th>
																<th class="text-right">Relativo (R$)</th>
															</tr>
														</thead>
														<tbody>
														<?php foreach($this->valores as $chave=>$valor) { ?>
															<tr>
																<td>
																<input type="hidden" class="form-control"  name="id_lp_cliente-<?= $valor->id_lp_cliente;?>"  value="<?= (isset($valor->id_lp_cliente))?$valor->id_lp_cliente:null; ?>">
																<input type="hidden" class="form-control"  name="id_produto" id="id_produto" value="<?= $contrato[0]->id_contrato_produto ?>">
																<input type="hidden" class="form-control"  name="id_modulo" id="id_modulo" value="<?= $value->id ?>">
																<input type="hidden" class="form-control"  name="tipo_cobranca" id="tipo_cobranca" value="<?= $value->tipo_cobranca ?>">
																<input type="text" class="form-control text-right"  name="valor_real-<?= $valor->id;?>" id="valor_real" value="<?= $valor->valor_real ?>"></td>
																<td><input type="text" class="form-control text-right" name="valor_relativo-<?= $valor->id;?>" id="valor_relativo" value="<?= $valor->valor_relativo ?>"></td>
																<td><a href="/cobranca/delete/<?= $this->parametros[1]?>/<?= $valor->id ?>/" class="btn btn-warning"><i class="fa fa-trash"></i>Apagar</a></td>
															</tr>
														<?php } ?> <!-- End FOREACH -->
														</tbody>
													</table>
												</fieldset>
												<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Salvar Faixas</button>
											</form>
										</div>
										<!-- /Faixas -->
										<?php if($value->empacotavel) { ?>
										<?php $pacote = json_decode($this->modelo->getPacote($contrato[0]->id_contrato, $value->id)); ?>
										<!-- Pacote -->
										<div class="col-md-5">
											<form name="pacote" action="/cobranca/pacote/save/id/<?= $contrato[0]->id?>"  method="post" style="margin-left: 0;">
											<input type="hidden" name="id" value="<?= (isset($pacote))?$pacote[0]->id:null; ?>">
											<input type="hidden" name="id_modulos_tarifaveis" value="<?= $value->id; ?>">
												<fieldset>
													<legend>Pacote</legend>
													<div class="form-group">
														<input type="text" class="form-control" placeholder="Quantidade" name="qdt_garantido" value="<?= (isset($pacote))?$pacote[0]->qdt_garantido:null; ?>">
													</div>
													<div class="form-group">
														<input type="text"  class="form-control" placeholder="Valor" name="preco_pkt" id="preco_pkt" value="<?= (isset($pacote))?$pacote[0]->preco_pkt:null; ?>">
													</div>
													<div class="form-group">
														<select name="status" class="form-control select">
															<option value="">Situação</option>
															<option value="ativo" <?= (isset($pacote) && $pacote[0]->status == 'ativo')?'selected':null; ?>>ATIVO</option>
															<option value="inativo" <?= (isset($pacote) && $pacote[0]->status == 'inativo')?'selected':null; ?>>INATIVO</option>
															<option value="suspenso" <?= (isset($pacote) && $pacote[0]->status == 'suspenso')?'selected':null; ?>>SUSPENSO</option>
														</select>
													</div>
												</fieldset>
												<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Salvar Pacote</button>
											</form>
										</div>
										<!-- /Pacote -->
										<?php } ?>
									</div>
									<!-- /GOCHK -->
									<?php } else if($value->tipo_cobranca == 'KUMRAM') {?>
									<!-- KUMRAM -->
									<div class="row">
										<!-- Faixas -->
										<div class="col-md-7">
											<form name="metodo_cobranca" id="kumram" action="/cobranca/processar/id/<?= $contrato[0]->id_contrato?>" method="post">
												<fieldset>
													<legend>Faixas</legend>
													<table id='list' class="table table-default table-striped table-bordered table-hover table-responsive dt-responsive">
														<thead>
															<tr>
																<th class="text-center">Licenças</th>
																<th class="text-right">Valor (R$)</th>
															</tr>
														</thead>
														<tbody>
														<?php foreach($this->valores as $chave=>$valor) { ?>
															<tr>
																<td>
																<input type="hidden" class="form-control"  name="id_lp_cliente-<?= $valor->id_lp_cliente;?>"  value="<?= (isset($valor->id_lp_cliente))?$valor->id_lp_cliente:null; ?>">
																<input type="hidden" class="form-control"  name="id_produto" id="id_produto" value="<?= $contrato[0]->id_produto ?>">
																<input type="hidden" class="form-control"  name="id_modulo" id="id_modulo" value="<?= $value->id ?>">
																<input type="hidden" class="form-control"  name="tipo_cobranca" id="tipo_cobranca" value="<?= $value->tipo_cobranca ?>">
																<input type="text" class="form-control" name="qtd_licencas-<?= $valor->id;?>" id="qtd_licencas" value="<?= $valor->qtd_licencas ?>"></td>
																<td><input type="text" class="form-control text-right"  name="valor_real-<?= $valor->id;?>" id="valor_real" value="<?= $valor->valor_real ?>"></td>
																<td><a href="/cobranca/delete/<?= $this->parametros[1]?>/<?= $valor->id ?>/" class="btn btn-warning"><i class="fa fa-trash"></i>Apagar</a></td>
															</tr>
														<?php } ?> <!-- End FOREACH -->
														</tbody>
													</table>
												</fieldset>
												<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Salvar Faixas</button>
											</form>
										</div>
										<!-- /Faixas -->
										<?php if($value->empacotavel) { ?>
										<?php $pacote = json_decode($this->modelo->getPacote($contrato[0]->id_contrato, $value->id)); ?>
										<!-- Pacote -->
										<div class="col-md-5">
											<form name="pacote" action="/cobranca/pacote/save/id/<?= $contrato[0]->id_contrato?>"  method="post" style="margin-left: 0;">
											<input type="hidden" name="id" value="<?= (isset($pacote))?$pacote[0]->id:null; ?>">
											<input type="hidden" name="id_modulos_tarifaveis" value="<?= $value->id; ?>">
												<fieldset>
													<legend>Pacote</legend>
													<div class="form-group">
														<input type="text" class="form-control" placeholder="Quantidade" name="qdt_garantido" value="<?= (isset($pacote))?$pacote[0]->qdt_garantido:null; ?>">
													</div>
													<div class="form-group">
														<input type="text"  class="form-control" placeholder="Valor" name="preco_pkt" id="preco_pkt" value="<?= (isset($pacote))?$pacote[0]->preco_pkt:null; ?>">
													</div>
													<div class="form-group">
														<select name="status" class="form-control select">
															<option value="">Situação</option>
															<option value="ativo" <?= (isset($pacote) && $pacote[0]->status == 'ativo')?'selected':null; ?>>ATIVO</option>
															<option value="inativo" <?= (isset($pacote) && $pacote[0]->status == 'inativo')?'selected':null; ?>>INATIVO</option>
															<option value="suspenso" <?= (isset($pacote) && $pacote[0]->status == 'suspenso')?'selected':null; ?>>SUSPENSO</option>
														</select>
													</div>
													<div class="form-group">
														<select name="flag" class="form-control select">
															<option value="SD" <?= (isset($pacote) && $pacote[0]->flag == 'SD')?'selected':null; ?>>SEM DESCONTO</option>
															<option value="CD" <?= (isset($pacote) && $pacote[0]->flag == 'CD')?'selected':null; ?>>COM DESCONTO</option>
														</select>
													</div>
												</fieldset>
												<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Salvar Pacote</button>
											</form>
										</div>
										<!-- /Pacote -->
										<?php } ?>
									</div>
									<!-- /KUMRAM -->
									<?php } else if($value->tipo_cobranca == 'VALOR-FIXO') {?>
									<!-- VALOR-FIXO -->
									<div class="row">
										<!-- Faixas -->
										<div class="col-md-7">
											<form name="metodo_cobranca" id="valor-fixo" action="/cobranca/processar/id/<?= $contrato[0]->id_contrato?>" method="post">
												<fieldset>
													<legend>Valor</legend>
													<?php foreach($this->valores as $chave=>$valor) { ?>
														<div class="form-group">
															<input type="hidden" class="form-control"  name="id_lp_cliente-<?= $valor->id_lp_cliente;?>"  value="<?= (isset($valor->id_lp_cliente))?$valor->id_lp_cliente:null; ?>">
															<input type="hidden" class="form-control"  name="id_produto" id="id_produto" value="<?= $contrato[0]->id_produto ?>">
															<input type="hidden" class="form-control"  name="id_modulo" id="id_modulo" value="<?= $value->id ?>">
															<input type="hidden" class="form-control"  name="tipo_cobranca" id="tipo_cobranca" value="<?= $value->tipo_cobranca ?>">
															<input type="text" class="form-control" placeholder="0.00" name="valor_total-<?= $chave; ?>-<?= $valor->id;?>" id="valor_total" value="<?= $valor->valor_total ?>">
															<a href="/cobranca/delete/<?= $this->parametros[1]?>/<?= $valor->id ?>/" class="btn btn-warning"><i class="fa fa-trash"></i>Apagar</a>
														</div>
													<?php } ?>
												</fieldset>
												<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Salvar Valor</button>
											</form>
										</div>
										<!-- /Faixas -->
										<?php if($value->empacotavel) { ?>
										<?php $pacote = json_decode($this->modelo->getPacote($contrato[0]->id_contrato, $value->id)); ?>
										<!-- Pacote -->
										<div class="col-md-5">
											<form name="pacote" action="/cobranca/pacote/save/id/<?= $contrato[0]->id_contrato?>"  method="post" style="margin-left: 0;">
											<input type="hidden" name="id" value="<?= (isset($pacote))?$pacote[0]->id:null; ?>">
											<input type="hidden" name="id_modulos_tarifaveis" value="<?= $value->id; ?>">
												<fieldset>
													<legend>Pacote</legend>
													<div class="form-group">
														<input type="text"  class="form-control" placeholder="Valor" name="preco_pkt" id="preco_pkt" value="<?= (isset($pacote))?$pacote[0]->preco_pkt:null; ?>">
													</div>
													<div class="form-group">
														<select name="status" class="form-control select">
															<option value="">Situação</option>
															<option value="ativo" <?= (isset($pacote) && $pacote[0]->status == 'ativo')?'selected':null; ?>>ATIVO</option>
															<option value="inativo" <?= (isset($pacote) && $pacote[0]->status == 'inativo')?'selected':null; ?>>INATIVO</option>
															<option value="suspenso" <?= (isset($pacote) && $pacote[0]->status == 'suspenso')?'selected':null; ?>>SUSPENSO</option>
														</select>
													</div>
												</fieldset>
												<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Salvar Pacote</button>
											</form>
										</div>
										<!-- /Pacote -->
										<?php } ?>
									</div>
									<!-- /VALOR-FIXO -->
									<?php } ?>
								<?php }?>
							</div>
						<?php }?>
					<?php }?>
					<a href="/contratos/lista/" class="btn btn-lg btn-success btn-block">Finalizar</a>
				</div>
			</div>
		</div>
		<!-- /.container-fluid -->
		<!-- /CONTENT -->
		<!-- END WRAPPER -->
		<?php include "template/end-menu-wrapper.html" ?>
		<!-- /END WRAPPER -->
		<!-- MODALS -->
		<!-- /MODALS -->
		<!-- INCLUDE DEFAULT SCRIPTS -->
		<?php include 'template/scripts.inc' ?>
		<!-- /INCLUDE DEFAULT SCRIPTS -->
		<!-- PAGE SCRIPTS -->
		<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
		<!-- /PAGE SCRIPTS -->
		<script>
			$().ready(function() {
				setTimeout(function () {
					$('#msg').hide(); // "foo" é o id do elemento que seja manipular.
				}, 2500); // O valor é representado em milisegundos.
			});
		</script>
	</body>
</html>
