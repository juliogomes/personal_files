<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "contratos";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Contratos</li>
		<?php
		if(!empty($this->parametros[1])){
			echo '<li>('.$contrato[0]->nome_fantasia.') '.$contrato[0]->razao_social.'</li>';
		}
		?>
		<li>Lista de preços</li>
		<?php
		if(!empty($contrato)){
			echo '<li>('.$contrato[0]->nome_produto.') '.$contrato[0]->descricao.'</li>';
		}
		?>
	</ol>
	<h4 class="page-title">
		<?php
		if(empty($this->parametros[4])){
			echo '<i class="fa fa-plus"></i> Nova Faixa';
		}
		else
		{
			echo '<i class="fa fa-edit"></i> Editar Faixa: '.$preco[0]->qtd_de.' - '.$preco[0]->qtd_ate;
		}
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-5">
				<form id="form" action="<?php echo HOME_URI.$this->nome_view.'/salvar/'.$this->parametros[1].'/'.$this->parametros[2].'/'.$this->parametros[3].'/'.$this->parametros[4]; ?>" class="" method="post">
					<fieldset>
						<legend>Valor incremental por mudança de faixa</legend>
						<div class="form-group">
							<label for="qtd_de">A cada xxx transações </label>
							<input type="hidden" name="tipo_cobranca" value="<?= $contrato[0]->tipo_cobranca; ?>">
							<input type="text" class="form-control mask-number" placeholder="0" value="<?php echo isset($preco[0])?funcValor($preco[0]->qtd_de, 'C', 0):null ?>" name="qtd_de" id="qtd_de"/>
						</div>
						<div class="form-group">
							<label for="valor_real">Valor</label>
							<input type="text" class="form-control mask-lp" placeholder="0.00" value="<?php echo isset($preco[0])?funcValor($preco[0]->valor_real, 'C', 6):null ?>" name="valor_real" id="valor_real"/>
						</div>
					</fieldset>
					<a href="/cobranca/detalhe/id/<?= $this->parametros[1]; ?>/<?= $this->parametros[2]?>/<?= $this->parametros[3]; ?>" class="btn btn-default"><i class="fa fa-times"></i> Cancelar</a>
					<button type="submit" class="btn btn-primary pull-right"><i class="fa fa-floppy-o"></i> Salvar</button>
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
		    jQuery('body').on('keydown', 'input, select, textarea', function(e) {
		        var self = $(this)
		                , form = self.parents('form:eq(0)')
		                , focusable
		                , next
		                ;
		        if (e.keyCode == 13) {
		            focusable = form.find('input,a,select,button,textarea').filter(':visible');
		            next = focusable.eq(focusable.index(this) + 1);
		            if (next.length) {
		                next.focus();
		            } else {
		                form.submit();
		            }
		            return false;
		        }
		    });
		});
		$(function() {
			//$('#valor_real').mask('##0.000', {reverse: true});
			//$('#qtd_de').mask('##', {reverse: true});
			//$('#qtd_ate').mask('##', {reverse: true});
			$form = $('#form');
			$form.formValidation({
				framework: 'bootstrap',
				excluded: ':disabled',
				icon: {
					valid: 'fa fa-check',
					invalid: 'fa fa-times',
					validating: 'fa fa-refresh'
				},
				addOns: {
					mandatoryIcon: {
						icon: 'fa fa-asterisk'
					}
				},
				live: 'enabled',
				fields: {
					'qtd_de':{
						validators:{
							// d
							// regexp:{
							// 	regexp: /^[0-9]{1,}$/,
							// 	message: 'Não válido'
							// }
						}
					},
					'qtd_ate':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							},
							// regexp:{
							// 	regexp: /^[0-9]{1,}$/,
							// 	message: 'Não válido'
							// }
						}
					},
					'valor_real':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
				}
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>