<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "cadastros";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Gestão</li>
		<li>Produtos</li>
		<?php
		if(!empty($this->parametros[1])){
			echo '<li>('.$produto->codigo.') '.$produto->nome.'</li>';
		}
		?>
		<?php
		if(!empty($this->parametros[2])){
			echo '<li>('.$modulo->codigo.') '.$modulo->descricao.'</li>';
		}
		?>
	</ol>
	<h4 class="page-title">
		<?php
		if(empty($this->parametros[3])){
			echo '<i class="fa fa-plus"></i> Nova Faixa';
		}
		else
		{
			echo '<i class="fa fa-edit"></i> Editar Faixa: '.$preco[0]->qtd_licencas.' - R$ '.$preco[0]->valor_real;
		}
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-5">
				<form id="form" action="<?php echo HOME_URI.$this->nome_view.'/produtos/modulo-faixa-save/'.$this->parametros[1].'/'.$this->parametros[2].'/'.$this->parametros[3]; ?>" class="" method="post">
					<input type="hidden" value="<?php echo $modulo->id ?>" name="id_modulos_tarifaveis" />
					<fieldset>
						<legend>Faixa de KUMRAM</legend>
						<div class="form-group">
							<label for="qtd_licencas">Licenças</label>
							<input type="text" class="form-control" placeholder="Quantidade" value="<?php echo isset($preco[0])?$preco[0]->qtd_licencas:null ?>" name="qtd_licencas" id="qtd_licencas"/>
						</div>
						<div class="form-group">
							<label for="valor_real">Valor</label>
							<input type="text" class="form-control" placeholder="0.00" value="<?php echo isset($preco[0])?$preco[0]->valor_real:null ?>" name="valor_real" id="valor_real"/>
						</div>
					</fieldset>
					<a href="/cadastros/produtos/modulo-detalhe/<?= $this->parametros[1]; ?>/<?= $this->parametros[2]; ?>" class="btn btn-default"><i class="fa fa-times"></i> Cancelar</a>
					<button type="submit" class="btn btn-primary pull-right"><i class="fa fa-floppy-o"></i> Salvar</button>
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$(function() {
			$('#valor_real').mask('##0.000', {reverse: true});
			$('#qtd_licencas').mask('##0', {reverse: true});
			$form = $('#form');
			$form.formValidation({
				framework: 'bootstrap',
				excluded: ':disabled',
				icon: {
					valid: 'fa fa-check',
					invalid: 'fa fa-times',
					validating: 'fa fa-refresh'
				},
				addOns: {
					mandatoryIcon: {
						icon: 'fa fa-asterisk'
					}
				},
				live: 'enabled',
				fields: {
					'qtd_licencas':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'valor_real':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
				}
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>