<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->

<head>
    <!-- INCLUDE DEFAULT HEAD CSS & METAS -->
    <?php include 'template/head-css.inc' ?>
    <!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
    <!-- PAGE STYLES -->
    <script type="text/javascript">
        var sidebarItem = "contratos";
    </script>
    <!-- /PAGE STYLES -->
</head>

<body>
    <!-- MENU + WRAPPER -->
    <?php include "template/menu-wrapper.php" ?>
    <!-- /MENU + WRAPPER -->
    <!-- HEADER -->
    <ol class="breadcrumb">
        <li>Tarifas.cmsw.com</li>
        <li>Contratos</li>
        <li> <?= '(' . $contrato[0]->nome_fantasia . ') ' . $contrato[0]->razao_social; ?> </li>
    </ol>
    <h4 class="page-title"><?= '(' . $contrato[0]->nome_fantasia . ') ' . $contrato[0]->razao_social; ?> - Lista de preços </h4>
    <!-- /HEADER -->
    <!-- CONTENT -->
    <div class="container-fluid">
        <div class="row" style="margin-bottom: 20px;">
            <div class="col-md-2">
                <form action="" method="POST" class="form-inline" role="form">
                    <div class="form-group">
                        <label class="sr-only" for="">label</label>
                        <select name="" id="input" class="form-control" required="required">
                            <option value=""></option>
                        </select>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
    <!-- /CONTENT -->
    <!-- END WRAPPER -->
    <?php include "template/end-menu-wrapper.html" ?>
    <!-- /END WRAPPER -->
    <!-- MODALS -->
    <!-- /MODALS -->
    <!-- INCLUDE DEFAULT SCRIPTS -->
    <?php include 'template/scripts.inc' ?>
    <?php include "template/modal_sistema.php" ?>
    <!-- /INCLUDE DEFAULT SCRIPTS -->
    <!-- PAGE SCRIPTS -->
    <script type="text/javascript">
        $(function() {
            oTable = $('#list').DataTable({
                info: false,
                responsive: true,
                autoFill: true,
                dom: "<'panel panel-default'" +
                    "tr" +
                    "<'panel-footer'" +
                    "<'row'<'col-sm-5'l><'col-sm-7'p>>" +
                    ">" +
                    ">",
                language: {
                    "url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
                },
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    ['10 rows', '25 rows', '50 rows', 'Show all']
                ],
                lengthChange: false,
                buttons: [{
                        extend: 'pageLength',
                        text: 'PAGINAS',
                        exportOptions: {
                            columns: [0, ':visible']
                        }
                    },
                    {
                        extend: 'copyHtml5',
                        text: 'COPY',
                        exportOptions: {
                            columns: [0, ':visible']
                        }
                    },
                    {
                        extend: 'excelHtml5',
                        text: 'EXCEL',
                        charset: 'utf-8',
                        bom: true,
                        exportOptions: {
                            //columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 11, 12, 13 ] // para quando quiser fixar as colunas a serem importadas
                            columns: ':visible'
                        }
                    },
                    {
                        extend: 'pdfHtml5',
                        text: 'PDF',
                        charset: 'utf-8',
                        bom: true,
                        exportOptions: {
                            columns: ':visible'
                            //columns: [ 0, 1, 2, 5 ]
                        }
                    },
                    {
                        extend: 'colvis',
                        text: 'COLUNAS',
                    },
                ]
            });
            oTable.buttons().container().appendTo('#list_wrapper .col-sm-6:eq(0)');
        });
    </script>
    <!-- /PAGE SCRIPTS -->
</body>

</html>