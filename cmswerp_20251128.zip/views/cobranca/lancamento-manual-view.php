<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "lancamento manual";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Contas a receber</li>
		<li>Lançamento</li>
	</ol>
	<h4 class="page-title">
		<?php
		echo '('.$records[0]->nome_fantasia.') '.$records[0]->razao_social;
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-5">
				<form name="save" action="/cobranca/savelancamento/" method="post">
					<fieldset>
						<legend>Dados do Produto</legend>
						<div class="form-group">
							<input type="hidden" name = "id_contrato" value="<?= $modulos[0]->id_contrato ?>" >
							<input type="hidden" name = "codigo_cliente" value="<?= $modulos[0]->codigo_cliente ?>" >
							<input type="hidden" name="id_produto" value ="<?= $modulos[0]->id_produto ?>" >
							<input type="hidden" name="codigo_produto" value ="<?= $modulos[0]->codigo_produto ?>" >
							<!-- <input type="hidden" name = "codigo_modulo" value="<?= $modulos[0]->codigo_modulo ?>" > -->
							<input type="hidden" name="id_modulo" value ="<?= $modulos[0]->id_modulo ?>" >
							<input type="hidden" name="tipo_tarifacao" value ="manual" >
							<label for="codigo_modulo">Produto</label>
							<select name="codigo_modulo" class="form-control">
								<?php
									if($modulos){
										foreach ($modulos as $key => $value) {
											echo "<option value='$value->codigo_modulo'>$value->descricao</option>";
										}
									}
								?>
							</select>
						<label for="data_tarifacao">Data tarifação</label>
						<input required type="text" name="data_tarifacao" class="form-control datepast">
						<div class="form-group">
							<label for="contador_trx">Quantidade</label>
							<input type="number" class="form-control" id="contador_trx" name="contador_trx">
						</div>
							<label for="contador_fin">Valor Total</label>
							<input type="text" class="form-control mask-money" name="contador_fin" >
						</div>
						<div class="form-group">
							<label for="obs">Descrição</label>
							<textarea rows="3" name="obs" id="obs" class="form-control" placeholder="Descrição"></textarea>
						</div>
					</fieldset>
					<a href="/cobranca/listarcontratos/" class="btn btn-default"><i class="fa fa-caret-left"></i> Voltar</a>
					<button type="submit" class="btn btn-info"><i class="fa fa-edit"></i> Inserir</button>
				</form>
			</div>
			<div class="col-sm-12 col-md-7">
				<h4 class="page-header">Modulos</h4>
				<table id='list' class="table table-default table-striped table-bordered table-hover table-responsive dt-responsive">
					<thead>
						<tr>
							<th width="90" class="text-center">Data</th>
							<th width="90" class="text-center">Modulo</th>
							<th width="120" class="text-center">Quantidade</th>
							<th width="120" class="text-center">Valor Total</th>
							<th width="90" class="text-center"></th>
						</tr>
					</thead>
					<tbody>
						<?php if (is_array($lancamentos)){ ?>
						<?php foreach($lancamentos as $key => $value) { ?>
						<tr>
							<td class="text-center"><?= convertDate($value->data_tarifacao); ?></td>
							<td class="text-center"><?= $value->codigo_modulo; ?></td>
							<td class="text-center"><?= number_format($value->qtd_transacoes, '2', ',', '.'); ?></td>
							<td class="text-center"><?= number_format($value->valor, '2', ',', '.'); ?></td>
							<td>
								<form name="save" action="/cobranca/deletelancamento/" method="post">
									<div class="pull-right">
										<input type="hidden" name = "id_contrato" value="<?= $modulos[0]->id_contrato ?>" >
										<input type="hidden" name ="id_rel_usuario" value ="<?= $value->id; ?>">
										<button type="submit" class="btn btn-warning btn-xs"><i class="fa fa-trash"></i> Excluir</button>
									</div>
								</form>
							</td>
						</tr>
						<?php } ?>
						<?php } else {?>
						<tr>
							<td colspan="100%" class="text-center">Sem Registros</td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
