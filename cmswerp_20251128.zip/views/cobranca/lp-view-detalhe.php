<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
	<head>
		<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
		<?php include 'template/head-css.inc' ?>
		<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
		<!-- PAGE STYLES -->
		<script type="text/javascript">
			var sidebarItem = "contratos";
		</script>
		<!-- /PAGE STYLES -->
	</head>
	<body>
		<!-- MENU + WRAPPER -->
		<?php include "template/menu-wrapper.php" ?>
		<!-- /MENU + WRAPPER -->
		<!-- HEADER -->
		<ol class="breadcrumb">
			<li>Tarifas.cmsw.com</li>
			<li>Contratos</li>
			<?php
				if(!empty($this->parametros[1])){
					echo '<li>('.$contrato[0]->nome_fantasia.') '.$contrato[0]->razao_social.'</li>';
				}
			?>
			<li>Lista de preços</li>
		</ol>
		<h4 class="page-title">
			<?php
				$empacotavel = false;
				foreach ($contrato as $key => $value) {
					if($value->id_modulo == $this->parametros[3] && $value->empacotavel == 1){
						$empacotavel = true;
					}
				}
				echo '('.$contrato[0]->codigo_produto.') '.$contrato[0]->nome_produto.' Modulo - '.$contrato[0]->nome_modulo.' - '.$contrato[0]->codigo_modulo;
			?>
		</h4>
		<!-- /HEADER -->
		<!-- CONTENT -->
		<div class="container-fluid">
			<div class="row">
				<!-- Pacotes -->
				<?php if(count($pacote) > 1){ ?>
					<div class="col-md-12">
						<b><h4>Erro ao carregar pacotes para este modulo contate o admim do sistema!!!</b></h4>
					</div>
				<?php }else{ ?>
					<?php if($contrato[0]->empacotavel == 1) { ?>
					<!-- Pacote -->
						<div class="col-md-12">
							<form name="frm_pacote" id="frm_pacote" action="#"  method="post" style="margin-left: 0;">
								<input type="hidden" name="id_pacote" id="id_pacote" value="<?= (isset($pacote))?$pacote[0]->id:null; ?>">
								<input type="hidden" name="id_modulos_tarifaveis" id="id_modulo" value="<?= $this->parametros[3]; ?>">
								<fieldset>
									<legend>Quantidade transações</legend>
									<div class="form-group">
									<input type="text"  class="form-control mask-number" placeholder="Quantidade" name="qdt_garantido" id="qdt_garantido" value="<?= (isset($pacote))?funcValor($pacote[0]->qdt_garantido, 'C', 0):0; ?>">
									</div>
									<legend>Valor do pacote</legend>
									<div class="form-group">
									<input type="text"  class="form-control mask-money" placeholder="Valor" name="preco_pkt" id="preco_pkt" value="<?= (isset($pacote))?funcValor($pacote[0]->preco_pkt, 'C'):'0,00'; ?>">
									</div>
										<div class="form-group">
											<select name="status_pacote" id="status_pacote" class="form-control select">
												<option value="inativo" <?= (isset($pacote) && strtoupper($pacote[0]->status) == 'INATIVO')?'selected':null; ?>>INATIVO</option>
												<option value="ativo" <?= (isset($pacote) && strtoupper($pacote[0]->status) == 'ATIVO')?'selected':null; ?>>ATIVO</option>
											</select>
										</div>
										<div class="form-group">
											<select name="flag" id="flag"  class="form-control select">
												<option value="SD" <?= (isset($pacote) && $pacote[0]->flag == 'SD')?'selected':null; ?>>SEM DESCONTO</option>
												<option value="CD" <?= (isset($pacote) && $pacote[0]->flag == 'CD')?'selected':null; ?>>COM DESCONTO</option>
											</select>
										</div>
								</fieldset>
								<!-- <div class="col-md-12"> -->
									<button type="button" class="btn btn-primary" id="bt_frm_pacote"><i class="fa fa-save"></i> Salvar Pacote</button>
									<button type="button" class="btn btn-success" id="bt_historico_pacote" value="<?=$this->parametros[1]."/".$this->parametros[3]?>"><i class="fa fa-history"></i> Histórico</button>
								<!-- </div> -->
							</form>
						</div>
					<!-- /Pacote -->
					<?php } ?>
				<?php } ?>
			</div>
			<div class="row">
				<div class="col-sm-12 col-md-12">
					<?php if ( $contrato[0]->tipo_cobranca != 'VALOR-FIXO') { ?>
						<?php if ( $contrato[0]->tipo_cobranca == 'VOLUMETRIA') { ?>
						<h4 class="page-header">Faixas de Volumetria</h4>
						<?php } elseif ( $contrato[0]->tipo_cobranca == 'FAIXA-FIXA') { ?>
						<h4 class="page-header">Cobrança fixa por faixa de uso</h4>
						<?php }elseif ( $contrato[0]->tipo_cobranca == 'INCREMENTAL-VOLUMETRIA') { ?>
						<h4 class="page-header">Cobrança mista incremental por faixa mais volumetria</h4>
						<?php }elseif ( $contrato[0]->tipo_cobranca == 'FIXO-INCREMENTAL') { ?>
						<h4 class="page-header">Cobrança incremental por mudança de faixa</h4>
						<?php } elseif ( $contrato[0]->tipo_cobranca == 'COBRANCA-ELETRONICA') { ?>
						<h4 class="page-header">Faixas de Cobranca Eletrônica</h4>
						<?php } elseif ( $contrato[0]->tipo_cobranca == 'LIQUIDADO-REAL') { ?>
						<h4 class="page-header">Faixas Liquidado</h4>
						<?php } elseif ( $contrato[0]->tipo_cobranca == 'LIQUIDADO-RELATIVO') { ?>
						<h4 class="page-header">Faixas Liquidado</h4>
						<?php } elseif ( $contrato[0]->tipo_cobranca == 'GOCHK') { ?>
						<h4 class="page-header">Faixas GoCHK</h4>
						<?php } elseif ( $contrato[0]->tipo_cobranca == 'KUMRAM') { ?>
						<h4 class="page-header">Faixas Kumram</h4>
						<?php } else { ?>Não Implementado [<?= $contrato[0]->tipo_cobranca ?>]<?php } ?>
					<a class="need_allow btn btn-success" href="/cobranca/valores/modulo-faixa-cadastro/<?= $contrato[0]->id_contrato; ?>/<?= $contrato[0]->id_produto ?>/<?= $this->parametros[3] ?>/0/"><i class="fa fa-plus"></i> Nova Faixa</a>
					<a href="/cobranca/ListaPrecoCliente/id/<?= $this->parametros[1];?>/order/1" class="btn btn-warning"><i class="fa fa-edit"></i> Voltar</a>
					
					<table id='list' class="table table-default table-striped table-bordered table-hover table-responsive dt-responsive">
						<thead>
							<?php if ( $contrato[0]->tipo_cobranca == 'LIQUIDADO-RELATIVO') { ?>
							<tr>
								<th colspan="2" class="text-center">Quantidade</th>
								<th colspan="2" class="text-center">Aging</th>
								<th colspan="2"></th>
							</tr>
							<?php } ?>
							<tr>
								<?php if ( $contrato[0]->tipo_cobranca == 'VOLUMETRIA') { ?>
								<th width="50" class="text-right">De</th>
								<th width="50" class="text-left">Até</th>
								<th width="50" class="text-right">Valor (R$)</th>
								<?php } elseif ( $contrato[0]->tipo_cobranca == 'FAIXA-FIXA') { ?>
								<th width="50" class="text-right">De</th>
								<th width="50" class="text-left">Até</th>
								<th width="50" class="text-right">Valor (R$)</th>
								<?php } elseif ( $contrato[0]->tipo_cobranca == 'FIXO-INCREMENTAL') { ?>
								<th width="50" class="text-left">A cada </th>
								<th colspan="2" width="50" class="text-left">Valor (R$)</th>
								<?php } elseif ( $contrato[0]->tipo_cobranca == 'INCREMENTAL-VOLUMETRIA') { ?>
								<th class="text-right" colspan="2">Faixas</th>
								<th class="text-right">Valor (R$)</th>
								<th class="text-right">Modalidade</th>
								<?php } elseif ( $contrato[0]->tipo_cobranca == 'LIQUIDADO-REAL') { ?>
								<th width="50" class="text-right">De</th>
								<th width="50" class="text-left">Até</th>
								<th width="50" class="text-right">Valor (R$)</th>
								<?php } elseif ( $contrato[0]->tipo_cobranca == 'LIQUIDADO-RELATIVO') { ?>
								<th width="50" class="text-right">De</th>
								<th width="50" class="text-left">Até</th>
								<th width="50" class="text-center">De</th>
								<th width="50" class="text-center">Até</th>
								<th width="50" class="text-right">Relativo (R$)</th>
								<?php } elseif ( $contrato[0]->tipo_cobranca == 'COBRANCA-ELETRONICA') { ?>
								<th width="50" class="text-right">De</th>
								<th width="50" class="text-left">Até</th>
								<th width="50" class="text-right">Percentual (%)</th>
								<?php } elseif ( $contrato[0]->tipo_cobranca == 'GOCHK') { ?>
								<th width="50" class="text-right">Real (R$)</th>
								<th width="50" class="text-right">Relativo (R$)</th>
								<?php } elseif ( $contrato[0]->tipo_cobranca == 'KUMRAM') { ?>
								<th width="50" class="text-center">Licenças</th>
								<th width="50" class="text-right">Valor (R$)</th>
								<?php } ?>
								<th width="150" class="text-center" >AÇÃO</th>
							</tr>
						</thead>
						<tbody>
							<?php if (is_array($lista_preco)){ ?>
							<?php foreach($lista_preco as $key => $value) { ?>
							<tr>
								<?php if ( $contrato[0]->tipo_cobranca == 'VOLUMETRIA') { ?>
								<td class="text-right"> <?= funcValor($value->qtd_de,'C',0) ?></td>
								<td class="text-left">	<?= funcValor($value->qtd_ate, 'C', 0) ?></td>
								<td class="text-right">R$ <?= funcValor($value->valor_real, 'C', 6) ?></td>
								<?php } elseif ( $contrato[0]->tipo_cobranca == 'FAIXA-FIXA') { ?>
								<td class="text-right"> <?= funcValor($value->qtd_de,'C',0) ?></td>
								<td class="text-left">	<?= funcValor($value->qtd_ate, 'C', 0) ?></td>
								<td class="text-right">R$ <?= funcValor($value->valor_real, 'C', 6) ?></td>
								
								<?php } elseif ( $contrato[0]->tipo_cobranca == 'INCREMENTAL-VOLUMETRIA' && $value->modalidade == 'FAIXA'){ ?>
								
								<td class="text-right" colspan="2"><?= funcValor($value->qtd_de,'C',0) ?> POR FAIXA</td>
								<td class="text-right">R$ <?= funcValor($value->valor_real, 'C', 6) ?></td>
								<td class="text-right">A CADA MUDANÇA DE  <?= $value->modalidade ?></td>
								
								<?php }elseif ( $contrato[0]->tipo_cobranca == 'INCREMENTAL-VOLUMETRIA') { ?>
								
								<td class="text-right" colspan="2">De: <?= funcValor($value->qtd_de,'C',0) ?> Até <?= funcValor($value->qtd_ate, 'C', 0) ?></td>
								<td class="text-right">R$ <?= funcValor($value->valor_real, 'C', 6) ?></td>
								<td class="text-right">POR <?= $value->modalidade ?></td>
								
								<?php } elseif ( $contrato[0]->tipo_cobranca == 'FIXO-INCREMENTAL') { ?>
								
								<td class="text-left"> <?= funcValor($value->qtd_de,'C',0) ?></td>
								<td colspan="2" class="text-left">R$ <?= funcValor($value->valor_real, 'C', 6) ?></td>
								
								<?php } elseif ( $contrato[0]->tipo_cobranca == 'LIQUIDADO-REAL') { ?>
								<td class="text-right"> <?= funcValor($value->qtd_de,'C',0) ?></td>
								<td class="text-left">	<?= funcValor($value->qtd_ate, 'C', 0) ?></td>
								<td class="text-right">R$ <?= funcValor($value->valor_real, 'C', 6) ?></td>
								<?php } elseif ( $contrato[0]->tipo_cobranca == 'LIQUIDADO-RELATIVO') { ?>
								<td class="text-right"> <?= funcValor($value->qtd_de,'C',0) ?></td>
								<td class="text-left">	<?= funcValor($value->qtd_ate, 'C', 0) ?></td>
								<td class="text-right"> <?= funcValor($value->idade_de,'C',0) ?></td>
								<td class="text-left">	<?= funcValor($value->idade_ate, 'C', 0) ?></td>
								<td class="text-right">R$ <?= funcValor($value->valor_relativo, 'C', 3) ?></td>
								<?php } elseif ( $contrato[0]->tipo_cobranca == 'COBRANCA-ELETRONICA') { ?>
								<td class="text-right"> <?= funcValor($value->qtd_de,'C',0) ?></td>
								<td class="text-left">	<?= funcValor($value->qtd_ate, 'C', 0) ?></td>
								<td class="text-right">R$ <?= funcValor($value->percentual, 'C', 3) ?></td>
								<?php } elseif ( $contrato[0]->tipo_cobranca == 'GOCHK') { ?>
								<td class="text-right">R$ <?= funcValor($value->valor_real, 'C') ?></td>
								<td class="text-right">R$ <?= funcValor($value->valor_relativo, 'C') ?></td>
								<?php } elseif ( $contrato[0]->tipo_cobranca == 'KUMRAM') { ?>
								<td class="text-right"> <?= funcValor($value->qtd_licencas,'C', 0) ?></td>
								<td class="text-right">R$ <?= funcValor($value->valor_real, 'C') ?></td>
								<?php } ?>
								<td class="text-center">
									<a href="/cobranca/valores/modulo-faixa-cadastro/<?=$contrato[0]->id_contrato;?>/<?= $value->id_produto ?>/<?= $value->id_modulo ?>/<?= $value->id_lp_cliente ?>" class="need_allow btn btn-info btn-xs"><i class="fa fa-edit"></i> Editar</a>
									<button value="<?=$value->id_lp_cliente?>" class="btn_modal_historico btn btn-success btn-xs"><i class="fa fa-history"></i> Histórico</button>
									<a href="/cobranca/delete/<?= $value->id_contrato ?>/<?= $value->id_produto ?>/<?= $value->id_modulo ?>/<?= $value->id_lp_cliente ?>" class="need_allow btn btn-warning btn-xs"><i class="fa fa-trash"></i> Apagar</a>
								</td>
							</tr>
							<?php } ?>
							<?php } else {?>
							<tr>
								<td colspan="100%" class="text-center">Sem Registros</td>
							</tr>
							<?php } ?>
						</tbody>
					</table>
					<?php } else { ?>
					<form style="margin-left: 0">
						<fieldset>
							<legend>Valor</legend>
							<div class="form-group">
								Nenhuma lista de preço encontrada
							</div>
							<?php if (is_array($modulo)){ ?>
							<a href="/cobranca/valores/modulo-faixa-cadastro/<?= $this->parametros[1];?>/<?= $this->parametros[2];?>/<?= $this->parametros[3];?>/<?= $modulo[0]->id_lp_cliente ?>" class="btn btn-info"><i class="fa fa-edit"></i> Editar</a>
							<?php } else { ?>
							<a class="need_allow btn btn-default" href="/cobranca/valores/modulo-faixa-cadastro/<?= $this->parametros[1];?>/<?= $this->parametros[2];?>/<?= $this->parametros[3];?>/0"><i class="fa fa-plus"></i> Adicionar Valor</a>
							<?php } ?>
							<a href="/cobranca/ListaPrecoCliente/id/<?= $this->parametros[1];?>/order/1" class="need_allow btn btn-warning"><i class="fa fa-edit"></i> Voltar</a>
						</fieldset>
					</form>
					<?php } ?>
				</div>
			</div>
		</div>
		<!-- /.container-fluid -->
		<!-- /CONTENT -->
		
		<!-- MODALS -->
		<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalTitle" aria-hidden="true">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title" id="myModalLabel">Resposta do servidor</h4>
					</div>
					<div class="modal-body">
						<strong></strong>
					</div>
				</div>
			</div>
		</div>
		<!-- /MODALS -->

		<!-- MODAL HISTORICO -->
		<div class="modal fade" id="modal_historico" tabindex="-1" role="dialog" aria-labelledby="Historico" aria-hidden="true">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close action_close_pendencia" data-dismiss="modal" >
							<span>x</span>
						</button>
						<h4 class="modal-title" id="myModalLabel">Histórico Lista de Preço</h4>					
					</div>
					<div class="modal-body">
						<div class="row">
							<div class="col-md-12">
								<div class="div_db" style='overflow-y:scroll'> 
									<table id='list_historico' class="table table-default table-striped table-bordered table-hover table-responsive dt-responsive">
										<thead>	
											<tr>						
												<th width="50" class="align-middle text-right" style="vertical-align:middle">De</th>
												<th width="50" class="align-middle text-left" style="vertical-align:middle">Até</th>
												<th width="50" class="align-middle text-center" style="vertical-align:middle">Valor Antigo</th>
												<th width="50" class="align-middle text-center" style="vertical-align:middle">Valor Atualizado</th>
												<th width="50" class="align-middle text-center" style="vertical-align:middle">Indice</th>
												<th width="30" class="align-middle text-center" style="vertical-align:middle">Percentual</th>
												<th width="100" class="align-middle text-center" style="vertical-align:middle">Ano / Mês</th>
												<th width="50" class="align-middle text-center" style="vertical-align:middle">Tipo Atualização</th>
												<th width="50" class="align-middle text-center" style="vertical-align:middle">Alterado em</th>
												<th width="50" class="align-middle text-center" style="vertical-align:middle">Alterado por</th>
											</tr>
										</thead>	
										<tbody id="historico_tbody">
											
										</tbody>
									</table>
								</div>	
							</div>
						</div>		
					</div>
					<div class="modal-footer">  
						<button type="button" class="btn btn-danger btn-xs fechar_modal" data-dismiss="modal"  style="font-weight:bold">
							FECHAR
						</button>                                                            
					</div>
				</div>
			</div>
		</div>
		<!-- END MODAL HISTORICO -->

		<!-- PACOTE HISTORICO -->
		<div class="modal fade" id="modal_pacote_historico" tabindex="-1" role="dialog" aria-labelledby="Historico" aria-hidden="true">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close action_close_pendencia" data-dismiss="modal" >
							<span>x</span>
						</button>
						<h4 class="modal-title" id="myModalLabel">Histórico Pacote</h4>
					</div>
					<div class="modal-body">
						<div class="row">
							<div class="col-md-12">
								<div class="div_db" style='overflow-y:scroll; max-height:470px;'>
									<table id='list_historico' class="table table-default table-striped table-bordered table-hover table-responsive dt-responsive">
										<thead>	
											<tr>						
												<th width="50" class="align-middle text-center" style="vertical-align:middle">Quantidade</th>
												<th width="50" class="align-middle text-center" style="vertical-align:middle">Quantidade Atual</th>
												<th width="50" class="align-middle text-center" style="vertical-align:middle">Preço Antigo</th>
												<th width="50" class="align-middle text-center" style="vertical-align:middle">Preço Atualizado</th>										
												<th width="30" class="align-middle text-center" style="vertical-align:middle">Percentual</th>
												<th width="100" class="align-middle text-center" style="vertical-align:middle">Ano / Mês</th>
												<th width="50" class="align-middle text-center" style="vertical-align:middle">Tipo Atualização</th>
												<th width="50" class="align-middle text-center" style="vertical-align:middle">Alterado em</th>
												<th width="50" class="align-middle text-center" style="vertical-align:middle">Alterado por</th>
											</tr>
										</thead>	
										<tbody id="pacote_historico_tbody">
											
										</tbody>
									</table>
								</div>	
							</div>
						</div>		
					</div>
					<div class="modal-footer">  
						<button type="button" class="btn btn-danger btn-xs fechar_modal" data-dismiss="modal"  style="font-weight:bold">
							FECHAR
						</button>                                                            
					</div>
				</div>
			</div>
		</div>
		<!-- END PACOTE HISTORICO -->

		<!-- END WRAPPER -->
		<?php include "template/end-menu-wrapper.html" ?>
		<!-- /END WRAPPER -->
		<!-- INCLUDE DEFAULT SCRIPTS -->
		<?php include 'template/scripts.inc' ?>
		<?php include "template/modal_sistema.php" ?>
		<!-- /INCLUDE DEFAULT SCRIPTS -->
		<!-- PAGE SCRIPTS -->
		<!-- Error Toaatr -->
		<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
		<!-- /Error Toaatr -->
		<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
		<script type="text/javascript">
			//$('#qdt_garantido').maskMoney({ thousands: '.', decimal: ',' });
			$('#bt_frm_pacote').click(function(){
				var $id_contrato   = '<?= $contrato[0]->id_contrato; ?>';
				var $id_produto    = '<?= $this->parametros[2]; ?>';
				var $id_modulo     = $('#id_modulo').val();
				var $id_pacote     = $('#id_pacote').val();
				var $preco_pkt     = $('#preco_pkt').val();
				var $qdt_garantido = $('#qdt_garantido').val();
				var $status        = $('#status_pacote').val();
				var $flag          = $('#flag').val();
				$.ajax({
					url: '/cobranca/pacote/save/',
					//datatype: 'json',
					//contentType: 'application/json; charset=utf-8',
					data: { 
						id_contrato:$id_contrato,
						id_produto:$id_produto,
						id_modulo:$id_modulo,
						id_pacote:$id_pacote,
						preco_pkt:$preco_pkt,
						qdt_garantido:$qdt_garantido,
						status:$status,
						flag:$flag
					},
					type: 'POST',
					success: function (data){
						var $retorno = JSON.parse(data);
						console.log($retorno);
						$('.modal-body').addClass('label-status');
						if($retorno.tipo == 'success'){
							$('#id_pacote').val($retorno.dados.id_pacote);
							$('.modal-body').addClass('alert alert-success');
						}else if($retorno.tipo == 'warning'){
							$('.modal-body').addClass('alert alert-warning');
						}else if($retorno.tipo == 'danger'){
							$('.modal-body').addClass('alert alert-danger');
						}
						$('.modal-body strong').html($retorno.mensagem);
						$("#myModal").modal("show");		        	
					},
					error: function (error){
						console.log(error);
					}				
				});
			});

			// AJAX MODAL LP HISTORICO
			$('.btn_modal_historico').click(function(){
				let value = $(this).val(); 
				let url   = "<?=HOME_URI.$this->nome_modulo.'/lpHistorico/'?>"+value;
				let html  = "";
				let tbody = document.getElementById('historico_tbody');
				$.ajax({
					url:url,
					type:"POST",
					beforeSend: function(){
						waitingDialog.show('PROCESSANDO...');
					}, 
					success: function(dados){
						waitingDialog.hide();
						retorno = JSON.parse(dados);				
						if(retorno.codigo == 0){
							let count  = Object.keys(retorno.output);
							for(i = 0; i < count.length; i++){
								html += 
									"<tr>"
										+ "<td class='text-right' style='vertical-align:middle;'>"+retorno.output[i].qtd_de+"</td>"
										+ "<td class='text-left' style='vertical-align:middle;'>"+retorno.output[i].qtd_ate+"</td>"
										+ "<td class='text-center' style='vertical-align:middle;color:red'><b>"+retorno.output[i].valor_antigo+"</b></td>"
										+ "<td class='text-center' style='vertical-align:middle;color:green'><b>"+retorno.output[i].valor_atualizado+"</b></td>"
										+ "<td class='text-center' style='vertical-align:middle;'>";
											if(retorno.output[i].indice != null){									
												html += retorno.output[i].indice;
											}
										html += "</td>"
										+ "<td class='text-center' style='vertical-align:middle;'>";
											if(retorno.output[i].percentual != null){
												html += retorno.output[i].percentual;
											}
										html += "</td>"
										+ "<td class='text-center' style='vertical-align:middle;'>";
											if(retorno.output[i].ano_reajuste != null && retorno.output[i].mes_reajuste != null ){
												html += retorno.output[i].ano_reajuste+"/"+retorno.output[i].mes_reajuste
											}else if(retorno.output[i].ano_reajuste != null){
												html += retorno.output[i].ano_reajuste;
											}else if(retorno.output[i].mes_reajuste != null){
												html += retorno.output[i].mes_reajuste;
											}									
										html += "</td>"
										+ "<td class='text-center' style='vertical-align:middle;'>";
											if(retorno.output[i].tipo_atualizacao != null){
												html += retorno.output[i].tipo_atualizacao;
											}
										html += "</td>"
										+ "<td class='text-center' style='vertical-align:middle;'>"+retorno.output[i].alterado_em+"</td>"
										+ "<td class='text-center' style='vertical-align:middle;'>"+retorno.output[i].nome+"</td>"
									+ "</tr>";
							}
							tbody.innerHTML = html;
							$("#modal_historico").modal('show');
						}else{
							$('#painel_error_msg').text(retorno.mensagem);
							$('#modal_erro_sistema').modal('show');
						}
					},
					erro: function(dados){
						$('#painel_error_msg').text("Erro reuisição AJAX");
						$('#modal_erro_sistema').modal('show');
					}
				})		
			});
		</script>
		<!-- /PAGE SCRIPTS -->
	</body>
</html>