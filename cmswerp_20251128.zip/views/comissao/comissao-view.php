


<!doctype html>
<html class="no-js" lang="">

<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc'; ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
    <!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "propostas";
	</script>
	<!-- /PAGE STYLES -->	  
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php"; ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Proposta</li>
	</ol>
	<h4 class="page-title">
		<?php		
			echo '<i class="fa fa-money"></i> PERFIL DE COMISSÃO';			
		?>        
	</h4>   
	<!-- /HEADER -->
        
	<!-- CONTENT -->
	<div class="container-fluid">        
        <form id="form" method="POST" action="" >            
            <div class="col-md-12">
                <hr>    
                <div class="col-md-7">                                   
                    <fieldset>
                        <legend>Comissão</legend>
                    </fieldset>   
                    <div class="col-md-12">                                                 
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="id_usuario">COMERCIAL RESPONSÁVEL:</label>
                                <select class='form-control select' id="id_usuario" name="id_usuario" >                            
                                    <option value="" selected>Selecione</option> 
                                    <?php if(isset($usuarios_sales) && is_array($usuarios_sales)){ ?>
                                        <?php foreach ($usuarios_sales as $key => $value){ ?>                                        
                                            <option value="<?=$value->id;?>" >
                                                <?=strtoupper($value->nome);?>
                                            </option>  
                                        <?php } ?> 
                                    <?php } ?>                                                                                                              
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="id_perfil" >TIPO DE PERFIL:</label>
                                <select class='form-control select' id="id_perfil" name="id_perfil" >                            
                                    <option value="" selected>Selecione</option>
                                    <?php if(isset($perfil_comissao) && is_array($perfil_comissao)){ ?>
                                        <?php foreach ($perfil_comissao as $key => $value) { ?>
                                            <option value="<?=$value->id?>"><?=strtoupper($value->nome);?></option>
                                        <?php } ?>
                                    <?php } ?>                                                                                                          
                                </select>
                            </div>
                        </div>                                           
                        <div class="col-md-12">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>VOLTAR:</label>
                                    <br>
                                    <a  class="btn btn-warning"  href="/comissao/index" style="width:100%;"> 
                                        <i class="fa fa-reply"></i> <strong> VOLTAR </strong> 
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-9">
                                <div class="form-group">
                                    <label>ADD COMERCIAL:</label>
                                    <button class="btn btn-success form-control" type="button" id="add_comissao">
                                        <b><i class="fa fa-plus"></i> ADD COMERCIAL</b>
                                    </button>
                                </div>
                            </div>  
                        </div>                   
                    </div>
                </div>
                <div class="col-md-5">               
                    <fieldset>
                        <legend>Comercial cadastrado</legend>
                    </fieldset> 
                    <table id='list' class="table table-default table-striped table-bordered table-hover display responsive nowrap"	width="100%">
                        <thead id="thead_comissao">                               
                            <tr role='row' class='cabecalho'>
                                <th width='80' class='text-left' style='font-size:9px;vertical-align:middle'>NOME </th>
                                <th width='80' class='text-left' style='font-size:9px;vertical-align:middle'>PERFIL</th>  
                                <th width='10' class='text-center' style='font-size:9px;vertical-align:middle'>DETALHE</th>   
                                <th width='10' class='text-center' style='font-size:9px;vertical-align:middle'>DELETAR</th>                                     	                                                                       
                            </tr>                               
                        </thead>						
                        <tbody id="body_comissao">
                            <?php if(isset($comercial_cadastrado) && !empty($comercial_cadastrado)){ ?>
                               
                                <?php foreach ($comercial_cadastrado as $key => $value) { ?>               
                                    <tr> 
                                        <?php if(isset($value->nome) && !empty($value->nome)){ ?>
                                            <?php $nome = explode(" ",strtoupper($value->nome)); ?>
                                        <?php } ?>
                                        <td style='text-align:left;vertical-align:middle;font-size:11px'><?=$nome[0]." ".$nome[1];?></td>
                                        <td style='text-align:left;vertical-align:middle;font-size:11px'><?=$value->nome_perfil;?></td>
                                        <td style='text-align:center;vertical-align:middle'>
                                            <button type='button' class='btn-xs btn-success detalhe_comissao' value='<?=$value->id_comissao?>'><i class='fa fa-plus'></i></button>
                                        </td>
                                        <td style='text-align:center;vertical-align:middle'>
                                            <button type='button' class='btn-xs btn-danger excluir_comissao' value='<?=$value->id_comissao."/".$value->nome."/".$value->nome_perfil;?>'><i class='fa fa-trash'></i></button>
                                        </td>
                                    </tr>
                                <?php } ?>                                        
                            <?php }else{ ?>
                                <tr> 
                                    <td colspan="4" style='text-align:left;vertical-align:middle;font-size:10px;text-align:center'>SEM COMERCIAL ADICIONADO</td>                                           
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>   
                </div>
            </div>
        </form>       
	</div>
    <!-- /CONTENT -->
    
  
    <!-- MODAL DETALHE COMISSÃO -->
    <div class="modal fade" id="modal_detalhe_comissao" tabindex="-1" role="dialog" >
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close action_close_jornada_dias" data-dismiss="modal" >
                        <span>x</span>
                    </button>
                    <fieldset>
                        <h2 style="text-align:center;font-size:16px; letter-spacing: 0.8em;">DETALHE COMISSÃO</h2>
                    </fieldset>
                </div>               
                <div class="modal-body">                       
                    <br>
                    <div class="container-fluid">
                        <div class="col-md-12" style="overflow:auto;">
                            <table class="table table-default table-striped table-bordered table-hover display responsive nowrap" width="100%">
                                <thead id="thead_comisao">
                                    <tr role="row" style="">                                 
                                        <th class="text-center" style="font-size:10px;vertical-align:middle;"> NOME </th>
                                        <th class="text-center" style="font-size:10px;vertical-align:middle;"> PERFIL </th>                                    
                                        <th class="text-center" style="font-size:10px;vertical-align:middle;"> OBJETO </th>                                       
                                        <th class="text-center" style="font-size:10px;vertical-align:middle;"> PERCENTUAL </th>                                                                                                                        
                                    </tr>
                                </thead>
                                <tbody id="tbody_comissao">
                                    
                                </tbody>                
                            </table>
                        </div>
                    </div>                                    
                </div>                
                <div class="modal-footer">					
                    <button type="button" class="btn btn-danger action_close_comissao" data-dismiss="modal" style="font-size:10px;font-weight:bold" >FECHAR</button>                    
                </div>
            </div>
        </div>
    </div>  
    <!-- END MODAL DETALHE CONTATO -->

    <!-- DELETE COMISSAO -->
    <div class="modal" id="modal_deletar_comissao" tabindex="-1" role="dialog" >
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" >
                        <span>X</span>
                    </button>
                    <fieldset>
                        <h2 style="text-align:center;font-size:14px; letter-spacing: 0.4em;">DELETAR COMERCIAL CADASTRADO</h2>
                    </fieldset>
                </div>
                <div class="modal-body">  
                    <br></br>                
                    <h5 style="">TEM CERTEZA QUE DESEJA DELETAR O USUÁRIO <b id="usuario"></b> COM O PERFIL <b id="perfil"></b> ? </h5>   
                    <br></br>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning action_close" data-dismiss="modal"  style="font-weight:bold;font-size:10px">FECHAR</button>
                    <button type="button" class="btn btn-danger" id="excluir_usuario_comissao" value="" style="font-weight:bold;font-size:10px" >DELETAR</button>
                </div>
            </div>
        </div> 
    </div>
    <!-- END DELETE COMISSAO -->
   
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html"; ?>
	<!-- /END WRAPPER -->
	
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc'; ?>
	<?php include "template/modal_sistema.php"; ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->	
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>    
    <script type="text/javascript" src="/libs/DataTables-1.10.13/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="/libs/DataTables-1.10.13/js/dataTables.bootstrap.min.js"></script>
    <!-- SCRIPT STATUS PROPOSTA -->   
    <script>
        $(document).ready(function(){
            $('#add_comissao').click(function(){
                url = "<?=HOME_URI.$this->nome_modulo.'/addComissao/';?>";
                form = $('#form').serialize();
                $.ajax({
                    url:url,
                    data:form,
                    type:"POST",
                    beforeSend: function(){
                        waitingDialog.show('PROCESSANDO..');
                    },
                    success: function(data){
                        waitingDialog.hide();                    
                        var retorno = JSON.parse(data);
                        if(retorno.codigo == 0){                        
                            $('#painel_success_msg').text(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');                        
                            $('#modal_sucesso_sistema').on('hidden.bs.modal',function(){                            
                                window.location.href = '/comissao/cadastro';                                                   
                            })                       
                        }else{  
                            $('#painel_error_msg').text(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');                        
                        }
                    },
                    erro: function(error){
                        $('#painel_error_msg').text("Erro AJAX");
                        $('#modal_erro_sistema').modal('show');
                    }
                });
            });

            $('.detalhe_comissao').click(function(e){
                id = $(this).val(); 
                detalheComissao(id);                        
            });

            $('.excluir_comissao').click(function(){
                value = $(this).val();
                parametros = value.split("/");
                $('#excluir_usuario_comissao').val(parametros[0]);
                $("#usuario").text(parametros[1].toUpperCase());
                $("#perfil").text(parametros[2].toUpperCase());  
                                         
                $('#modal_deletar_comissao').modal('show');
                $('#excluir_usuario_comissao').click(function(){                    
                    id = $(this).val();
                    excluirUsuarioComissao(id);
                });
            });

           

            $('#modal_detalhe_comissao').on('hidden.bs.modal', function () {                                                       
                $('.tr_class').remove();                                                                                                                                       
            })                       

            function detalheComissao(id){
                url = "<?=HOME_URI.$this->nome_modulo.'/detalheComissao/';?>"+id;                            
                $.ajax({
                    url:url,                             
                    type:"POST",
                    beforeSend: function(){
                        waitingDialog.show('PROCESSANDO..');
                    },
                    success: function(data){
                        waitingDialog.hide();                    
                        var retorno = JSON.parse(data);                                              
                        if(retorno.codigo == 0){                                             
                            let td = "";
                            td += "<tr class='tr_class' id='tr_"+retorno.output[0].id+"'>";
                                td += "<td style='text-align:center;vertical-align:middle;font-size:10px;'>";
                                    td += retorno.output[0].nome.toUpperCase();  
                                td += "</td>";
                                td += "<td style='text-align:center;vertical-align:middle;font-size:10px;'>";
                                    td += retorno.output[0].nome_perfil.toUpperCase();
                                td += "</td>";
                                td += "<td style='text-align:center;vertical-align:middle;font-size:10px;'>";
                                    td += retorno.output[0].objeto.toUpperCase();
                                td += "</td>";                                
                                td += "<td style='text-align:center;vertical-align:middle;font-size:10px;'>";  
                                    td += retorno.output[0].percentual;
                                td += "</td>"; 
                            td += "</tr>";
                            
                            $('.action_close_comissao').val(retorno.output[0].id);
                            $('#tbody_comissao').append(td);  
                            $('#modal_detalhe_comissao').modal('show');                                             
                        }else{  
                            $('#painel_error_msg').text(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');                        
                        }
                    },
                    erro: function(error){
                        $('#painel_error_msg').text(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }
                });
            }

            function excluirUsuarioComissao(id){
                url = "<?=HOME_URI.$this->nome_modulo.'/excluirUsuarioComissao/';?>"+id;                            
                $.ajax({
                    url:url,                             
                    type:"POST",
                    beforeSend: function(){
                        waitingDialog.show('PROCESSANDO..');
                    },
                    success: function(data){
                        waitingDialog.hide();                    
                        var retorno = JSON.parse(data);                        
                        if(retorno.codigo == 0){                                             
                            $('#painel_success_msg').text(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');                        
                            $('#modal_sucesso_sistema').on('hidden.bs.modal', function () {                                                       
                                window.location.href = '/comissao/cadastro';                                                                                                                                         
                            });                                                                    
                        }else{  
                            $('#painel_error_msg').text(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');                        
                        }
                    },
                    erro: function(error){
                        $('#painel_error_msg').text(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }
                });
            }
            
            <?php if(isset($comercial_cadastrado) && !empty($comercial_cadastrado)){ ?>
               
                oTable = $('#list').DataTable({	
                    "order": [
                        [ 0, "asc" ]
                    ],
                    info: false,  
                    "iDisplayLength": 8,
                    language: {
                        "url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
                    },                            
                    lengthMenu: [
                        [ 5, 25, 50, -1 ],
                        [ '5 linhas', '25 linhas', '50 linhas', 'Tudo' ],
                    ],
                    lengthMenu: true,

                     dom: 'Bfrtip',

                    buttons: [
				        {
                            extend: 'pageLength',
                            text: 'PAGINAS',
                        }
                    ]              
                  
                });

            <?php } ?>

        });
    </script>