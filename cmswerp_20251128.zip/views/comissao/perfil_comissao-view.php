<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "home";
	</script>
	<!-- /PAGE STYLES -->

	
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Cadastro</li>
        <li>Comissão</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> Comissão</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<form name="form_contrato" >
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">

				</div>
			</div>
		</div>
	</form>
    <div class="col-md-12">        
		<form class="form-inline page-toolbar" id="comissao" name="comissao" method="post" action="/comissao/perfil">
            <div class="pull-left" style="margin-right:1%">
                <a  class="btn btn-warning"  href="/comissao/index"> 
                    <i class="fa fa-reply"></i> <strong> VOLTAR </strong> 
                </a>
            </div>   	
            <div class="pull-left" style="margin-right:1%">  
                <div class="form-group" >
                    <button type="button" class="btn btn-success" id="add_comissao"><b>ADICIONAR COMISSÃO <i class="fa fa-plus"></i></b></button>
                </div>
            </div>	
            <div class="pull-left" style="margin-right:5%;">  
                <div class="form-group" >
                    <button type="button" class="btn btn-danger" id="deletar_comissao" style="width:150px" ><b>DELETAR <i class="fa fa-ban"></i></b></button>
                </div>
            </div>		
            <div class="pull-left">                  
				<div class="form-group">
					<div class="input-group">
                        <div class="input-group-addon"><b style="font-size:11px"> TIPO DE PERFIL: </b></div>
                        <select class="search form-control" id="id_perfil" name="id_perfil" style="width:300px" >  
                            <?php if(isset($comissao_perfil     ) && is_array($comissao_perfil  )){ ?>                          
                                <option value="" selected>Selecione</option>
                                <?php if(isset($comissao_perfil     ) && is_array($comissao_perfil  )){ ?>
                                    <?php foreach ($comissao_perfil      as $key => $value) { ?>
                                        <option value="<?=$value->id?>" <?=($value->id == $id_perfil)?"selected":null;?>>
                                            <?=strtoupper($value->nome);?>
                                        </option>
                                    <?php } ?>
                                <?php } ?>     
                            <?php }else{ ?>           
                                <option value="" selected>Sem perfil</option>
                            <?php } ?>
                        </select>
					</div>	
				</div>				
				<div class="btn-group" role="group">
					<button type="submit" class="btn btn-primary" style="margin-left:5%"><b style="font-size:12px"><i class="fa fa"></i>PESQUISAR</b></button>
				</div>
			</div>
		</form>		
    </div>
	<div class="col-md-12">
		<hr>
	</div>
	<div class="container-fluid">  
		<div class="col-md-12">
			<fieldset>
				<legend style="text-align:center;font-size:16px; letter-spacing: 0.8em;">COMISSÕES</lengend>
			</fieldset>
		</div>
		<div class="col-md-12">		
            <table id='table_diario' class="table table-responsive table-default table-striped table-bordered table-hover display responsive nowrap">
                <thead>
                    <tr>  
                        <th style="text-align:center;vertical-align:middle"></th>
                        <th style="text-align:center;vertical-align:middle">PERFIL</th>                                
                        <th style="text-align:center;vertical-align:middle">OBJETO</th>            
                        <th style="text-align:center;vertical-align:middle">TIPO VALOR</th>  
                        <th style="text-align:center;vertical-align:middle">COMISSÃO</th>                                                                                                                                                               
                    </tr>
                </thead>
                <tbody>
                    <?php if(is_array($comissao) && !empty($comissao)){ ?>                               
                        <?php foreach ($comissao as $key => $value) { ?>
                            <tr> 
                                <td style="text-align:center;vertical-align:middle"> <input class='form-check-input check_comissao' type='radio' name="check_comissao[]" value="<?=$value->id?>" ></td>    
                                <td style="text-align:center;vertical-align:middle"><?=strtoupper($value->nome);?></td>                                                                                  
                                <td style="text-align:center;vertical-align:middle"><?=strtoupper($value->objeto);?></td>                           
                                <td style="text-align:center;vertical-align:middle">PERCENTUAL</td>                                                                                  
                                <td style="text-align:center;vertical-align:middle"><?=($value->percentual)?strtoupper($value->percentual):"<i class='fa fa-ban'></i>";?></td>                                                                                                                             
                            </tr>
                        <?php } ?>                                                                                                                
                    <?php }else{ ?>
                            <tr>                                            
                                <td colspan="8" style="text-align:center">SEM COMISSÃO CADASTRADA</td>                                                
                            </tr>
                    <?php } ?>
                </tbody>
            </table>		
		</div>		
	</div>
			
	<!-- MODAL ADICIONA COMISSÃO -->
    <div class="modal fade" id="modal_comissao" tabindex="-1" role="dialog" >
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close action_close_jornada_dias" data-dismiss="modal" >
                        <span>x</span>
                    </button>
                    <fieldset>
                        <h2 style="text-align:center;font-size:16px; letter-spacing: 0.8em;">CADASTRAR COMISSÃO</h2>
                    </fieldset>
                </div>               
                <div class="modal-body">                       
                    <br>
                    <form id="form_add_comissao" name="form_add_comissao" method="post">
                        <div class="container-fluid">
                            <div class="col-md-12">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="nome" >PERFIL COMERCIAL:</label>
                                        <input type="text" class="form-control" id="nome" name="nome" placeholder="Nome perfil comercial" />
                                    </div>
                                </div>                                
                            </div>
                            <div class="col-md-12">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="objeto" >OBJETO DE COMISSÃO: </label>
                                        <select class='form-control select' id="objeto" name="objeto">                                         
                                            <option value="contrato" selected>CONTRATO</option>                                          
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="valor_comissao" >PERCENTUAL DE COMISSÃO:</label>
                                        <input type="text" class="form-control" name="valor_comissao" id="valor_comissao" placeholder="Percentual"/>
                                    </div>  
                                </div>                                 
                            </div>                        
                        </div>      
                        <br>   
                    </form>
                </div>                
                <div class="modal-footer">	                    
                    <button type="button" class="btn btn-danger action_close" data-dismiss="modal" style="font-size:10px;font-weight:bold" >FECHAR</button>  
                    <button type="button" class="btn btn-success" style="font-size:10px;font-weight:bold" id="adicionar_comissao" >ADICIONAR</button>                  
                </div>
            </div>
        </div>
	</div>  
    <!-- END MODAL ADICIONA COMISSÃO -->	

	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc'; ?>
	<?php include "template/modal_sistema.php"; ?>
	<?php include "template/end-menu-wrapper.html"; ?>
    <script type="text/javascript" src="/assets/js/form-behaviors.js"></script>

	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script>
        
        $(document).ready(function(){

            $('#add_comissao').click(function(){
                $('#modal_comissao').modal('show');
            });

            $('#adicionar_comissao').click(function(){
                url = "<?=HOME_URI.$this->nome_modulo.'/adicionaComissao/'?>";
                form = $('#form_add_comissao').serialize();   
                $.ajax({
                    url:url,  
                    data:form,             
                    type:"POST",
                    beforeSend: function(){
                        waitingDialog.show('PROCESSANDO..');
                    },
                    success: function(data){
                        waitingDialog.hide();                    
                        var retorno = JSON.parse(data);                        
                        if(retorno.codigo == 0){                        
                            $('#painel_success_msg').text(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');                        
                            $('#modal_sucesso_sistema').on('hidden.bs.modal', function () {                                                       
                                window.location.href = '/comissao/perfil';                                                                                                                                         
                            })                       
                        }else{  
                            $('#painel_error_msg').text(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');                        
                        }
                    },
                    erro: function(error){
                        $('#painel_error_msg').text(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }
                });
            });

            $('#deletar_comissao').click(function(){''
                checados = [];
                $.each($("input[name='check_comissao[]']:checked"), function(){
                    checados.push($(this).val());
                });
                if(checados.length == 0){ 
                    $('#painel_error_msg').text('Selecione uma comissão');
                    $('#modal_erro_sistema').modal('show');
                }else{                   
                    url = "<?=HOME_URI.$this->nome_modulo.'/deletarComissao/'?>"+checados;                  
                    $.ajax({
                        url:url,                           
                        type:"POST",
                        beforeSend: function(){
                            waitingDialog.show('PROCESSANDO..');
                        },
                        success: function(data){
                            waitingDialog.hide();                    
                            var retorno = JSON.parse(data);                        
                            if(retorno.codigo == 0){                        
                                $('#painel_success_msg').text(retorno.mensagem);
                                $('#modal_sucesso_sistema').modal('show');                        
                                $('#modal_sucesso_sistema').on('hidden.bs.modal', function () {                                                       
                                    window.location.href = '/comissao/perfil';                                                                                                                                         
                                });                       
                            }else{  
                                $('#painel_error_msg').text(retorno.mensagem);
                                $('#modal_erro_sistema').modal('show');                        
                            }
                        },
                        erro: function(error){
                            $('#painel_error_msg').text(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    });
                }               
            });
            
            contador = 0; 
            $('#objeto_regra').change(function(){    
                value = $(this).val();          
                if(value == "status"){  
                    if(contador != 0){
                        $("#comparador option").filter(":selected").remove();  
                    }              
                    $("#comparador").append('<option value="ativo" selected> ATIVO </option>');  
                    $('#div_valor_comparador').attr('style', 'display:none');               
                }else if(value != ""){    
                    if(contador != 0){
                        $("#comparador option").filter(":selected").remove();
                    }              
                    $("#comparador").append('<option value="maior" selected> MAIOR </option>');                 
                    $('#div_valor_comparador').attr('style', 'display:block');               
                }            
                contador++;   
            });
        }); 

	</script>
	<!-- /PAGE SCRIPTS -->
	

</body>
</html>
