<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "cadastro-comissoes";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Cadastros</li>
		<li>Comissoes</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i>Comissoes</h4>
	<div class="container-fluid">
		<form class="form" method="post" action="/comissoes/comissionadoSave/id/<?= $this->parametros[1]; ?>">
			<div class="row">
				<div class="col-md-12">
                    <label for="nome">Nome</label>
                    <input name="nome" id="nome" class="form-control" value="<?= $comissionado[0]->nome; ?>"/>

                    <label for="email">Email</label>
                    <input name="email" id="email" class="form-control" value="<?= $comissionado[0]->email; ?>"/>

                    <label for="cargo">Cargo</label>
                    <select name="cargo" id="cargo" class="form-control">
						<option value="vendedor" <?= ($comissionado[0]->cargo == 'aux_venda_mrrs')?'selected':null; ?> >Auxiliar de Vendas (MRRS)</option>
						<option value="vendedor" <?= ($comissionado[0]->cargo == 'aux_venda_sdr')?'selected':null; ?> >Auxiliar de Vendas (SDR)</option>
                        <option value="diretor" <?= ($comissionado[0]->cargo == 'diretor')?'selected':null; ?> >DIRETOR</option>
                        <option value="vendedor" <?= ($comissionado[0]->cargo == 'vendedor')?'selected':null; ?> >VENDEDOR</option>
					</select>

                    <label for="departamento">Departamento</label>
                    <input name="departamento" id="departamento" class="form-control" value="<?= $comissionado[0]->departamento; ?>"/>

                    <label for="winrate">Winrate</label>
                    <input name="winrate" id="winrate" class="form-control" value="1,00"/>

                    <label for="data_admissao">Admissão</label>
                    <input name="data_admissao" id="data_admissao" class="form-control datepast2" value="<?= convertDate($comissionado[0]->data_admissao); ?>"/>

                    <label for="data_demissao">Demissão</label>
                    <input name="data_demissao" id="data_demissao" class="form-control datepast2" value="<?= convertDate($comissionado[0]->data_demissao); ?>"/>

                    <label for="status">Status</label>
					<select name="status" id="status" class="form-control">
						<option value="A" <?= ($comissionado[0]->status == 'A')?'selected':null; ?> >ATIVO</option>
						<option value="I" <?= ($comissionado[0]->status == 'I')?'selected':null; ?> >INATIVO</option>
					</select>
				</div>
				
            </div>
            <div class="row">
				<div class="col-md-12">
                    <button type="submit" class="form-control btn btn-success" ><i class="fa fa-save"> GRAVAR</i></button>
                    <button type="submit" class="form-control btn btn-warning" ><i class="fa fa-angle-double-left"> VOLTAR</i></button>
                </div>
            </div>
            <div class="row">
				<div class="col-md-12">
                    <p><fieldset><legend>CONTRATOS PARA ESSE COMERCIAL</legend></fieldset></p>
                    <table class="table">
                        <thead>
                            <tr>
                                <td><b>CLIENTE</b></td>
                                <td><b>COMISSAO</b></td>
                                <td><b>VALIDO ATÉ</b></td>
								<td></td>
                            </tr>
                        </thead>
                    <?php
                        if(isset($contratos) && !empty($contratos)){
                            foreach ($contratos as $key => $value) {
                    ?>
                            <tr>
                                <td><?= $value->nome_fantasia; ?></td>
                                <td><?= number_format($value->valor_comissao,'2',',','.'); ?> %</td>
                                <td><?= convertDate($value->valida_ate); ?></td>
								<td><a href="/comissoes/editar/id/<?= $value->id_comissao; ?>" class="form-control btn btn-warning"><i class="fa fa-gg"></i> </a></td>
                            </tr>
                    <?php
                            }
                        }
                    ?>
                    </table>
                </div>
            </div>
		</form>
	</div>

	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<!-- <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.0/themes/smoothness/jquery-ui.css" /> -->
	<script>
		$(function(){
			$('.date').mask('00/00/0000', {
				onComplete: function(value, event, field) {
					oTable
					.columns( 5 )
					.search( value )
					.draw();
				}
			}).datepicker({
				format: "dd/mm/yyyy",
				clearBtn: true,
				language: "pt-BR",
				autoclose: true,
				todayBtn: "linked",
				//todayHighlight: true
			}).change(function(){
				// $('#filter').attr('action', '/despesas/listar/').submit();
			});
		});
		
	</script>
	<!-- PAGE SCRIPTS -->
</body>
</html>