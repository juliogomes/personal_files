<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "comissoes";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Contas a pagar</li>
		<li>Comissões</li>
	</ol>
	<h4 class="page-title">
		<?php
		if(empty($this->parametros[1])){
			echo '<i class="fa fa-plus"></i> Novo Diretor';
		}
		else
		{
			echo '<i class="fa fa-edit"></i> Editar Diretor';
		}
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-6">
				<form id="form" action="<?php echo HOME_URI.$this->module.'/save/'.$this->parametros[0].'/'.$this->parametros[1]; ?>?debug" class="" method="post">
					<fieldset>
						<legend>Dados do Vendedor</legend>
						<input type="hidden" value="diretor" name="cargo"/>
						<div class="form-group">
							<label class="control-label" for="nome">GERENTE COMERCIAL</label>
							<select name="id_diretor" class="form-control">
								<?php
								foreach($this->diretores as $key=>$value){
									if($comissao[0]->id_diretor == $value->id){
									?>
									<option value="<?= $value->id?>" selected><?= $value->nome ?></option>
								<?php	
									}else{
								?>
									<option value="<?= $value->id?>"><?= $value->nome ?></option>
								<?php	
									}
								}
								?>
							</select>
						</div>

						<div class="form-group">
							<label class="control-label" for="percentual_comissao">Percentual de comissões:</label>
							<input type="hidden" name="cargo" id="cargo" value = "diretor"/>
							<input type="text" class="form-control mask-money" placeholder="00.00%" name="percentual_comissao" id="percentual_comissao" value="<?php echo isset($comissao)?number_format($comissao[0]->percentual_comissao,'2',',','.'):null ?>" required/>
						</div>
						<div class="form-group">
							<label class="control-label" for="comissao_devida_ate">Comissões devidas até:</label>
							<input type="text"  class="form-control datepast" placeholder="Dia/Mês/Ano" name="comissao_devida_ate" id="comissao_devida_ate" value="<?php echo isset($comissao)?convertDate($comissao[0]->comissao_devida_ate):null ?>" required/>
						</div>
						<div class="form-group">
							<label class="control-label" for="tipo_comissao">Tipo de comissão</label>
							<select name="tipo_comissao" id="tipo_comissao" class="form-control">
								<option value="comum" <?= (isset($comissao) && $comissao[0]->tipo_comissao == 'comum')?'selected':null?> >Comum</option>
								<option value="incremental" <?= (isset($comissao) && $comissao[0]->tipo_comissao == 'incremental')?'selected':null?>>Incremental</option>
							</select>
						</div>
						<div class="form-group">
							<label class="control-label" for="status">Status</label>
							<select name="status" id="status" class="form-control">
								<option value="ativo" <?= (isset($comissao) && $comissao[0]->tipo_comissao == 'ativo')?'selected':null?>>Ativo</option>
								<option value="inativo" <?= (isset($comissao) && $comissao[0]->tipo_comissao == 'inativo')?'selected':null?>>Inativo</option>
							</select>
						</div>
					</fieldset>
					<a href="/comissoes/detalhe/id/<?= $this->parametros[0] ?>/" class="btn btn-default"><i class="fa fa-times"></i> Cancelar</a>
					<button type="submit" class="btn btn-primary pull-right"><i class="fa fa-floppy-o"></i> Salvar</button>
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$(function() {
			$form = $('#form');
			$form.formValidation({
				framework: 'bootstrap',
				excluded: ':disabled',
				icon: {
					valid: 'fa fa-check',
					invalid: 'fa fa-times',
					validating: 'fa fa-refresh'
				},
				addOns: {
					mandatoryIcon: {
						icon: 'fa fa-asterisk'
					}
				},
				live: 'enabled',
				fields: {
					'nome':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'email':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							},
							regexp: {
								regexp: /^([\w\.\-_]+)?\w+@[\w-_]+(\.\w+){1,}$/i,
								message: 'Email mão é válido'
							}
						}
					},
					'winrate':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					}
				}
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>