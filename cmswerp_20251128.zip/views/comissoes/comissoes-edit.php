<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "cadastro-comissoes";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Cadastros</li>
		<li>Comissoes</li>
		<li><?= ($this->parametros[1])?$comissionado[0]->nome:null; ?></li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i>Comissoes <i class="fa fa-caret-right"></i><?= ($this->parametros[1])?$comissionado[0]->nome:null; ?></h4>
	<div class="container-fluid">
		<form class="form" method="post" action="/comissoes/save/id/<?= $comissao[0]->id_comissao; ?>">
			<div class="row">
				<div class="col-md-12">
					<label for="tipo_comissao">Tipo da comissão</label>
					<select name="tipo_comissao" id="tipo_comissao" class="form-control">
						<option value="comum" <?= ($comissao[0]->tipo_comissao == 'comum')?'selected':null; ?> >Comun</option>
						<option value="incremental" <?= ($comissao[0]->tipo_comissao == 'incremental')?'selected':null; ?>>Incremental</option>
						<option value="upselling" <?= ($comissao[0]->tipo_comissao == 'upselling')?'selected':null; ?>>Upselling</option>
					</select>

					<label for="id_comercial">Favorecido</label>
					<select name="id_comercial" id="id_comercial" class="form-control">
						<?php foreach ($comissionado as $key => $value) { ?>
							<option value="<?= $value->id; ?>"><?= $value->nome; ?></option>
						<?php } ?>
					</select>

					<label for="id_contrato">Contrato</label>
					<select name="id_contrato" id="id_contrato" class="form-control">
						<?php foreach ($contratos as $key => $value) { ?>
							<option value="<?= $value->id_contrato; ?>"><?= $value->razao_social; ?> - <?= $value->codigo_produto; ?></option>
						<?php } ?>
					</select>

					<label for="incluir_adm">Incluir contratos ADM</label>
					<select name="incluir_adm" id="incluir_adm" class="form-control">
						<option value="S" <?= ($comissao[0]->incluir_adm == 'S')?'selected':null; ?> >SIM</option>
						<option value="N" <?= ($comissao[0]->incluir_adm == 'N')?'selected':null; ?> >NÃO</option>
					</select>
					
					<label for="valida_de">Comissao valida de:</label>
					<input name="valida_de" id="valida_de" class="form-control datepast2" placeholder="Dia/Mês/Ano" value="<?= convertDate($comissao[0]->valida_de); ?>" />

					<label for="valida_ate">Comissao valida até:</label>
					<input name="valida_ate" id="valida_ate" class="form-control datepast2" placeholder="Dia/Mês/Ano" value="<?= convertDate($comissao[0]->valida_ate); ?>" />

					<label for="valor_comissao_em">Comissao_em</label>
					<select name="valor_comissao_em" id="valor_comissao_em" class="form-control">
						<option value="percentual" <?= ($comissao[0]->valor_comissao_em == 'percentual')?'selected':null; ?> >Porcentagem</option>
						<option value="dinheiro" <?= ($comissao[0]->valor_comissao_em == 'dinheiro')?'selected':null; ?> >Dinheiro</option>
					</select>

					<label for="valor_comissao">Valor da comissao:</label>
					<input name="valor_comissao" id="valor_comissao" class="form-control mask-money"  value="<?= number_format($comissao[0]->valor_comissao ,'2',',','.'); ?>" />
					<!-- 
					<label for="meta_bonus">Meta Bonus:</label>
					<input name="meta_bonus" id="meta_bonus" class="form-control"  value="<?= number_format($comissao[0]->meta_bonus ,'2',',','.'); ?>" />
					
				    <label for="tipo_parametro_bonus">Parametros para bonus</label>
					<select name="tipo_parametro_bonus" id="tipo_parametro_bonus" class="form-control">
						<option value="total_liquido_maior" <?= ($comissao[0]->tipo_parametro_bonus == 'total_liquido_maior')?'selected':null; ?> >Total valor liquido maior que</option>
					</select>	

					<label for="periodo_apuracao">Periodo apuração</label>
					<select name="periodo_apuracao" id="periodo_apuracao" class="form-control">
						<option value="anual" <?= ($comissao[0]->periodo_apuracao == 'anual')?'selected':null; ?> >Anual</option>
						<option value="trimestral" <?= ($comissao[0]->periodo_apuracao == 'trimestral')?'selected':null; ?>>Trimestral</option>
						<option value="mensal" <?= ($comissao[0]->periodo_apuracao == 'mensal')?'selected':null; ?> >Mensal</option>
					</select>	

					<label for="valor_parametro_bonus">Valor do parametros para bonus </label>
					<input name="valor_parametro_bonus" id="valor_parametro_bonus" class="form-control" value="<?= number_format($comissao[0]->valor_parametro_bonus ,'2',',','.'); ?>" />

					<label for="meta_valida_de">Meta valida de:</label>
					<input name="meta_valida_de" id="meta_valida_de" class="form-control" value="<?= number_format($comissao[0]->meta_valida_de ,'2',',','.'); ?>" />

					<label for="meta_valida_ate">Meta valida até:</label>
					<input name="meta_valida_ate" id="meta_valida_ate" class="form-control" value="<?= number_format($comissao[0]->meta_valida_ate ,'2',',','.'); ?>" />

					<label for="meta_em">Meta em:</label>
					<select name="meta_em" id="meta_em" class="form-control">
						<option value="percentual" <?= ($comissao[0]->meta_em == 'percentual')?'selected':null; ?> >Porcentagem</option>
						<option value="dinheiro" <?= ($comissao[0]->meta_em == 'dinheiro')?'selected':null; ?> >Dinheiro</option>
					</select>

					<label for="valor_meta">Valor da meta:</label>
					<input name="valor_meta" id="valor_meta" class="form-control" value="<?= number_format($comissao[0]->valor_meta ,'2',',','.'); ?>" /> -->

					<label for="status">Status:</label>
					<select name="status" id="status" class="form-control">
						<option value="inativo" <?= ($comissao[0]->status_comissao == 'inativo')?'selected':null;?> >INATIVO</option>
						<option value="ativo" <?= ($comissao[0]->status_comissao == 'ativo')?'selected':null;?> > ATIVO</option>
					</select>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
                    <button type="submit" class="form-control btn btn-success" ><i class="fa fa-save"> GRAVAR</i></button>
                    <button type="submit" class="form-control btn btn-warning" ><i class="fa fa-angle-double-left"> VOLTAR</i></button>
                </div>
            </div>
		</form>
	</div>

	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<!-- <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.0/themes/smoothness/jquery-ui.css" /> -->
	<script>
		$(function(){
			$('.date').mask('00/00/0000', {
				onComplete: function(value, event, field) {
					oTable
					.columns( 5 )
					.search( value )
					.draw();
				}
			}).datepicker({
				format: "dd/mm/yyyy",
				clearBtn: true,
				language: "pt-BR",
				autoclose: true,
				todayBtn: "linked",
				//todayHighlight: true
			}).change(function(){
				// $('#filter').attr('action', '/despesas/listar/').submit();
			});
		});
		
	</script>
	<!-- PAGE SCRIPTS -->
</body>
</html>