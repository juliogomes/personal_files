<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<style type="text/css">
		.progresso {
			display: none;
			position: fixed;
			left: 50%;
			top: 50%;
			-webkit-transform: translate(-50%, -50%);
			transform: translate(-50%, -50%);
			text-align: center;
			font-size: 16px;
			font-weight: bold;
			background-color: white;
			border: 1px solid black;
			height: 90px;
			width: 120px;
		}
	</style>
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "report-comissoes";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Reports</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i>Comissoes</h4>

	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<form class="form-inline" id="form_filter" name="form_filter" method="post" action="/comissoes/listar/">
			<div class="pull-left">
				<div class="form-group">
					<div class="input-group date">
						<span class="input-group-addon"><i class="fa fa-user"></i></span>
						<select name="user_comercial[]" id="user_comercial" class="form-control action" multiple>
							<option value="">Selecione</option>
							<?php foreach ($comissionados as $key => $value) { ?>
								<option value="<?= $value->id; ?>" <?= (isset($param['id_comercial']) && in_array($value->id, $param['id_comercial']))?'selected':null ?> ><?= $value->nome; ?></option>
							<?php } ?>
						</select>
					</div>
					<div class="input-group date">
						<span class="input-group-addon"></span>
							<select name="status" id="status" class="form-control action">
							<option value="">Selecione</option>
							<option value="recebido" <?= (isset($param['status']) && $param['status'] == 'recebido')?'selected':null ?> >Recebido</option>
							<option value="receber" <?= (isset($param['status']) &&$param['status'] == 'receber')?'selected':null ?>>Receber</option>
						</select>
					</div>
					<div class="input-group date">
						<span class="input-group-addon"></span>
							<select name="tipo_data" id="tipo_data" class="form-control action">
							<option value="data_emissao" <?= (isset($param['tipo_data']) && $param['tipo_data'] == 'data_emissao')?'selected':null ?> >Data de emissão</option>
							<option value="data_vencimento" <?= (isset($param['tipo_data']) && $param['tipo_data'] == 'data_vencimento')?'selected':null ?> >Data de vencimento</option>
							<option value="data_recebimento" <?= (isset($param['tipo_data']) && $param['tipo_data'] == 'data_recebimento')?'selected':null ?> >Data de recebimento</option>
						</select>
					</div>
					<div class="input-group date">
						<span class="input-group-addon">De <i class="fa fa-calendar"></i></span>
						<input type="text" name="data_de" id="data_de" class=" search form-control action datepast2" value="<?= convertDate($param['data_de']);?>" size=8 autocomplete="off" >
					</div>
					<div class="input-group date">
						<span class="input-group-addon">Até <i class="fa fa-calendar"></i></span>
						<input type="text" name="data_ate" id="data_ate" class="search form-control action datepast2" value="<?= convertDate($param['data_ate']);?>" size=8 autocomplete="off">
					</div>
					<div class="input-group date">
						<button type="submit" class="form-control btn btn-success">PESQUISAR</button>
					</div>
				</div>
			</div>
			<br /> 
		</form>
		<br />
		<form action="post" name="despesas" id="despesas">
			<div class="row">
				<div class="col-md-12">
					<?php if (is_array($relatorio)){ ?>
						<?php 	
							foreach($relatorio as $k1 => $v1) {
								$total = null; 
						?>
							<table id='list' class="list table table-default table-striped table-bordered table-hover" width="100%">
								<thead>
									<tr role="row">
										<th colspan = "11" class="text-center"><b><?= $k1; ?></b></th>
									</tr>
									<tr role="row">
										<th class="text-center">Nota</th>
										<th class="text-center">Comercial</th>
										<th class="text-center">Cliente</th>
										<th class="text-center">Produto</th>
										<th class="text-center">Valida Até</th>
										<th class="text-center">Valor da nota</th>
										<th class="text-center">Emissão</th>
										<th class="text-center">Vencimento</th>
										<th class="text-center">Recebimento</th>
										<th class="text-center">Comissao</th>
										<th class="text-center">Pagamento Previsto</th>
									</tr>
								</thead>
								<tbody>
									<?php foreach($v1['detalhes'] as $key => $value) { 
										$value = (object)$value;
										$total += $value->valor_receber;
									?>
									<tr>
										<td class="text-center"><?= $value->id_nota; ?></td>
										<td class="text-center"><?= $value->comerical; ?></td>
										<td class="text-center"><?= $value->cliente; ?></td>
										<td class="text-center"><?= $value->produto; ?></td>
										<td class="text-center"><?= convertDate($value->valida_ate); ?></td>
										<td class="text-center"><?= number_format($value->valor_liquido, '2', ',','.'); ?></td>
										<td class="text-center"><?= convertDate($value->data_emissao); ?></td>
										<td class="text-center"><?= convertDate($value->data_vencimento); ?></td>
										<td class="text-center"><?= convertDate($value->recebido_em); ?></td>
										<td class="text-center"><?= number_format($value->valor_receber, '2', ',','.'); ?></td>
										<td class="text-center"><?= convertDate($value->pagamento_previsto); ?></td>
									</tr>
									<?php } ?>
								</tbody>
								<tfoot>
									<tr>
										<th class= "text-right" colspan="9">Total</th>
										<th colspan="2"><?= number_format($total, '2', ',','.'); ?></th>
									</tr>
								</tfoot>					
							</table>
						<?php } ?>
					<?php } ?>
				</div>
			</div>
		</form>
		<!-- /.container-fluid -->
		<!-- /CONTENT -->
		<!-- END WRAPPER -->
		<?php include "template/end-menu-wrapper.html" ?>
		<!-- /END WRAPPER -->
	<!-- MODALS -->
	<div id="divCarregando" class="progresso">
		<span>TESTE</span>
	</div>
	<!-- MODALS -->
		<div class="modal fade" tabindex="-1" role="dialog" id="statusModal">
			<div class="modal-dialog " role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4><span class="modal-title"></span></h4>
				</div>
				<div class="modal-header">
					<div id="aviso_error" style="color:red"></div>
					<div id="aviso_success" style="color:green"></div>	
				</div>
				<form method="post">
					<div class="modal-body">
						<div id="mensagem"></div>
						<div id="senha">
							<form class="form-inline" id="frm_despesa" name="frm_despesa" method="post">	
								<div class="form-group">
									<label for="email_aprovacao">Email</label>
									<input type="email" class="form-control" id="email_aprovacao" aria-describedby="emailHelp" placeholder="xxx@xx" />
									<small class="form-text text-muted">Digite o email para aprovar as despesas </small>
								</div>	
								<div class="form-group">
									<label for="senha_aprovacao">Senha</label>
									<input type="password" class="form-control" id="senha_aprovacao" aria-describedby="emailHelp" />
									<small class="form-text text-muted">Digite a senha para aprovar as despesas </small>
								</div>
								<button type="button" id="btn-aprovar" class="form-control btn btn-success" value="aprovar">Aprovar Despesa</button>
								<button type="button" id="btn-pagar"  class="form-control btn btn-primary" value="pagar">Pagar Despesa</button>
							</form>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
					</div>
				</form>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
// 		jQuery(window).ready(function() {
//             //Após a leitura da pagina o evento fadeOut do loader é acionado, esta com delay para ser perceptivo em ambiente fora do servidor.
//             jQuery("#divCarregando").show().delay(2000).fadeOut("slow");
//         });
		$(function(){
			oTable = $('.list').DataTable({
				info: false,
				responsive: true,
				autoFill: true,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				},
				dom: 'Bfrtip',
				lengthMenu: [
					[ 10, 25, 50, -1 ],
					[ '10 rows', '25 rows', '50 rows', 'Show all' ]
				],
				lengthChange: false,
				buttons: [
					{
						extend: 'pageLength',
						text: 'PAGINAS',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'copyHtml5',
						text: 'COPY',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'excelHtml5',
						text: 'EXCEL',
						charset: 'utf-8',
						bom: true,
						exportOptions: {
							//columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 11, 12, 13 ] // para quando quiser fixar as colunas a serem importadas
							columns: ':visible'
						}
					},
					{
						extend: 'csv',
						text: 'CSV',
						charset: 'utf-8',
						bom: true,
						exportOptions: {
							//columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 11, 12, 13 ] // para quando quiser fixar as colunas a serem importadas
							columns: ':visible'
						}
					},
					{
						extend: 'pdfHtml5',
						text: 'PDF',
						charset: 'utf-8',
						bom: true,
						exportOptions: {
							columns: ':visible'
							//columns: [ 0, 1, 2, 5 ]
						}
					},
					{
						extend: 'colvis',
						text: 'COLUNAS',
					},
				]
			});
			oTable.buttons().container().appendTo('#list_wrapper .col-sm-6:eq(0)');
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>