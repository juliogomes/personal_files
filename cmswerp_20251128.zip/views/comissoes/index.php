<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<style type="text/css">
		.progresso {
			display: none;
			position: fixed;
			left: 50%;
			top: 50%;
			-webkit-transform: translate(-50%, -50%);
			transform: translate(-50%, -50%);
			text-align: center;
			font-size: 16px;
			font-weight: bold;
			background-color: white;
			border: 1px solid black;
			height: 90px;
			width: 120px;
		}
	</style>
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "report-comissoes";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Reports</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i>Comissoes</h4>

	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<form class="form-inline" id="form_filter" name="form_filter" method="post" action="/comissoes/listar/">
			<div class="pull-left">
				<div class="form-group">
					<div class="input-group">
						
					</div>
				</div>
			</div>
			<br /> 
		</form>
		<!-- /.container-fluid -->
		<!-- /CONTENT -->
		<!-- END WRAPPER -->
		<?php include "template/end-menu-wrapper.html" ?>
		<!-- /END WRAPPER -->
	<!-- MODALS -->
	<div id="divCarregando" class="progresso">
		<span>TESTE</span>
	</div>
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>