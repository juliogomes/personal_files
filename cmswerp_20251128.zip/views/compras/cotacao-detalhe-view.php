<?php

$etapa = [
    'elaboracao' => [
        'nome' => 'Elaboração',
        'icone' => '<i class="fa-solid fa-file"></i>',
        'color' => '#FFC107'
    ],
    'aprovacao' => [
        'nome' => 'Aprovação',
        'icone' => '<i class="fa-solid fa-hourglass"></i>',
        'color' => '#1707ffff'
    ],
    'aguardando' => [
        'nome' => 'Aguardando',
        'icone' => '<i class="fa-solid fa-hourglass"></i>',
        'color' => '#1707ffff'
    ],
    'aprovada' => [
        'nome' => 'Aprovada',
        'icone' => '<i class="fa-solid fa-check"></i>',
        'color' => '#2c8808ff'
    ],
    'reprovada' => [
        'nome' => 'Rejeitada',
        'icone' => '<i class="fa-solid fa-xmark"></i>',
        'color' => '#ff0000ff'
    ]
];

$empresas_em_uso = [];
$temOrcamentoGanho = false;

$etapaAtual =  'elaboracao' ;

if($etapasAprovacao->etapaAtual->aprovadores && isset($etapasAprovacao->etapaAtual->status) && $etapasAprovacao->etapaAtual->status == 'r'){
    $etapaAtual = 'reprovada';
}else if ($etapasAprovacao->status == 'aprovacao') {
    $etapaAtual = 'aprovacao';
}

if($cotacao->status == 'finalizada' || $cotacao->status == 'cancelada' || $cotacao->status == 'reprovada'){
    $etapaAtual = $cotacao->status;
}

?>

<?php include 'template/head-css.inc' ?>
<?php include "template/menu-wrapper.php" ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<script type="text/javascript">
    var sidebarItem = 'cotacao';
</script>

<style>
    .tab-hide {
        display: none;
    }

    .etapas_cotacao {
        padding: 15px;
        background-color: #f8f8f8ff;
        border-radius: 5px;
        margin: 10px 0px;
    }

    .stepper {
        display: flex;
        justify-content: space-between;
        align-items: center;
        position: relative;
    }

    .step {
        text-align: center;
        flex: 1;
        position: relative;
    }

    .step .circle {
        width: 50px;
        height: 50px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto;
        font-size: 22px;
        background-color: #eaeef5;
        color: #888;
        border: 3px solid #eaeef5;
        position: relative;
        z-index: 1;
    }

    .step:not(:last-child)::after {
        content: "";
        position: absolute;
        top: 25px;
        left: 50%;
        width: 100%;
        height: 4px;
        background-color: #eaeef5;
        z-index: 0;
    }

    .step span {
        display: block;
        margin-top: 10px;
        font-size: 14px;
        color: #666;
    }

    .step.active .circle {
        background-color: #1c912fff;
        color: #fff;
        border-color: #1c912fff;
    }

    .step.active span {
        color: #1c912fff;
        font-weight: bold;
    }

    .step.completed .circle {
        background-color: #1c912fff;
        border-color: #1c912fff;
        color: #fff;
    }

    .step.completed:not(:last-child)::after {
        background-color: #1c912fff;
    }

    .step.active.cancelada .circle {
        background-color: #ff0000ff;
        color: #fff;
        border-color: #ff0000ff;
    }

    .step.active:not(:last-child):not(.cancelada)::before {
        content: "";
        position: absolute;
        top: 25px;
        left: 50%;
        width: 50%;
        height: 4px;
        background-color: #1c912fff;
        z-index: 1;
    }

    .step.completed span {
        color: #1c912fff;
    }

    .tr_deletavel {
        position: relative;
    }

    .tr_deletada:after {
        content: '';
        position: absolute;
        width: 85%;
        height: 2px;
        background: #ff0000ff;
        left: 0;
        top: 50%;
        z-index: 9999;
    }

    .btn_hide {
        display: none;
    }
</style>

<body>

    <ol class="breadcrumb">
        <li>Tarifas.cmsw.com</li>
        <li>Compras</li>
        <li>Detalhe Cotação</li>
    </ol>

    <h4 class="page-title"><i class="fa fa-caret-right"></i> DETALHE COTAÇÃO</h4>

    <div style="margin:10px">
        <h4>Só é permitida a alteração de uma cotação nos casos:</h4>
        <ul>
            <li>Se a etapa for <b>Elaboração</b></li>
            <li>Se o status for <b>Andamento</b></li>
            <li>Se não houver <b>orçamentos</b></li>
        </ul>

    </div>

    <div class="container-fluid">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 etapas_cotacao" role="group" role="group">
            <h5 style="margin: 4px 0;"><strong>FLUXO DE COTAÇÃO</strong></h5>
            <div class="stepper">
                <div class="step active <?= $etapaAtual !== 'elaboracao' ? 'completed': '' ?>">
                    <div class="circle"><?= $etapa['elaboracao']['icone'] ?></i></div>
                    <span>Elaboração</span>
                    <?php 
                        $solicitante_explode = explode(' ', $cotacao->solicitante);
                        $solicitante = ucfirst(strtolower($solicitante_explode[0])) . ' ' . ucfirst(strtolower($solicitante_explode[count($solicitante_explode) - 1])) ;
                    ?>
                    <span><?=$solicitante ?></span>

                </div>
                <?php if ($etapasAprovacao->etapas && $cotacao->status !== 'cancelada') {

                    $justificativa = '';
                    
                    foreach ($etapasAprovacao->etapas as $key => $etapaAprovacao) {
                        foreach($etapaAprovacao->aprovadores as $this_aprovador){
                            if($cotacao->id_solicitante == $this_aprovador->aprovador){
                                continue;
                            }
                        }

                        $aprovador = '<span>';
                        foreach($etapaAprovacao->aprovadores as $thisAprovador){
                            $name_explode = explode(' ', $thisAprovador['nome']);
                            $aprovador .= ucfirst(strtolower($name_explode[0])) . ' ' . ucfirst(strtolower($name_explode[count($name_explode) - 1])) . ' ou     ' ;
                        }

                        $aprovador .='</span>';

                        $status = $etapaAprovacao->statusAprovacao ? $etapaAprovacao->statusAprovacao  : 'aguardando';
                        switch($status) {
                            case 'p':
                                $status = 'aprovacao';
                                break;
                            case 'a':
                                $status = 'aprovada';
                                break;
                            case 'r':
                                $status = 'reprovada';
                                break;
                            default:
                                $status = 'aguardando';
                                break;
                        }

                        $classStatus = '';
                        if($etapaAprovacao->statusAprovacao == 'r') {
                            $classStatus = 'active cancelada';
                        }else if($etapaAprovacao->statusAprovacao == 'p') {
                            $classStatus = 'active';
                        }else if($etapaAprovacao->statusAprovacao == 'a'){
                            $classStatus = 'active completed';

                        }
                        ?>
                        <div class="step <?= $classStatus ?>">
                            <div class="circle"><?= $etapa[$status]['icone'] ?></i></div>
                            <span><?= $etapa[$status]['nome'] ?></span>
                            <?=  $aprovador ?>
                            <?php if($etapaAprovacao->justificativa && $etapaAprovacao->statusAprovacao == 'r') { 
                                $justificativa = $etapaAprovacao->justificativa;
                                echo '<a href="#" id="btn_ver_justificativa" style="position: absolute;left: calc(50% - 45px);">Ver justificativa</a>';
                            }?>
                        </div>

                        
                    <?php } } 
                    
                    if($cotacao->status == 'cancelada' && 1==2) { ?>
                        <div class="step active cancelada">
                        <div class="circle"><i class="fa-solid fa-close"></i></div>
                        <span>Cancelada</span>
                        <span>-</span>
                     <?php }else if($cotacao->status == 'concluida'){?>
                        <div class="step concluida">
                        <div class="circle"><i class="fa-solid fa-check"></i></div>
                        <span>Concluida</span>
                        <span>-</span>
                     <?php }else if($cotacao->status == 'finalizada'){ ?>
                        <div class="step active">
                        <div class="circle"><i class="fa-solid fa-check"></i></div>
                        <span>Conclusão</span>
                        <span>-</span>
                     <?php  }  else{ ?>
                        <div class="step">
                        <div class="circle"><i class="fa-solid fa-check"></i></div>
                        <span>Conclusão</span>
                        <span>-</span>
                     <?php  } ?>
                     
                </div>
            </div>
        </div>
        <hr>

        <div>
            <div class="container-fluid">
                <?php
                $permitidoAlterar = ($cotacao->tipo == 'contratação' && $etapaAtual == 'elaboracao') || ($orcamentos == null || count($orcamentos) == 0 && $etapaAtual == 'elaboracao')
                    ?>
                <ul class="nav nav-tabs">
                    <li class="nav-tabs active"><a data-toggle="tab" href="#tabDadosGerais">DADOS GERAIS</a></li>
                    <?php if ($cotacao->tipo !== 'contratação') { ?>
                        <li class="nav-tabs"><a data-toggle="tab" href="#tabOrcamentos">ORÇAMENTOS</a></li>
                    <?php } ?>
                    <li class="nav-tabs"><a data-toggle="tab" href="#tabDocumentos">DOCUMENTOS</a></li>
                </ul>
                <div id="tabDadosGerais" class="tab-custom">
                    <form id="form_dados_gerais">
                        <div class="modal-body">
                            <div class="form-group col-md-4">
                                <label for="id_solicitante">Solicitante</label>
                                <select class="form-control select col-md-3" name="id_solicitante" id="id_solicitante"
                                    <?= !$permitidoAlterar ? 'disabled readonly' : null ?>>
                                    <?php if ($usuarios) {
                                        echo '<option value="">Selecione</option>';
                                        foreach ($usuarios as $key => $value) { ?>
                                            <option value="<?= $value->id ?>" <?= (isset($cotacao) && $cotacao->id_solicitante == $value->id) ? 'selected' : null; ?>>
                                                <?= $value->nome ?>
                                            </option>
                                        <?php } ?>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="form-group col-md-2">
                                <label for="tipo">Tipo Cotação</label>
                                <select class="form-control select col-md-3" name="tipo" id="tipo" <?= !$permitidoAlterar ? 'disabled readonly' : null ?>>
                                    <option value="">Selecione</option>
                                    <option value="compra" <?= (isset($cotacao) && $cotacao->tipo == 'compra') ? 'selected' : null; ?>>COMPRA</option>
                                    <option value="serviço" <?= (isset($cotacao) && $cotacao->tipo == 'serviço') ? 'selected' : null; ?>>SERVIÇO</option>
                                    <option value="contratação" <?= (isset($cotacao) && $cotacao->tipo == 'contratação') ? 'selected' : null; ?>>CONTRATAÇÃO</option>
                                </select>
                            </div>
                            <div class="form-group col-md-2">
                                <label for="departamento">Departamento</label>
                                <select name="departamento" id="departamento" class="form-control select"
                                    <?= !$permitidoAlterar ? 'disabled readonly' : null ?>>
                                    <option value="">Selecione</option>
                                    <option value="ADM" <?= (isset($cotacao) && $cotacao->departamento == 'ADM') ? 'selected' : null; ?>>
                                        ADMINISTRAÇÃO
                                    </option>
                                    <option value="BI" <?= (isset($cotacao) && $cotacao->departamento == 'BI') ? 'selected' : null; ?>>BI
                                    </option>
                                    <option value="COMERCIAL" <?= (isset($cotacao) && $cotacao->departamento == 'COMERCIAL') ? 'selected' : null; ?>>
                                        COMERCIAL
                                    </option>
                                    <option value="customer_success" <?= (isset($cotacao) && $cotacao->departamento == 'customer_success') ? 'selected' : null; ?>>
                                        CUSTOMER
                                        SUCCESS</option>
                                    <option value="DESENVOLVIMENTO" <?= (isset($cotacao) && $cotacao->departamento == 'DESENVOLVIMENTO') ? 'selected' : null; ?>>
                                        DESENVOLVIMENTO</option>
                                    <option value="JURIDICO" <?= (isset($cotacao) && $cotacao->departamento == 'JURIDICO') ? 'selected' : null; ?>>
                                        JURIDICO
                                    </option>
                                    <option value="MARKETING" <?= (isset($cotacao) && $cotacao->departamento == 'MARKETING') ? 'selected' : null; ?>>
                                        MARKETING
                                    </option>
                                    <option value="MODELOS PREDITIVOS" <?= (isset($cotacao) && $cotacao->departamento == 'MODELOS PREDITIVOS') ? 'selected' : null; ?>>
                                        MODELOS
                                        PREDITIVOS</option>
                                    <option value="OPERACOES" <?= (isset($cotacao) && $cotacao->departamento == 'OPERACOES') ? 'selected' : null; ?>>
                                        OPERACÕES
                                    </option>
                                    <option value="PRODUTOS" <?= (isset($cotacao) && $cotacao->departamento == 'PRODUTOS') ? 'selected' : null; ?>>
                                        PRODUTOS
                                    </option>
                                    <option value="PRESIDENCIA" <?= (isset($cotacao) && $cotacao->departamento == 'PRESIDENCIA') ? 'selected' : null; ?>>
                                        PRESIDENCIA
                                    </option>
                                    <option value="SUPORTE" <?= (isset($cotacao) && $cotacao->departamento == 'SUPORTE ') ? 'selected' : null; ?>>
                                        SUPORTE
                                    </option>
                                </select>
                            </div>
                            <div class="form-group col-md-2">
                                <label for="departamento">Previsão de Aquisição</label>
                                <input type="date" name="previsao_aquisicao" class="form-control"
                                    name="previsao_aquisicao" id='previsao_aquisicao'
                                    value="<?= $cotacao->previsao_aquisicao ?>" <?= !$permitidoAlterar ? 'disabled readonly' : null ?> />
                            </div>
                            <!-- <div class="form-group col-md-2">
                                <label for="valor_total">Valor Total</label>
                                <input type="text" class="form-control" id="valor_total" name="valor_total" value="<?= $cotacao->valor ?>"
                                    <?= $cotacao->tipo !== 'contratação' ? 'disabled readonly' : null ?> />
                                    <?php if ($cotacao->tipo !== 'contratação') {
                                        echo '<span>Baseado no orçamento selecionado.</span>';
                                    } ?>
                            </div> -->

                            <?php if ($cotacao->tipo == 'contratação') { ?>
                                <input type='hidden' name='contratacao_id'
                                    value='<?= isset($cotacao->contratacao_id) ? $cotacao->contratacao_id : 0; ?>'>
                                <div class="form-group col-md-2">
                                    <label for="cargo">Cargo</label>
                                    <input type="text" class="form-control" id="cargo" name="cargo"
                                        value="<?= $cotacao->cargo ?>" <?= !$permitidoAlterar ? 'disabled readonly' : null ?> />
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="forma_contratacao">Forma de Contratação</label>
                                    <select class="form-control select col-md-3" name="forma_contratacao"
                                        id="forma_contratacao" <?= !$permitidoAlterar ? 'disabled readonly' : null ?>>
                                        <option value="">Selecione</option>
                                        <option <?php if ($cotacao->forma_contratacao == 'CLJ')
                                            echo 'selected'; ?>
                                            value="CLJ">CLJ</option>
                                        <option <?php if ($cotacao->forma_contratacao == 'PJ')
                                            echo 'selected'; ?> value="PJ">
                                            PJ</option>
                                        <option <?php if ($cotacao->forma_contratacao == 'Terceirizado')
                                            echo 'selected'; ?>
                                            value="Terceirizado">Terceirizado</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="tipo_contrato">Tipo de Contrato</label>
                                    <select class="form-control select col-md-3" name="tipo_contrato" id="tipo_contrato"
                                        <?= !$permitidoAlterar ? 'disabled readonly' : null ?>>
                                        <option>Selecione</option>
                                        <option <?php if ($cotacao->tipo_contrato == 'Autônomo')
                                            echo 'selected'; ?>
                                            value="Autônomo">Autônomo</option>
                                        <option <?php if ($cotacao->tipo_contrato == 'Estágio')
                                            echo 'selected'; ?>
                                            value="Estágio">Estágio</option>
                                        <option <?php if ($cotacao->tipo_contrato == 'Experiência')
                                            echo 'selected'; ?>
                                            value="Experiência">Experiência</option>
                                        <option <?php if ($cotacao->tipo_contrato == 'Determinado')
                                            echo 'selected'; ?>
                                            value="Determinado">Determinado</option>
                                        <option <?php if ($cotacao->tipo_contrato == 'Indeterminado')
                                            echo 'selected'; ?>
                                            value="Indeterminado">Indeterminado</option>
                                        <option <?php if ($cotacao->tipo_contrato == 'Temporário')
                                            echo 'selected'; ?>
                                            value="Temporário">Temporário</option>
                                    </select>
                                </div>
                            <?php } ?>

                            <div class="form-group col-md-12">
                                <label for="detalhes">Detalhes</label>
                                <textarea class="form-control" name="detalhes" id="detalhes" rows="3"
                                    <?= !$permitidoAlterar ? 'disabled readonly' : null ?>><?= $cotacao->detalhes ?></textarea>
                            </div> 
                            <?php 
                            
                            if($cotacao->status == 'andamento') {
                                if ($cotacao->id_solicitante == $_SESSION['cmswerp']['userdata']->id && $permitidoAlterar) { ?>
                                    <div class="form-group col-md-2">
                                        <button type="button" id="btn_salvar_cotacao" class="form-control btn btn-success">
                                            <i class="fa fa-save"></i>&nbsp;&nbsp;SALVAR ALTERAÇÕES
                                        </button>
                                    </div>
                                <?php  }?>

                                <?php if (($orcamentos || $cotacao->tipo == 'contratação') && $etapaAtual == 'elaboracao' && $cotacao->id_solicitante == $_SESSION['cmswerp']['userdata']->id) { ?>
                                    <div class="form-group col-md-2">
                                        <button type="button" id="btn_avancar_cotacao" class="form-control btn btn-info" value="avancar">
                                            <i class="fa fa-paper-plane"></i>&nbsp;&nbsp;ENVIAR PARA APROVAÇÃO
                                        </button>
                                    </div>
                                <?php } ?>

                                <?php if($cotacao->id_solicitante == $_SESSION['cmswerp']['userdata']->id){ ?>
                                    <div class="form-group col-md-2">
                                        <button type="button" id="btn_cancelar_cotacao" class="form-control btn btn-danger">
                                            <i class="fa fa-close"></i>&nbsp;&nbsp;CANCELAR COTACÃO
                                        </button>
                                    </div>
                            <?php } ?>
                                
                            <?php if (in_array($_SESSION['cmswerp']['userdata']->id, $etapasAprovacao->proximaEtapa->arrIdAprovadores)) {?>
                                    <div class="form-group col-md-2">
                                        <button type="button" id="btn_avancar_cotacao" class="form-control btn btn-success" >
                                            <i class="fa fa-check"></i>&nbsp;&nbsp;APROVAR
                                        </button>
                                    </div>
                                    <div class="form-group col-md-2">
                                        <button type="button" id="btn_reprovar_cotacao" class="form-control btn btn-danger" >
                                            <i class="fa fa-close"></i>&nbsp;&nbsp;REPROVAR
                                        </button>
                                    </div>
                                <?php } 
                            } ?>
                        </div>
                    </form>
                </div>
                <?php if ($cotacao->tipo !== 'contratação') { ?>
                    <div id="tabOrcamentos" class="tab-custom tab-hide">
                        <div class="container-fluid" style="padding: 5px 0 ">
                            <?php if ($etapaAtual == 'elaboracao') { ?>
                                <div class="btn-group" role="group">
                                    <button type="button" id='btn_modal_add_proposta' class="btn btn-primary"><i
                                        class="fa fa-plus"></i>&nbsp;&nbsp;Adicionar Orçamento</button>
                                </div>
                            <?php } ?>

                            <div>
                                <?php if ($cotacao->tipo == 'compra' || $cotacao->tipo == 'serviço') { ?>
                                    <table class="table table-default">
                                        <thead>
                                            <tr>
                                                <th>Código Orçamento</th>
                                                <th>Empresa</th>
                                                <th>Valor total</th>
                                                <th>Ganhadora</th>
                                                <th>Ações</th>
                                        </thead>
                                        <tbody>
                                            <?php if (!$orcamentos) {
                                                echo '<tr><td colspan="5">Nenhum orçamento adicionado</td></tr>';
                                            } ?>
                                            <?php foreach ($orcamentos as $key => $value) {
                                                if ($value->ganho == 1) {
                                                    $temOrcamentoGanho = true;
                                                }
                                                array_push($empresas_em_uso, $value->id_empresa) ?>
                                                <tr>
                                                    <td><?= $value->codigo_orcamento ?></td>
                                                    <td data-fornecedor-id="<?= $value->id_empresa ?>"><?= $value->empresa ?></td>
                                                    <td>R$ <?= number_format($value->valor, 2) ?></td>
                                                    <td><?= $value->ganho == 1 ? '<span style="color: green"><i class="fa fa-check"></i></span>' : '' ?>
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-success btn_visualizar_orcamento"
                                                            title="Visualizar Orçamento" value="<?= $value->id ?>"><i class="fa fa-eye"></i> </span>
                                                        </button>
                                                        <?php if ($etapaAtual == 'elaboracao') { ?>
                                                            <?php if ($value->ganho == 0) { ?>
                                                                <button class="btn btn-info btn_definir_ganho" title="Definir Ganho"
                                                                    value="<?= $value->id ?>"><i class="fa fa-check"></i> </span></button>
                                                            <?php } ?>
                                                            <button value="<?= $value->id ?>" type="button" title="Excluir Orçamento"
                                                                class="btn btn-danger btn_delete_orcamento"><i class="fa fa-trash"></i>
                                                                </span>
                                                            </button>
                                                        <?php } ?>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                <?php } ?>
                <div id="tabDocumentos" class="tab-custom tab-hide">
                    <div class="container-fluid" style="padding: 5px 0">
                        <div class="btn-group" role="group">
                            <a type="button" class="btn btn-primary" data-toggle="collapse"
                                href="#form_adicionar_documento" role="button" aria-expanded="false"
                                aria-controls="modal_adc_produto">
                                <i class="fa fa-plus"></i>&nbsp;&nbsp;<span>Adicionar Documento</span>
                            </a>
                        </div>

                        <form id="form_adicionar_documento" enctype="multipart/form-data" class="collapse">
                            <input type="hidden" name="id_cotacao" value="<?= $cotacao->id ?>">
                            <div class="row">
                                <div class="row col-md-12">
                                    <div class="form-group col-md-2">
                                        <label for="referencia">Referência</label>
                                        <select name="referencia" id="referencia" class="form-control" required>
                                            <option value="">Selecione</option>
                                            <option value="cotacao">Cotação em geral</option>
                                            <?php if ($orcamentos) {
                                                foreach ($orcamentos as $key => $value) {
                                                    echo '<option value="' . $value->id . '">' . 'Orçamento ' . $value->codigo_orcamento . '</option>';
                                                }
                                            } ?>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-2" style="padding-top:30px">
                                        <input type="file" name="documento" id="documento" style="" required>
                                    </div>
                                </div>
                                <div class="row col-md-12">
                                    <div class="form-group col-md-6">
                                        <label for="descricao">Descrição</label>
                                        <input type="text" name="descricao" id="descricao" class="form-control"
                                            required>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group col-md-12" style="padding-top:30px">
                                <button type="button" id='btn_modal_add_documento' class="btn btn-primary" disabled><i
                                        class="fa fa-plus"></i>&nbsp;&nbsp;Salvar Documento</button>
                            </div>
                        </form>
                        <div>
                            <table class="table table-default">
                                <thead>
                                    <tr>
                                        <th>Documento ID</th>
                                        <th>Nome</th>
                                        <th>Descrição</th>
                                        <th>Anexado Em</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (!$documentos) {
                                        echo '<tr><td colspan="12">Nenhum documento anexado</td></tr>';
                                    } ?>
                                    <?php foreach ($documentos as $key => $value) { ?>
                                        <tr>
                                            <td><?= $value->id ?></td>
                                            <td><?= $value->nome_documento ?></td>
                                            <td><?= $value->descricao ?></td>
                                            <td><?= date('d/m/Y ', strtotime($value->data_documento)) ?></td>
                                            <td>
                                                <a href="/compras/downloadFile/id/<?= $value->id ?>"
                                                    title="Baixar documento" class="btn btn-success btn_download_documento"
                                                    target="_blank">
                                                    <i class="fa fa-download"></i>
                                                </a>
                                                <?php if ($etapaAtual == 'elaboracao') { ?>
                                                    <button value="<?= $value->id ?>" type="button" title="Excluir Documento"
                                                        class="btn btn-danger btn_delete_documento"><i class="fa fa-trash"></i>
                                                    </button>
                                                </td>
                                            <?php } ?>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- MODAL ADICIOAR ORÇAMENTO -->
            <div class="modal fade" id="modal_add_proposta" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">
                                <span>x</span>
                            </button>
                            <fieldset>
                                <h2 style="text-align:center;font-size:16px; letter-spacing: 0.8em;"><span
                                        id="text_add_proposta">ADICIONAR ORÇAMENTO</span></h2>
                            </fieldset>
                        </div>
                        <div class="modal-body">
                            <?php if ($cotacao->tipo == 'compra') {
                                include('views/compras/forms/form_add_produto.php');
                            } else if ($cotacao->tipo == 'serviço') {
                                include('views/compras/forms/form_add_servico.php');
                            } ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END MODAL ADICIOAR ORÇAMENTO -->
             
            <!-- MODAL JUSTIFICATIVA NEGATIVA -->
            <div class="modal fade" id="modal_rejeicao" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">
                                <span>x</span>
                            </button>
                            <fieldset>
                                <h2 style="text-align:center;font-size:16px; letter-spacing: 0.8em;"><span id="text_add_proposta">JUSTIFICATIVA DA NEGATIVA</span></h2>
                            </fieldset>
                        </div>
                        <div class="modal-body">
                            <textarea id="justificativaNegativa" class="form-control" cols="30" rows="10"></textarea>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-success" id="btn_reject_cotacacao"
                                style="font-size:10px;font-weight:bold">CONFIRMAR</button>
                            <button type="button" class="btn btn-danger action_close_comissao" data-dismiss="modal"
                                style="font-size:10px;font-weight:bold">CANCELAR</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END MODAL JUSTIFICATIVA -->

            <!-- MODAL VISUALIZAR JUSTIFICATIVA NEGATIVA -->
            <div class="modal fade" id="modal_visualizar_rejeicao" tabindex="-1" role="dialog">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">
                                <span>x</span>
                            </button>
                            <fieldset>
                                <h2 style="text-align:center;font-size:16px; letter-spacing: 0.8em;"><span id="text_add_proposta">JUSTIFICATIVA DA NEGATIVA</span></h2>
                            </fieldset>
                        </div>
                        <div class="modal-body">
                            <textarea id="justificativaNegativa" class="form-control" cols="30" rows="10" disabled readonly><?php if($justificativa) echo $justificativa; ?></textarea>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END MODAL VISUALIZAR JUSTIFICATIVA -->

            <?php include "template/end-menu-wrapper.html" ?>
            <?php include 'template/scripts.inc' ?>
            <script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
            <?php include "template/modal_sistema.php" ?>

            <script type="text/javascript">

                $('#btn_ver_justificativa').on('click', function () {
                    $('#modal_visualizar_rejeicao').modal('show');
                })

                const tipoCotacao = '<?= $cotacao->tipo ?>';
                $('#btn_avancar_cotacao').on('click', function () {
                    <?php if ($temOrcamentoGanho || $cotacao->tipo == 'contratação') { ?>
                        if (tipoCotacao == 'contratação') {
                            let temDadoPendente = false;
                            $('#form_dados_gerais input').each((a, b) => temDadoPendente = b.value == '' || b.value == null)
                            $('#form_dados_gerais select').each((a, b) => temDadoPendente = b.value == '' || b.value == null)

                            if (!temDadoPendente) {
                                alert('Preencha todos os dados do formulário')
                                return;
                            }
                        }

                        if (confirm('Confirma o envio da cotação?')) {
                            ajax("/compras/aprovaCotacao", 'POST',
                                {
                                    cotacao_id: <?= $cotacao->id ?>,
                                    ids_aprovacao: <?= $etapasAprovacao->etapaAtual->ids_aprovacao ? json_encode($etapasAprovacao->etapaAtual->ids_aprovacao) :  json_encode(false) ?>,
                                    proxima_etapa: <?= $etapasAprovacao->proximaEtapa ? json_encode($etapasAprovacao->proximaEtapa) :  json_encode(false) ?>
                                },
                                success_modal_reload_page,
                                error_default,
                                true,
                                false)
                        }
                    <?php } else {
                        echo 'alert("Defina um orçamento como ganho para avançar com cotação")';
                    } ?>

                })

                $('#btn_reject_cotacacao').on('click', function () {

                    const justificativa = $('#justificativaNegativa').val();
                    if(!justificativa){
                        alert('Preencha a justificativa');
                        return;
                    }

                    if (confirm('Confirma a negativa da cotação?')) {
                        ajax("/compras/reprovaCotacao", 'POST',
                            {
                                cotacao_id: <?= $cotacao->id ?>,
                                ids_aprovacao: <?= $etapasAprovacao->etapaAtual->ids_aprovacao ? json_encode($etapasAprovacao->etapaAtual->ids_aprovacao) :  json_encode(false) ?>,
                                justificativa: justificativa
                            },
                            success_modal_reload_page,
                            error_default,
                            true,
                            false)
                    }
       
                })

                $('#btn_reprovar_cotacao').on('click', function () {
                    $('#modal_rejeicao').modal('show');
                })

                $('.btn_delete_documento').on('click', function () {
                    if (confirm('Tem certeza que deseja excluir o documento?')) {
                        const id = $(this).val();
                        ajax("/compras/excluirDocumento", 'POST', { documento_id: id }, success_modal_reload_page, error_default, true, false);
                    }
                })

                $('#btn_modal_add_documento').on('click', function () {
                    const data = new FormData($('#form_adicionar_documento').get(0));
                    if (!data.get('documento') || !data.get('referencia') || !data.get('descricao')) {
                        alert('Preencha os campos obrigatórios e anexe o documento.');
                        return;
                    }
                    ajax("/compras/adicionarDocumento", 'POST', data, success_modal_reload_page, error_default, false, true)
                })

                // $(document).ready(function () {
                //     $('#valor_total').maskMoney({ decimal: ',', thousands: '.' });
                //     $('#valor').maskMoney({ decimal: ',', thousands: '.' });
                // })

                function success_modal_reload_page(data) { //GENERICO
                    $('#painel_success_msg').text(data.mensagem);
                    $('#modal_sucesso_sistema').modal('show');
                    $('#modal_sucesso_sistema').on('hidden.bs.modal', function () {
                        window.location.reload();
                    });
                }
                function error_default(data) {
                    $('#painel_error_msg').text(data.mensagem);
                    $('#modal_erro_sistema').modal('show');
                }

                function ajax(url, method, data, success, error, processData, isFile) { //GENERICO
                    $.ajax({
                        url,
                        method,
                        data,
                        processData,
                        contentType: isFile ? false : "application/x-www-form-urlencoded",
                        beforeSend: function () {
                            waitingDialog.show('PROCESSANDO...');
                        },
                        success: function (data) {
                            if (typeof data == 'string') {
                                data = JSON.parse(data);
                            }
                            if (data.codigo == 1) {
                                success(data);
                            } else {
                                error(data);
                            }
                            waitingDialog.hide();

                        },
                        error: function (error) {
                            waitingDialog.hide();
                            $('#painel_error_msg').text(error.responseText);
                            $('#modal_erro_sistema').modal('show');
                        }
                    })
                }

                $('#btn_modal_add_proposta').on('click', function () {// A DEFINIR
                    $('#text_add_proposta').text('ADICIONAR ORÇAMENTO');
                    $('#modal_add_proposta').modal('show');
                })

                <?php if (isset($cotacao) && $cotacao->id_solicitante) { ?>
                    $('#id_solicitante').selectpicker('val', '<?= $cotacao->id_solicitante ?>')
                <?php } ?>

                <?php if (isset($cotacao) && $cotacao->tipo) { ?>
                    $('#tipo').selectpicker('val', '<?= $cotacao->tipo ?>')
                <?php } ?>

                $(document).on('click', 'li.nav-tabs a', function (e) {
                    let href = $(e.currentTarget).attr('href');
                    $('.tab-custom:not(' + href + ')').addClass('tab-hide');
                    $(href).removeClass('tab-hide');
                })

                <?php if ($permitidoAlterar) { ?>
                    $('#btn_cancelar_cotacao').on('click', function () {
                        if (confirm('Tem certeza que deseja cancelar a cotação?')) {
                            ajax('/compras/cancelarCotacao/id/<?= $cotacao->id ?>', 'POST', {}, success_modal_reload_page, error_default, true, false)
                        }
                    })

                    $('#btn_salvar_cotacao').on('click', function () {
                        ajax('/compras/atualizaCotacao/id/<?= $cotacao->id ?>', 'POST', $('#form_dados_gerais').serialize(), success_modal_reload_page, error_default, true, false)
                    })

                <?php } ?>

            </script>