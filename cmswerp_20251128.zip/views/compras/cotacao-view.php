<!doctype html>
<html class="no-js" lang="">

<head>
    <?php include 'template/head-css.inc' ?>
    <script type="text/javascript">
        var sidebarItem = 'cotacao';
    </script>
</head>

<body>
    <?php include "template/menu-wrapper.php" ?>
    <ol class="breadcrumb">
        <li>Tarifas.cmsw.com</li>
        <li>Compras</li>
        <li>Cotação</li>
    </ol>

    <h4 class="page-title"><i class="fa fa-caret-right"></i> COTAÇÕES</h4>

    <div class="container-fluid">
        <div class="btn-group" role="group">
            <button type="button" id='nova_cotacao' class="btn btn-primary"><i class="fa fa-plus"></i>
                Nova Cotação</button>
        </div>
        <hr>
        <div>
            <table class="table table-default" id="table_cotacoes">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Solicitante</th>
                        <th>Departamento</th>
                        <th>Tipo</th>
                        <th>Criado em</th>
                        <th>Previsão compra</th>
                        <th>Valor</th>
                        <th>Etapa</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($cotacoes) {
                        foreach ($cotacoes as $key => $value) {
                            ?>
                            <tr>
                                <td class="text-left"><?= $value->id; ?></small></td>
                                <td class="text-left"><small class="label-status"><?= $value->solicitante; ?></small></td>
                                <td class="text-left"><small class="label-status"><?= $value->departamento; ?></small></td>
                                <td class="text-left"><small class="label-status"><?= $value->tipo; ?></small></td>
                                <td class="text-left"><small
                                        class="label-status"><?= date('d/m/Y H:i', strtotime($value->criado_em)) ?></small></td>
                                <td class="text-left"><small
                                        class="label-status"><?= date('d/m/Y', strtotime($value->previsao_aquisicao)) ?></small>
                                </td>
                                <td class="text-left"><small class="label-status">R$ <?= $value->valor; ?></small></td>
                                <td class="text-left"><small class="label-status"><?= $value->etapa; ?></small></td>
                                <td class="text-left"><small class="label-status"><?= $value->status; ?></small></td>
                                <td class="text-left">
                                    <a class="btn btn-info" href="/compras/detalhe/id/<?= $value->id ?>/">
                                        <i class="fa fa-eye"></i> </span>
                                    </a>
                                    <?php if ($value->etapa == 'elaboração') { ?>
                                        <button value="<?= $value->id ?>" type="button" class="btn btn-danger delete_cotacao">
                                            <i class="fa fa-trash"></i> </span>
                                        </button>
                                    <?php } ?>
                                </td>
                            </tr>
                        <?php }
                    } ?>
                </tbody>
            </table>
        </div>
    </div>


    <!-- MODAL NOVA COTAÇÃO -->
    <div class="modal fade" id="modal_nova_cotacao" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close action_close_jornada_dias" data-dismiss="modal">
                        <span>x</span>
                    </button>
                    <fieldset>
                        <h2 style="text-align:center;font-size:16px; letter-spacing: 0.8em;">ADICIONAR COTAÇÃO</h2>
                    </fieldset>
                </div>
                <div class="modal-body">
                    <form method="post" id="form_nova_cotacao" action="/compras/adicionarCotacao/">
                        <div class="container-fluid">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group" style="width:180px;">
                                        <label for="tipo">Tipo de Cotação</label>
                                        <select class="form-control select col-md-3" name="tipo" id="tipo">
                                            <option value="">Selecione</option>
                                            <option value="compra">COMPRA</option>
                                            <option value="serviço">SERVIÇO</option>
                                            <option value="contratação">CONTRATAÇÃO</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group" style="width:180px;">
                                        <label for="id_solicitante">Solicitante</label>
                                        <select class="form-control select col-md-3" name="id_solicitante"
                                            id="id_solicitante">
                                            <?php if ($usuarios) {
                                                echo '<option value="">Selecione</option>';
                                                foreach ($usuarios as $key => $value) { ?>
                                                    <option value="<?= $value->id ?>">
                                                        <?= $value->nome ?>
                                                    </option>
                                                <?php } ?>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group" style="width:180px;">
                                        <label for="departamento">Departamento</label>
                                        <select name="departamento" id="departamento" class="form-control select">
                                            <option value="">Selecione</option>
                                            <option value="ADM" <?= (isset($records[0]) && $records[0]->departamento == 'ADM') ? 'selected' : null; ?>>ADMINISTRAÇÃO
                                            </option>
                                            <option value="BI" <?= (isset($records[0]) && $records[0]->departamento == 'BI') ? 'selected' : null; ?>>BI</option>
                                            <option value="COMERCIAL" <?= (isset($records[0]) && $records[0]->departamento == 'COMERCIAL') ? 'selected' : null; ?>>
                                                COMERCIAL
                                            </option>
                                            <option value="customer_success" <?= (isset($records[0]) && $records[0]->departamento == 'customer_success') ? 'selected' : null; ?>>
                                                CUSTOMER
                                                SUCCESS</option>
                                            <option value="DESENVOLVIMENTO" <?= (isset($records[0]) && $records[0]->departamento == 'DESENVOLVIMENTO') ? 'selected' : null; ?>>
                                                DESENVOLVIMENTO</option>
                                            <option value="JURIDICO" <?= (isset($records[0]) && $records[0]->departamento == 'JURIDICO') ? 'selected' : null; ?>>JURIDICO
                                            </option>
                                            <option value="MARKETING" <?= (isset($records[0]) && $records[0]->departamento == 'MARKETING') ? 'selected' : null; ?>>
                                                MARKETING
                                            </option>
                                            <option value="MODELOS PREDITIVOS" <?= (isset($records[0]) && $records[0]->departamento == 'MODELOS PREDITIVOS') ? 'selected' : null; ?>>
                                                MODELOS
                                                PREDITIVOS</option>
                                            <option value="OPERACOES" <?= (isset($records[0]) && $records[0]->departamento == 'OPERACOES') ? 'selected' : null; ?>>
                                                OPERACÕES
                                            </option>
                                            <option value="PRODUTOS" <?= (isset($records[0]) && $records[0]->departamento == 'PRODUTOS') ? 'selected' : null; ?>>PRODUTOS
                                            </option>
                                            <option value="PRESIDENCIA" <?= (isset($records[0]) && $records[0]->departamento == 'PRESIDENCIA') ? 'selected' : null; ?>>
                                                PRESIDENCIA
                                            </option>
                                            <option value="SUPORTE" <?= (isset($records[0]) && $records[0]->departamento == 'SUPORTE ') ? 'selected' : null; ?>>SUPORTE
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="previsao_aquisicao">Previsão de aquisição</label>
                                        <input type="date" class="form-control" placeholder="<?= date('Y-m-d') ?>"
                                            name="previsao_aquisicao" id="previsao_aquisicao" />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="justificativa">Justificativa</label>
                                        <textarea type="text" class="form-control" placeholder="Jusiticativa da compra"
                                            name="justificativa" id="justificativa"> </textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success" id="btn_add_cotacacao"
                                style="font-size:10px;font-weight:bold">CRIAR</button>
                            <button type="button" class="btn btn-danger action_close_comissao" data-dismiss="modal"
                                style="font-size:10px;font-weight:bold">FECHAR</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- END MODAL NOVA COTAÇÃO -->


    <?php include "template/end-menu-wrapper.html" ?>
    <?php include 'template/scripts.inc' ?>
    <?php include "template/modal_sistema.php" ?>
    <script type="text/javascript" src="/assets/js/form-behaviors.js"></script>

    <script type="text/javascript" src="/libs/DataTables-1.10.13/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="/libs/DataTables-1.10.13/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript">
        $(function () {
            oTable = $('#table_cotacoes').DataTable({
                info: false,
                responsive: true,
                autoFill: true,
                dom: "<'panel panel-default'" +
                    "tr" +
                    "<'panel-footer'" +
                    "<'row'<'col-sm-5'l><'col-sm-7'p>>" +
                    ">" +
                    ">",
                language: {
                    "url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
                },
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    ['10 rows', '25 rows', '50 rows', 'Show all']
                ],
                lengthChange: false,
            });
        })


        $(document).on('click', '.delete_cotacao', function () {
            var id = $(this).val();
            if (confirm('Deseja realmente excluir essa cotação?')) {
                $.ajax({
                    url: '/compras/deleteCotacao/id/' + id,
                    method: 'POST',
                    beforeSend: function () {
                        waitingDialog.show('PROCESSANDO...');
                    },
                    success: function (data) {
                        waitingDialog.hide();
                        if (data.codigo == 1) {
                            $('#painel_success_msg').text(data.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('#modal_sucesso_sistema').on('hidden.bs.modal', function () {
                                window.location.reload();
                            });
                        } else {
                            $('#painel_error_msg').text(data.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    }, error: function (error) {
                        waitingDialog.hide();
                        $('#painel_error_msg').text(error.responseText);
                        $('#modal_erro_sistema').modal('show');
                    }
                })
            }
        });

        $('#nova_cotacao').click(function () {
            $('#modal_nova_cotacao').modal('show');
        });

        $('#modal_nova_cotacao').on('hide.bs.modal', function (event) {
            $('#form_nova_cotacao select').selectpicker('val', null);
            $('#form_nova_cotacao input').val('');
            $('#form_nova_cotacao textarea').val('');
        });


        $('#form_nova_cotacao').formValidation({
            framework: 'bootstrap',
            excluded: ':disabled',
            icon: {
                valid: 'fa fa-check',
                invalid: 'fa fa-times',
                validating: 'fa fa-refresh'
            },
            addOns: {
                mandatoryIcon: {
                    icon: 'fa fa-asterisk'
                }
            },
            fields: {
                tipo: {
                    validators: {
                        notEmpty: { message: "Campo Obrigatório" }
                    }
                },
                id_solicitante: {
                    validators: {
                        notEmpty: { message: "Campo Obrigatório" }
                    }
                },
                departamento: {
                    validators: {
                        notEmpty: { message: "Campo Obrigatório" }
                    }
                },
                previsao_aquisicao: {
                    validators: {
                        notEmpty: { message: "Campo Obrigatório" }
                    }
                },
                justificativa: {
                    validators: {
                        notEmpty: { message: "Campo Obrigatório" }
                    }
                }
            }
        }).on('success.form.fv', function (e) {
            e.preventDefault();
            $.ajax({
                url: '/compras/adicionarCotacao',
                method: 'POST',
                data: $('#form_nova_cotacao').serialize(),
                beforeSend: function () {
                    waitingDialog.show('PROCESSANDO...');
                },
                success: function (data) {
                    waitingDialog.hide();

                    $('#modal_nova_cotacao').modal('hide');
                    if (data.codigo == 1) {
                        $('#painel_success_msg').html(data.mensagem);
                        $('#modal_sucesso_sistema').modal('show');
                        $('#modal_sucesso_sistema').on('hidden.bs.modal', function () {
                            window.location.reload();
                        });
                    } else {
                        $('#painel_error_msg').html(data.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }
                }, error: function (error) {
                    waitingDialog.hide();
                    $('#painel_error_msg').text(error.responseText);
                    $('#modal_erro_sistema').modal('show');
                }
            })
        });

    </script>
</body>

</html>