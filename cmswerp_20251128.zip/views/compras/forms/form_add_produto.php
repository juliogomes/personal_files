<div id="div_orcamento" style="max-height: 80%;overflow: auto;">
    <input type="hidden" name="id_cotacao" value="<?= $cotacao->id ?>">
    <input type="hidden" id="id_orcamento" value="0">
    <input type="hidden" id="id_fornecedor" value="0">
    <div class="container-fluid">
        <?php if ($etapaAtual == 'elaboracao') { ?>
            <div class="col-md-12" style="margin-bottom: 10px;padding: 0">
                <a type="button" class="btn btn-primary" data-toggle="collapse" href="#form_add_orcamento" role="button"
                    aria-expanded="false" aria-controls="modal_adc_produto">
                    <i class="fa fa-plus"></i> <span id="">FORMULÁRIO PRODUTOS</span>
                </a>
            </div>

            <div id="form_add_orcamento" class="collapse">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="fornecedor">Fornecedor</label>
                            <select class="form-control select col-md-3" name="id_fornecedor" id="fornecedor">
                                <?php if ($fornecedores) {
                                    echo '<option value="">Selecione</option>';
                                    foreach ($fornecedores as $key => $value) { ?>
                                        <option value="<?= $value->id ?>" <?= in_array($value->id, $empresas_em_uso) ? 'disabled' : null ?>> <?= $value->razao_social ?> </option>
                                    <?php } ?>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="Autocomplete">Autocomplete Produto</label>
                            <!-- <select class="form-control select col-md-3" name="produtos_autocomplete"
                                id="produtos_autocomplete">
                            </select> -->
                            <input type="text" id="produtos_autocomplete" name="produtos_autocomplete" />
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="produtos">Produto</label>
                            <select class="form-control select col-md-3" name="id_produto" id="produto">
                            </select>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="valor">Valor</label>
                            <input type="text" class="form-control" id="valor" />
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="quantidade">Quantidade</label>
                            <input type="number" min="1" value="1" class="form-control" placeholder="" name="quantidade"
                                id="quantidade" />
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="total">Total</label>
                            <input type="text" class="form-control" id="total" disabled readonly />
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group col-md-2" style="padding: 0;">
                            <label for="">&nbsp</label>
                            <button value="<?= $value->id ?>" type="button" class="btn btn-success" id="btn_add_produto">
                                <i class="fa fa-plus"></i> Adicionar Produto</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>

        <hr>
        <h4>Produtos Selecionados</h4>
        <div class="row" id="div_produtos_selecionados">
            <table class="table table-default">
                <thead>
                    <tr>
                        <th>Produto ID</th>
                        <th>Nome</th>
                        <th>Quantidade</th>
                        <th>Valor</th>
                        <th>Total</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="tbody_produtos">
                </tbody>
            </table>
        </div>
        <hr>
        <h4>TOTAL: R$ <span id="total_cotacao"></span></h4>
    </div>
    <?php if ($etapaAtual == 'elaboracao') { ?>
        <div class="modal-footer">
            <button type="button" class="btn btn-success" id="btn_add_edit_cotacacao"
                style="font-size:10px;font-weight:bold">SALVAR</button>
            <button type="button" class="btn btn-danger action_close_comissao" data-dismiss="modal"
                style="font-size:10px;font-weight:bold">CANCELAR</button>
        </div>
        <span>SALVE PARA GUARDAR AS ALTERAÇÕES *</span>
    <?php } ?>
</div>

<script src="/libs/jquery/js/jquery-3.7.1.min.js"></script>

<script type="text/javascript">
    $(document).ready(function () {


        $('#produtos_autocomplete').autocomplete({
            // minLength: 1,
            // autoFocus: true,
            // delay: 300,
            // position: {
            //     my: 'left top',
            //     at: 'right top'
            // },
            // source: '/compras/autoCompleteProdutos',
            // onSelect: function (suggestion) {
            //     console.log(suggestion);
            // }
            // appendTo: '#produtos_autocomplete',
            source: function (request, response) {
                $.ajax({
                    url: '/compras/autoCompleteProdutos',
                    type: 'post',
                    dataType: 'json',
                    data: {
                        'search': request.term
                    }
                }).done(function (data) {
                    // obj = JSON.parse(data);   //parse the data in JSON (if not already)
                    response($.map(data, function (item) {
                        console.log(data)
                        return {
                            label: item.nome_reduzido,
                            value: item.id
                        }
                    }))
                });
            },
            //     select: function (event, ui) {
            //         console.log(ui);
            //         $('#produtos_autocomplete').val(ui.item.label);
            //         return false;
            //     }
        });
    })

    $(document).on('click', '.btn_remove_produto', function () {
        const tr_ir = $(this).attr('data-prod-id');
        $('tr[data-prod-id="' + tr_ir + '"]').remove();
        const tbody_produtos = $('#tbody_produtos');
        let total_cotacao = 0;
        tbody_produtos.find('tr').each(function () {
            const total = 0;
            const td = $(this).find('td[data-ref="total"]').text();
            total_cotacao += parseFloat(total);
        });
        $('#total_cotacao').text(total_cotacao.toFixed(2));

        if (tbody_produtos.find('tr').length == 0) {
            $('#fornecedor').prop('disabled', false);
            $('#fornecedor').selectpicker('refresh');
        }
    })

    $('#btn_add_produto').click(function () {
        const id_produto = $('#produto').val();
        const quantidade = $('#quantidade').val();
        const fornecedor = $('#fornecedor').selectpicker('val') ?? $('#id_fornecedor').val();
        const valor = $('#valor').val();
        const total = $('#total').val();
        if (!id_produto || !quantidade || !fornecedor || !valor || !total) {
            alert('Preencha todos os campos');
            return;
        }

        $('#fornecedor').prop('disabled', true);
        $('#fornecedor').selectpicker('refresh');

        if ($('#tbody_produtos').find('tr[data-prod-id="' + id_produto + '"]').length > 0) {
            const qtdAtual = $('#tbody_produtos').find('tr[data-prod-id="' + id_produto + '"] td[data-ref="quantidade"]').text();
            const totalAtual = $('#tbody_produtos').find('tr[data-prod-id="' + id_produto + '"] td[data-ref="total"]').text();
            const qtdNova = parseInt(qtdAtual) + parseInt(quantidade);
            const totalNova = parseInt(totalAtual) + parseInt(total);
            $('#tbody_produtos').find('tr[data-prod-id="' + id_produto + '"] td[data-ref="quantidade"]').text(qtdNova);
            $('#tbody_produtos').find('tr[data-prod-id="' + id_produto + '"] td[data-ref="total"]').text(totalNova.toFixed(2));
        } else {
            $('#tbody_produtos').append(`
            <tr data-prod-id="${id_produto}" data-deleted="0" data-orcamento-id="0">
                <td><i class="fa fa-plus" style="color:green"></i> ${id_produto}</td>
                <td>${$('#produto').find('option:selected').text()}</td>
                <td data-ref="quantidade">${quantidade}</td>
                <td data-ref="valor">${valor}</td>
                <td data-ref="total">${total}</td>
                <td>
                 <?php if ($etapaAtual == 'elaboracao') { ?> 
                     <button type="button" class="btn btn-danger btn-sm btn_remove_produto" data-prod-id="${id_produto}"><i class="fa fa-trash"></i></button>
                <?php } ?> 
                </td>
            </tr>
        `);
        }

        const tr = $('#tbody_produtos');
        let total_cotacao = 0;
        tr.find('tr').each(function () {
            const total = $(this).find('td[data-ref="total"]').text();
            total_cotacao += parseFloat(total);
        });
        $('#total_cotacao').text(total_cotacao.toFixed(2));
    })

    $('#quantidade').on('change', function () {
        const quantidade = $(this).val();
        const valor = $('#valor').val().replace(',', '.')
        if (!valor) {
            return;
        }
        const total = quantidade * valor;
        $('#total').val(total).maskMoney('mask', total);
    })

    // $(document).on('change', '#produto', function (e) {
    //     const valor = $(this).find('option:selected').attr('data-valor');
    //     $('#valor').val(valor);
    //     $('#total').val(valor).maskMoney('mask', valor);
    // })

    $('#fornecedor').on('change', function () {
        const id_fornecedor = $(this).val();
        $('#div_orcamento #id_fornecedor').val(id_fornecedor);
        obtemProdutosByFornecedor(id_fornecedor);
    });

    function obtemProdutosByFornecedor(id_fornecedor) {
        const function_success = function (data) {
            if (data.output && data.output.length > 0) {
                let html = '<option value="">Selecione</option>';
                for (let i = 0; i < data.output.length; i++) {
                    html += '<option value="' + data.output[i].id + '" data-valor="' + data.output[i].valor + '">Descrição: ' + data.output[i].nome + '| Marca: ' + data.output[i].marca + ' | Modelo: ' + data.output[i].modelo + '</option>';
                }
                $('#produto').html(html);
            }
            $('#produto').selectpicker({ liveSearch: true }).selectpicker('refresh');
        }

        $('#produto').selectpicker('destroy');
        ajax('/compras/obtemProdutosByFornecedor/id/' + id_fornecedor, 'POST', '', function_success, error_default, true, false);
    }

    $('#btn_add_edit_cotacacao').on('click', function () {
        const id_orcamento = $('#div_orcamento #id_orcamento').val();
        const id_fornecedor = $('#div_orcamento #id_fornecedor').val();
        const id_cotacao = '<?= $cotacao->id ?>'
        const total = $('#total_cotacao').text();
        let produtos = [];

        const tbody_produtos = $('#tbody_produtos');
        if (tbody_produtos.find('tr').length == 0) {
            alert('Nenhum produto adicionado');
            return;
        }
        tbody_produtos.find('tr').each(function () {
            const id_produto = $(this).find('td').eq(0).text();
            const data_orcamento_id = $(this).attr('data-orcamento-id');
            const deleted = $(this).attr('data-deleted');
            const quantidade = $(this).find('td[data-ref="quantidade"]').text();
            const valor = $(this).find('td[data-ref="valor"]').text();
            const total = $(this).find('td[data-ref="total"]').text();

            produtos.push({
                data_orcamento_id,
                id_produto,
                id_fornecedor,
                id_cotacao,
                quantidade,
                deleted,
            });
        });

        const new_data = {
            dados_cotacao: {
                id_cotacao,
                id_fornecedor,
                id_orcamento,
                total,
                type: 'compra'
            },
            dados_produtos: produtos
        };
        ajax('/compras/adicionarEditarOrcamento/id/<?= $cotacao->id ?>', 'POST', JSON.stringify(new_data), success_modal_reload_page, error_default, true, false);
    });

    $('.btn_definir_ganho').on('click', function () {//COMPRAS E SERVICOS
        if (confirm('Tem certeza que deseja definir o orçamento como ganho?')) {
            const data = {
                id_orcamento: $(this).val(),
                id_cotacao: '<?= $cotacao->id ?>'
            }
            ajax('/compras/definirganhoorcamento', 'POST', data, success_modal_reload_page, error_default, true, false)
        }
    })

    $('.btn_delete_orcamento').on('click', function () {//COMPRAS E SERVICOS
        if (confirm('Tem certeza que deseja excluir o orçamento?')) {
            const data = {
                id_orcamento: $(this).val()
            }
            ajax('/compras/deleteorcamento', 'POST', data, success_modal_reload_page, error_default, true, false)
        }
    })

    $(document).on('click', '.btn_remove_produto_edit', function () {//COMPRAS E SERVICOS
        $(this).closest('tr').attr('data-deleted', '1');
        $(this).closest('tr').find('td').addClass('tr_deletada');
        $(this).closest('tr').find('.btn_return_produto_edit').show();
        $(this).hide();
        let total_cotacao = 0;
        $(this).closest('table').find('td[data-ref="total"]:not(.tr_deletada)').each(function () {
            let valor = $(this).text();
            total_cotacao += parseFloat(valor)
        })
        $('#total_cotacao').text(total_cotacao.toFixed(2));
    })

    $(document).on('click', '.btn_return_produto_edit', function () {//COMPRAS E SERVICOS
        $(this).closest('tr').find('td').removeClass('tr_deletada');
        $(this).closest('tr').attr('data-deleted', '0');
        $(this).closest('tr').find('.btn_remove_produto_edit').show();
        $(this).hide();
        let total_cotacao = 0;
        $(this).closest('table').find('td[data-ref="total"]:not(.tr_deletada)').each(function () {
            let valor = $(this).text();
            total_cotacao += parseFloat(valor)
        })
        $('#total_cotacao').text(total_cotacao.toFixed(2));
    })

    $('#modal_add_proposta').on('hidden.bs.modal', function () {//COMPRAS E SERVICOS
        $(this).find('select').selectpicker('val', '').selectpicker('refresh');
        $(this).find('input').val('');
        $(this).find('#quantidade').val(1);
        $('#div_orcamento #id_orcamento').val('0');
        $(this).find('#total_cotacao').text('');
        $(this).find('#tbody_produtos').html('');
        $(this).find('#fornecedor').prop('disabled', false);
        $('#form_add_orcamento').collapse('hide');
    })

    $(document).on('click', '.btn_visualizar_orcamento', function () {//COMPRAS E SERVICOS
        let id_cotacao = '<?= $cotacao->id ?>';
        let id_orcamento = $(this).val();
        let tipo = '<?= $cotacao->tipo ?>';
        let fornecedor_id = $(this).closest('tr').find('td[data-fornecedor-id]').attr('data-fornecedor-id');
        $('#div_orcamento #id_orcamento').val(id_orcamento);
        $('#div_orcamento #id_fornecedor').val(fornecedor_id);

        const data = { id_cotacao, id_orcamento, tipo }

        const function_success = function (data) {
            obtemProdutosByFornecedor(fornecedor_id);
            let produtos = data.output.dados;
            let valorTotal = 0;
            $('#fornecedor').selectpicker('val', fornecedor_id).selectpicker('refresh');
            $('#fornecedor').prop('disabled', true);
            if (produtos) {

                for (let i = 0; i < produtos.length; i++) {
                    valorTotal += parseFloat(produtos[i].valor * produtos[i].quantidade);
                    $('#tbody_produtos')
                        .append(`
                        <tr data-orcamento-id=${produtos[i].cotacao_produto_id} data-prod-id="${produtos[i].produto_id}" class="tr_deletavel" data-deleted="0" data-orcamento-id="${produtos[i].cotacao_produto_id}" >
                            <td>${produtos[i].produto_id}</td>
                            <td>Produto: ${produtos[i].nome_produto} | Descrição: ${produtos[i].marca} | Modelo: ${produtos[i].modelo}</td>
                            <td data-ref="quantidade">${produtos[i].quantidade}</td>
                            <td data-ref="valor">${parseFloat(produtos[i].valor).toFixed(2)}</td>
                            <td data-ref="total">${parseFloat(produtos[i].valor * produtos[i].quantidade).toFixed(2)}</td>
                            <td>
                            <?php if ($etapaAtual == 'elaboracao') { ?> 
                                <button type="button" class="btn btn-danger btn-sm btn_remove_produto_edit" ><i class="fa fa-trash"></i></button>
                                <button type="button" class="btn btn-info btn-sm btn_return_produto_edit btn_hide"><i class="fa fa-rotate-left"></i></button>
                                <?php } ?> 
                            </td>
                        </tr>`);
                }
            }

            $('#total_cotacao').text(valorTotal.toFixed(2));
            $('#text_add_proposta').text('EDITAR ORÇAMENTO');
            $('#modal_add_proposta').modal('show');
        }
        ajax('/compras/obterdadosorcamento', 'POST', data, function_success, error_default, true, false);
    })

</script>