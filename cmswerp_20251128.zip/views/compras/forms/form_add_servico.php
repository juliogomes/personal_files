<div id="div_orcamento" style="max-height: 80%;overflow: auto;">
    <input type="hidden" name="id_cotacao" value="<?= $cotacao->id ?>">
    <input type="hidden" id="id_orcamento" value="0">
    <input type="hidden" id="id_fornecedor" value="0">
    <div class="container-fluid">
        <?php if ($etapaAtual == 'elaboracao') { ?>

            <div class="col-md-12" style="margin-bottom: 10px;padding: 0">
                <a type="button" class="btn btn-primary" data-toggle="collapse" href="#form_add_orcamento" role="button"
                    aria-expanded="false" aria-controls="modal_adc_servico">
                    <i class="fa fa-plus"></i> <span id="">FORMULÁRIO SERVIÇOS</span>
                </a>
            </div>

            <div id="form_add_orcamento" class="collapse">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="fornecedor">Fornecedor</label>
                            <select class="form-control select col-md-3" name="id_fornecedor" id="fornecedor">
                                <?php if ($fornecedores) {
                                    echo '<option value="">Selecione</option>';
                                    foreach ($fornecedores as $key => $value) { ?>
                                        <option value="<?= $value->id ?>" <?= in_array($value->id, $empresas_em_uso) ? 'disabled' : null ?>> <?= $value->razao_social ?> </option>
                                    <?php } ?>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="categoria">Categoria</label>
                            <input type="text" class="form-control" name="categoria" id="categoria">
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                            <label for="valor">Valor</label>
                            <input type="text" class="form-control" id="valor" />
                        </div>
                    </div>
                    <div class="col-md-10">
                        <div class="form-group">
                            <label for="descricao">Descrição</label>
                            <input type="text" class="form-control" name="servico_descricao" id="servico_descricao">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group col-md-2" style="padding: 0;">
                            <label for="">&nbsp</label>
                            <button value="<?= $value->id ?>" type="button" class="btn btn-success" id="btn_add_servico">
                                <i class="fa fa-plus"></i> Adicionar Serviço</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>

        <hr>
        <h4>Serviços Selecionados</h4>
        <div class="row" id="div_servicos_selecionados">
            <table class="table table-default">
                <thead>
                    <tr>
                        <th>Descrição</th>
                        <th width="10%">Categoria</th>
                        <th width="10%">Valor</th>
                        <th width="10%">Ações</th>
                    </tr>
                </thead>
                <tbody id="tbody_servicos">
                </tbody>
            </table>
        </div>
        <hr>
        <h4>TOTAL: R$ <span id="total_cotacao"></span></h4>
    </div>
    <?php if ($etapaAtual == 'elaboracao') { ?>
        <div class="modal-footer">
            <button type="button" class="btn btn-success" id="btn_add_edit_cotacacao"
                style="font-size:10px;font-weight:bold">SALVAR</button>
            <button type="button" class="btn btn-danger action_close_comissao" data-dismiss="modal"
                style="font-size:10px;font-weight:bold">CANCELAR</button>
        </div>
        <span>SALVE PARA GUARDAR AS ALTERAÇÕES *</span>
    <?php } ?>
</div>

<script src="/libs/jquery/js/jquery-3.7.1.min.js"></script>

<script type="text/javascript">

    $(document).ready(function () {
        $('#valor').maskMoney({ decimal: ',', thousands: '.' });
    })

    $('#fornecedor').on('change', function () {
        const id_fornecedor = $(this).val();
        $('#div_orcamento #id_fornecedor').val(id_fornecedor);
    });

    $(document).on('click', '.btn_remove_servico', function () {
        const tr_ir = $(this).closest('tr').remove();
        const tbody_servicos = $('#tbody_servicos');
        let total_cotacao = 0;
        tbody_servicos.find('tr').each(function () {
            const total = 0;
            const td = $(this).find('td[data-ref="valor"]').text();
            total_cotacao += parseFloat(total);
        });
        $('#total_cotacao').text(total_cotacao.toFixed(2));

        if (tbody_servicos.find('tr').length == 0) {
            $('#fornecedor').prop('disabled', false);
            $('#fornecedor').selectpicker('refresh');
        }
    })

    $('#btn_add_servico').click(function () {
        const fornecedor = $('#fornecedor').selectpicker('val') ?? $('#id_fornecedor').val();
        const descricao = $('#servico_descricao').val();
        const categoria = $('#categoria').val();
        const valor = $('#valor').val();
        if (!fornecedor || !descricao || !categoria || !valor) {
            alert('Preencha todos os campos');
            return;
        }

        $('#fornecedor').prop('disabled', true);
        $('#fornecedor').selectpicker('refresh');

        $('#tbody_servicos').append(`
            <tr data-deleted="0" data-orcamento-id="0">
                <td data-ref="descricao"><i class="fa fa-plus" style="color:green"></i> ${descricao}</td>
                <td width="10%" data-ref="categoria">${categoria}</td>
                <td width="10%" data-ref="valor">${valor}</td>
                <td width="10%">
                    <button type="button" class="btn btn-danger btn-sm btn_remove_servico" ><i class="fa fa-trash"></i></button>
                </td>
            </tr>
        `);

        const tr = $('#tbody_servicos');
        let total_cotacao = 0;
        tr.find('tr').each(function () {
            const total = $(this).find('td[data-ref="valor"]').text();
            total_cotacao += parseFloat(total);
        });
        $('#total_cotacao').text(total_cotacao.toFixed(2));
    })

    $('#btn_add_edit_cotacacao').on('click', function () {
        const id_orcamento = $('#div_orcamento #id_orcamento').val();
        const id_fornecedor = $('#div_orcamento #id_fornecedor').val();
        const id_cotacao = '<?= $cotacao->id ?>'
        const total = $('#total_cotacao').text();
        let servicos = [];

        const tbody_servicos = $('#tbody_servicos');
        if (tbody_servicos.find('tr').length == 0) {
            alert('Nenhum servico adicionado');
            return;
        }
        tbody_servicos.find('tr').each(function () {
            const data_orcamento_id = $(this).attr('data-orcamento-id');
            const descricao = $(this).find('td[data-ref="descricao"]').text();;
            const categoria = $(this).find('td[data-ref="categoria"]').text();
            const valor = $(this).find('td[data-ref="valor"]').text();
            const deleted = $(this).attr('data-deleted');

            servicos.push({
                data_orcamento_id,
                descricao,
                categoria,
                id_fornecedor,
                valor,
                id_cotacao,
                deleted,
            });
        });

        const new_data = {
            dados_cotacao: {
                id_cotacao,
                id_fornecedor,
                id_orcamento,
                total,
                type: 'servico'

            },
            dados_servicos: servicos
        };
        ajax('/compras/adicionarEditarOrcamento/id/<?= $cotacao->id ?>', 'POST', JSON.stringify(new_data), success_modal_reload_page, error_default, true, false);
    });

    $('.btn_definir_ganho').on('click', function () {//COMPRAS E SERVICOS
        if (confirm('Tem certeza que deseja definir o orçamento como ganho?')) {
            const data = {
                id_orcamento: $(this).val(),
                id_cotacao: '<?= $cotacao->id ?>'
            }
            ajax('/compras/definirganhoorcamento', 'POST', data, success_modal_reload_page, error_default, true, false)
        }
    })

    $('.btn_delete_orcamento').on('click', function () {//COMPRAS E SERVICOS
        if (confirm('Tem certeza que deseja excluir o orçamento?')) {
            const data = {
                id_orcamento: $(this).val()
            }
            ajax('/compras/deleteorcamento', 'POST', data, success_modal_reload_page, error_default, true, false)
        }
    })

    $(document).on('click', '.btn_remove_servico_edit', function () {//COMPRAS E SERVICOS
        $(this).closest('tr').attr('data-deleted', '1');
        $(this).closest('tr').find('td').addClass('tr_deletada');
        $(this).closest('tr').find('.btn_return_servico_edit').show();
        $(this).hide();
        let total_cotacao = 0;
        $(this).closest('table').find('td[data-ref="valor"]:not(.tr_deletada)').each(function () {
            let valor = $(this).text();
            total_cotacao += parseFloat(valor)
        })
        $('#total_cotacao').text(total_cotacao.toFixed(2));
    })

    $(document).on('click', '.btn_return_servico_edit', function () {//COMPRAS E SERVICOS
        $(this).closest('tr').find('td').removeClass('tr_deletada');
        $(this).closest('tr').attr('data-deleted', '0');
        $(this).closest('tr').find('.btn_remove_servico_edit').show();
        $(this).hide();
        let total_cotacao = 0;
        $(this).closest('table').find('td[data-ref="valor"]:not(.tr_deletada)').each(function () {
            let valor = $(this).text();
            total_cotacao += parseFloat(valor)
        })
        $('#total_cotacao').text(total_cotacao.toFixed(2));
    })

    $('#modal_add_proposta').on('hidden.bs.modal', function () {//COMPRAS E SERVICOS
        $(this).find('select').selectpicker('val', '').selectpicker('refresh');
        $(this).find('input').val('');
        $(this).find('#quantidade').val(1);
        $('#div_orcamento #id_orcamento').val('0');
        $(this).find('#total_cotacao').text('');
        $(this).find('#tbody_servicos').html('');
        $(this).find('#fornecedor').prop('disabled', false);
        $('#form_add_orcamento').collapse('hide');

    })

    $(document).on('click', '.btn_visualizar_orcamento', function () {//COMPRAS E SERVICOS
        let id_cotacao = '<?= $cotacao->id ?>';
        let id_orcamento = $(this).val();
        let tipo = '<?= $cotacao->tipo ?>';
        let fornecedor_id = $(this).closest('tr').find('td[data-fornecedor-id]').attr('data-fornecedor-id');
        $('#div_orcamento #id_orcamento').val(id_orcamento);
        $('#div_orcamento #id_fornecedor').val(fornecedor_id);
        const data = {
            id_cotacao,
            id_orcamento,
            tipo
        }

        const function_success = function (data) {
            let servicos = data.output.dados;
            let valorTotal = 0;
            $('#div_orcamento #id_fornecedor').val(fornecedor_id);
            $('#fornecedor').selectpicker('val', fornecedor_id).selectpicker('refresh');
            $('#id_fornecedor').val(fornecedor_id);
            $('#fornecedor').prop('disabled', true);
            if (servicos) {
                for (let i = 0; i < servicos.length; i++) {
                    valorTotal += parseFloat(servicos[i].valor);
                    $('#tbody_servicos')
                        .append(`
                        <tr data-orcamento-id=${servicos[i].cotacao_servico_id} class="tr_deletavel" data-deleted="0" data-orcamento-id="${servicos[i].cotacao_servico_id}" >
                            <td data-ref="descricao">${servicos[i].descricao}</td>
                            <td data-ref="categoria">${servicos[i].categoria}</td>
                            <td data-ref="valor">${parseFloat(servicos[i].valor).toFixed(2)}</td>
                            <td>
                                <button type="button" class="btn btn-danger btn-sm btn_remove_servico_edit" ><i class="fa fa-trash"></i></button>
                                <button type="button" class="btn btn-info btn-sm btn_return_servico_edit btn_hide"><i class="fa fa-rotate-left"></i></button>
                            </td>
                        </tr>`);
                }
            }

            $('#total_cotacao').text(valorTotal.toFixed(2));
            $('#text_add_proposta').text('EDITAR ORÇAMENTO');
            $('#modal_add_proposta').modal('show');
        }

        ajax('/compras/obterdadosorcamento', 'POST', data, function_success, error_default, true, false);
    })


</script>