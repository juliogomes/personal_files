<?php// ob_start(); ?>
<!doctype html>
<html class="no-js" lang="">
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "configuracoes";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Configuracoes</li>
        <li>Alertas / Notificações</li>
	</ol>
	<h4 class="page-title">
        ALERTAS / NOTIFICAÇÕES
	</h4>  
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-12">
				<form id="alerta_save" name="alerta_save" method="post">
					<fieldset>
						<legend>ADICIONAR </legend>
						<div class="row">  
                            <div class="col-md-12"> 
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="usuario">Usuários:</label>
                                        <select id="usuario" name='usuario' class="search form-control">
                                            <option value="" selected>Selecione</option>
                                            <?php foreach ($usuarios as $key => $value) { ?>
                                                    <?="<option value='$value->id'>".strtoupper($value->nome)."</option>";?>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>                                                                                                     
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="objeto">Objeto:</label>
                                        <select id="objeto" name='objeto' class="search form-control">
                                            <option value="" selected>Selecione</option>
                                            <option value="proposta">PROPOSTA</option>
                                            <option value="minuta"> MINUTA</option>                                                
                                            <option value="contrato"> CONTRATO</option>                                           
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="alerta">Receber Alerta:</label>
                                        <select id="alerta" name='alerta' class="search form-control">
                                            <option value="" selected>Selecione</option>
                                            <option value="0">SIM</option>
                                            <option value="1">NÃO</option>                                           
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="ordem">Adicionar:</label>
                                        <button type="button" id="salvar_alerta" class="form-control btn btn-success" style="font-weight:bold">
                                            <i class="fa fa-save"></i> ADICIONAR
                                        </button>
                                    </div>
                                </div>  
                            </div>                         
						</div>	
                        <hr>					
					</fieldset>
				</form>
			</div>
            <div class="col-md-12">
                <div class="col-md-12">
                    <fieldset>
                        <legend style="text-align:center;font-size:16px; letter-spacing: 0.8em;">CONTATOS C&M SOFTWARE</legend>  
                    <fieldset>
                    <table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
                        <thead>
							<tr role="row">
								<th width="200" class="text-left" style="vertical-align:middle">NOME</th>
                                <th  width="20" class="text-center"  style="vertical-align:middle">OBJETO</th>							
                                <th  width="20" class="text-center"  style="vertical-align:middle">E-MAIL</th>		
                                <th  width="20" class="text-center"  style="vertical-align:middle">DEPARTAMENTO</th>		
                                <th  width="20" class="text-center"  style="vertical-align:middle">ALERTA</th>	
                                <th  width="20" class="text-center"  style="vertical-align:middle">DELETAR</th>							
							</tr>
						</thead>
						<tbody>
                            <?php if(isset($get_alerta) && is_array($get_alerta)){ ?>
                                <?php foreach ($get_alerta as $key => $value) { ?>                           
                                    <tr>                                        
                                        <td class="text-left" style="vertical-align:middle;font-size:14px">
                                            <span class="label-status"><?=strtoupper($value->nome)?></span>
                                        </td>
                                        <td class="text-center" style="vertical-align:middle;font-size:14px">
                                            <span class="label-status"><?=strtoupper($value->objeto)?></span>
                                        </td>								
                                        <td class="text-center" style="vertical-align:middle;font-size:14px">								
                                           <?=$value->email;?>									
                                        </td>
                                        <td class="text-center" style="vertical-align:middle;font-size:14px">								
                                           <?=$value->departamento;?>									
                                        </td>                                       
                                        <td class="text-center">	
                                            <?php
                                                if($value->alerta == 0){
                                                    echo "<button class='btn btn-success' style='font-weight:bold'>RECEBENDO</button>";
                                                }else{
                                                    echo "<button class='btn btn-warning' style='font-weight:bold'>SUSPENSO</button>";
                                                }	
                                            ?>	                                           								
                                        </td>
                                        <td class="text-center">                                            
                                            <button class='btn btn-danger excluir' value="<?=$value->id;?>"  style='font-weight:bold'> <i class='fa fa-trash-o'> </i></button>                                            	                                           								
                                        </td>
                                    </tr>	
                                <?php } ?>		
                            <?php }else{ ?>	
                                <tr>	
                                    <td colspan="6" style="text-align:center">Sem configuração</td> 
                                </tr> 
                            <?php } ?>
						</tbody>
					</table>  
                    
                </div>                   
            </div>
		</div>
	</div>	
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->

	<!-- MODALS -->
   
	<!-- /MODALS -->

	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
    <?php include "template/modal_sistema.php" ?>
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
  
	<!-- PAGE SCRIPTS -->
    <script>
        $(document).ready(function(){
            <?php if(isset($get_alerta) && is_array($get_alerta)){ ?>
                oTable = $('#list').DataTable({	
                    "order": [
                        [ 1, "desc" ]
                    ],                    
                    info: false,                                        
                    language: {
                        "url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
                    },  
                    pageLength: 20,                          
                    lengthMenu: [
                        [ 25, 50, 75, -1 ],
                        [ '25 linhas', '50 linhas', '75 linhas', 'Tudo' ],
                    ],
                    lengthMenu: true,
                    dom: 'Bfrtip',
                });
            <?php } ?>
            

            $("#salvar_alerta").click(function(){               
                ajaxAddAlerta();
            });

            function ajaxAddAlerta(){
                url = "<?=HOME_URI.$this->nome_modulo.'/addAlerta/'?>";    
                form = $("#alerta_save").serialize();                           
                $.ajax({
                    url:url,    
                    data:form,                
                    type:"POST",
                    beforeSend: function(){
                        waitingDialog.show("PROCESSANDO...");
                    },
                    success: function(dados){
                        waitingDialog.hide();
                        retorno = JSON.parse(dados);
                        if(retorno.codigo == 0){
                            $('#painel_success_msg').text(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('#modal_sucesso_sistema').on('hidden.bs.modal', function() {
                                window.location.href = "/configuracoes/alerta"; 
                            });   
                        }else{
                            $('#painel_error_msg').text(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function(){
                        $('#painel_error_msg').text(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }                
                });
            }

            function deletarAlerta(id){
                url = "<?=HOME_URI.$this->nome_modulo.'/deletarAlerta/'?>"+id;                                               
                $.ajax({
                    url:url,    
                    type:"POST",
                    beforeSend: function(){
                        waitingDialog.show("PROCESSANDO...");
                    },
                    success: function(dados){
                        waitingDialog.hide();
                        retorno = JSON.parse(dados);
                        if(retorno.codigo == 0){
                            $('#painel_success_msg').text(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('#modal_sucesso_sistema').on('hidden.bs.modal', function() {
                                window.location.href = "/configuracoes/alerta"; 
                            });   
                        }else{
                            $('#painel_error_msg').text(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function(){
                        $('#painel_error_msg').text(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }                
                });
            }

            $(".excluir").click(function(){
                id = $(this).val();
                deletarAlerta(id);
            })
           

        });
    </script>
    <!-- /PAGE SCRIPTS -->
</body>
</html>