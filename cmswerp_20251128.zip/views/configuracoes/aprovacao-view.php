<?php// ob_start(); ?>
<!doctype html>
<html class="no-js" lang="">
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "configuracoes";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Configuracoes</li>
	</ol>
	<h4 class="page-title">
		Configurações
	</h4>  
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-12">
				<form id="fluxo_save" name="fluxo_save" method="post" >
					<fieldset>
						<legend>ADICIONAR NOVA CONFIGURAÇÃO DE FLUXO</legend>
						<div class="row">
							<div class="col-md-2">
								<div class="form-group">
									<label for="id_empresa">Empresa:</label>
									<select id="id_empresa" name="id_empresa" class="form-control select">
                                        <option value="" selected>Selecione...</option>
                                        <?php if( $lista_empresas ){ ?>
                                            <?php foreach( $lista_empresas as $key => $value ){ ?>
                                                <option value="<?= strtoupper( $value->id ); ?>" selected><?= strtoupper( $value->razao_social ); ?></option>
                                            <?php } ?>
                                        <?php } ?>
									</select>
								</div>
							</div>
                            <div class="col-md-2">
								<div class="form-group">
									<label for="objeto">Objeto:</label>
									<select id="objeto" name="objeto" class="form-control select">
                                        <option value="" selected>Selecione</option>
										<option value="proposta">PROPOSTA</option>					
                                        <option value="minuta">MINUTA</option>		
									</select>
								</div>
							</div>	
                            <div class="col-md-2">
								<div class="form-group">
									<label for="acao">Ação:</label>
									<select id="acao" name="acao" class="form-control select">
                                        <option value="" selected>Selecione</option>
										<option value="aprovar">APROVAR</option>												
									</select>
								</div>
							</div>							
							<div class="col-md-2">
								<div class="form-group">
									<label for="id_usuario">Aprovadores:</label>
									<select id="id_usuario" name='id_usuario' class="form-control select">
                                        <option value="" selected>Selecione</option>
										<?php foreach($usuarios as $key => $value){ ?>
											echo '<option value="'.$value->id.'" >'.strtoupper($value->nome).'</option>';																						
										<?php } ?>
									</select>
								</div>
							</div>
                            <div class="col-md-2">
								<div class="form-group">
									<label for="ordem">Ordem de aprovação:</label>
									<select id="ordem" name='ordem' class="form-control select">
                                        <option value="" selected>Selecione</option>
                                        <option value="1">1° APROVAR</option>
										<option value="2">2° APROVAR</option>
                                        <option value="3">3° APROVAR</option>
                                        <option value="4">4° APROVAR</option>
                                        <option value="5">5° APROVAR</option>
									</select>
								</div>
							</div>
                            <div class="col-md-2">
								<div class="form-group">
									<label for="ordem">Salvar:</label>
                                    <button type="button" id="salvar_fluxo" class="form-control btn btn-primary"><i class="fa fa-save"></i> Salvar</button>
								</div>
							</div>                            
						</div>	
                        <hr>					
					</fieldset>
				</form>
			</div>
            <div class="col-md-12">
                <div class="col-md-12">
                    <fieldset>
                        <legend style="text-align:center;font-size:16px; letter-spacing: 0.8em;">CONFIGURAÇÃO DE FLUXO</legend>  
                    <fieldset>
                    <table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
                        <thead>
							<tr role="row">
								<th width="80" class="text-left"   style="vertical-align:middle">ID EMPRESA</th>
                                <th width="80" class="text-left"   style="vertical-align:middle">NOME EMPRESA</th>
                                <th width="80" class="text-left"   style="vertical-align:middle">OBJETO</th>
								<th width="20" class="text-center" style="vertical-align:middle">DETALHE</th>								
							</tr>
						</thead>
						<tbody>
                            <?php if( isset( $fluxo_aprovacao ) && is_array( $fluxo_aprovacao ) ){ ?>
                                <?php foreach ( $fluxo_aprovacao as $key => $value ){ ?>  
                                    <tr>
                                        <td class="text-left" style="vertical-align:middle">
                                            <span class="label-status"><small></small><?= strtoupper( str_replace("_"," ", $value->id_empresa) ); ?></span>
                                        </td>
                                        <td class="text-left" style="vertical-align:middle">
                                            <span class="label-status"><small></small><?= strtoupper( str_replace("_"," ", $value->nome_empresa) ); ?></span>
                                        </td>
                                        <td class="text-left" style="vertical-align:middle">
                                            <span class="label-status"><small></small><?= strtoupper( str_replace("_"," ", $value->objeto) ); ?></span>
                                        </td>								
                                        <td class="text-center">								
                                            <button type="button" class="btn btn-info detalhe_fluxo" data-empresa="<?= $value->id_empresa; ?>" value="<?= $value->objeto; ?>">
                                                <i class="fa fa-edit"></i> 
                                            </button>										
                                        </td>
                                    </tr>	
                                <?php } ?>		
                            <?php }else{ ?>	
                                <tr><td colspan="2" style="text-align:center">Sem configuração</td></tr> 
                            <?php } ?>
						</tbody>
					</table>
                </div>
            </div>
		</div>
	</div>	
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->

	<!-- MODALS -->
    <!-- MODAL DETALHE FLUXO APROVAÇÃO -->
    <div class="modal fade" id="modal_detalhe_fluxo" tabindex="-1" role="dialog" >
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close action_close" data-dismiss="modal" >
                        <span>x</span>
                    </button>
                    <fieldset>
                        <h2 style="text-align:center;font-size:16px; letter-spacing: 0.8em;">DETALHE FLUXO APROVAÇÃO</h2>
                    </fieldset>
                </div>               
                <div class="modal-body">                       
                    <br>
                    <div class="container-fluid">
                        <div class="col-md-12" style="overflow:auto;">
                            <table class="table table-default table-striped table-bordered table-hover display responsive nowrap" width="100%">
                                <thead id="thead_detalhe">
                                    <tr role="row" style="">                                 
                                        <th id="th_id" class="text-center" style="font-size:10px;vertical-align:middle;"> OBJETO </th>
                                        <th id="th_id" class="text-center" style="font-size:10px;vertical-align:middle;"> ID USUARIO </th>
                                        <th id="th_id" class="text-center" style="font-size:10px;vertical-align:middle;"> APROVADOR </th>
                                        <th id="th_id" class="text-center" style="font-size:10px;vertical-align:middle;"> ORDEM APROVAÇÃO </th> 
                                        <th id="th_id" class="text-center" style="font-size:10px;vertical-align:middle;"> DELETAR </th>                                                                                                       
                                    </tr>
                                </thead>
                                <tbody id="tbody_detalhe">
                                    
                                </tbody>                
                            </table>
                        </div>
                    </div>                                    
                </div>                
                <div class="modal-footer">					
                    <button type="button" class="btn btn-danger action_close" data-dismiss="modal" style="font-size:10px;font-weight:bold" >FECHAR</button>                    
                </div>
            </div>
        </div>
	</div>  
    <!-- END MODAL DETALHE  FLUXO APROVAÇÃO -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
    <?php include "template/modal_sistema.php" ?>
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
  
	<!-- PAGE SCRIPTS -->
    <script>
        $(document).ready(function(){
            $('#salvar_fluxo').click(function(){
                ajaxFluxo();
            });

            $( '.detalhe_fluxo' ).click( function(){
                var objeto  = $(this).val();  
                var empresa = $(this).data('empresa');
                // console.log(objeto, empresa);                             
                ajaxDetalhe( empresa, objeto );
            });

            $('#modal_detalhe_fluxo').on('hide.bs.modal', function (event) {
                window.location.href = "/configuracoes/fluxoAprovacao"; 
            });           

            function ajaxFluxo(){
                url = "<?=HOME_URI.$this->nome_modulo.'/newSave/'?>";
                form = $('#fluxo_save').serialize();                
                $.ajax({
                    url:url,
                    data:form,
                    type:"POST",
                    beforeSend: function(){
                        waitingDialog.show("PROCESSANDO...");
                    },
                    success: function(dados){
                        waitingDialog.hide();
                        retorno = JSON.parse(dados);
                        if(retorno.codigo == 0){
                            $('#painel_success_msg').text(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('#modal_sucesso_sistema').on('hidden.bs.modal', function() {
                                window.location.href = "/configuracoes/fluxoAprovacao"; 
                            });   
                        }else{
                            $('#painel_error_msg').text(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function(){
                        $('#painel_error_msg').text(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }                
                });
            }

            function ajaxDetalhe( $empresa, objeto ){
                url = "<?= HOME_URI.$this->nome_modulo.'/detalheFluxoAprovacao/'?>"+objeto+"/"+$empresa;           
                tbody = $('#tbody_detalhe');
                $.ajax({
                    url:url,                   
                    type:"POST",
                    beforeSend: function(){
                        waitingDialog.show("PROCESSANDO...");
                    },
                    success: function(dados){
                        waitingDialog.hide();
                        retorno = JSON.parse(dados);
                        if( retorno.codigo == 0 ){
                            console.log( retorno.output );
                            x = retorno.output.length                           
                            let html = "";                         
                            for(i = 0; i < x; i++){     
                                let tipo_objeto = retorno.output[i].objeto.toUpperCase()                                               
                                html += "<tr class='text-center'>";
                                    html += "<td style='vertical-align:middle'>"+tipo_objeto.replace("_"," ")+"</td>";
                                    html += "<td style='vertical-align:middle'>"+retorno.output[i].id_usuario.toUpperCase()+"</td>";
                                    html += "<td style='vertical-align:middle'>"+retorno.output[i].nome_usuario.toUpperCase()+"</td>";
                                    html += "<td style='vertical-align:middle'>"+retorno.output[i].ordem+"° APROVAR </td>";
                                    html += "<td style='vertical-align:middle'>";
                                        html += "<button class='btn btn-danger deletar' type='button' value='"+retorno.output[i].id+"/"+retorno.output[i].objeto+"'>";
                                            html += "<i class='fa fa-trash'></i>";
                                        html += "</button>";
                                    html += "</td>";
                                html += "</tr>";
                            }                           
                            $('#tbody_detalhe').append(html);
                            $('#modal_detalhe_fluxo').modal('show'); 
                            $('.deletar').click(function(){
                                id = $(this).val();                                             
                                ajaxDeletar(id);
                            });
                        }else{
                            $('#painel_error_msg').text(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function(){
                        $('#painel_error_msg').text(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }                
                });
            }

            function ajaxDeletar(id){
                url = "<?=HOME_URI.$this->nome_modulo.'/deletarFluxo/'?>"+id;                               
                $.ajax({
                    url:url,                    
                    type:"POST",
                    beforeSend: function(){
                        waitingDialog.show("PROCESSANDO...");
                    },
                    success: function(dados){
                        waitingDialog.hide();
                        retorno = JSON.parse(dados);
                        if(retorno.codigo == 0){
                            $('#painel_success_msg').text(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('#modal_sucesso_sistema').on('hidden.bs.modal', function() {
                                window.location.href = "/configuracoes/fluxoAprovacao"; 
                            });   
                        }else{
                            $('#painel_error_msg').text(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function(){
                        $('#painel_error_msg').text(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }                
                });
            }
        });
    </script>
    <!-- /PAGE SCRIPTS -->
</body>
</html>