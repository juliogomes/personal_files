<?php// ob_start(); ?>
<!doctype html>
<html class="no-js" lang="">
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "configuracoes";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Configuracoes</li>
        <li>Contatos C&M Software</li>
	</ol>
	<h4 class="page-title">
        CONTATOS C&M SOFTWARE
	</h4>  
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-12">
				<form id="contato_save" name="contato_save" method="post">
					<fieldset>
						<legend>ADICIONAR CONTATO </legend>
						<div class="row">  
                            <div class="col-md-12"> 
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="usuario">Empresa C&M:</label>
                                        <select id="id_cm" name="id_cm" class="form-control select">
                                            <option value="" selected>Selecione...</option>
                                            <?php if( $lista_empresas ){ ?>
                                                <?php foreach( $lista_empresas as $key => $value ){ ?>
                                                    <option value="<?= strtoupper( $value->id ); ?>" selected><?= strtoupper( $value->razao_social ); ?></option>
                                                <?php } ?>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="usuario">Usuários:</label>
                                        <select id="usuario" name='usuario' class="search form-control">
                                            <option value="" selected>Selecione</option>
                                            <?php foreach ($usuarios as $key => $value) { ?>
                                                    <?="<option value='$value->id'>".strtoupper($value->nome)."</option>";?>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>                                                                                                     
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="tipo_contato">Tipo contato:</label>
                                        <select id="tipo_contato" name='tipo_contato' class="search form-control">
                                            <option value="" selected>Selecione</option>
                                            <option value="responsavel_legal">REPRESENTANTE LEGAL</option>
                                            <option value="juridico">JURÍDICO</option>
                                            <option value="testemunha">TESTEMUNHA</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="ordem">ADICIONAR:</label>
                                        <button type="button" id="salvar_contato" class="form-control btn btn-success" style="font-weight:bold">
                                            <i class="fa fa-save"></i> ADICIONAR CONTATO
                                        </button>
                                    </div>
                                </div>  
                            </div>                         
						</div>	
                        <hr>					
					</fieldset>
				</form>
			</div>
            <div class="col-md-12">
                <div class="col-md-12">
                    <fieldset>
                        <legend style="text-align:center;font-size:16px; letter-spacing: 0.8em;">CONTATOS C&M SOFTWARE</legend>  
                    <fieldset>
                    <table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
                        <thead>
							<tr role="row">
								<th width="200" class="text-left" style="vertical-align:middle">C&M</th>
                                <th width="200" class="text-left" style="vertical-align:middle">NOME</th>
								<th  width="20" class="text-center"  style="vertical-align:middle">CPF</th>	
                                <th  width="20" class="text-center"  style="vertical-align:middle">E-MAIL</th>		
                                <th  width="20" class="text-center"  style="vertical-align:middle">TIPO CONTATO</th>		
                                <th  width="20" class="text-center"  style="vertical-align:middle">STATUS</th>	
                                <th  width="20" class="text-center"  style="vertical-align:middle">AÇÕES</th>							
							</tr>
						</thead>
						<tbody>
                            <?php if(isset($contatos) && is_array($contatos)){ ?>
                                <?php foreach ($contatos as $key => $value) { ?>                           
                                    <tr>
                                        <td class="text-left" style="vertical-align:middle;font-size:12px">
                                            <span class="label-status"><?= strtoupper($value->nome_cm); ?></span>
                                        </td>
                                        <td class="text-left" style="vertical-align:middle;font-size:12px">
                                            <span class="label-status"><?= strtoupper($value->nome); ?></span>
                                        </td>
                                        <td class="text-center" style="font-size:12px">
                                           <?=$value->cpf;?>	
                                        </td>
                                        <td class="text-center" style="font-size:12px">
                                           <?=$value->email;?>	
                                        </td>
                                        <td class="text-center" style="font-size:12px">		
                                            <?php if($value->tipo_contato == "responsavel_legal"){ ?>
                                                REPRESENTANTE LEGAL
                                            <?php }else{ ?>
                                                <?=str_replace("_"," ",strtoupper($value->tipo_contato));?>			
                                            <?php } ?>						
                                        </td>
                                        <td class="text-center">	
                                            <?php
                                                if($value->status == 0){
                                                    echo "<button class='btn btn-success btn-xs' style='font-weight:bold'>ATIVO</button>";
                                                }else{
                                                    echo "<button class='btn btn-danger btn-xs' style='font-weight:bold'>INATIVO</button>";
                                                }	
                                            ?>	                                           								
                                        </td>
                                        <td class="text-center">	
                                            <?php
                                                if($value->status == 0){
                                                    echo "<button class='btn btn-warning btn-xs inativar' value='$value->id' style='margin-right:4%;font-weight:bold'>INATIVAR</button>";
                                                }else{
                                                    echo "<button class='btn btn-success btn-xs ativar' value='$value->id'  style='margin-right:4%;font-weight:bold'>ATIVAR</button>";
                                                }
                                                echo "<button class='btn btn-danger btn-xs excluir' value='$value->id'  style='font-weight:bold'> <i class='fa fa-trash-o'> </i></button>";	
                                            ?>	                                           								
                                        </td>
                                    </tr>	
                                <?php } ?>		
                            <?php }else{ ?>	
                                <tr>	
                                    <td colspan="6" style="text-align:center">Sem configuração</td> 
                                </tr> 
                            <?php } ?>
						</tbody>
					</table>  
                    
                </div>                   
            </div>
		</div>
	</div>	
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->

	<!-- MODALS -->
   
	<!-- /MODALS -->

	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
    <?php include "template/modal_sistema.php" ?>
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
  
	<!-- PAGE SCRIPTS -->
    <script>
        $(document).ready(function(){
            
            $(".inativar").click(function(){
                value = $(this).val();                
                ajaxContato("inativar",value);
            });

            $(".excluir").click(function(){
                value = $(this).val();
                ajaxContato("excluir",value);
            });

            $(".ativar").click(function(){
                value = $(this).val();
                ajaxContato("ativar",value);
            });

            $("#salvar_contato").click(function(){
                ajaxAddContato();
            });

            function ajaxContato(parametro, id){
                url = "<?=HOME_URI.$this->nome_modulo.'/statusContato/'?>"+parametro+"/"+id;                               
                $.ajax({
                    url:url,                    
                    type:"POST",
                    beforeSend: function(){
                        waitingDialog.show("PROCESSANDO...");
                    },
                    success: function(dados){
                        waitingDialog.hide();
                        retorno = JSON.parse(dados);
                        if(retorno.codigo == 0){
                            $('#painel_success_msg').text(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('#modal_sucesso_sistema').on('hidden.bs.modal', function() {
                                window.location.href = "/configuracoes/contato"; 
                            });   
                        }else{
                            $('#painel_error_msg').text(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function(){
                        $('#painel_error_msg').text(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }                
                });
            }

            function ajaxAddContato(){
                url = "<?=HOME_URI.$this->nome_modulo.'/addContato/'?>";    
                form = $("#contato_save").serialize();                           
                $.ajax({
                    url:url,    
                    data:form,                
                    type:"POST",
                    beforeSend: function(){
                        waitingDialog.show("PROCESSANDO...");
                    },
                    success: function(dados){
                        waitingDialog.hide();
                        retorno = JSON.parse(dados);
                        if(retorno.codigo == 0){
                            $('#painel_success_msg').text(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('#modal_sucesso_sistema').on('hidden.bs.modal', function() {
                                window.location.href = "/configuracoes/contato"; 
                            });   
                        }else{
                            $('#painel_error_msg').text(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function(){
                        $('#painel_error_msg').text(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }                
                });
            }
           

        });
    </script>
    <!-- /PAGE SCRIPTS -->
</body>
</html>