<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "configuracoes";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Configuracoes</li>
	</ol>
	<h4 class="page-title">
		Configurações
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-9">
				<form id="frm_save" name="frm_save" action="<?php echo HOME_URI.$this->module.'/save/id/'.$this->parametros[1].''; ?>"  method="post">
					<fieldset>
						<legend>Opções</legend>
						<div class="row">
							<div class="col-md-2">
								<div class="form-group">
									<label for="nome_controle">Nome controle</label>
									<input type="text" id = "nome_controle" name='orcamento[nome_controle]' class="form-control" value="Orcamento" readonly>
								</div>
							</div>	
							<div class="col-md-2">
								<div class="form-group">
									<label for="nivel_controle">Nivel de controle</label>
									<select id = "nivel_controle" name='orcamento[nivel_controle]' class="form-control select">
										<option value="subconta"     <?= ($conf_orcamento->nivel_controle == 'subconta')?'selected':null; ?> >Sub Conta</option>
										<option value="conta"        <?= ($conf_orcamento->nivel_controle == 'conta')?'selected':null; ?> >Conta</option>
										<option value="grupo"        <?= ($conf_orcamento->nivel_controle == 'grupo')?'selected':null; ?> >Grupo</option>
										<option value="centro_custo" <?= ($conf_orcamento->nivel_controle == 'centro_custo')?'selected':null; ?> >Centro de custo</option>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="tipo_controle">Tipo de controle</label>
									<select id = "tipo_controle" name='orcamento[tipo_controle]' class="form-control select">
										<option value=""             <?= (empty($conf_orcamento->tipo_controle))?'selected':null; ?> >Todos</option>
										<option value="global"        <?= ($conf_orcamento->tipo_controle == 'global')?'selected':null; ?> >Global</option>
										<option value="comercial"        <?= ($conf_orcamento->tipo_controle == 'comercial')?'selected':null; ?> >Comercial</option>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="periodo_controle">Periodo</label>
									<select id = "periodo_controle" name = 'orcamento[periodo_controle]' class="form-control select">
										<option value="mensal" <?= ($conf_orcamento->periodo_controle == 'mensal')?'selected':null; ?> >Mensal</option>	
										<option value="trimestral" <?= ($conf_orcamento->periodo_controle == 'trimestral')?'selected':null; ?> >Trimestral</option>
										<option value="semestral" <?= ($conf_orcamento->periodo_controle == 'semestral')?'selected':null; ?> >Semestral</option>
										<option value="anual" <?= ($conf_orcamento->periodo_controle == 'anual')?'selected':null; ?> >Anual</option>
									</select>
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="aprovadores">Aprovadores</label>
									<select id = "aprovadores" name='orcamento[aprovadores][]' class="form-control select" multiple>
										<?php
										foreach($usuarios as $key => $value){
											if(in_array($value->id, $conf_orcamento->aprovadores)){
												echo '<option value ="'.$value->id.'" selected >'.strtoupper($value->nome).'</option>';
											}else{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome).'</option>';
											}											
										}
										?>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<button type="submit" class="form-control btn btn-primary"><i class="fa fa-save"></i> Salvar</button>
							</div>
						</div>
					</fieldset>
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
<!-- /PAGE SCRIPTS -->
</body>
</html>