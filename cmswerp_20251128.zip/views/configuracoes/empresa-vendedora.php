<?php// ob_start(); ?>
<!doctype html>
<html class="no-js" lang="">
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "configuracoes";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Configuracoes</li>
        <li>Empresa Vendedora</li>
	</ol>
	<h4 class="page-title">
        EMPRESA VENDEDORA
	</h4>  
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-12">
				<form id="contato_save" name="contato_save" method="post">
					<fieldset>
						<legend>ADICIONAR CONTATO </legend>
						<div class="row">  
                            <div class="col-md-12"> 
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="empresa">EMPRESAS:</label>
                                        <select id="empresa" name='empresa' class="search form-control">
                                            <option value="" selected>Selecione</option>
                                            <?php foreach ($empresa as $key => $value) { ?>
                                                    <?="<option value='$value->id'>".strtoupper($value->razao_social)."</option>";?>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>                                                                                                     
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="ordem">INDICAR EMPRESA VENDEDORA:</label>
                                        <button type="button" id="atualizar_empresa" class="form-control btn btn-primary" style="font-weight:bold">
                                            <i class="fa fa-save"></i> ATUALIZAR
                                        </button>
                                    </div>
                                </div>  
                            </div>                         
						</div>	
                        <hr>					
					</fieldset>
				</form>
			</div>
            <div class="col-md-12">
                <div class="col-md-12">
                    <fieldset>
                        <legend style="text-align:center;font-size:16px; letter-spacing: 0.8em;">EMPRESAS</legend>  
                    <fieldset>
                    <table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
                        <thead>
							<tr role="row">
								<th  width="10" class="text-center" style="vertical-align:middle">ID</th>
								<th  width="20" class="text-center"  style="vertical-align:middle">CNPJ</th>	
                                <th  width="20" class="text-center"  style="vertical-align:middle">NOME</th>		
                                <th  width="20" class="text-center"  style="vertical-align:middle">STATUS</th>		
                                <th  width="20" class="text-center"  style="vertical-align:middle">ATUAL EMPRESA VENDEDORA</th>	
                                <!-- <th  width="20" class="text-center"  style="vertical-align:middle">PERÍODO</th>							 -->
							</tr>
						</thead>
						<tbody>
                            <?php if(isset($empresa) && is_array($empresa)){ ?>
                                <?php foreach ($empresa as $key => $value) { ?>                           
                                    <tr>
                                        <td class="text-center" style="vertical-align:middle;font-size:12px">
                                            <span class="label-status"><?=strtoupper($value->id)?></span>
                                        </td>								
                                        <td class="text-center" style="font-size:12px">								
                                           <?=$value->cnpj;?>									
                                        </td>
                                        <td class="text-center" style="font-size:12px">								
                                           <?=$value->razao_social;?>									
                                        </td>
                                        <td class="text-center" style="font-size:12px">		
                                           	<?=strtoupper($value->status);?>					
                                        </td>
                                        <td class="text-center" style="font-size:12px">	
                                            <?php if($value->empresa_vendedora == "0"){ ?>
                                                <button class="btn btn-success" width="200px"> <b>SIM</b> </button>
                                            <?php }else{ ?>
                                                <button class="btn btn-danger" width="200px"> <b>NÃO</b> </button>	                               
                                            <?php } ?>            								
                                        </td>                                        
                                    </tr>	
                                <?php } ?>		
                            <?php }else{ ?>	
                                <tr>	
                                    <td colspan="6" style="text-align:center">SEM EMPRESA</td> 
                                </tr> 
                            <?php } ?>
						</tbody>
					</table>  
                    
                </div>                   
            </div>
		</div>
	</div>	
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->

	<!-- MODALS -->
   
	<!-- /MODALS -->

	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
    <?php include "template/modal_sistema.php" ?>
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
  
	<!-- PAGE SCRIPTS -->
    <script>
        $(document).ready(function(){
            
           

            $("#atualizar_empresa").click(function(){
                id = $('#empresa option:selected').val();           
                ajax(id);
            });

            function ajax(id){
                url = "<?=HOME_URI.$this->nome_modulo.'/atualizarEmpresaVendedora/'?>"+id;                               
                $.ajax({
                    url:url,                    
                    type:"POST",
                    beforeSend: function(){
                        waitingDialog.show("PROCESSANDO...");
                    },
                    success: function(dados){
                        waitingDialog.hide();
                        retorno = JSON.parse(dados);
                        if(retorno.codigo == 0){
                            $('#painel_success_msg').text(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('#modal_sucesso_sistema').on('hidden.bs.modal', function() {
                                window.location.href = "/configuracoes/empresaVendedora"; 
                            });   
                        }else{
                            $('#painel_error_msg').text(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function(){
                        $('#painel_error_msg').text(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }                
                });
            }

            function ajaxAddContato(){
                url = "<?=HOME_URI.$this->nome_modulo.'/addContato/'?>";    
                form = $("#contato_save").serialize();                           
                $.ajax({
                    url:url,    
                    data:form,                
                    type:"POST",
                    beforeSend: function(){
                        waitingDialog.show("PROCESSANDO...");
                    },
                    success: function(dados){
                        waitingDialog.hide();
                        retorno = JSON.parse(dados);
                        if(retorno.codigo == 0){
                            $('#painel_success_msg').text(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('#modal_sucesso_sistema').on('hidden.bs.modal', function() {
                                window.location.href = "/configuracoes/contato"; 
                            });   
                        }else{
                            $('#painel_error_msg').text(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function(){
                        $('#painel_error_msg').text(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }                
                });
            }
           

        });
    </script>
    <!-- /PAGE SCRIPTS -->
</body>
</html>