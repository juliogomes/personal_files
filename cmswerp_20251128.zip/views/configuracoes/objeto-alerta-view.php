<?php// ob_start(); ?>
<!doctype html>
<html class="no-js" lang="">
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "configuracoes";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Configuracoes</li>
        <li>Alertas / Objeto</li>
	</ol>
	<h4 class="page-title">
        ALERTAS / OBJETO
	</h4>  
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-12">
                <form id="search" name="search" method="post">
					<fieldset>						
						<div class="row">  
                            <div class="col-md-12"> 
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="objeto">OBJETO:</label>
                                        <select id="objeto" name='objeto' class="search form-control">
                                            <option value="" selected>SELECIONE</option>
                                            <?php if(isset($pesquisa_alerta) && !empty($pesquisa_alerta)){ ?>
                                                <?php foreach ($pesquisa_alerta as $key => $value) { ?>
                                                    <option value="<?=$value->id;?>" <?=($value->id == $id_objeto)?"selected":null;?>> <?=strtoupper($value->objeto);?> </option>
                                                <?php } ?>
                                            <?php } ?>
                                        </select>
                                    </div>
                                </div>                                                                                                     
                                                                
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="ordem">PESQUISAR:</label>
                                        <button type="submit" class="form-control btn btn-primary" style="font-weight:bold">
                                            <i class="fa fa-search"></i> PESQUISAR
                                        </button>
                                    </div>
                                </div> 
                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="ordem">ADICIONAR OBJETO DE ALERTA:</label>
                                        <button type="button" class="form-control btn btn-danger" style="font-weight:bold" data-toggle="modal" data-target="#modal_objeto">
                                            <i class="fa fa-save"></i> ADICIONAR OBJETO DE ALERTA
                                        </button>
                                    </div>
                                </div> 
                                                              
                            </div>                         
						</div>	
                        <hr>					
					</fieldset>
				</form>				
			</div>

            <div class="col-md-12">
                <div class="col-md-12">
                    <fieldset>
                        <legend style="text-align:center;font-size:16px; letter-spacing: 0.8em;">OBJETO C&M SOFTWARE</legend>  
                    <fieldset>
                    <table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
                        <thead>
							<tr role="row">
								<th  width="10%" class="text-center" style="vertical-align:middle">ID</th>
                                <th  width="20%" class="text-center"  style="vertical-align:middle">OBJETO</th>							
                                <th  width="60%" class="text-center"  style="vertical-align:middle">DESCRIÇÃO</th>	                                
                                <th  width="10%" class="text-center"  style="vertical-align:middle">DELETAR</th>							
							</tr>
						</thead>
						<tbody>
                            <?php if(isset($objeto_alerta) && is_array($objeto_alerta)){ ?>
                                <?php foreach ($objeto_alerta as $key => $value) { ?>                           
                                    <tr>                                        
                                        <td class="text-center" style="vertical-align:middle;font-size:14px">
                                            <span class="label-status"><?=$value->id;?></span>
                                        </td>
                                        <td class="text-center" style="vertical-align:middle;font-size:14px">
                                            <span class="label-status"><?=strtoupper($value->objeto);?></span>
                                        </td>								
                                        <td class="text-center" style="vertical-align:middle;font-size:14px">								
                                           <?=$value->descricao;?>									
                                        </td>                             
                                        <td class="text-center">                                            
                                            <button class='btn btn-danger excluir' value="<?=$value->id;?>"  style='font-weight:bold'> <i class='fa fa-trash-o'> </i></button>                                            	                                           								
                                        </td>
                                    </tr>	
                                <?php } ?>		
                            <?php }else{ ?>	
                                <tr>	
                                    <td colspan="4" style="text-align:center">SEM OBJETO DE ALERTA CADASTRADO</td> 
                                </tr> 
                            <?php } ?>
						</tbody>
					</table>                     
                </div>                   
            </div>
		</div>
	</div>	



	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->

	<!-- MODALS -->
    <div class="modal" id="modal_objeto" tabindex="-1" role="dialog" data-backdrop="static" >
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">                        
                    <h2 style="text-align:center;font-size:20px;letter-spacing:0.8em;">CADASTRAR OBJETO</h2>
                </div>               
                <div class="modal-body">    
                    <form id="form" method="POST" action=""> 
                        <div class="container-fluid">                  
                            <div class="form-group"> 
                                <div class="col-md-12">
                                    <label>NOME:</label>
                                    <input class="form-control" name="objeto"></input>
                                </div> 
                                <div class="col-md-12">
                                    <br>
                                    <label>DESCRIÇÃO:</label>
                                    <textarea style="width:100%;height:200px;resize:none" id="text_objeto" name="descricao"></textarea>
                                </div>                            
                            </div>   
                        </div> 
                    </form>                                                                                 
                </div>
                
                <div class="modal-footer">  
                    <button type="button" class="btn btn-danger fechar_modal" data-dismiss="modal"  style="font-weight:bold">
                        FECHAR
                    </button>                   
                    <button type="button" class="btn btn-success" id="cadastrar" value="" style="font-weight:bold">
                        CADASTRAR
                    </button>                                            
                </div>
            </div>
        </div> 
    </div>                           
	<!-- /MODALS -->

	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
    <?php include "template/modal_sistema.php" ?>
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
  
	<!-- PAGE SCRIPTS -->
    <script>
        $(document).ready(function(){

            $("#cadastrar").click(function(){
                requestAjax();
            });

            $(".excluir").click(function(){
                id = $(this).val();
                console.log(id);
                requestAjaxDeletar(id);
            });

            function requestAjax(){                
                url = "/configuracoes/cadastrarObjeto";                
                form = $("#form").serialize();
                $.ajax({
                    url:url,
                    data:form,
                    type:'POST',
                    beforeSend: function(){
                        waitingDialog.show('PROCESSANDO...');
                    },
                    success: function(dados){
                        waitingDialog.hide();
                        var retorno = JSON.parse(dados);
                        if(retorno.codigo == 0){
                            $('#painel_success_msg').text(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('#modal_sucesso_sistema').on('hide.bs.modal', function(){                           
                                window.location.href = "/configuracoes/alertaObjeto";
                            });
                        }else{
                            $('#painel_error_msg').text(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function(erro){
                        $('#painel_error_msg').text("Erro requisição AJAX.");
                        $('#modal_erro_sistema').modal('show');
                    }
                })
            } 

            function requestAjaxDeletar(id){                
                url = "/configuracoes/deleteObjeto/"+id;                   
                $.ajax({
                    url:url,                   
                    type:'POST',
                    beforeSend: function(){
                        waitingDialog.show('PROCESSANDO...');
                    },
                    success: function(dados){
                        waitingDialog.hide();
                        var retorno = JSON.parse(dados);
                        if(retorno.codigo == 0){
                            $('#painel_success_msg').text(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('#modal_sucesso_sistema').on('hide.bs.modal', function(){                           
                                window.location.reload();
                            });
                        }else{
                            $('#painel_error_msg').text(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function(erro){
                        $('#painel_error_msg').text("Erro requisição AJAX.");
                        $('#modal_erro_sistema').modal('show');
                    }
                })
            }       

        });
    </script>
    <!-- /PAGE SCRIPTS -->
</body>
</html>