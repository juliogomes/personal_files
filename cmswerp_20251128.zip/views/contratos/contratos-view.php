<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "contratos";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Cadastros</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> Contratos</h4>
	<form class="form-inline page-toolbar">
		<div class="btn-group" role="group">
			<a href="/contratos/detalhe/id/0/" class="need_allow form-control btn btn-primary"><i class="fa fa-plus"></i> Novo Contrato</a>
			<!-- <button type="button" id='send_doc_max' class="form-control btn btn-info"><i class="fa fa-envelope"></i> Enviar Doc. Rocket Max</button> -->
		</div>
	</form>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<form name="form_contrato" >
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<table id='list' class="table table-default table-striped table-bordered table-hover display responsive nowrap" width="100%">
						<thead>
							<tr role="row">
								<!-- <th width="90" class="text-center"><input type="checkbox" name="sl_all" class="form-control"></th> -->
								<th width="90" class="text-right">ID</th>
								<th width="90" class="text-right">Contrato</th>
								<th width="90" class="text-right">Código</th>
								<!-- <th width="120" class="text-center">CNPJ</th> -->
								<th>Nome Fantasia</th>
								<th width="160" class="text-left">Codigo produto</th>
								<th width="160" class="text-left">Produto</th>
								<th class="text-left">Empresa vendedora</th>
								<th class="text-left">Fechamento</th>
								<th width="160" class="text-left">Status</th>
								<th width="160" class="text-left">Assinado em</th>
								<th width="160" class="text-left">NF</th>
								<th width="" class="text-center"></th>
								<th width="" class="text-center"></th>
							</tr>
						</thead>
						<tbody>
							<?php if ($records){ ?>
							<?php foreach($records as $key => $value) {
								if($value->codigo_produto != 'COB0001'){
									$order = 1;
								}else{
									$order = 2;
								}
							?>
							<tr>
								<td class="text-center"><a href="/contratos/detalhe/id/<?= $value->id_contrato ?>/"><?= $value->id_contrato ?></a></td>
								<td class="text-center"><?= $value->codigo_contrato; ?></td>
								<td class="text-center"><?= $value->codigo_cliente; ?></td>
								<!-- <td class="text-center"><?= mask($value->cnpj, '##.###.###/####-##'); ?></td> -->
								<td data-toggle="tooltip" data-placement="left" data-container="body" title="<?= $value->razao_social ?>">
									<span class="label-status">
										<small>
										<a href="/contratos/detalhe/id/<?= $value->id_contrato ?>/"><?= $value->nome_fantasia ?></a>
										</small>
									</span>
								</td>
								<td class="text-center"><span class="label-status"><small><?= $value->codigo_produto; ?></small></span></td>
								<td class="text-center"><span class="label-status"><small><?= $value->nome_produto; ?></small></span></td>
								<td class="text-center"><span class="label-status"><small><?= $value->razao_social_cm; ?></small></span></td>
								<td class="text-center"><span class="label-status"><small><?= $value->data_corte_faturamento ?></small></span></td>
								<td class="text-center"><span class="label-status"><small><?= $value->status ?></small></span></td>
								<td class="text-center"><span class="label-status"><small><?=convertDate($value->data_assinatura);?></small></span></td>
								<td class="text-center"><span class="label-status"><small>
									<?php
										if($records[0]->enviar_email_cobranca == 1){
											echo "SIM";
										}else{
											echo "NÃO";
										}
									?>
								</small></span></td>
								<td class="text-center">
									<div class="">
										<a class="btn btn-primary btn-xs" href="/cobranca/ListaPrecoCliente/id/<?= $value->id_contrato ?>/order/<?= $order; ?>"><i class="fa fa-money"></i></a>
									</div>
								</td>
								<td class="text-center">
									<div class="">
										<?php if(isset($value->id_if_contrato) && !empty($value->id_if_contrato)){ ?>
											<button type='button' class="btn btn-success btn-xs comissao" value="<?=$value->id_contrato;?>" ><i class="fa fa-bars"></i></button>
										<?php } ?>
									</div>
								</td>
							</tr>
							<?php } ?>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</form>

	  <!-- MODAL COMISSAO COMERCIAL -->
	  <div class="modal" id="modal_comissao" tabindex="-1" role="dialog" >
        <div class="modal-dialog  modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close close_comissao" data-dismiss="modal" >
                        <span>X</span>
                    </button>
                    <fieldset>
                        <h2 style="text-align:center;font-size:16px; letter-spacing: 0.4em;">COMERCIAL COMISSÃO</h2>
                    </fieldset>
                </div>
                <div class="modal-body">   
                    <div class="container-fluid">                     
                        <div class="col-md-12" id="div_comissao">
                            <fieldset>
                                <legend style="text-align:center;font-size:14px; letter-spacing: 0.8em;">DETALHE COMISSÃO</lengend>
                            </fieldset>
                            <table class="table table-default table-striped table-bordered table-hover display responsive nowrap" width="100%">
                                <thead>
                                    <tr role="row" style="">      
										<th class="text-center" style="font-size:10px;vertical-align:middle;"> CLIENTE </th>  
                                        <th class="text-center" style="font-size:10px;vertical-align:middle;"> PERFIL </th>                          
                                        <th class="text-center" style="font-size:10px;vertical-align:middle;"> MODELO COMISSÃO </th>
                                        <th class="text-center" style="font-size:10px;vertical-align:middle;"> NOME </th>
                                        <th class="text-center" style="font-size:10px;vertical-align:middle;"> VALIDADE </th>
                                        <th class="text-center" style="font-size:10px;vertical-align:middle;"> PERCENTUAL </th>
                                        <th class="text-center" style="font-size:10px;vertical-align:middle;"> DELETAR </th>                                                                                                           
                                    </tr>
                                </thead>
                                <tbody id="dados_comissao">                                    
                                        
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>                 
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger close_comissao" data-dismiss="modal"  style="font-weight:bold;font-size:10px">FECHAR</button>                   
                </div>
            </div>
        </div> 
    </div>
    <!-- END MODAL COMISSAO COMERCIAL -->

	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
    <?php include "template/modal_sistema.php" ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript">
		$(document).ready(function(){
			$(function() {
				oTable = $('#list').DataTable({
					info: false,
					responsive: true,
					autoFill: true,
					dom: "<'panel panel-default'" +
					"tr" +
					"<'panel-footer'" +
					"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
					">" +
					">",
					language: {
						"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
					},
					dom: 'Bfrtip',
					lengthMenu: [
						[ 10, 25, 50, -1 ],
						[ '10 rows', '25 rows', '50 rows', 'Show all' ]
					],
					lengthChange: false,
					buttons: [
						{
							extend: 'pageLength',
							text: 'PAGINAS',
							exportOptions: {
								columns: [ 0, ':visible' ]
							}
						},
						{
							extend: 'copyHtml5',
							text: 'COPY',
							exportOptions: {
								columns: [ 0, ':visible' ]
							}
						},
						{
							extend: 'excelHtml5',
							text: 'EXCEL',
							charset: 'utf-8',
							bom: true,
							exportOptions: {
								//columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 11, 12, 13 ] // para quando quiser fixar as colunas a serem importadas
								columns: ':visible'
							}
						},
						{
							extend: 'pdfHtml5',
							text: 'PDF',
							charset: 'utf-8',
							bom: true,
							exportOptions: {
								columns: ':visible'
								//columns: [ 0, 1, 2, 5 ]
							}
						},
						{
							extend: 'colvis',
							text: 'COLUNAS',
						},
					]
				});
				oTable.buttons().container().appendTo('#list_wrapper .col-sm-6:eq(0)');
			});

			$('.comissao').click(function(){
				html = "";
				id = $(this).val();
				url = "<?=HOME_URI.$this->nome_modulo.'/getComissao/'?>"+id;
				$.ajax({
					url:url,                                 
					type:"POST",
					beforeSend: function(){
						waitingDialog.show('PROCESSANDO..');
					},
					success: function(data){
						waitingDialog.hide();                    
						var retorno = JSON.parse(data);                        
						if(retorno.codigo == 0){   

							x = retorno.output.length;                                          
                        	for(i = 0; i < x; i++){  
								html += "<tr class='tr'>";
									html += "<td class='text-center' style='font-size:10px;vertical-align:middle;'>"+retorno.input[0].nome_fantasia.toUpperCase()+"</td>";
									html += "<td class='text-center' style='font-size:10px;vertical-align:middle;'>"+retorno.output[i].perfil.toUpperCase().replace('_', ' ')+"</td>";
									html += "<td class='text-center' style='font-size:10px;vertical-align:middle;'>"+retorno.output[i].nome_perfil.toUpperCase();+"</td>";
									html += "<td class='text-center' style='font-size:10px;vertical-align:middle;'>"+retorno.output[i].nome_usuario.toUpperCase();+"</td>";
									html += "<td class='text-center' style='font-size:10px;vertical-align:middle;'>";
										if(retorno.output[i].meses_validade == '1'){
											html += retorno.output[i].meses_validade+" MÊS";
										}else{
											html += retorno.output[i].meses_validade+" MESES";
										}    
									html += "</td>";
									html += "<td class='text-center' style='font-size:10px;vertical-align:middle;'>"+retorno.output[i].percentual.toUpperCase();+"</td>";
									html += "<td class='text-center' style='font-size:10px;vertical-align:middle;'>";                                    
											html += "<i class='fa fa-ban'></i>";                                    
									html += "</td>";
								html += "</tr>";    
							}
							$('#dados_comissao').append(html);   
							$('#modal_comissao').modal('show');

						}else{  
							$('#painel_error_msg').text(retorno.mensagem);
							$('#modal_erro_sistema').modal('show');                        
						}
					},
					erro: function(error){
						$('#painel_error_msg').text(retorno.mensagem);
						$('#modal_erro_sistema').modal('show');
					}
				});				
			});

			$('#modal_comissao').on('hidden.bs.modal', function () {     				    
				$('.tr').remove();                                                                                     
			}) 
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
