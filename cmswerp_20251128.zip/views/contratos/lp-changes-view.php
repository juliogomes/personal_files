<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "contratos";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Checar lista de preços</li>
		<li>replicar lista de preço</li>
		<li><?= $cliente[0]->nome_fantasia.' - '.$cliente[0]->razao_social?></li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> Listas de preços</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<a class="col-md-12 btn btn-success" href="/cadastros/replicarlista/id/<?= $cliente[0]->id_contrato ?>/<?= $cliente[0]->id_produto ?>/"><i class="fa fa-repeat"></i> </span>Aplicar aos novos contratos</a> 
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
					<?php
						if(isset($param)){
						foreach ($param as $key => $value) {
						if(isset($value['valores'])){
						?>
							<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
							<thead>	
						<?php
							if($value['tipo_cobranca'] == 'VOLUMETRIA'){
							?>
								<th>
									<td colspan="3"><?= $value['codigo_modulo'].' - '.$value['nome_modulo']?></td>
								</th>
								<tr role="row">
									<th class="text-center">Quantidade de</th>
									<th>Quantidade até</th>
									<th width="160" class="text-center">Valor real</th>
								</tr>
							<?php	
							}elseif($value['tipo_cobranca'] == 'VALOR-FIXO'){
							?>
								<tr>
									<td><?= $value['codigo_modulo'].' - '.$value['nome_modulo']?></td>
								</tr>
								<tr role="row">
									<td class="text-center">Valor fixo</td>
								</tr>
							<?php
							}elseif($value['tipo_cobranca'] == 'LIQUIDADO-REAL'){
							?>
								<th>
									<td colspan="3"><?= $value['codigo_modulo'].' - '.$value['nome_modulo']?></td>
								</th>
								<tr role="row">
									<th class="text-center">Quantidade de</th>
									<th>Quantidade até</th>
									<th width="160" class="text-center">Valor real</th>
								</tr>
							<?php
							}elseif($value['tipo_cobranca'] == 'LIQUIDADO-RELATIVO'){
							?>
								<th>
									<td colspan="3"><?= $value['codigo_modulo'].' - '.$value['nome_modulo']?></td>
								</th>
								<tr role="row">
									<th class="text-center">Quantidade de</th>
									<th>Quantidade até</th>
									<th class="text-center">Idade de</th>
									<th>Idade até</th>
									<th width="160" class="text-center">Valor real</th>
								</tr>
							<?php
							}elseif($value['tipo_cobranca'] == 'COBRANCA-ELETRONICA'){
							?>
								<th>
									<td colspan="3"><?= $value['codigo_modulo'].' - '.$value['nome_modulo']?></td>
								</th>
								<tr role="row">
									<th class="text-center">Quantidade de</th>
									<th>Quantidade até</th>
									<th width="160" class="text-center">Percentual</th>
								</tr>
							<?php
							}elseif($value['tipo_cobranca'] == 'GOCHK'){
							?>
								<th>
									<td colspan="3"><?= $value['codigo_modulo'].' - '.$value['nome_modulo']?></td>
								</th>
								<tr role="row">
									<th class="text-center">Valor real</th>
									<th>Valor relativo</th>
								</tr>
							<?php
							}elseif($value['tipo_cobranca'] == 'KUMRAM'){
							?>
								<th>
									<td colspan="3"><?= $value['codigo_modulo'].' - '.$value['nome_modulo']?></td>
								</th>
								<tr role="row">
									<th class="text-center">Quantidade de licenças</th>
									<th>Valor real</th>
								</tr>
							<?php
							}
						}
							?>
							</thead>
								<tbody>
								<?php
								if(isset($value['valores'])){
									foreach ($value['valores'] as $chave => $valor) {
										if($value['tipo_cobranca'] == 'VOLUMETRIA'){
								?>
									<tr role="row">
										<td><?= $valor['qtd_de'] ?></td>
										<td><?= $valor['qtd_ate'] ?></td>
										<td><?= $valor['valor_real'] ?></td>
									</tr>
								<?php	
										}elseif($value['tipo_cobranca'] == 'VALOR-FIXO'){
								?>
									<tr role="row">
										<td><?= $valor['valor_total']; ?></td>
									</tr>
								<?php
										}elseif($value['tipo_cobranca'] == 'LIQUIDADO-REAL'){
								?>
									<tr role="row">
										<td><?= $valor->qtd_de ?></td>
										<td><?= $valor->qtd_ate ?></td>
										<td><?= $valor->valor_real ?></td>
									</tr>
								<?php
										}elseif($value['tipo_cobranca'] == 'LIQUIDADO-RELATIVO'){
								?>
									<tr role="row">
										<td><?= $valor->qtd_de ?></td>
										<td><?= $valor->qtd_ate ?></td>
										<td><?= $valor->idade_de ?></td>
										<td><?= $valor->idade_ate ?></td>
										<td><?= $valor->valor_real ?></td>
									</tr>
								<?php
										}elseif($value['tipo_cobranca'] == 'COBRANCA-ELETRONICA'){
								?>
									<tr role="row">
										<td><?= $valor->qtd_de ?></td>
										<td><?= $valor->qtd_ate ?></td>
										<td><?= $valor->percentual ?></td>
									</tr>
								<?php
										}elseif($value['tipo_cobranca'] == 'GOCHK'){
								?>
									<tr role="row">	
										<td><?= $valor->valor_relativo ?></td>
										<td><?= $valor->valor_real ?></td>
									</tr>
								<?php
										}elseif($value['tipo_cobranca'] == 'KUMRAM'){
								?>
									<tr role="row">	
										<td><?= $valor->qtd_licencas ?></td>
										<td><?= $valor->valor_real ?></td>
									</tr>
								<?php
										}
										}
									}
								?>
								</tbody>
							</table>
							<?php
						}
					}
					?>
			</div>
		</div>
				<div class="row">
			<div class="col-md-12">
				<a class="col-md-12 btn btn-success" href="/cadastros/replicarlista/id/<?= $cliente[0]->id_contrato ?>/<?= $cliente[0]->id_produto ?>/"><i class="fa fa-repeat"></i> </span>Aplicar aos novos contratos</a> 
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
</body>
</html>
