<?php
/**
 * Created by PhpStorm.
 * User: julio.gomes
 * Date: 14/10/2016
 * Time: 12:56
 */

if ( !$this->logged_in ) {
    echo 'Efetue o login para acessar esse registro, clicando <a href="'.HOME_URI.'login/"> aqui </a>';
    exit;
}
?>
<!-- Custom CSS -->
<link href="<?php echo HOME_URI?>/views/_css/sb-admin.css" rel="stylesheet">

<!-- Morris Charts CSS -->
<link href="<?php echo HOME_URI?>/views/_css/morris.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="<?php echo HOME_URI?>/views/_css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

<div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-comments fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo count($results); ?></div>
                                        <div>Leads!</div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo HOME_URI;?>lead/">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-tasks fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo count($activities); ?></div>
                                        <div>Atividades!</div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo HOME_URI;?>lead/">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-shopping-cart fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo (count($documents)-2); ?></div>
                                        <div>Documentos!</div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo HOME_URI;?>documents/">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>