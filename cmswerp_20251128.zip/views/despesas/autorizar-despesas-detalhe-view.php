<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "despesas";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Contas a pagar</li>
	</ol>
	<h4 class="page-title">
		<i class="fa fa-check"></i> Aprovar Despesa
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<form name="frm_despesa" action="#" method="post" >
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<fieldset>
						<div class="form-group">
							<table class="table">
								<tr>
									<td>Empresa CM</td>
									<td><?= $records[0]->nome_cm ?></td>
								</tr>
								<tr>
									<td>Fornecedor</td>
									<td><?= $records[0]->nome_fornecedor ?></td>
								</tr>
								<tr>
									<td>Centro de Custo</td>
									<td><?= $records[0]->nome_centro_custo ?></td>
								</tr>
								<tr>
									<td>Grupo</td>
									<td><?= $records[0]->nome_grupo ?></td>
								</tr>
								<tr>
									<td>Conta</td>
									<td><?= $records[0]->nome_conta ?></td>
								</tr>
								<tr>
									<td>Sub Conta</td>
									<td><?= $records[0]->nome_subconta ?></td>
								</tr>
								<tr>
									<td>Vencimento</td>
									<td><?= $dt_vencimento->format('d/m/Y') ?></td>
								</tr>
								<tr>
									<td>Valor</td>
									<td><?= number_format($records[0]->valor, '2', ',', '.') ?></td>
								</tr>
							</table>
							<table class="table">
								<tr>
									<td></td>
									<td>Total do Orçamento</td>
									<td>Total Despesas</td>
									<td>Saldo</td>
								</tr>
								<tr>
									<td>Centro de custo <?= $saldo_centro_custo[0]->nome ?></td>
									<td class="text-left"><?= number_format($saldo_centro_custo[0]->valor_total, '2', ',', '.') ?></td>
									<td class="text-left"><?= number_format($despesa_centro_custo[0]->valor, '2', ',', '.') ?></td>
									<td class="text-left"><?= number_format(($saldo_centro_custo[0]->valor_total - $despesa_centro_custo[0]->valor),'2', ',', '.') ?></td>
								</tr>
								<tr>
									<td>Grupo <?= $saldo_grupo[0]->nome ?></td>
									<td class="text-left"><?= number_format($saldo_grupo[0]->valor_total, '2', ',', '.')  ?></td>
									<td class="text-left"><?= number_format($despesa_grupo[0]->valor, '2', ',', '.') ?></td>
									<td class="text-left"><?= number_format(($saldo_grupo[0]->valor_total - $despesa_grupo[0]->valor), '2', ',', '.') ?></td>
								</tr>
								<tr>
									<td>Conta <?= $saldo_conta[0]->nome ?></td>
									<td class="text-left"><?= number_format($saldo_conta[0]->valor_total, '2', ',', '.') ?></td>
									<td class="text-left"><?= number_format($despesa_conta[0]->valor, '2', ',', '.') ?></td>
									<td class="text-left"><?= number_format(($saldo_conta[0]->valor_total - $despesa_conta[0]->valor), '2', ',', '.') ?></td>
								</tr>
								<tr>
									<td>Sub-Conta <?= $saldo_subconta[0]->nome ?></td>
									<td class="text-left"><?= number_format($saldo_subconta[0]->valor_total, '2', ',', '.') ?></td>
									<td class="text-left"><?= number_format($despesa_subconta[0]->valor, '2', ',', '.') ?></td>
									<td class="text-left"><?= number_format(($saldo_subconta[0]->valor_total - $despesa_subconta[0]->valor), '2', ',', '.') ?></td>
								</tr>
							</table>
						</div>
					</fieldset>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="form-group">
						<?php
						if($saldo_conta){
							if(($saldo_conta[0]->valor_total - $despesa_conta[0]->valor_total) > 0 || $this->userdata->perfil == 'ceo'){
						?>
							<input type="checkbox" id="despesas" name="despesas[<?= $records[0]->id_despesa; ?>]" value="<?= $records[0]->id_despesa; ?>" checked />
							<button class="form-control btn btn-success action" name="acao" id="btn-aprovar" value="aprovar"><i class="fa fa-check"></i> Autorizar</button>
							<button class="form-control btn btn-danger action"  name="acao" id="btn-reprovar" value="reprovar"><i class="fa fa-ban"></i> Reprovar</button>
						<?php
							}else{
						?>
							<span class="btn btn-danger"><i class="fa fa-ban"></i> Não há saldo disponivel para aprovar essa despesa!</span>
						<?php
							}
						}
						?>
					</div>
				</div>
			</div>
		</div>
	</form>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$(function() {
			$('#despesas').hide();
			$('.action').click(function(e){
				e.preventDefault();
				$.ajax({
					url: '/despesas/autorizar/',
					//datatype: 'json',
					//contentType: 'application/json; charset=utf-8',
					type: 'POST',
					data: { acao:$(this).val(), despesas:$('#despesas').val()},
					success: function (data){
						var obj_json = JSON.parse(data);
						alert(obj_json.processo[0].mensagem);
						console.log(obj_json);
					},
					error: function (error){
						console.log(error);
					}
				});
			});
		});
	</script>
<!-- /PAGE SCRIPTS -->
</body>
</html>