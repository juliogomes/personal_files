<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "calendario de despesas";
	</script>
	<!-- /PAGE STYLES -->
	<style>

	/* body {
		margin: 40px 10px;
		padding: 0;
		font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;
		font-size: 14px;
	} */


	#calendar {
		max-width: 900px;
		margin: 0 auto;
	}
</style>
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Faturamento</li>
		<li>Calendario</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i>Calendario contas a pagar e receber</h4>
	<div>
		<span><i class="fa fa-square" style="color:green"></i> Despesas aprovadas </span>
		<span><i class="fa fa-square" style="color:yellow"></i> Despesas pendentes </span>
		<span><i class="fa fa-square" style="color:red"></i> Despesas reprovadas </span>
		<span><i class="fa fa-square" style="color:blue"></i> Notas recebidas</span>
		<span><i class="fa fa-square" style="color:purple"></i> Notas a receber </span>
	</div>
	<form class="form-inline page-toolbar" id="gerar_nf" name="gerar_nf" method="post" action="/faturamento/gerarnf/">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div id='loading'>loading...</div>
				<div id='calendar'></div>
			</div>
		</div>
	</div>
	</form>

	<!-- Modal -->
	<div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	    <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
	        <h3 id="myModalLabel">Modal header</h3>
	    </div>
	    <div class="modal-body">
	        <p>One fine body</p>
	    </div>
	    <div class="modal-footer">
	        <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
	        <button class="btn btn-primary">Save changes</button>
	    </div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script>
		$(function(){
			//var hoje = "<?= $this->data_hora_atual->format('Y-m-d'); ?>";
			$('#calendar').fullCalendar({
				contentHeight: 600,
				windowResize: function(view){
    				},
				header: {
					left: 'prev,next today',
					center: 'title',
					right: 'month,agendaWeek,agendaDay,listWeek'
				},
				//defaultDate: hoje,
				editable: true,
				buttonIcons: false,
				navLinks: true, // can click day/week names to navigate views
				eventLimit: true, // allow "more" link when too many events
				editable: true,
				events: {
					url: '/despesas/dadosCalendario/',
					error: function(e){
						console.log(e);
						$('#script-warning').show();
					}
				},
				loading: function(bool) {
					$('#loading').toggle(bool);
				}
			});
		});
	</script>

	<!-- /PAGE SCRIPTS -->
</body>
</html>
