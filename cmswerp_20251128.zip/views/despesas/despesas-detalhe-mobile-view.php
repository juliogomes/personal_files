<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "despesas";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Contas a pagar</li>
		<li>Detalhe</li>
	</ol>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-9">
				<form id="periodo" name="periodo" action="/despesas/listar/" method="post">
					<fieldset>
						<div class="row">
							<div class="col-md-12">
								<span><b><?= count($despesas)?> para serem aprovadas</b></span>
							</div>
						</div>
						<br>
						<div class="row">
							<div class="col-md-4">
								<input type="hidden" value="<?= $_POST['action'] ?>" id="action" name="action" />
								<input type="hidden" value="<?= $atual ?>"           id="indice" name="indice" />

								<label for="dt_ini">De</label>
								
								<input type="text" class="form-control datepast2" value="<?= $dt_ini->format('d/m/Y'); ?>" name="dt_ini" />
							</div>
							<div class="col-md-4">
								<label for="dt_fim">Até</label>
								<input type="text" class="form-control datepast2" value="<?= $dt_fim->format('d/m/Y'); ?>" name="dt_fim" />
							</div>
							<div class="col-md-4">
								<button type="button" class="form-control btn-primary action" id="search" value="search"><i class="fa fa-search"></i></button>
							</div>
						</div>

						<?php
							if($despesas){
						?>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="id_cm">Empresa CM</label>
									<input type="hidden" name="id_despesa" id="id_despesa" value="<?= $records[0]->id_despesa; ?>" />
									<select name='id_cm' class="form-control select" disabled>
										<!-- <option value=''>Selecione</option> -->
										<?php
										foreach($this->empresas as $key=>$value){
											if($value->id == $records[0]->id_cm){
												echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome_fantasia).'</option>';
											}else{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome_fantasia).'</option>';
											}
										}
										?>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="id_fornecedor">Fornecedor</label>
									<select name='id_fornecedor' class="form-control select" disabled>
										<!-- <option value=''>Selecione</option> -->
										<?php
										foreach($fornecedores as $key=>$value)
										{
											if($value->id == $records[0]->id_fornecedor)
											{
												echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->razao_social).'</option>';
											}
											else
											{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->razao_social).'</option>';
											}
										}
										?>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="id_centro_custo">Centro de Custo</label>
									<select name='id_centro_custo' id='id_centro_custo' class="form-control select" disabled>
										<!-- <option value=''>Selecione</option> -->
										<?php
										foreach($centro_custo as $key=>$value){
											if($value->id == $records[0]->id_centro_custo){
												echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome).'</option>';
											}else{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome).'</option>';
											}
										}
										?>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="id_grupo">Grupos</label>
									<select name='id_grupo' id='id_grupo' class="form-control select" disabled>
										<!-- <option value=''>Selecione</option> -->
										<?php
										foreach($grupos as $key=>$value){
											if($value->id == $records[0]->id_grupo){
												echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome).'</option>';
											}else{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome).'</option>';
											}
										}
										?>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="id_conta">Conta</label>
									<select name='id_conta' id='id_conta' class="form-control select" disabled>
										<?php
											foreach ($contas as $key => $value) {
												if(!isset($records) && $value->id == 3 ){
												?>
													<option value='<?= $value->id ?>' data-prioridade="<?= $value->prioridade ?>" selected><?= $value->nome ?></option>
												<?php
												}elseif($value->id == $records[0]->id_conta){
												?>
													<option value='<?= $value->id ?>' data-prioridade="<?= $value->prioridade ?>" selected><?= $value->nome ?></option>
												<?php
												}else{
												?>
													<option value='<?= $value->id ?>' data-prioridade="<?= $value->prioridade ?>"><?= $value->nome ?></option>
												<?php
												}
											}
										?>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="id_subconta">Sub Conta</label>
									<input type="hidden" value="<?php echo isset($records[0])?$records[0]->id_subconta:null ?>" name="subconta" id="subconta" />
									<select name='id_subconta' id='id_subconta' class="form-control" disabled>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="data_vencimento">Data Vencimento</label>
									<input type="text" maxlength="60" class="form-control datepast" value="<?php echo isset($records[0])?convertDate($records[0]->data_vencimento):null ?>" name="data_vencimento" id="data_vencimento" disabled/>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="valor">Valor</label>
									<input type="text" maxlength="60" class="form-control mask-money" class="form-control" value="<?= isset($records[0])?$records[0]->valor:null ?>" name="valor" id="valor" required disabled/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="historico">Historico</label>
									<input type="text" maxlength="60" class="form-control" class="form-control" value="<?php echo isset($records[0])?$records[0]->historico:null ?>" name="historico" disabled />
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="descricao">Descricao</label>
									<input type="text" maxlength="60" class="form-control" value="<?php echo isset($records[0])?$records[0]->descricao:null ?>" name="descricao" disabled/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group" id="saldos">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<span style="color:white;background-color: grey ">
									<?= (isset($this->parametros[3]))?base64_decode($this->parametros[3]):null; ?><br><br>
								</span>
							</div>
						</div>
						<?php
							}else{
						?>
						<div class="row">
							<div class="col-md-6">
								<h5>Não há mais contas para aprovar no periodo selecionado</h>
							</div>
						</div>
						<?php
							}
						?>
						<div class="row">
							<div class="col-md-12">
								<button type="button" class="form-control btn btn-success action" value="aprovar">Aprovar</button>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<button type="button" class="form-control btn btn-primary action" value="anterior">Anterior</button>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<button type="button" class="form-control btn btn-warning action" value="proximo">Proximo</button>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<button type="button" class="form-control btn btn-danger  action" value="reprovar">Reprovar</button>
							</div>
						</div>
					</fieldset>
				</form>
			</div>
		</div>
	</div>

	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>

<script type="text/javascript">
	$(function() {
		$('.action').click(function(){
			var $action     = $(this).val(); 
			var $id_despesa = $('#id_despesa').val();
			var $atual      = '<?= $atual ?>';
			if($action == 'proximo' || $action == 'anterior' || $action == 'search'){
				$('#action').val($action);
				$('#periodo').submit();
				//window.location = url+$action+'/'+$atual;
				//window.location = url+$action+'/'+$atual;
			}else{
				$.ajax({
			        url: '/despesas/autorizaMobile/action/'+$action+'/'+$id_despesa,
			        type: 'POST',
			        success: function (data){
			        	// console.log(data);
			        	var retorno = JSON.parse(data);
			        	if(retorno.codigo == 0){
			        		alert(retorno.mensagem);
			        		if($atual > 0){
			        			$atual--;
			        		}
			        		$('#action').val($action);
							alert($('#action').val());
							$('#periodo').submit();
			        	}else{
			        		alert(retorno.mensagem);
			        	}		        	
			        },
			        error: function (error){
			        	console.log(error);
			        }
				});
			}			
		});
		$('.mask-money').maskMoney({allowNegative: false, thousands:'.', decimal:','});
		$('.mask-money').each(function(){ // function to apply mask on load!
		    $(this).maskMoney('mask', $(this).val());
		})
		var id_conta   = $('#id_conta').val();
		var subconta   = $('#subconta').val();
		var prioridade = $('#id_conta option:selected').attr('data-prioridade');
		$('#prioridade').val(prioridade);
		includeSubContas(id_conta);
		function includeSubContas(id_conta){
			var str = '';
			$.ajax({
			        url: '/orcamento/getsubconta/?id_conta='+id_conta,
			        //datatype: 'json',
			        //contentType: 'application/json; charset=utf-8',
			        type: 'POST',
			        success: function (data){
			        	var subcontas = JSON.parse(data);
			        	//console.log(subcontas);
			        	//alert(dados[0].id_conta);
			        	$.each(subcontas,function(i, dados){
			        		if(dados.id == subconta){
			        			str += '<option value=' + dados.id + ' selected>' + dados.nome + '</option>';
			        			//alert(dados.id);
			        			//getSaldos(dados.id);
			        		}else{
			        			//alert(dados.id);
			        			str += '<option value=' + dados.id + '>' + dados.nome + '</option>';
			        		}
			        		$('#id_subconta').html(str);
			        	});
			        	id_subconta = $('#id_subconta').find(":selected").val();
			        	getSaldos(id_subconta);
			        },
			        error: function (error){
			        }
			});
			return str;
		}
		function getSaldos(subconta = false){
			id_despesa = $('#id_despesa').val();
			tipo       = $('#tipo').val();
			id_cc      = $('#id_centro_custo').val();
			id_grupo   = $('#id_grupo').val();
			id_conta   = $('#id_conta').val();
			var is_mob = '<?= $is_mobile ?>'; 
			if(subconta == false){
				id_subconta = $('#id_subconta').val();
			}else{
				id_subconta = subconta;
			}
			data_vencimento = $('#data_vencimento').val();
			valor = $('#valor').val();
			var str = '';
			$.ajax({
		        url: '/despesas/ajaxDadosOrcamento/',
		        //datatype: 'json',
		        //contentType: 'application/json; charset=utf-8',
		        type: 'POST',
		        data: { tipo:tipo, id_despesa:id_despesa, id_cc:id_cc,id_grupo:id_grupo,id_conta:id_conta, id_subconta:id_subconta, data_vencimento:data_vencimento, valor:valor },
		        success: function (data){
		        	var saldos = JSON.parse(data);
		        	if(is_mob == 'sim'){
		        		//alert(dados[0].id_conta);
			        	str = '<table class="table table-default table-striped table-bordered table-hover" ><th>Nome</th><th>Saldo Orçamento</th><th>Saldo</th><tbody>';
			        	$.each(saldos,function(i, dados){
			        		// console.log(i);
			        		// console.log(dados);
			        		str += '<tr><td>'+dados.nome+'</td><td>'+dados.orcamento+'</td><td>'+dados.saldo+'</td></tr>';
								});
			        	str += '</tbody></table>';
								console.log(str);
		        	}else{
		        		//alert(dados[0].id_conta);
			        	str = '<table class="table table-default table-striped table-bordered table-hover" ><th>Area</th><th>Nome</th><th>Saldo Orçamento</th><th>Despesas</th><th>Saldo</th><tbody>';
			        	$.each(saldos,function(i, dados){
			        		// console.log(i);
			        		// console.log(dados);
			        		str += '<tr><td>'+dados.area+'</td><td>'+dados.nome+'</td><td>'+dados.orcamento+'</td><td>'+dados.despesa+'</td><td>'+dados.saldo+'</td></tr>';
								});
			        	str += '</tbody></table';
								console.log(str);
		        	}	
		        	$('#saldos').html(str);
		        },
		        error: function (error){
		        	console.log(error);
		        }
			});
		}

		$('#id_centro_custo').change(function(){
			getSaldos();
		});

		$('#id_grupo').change(function(){
			getSaldos();
		});

		$('#data_vencimento').change(function(){
			getSaldos();
		});

		$('#valor').change(function(){
			getSaldos();
		});

		$('#tipo').change(function(){
			getSaldos();
		});

		$('#id_conta').change(function(){
			var id_conta = $(this).val();
			var prioridade = $('#id_conta option:selected').attr('data-prioridade');
			$('#prioridade').val(prioridade);
			includeSubContas(id_conta);
		});

		$('#id_subconta').change(function(){
			getSaldos();
		});
		getSaldos();
	});
</script>
<!-- /PAGE SCRIPTS -->
</body>
</html>