<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "retorno de remessas";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Contas a pagar</li>
		<li>Detalhe</li>
	</ol>
	<h4 class="page-title">
		<?php
		if(empty($this->parametros[1])){
			echo '<i class="fa fa-plus"></i> Novo Despesa';
		}else{
			echo '<i class="fa fa-edit"></i> Editar Despesa';
		}
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-12">
				<form id="form_despesa" action="" name="form_despesa" method="post">
					<fieldset>
						<legend>Dados da despesa</legend>
					</fieldset>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="id_cm">Empresa CM</label>
								<input type="hidden" name="id_despesa" id="id_despesa" value="<?= $this->parametros[1]; ?>">
								<select name='id_cm' class="form-control select">
									<!-- <option value=''>Selecione</option> -->
									<?php
									foreach($this->empresas as $key=>$value){
										if($value->id == $records[0]->id_cm){
											echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome_fantasia).'</option>';
										}else{
											echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome_fantasia).'</option>';
										}
									}
									?>
								</select>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="id_fornecedor">Fornecedor</label>
								<select name='id_fornecedor' id='id_fornecedor' class="form-control select">
									<!-- <option value=''>Selecione</option> -->
									<?php
										foreach($fornecedores as $key=>$value){
											if($value->id == $records[0]->id_fornecedor){
												echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->razao_social).' - '.$value->cnpj_cpf.'</option>';
											}else{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->razao_social).' - '.$value->cnpj_cpf.'</option>';
											}
										}
									?>
								</select>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="id_centro_custo">Centro de Custo</label>
								<select name='id_centro_custo' id='id_centro_custo' class="form-control select">
									<option value=''>Selecione</option>
									<?php
										foreach($centro_custo as $key=>$value){
											if($value->id == $records[0]->id_centro_custo){
												echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome).'</option>';
											}else{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome).'</option>';
											}
										}
									?>
								</select>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="id_grupo">Grupos</label>
								<select name='id_grupo' id='id_grupo' class="form-control select">
									<option value=''>Selecione</option>
									<?php
									foreach($grupos as $key=>$value){
										if($value->id == $records[0]->id_grupo){
											echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome).'</option>';
										}else{
											echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome).'</option>';
										}
									}
									?>
								</select>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label for="id_conta">Conta</label>
								<select name='id_conta' id='id_conta' class="form-control select">
									<option value='' data-prioridade="" >Selecione...</option>
									<?php
										foreach ($contas as $key => $value){
											if($value->id == $records[0]->id_conta){ ?>
												<option value='<?= $value->id ?>' data-prioridade="<?= $value->prioridade ?>" selected><?= $value->nome ?></option>
											<?php }else{ ?>
												<option value='<?= $value->id ?>' data-prioridade="<?= $value->prioridade ?>"><?= $value->nome ?></option>
											<?php }
										}
									?>
								</select>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="id_subconta">Sub Conta</label>
								<input type="hidden" value="<?= isset($records[0])?$records[0]->id_subconta:null ?>" name="subconta" id="subconta"/>
								<select name='id_subconta' id='id_subconta' class="form-control">
								</select>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="prioridade">Prioridade</label>
								<input type="text" name = "prioridade" id="prioridade" readonly="readonly" class="form-control">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-3">
							<div class="form-group">
								<label for="tipo_despesa">Tipo de despesa</label>
								<select name='tipo_despesa' id='tipo_despesa' class="form-control select">
									<option value="fornecedor" <?= (isset($records[0]->tipo_despesa) && $records[0]->tipo_despesa == 'fornecedor')?'selected':null ?>>Fornecedor</option>
									<option value="pessoal" <?= (isset($records[0]->tipo_despesa) && $records[0]->tipo_despesa == 'pessoal')?'selected':null ?>>Pessoal</option>
									<option value="tributo" <?= (isset($records[0]->tipo_despesa) && $records[0]->tipo_despesa == 'tributo')?'selected':null ?>>Tributos</option>
								</select>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label for="tipo_cobranca">Tipo de Cobrança</label>
								<select name='tipo_cobranca' id='tipo_cobranca' class="form-control select">
									<option value="concessionaria" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'concessionaria')?'selected':null ?>>AGUA, LUZ, TELEFONE</option>	
									<option value="darf_simples" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'darf_simples')?'selected':null ?>>DARF SIMPLES</option>
									<option value="darf_normal" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'darf_normal')?'selected':null ?>>DARF NORMAL</option>
									<option value="darj" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'darj')?'selected':null ?>>DARJ</option>
									<option value="dpvat" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'dpvat')?'selected':null ?>>DPVAT</option>
									<option value="fatura" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'fatura')?'selected':null ?>>FATURA</option>
									<option value="salario" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'salario')?'selected':null ?>>SALARIO</option>
									<option value="adiantamento" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'adiantamento')?'selected':null ?>>ADIANTAMENTO</option>
									<option value="beneficio" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'beneficio')?'selected':null ?>>BENEFICIOS</option>
									<option value="prolabore" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'prolabore')?'selected':null ?>>PROLABORE</option>
									<option value="reembolso" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'reembolso')?'selected':null ?>>REEMBOLSO</option>
									<option value="fgts" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'fgts')?'selected':null ?>>FGTS</option>
									<option value="gare_sp" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'gare_sp')?'selected':null ?>>GARE SP</option>
									<option value="gare_sp_icms" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'gare_sp_icms')?'selected':null ?>>GARE SP ICMS</option>
									<option value="gare_sp_dr" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'gare_sp_dr')?'selected':null ?>>GARE SP DR</option>
									<option value="gare_sp_itcmd" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'gare_sp_itcmd')?'selected':null ?>>GARE SP ITCMD</option>
									<option value="gps" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'gps')?'selected':null ?>>GPS PADRÃO</option>
									<option value="gps_parc" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'gps_parc')?'selected':null ?>>GPS PARCELAMENTO</option>
									<option value="iptu" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'iptu')?'selected':null ?>>IPTU</option>
									<option value="ipva" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'ipva')?'selected':null ?>>IPVA</option>
									<option value="licenciamento" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'licenciamento')?'selected':null ?>>LICENCIAMENTO</option>
									<option value="nota fiscal" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'nota fiscal')?'selected':null ?>>NOTA FISCAL</option>
									<option value="recibo" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'recibo')?'selected':null ?>>RECIBO</option>
									<option value="outros" <?= (isset($records[0]->tipo_cobranca) && $records[0]->tipo_cobranca == 'outros')?'selected':null ?>>OUTROS</option>
								</select>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label for="numero_documento">Numero do documento(Nf, Fatura etc.)</label>
								<input type="text" name="numero_documento" id="numero_documento" class="form-control" value="<?= isset($records[0])?$records[0]->numero_documento:null ?>" required />
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label for="meio_pagamento">Meio de Pagamento</label>
								<select name='meio_pagamento' id='meio_pagamento' class="form-control select">
									<option value="boleto_cc" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'boleto_cc')?'selected':null ?>>Boleto com codigo de barra</option>
									<option value="boleto_sc" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'boleto_sc')?'selected':null ?>>Boleto sem codigo de barra</option>
									<option value="caixa" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'caixa')?'selected':null ?>>Caixa</option>
									<option value="cartao_credito" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'cartao_credito')?'selected':null ?>>Cartão de crédito</option>
									<option value="cheque_adm" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'cheque_adm')?'selected':null ?>>Cheque Administrativo</option>
									<option value="cheque_comum" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'cheque_comum')?'selected':null ?>>Cheque Comum</option>
									<option value="credito_tributario" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'credito_tributario')?'selected':null ?>>Crédito Tributário</option>
									<option value="debito_automatico" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'debito_automatico')?'selected':null ?>>Débito Automatico</option>
									<option value="guia_recolhimento" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'guia_recolhimento')?'selected':null ?>>Guia de Recolhimento</option>
									<option value="orderm_pagamento" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'orderm_pagamento')?'selected':null ?>>Ordem de Pagamento</option>
									<!-- <option value="pix" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'pix')?'selected':null ?>>PIX</option> -->
									<option value="transferencia" <?= (isset($records[0]->meio_pagamento) && $records[0]->meio_pagamento == 'transferencia')?'selected':null ?>>Transfêrencia (TED, DOC, Mesmo banco)</option>
								</select>
							</div>
						</div>
					</div>			
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label for="historico">Historico</label>
								<input type="text" maxlength="60" class="form-control" value="<?= isset($records[0])?$records[0]->historico:null ?>" name="historico" />
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-3">
							<div class="form-group">
								<label for="data_vencimento">Data Vencimento</label>
								<input type="text" maxlength="60" class="form-control datepast" value="<?= isset($records[0])?convertDate($records[0]->data_vencimento):$data_vencimento->format('d/m/Y') ?>" name="data_vencimento" id="data_vencimento" required/>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label for="valor">Valor Principal</label>
								<input type="text" maxlength="60" class="form-control mask-money" class="form-control" value="<?= isset($records[0])?$records[0]->valor:null ?>" name="valor" id="valor" required/>
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label for="multa">Total de Multas</label>
								<input type="text" maxlength="60" class="form-control mask-money" class="form-control" value="<?= isset($records[0])?$records[0]->multa:null ?>" name="multa" id="multa" />
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label for="juros">Total de Juros</label>
								<input type="text" maxlength="60" class="form-control mask-money" class="form-control" value="<?= isset($records[0])?$records[0]->juros:null ?>" name="juros" id="juros" />
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label for="outros_valores">Outros Valores a pagar</label>
								<input type="text" maxlength="60" class="form-control mask-money" class="form-control" value="<?= isset($records[0])?$records[0]->outros_valores:null ?>" name="outros_valores" id="outros_valores" />
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="abatimento">Total de Abatimentos</label>
								<input type="text" maxlength="60" class="form-control mask-money" class="form-control" value="<?= isset($records[0])?$records[0]->abatimento:null ?>" name="abatimento" id="abatimento" />
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="desconto">Total de descontos</label>
								<input type="text" maxlength="60" class="form-control mask-money" class="form-control" value="<?= isset($records[0])?$records[0]->desconto:null ?>" name="desconto" id="desconto" />
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12"></div>
					</div>
					<fieldset>
						<legend>Informações complementares</legend>
					</fieldset>
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label for="codigo_receita">Codigo da Receita</label>
								<input type="text" maxlength="60" class="form-control" value="<?= isset($records[0])?$records[0]->codigo_receita:null ?>" name="codigo_receita" id="codigo_receita" />
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="divida_ativa">Codigo da Divida Ativa</label>
								<input type="text" maxlength="60" class="form-control" value="<?= isset($records[0])?$records[0]->divida_ativa:null ?>" name="divida_ativa" id="divida_ativa" />
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="identificacao_contribuinte">Identificação do Contribuinte</label>
								<input type="text" maxlength="60" class="form-control" value="<?= isset($records[0])?$records[0]->identificacao_contribuinte:null ?>" name="identificacao_contribuinte" id="identificacao_contribuinte" />
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-3">
							<div class="form-group">
								<label for="codigo_tributo">Codigo do Tributo</label>
								<input type="text" maxlength="60" class="form-control" value="<?= isset($records[0])?$records[0]->codigo_tributo:null ?>" name="codigo_tributo" id="codigo_tributo" />
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label for="periodo_apuracao">Periodo de apuração</label>
								<input type="text" maxlength="60" class="form-control datepast" value="<?= isset($records[0])?convertDate($records[0]->periodo_apuracao):null ?>" name="periodo_apuracao" id="periodo_apuracao" />
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label for="competencia">Competencia</label>
								<input type="text" maxlength="60" class="form-control dateyymm" value="<?= isset($records[0])?$records[0]->competencia:null ?>" name="competencia" id="competencia" />
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<label for="numero_referencia">Numero de Referencia</label>
								<input type="text" maxlength="60" class="form-control" value="<?= isset($records[0])?$records[0]->numero_referencia:null ?>" name="numero_referencia" id="numero_referencia" />
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="atualizacao_monetaria">Atualização Monetaria</label>
								<input type="text" maxlength="60" class="form-control" value="<?= isset($records[0])?$records[0]->atualizacao_monetaria:null ?>" name="atualizacao_monetaria" id="atualizacao_monetaria" />
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="percentual_receita">Percentual da Receita</label>
								<input type="text" maxlength="60" class="form-control mask-money" value="<?= isset($records[0])?$records[0]->percentual_receita:null ?>" name="percentual_receita" id="percentual_receita" />
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label for="parcelado">Parcelado</label>
									<select name="parcelado" class="form-control">
										<option value='0' <?= (isset($records[0]) && $records[0]->parcelado == 0)?'selected':'' ?> >Não</option>
										<option value='1' <?= (isset($records[0]) && $records[0]->parcelado == 1)?'selected':'' ?> >Sim</option>
									</select>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="numero_parcelas">Numero de parcelas</label>
								<input type="text" maxlength="60" class="form-control" value="<?= isset($records[0])?$records[0]->numero_parcelas:null ?>" name="numero_parcelas"/>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="parcela_numero">Parcela numero</label>
								<input type="text" maxlength="60" class="form-control" value="<?= isset($records[0])?$records[0]->parcela_numero:null ?>" name="parcela_numero"/>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="tipo">Tipo</label>
								<select name='tipo' id="tipo" class="form-control select">
									<option value='comercial' <?= (isset($records[0]) && $records[0]->tipo == 'comercial')?'selected':'' ?> >Comercial</option>
									<option value='global' <?= (isset($records[0]) && $records[0]->tipo == 'global')?'selected':'' ?> >Global</option>
								</select>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="codigo_barra">Codigo de barras (Obrigatorio para pagamentos por boleto)</label>
								<input type="text" maxlength="60" class="form-control" value="<?= isset($records[0])?$records[0]->codigo_barra:null ?>" name="codigo_barra" id="codigo_barra"/>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label for="descricao">Descricao</label>
								<textarea class="form-control" name="descricao" id="descricao" rows="3"><?= isset($records[0])?$records[0]->descricao:null ?></textarea>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label for="data_pagamento">Data de Pagamento</label>
								<input type="text" maxlength="60" class="form-control datepast" value="<?= isset($records[0])?convertDate($records[0]->data_pagamento):null ?>" name="data_pagamento"/>
							</div>
						</div>
						<?php if(isset($records[0]) && $records[0]->status_autorizacao == 'aprovado'){ ?>
							<div class="col-md-4">
								<div class="form-group">
									<label for="status">Status</label>
										<select name='status' class="form-control select" <?= (isset($records[0]) && $records[0]->status == 'pago')?'disabled':'' ?> >
											<option value='aberto' <?= (isset($records[0]) && $records[0]->status == 'aberto')?'selected':'' ?> >Aberto</option>
											<option value='pago' <?= (isset($records[0]) && $records[0]->status == 'pago')?'selected':'' ?> >Pago</option>
										</select>
								</div>
							</div>
						<?php }else{ ?>
							<div class="col-md-4">
								<div class="form-group">
									<label for="status">Status</label>
										<select name='status' class="form-control select" <?= (isset($records[0]) && $records[0]->status == 'pago')?'disabled':'' ?> >
											<option value='aberto' <?= (isset($records[0]) && $records[0]->status == 'aberto')?'selected':'' ?> >Aberto</option>
											<!-- <option value='pago' <?= (isset($records[0]) && $records[0]->status == 'pago')?'selected':'' ?> >Pago</option> -->
										</select>
								</div>
							</div>
						<?php } ?>
						<div class="col-md-4">
							<div class="form-group">
								<label for="status_remessa">Status Remessa</label>
								<select name='status_remessa' class="form-control select" disabled >
									<option value='pendente' <?= (isset($records[0]) && $records[0]->status_remessa == 'pendente')?'selected':'' ?> >Pendente</option>
									<option value='enviado' <?= (isset($records[0]) && $records[0]->status_remessa == 'enviado')?'selected':'' ?> >Enviado</option>
									<option value='processado' <?= (isset($records[0]) && $records[0]->status_remessa == 'processado')?'selected':'' ?> >Processado</option>
								</select>
							</div>
						</div>
					</div>
					<fieldset>
						<legend>Saldos</legend>
					</fieldset>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group" id="saldos">
							</div>
						</div>
					</div>
					<fieldset >
						<legend>Dados bancarios do fornecedor</legend>
					</fieldset>
					<div class="row">
						<div class="col-md-3">
							<button type="button" class="btn_add_conta_bancaria form-control btn btn-info"><i class="fa fa-plus" ></i> ADD CONTA BANCARIA</button>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="alert alert-danger" role="alert">
								<p><h4><b>Observações.</b></h4></p>
								<p>1 - A "Conta padrão para despesa" tem precedência sobre a "Conta padrão para fornecedores". Caso haja alguma conta desse tipo cadastrada para a despesa, o pagamento será feito na mesma.</p>
								<p>2 - Contas padrão para despesa só podem ser add após a despesa ser cadastrada no sistema.</p>
								<p>3 - Contas marcadas como padrão não podem ser excluidas, para excluir marque outra conta como padrão antes de apagar.</p>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12 col-md-12">
							<div class="form-group">
								<table id="table_bancos" class="table table-responsive">
									<thead>
										<tr>
											<th>ID</th>
											<th>COD BANCO</th>
											<th>NOME BANCO</th>
											<th>TIPO</th>
											<th>TIPO PIX</th>
											<th>CHAVE PIX</th>
											<th>AGENCIA</th>
											<th>CONTA</th>
											<th>ORIGEM</th>
											<th>SELECIONADA</th>
											<th>AÇAO</th>
										</tr>
									</thead>
									<tbody id='lista_banco'></tbody>
								</table>
							</div>
						</div>
					</div>
					<fieldset>
						<legend>Ações</legend>
					</fieldset>
					<div class="row">
						<div class="col-md-12">
							<span style="color:white;background-color: grey "><?= (isset($this->parametros[3]))?base64_decode($this->parametros[3]):null; ?><br><br></span>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<a href="/despesas/detalhe/id/0/" class=" form-control btn btn-success"><i class="fa fa-plus"></i> Nova Despesa</a>
						</div>
						<div class="col-md-6">
							<?php if(!isset($records[0]) || $records[0]->status != 'pago' || $_SESSION['cmswerp']['userdata']->nome_perfil == 'CEO'){ ?>
								<button type="button" id="btn-gravar" class="form-control btn btn-primary"><i class="fa fa-save"></i> Salvar</button>		
							<?php } ?>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<div class="modal fade" tabindex="-1" role="dialog" id="ContaBancariaModal">
		<div class="modal-dialog " role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4><span class="modal-title"></span></h4>
				</div>
				<div class="modal-header">
					<span><b>CADASTRO DE CONTA BANCARIA</b></span>	
				</div>
				<div class="modal-body">
					<form id="form_conta_bancaria" action="" name="form_conta_bancaria" method="post" >
						<div class="row">
							<div class="col-md-12">
								<input type="hidden" name="modal_fornecedor" id="modal_fornecedor" value="" />
								<p class='alert alert-success' role='alert' id="span_nome_fornecedor"></p>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<input type="hidden" class="form-control" name="id_empresa" id="id_empresa" value="" />
								<input type="hidden" class="form-control" name="id_banco_bacen" id="id_banco_bacen" value="" />
								<label>Banco</label>
								<input type="text" class="form-control" name="nome_banco" id='autocomplete' />
							</div>
						</div>
						<div class="form-group">
							<label for="tipo_conta">Tipo da Conta</label>
							<select name="tipo_conta" id="tipo_conta" class="form-control select">
								<option value="c">Conta Corrente</option>
								<option value="p">Conta Poupança</option>
								<option value="pix">Chave Pix</option>
							</select>
						</div>
						<div class="form-group">
							<label for="tipo_chave_pix">Tipo da chave</label>
							<select name="tipo_chave_pix" id="tipo_chave_pix" class="form-control select">
								<option value="cnpj">CNPJ</option>	
								<option value="cpf">CPF</option>
								<option value="email">Email</option>
								<option value="telefone">Telefone</option>
								<option value="aleatoria">Aleatoria</option>
							</select>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label>Chave PIX</label>
								<input type="text" class="form-control" name="chave_pix" id='chave_pix' />
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label>Agência</label>
								<input type="text" class="form-control" name="numero_agencia" id='numero_agencia' />
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label>Digito Agência</label>
								<input type="text" class="form-control" name="digito_agencia" id='digito_agencia' />
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label>Numero da conta</label>
								<input type="text" class="form-control" name="numero_conta" id='numero_conta' />
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label>Digito conta</label>
								<input type="text" class="form-control" name="digito_conta" id='digito_conta' />
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label>Origem da conta</label>
									<select name="origem_conta" id="origem_conta" class="form-control select">
									<option value="fornecedor">Fornecedor</option>
								</select>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label>Conta default</label>
								<select name="conta_default" id="conta_default" class="form-control select">
									<option value="1">Sim</option>
									<option value="0">Não</option>
								</select>
							</div>
						</div>
						<div class="row">
						<div class="col-md-12">
							<div id="msg_obs" >
							</div>
						</div>
					</div>
						<div class="row">
							<div class="col-md-12">
								<button type="button" id="btn_incluir_conta_bancaria" class="form-control btn btn-info"><i class="fa fa-plus"></i> INCLUIR CONTA</button>
							</div>
						</div>
					</form>	
				</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div>
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<?php include "template/modal_sistema.php" ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<!-- <script type="text/javascript" src="/libs/disableautofill/jquery.disableautofill.js"></script> -->
	<script type="text/javascript">
		$('#autocomplete').autocomplete({
			minLength: 1,
			autoFocus: true,
			delay: 300,
			position: {
				my: 'left top',
				at: 'right top'
			},
			appendTo: '#form_conta_bancaria',
			source: function(request, response){
				$.ajax({
					url: '/contabancaria/getBancoList',
					type: 'post',
					dataType: 'json',
					data: {
						'search': request.term
					}
				}).done(function(data){
					// obj = JSON.parse(data);   //parse the data in JSON (if not already)
					response($.map(data, function(item){
						return {
							label: item.nome_reduzido,
							value: item.id
						}
					}))
				});
			},
			select:function(event, ui){
				console.log(event); 
				$('#autocomplete').val(ui.item.label);
				$('#id_banco_bacen').val(ui.item.value);
				return false;
			}   
		});
	</script>
	<script type="text/javascript">
		$(function(){
			// carregando id do fornecedor ao carregar a tela
			var id_fornecedor = $('#id_fornecedor').val();
			//configurando id empresa com id do fornecedor por padrao.
			$('#id_empresa').val(id_fornecedor);
			var id_despesa    = "<?= $this->parametros[1]; ?>";
			function checkContaBancaria(tipo, id){
				if(tipo == 'despesa'){
					url_conta = "/contabancaria/getContasBancariasJson/despesa/"+id;
				}else if(tipo == 'fornecedor'){
					url_conta = "/contabancaria/getContasBancariasJson/fornecedor/"+id;
				}
				var response = null;
				$.ajax({
					type: "GET",   
					url: url_conta,   
					async: false,
					success : function(data) {
						// Here you can specify that you need some exact value like responseText
						response = data;
					}
				});
				var obj = JSON.parse(response);
				if(obj.codigo == 0){
					return true;
				}else{
					return false;
				}
			}

			$('#btn-gravar').click(function(){
				var id_fornecedor = $('#id_fornecedor').val();
				console.log(id_fornecedor);
				var url   = "<?= HOME_URI.$this->nome_modulo.'/save/id/' ?>"+id_despesa;
				var dados_form = $('#form_despesa').serialize();
				var meio_pagamento = $('#meio_pagamento').val();
				var tipo_cobranca  = $('#tipo_cobranca').val();
				switch (meio_pagamento) {
					case 'boleto_cc':
						var codigo_barras = $.trim($('#codigo_barra').val());
						if(codigo_barras == '' && codigo_barras.length < 1 ){
							$('#painel_error_msg').text('Preencha o codigo de barras');
							$('#modal_erro_sistema').modal('show');
							return;
						}
					break;
					case 'transferencia':
						var chk1 = checkContaBancaria('fornecedor', id_fornecedor);
						var chk2 = checkContaBancaria('despesa', id_despesa);
						console.log(chk1);
						console.log(chk2);
						if(chk1 == false && chk2 == false){
							$('#painel_error_msg').text('Nenhuma conta bancaria encontrada para o fornecedor ou despesa');
							$('#modal_erro_sistema').modal('show');
							return;
						}
					break;
					case 'guia_recolhimento':
						switch (tipo_cobranca){
							case 'gps':
							case 'gps_parc':
							case 'darf_normal':
							case 'darf_simples':
								var identificacao_contribuinte = $.trim($('#identificacao_contribuinte').val());
								if(identificacao_contribuinte == '' && identificacao_contribuinte.length < 1 ){
									$('#painel_error_msg').text('Preencha o campo identificacao do contribuinte');
									$('#modal_erro_sistema').modal('show');
									return;
								}
							break;
						}
					break;
				}
				
				$.ajax({
					url: url,
					data: dados_form,
					type: 'POST',
					beforeSend: function() {
						// setting a timeout
						waitingDialog.show('PROCESSANDO...');
					},
					success: function (data){
						waitingDialog.hide();
						var obj_json = JSON.parse(data);
						if(obj_json.codigo == 0){
							$('#painel_success_msg').text(obj_json.mensagem);
							$('#modal_sucesso_sistema').modal('show');
							$('#modal_sucesso_sistema').on('hidden.bs.modal', function () {
								window.location.href = '/despesas/index';
							})
						}else{
							$('#painel_error_msg').text(obj_json.mensagem);
							$('#modal_erro_sistema').modal('show');
							return;
						}
					},
					error: function (error){
						waitingDialog.hide();
						// console.log(error);
						$('#painel_error_msg').text('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
						$('#modal_erro_sistema').modal('show');
						alert();
					}
				});
			});
			
			//montando as tabelas com as contas bancarias
			montaTabelaBancos(id_fornecedor, 'fornecedor');
			montaTabelaBancos(id_despesa, 'despesa');
			
			$('#id_fornecedor').change(function(){
				var id_fornecedor = $('#id_fornecedor').val();
				$('#id_empresa').val(id_fornecedor);
				montaTabelaBancos(id_fornecedor);
			});

			$('#origem_conta, #conta_default').change(function(){
				
				var origem_conta  = $('#origem_conta').val();
				var conta_default = $('#conta_default').val()

				if(origem_conta == 'fornecedor'){
					if($('#conta_default').val() == 1){
						$('#id_empresa').val(id_fornecedor);
						var nome_fornecedor = $( "#id_fornecedor option:selected").text();
						msg_obs = "<p class='alert alert-danger' role='alert'>Essa conta será utilizada para pagamento de todas as despesas do fornecedor "+nome_fornecedor+"</p>";
					}else{
						msg_obs = null;
					}
				}else if(origem_conta == 'despesa'){
					$('#id_empresa').val(id_despesa);
					if($('#conta_default').val() == 1){
						msg_obs = "<p class='alert alert-danger' role='alert'>Essa conta será utilizada para pagamento apenas dessa despesa!</p>";	
					}else{
						msg_obs = null;
					}
				}
				$('#msg_obs').html(msg_obs);
			});

			$('.btn_add_conta_bancaria').click(function(){
				var nome_fornecedor = $( "#id_fornecedor option:selected").text();
				// exibe o nome do fornecedor no modal de cadastro das contas bancarias
				$('#span_nome_fornecedor').html(nome_fornecedor);
				// add o id do fornecedor no form de cadastro de contas bancarias
				$('#modal_fornecedor').val($( "#id_fornecedor").val());
				msg_obs = "<p class='alert alert-danger' role='alert'>Essa conta será utilizada para pagamento de todas as despesas do fornecedor "+nome_fornecedor+"</p>";
				$('#msg_obs').html(msg_obs);
				if(id_despesa > 0){
					if($("#origem_conta option[value='despesa']").length == 0){
						$('#origem_conta').append('<option value="despesa">Despesa</option>').selectpicker('refresh');
					}
				}
				$('#ContaBancariaModal').modal('show');
			});

			$('#btn_incluir_conta_bancaria').click(function(){
				var url   = "/contabancaria/save";
				var dados_conta_bancaria = $('#form_conta_bancaria').serialize();
				console.log(dados_conta_bancaria);
				$.ajax({
					url: url,
					data: dados_conta_bancaria,
					type: 'POST',
					beforeSend: function() {
						// setting a timeout
						waitingDialog.show('PROCESSANDO...');
					},
					success: function (data){
						var obj_json = JSON.parse(data);
						waitingDialog.hide();
						if(obj_json.codigo == 0){
							$('#painel_success_msg').text(obj_json.mensagem);
							$('#modal_sucesso_sistema').modal('show');
							$('#modal_sucesso_sistema').on('hidden.bs.modal', function () {
								location.reload();
							});
						}else{
							$('#painel_error_msg').text(obj_json.mensagem);
							$('#modal_erro_sistema').modal('show');
							// $('#div_aviso').html('<p style="color:red"><b>'+obj_json.mensagem+'</b></p>');
						}
					},
					error: function (error){
						waitingDialog.hide();
						console.log(error);
						alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
					}
				});
			});
		
			function montaTabelaBancos(id_empresa, origem_conta){
				var bancos = null;
				var table_rows = null;
				
				if(origem_conta == 'despesa'){
					var url = '/contabancaria/getContasBancariasJson/despesa/'+id_empresa;
				}else{
					var url = '/contabancaria/getContasBancariasJson/fornecedor/'+id_empresa;
				}

				$.ajax({
					url: url,
					// data: dados_form,
					type: 'POST',
					success: function (data){
						var obj_json = JSON.parse(data);
						console.log(obj_json);
						if(obj_json.codigo == 0){
							bancos = obj_json.output;
							$.each(bancos, function(index, element) {
								if(element.origem_conta == 'despesa' && element.conta_default == 1){
									var conta_default = 'SIM';
								}else if(element.origem_conta == 'fornecedor' && element.conta_default == 1){
									var conta_default = 'SIM';
								}else{
									var conta_default = 'NÃO';
								}

								table_rows += '<tr>';
								table_rows += '<td>';
								table_rows += element.id;
								table_rows += '</td>';
								table_rows += '<td>';
								if(element.codigo_banco){
									table_rows += element.codigo_banco;
								}else{
									table_rows += ' - ';
								}
								table_rows += '</td>';
								table_rows += '<td>';
								if(element.nome_reduzido){
									table_rows += element.nome_reduzido;
								}else{
									table_rows += ' - ';
								}
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += element.tipo_conta;
								table_rows += '</td>';
								table_rows += '<td>';
								if(element.tipo_chave_pix){
									table_rows += element.tipo_chave_pix;
								}else{
									table_rows += ' - ';
								}
								table_rows += '</td>';

								table_rows += '<td>';
								if(element.chave_pix){
									table_rows += element.chave_pix;
								}else{
									table_rows += ' - ';
								}
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += element.numero_agencia+'-'+element.digito_agencia;
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += element.numero_conta+'-'+element.digito_conta;
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += element.origem_conta;
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += conta_default;
								table_rows += '</td>';
								table_rows += '<td>';
								
								if(element.conta_default < 1 || element.conta_default == ''){
								    table_rows += '<div style="display: inline-flex; gap: 10px;">';
									table_rows += '<button type="button" data-origem="'+element.origem_conta+'" data-acao="default" class="uppercase action btn btn-info" value="'+element.id+'">SELECIONAR </span> </button>';
									table_rows += '<button type="button" data-acao="apagar" class="uppercase action btn btn-danger" value="'+element.id+'"><i class="fa fa-trash"></i> </span> </button>';
									table_rows += '</div>';
								}else{
									table_rows += ' - ';
								}

								table_rows += '</td>';
								table_rows += '</tr>';
								// console.log(element);
							});

							$('#lista_banco').append(table_rows);
							$('#table_bancos').show();
						}else{
							// $('#lista_banco').html('');
						}
					},
					error: function (error){	
						console.log(error);
						alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
					}
				});
			}

			function converteMoedaFloat(valor){
				if(valor === ""){
				valor =  0;
				}else{
				valor = valor.replace(".","");
				valor = valor.replace(",",".");
				valor = parseFloat(valor);
				}
				return valor;
			}

			$('.mask-money').maskMoney({allowNegative: false, thousands:'.', decimal:','});
			$('.mask-money').each(function(){ // function to apply mask on load!
				$(this).maskMoney('mask', $(this).val());
			})
			var id_conta   = $('#id_conta').val();
			var subconta   = $('#subconta').val();
			var prioridade = $('#id_conta option:selected').attr('data-prioridade');
			$('#prioridade').val(prioridade);
			includeSubContas(id_conta);
			function includeSubContas(id_conta){
				// var str = '';
				var str = '<option value="">Selecione...</option>';
				$.ajax({
						url: '/orcamento/getsubconta/?id_conta='+id_conta,
						//datatype: 'json',
						//contentType: 'application/json; charset=utf-8',
						type: 'POST',
						success: function (data){
							console.log(data);
							var subcontas = JSON.parse(data);
							//alert(dados[0].id_conta);
							$.each(subcontas,function(i, dados){
								
								if(dados.id == subconta){
									str += '<option value=' + dados.id + ' selected>' + dados.nome + '</option>';
									//alert(dados.id);
									//getSaldos(dados.id);
								}else{
									//alert(dados.id);
									str += '<option value=' + dados.id + '>' + dados.nome + '</option>';
								}
								$('#id_subconta').html(str);
							});
							id_subconta = $('#id_subconta').find(":selected").val();
							getSaldos(id_subconta);
						},
						error: function (error){
						}
				});
				return str;
			}

			function getSaldos(subconta = false){
				id_despesa    = $('#id_despesa').val();
				tipo          = $('#tipo').val();
				id_cc         = $('#id_centro_custo').val();
				id_grupo      = $('#id_grupo').val();
				id_conta      = $('#id_conta').val();

				nome_cc       = $('#id_centro_custo option:selected').text();
				nome_grupo    = $('#id_grupo option:selected').text();
				nome_conta    = $('#id_conta option:selected').text();

				if(subconta == false){
					id_subconta   = $('#id_subconta').val();
					nome_subconta = $('#id_subconta option:selected').text();
				}else{
					id_subconta = subconta;
				}
				data_vencimento = $('#data_vencimento').val();
				valor = $('#valor').val();
				var str = '';
				$.ajax({
					url: '/despesas/ajaxDadosOrcamento/',
					//datatype: 'json',
					//contentType: 'application/json; charset=utf-8',
					type: 'POST',
					data: { tipo:tipo,id_despesa:id_despesa,nome_cc:nome_cc,nome_grupo:nome_grupo,nome_conta:nome_conta,id_cc:id_cc,id_grupo:id_grupo,id_conta:id_conta,id_subconta:id_subconta, data_vencimento:data_vencimento, valor:valor },
					success: function (data) {
						var saldos = JSON.parse(data);
						var dados = saldos.dados;
						console.log(converteMoedaFloat(dados.saldo_centro_custo));
						console.log(converteMoedaFloat(dados.total_grupo));
						if(converteMoedaFloat(dados.total_grupo) > 0 && converteMoedaFloat(dados.total_centro_custo) > 0 ){
							$('#btn-gravar').show();
						}
						//alert(dados[0].id_conta);
						str = '<table class="table table-default table-striped table-bordered table-hover" width="100%"><th>Nome</th><th>Orçamento</th><th>Despesas</th><th>Saldo</th><tbody>';
						str += '<tr><td> Centro de custo - '+dados.nome_centro_custo+'</td><td>'+dados.orc_centro_custo+'</td><td>'+dados.debitos_centro_custo+'</td><td>'+dados.saldo_centro_custo+'</td></tr>';
						str += '<tr><td> Grupo - '+dados.nome_grupo+'</td><td>'+dados.orc_grupo+'</td><td>'+dados.debitos_grupo+'</td><td>'+dados.saldo_grupo+'</td></tr>';
						// str += '<tr><td>'+dados.nome_conta+'</td><td>'+dados.orc_conta+'</td><td>'+dados.debitos_conta+'</td><td>'+dados.saldo_conta+'</td></tr>';
						str += '</tbody></table';
						console.log(str);
						$('#saldos').html(str);
					},
					error: function (error){
						console.log(error);
					}
				});
			}

			$('#id_centro_custo').change(function(){
				getSaldos();
			});

			$('#id_grupo').change(function(){
				getSaldos();
			});

			$('#data_vencimento').change(function(){
				getSaldos();
			});

			$('#valor').change(function(){
				getSaldos();
			});

			$('#tipo').change(function(){
				getSaldos();
			});

			$('#id_conta').change(function(){
				var id_conta = $(this).val();
				var prioridade = $('#id_conta option:selected').attr('data-prioridade');
				$('#prioridade').val(prioridade);
				includeSubContas(id_conta);
			});

			$('#id_subconta').change(function(){
				getSaldos();
			});

			getSaldos();

			$(document).on('click', '.action', function(e) {
				e.preventDefault;
				// alert('teste');
				var id           = $(this).val();
				var id_despesa   = "<?= $this->parametros[1]; ?>";
				var id_empresa   = $('#id_fornecedor').val();
				var acao         = $(this).data('acao');
				var origem_conta = $(this).data("origem");
				
				if(acao == 'default'){
					if(origem_conta == 'despesa'){
						var url_action = '/contabancaria/checkContaDefault/despesa/id/'+id_despesa+'/'+id;
					}else{
						var url_action = '/contabancaria/checkContaDefault/fornecedor/id/'+id_empresa+'/'+id;
					}
				}else if(acao == 'apagar'){
					var url_action = '/contabancaria/apagar/id/'+id;
				}

				$.ajax({
					url: url_action,
					// data: dados_form,
					type: 'POST',
					success: function (data){
						var obj_json = JSON.parse(data);
						console.log(obj_json);
						if(obj_json.codigo == 0){
							location.reload();
						}else{
							//implementar erro 
						}
					},
					error: function (error){	
						console.log(error);
						alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
					}
				});
			})
		});
	</script>
	<!-- /PAGE SCRIPTS -->
	</body>	
</html>