<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "despesas";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Contas a pagar</li>
		<li>Detalhe</li>
	</ol>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-9">
				<form id="periodo" name="periodo" action="/despesas/listar/" method="post">
					<fieldset>
						<div class="row">
							<div class="col-md-12">
								<span><b><?= count($despesas)?> para serem aprovadas</b></span>
							</div>
						</div>
						<br>
						<div class="row">
							<div class="col-md-4">
								<input type="hidden" value="<?= $_POST['action'] ?>" id="action" name="action" />
								<input type="hidden" value="<?= $atual ?>"           id="indice" name="indice" />

								<label for="dt_ini">De</label>
								
								<input type="text" class="form-control datepast2" value="<?= $dt_ini->format('d/m/Y'); ?>" name="dt_ini" />
							</div>
							<div class="col-md-4">
								<label for="dt_fim">Até</label>
								<input type="text" class="form-control datepast2" value="<?= $dt_fim->format('d/m/Y'); ?>" name="dt_fim" />
							</div>
							<div class="col-md-4">
								<button type="button" class="form-control btn-primary action" id="search" value="search"><i class="fa fa-search"></i></button>
							</div>
						</div>

						<?php
							if($despesas){
						?>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<span>ID DESPESA: <?= $records[0]->id_despesa; ?></span>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="id_cm">Empresa CM</label>
									<input type="hidden" name="id_despesa" id="id_despesa" value="<?= $records[0]->id_despesa; ?>" />
									<select name='id_cm' class="form-control select" disabled>
										<!-- <option value=''>Selecione</option> -->
										<?php
										foreach($this->empresas as $key=>$value){
											if($value->id == $records[0]->id_cm){
												echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome_fantasia).'</option>';
											}else{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome_fantasia).'</option>';
											}
										}
										?>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="id_fornecedor">Fornecedor</label>
									<select name='id_fornecedor' class="form-control select" disabled>
										<!-- <option value=''>Selecione</option> -->
										<?php
										foreach($fornecedores as $key=>$value)
										{
											if($value->id == $records[0]->id_fornecedor)
											{
												echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->razao_social).'</option>';
											}
											else
											{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->razao_social).'</option>';
											}
										}
										?>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="id_centro_custo">Centro de Custo</label>
									<select name='id_centro_custo' id='id_centro_custo' class="form-control select" disabled>
										<!-- <option value=''>Selecione</option> -->
										<?php
										foreach($centro_custo as $key=>$value){
											if($value->id == $records[0]->id_centro_custo){
												echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome).'</option>';
											}else{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome).'</option>';
											}
										}
										?>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="id_grupo">Grupos</label>
									<select name='id_grupo' id='id_grupo' class="form-control select" disabled>
										<!-- <option value=''>Selecione</option> -->
										<?php
										foreach($grupos as $key=>$value){
											if($value->id == $records[0]->id_grupo){
												echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->nome).'</option>';
											}else{
												echo '<option value ="'.$value->id.'" >'.strtoupper($value->nome).'</option>';
											}
										}
										?>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="id_conta">Conta</label>
									<select name='id_conta' id='id_conta' class="form-control select" disabled>
										<?php
											foreach ($contas as $key => $value) {
												if(!isset($records) && $value->id == 3 ){
												?>
													<option value='<?= $value->id ?>' data-prioridade="<?= $value->prioridade ?>" selected><?= $value->nome ?></option>
												<?php
												}elseif($value->id == $records[0]->id_conta){
												?>
													<option value='<?= $value->id ?>' data-prioridade="<?= $value->prioridade ?>" selected><?= $value->nome ?></option>
												<?php
												}else{
												?>
													<option value='<?= $value->id ?>' data-prioridade="<?= $value->prioridade ?>"><?= $value->nome ?></option>
												<?php
												}
											}
										?>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="id_subconta">Sub Conta</label>
									<input type="hidden" value="<?php echo isset($records[0])?$records[0]->id_subconta:null ?>" name="subconta" id="subconta" />
									<select name='id_subconta' id='id_subconta' class="form-control" disabled>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="data_vencimento">Data Vencimento</label>
									<input type="text" maxlength="60" class="form-control datepast" value="<?php echo isset($records[0])?convertDate($records[0]->data_vencimento):null ?>" name="data_vencimento" id="data_vencimento" disabled/>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="valor">Valor</label>
									<input type="text" maxlength="60" class="form-control mask-money" class="form-control" value="<?= isset($records[0])?$records[0]->valor:null ?>" name="valor" id="valor" required disabled/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label for="historico">Historico</label>
									<input type="text" maxlength="60" class="form-control" class="form-control" value="<?php echo isset($records[0])?$records[0]->historico:null ?>" name="historico" disabled />
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label for="descricao">Descricao</label>
									<input type="text" maxlength="60" class="form-control" value="<?php echo isset($records[0])?$records[0]->descricao:null ?>" name="descricao" disabled/>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group" id="saldos">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<span style="color:white;background-color: grey ">
									<?= (isset($this->parametros[3]))?base64_decode($this->parametros[3]):null; ?><br><br>
								</span>
							</div>
						</div>
						<?php
							}else{
						?>
						<div class="row">
							<div class="col-md-6">
								<h5>Não há mais contas para aprovar no periodo selecionado</h>
							</div>
						</div>
						<?php
							}
						?>
						<div class="row">
							<div class="col-md-12">
								<button type="button" class="form-control btn btn-success action" value="aprovar" data-role="aprovar">Aprovar</button>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<button type="button" class="form-control btn btn-primary action" value="anterior">Anterior</button>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<button type="button" class="form-control btn btn-warning action" value="proximo">Proximo</button>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<button type="button" class="form-control btn btn-danger action" value="reprovar">Reprovar</button>
							</div>
						</div>
					</fieldset>
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<div class="modal fade" tabindex="-1" role="dialog" id="statusModal">
		<div class="modal-dialog " role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					<h4><span class="modal-title"></span></h4>
				</div>
				<div class="modal-header">
					<span style="color:red">Para aprovar essa despesa, insira um email e senha valido.</span>
				</div>
				<form method="post">
					<div class="modal-body">
						<div id="mensagem"></div>
						<div id="msg_retorno" style="color:red;font-weight: bold;text-transform: uppercase;"></div>
						<div id="senha">
							<br>
							<form class="form-inline" id="frm_despesa" name="frm_despesa" method="post">	
								<div class="form-group">
									<label for="email_aprovacao">Email</label>
									<input type="email" class="form-control" id="email_aprovacao" aria-describedby="emailHelp" placeholder="xxx@xx" />
									<small class="form-text text-muted">Digite o email para aprovar as despesas </small>
								</div>	
								<div class="form-group">
									<label for="senha_aprovacao">Senha</label>
									<input type="password" class="form-control" id="senha_aprovacao" aria-describedby="emailHelp" />
									<small class="form-text text-muted">Digite a senha para aprovar as despesas </small>
								</div>
								<button type="button" id="btn-confirmar" class="form-control btn btn-success action" value="aprovar" data-role="confirmar">Aprovar Despesa</button>
							</form>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
					</div>
				</form>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<?php include "template/modal_sistema.php" ?>
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
    <script type="text/javascript">
	    $(function() {
    		$("#checkAll").click(function(){
    		    $('input:checkbox').not(this).prop('checked', this.checked);
    		});
    			
    		$('#statusModal').trigger('focus', function(){
    			alert('teste');
    		});
    	
    		function getSaldos(subconta = false){
    			id_despesa = $('#id_despesa').val();
    			tipo       = $('#tipo').val();
    			id_cc      = $('#id_centro_custo').val();
    			id_grupo   = $('#id_grupo').val();
    			id_conta   = $('#id_conta').val();
    			var is_mob = '<?= $is_mobile ?>'; 
    			if(subconta == false){
    				id_subconta = $('#id_subconta').val();
    			}else{
    				id_subconta = subconta;
    			}
    			data_vencimento = $('#data_vencimento').val();
    			valor   = $('#valor').val();
    			var str = '';
    			$.ajax({
    		        url: '/despesas/ajaxDadosOrcamento/',
    		        //datatype: 'json',
    		        //contentType: 'application/json; charset=utf-8',
    		        type: 'POST',
    		        data: { tipo:tipo, id_despesa:id_despesa, id_cc:id_cc,id_grupo:id_grupo,id_conta:id_conta, id_subconta:id_subconta, data_vencimento:data_vencimento, valor:valor },
    		        success: function (data){
    		        	var saldos = JSON.parse(data);
    					
    					str = '<table class="table table-default table-striped table-bordered table-hover" ><th>Nome</th><th>Saldo Orçamento</th><th>Saldo</th><tbody>';
    					if(saldos.codigo == 0){
    						var dados = saldos.dados; 
    						console.log(dados);	
    						if(dados.nome_centro_custo){
    							str += '<tr><td>'+dados.nome_centro_custo+'</td><td class="money">'+dados.orc_centro_custo+'</td><td class="money">'+dados.total_centro_custo+'</td></tr>';
    						}else{
    							str += '<tr><td><?= $records->nome_centro_custo; ?></td><td>0,00</td><td>0,00</td></tr>';
    						}
    
    						if(dados.nome_grupo){
    							str += '<tr><td>'+dados.nome_grupo+'</td><td class="money">'+dados.orc_grupo+'</td><td class="money">'+dados.total_grupo+'</td></tr>';
    						}else{
    							str += '<tr><td><?= $records[0]->nome_grupo; ?></td><td>0,00</td><td>0,00</td></tr>';
    						}
    
    						if(dados.nome_conta){
    							str += '<tr><td>'+dados.nome_conta+'</td><td class="money">'+dados.orc_conta+'</td><td class="money">'+dados.total_conta+'</td></tr>';
    						}else{
    							str += '<tr><td><?= $records[0]->nome_conta; ?></td><td>0,00</td><td>0,00</td></tr>';
    						}
    
    						if(dados.nome_subconta){
    							str += '<tr><td>'+dados.nome_subconta+'</td><td class="money">'+dados.orc_subconta+'</td><td class="money">'+dados.total_subconta+'</td></tr>';
    						}else{
    							str += '<tr><td><?= $records[0]->nome_subconta; ?></td><td>0,00</td><td>0,00</td></tr>';
    						}
    					}else{
    						str += '<tr><td>Não foi possivel carregar o orçamento</td><td></td><td></td></tr>';
    					}
    					str += '</tbody></table>';
    		        	$('#saldos').html(str);
    		        },
    		        error: function (error){
    		        	console.log(error);
    		        }
    			});
    		}
    
    		$('.action').click(function(){
    			var $action     = $(this).val(); 
    			var $id_despesa = $('#id_despesa').val();
    			var $atual      = '<?= $atual ?>';
    			
    			if($action == 'proximo' || $action == 'anterior' || $action == 'search'){
    				$('#action').val($action);
    				$('#periodo').submit();
    				//window.location = url+$action+'/'+$atual;
    				//window.location = url+$action+'/'+$atual;
    			}else{
    				var data_acao = $('#data_vencimento').val();
    				var dados_form = {};
    				var role = $(this).data('role');
    				$.ajax({
    					url: '/despesas/autorizar/',
    					data: 'despesas=<?= $records[0]->id_despesa; ?>'+'&acao='+$(this).val()+'&data_acao='+data_acao+'&senha_aprovacao='+$('#senha_aprovacao').val()+'&email_aprovacao='+$('#email_aprovacao').val(),
    					type: 'POST',
    					success: function (data){
    						var obj_json = JSON.parse(data);
    						console.log(obj_json);
    						var modal = $("#statusModal");
    						
    						if(obj_json.codigo == 0){
    							$('#painel_success_msg').text('Sucesso');
								$('#modal_sucesso_sistema').modal('show');
								$('#modal_sucesso_sistema').on('hidden.bs.modal', function () {                           
									window.location.reload();                   
								});
    						}else{
								titulo = 'Erro na autorizacao'
								mensagem = 'Error - '+obj_json.mensagem;
								console.log(mensagem);
								console.log(role);
								style = 'danger';
								if(role == 'confirmar'){
									$('#msg_retorno').html('<b>'+obj_json.mensagem+'</b>');
								}else if(role == 'aprovar'){
									$("#statusModal").on("shown.bs.modal", function () { 
										$('#aviso_success').html('');
										$('#aviso_error').html('');
										$('#email_aprovacao').val('');
										$('#senha_aprovacao').val('');
										var modal = $(this);
										modal.find('.modal-title').html('<b>'+titulo+'</b>');
										modal.find('.modal-body #mensagem').html('<b>'+obj_json.mensagem+'</b>');
									}).modal('show');
								}else{
									if (obj_json.status == 'error'){
										$('#mensagem').html(obj_json.mensagem);	
									}
								}
							}
    					},
    					error: function (error){	
    						console.log(error);
    						alert(error);
    					}
    				});
    			}
    		});
    
    		$('.mask-money').maskMoney({allowNegative: false, thousands:'.', decimal:','});
    		
    		$('.mask-money').each(function(){ // function to apply mask on load!
    		    $(this).maskMoney('mask', $(this).val());
    		})
    
    		$('#prioridade').val(prioridade);
    
    		var id_conta   = $('#id_conta').val();
    		var subconta   = $('#subconta').val();
    		var prioridade = $('#id_conta option:selected').attr('data-prioridade');
    
    		includeSubContas(id_conta);
    		
    		function includeSubContas(id_conta){
    			var str = '';
    			$.ajax({
    			        url: '/orcamento/getsubconta/?id_conta='+id_conta,
    			        //datatype: 'json',
    			        //contentType: 'application/json; charset=utf-8',
    			        type: 'POST',
    			        success: function (data){
    			        	var subcontas = JSON.parse(data);
    			        	//console.log(subcontas);
    			        	//alert(dados[0].id_conta);
    			        	$.each(subcontas,function(i, dados){
    			        		if(dados.id == subconta){
    			        			str += '<option value=' + dados.id + ' selected>' + dados.nome + '</option>';
    			        			//alert(dados.id);
    			        			//getSaldos(dados.id);
    			        		}else{
    			        			//alert(dados.id);
    			        			str += '<option value=' + dados.id + '>' + dados.nome + '</option>';
    			        		}
    			        		$('#id_subconta').html(str);
    			        	});
    			        	id_subconta = $('#id_subconta').find(":selected").val();
    			        	getSaldos(id_subconta);
    			        },
    			        error: function (error){
    			        }
    			});
    			return str;
    		}
    		
    		$('#id_conta').change(function(){
    			var id_conta = $(this).val();
    			var prioridade = $('#id_conta option:selected').attr('data-prioridade');
    			$('#prioridade').val(prioridade);
    			includeSubContas(id_conta);
    		});
    
    		$('#id_subconta').change(function(){
    			getSaldos();
    		});
	});
    </script>
<!-- /PAGE SCRIPTS -->
</body>
</html>