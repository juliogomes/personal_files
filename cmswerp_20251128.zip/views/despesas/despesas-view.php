<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
	<html class="no-js" lang="">
<!--[if gt IE 8]><!-->
	<head>
		<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
		<?php include 'template/head-css.inc' ?>
		<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
		<!-- PAGE STYLES -->
		<script type="text/javascript">
			var sidebarItem = "contas a pagar";
		</script>
		<!-- /PAGE STYLES -->
	</head>
	<body>
		<!-- MENU + WRAPPER -->
		<?php include "template/menu-wrapper.php" ?>
		<!-- /MENU + WRAPPER -->
		<!-- HEADER -->
		<ol class="breadcrumb">
			<li>Tarifas.cmsw.com</li>
			<li>Contas a pagar</li>
		</ol>
		<h4 class="page-title"><i class="fa fa-caret-right"></i> Contas a pagar</h4>

		<!-- /HEADER -->
		<!-- CONTENT -->
		<div class="container-fluid">
			<form class="form-inline" id="filter" name="form_filter" method="post">
				<div class="btn-group" role="group">
					<a href="/despesas/detalhe/id/0/" class="btn btn-primary "><i class="fa fa-plus"></i> Nova Despesa</a>
				</div>
				<?php
					if( $this->cl_permissoes->permissao_acesso > 2 ){
				?>		
					<div class="btn-group" role="group">
						<button type="button" value="reprovar" class="btn btn-danger processar_despesa"><i class="fa fa-ban"></i> Reprovar</button>
					</div>
					<div class="btn-group" role="group">
						<button type="button" value="aprovar" class="btn btn-success processar_despesa"><i class="fa fa-check"></i> Aprovar</button>
					</div>
				<?php
					}
				?>		
				<div class="btn-group" role="group">
					<button type="button"  value="pagar" class="btn btn-info processar_despesa"><i class="fa fa-money"></i> Pagar Despesas</button>
				</div>
				<div class="btn-group" role="group">
					<button type="button"  value="enviar_remessa" class="btn btn-default processar_despesa"><i class="fa fa-file"></i> Enviar para remessa</button>
				</div>
				<div class="btn-group" role="group">
					<button type="button"  value="reordenar_remessa" class="btn btn-warning processar_despesa"><i class="fa fa-refresh"></i> Reordenar despesas</button>
				</div>
				<div class="btn-group" role="group">
					<span><i class="fa fa-calendar"></i></span>
					<input type="text" name="data_acao" id="data_acao" value="<?= $this->data_hora_atual->format('d/m/Y'); ?>" class="datepast form-control" autocomplete="off">
				</div>
				<br />
				<br />
				<div class="pull-left">
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon">Data de:</div>
								<select name='tipo_data' class="form-control select">
									<option value="vencimento" <?= ($tipo_data == 'vencimento')?'selected':null ?>>Vencimento</option>
									<option value="pagamento" <?= ($tipo_data == 'pagamento')?'selected':null ?>>Pagamento</option>
								</select>
							</div>
						</div>
						<div class="input-group date">
							<span class="input-group-addon">De <i class="fa fa-calendar"></i></span>
							<input type="text" name="vencimento_de" id="vencimento_de" class=" search form-control datepast" value="<?= $vencimento_de; ?> " size=8 autocomplete="off" >
						</div>
						<div class="input-group date">
							<span class="input-group-addon">Até <i class="fa fa-calendar"></i></span>
							<input type="text" name="vencimento_ate" id="vencimento_ate" class="search form-control datepast" value="<?= $vencimento_ate; ?>" size=8 autocomplete="off">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon">Conta</div>
							<input class="search form-control" type="text" id="search1" name="search1" size="5">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon">Sub Conta</div>
							<input class="search form-control" type="text" name="search2" id="search2" size="5">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon">Fornecedor</div>
							<input class="search form-control" type="text" name="search3" id="search3" size="5">
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
						<div class="input-group-addon">Meio de Pagamento</div>
							<select name='meio_pagamento' class="form-control select" id="search7">
								<option value="">Todos</option>
								<option value="boleto_cc" <?= ($meio_pagamento == 'boleto_cc')?'selected':null ?>>Boleto com codigo de barra</option>
								<option value="boleto_sc" <?= ($meio_pagamento == 'boleto_sc')?'selected':null ?>>Boleto sem codigo de barra</option>
								<option value="caixa" <?= ($meio_pagamento == 'caixa')?'selected':null ?>>Caixa</option>
								<option value="cartao_credito" <?= ($meio_pagamento == 'cartao_credito')?'selected':null ?>>Cartão de crédito</option>
								<option value="cheque_adm" <?= ($meio_pagamento == 'cheque_adm')?'selected':null ?>>Cheque Administrativo</option>
								<option value="cheque_comum" <?= ($meio_pagamento == 'cheque_comum')?'selected':null ?>>Cheque Comum</option>
								<option value="debito_automatico" <?= ($meio_pagamento == 'debito_automatico')?'selected':null ?>>Cheque Comum</option>
								<option value="guia_recolhimento" <?= ($meio_pagamento == 'guia_recolhimento')?'selected':null ?>>Cheque Comum</option>
								<option value="orderm_pagamento" <?= ($meio_pagamento == 'orderm_pagamento')?'selected':null ?>>Cheque Comum</option>
								<option value="credito_tributario" <?= ($meio_pagamento == 'credito_tributario')?'selected':null ?>>Crédito Tributário</option>
								<option value="transferencia" <?= ($meio_pagamento == 'transferencia')?'selected':null ?>>Transferência</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<!-- <input class="search form-control" type="text" name="search5" id="search5" size="5"> -->
							<div class="input-group-addon">Status</div>
							<select class="search form-control" name="status" id="search5">
								<option value="">Todos</option>
								<option value="aberto" <?= ($status == 'aberto')?'selected':null;?> >Aberto</option>
								<option value="pago"   <?= ($status == 'pago')?'selected':null;?> >Pago</option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon">Aut</div>
							<!-- <input class="search form-control" type="text" name="search6" id="search6" size="5" value="<?= $status_autorizacao ?>" /> -->
							<select class="search form-control" name="status_autorizacao" id="search6">
								<option value="">Todos</option>
								<option value="aprovado" <?= ($status_autorizacao == 'aprovado')?'selected':null;?> >Aprovado </option>
								<option value="reprovado" <?= ($status_autorizacao == 'reprovado')?'selected':null;?> >Reprovado</option>
								<option value="pendente" <?= ($status_autorizacao == 'pendente')?'selected':null;?> >Pendente </option>
							</select>
						</div>
					</div>
					<div class="form-group">
						<div class="input-group">
							<div class="input-group-addon">$</div>
							<input class="search form-control" type="text" id="search4" size="5">
						</div>
					</div>
				</div>
				<br /> 
			</form>
			<br />
			<form action="post" name="despesas" id="despesas">
				<div class="row">
					<div class="col-md-12">
						<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
							<thead>
								<tr role="row">
									<th class="text-center"><input type="checkbox"  id="checkAll"></th>
									<th class="text-center">ID</th>
									<th class="text-center">DOC</th>
									<th class="text-center">Remessa</th>
									<th class="text-center">Empresa</th>
									<th class="text-center">Centro Custo</th>
									<th class="text-center">Grupo</th>
									<th class="text-center">Conta</th>
									<th class="text-center">Sub Conta</th>
									<th class="text-center">Fornecedor</th>
									<th class="text-center">Valor</th>
									<th class="text-center">Vencimento</th>
									<th class="text-center">Pago em</th>
									<th class="text-center">Tipo</th>
									<th class="text-center">Tipo Despesa</th>
									<th class="text-center">Pagamento</th>
									<th class="text-center">Status</th>
									<th class="text-center">Autorizado</th>
									<th class="text-center"><i class="fa fa-info"></i></th>
									<th class="text-center" width="130" class="text-center">Ações</td>
								</tr>
							</thead>
							<tbody>
								<?php if ( is_array( $records ) ){ ?>
									<?php foreach( $records as $key => $value ) { ?>
										<?php
											switch ( $value->status ) {
												case 'pago':
													$cor_btn = "btn-success";
												break;
												case 'gerado':
												case 'processado':
													$cor_btn = "btn-primary";
												break;
												case 'error':
												case 'erro':
													$cor_btn = "btn-danger";
												break;
												default:
													$cor_btn = "btn-warning";
												break;
											}
										?>
										<tr>
											<td class="text-center">
												<?php if(((empty($value->status) || $value->status == 'aberto') && $value->status_autorizacao == 'aprovado') || $this->cl_permissoes->getNivelAcesso() >= 4 ){ ?>
													<input type="checkbox" name="despesas[<?= $value->id_despesa ?>]" value="<?= $value->id_despesa ?>">
												<?php } ?>								
											</td>
											<td class="text-center"><a href="/despesas/detalhe/id/<?= $value->id_despesa; ?>"><?= $value->id_despesa; ?></a></td>
											<td class="text-center"><a href="/despesas/detalhe/id/<?= $value->id_despesa; ?>"><?= $value->id_doc; ?></a></td>
											<td class="text-center">
												<button type="button" class="checkRemessa btn <?= $cor_btn; ?>" data-vencimento="<?= $value->data_vencimento; ?>" value="<?= $value->id_despesa; ?>"><?= strtoupper( $value->status ); ?></button>
											</td>
											<td class="text-center"><?= $value->nome_cm; ?></td>
											<td class="text-center"><?= $value->nome_centro_custo; ?></td>
											<td class="text-center"><?= $value->nome_grupo; ?></td>
											<td class="text-center"><?= $value->nome_conta; ?></td>
											<td class="text-center"><?= $value->nome_subconta; ?></td>
											<td class="text-center"><a href="/fornecedores/detalhe/id/<?= $value->id_fornecedor; ?>"><?= $value->nome_fornecedor; ?></a></td>
											<td class="text-center"><?= (($value->valor - $value->desconto - $value->abatimento)+$value->juros+$value->multa+$value->outros_valores+$value->atualizacao_monetaria); ?></td>
											<td class="text-center"><?= convertDate($value->data_vencimento); ?></td>
											<td class="text-center"><?= convertDate($value->data_pagamento); ?></td>
											<td class="text-center"><?= $value->tipo; ?></td>
											<td class="text-center"><?= $value->tipo_despesa; ?></td>
											<td class="text-center"><?= $value->meio_pagamento; ?></td>
											<td class="text-center"><?= (empty($value->status))?'aberto':$value->status; ?></td>
											<td class="text-center"><?= $value->status_autorizacao; ?></td>
											<td class="text-center">
												<?php if(!empty(removerEspacos($value->descricao))){ ?>
													<div class="modal fade" id="descricao<?= $value->id_despesa; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
														<div class="modal-dialog" role="document">
															<div class="modal-content">
																<div class="modal-header">
																	<h4 class="modal-title"><b>Descrição da despesa</b></h4>
																	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
																	<span aria-hidden="true">&times;</span>
																	</button>
																</div>
																<div class="modal-body">
																	<b><?= $value->descricao; ?></b>
																</div>
																<div class="modal-footer">
																	<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
																</div>
															</div>
														</div>
													</div>
													<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#descricao<?= $value->id_despesa; ?>" > <i class="fa fa-info"></i> </button>
												<?php } ?>
											</td>
											<td class="text-center">
												<div class="pull-center">
													<a href="/despesas/detalhe/id/<?= $value->id_despesa ?>" class="btn btn-info" value=""><i class="fa fa-edit"></i></a>
													<button type="button" class="deletar btn btn-danger" value="<?= $value->id_despesa ?>"><i class="fa fa-trash"></i></button>
												</div>
											</td>
										</tr>
									<?php } ?>
								<?php } ?>
							</tbody>
							<tfoot>
								<tr>
									<th class= "text-right" colspan="10">Total Pagina</th>
									<th></th>
									<th class= "text-right" colspan="3">Total Geral</th>
									<th class= "text-left" colspan="6"></th>
								</tr>
							</tfoot>
						</table>
					</div>	
				</div>
			</form>
		</div>
		<!-- /.container-fluid -->
		<!-- /CONTENT -->
		<!-- END WRAPPER -->
		<?php include "template/end-menu-wrapper.html" ?>
		<!-- /END WRAPPER -->
			<!-- MODALS -->
			<div class="modal fade" tabindex="-1" role="dialog" id="statusModal">
				<div class="modal-dialog " role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h4><span class="modal-title"></span></h4>
						</div>
						<div class="modal-header">
							<div id="mensagem" style="color: red; font-weight: bold;"></div>
						</div>
						<form method="post">
							<div class="modal-body">
								<!-- <div><fieldset><legend><span style="color: red; font-weight: bold;">Deseja aprovar mesmo assim? </span></legend></fieldset></div> -->
								<div id="senha">
									<form class="form-inline" id="frm_despesa" name="frm_despesa" method="post">	
										<div class="form-group">
											<label for="email_aprovacao">Email</label>
											<input type="email" class="form-control" id="email_aprovacao" aria-describedby="emailHelp" placeholder="xxx@xx" />
											<small class="form-text text-muted">Digite o email para aprovar as despesas </small>
										</div>	
										<div class="form-group">
											<label for="senha_aprovacao">Senha</label>
											<input type="password" class="form-control" id="senha_aprovacao" aria-describedby="emailHelp" />
											<small class="form-text text-muted">Digite a senha para aprovar as despesas </small>
										</div>
										<button type="button" id="btn_auth" data-auth = "1" class="processar_despesa form-control btn btn-success" value="">Aprovar Despesa</button>
										<!-- <button type="button" data-auth = "1" class="processar_despesa form-control btn btn-primary" value="pagar">  Pagar Despesa</button> -->
									</form>
								</div>
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
							</div>
						</form>
					</div><!-- /.modal-content -->
				</div><!-- /.modal-dialog -->
			</div>
			<!-- /.modal -->
			<!-- MODAL ARQUIVO INICIO -->
			<div class="modal fade" tabindex="-1" role="dialog" id="arquivoModal">
				<div class="modal-dialog " role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						</div>
						<div class="modal-header">
							<h4><span class="modal-title" id="header_arquivo"></span></h4>
						</div>
						<form method="post">
							<div class="modal-body">
								<div id="mensagem_arquivo"></div>
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
							</div>
						</form>
					</div><!-- /.modal-content -->
				</div><!-- /.modal-dialog -->
			</div>
			<!-- MODAL ARQUIVO FIM -->
			<!-- /MODALS -->
		<!-- INCLUDE DEFAULT SCRIPTS -->
		<?php include 'template/scripts.inc' ?>
		<?php include "template/modal_sistema.php" ?>
		<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
		<!-- /INCLUDE DEFAULT SCRIPTS -->
		<!-- PAGE SCRIPTS -->
		<script type="text/javascript">
			$(function(){
				$(document).on('show.bs.modal', '.modal', function (event) {
					var zIndex = 1040 + (10 * $('.modal:visible').length);
					$(this).css('z-index', zIndex);
					setTimeout(function() {
						$('.modal-backdrop').not('.modal-stack').css('z-index', zIndex - 1).addClass('modal-stack');
					}, 0);
				});
				
				$('#modal_erro_sistema').on('hidden.bs.modal', function () {
					window.location.reload(true);
				});

				$('#modal_sucesso_sistema').on('hidden.bs.modal', function () {
					window.location.reload(true);
				});
				
				$("#checkAll").click(function(){
					$('input:checkbox').not(this).prop('checked', this.checked);
				});
				
				function execAction( parametros ){ // function execAction 
					if(parametros['auth'] == undefined){
						parametros.auth = 0
					}
					var dados_form = parametros.dados_form;
					delete parametros.dados_form;
					console.log(dados_form);
					//para serizlize em string
					// var dados_post = JSON.stringify(parametros);
					var dados_post = $.param( parametros );
					console.log(dados_post);
					dados_post += '&'+dados_form
					console.log(dados_post);

					if(parametros['auth'] == undefined){
						parametros.auth = 0
					}
					
					$('#btn_auth').val(parametros.acao);
					
					if(parametros.acao =='pagar'){
						var url = '/despesas/pagarDespesa/';
					}else if(parametros.acao == 'aprovar'){
						var url = '/despesas/autorizar/json';
					}else if(parametros.acao == 'reprovar'){
						var url = '/despesas/autorizar/json';
					}else if(parametros.acao == 'enviar_remessa'){
						var url = '/despesas/permitirRemessa/';
					}else if(parametros.acao == 'reordenar_remessa'){
						var url = '/despesas/reordenarRemessa/';
					}

					$.ajax({
						url: url,
						//datatype: 'json',
						//contentType: 'application/json; charset=utf-8',
						//data: dados_form+'&acao='+$(this).val()+'&data_acao='+data_acao,
						data: dados_post,
						type: 'POST',
						beforeSend: function() {
							// setting a timeout
							waitingDialog.show('PROCESSANDO...');
						},
						success: function (data){
							waitingDialog.hide();
							var obj_json = JSON.parse(data);
							console.log(obj_json);
							// verificar se o modal está aberto
							// alert($('#statusModal').is(':visible'));
							// Quando a ação requer autenticacao com previlegios
							if(obj_json.codigo == 'auth_required'){
								$("#statusModal").on("shown.bs.modal", function (){ 
									$('#aviso_success').html('');
									$('#aviso_error').html('');
									$('#email_aprovacao').val('');
									$('#senha_aprovacao').val('');
									var modal = $(this);
									modal.find('.modal-title').html('<b>Ação requer autenticação</b>');
									modal.find('.modal-header #mensagem').html(obj_json.mensagem);
									// modal.find('.modal-header #aviso_error').html(msg_error);
									// modal.find('.modal-header #aviso_success').html(msg_success);
								}).modal('show');

							}else if(obj_json.codigo == 0){ // quando acao é executada com sucesso
								$('#painel_success_msg').text('Ação executada com sucesso');
								$('#modal_sucesso_sistema').modal('show');
							}else if(obj_json.codigo == 1){ // quando ocorre erro ao executar ação
								$('#painel_error_msg').text(obj_json.mensagem);
								$('#modal_erro_sistema').modal('show');
							}else{ // erro desconhecido
								$('#painel_error_msg').text('Erro desconhecido');
								$('#modal_erro_sistema').modal('show');
							}
						},
						error: function (error){	
							waitingDialog.hide();
							console.log(error);
							alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
						},
						complete: function() {
							waitingDialog.hide();
						}
					});
				}// fim function execAction
				
				$('.deletar').click(function(){
					var id_despesa = $(this).val();
					var url = '/despesas/deletar/id/'+id_despesa;
					$.ajax({
						url: url,
						//datatype: 'json',
						//contentType: 'application/json; charset=utf-8',
						//data: dados_form+'&acao='+$(this).val()+'&data_acao='+data_acao,
						data: null,
						type: 'POST',
						beforeSend: function() {
							// setting a timeout
							waitingDialog.show('PROCESSANDO...');
						},
						success: function (data){
							waitingDialog.hide();
							var obj_json = JSON.parse(data);
							console.log(obj_json);
							// verificar se o modal está aberto
							// alert($('#statusModal').is(':visible'));
							// Quando a ação requer autenticacao com previlegios
							if(obj_json.codigo == 0){ // quando acao é executada com sucesso
								$('#painel_success_msg').text('Ação executada com sucesso');
								$('#modal_sucesso_sistema').modal('show');
							}else if(obj_json.codigo == 1){ // quando ocorre erro ao executar ação
								$('#painel_error_msg').text(obj_json.mensagem);
								$('#modal_erro_sistema').modal('show');
							}else{ // erro desconhecido
								$('#painel_error_msg').text('Erro desconhecido');
								$('#modal_erro_sistema').modal('show');
							}
						},
						error: function (error){	
							waitingDialog.hide();
							console.log(error);
							alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
						},
						complete: function() {
							waitingDialog.hide();
						}
					});
				});

				$('.processar_despesa').click(function(){
					console.log( $(this).val() );
					var parametros = {
						acao : $(this).val(),
						auth: $(this).data('auth'),
						email_aprovacao: $('#email_aprovacao').val(),
						senha_aprovacao: $('#senha_aprovacao').val(),
						data_acao: $('#data_acao').val(),
						dados_form: oTable.$('input[type="checkbox"]').serialize()
					};
					execAction( parametros );		
				});
				
				oTable = $('#list').DataTable({
					"order": [
						[ 1, "asc" ]
					],
					info: false,
					dom: "<'panel panel-default'" +
					"tr" +
					"<'panel-footer'" +
					"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
					">" +
					">",
					language: {
						"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
					},
					lengthMenu: [
						[ 10, 25, 50, -1 ],
						[ '10 linhas', '25 linhas', '50 linhas', 'Tudo' ]
					],
					dom: 'Bfrtip',
					lengthChange: true,
					buttons: [
						{
							extend: 'pageLength',
							text: 'PAGINAS',
							exportOptions: {
								columns: [ 0, ':visible' ]
							}
						},
						{
							extend: 'copyHtml5',
							text: 'COPY',
							exportOptions: {
								columns: [ 0, ':visible' ]
							}
						},
						{
							extend: 'csvHtml5',
							text: 'EXCEL',
							charset: 'utf-8',
							fieldSeparator: ';',
							bom: true,
							exportOptions: {
								columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14 ]
							}
						},
						{
							extend: 'pdfHtml5',
							text: 'PDF',
							exportOptions: {
								columns: [ 0, ':visible' ]
								//columns: [ 0, 1, 2, 5 ]
							}
						},
						{
							extend: 'colvis',
							text: 'COLUNAS',
						},
					],
					"columnDefs":[
						{
							"targets": 10,
							"data": "valor", // Use the full data source object for the renderer's source
							'render': function ( data, type, full, meta ) {
								var valor = Number(data);
								//console.log(valor);
								return '<span>'+valor.toFixed(2).replace(".", ",").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.")+'</span>';
							}
						},
						{
							"orderable": false,
							"targets": 0,
						}
					],
					"footerCallback": function ( row, data, start, end, display ){
						//console.log(data);
						var api = this.api();
						// Remove the formatting to get integer data for summation
						var intVal = function ( i ) {
							return typeof i === 'string' ?
								i.replace(/[\$,]/g, '')*1 :
								typeof i === 'number' ?
									i : 0;
						};
						// Total over all pages
						// Somando a coluna 10 de todas as linhas onde fica o valor
						total = api.column( 10 ).data().reduce( function (a, b) {
							return intVal(a) + intVal(b);
						}, 0 );
						// Total over this page
						// Somando a coluna 10 apenas das linhas apresentadas.
						pageTotal = api.column( 10, { page: 'current'} ).data().reduce( function (a, b) {
							return intVal(a) + intVal(b);
						}, 0 );
						// Update footer
						// $('tr:eq(0) th:eq(1)', api.table().footer()).html(
						// 	total.toFixed(2).replace(".", ",").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.")
						// );

						// $('tr:eq(0) th:eq(3)', api.table().footer()).html(
						// 	pageTotal.toFixed(2).replace(".", ",").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.")
						// );
					
						$( api.column( 10 ).footer() ).html(
							pageTotal.toFixed(2).replace(".", ",").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.")
						);

						$( api.column( 14 ).footer() ).html(
							total.toFixed(2).replace(".", ",").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.")
						);
					}
				});

				$('#search1').keyup(function(){
					oTable
					.columns( 7 )
					.search( this.value )
					.draw();
				});
			
				$('#search2').keyup(function(){
					oTable
					.columns( 8 )
					.search( this.value )
					.draw();
				});

				$('#search3').keyup(function(){
					oTable
					.columns( 9 )
					.search( this.value )
					.draw();
				});

				$('#search4').keyup(function(){
					oTable
					.columns( 10 )
					.search( this.value )
					.draw();
				});

				$('#search5').keyup(function(){
					oTable
					.columns( 16 )
					.search( this.value )
					.draw();
				}).change(function(){
					$('#filter').attr('action', '/despesas/listar/').submit();
				});

				$('#search6').keyup(function(){
					oTable
					.columns( 17 )
					.search( this.value )
					.draw();
				}).change(function(){
					$('#filter').attr('action', '/despesas/listar/').submit();
				});

				$('#search7').keyup(function(){
					oTable
					.columns( 15 )
					.search( this.value )
					.draw();
				}).change(function(){
					$('#filter').attr('action', '/despesas/listar/').submit();
				});
				
				$('#vencimento_ate').change(function(){
					$('#filter').attr('action', '/despesas/listar/').submit();
				});

				$('.checkRemessa').click( function(){
					var id_despesa = $(this).val();
					var vencimento = $(this).data('vencimento');
					var texto = null;
					$.ajax({
						url: '/despesas/checkStatusDespesa/'+id_despesa,
						//datatype: 'json',
						//contentType: 'application/json; charset=utf-8',
						//data: dados_form+'&acao='+$(this).val()+'&data_acao='+data_acao,
						data: {id_despesa:id_despesa},
						type: 'POST',
						beforeSend: function() {
							// setting a timeout
							waitingDialog.show('PROCESSANDO...');
						},
						success: function (data){
							waitingDialog.hide();
							var obj_json = JSON.parse(data);
							console.log( obj_json );
							if (obj_json.output !== null){
								if( obj_json.codigo == 0 ){
									$.each( obj_json.output, function( index, value){
										$.each( value, function( k1, v1){
											texto += '<tr>';
											texto += '<td> <b>ARQUIVO</b>: '+k1+'</td>';
											texto += '</tr>';
											$.each( v1, function( k2, v2){
												texto += '<tr>';
												texto += '<td> <b>CODIGO</b>: '+k2+' </b>DESCRIÇÃO</b>: '+v2+'</td>';
												texto += '</tr>';
											});
										});
									});
									$('#painel_info_body_msg').html( texto );
									$('#modal_info_sistema').modal('show');
									$('#modal_info_titulo').html('Descrição Remessa');
								} else {
									$('#painel_error_msg').html( obj_json.mensagem );
									$('#modal_erro_sistema').modal('show');
								}
							} else {
								$('#modal_info_titulo').html( 'Nenhum registro encontrado.' );
								$('#modal_info_sistema').modal('show');
							}
						},
						error: function (error){
							waitingDialog.hide();
							console.log(error);
							alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
						},
						complete: function() {
							waitingDialog.hide();
						}
					});
				});
			});
		</script>
		<!-- /PAGE SCRIPTS -->
	</body>
</html>
