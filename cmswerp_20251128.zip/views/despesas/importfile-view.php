<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
	<head>
		<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
		<?php include 'template/head-css.inc' ?>
		<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
		<!-- PAGE STYLES -->
		<script type="text/javascript">var sidebarItem = "importar despesas";</script>
		<!-- /PAGE STYLES -->
	</head>
	<body>
		<!-- MENU + WRAPPER -->
		<?php include "template/menu-wrapper.php" ?>
		<!-- /MENU + WRAPPER -->
		<!-- HEADER -->
		<ol class="breadcrumb">
			<li>Tarifas.cmsw.com</li>
			<li>Bancos</li>
		</ol>
		<h4 class="page-title">
			<i class="fa fa-file"></i> Importar arquivo de despesas
		</h4>
		<!-- /HEADER -->
		<!-- CONTENT -->
		<div class="container-fluid">
			<form id="form_upload" action="/despesas/processaFile/" name="form_upload" method="post" enctype="multipart/form-data">
				<div class="row">
					<div class="col-sm-12 col-md-9">
						<fieldset>
							<legend>Origem arquivo</legend>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<select name="tipo_despesa" id="tipo_despesa" class="form-control" required="required">
											<option value="pessoal">Pessoal</option>
											<option value="fornecedor">Fornecedor</option>
											<option value="tributo">Tributo</option>
										</select>
									</div>
								</div>
							</div>
						</fieldset>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-12 col-md-9">
						<fieldset>
							<legend>Empresa C&M</legend>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<select name="id_cm" id="id_cm" class="form-control" required="required">
										<?php
											foreach($this->empresas as $key=>$value){
												if($value->id == $records[0]->id_cm){
													echo '<option value ="'.$value->id.'" selected>'.strtoupper($value->razao_social).'</option>';
												}else{
													echo '<option value ="'.$value->id.'" >'.strtoupper($value->razao_social).'</option>';
												}
											}
										?>
										</select>
									</div>
								</div>
							</div>
						</fieldset>
					</div>
				</div>
				<!-- <div class="row">
					<div class="col-sm-12 col-md-9">
						<fieldset>
							<legend>Tipo do arquivo</legend>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<select name="id_subconta" id="id_subconta" class="form-control" required="required">
											<option value="61">Salario</option>
											<option value="167">Adiantamento</option>
											<option value="206">Recisão</option>
											<option value="64">Férias</option>
											<option value="33">Vale refeição</option>
											<option value="34">Vale transporte</option>
											<option value="30">Estacionamento</option>
											<option value="2000000">13º Primeira Parcela</option>
											<option value="2000001">13º Segunda Parcela</option>
											<option value="5000014">14º Primeira Parcela</option>
											<option value="5000015">14º Segunda Parcela</option>
										</select>
									</div>
								</div>
							</div>
						</fieldset>
					</div>
				</div> -->
				<div class="row">
					<div class="col-sm-12 col-md-9">
						<fieldset>
							<legend>Selecione o arquivo</legend>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<input type="file" name="arquivo" class="form-control" class="form-control" required/>
									</div>
								</div>
							</div>
						</fieldset>
						<button type="submit" name="btn-import"	 class="form-control btn btn-success"> Importar</button>
					</div>
				</div>
			</form>
		</div>
		<!-- /.container-fluid -->
		<!-- /CONTENT -->
		<!-- END WRAPPER -->
		<?php include "template/end-menu-wrapper.html" ?>
		<!-- /END WRAPPER -->
		<!-- MODALS -->
		<!-- /MODALS -->
		<!-- INCLUDE DEFAULT SCRIPTS -->
		<?php include 'template/scripts.inc' ?>
		<?php include "template/modal_sistema.php" ?>
		<!-- /INCLUDE DEFAULT SCRIPTS -->
		<!-- PAGE SCRIPTS -->
		<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
		<!-- <script>
			$('#form_upload').submit(function(){
				event.preventDefault();
				var formData = new FormData(this);
				$.ajax({
					cache: false,
					contentType: false,
					processData: false,
					url: '/despesas/processaFile/',
					type: 'POST',
					data: formData,
					beforeSend: function ( xhr ) {    
						waitingDialog.show('PROCESSANDO...');
					},
					success: function (data){
						waitingDialog.hide();
						var retorno = JSON.parse(data);
						console.log(retorno);
						if(retorno.codigo == 0){ // quando acao � executada com sucesso
							console.log(retorno.output);

						}else if(retorno.codigo == 1){ // quando ocorre erro ao executar a��o
							$('#painel_error_msg').text(retorno.mensagem);
							$('#modal_erro_sistema').modal('show');
						}else{ // erro desconhecido
							$('#painel_error_msg').text('Erro desconhecido');
							$('#modal_erro_sistema').modal('show');
						}
					},
					error: function (error){	
						waitingDialog.hide();
						console.log(error);
						alert('Erro na requisi��o codigo: '+error.status+' mensagem: '+error.statusText);
					}
					// xhr: function(){  // Custom XMLHttpRequest
					//     var myXhr = $.ajaxSettings.xhr();
					//     if (myXhr.upload) { // Avalia se tem suporte a propriedade upload
					//         myXhr.upload.addEventListener('progress', function () {
					//             /* faz alguma coisa durante o progresso do upload */
					//         }, false);
					//     }
					// 	return myXhr;
					// }
				});
			});
		</script> -->
	</body>
</html>