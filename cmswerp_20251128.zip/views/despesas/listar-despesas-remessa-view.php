<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "gerar remessa para pagamento";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Contas a pagar</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> DESPESAS PARA REMESSA</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<form class="form-inline" id="filter" name="form_filter" method="post">
			<div class="btn-group" role="group">
				<select name="empresas_cm" id="empresas_cm" class="form-control select">
					<option value="">Selecione</option>	
					<?php foreach ($this->convenios_cobranca as $key => $value) { ?>
						<option value="<?= $value->id; ?>" ><?= $value->nome_reduzido.' - AG: '.$value->numero_agencia.' - C/C: '.$value->numero_conta; ?></option>
					<?php } ?>
				</select>
			</div>
            <div class="btn-group" role="group">
				<button type="button" id="btn_gerar_arquivo_remessa" value="gerar_arquivo_remessa" class="btn btn-warning "><i class="fa fa-plus"></i> Arquivo de Remessa</button>
			</div>
            <div class="pull-left">
				<div class="form-group">
					<div class="input-group date">
						<span class="input-group-addon">De <i class="fa fa-calendar"></i></span>
						<input type="text" name="vencimento_de" id="vencimento_de" class=" search form-control datepast" value="<?= $dt_ini->format('d/m/Y'); ?> " size=8 autocomplete="off" >
					</div>
					<div class="input-group date">
						<span class="input-group-addon">Até <i class="fa fa-calendar"></i></span>
						<input type="text" name="vencimento_ate" id="vencimento_ate" class="search form-control datepast" value="<?= $dt_fim->format('d/m/Y'); ?>" size=8 autocomplete="off">
					</div>
				</div>
			</div>
			<br /> 
		</form>
		<br />
		<form action="post" name="despesas" id="despesas">
			<div class="row">
				<div class="col-md-12">
					<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
						<thead>
							<tr role="row">
								<th class="text-center"><input type="checkbox"  id="checkAll"></th>
								<th class="text-center">ID</th>
								<th class="text-center">DOC</th>
								<th class="text-center">C&M</th>
								<th class="text-center">Fornecedor</th>
								<th class="text-center">Valor</th>
								<th class="text-center">Vencimento</th>
								<th class="text-center">Tipo</th>
								<th class="text-center">Tipo Despesa</th>
								<th class="text-center">Pagamento</th>
								<th class="text-center">Status</th>
								<th class="text-center">Autorizado</th>
							</tr>
						</thead>
						<tbody>
							<?php if (is_array($despesas)){ ?>
							<?php foreach($despesas as $key => $value) { ?>
							<tr>
								<td class="text-center">
									<?php
										if(((empty($value->status) || $value->status == 'aberto') && $value->status_autorizacao == 'aprovado') || $_SESSION['cmswerp']['userdata']->perfil == 'ceo' ){
									?>
										<input type="checkbox" name="despesas[<?= $value->id_despesa ?>]" value="<?= $value->id_despesa ?>">
									<?php		
										}
									?>								
								</td>
								<td class="text-center"><?= $value->id_despesa; ?></td>
								<td class="text-center"><?= $value->id_doc; ?></td>
								<td class="text-center"><?= $value->nome_cm; ?></td>
								<td class="text-center"><?= $value->nome_fornecedor; ?></td>
								<td class="text-center"><?= $value->valor; ?></td>
								<td class="text-center"><?= convertDate($value->data_vencimento); ?></td>
								<td class="text-center"><?= $value->tipo; ?></td>
								<td class="text-center"><?= $value->tipo_despesa; ?></td>
								<td class="text-center"><?= $value->meio_pagamento; ?></td>
								<td class="text-center"><?= (empty($value->status))?'aberto':$value->status; ?></td>
								<td class="text-center"><?= $value->status_autorizacao; ?></td>
							</tr>
							<?php } ?>
							<?php } ?>
						</tbody>
						<tfoot>
							<tr>
								<th colspan="12"></th>
							</tr>
							<tr>
								<th class= "text-right" colspan="5">Total Pagina</th>
								<th></th>
								<th class= "text-right" colspan="3">Total Geral</th>
								<th colspan="3"></th>
							</tr>
						</tfoot>
					</table>
				</div>
			</div>
		</form>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
		<!-- MODALS -->
		<!-- /.modal -->
		<!-- MODAL ARQUIVO INICIO -->
		<div class="modal fade" tabindex="-1" role="dialog" id="arquivoModal">
			<div class="modal-dialog " role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					</div>
					<div class="modal-header">
						<h4><span class="modal-title" id="header_arquivo"></span></h4>
					</div>
					<form method="post">
						<div class="modal-body">
							<div id="mensagem_arquivo"></div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
						</div>
					</form>
				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>
		<!-- MODAL ARQUIVO FIM -->
		<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript">
		$(function(){
			$('#statusModal').on('hidden.bs.modal', function () {
				window.location.reload(true);
			})
			
			$( "#process" ).dialog({
				autoOpen: false,
				width: 400,
				resizable: false,
				draggable: false,
				close: function(){
					// executa uma ação ao fechar
					//alert("você fechou a janela");
				}
			});

			$("#checkAll").click(function(){
			    $('input:checkbox').not(this).prop('checked', this.checked);
			});
			
			$('#arquivoModal').on('hidden.bs.modal', function () {
				window.location.reload(true);
			})

			$('#btn_gerar_arquivo_remessa').click(function(){
				var dados_form = oTable.$('input[type="checkbox"]').serialize();
				var banco_pagamento = $('#empresas_cm').val();
				var acao = $(this).val();
                // alert('asdas');
				$.ajax({
			        url: '/despesas/gerar_arquivo_remessa/',
			        data: dados_form+'&acao='+acao+'&banco_pagamento='+banco_pagamento,
					type: 'POST',
					success: function (data){
						var obj_json = JSON.parse(data);
						if(obj_json){
							var msg_erro = '';
							$.each(obj_json, function(key, value) {
								if(value.codigo > 0){
									console.log(value.mensagem);
									msg_erro += '<p>'+value.mensagem+'</p>';
								}
							});
							console.log(msg_erro);
						}
						var modal = $("#arquivoModal");
						$("#arquivoModal").on("shown.bs.modal", function (){ 
							$('#mensagem_arquivo').text(obj_json.mensagem);
							if(!msg_erro){
								$('#header_arquivo').css({"color":"green", "font-weight":"bold"});
								$('#mensagem_arquivo').css({"color":"black", "font-weight":"bold"});
								$('#header_arquivo').text('Clique no link abaixo para ver os arquivos gerados?');
								$('#mensagem_arquivo').html('<span><a href="/despesas/listarremessa/" ><i class="fa fa-file" style="font-size:24px"></i> Ver Remessas? </a></span>');
							}else{
								$('#header_arquivo').css({"color":"red", "font-weight":"bold"});
								$('#header_arquivo').html('Erro ao gerar remessa');
								$('#mensagem_arquivo').css({"color":"black", "font-weight":"bold"});
								$('#mensagem_arquivo').html(msg_erro);
							}
						}).modal('show');
			        },
			        error: function (error){	
						console.log(error);
						alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
			        }
				});
			});

			oTable = $('#list').DataTable({
				"order": [
					[ 1, "asc" ]
				],
				info: false,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				},
				
				lengthMenu: [
					[ 10, 25, 50, -1 ],
					[ '10 linhas', '25 linhas', '50 linhas', 'Tudo' ]
				],
				dom: 'Bfrtip',
				lengthChange: true,
				buttons: [
					{
						extend: 'pageLength',
						text: 'PAGINAS',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'copyHtml5',
						text: 'COPY',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'csvHtml5',
						text: 'EXCEL',
						charset: 'utf-8',
						fieldSeparator: ';',
						bom: true,
						exportOptions: {
							columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 ]
						}
					},
					{
						extend: 'pdfHtml5',
						text: 'PDF',
						exportOptions: {
							columns: [ 0, ':visible' ]
							//columns: [ 0, 1, 2, 5 ]
						}
					},
					{
						extend: 'colvis',
						text: 'COLUNAS',
					},
				],
				"columnDefs":[
					{
					    "targets": 5,
					    "data": "valor", // Use the full data source object for the renderer's source
					    'render': function ( data, type, full, meta ) {
							var valor = Number(data);
							//console.log(valor);
							return '<span>'+valor.toFixed(2).replace(".", ",").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.")+'</span>';
						}
					},
					{
						"orderable": false,
						"targets": 0,
					}
				],
				"footerCallback": function ( row, data, start, end, display ){
            	//console.log(data);
            	var api = this.api(), data;
				// Remove the formatting to get integer data for summation
				var intVal = function ( i ) {
					return typeof i === 'string' ?
						i.replace(/[\$,]/g, '')*1 :
						typeof i === 'number' ?
							i : 0;
				};
				// Total over all pages
				total = api
					.column( 5 )
					.data()
					.reduce( function (a, b) {
						return intVal(a) + intVal(b);
					}, 0 );
				// Total over this page
				pageTotal = api
					.column( 5, { page: 'current'} )
					.data()
					.reduce( function (a, b) {
						return intVal(a) + intVal(b);
					}, 0 );
				// Update footer
				$('tr:eq(1) th:eq(3)', api.table().footer()).html(
					total.toFixed(2).replace(".", ",").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.")
				);

				$('tr:eq(1) th:eq(1)', api.table().footer()).html(
					pageTotal.toFixed(2).replace(".", ",").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.")
				);
      			//$( api.column( 5 ).footer() ).html(
						//    pageTotal.toFixed(2).replace(".", ",").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.")
						//);
	    		}
			});

			$('#search1').keyup(function(){
				oTable
				.columns( 4 )
				.search( this.value )
				.draw();
			});
		
			$('#search2').keyup(function(){
				oTable
				.columns( 5 )
				.search( this.value )
				.draw();
			});

			$('#search3').keyup(function(){
				oTable
				.columns( 6 )
				.search( this.value )
				.draw();
			});

			$('#search4').keyup(function(){
				oTable
				.columns( 7 )
				.search( this.value )
				.draw();
			});

			$('#search5').keyup(function(){
				oTable
				.columns( 9 )
				.search( this.value )
				.draw();
			}).change(function(){
				$('#filter').attr('action', '/despesas/remessapagamento/').submit();
			});

			$('#search7').keyup(function(){
				oTable
				.columns( 10 )
				.search( this.value )
				.draw();
			}).change(function(){
				$('#filter').attr('action', '/despesas/remessapagamento/').submit();
			});

			$('#search6').keyup(function(){
				oTable
				.columns( 11 )
				.search( this.value )
				.draw();
			}).change(function(){
				$('#filter').attr('action', '/despesas/remessapagamento/').submit();
			});

			$('#vencimento_ate').change(function(){
				$('#filter').attr('action', '/despesas/remessapagamento/').submit();
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
