<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "remessas geradas";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Remessas de Pagamentos</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> Remessas de Pagamentos</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<form class="form-inline page-toolbar" name="form_filter" method="post" action="/despesas/listarremessa/">
			<div class="pull-left">
				<div class="form-group">
					<div class="input-group date">
						<span class="input-group-addon">De <i class="fa fa-calendar"></i></span>
						<input type="text" name="data_ini" id="data_ini" class=" search form-control datepast" value="<?= $data_ini->format('d/m/Y'); ?> " size=8 autocomplete="off" >
					</div>
					<div class="input-group date">
						<span class="input-group-addon">Até <i class="fa fa-calendar"></i></span>
						<input type="text" name="data_fim" id="data_fim" class="search form-control datepast" value="<?= $data_fim->format('d/m/Y'); ?>" size=8 autocomplete="off">
						<span class="input-group-addon"><button type="submit"><i class="fa fa-search"></i></button></span>
					</div>
				</div>
			</div>
			<br /> 
		</form>
		<form id="frm_boletos" class="form-inline page-toolbar" method="post" action="/boletos/gerarremessa/">
			<div class="row">
				<div class="col-md-12">
					<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
						<thead>
							<tr role="row">
								<th class="text-center"><small><input type="checkbox" id="checkAll"></small></th>
								<th class="text-center">Id</th>
								<th class="text-center">Empresa</th>
								<th class="text-center">Banco</th>
								<th class="text-center">Agencia</th>
								<th class="text-center">Conta</th>
								<th class="text-center">Arquivo</th>
								<th class="text-center">Emissao</td>
								<th class="text-center">Status</td>
								<th class="text-center"></td>
							</tr>
						</thead>
						<tbody>
							<?php if (is_array($remessas)){ ?>
							<?php foreach($remessas as $key => $value){ ?>
							<tr>
								<td class="text-center"><span class="label-status"><b><input type="checkbox" name="id_remessa" value='<?= $value->id; ?>'></b></span></td>
								<td class="text-left"><span class="label-status"><b><?= $value->id; ?></b></span></td>
								<td class="text-left"><span class="label-status"><b><?= $value->nome_empresa; ?></b></span></td>
								<td class="text-left"><span class="label-status"><b><?= $value->nome_banco; ?></b></span></td>
								<td class="text-right"><span class="label-status"><b><?= $value->agencia; ?></b></span></td>
								<td class="text-right"><span class="label-status"><b><?= $value->conta; ?></b></span></td>
								<td class="text-right"><span class="label-status"><b><a target="_blank" href="/despesas/remessadespesas/id_remessa/<?= $value->id ?>/"><?= $value->nome_arquivo; ?></a></b></span></td>
								<td class="text-right"><span class="label-status"><b><?= convertDate($value->data_gravacao); ?></b></span></td>
								<td class="text-center">
									<?php
										switch ($value->status){
											case 'enviado':
												echo '<a><i style="color:brown;font-size:25px" class="fa fa-upload" aria-hidden="true"></i></a>';
											break;
											case 'processado':
												echo '<a><i style="color:blue;font-size:25px" class="fa fa-check-square-o" aria-hidden="true"></i></a>';
											break;
											case 'finalizado':
												echo '<a><i style="color:green;font-size:25px" class="fa fa-thumbs-o-up" aria-hidden="true"></i></a>';
											break;
											case 'error':
												echo '<a><i style="color:red;font-size:25px" class="fa fa-exclamation-triangle" aria-hidden="true"></i></a>';
											break;
											default:
												echo '<a"><i style="color:orange;font-size:25px" class="fa fa-clock-o fa-lg" aria-hidden="true"></i></a>';
											break;
										}
									?>
								</td>
							</tr>
							<?php } ?>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</form>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript">
		$(function(){
			oTable = $('#list').DataTable({
				info: false,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				},
				select: true,
				dom: 'Bfrtip',
				lengthMenu: [
					[ 10, 25, 50, -1 ],
					[ '10 rows', '25 rows', '50 rows', 'Show all' ]
				],
				buttons: [
					{
						extend: 'pageLength',
						text: 'PAGINAS',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'print',
						text: 'PRINT',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'copyHtml5',
						text: 'COPY',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'excelHtml5',
						text: 'EXCEL',
						exportOptions: {
							columns: ':visible'
						}
					},
					{
						extend: 'pdfHtml5',
						text: 'PDF',
						exportOptions: {
							columns: ':visible'
							//columns: [ 0, 1, 2, 5 ]
						}
					},
					{
						extend: 'colvis',
						text: 'COLUNAS',
					},
				]
			});
			$("#checkAll").click(function(){
			    $('input:checkbox').not(this).prop('checked', this.checked);
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
