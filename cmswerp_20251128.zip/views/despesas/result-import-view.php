<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
	<!--<![endif]-->
	<head>
		<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
		<?php include 'template/head-css.inc' ?>
		<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
		<!-- PAGE STYLES -->
		<script type="text/javascript">
			var sidebarItem = "import-despesas";
		</script>
		<!-- /PAGE STYLES -->
	</head>
	<body>
		<!-- MENU + WRAPPER -->
		<?php include "template/menu-wrapper.php" ?>
		<!-- /MENU + WRAPPER -->
		<!-- HEADER -->
		<ol class="breadcrumb">
			<li>Tarifas.cmsw.com</li>
			<li>Resultado do processamento</li>
		</ol>
		<h4 class="page-title"><i class="fa fa-caret-right"></i>Importação de despesas</h4>
		<form id='alterar_nf' name="alterar_nf" method="post" action="#">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<table id='list' class="table table-default table-striped table-bordered table-hover" >
							<thead>
								<tr role="row">
									<th>CPF</th>
                                    <th>NOME</th>
                                    <th>VALOR</th>
									<th>VENCIMENTO</th>
                                    <th>STATUS</th>
									<th>MENSAGEM</th>
								</tr>
							</thead>
							<tbody>
                                <?php if(isset($result) && $result->codigo == 0){ ?>
                                    <?php foreach($result->output as $key=>$value){ ?>
                                        <?php if(!empty($value->cpf)){ ?>
                                            <tr>
                                                <td><?= $value->nome; ?></td>
                                                <td><?= $value->cpf; ?></td>
												<td><?= $value->valor; ?></td>
												<td><?= $value->vencimento; ?></td>
                                                <?php if($value->status == 'erro'){ ?>
                                                    <td><div class="alert alert-danger" role="alert"><?= strtoupper($value->status); ?></div></td>
                                                    <td><div class="alert alert-danger" role="alert"><?= $value->mensagem; ?></td>    
                                                <?php }else{ ?>
                                                    <td><div class="alert alert-success" role="alert"><?= strtoupper($value->status); ?></div></td>
                                                    <td><div class="alert alert-success" role="alert"><?= $value->mensagem; ?></td>  
                                                <?php } ?>
                                            </tr>
                                        <?php } ?>
                                    <?php } ?>
                                <?php }else{ ?>
									<tr>
                                        <td colspan="4" align="center"><div class="alert alert-danger" role="alert"><?= $result->mensagem; ?></div></td>
									</tr>
								<?php } ?>
                            </tbody>
						</table>
					</div>
				</div>
                <div class="row">
                    <div class="col-md-12">
                        <a href="/despesas/importFileView/" class="form-control btn btn-warning"> VOLTAR </a>
                    </div>
                </div>
			</div>
		</form>
		<!-- /.container-fluid -->
		<!-- /CONTENT -->
		<!-- END WRAPPER -->
		<?php include "template/end-menu-wrapper.html" ?>
		<!-- /END WRAPPER -->
		<!-- MODALS -->
		<!-- /.modal -->
		<!-- INCLUDE DEFAULT SCRIPTS -->
		<?php include 'template/scripts.inc' ?>
		<?php include "template/modal_sistema.php" ?>
		<!-- /INCLUDE DEFAULT SCRIPTS -->
		<!-- PAGE SCRIPTS -->
		<script type="text/javascript">
			
		</script>
		<!-- /PAGE SCRIPTS -->
	</body>
</html>
