<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "empresas";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<style type="text/css">
		.ui-menu.ui-widget.ui-widget-content.ui-autocomplete.ui-front{
			max-height: 500px;
			overflow-y: auto;
		}
	</style>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Cadastros</li>
		<li>Empresas</li>
	</ol>
	<h4 class="page-title">
		<?php
		if(empty($this->parametros[1])){
			echo '<i class="fa fa-plus"></i> Novo Empresa';
		}else{
			echo '<i class="fa fa-edit"></i> Editar Empresa';
		}
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<form id="form" action="<?= HOME_URI.$this->nome_view.'/save/id/'.$this->parametros[1]; ?>" method="post">
			<div class="row">
				<div class="col-md-12">
					<fieldset>
						<legend>Empresas</legend>
					</fieldset>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="form-group">
						<label for="cnpj">CNPJ</label>
						<input type="text" class="form-control masked" id="cnpj" placeholder="99.999.999/9999-99" value="<?php echo isset($records)?$records[0]->cnpj:null ?>" name="cnpj" data-masked="00.000.000/0000-00"/>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
					<label for="inscricao_estadual">Inscricao Estadual</label>
					<input type="text" maxlength="12" class="form-control masked" id="inscricao_estadual"  value="<?php echo isset($records)?$records[0]->inscricao_estadual:null ?>" name="inscricao_estadual" />
				</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label for="inscricao_municipal">Inscricao Municipal</label>
						<input type="text" maxlength="15" class="form-control masked" id="inscricao_municipal"  value="<?php echo isset($records)?$records[0]->inscricao_municipal:null ?>" name="inscricao_municipal" />
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label for="razao_social">Razao Social</label>
						<input type="text" maxlength="60" class="form-control" class="form-control" value="<?php echo isset($records)?$records[0]->razao_social:null ?>" name="razao_social"/>
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label for="razao_social">Razao Social</label>
						<input type="text" maxlength="60" class="form-control" class="form-control" value="<?php echo isset($records)?$records[0]->nome_fantasia:null ?>" name="nome_fantasia"/>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<fieldset>
						<legend>Endereço</legend>
					</fieldset>
				</div>
			</div>
			<div class="row">
				<div class="col-md-9">
					<div class="form-group">
						<label for="endereco">Endereço</label>
						<input type="text" maxlength="75" class="form-control" value="<?php echo isset($records)?$records[0]->endereco:null ?>" name="endereco" data-autocep-input="logradouro"/>
					</div>
				</div>
				<div class="col-md-3">
					<div class="form-group">
						<label for="numero">Numero</label>
						<input type="text" maxlength="9" class="form-control" value="<?php echo isset($records)?$records[0]->numero:null ?>" name="numero" data-autocep-input="numero"/>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="form-group">
						<label for="complemento">Complemento</label>
						<input type="text" maxlength="30" class="form-control" value="<?php echo isset($records)?$records[0]->complemento:null ?>" name="complemento" data-autocep-input="complemento"/>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label for="cep">CEP</label>
						<input type="text" maxlength="9" class="form-control cep" id="cep" placeholder="99999-999"value="<?= isset($records)?mask($records[0]->cep,'#####-###'):null ?>" name="cep"/>
					</div>
				</div>
				<div class="col-md-4">
					<div class="form-group">
						<label for="bairro">Bairro</label>
						<input type="text" maxlength="40" class="form-control" value="<?php echo isset($records)?$records[0]->bairro:null ?>" name="bairro" data-autocep-input="bairro"/>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="form-group">
						<label for="estado">Estado</label>
						<select name="estado" id="estado" class="form-control uf-cidade" data-pair="cidade" data-autocep-select="uf" >
							<option value="">Selecione</option>
						</select>
					</div>
				</div>
				<div class="col-md-8">
					<div class="form-group">
						<label for="cidade">Cidade</label>
						<select name="cidade" maxlength="40" id="cidade" class="form-control cidade-uf" data-autocep-select="localidade">
							<option value=""></option>
						</select>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="form-group">
						<label for="status">Status</label>
						<select name='status' class="form-control select">
							<option value=''>Selecione</option>
							<option value='inativo' <?php echo (isset($records) && $records[0]->status == 'inativo')?'selected':'' ?> >INATIVO</option>
							<option value='ativo' <?php echo (isset($records) && $records[0]->status == 'ativo')?'selected':'' ?> >ATIVO</option>
							<option value='suspenso' <?php echo (isset($records) && $records[0]->status == 'suspenso')?'selected':'' ?> >SUSPENSO</option>
						</select>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<fieldset>
						<legend>Bancos Cadastrados</legend>
					</fieldset>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-md-6">
					<div class="form-group">
						<button type="button" id="btn_add_banco" class="form-control btn btn-success"><i class="fa fa-plus"></i> NOVO BANCO</button>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-md-12">
					<div class="form-group">
						<table id="table_bancos" class="table table-responsive">
							<thead>
								<tr>
									<th>ID</th>
									<th>CODIGO</th>
									<th>NOME</th>
									<th>TIPO</th>
									<th>AGENCIA</th>
									<th>CONTA</th>
									<th>CONTA PADRÂO</th>
									<th>AÇAO</th>
								</tr>
							</thead>
							<tbody id='lista_banco'>
							
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-6">
					<a href="/empresas/list/" class="form-control btn btn-warning"><i class="fa fa-times"></i> Cancelar</a>
				</div>
				<div class="col-md-6">
					<button type="submit" class="form-control btn btn-primary"><i class="fa fa-floppy-o"></i> Salvar</button>
				</div>
			</div>
		</form>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
		<!-- MODALS -->
		<div class="modal fade" tabindex="-1" role="dialog" id="addBancoModal">
			<div class="modal-dialog " role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4><span class="modal-title">Cadastrar Dados Bancarios</span></h4>
					</div>
					<div class="modal-header">
						<div id="div_aviso" style="font-weight:bold"></div>
					</div>
					<form id="frm_add_banco" name="frm_add_banco" method="post">
						<div class="modal-body">
							<div id="mensagem"></div>
							<div id="senha">
								<div class="form-group">
									<input type="hidden" class="form-control" name="id_empresa" id="id_empresa" value="<?= $this->parametros[1]; ?>" />
									<input type="hidden" class="form-control" name="origem_conta" id="origem_conta" value="empresa_cm" />
									<input type="hidden" class="form-control" name="id_banco_bacen" id="id_banco_bacen" value="" />
									<label for="nome_banco">Banco</label>
									<input type="text" class="form-control" name="nome_banco" id='autocomplete' />
									
								</div>
								<div class="form-group">
									<label for="tipo_conta">Tipo da Conta</label>
									<select name="tipo_conta" id="tipo_conta" class="form-control select">
										<option value="c">Conta Corrente</option>
										<option value="p">Conta Poupança</option>
									</select>
								</div>
								<div class="row">
									<div class="col-md-12">
										<label>Chave PIX</label>
										<input type="text" class="form-control" name="chave_pix" id='chave_pix' />
									</div>
								</div>
								<div class="form-group">
									<label for="numero_agencia">Agencia</label>
									<input type="text" class="form-control" name="numero_agencia" id="numero_agencia" aria-describedby="" placeholder="" value="" />
								</div>	
								<div class="form-group">
									<label for="digito_agencia">Digito</label>
									<input type="text" class="form-control" name="digito_agencia" id="digito_agencia" aria-describedby="" placeholder="" value="" />
								</div>
								<div class="form-group">
									<label for="numero_conta">Conta</label>
									<input type="text" class="form-control" name="numero_conta" id="numero_conta" aria-describedby="" placeholder="" value="" />
								</div>
								<div class="form-group">
									<label for="digito_conta">Digito</label>
									<input type="text" class="form-control" name="digito_conta" id="digito_conta" aria-describedby="" placeholder="" value="" />
								</div>
								<div class="form-group">
									<label for="email">Email de contato</label>
									<input type="text" class="form-control" name="email" id="email" aria-describedby="" placeholder="" value="" />
								</div>
								<div class="form-group">
									<label for="codigo_convenio_cnab400">Convenio Cobrança/Pagamento CNAB 400 </label>
									<input type="text" class="form-control" name="codigo_convenio_cnab400" id="codigo_convenio_cnab400" aria-describedby="" placeholder="" value="" />
								</div>
								<div class="form-group">
									<label for="codigo_convenio_cnab240">Convenio Cobrança/Pagamento CNAB 240</label>
									<input type="text" class="form-control" name="codigo_convenio_cnab240" id="codigo_convenio_cnab240" aria-describedby="" placeholder="" value="" />
								</div>
								<div style="display: flex;align-items: center;">
									<label for="conta_default">Conta Padrão?</label>
									<input type="checkbox" class="form-control" name="conta_default" id="conta_default" aria-describedby="" placeholder="" value="1" style="width: auto;height: auto; margin: 0 5px"/>
								</div>
								<button type="button" id="btn_incluir_banco" class="form-control btn btn-success" value="adicionar"><id class="fa fa-plus"></i> Adicionar</button>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
						</div>
					</form>
				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$('#autocomplete').autocomplete({
			minLength: 1,
			autoFocus: true,
			// delay: 300,
			position: {
				my: 'left top',
				at: 'left bottom'
			},
			appendTo: '#frm_add_banco',
			source: function(request, response){
				$.ajax({
					url: '/contabancaria/getBancoList',
					type: 'post',
					dataType: 'json',
					data: {
						'search': request.term
					}
				}).done(function(data){
					// obj = JSON.parse(data);   //parse the data in JSON (if not already)
					response($.map(data, function(item){
						return {
							label: item.nome_reduzido,
							value: item.id
						}
					}))
				});
			},
			select:function(event, ui){
				console.log(event); 
				$('#autocomplete').val(ui.item.label);
				$('#id_banco_bacen').val(ui.item.value);
				return false;
			}   
		});
	</script>
	<script type="text/javascript">
		$(function() {
			$form = $('#form');
			$form.formValidation({
				framework: 'bootstrap',
				excluded: ':disabled',
				icon: {
					valid: 'fa fa-check',
					invalid: 'fa fa-times',
					validating: 'fa fa-refresh'
				},
				addOns: {
					mandatoryIcon: {
						icon: 'fa fa-asterisk'
					}
				},
				live: 'enabled',
				fields: {
					'razao_social': { validators:{ notEmpty:{ message:"Campo Obrigatório" } } },
					'cnpj':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							},
							regexp: {
								regexp: /^[0-9]{2}\.[0-9]{3}\.[0-9]{3}\/[0-9]{4}\-[0-9]{2}$/i,
								message: 'CNPJ não é Válido'
							}
						}
					},
					'cep':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							},
							regexp: {
								regexp: /^[0-9]{5}\-[0-9]{3}$/i,
								message: 'CEP não é Válido'
							}
						}
					},
					'endereco':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'bairro':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'estado':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					},
					'cidade':{
						validators:{
							notEmpty:{
								message:"Campo Obrigatório"
							}
						}
					}
				}
			});

			$('#table_bancos').hide();
			var id_empresa = "<?= $this->parametros[1]; ?>";
			// alert(id_empresa);
			
			if(id_empresa > 0 ){
				montaTabelaBancos(id_empresa);
			}
			
			$('#btn_add_banco').click(function(){
				var id_empresa = "<?= $this->parametros[1];?>";
				if(id_empresa == 0 || id_empresa ==""){
					alert('É necessario cadastrar o fornecedor antes de atribuir uma conta!');
					return;
				}
				$("#addBancoModal").modal({
        			show: 'true'
    			});
			});

			$('#btn_incluir_banco').click(function(){
				var dados_form = $('#frm_add_banco').serialize();
				// var dados_form = $("form[name=frm_add_banco]").serialize();
				console.log(dados_form);
				$.ajax({
					url: '/contabancaria/save/',
					data: dados_form,
					type: 'POST',
					success: function (data){
						var obj_json = JSON.parse(data);
						console.log(obj_json);
						if(obj_json.codigo == 0){
							location.reload();
						}else{
							$('#div_aviso').html('<p style="color:red"><b>'+obj_json.mensagem+'</b></p>');
						}
					},
					error: function (error){	
						console.log(error);
						alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
					}
				});
			});

			function montaTabelaBancos(id_empresa){
				// alert(id_empresa);
				var bancos = null;
				var table_rows = null;
				$.ajax({
					url: '/contabancaria/getContasBancariasJson/empresa_cm/'+id_empresa,
					data: {default: false},
					type: 'POST',
					success: function (data){
						var obj_json = JSON.parse(data);
						console.log(obj_json);
						if(obj_json.codigo == 0){
							bancos = obj_json.output;
							$.each(bancos, function(index, element) {
								if(element.conta_default == 0){
									var conta_default = 'NÂO';
								}else{
									var conta_default = 'SIM';
								}
								table_rows += '<tr>';
								table_rows += '<td>';
								table_rows += element.id;
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += element.codigo_banco;
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += element.nome_reduzido;
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += element.tipo_conta;
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += element.numero_agencia+'-'+element.digito_agencia;
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += element.numero_conta+'-'+element.digito_conta;
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += conta_default;
								table_rows += '</td>';
								table_rows += '<td>';
								if(conta_default == 'NÂO'){
									table_rows += '<button type="button" data-acao="default" class="uppercase action btn btn-success" value="'+element.id+'" title="Definir como padrão"><i class="fa fa-check"></i> </span> </button>';
								}
								table_rows += '<button type="button" data-acao="apagar" class="uppercase action btn btn-danger" value="'+element.id+'" title="Apagar"><i class="fa fa-trash"></i> </span> </button>';
								table_rows += '</td>';
								table_rows += '</tr>';
								// console.log(element);
							});
							$('#lista_banco').html(table_rows);
							$('#table_bancos').show();
						}else{
							//implementar erro 
						}
					},
					error: function (error){	
						console.log(error);
						alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
					}
				});
			}

			$(document).on('click', '.action', function(e) {
				e.preventDefault;
				// alert('teste');
				var id         = $(this).val();
				var id_empresa = <?= $this->parametros[1]; ?>;
				var acao       = $(this).data('acao');
				if(acao == 'default'){
					var url_action = '/contabancaria/checkContaDefault/empresa_cm/id/'+id_empresa+'/'+id;
				}else if(acao == 'apagar'){
					var url_action = '/contabancaria/apagar/id/'+id;
				}

				$.ajax({
					url: url_action,
					// data: dados_form,
					type: 'POST',
					success: function (data){
						var obj_json = JSON.parse(data);
						console.log(obj_json);
						if(obj_json.codigo == 0){
							montaTabelaBancos(id_empresa);
						}else{
							//implementar erro 
						}
					},
					error: function (error){	
						console.log(error);
						alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
					}
				});
			})

			$('#addBancoModal').on('hidden.bs.modal', function(){
				montaTabelaBancos(id_empresa);
			});
		});
	</script>

<?php if (isset($records)){ ?>
	<script type="text/javascript">
		function justNumber(string){
			var numsStr = string.replace(/[^0-9]/g,'');
			return parseInt(numsStr);
		}

		$(function() {
			var estado = '<?= $records[0]->estado ?>';
			var cidade = '<?= $records[0]->cidade ?>';
			setTimeout(function(){

			$('#estado').selectpicker('val', estado);

			if (estado) {
				$('#estado').trigger("change");
			}

			$('#cidade').selectpicker('val', cidade);
			if (cidade) {
				$('#cidade').trigger("change");
			}
			},50);
		});
	</script>
<?php } ?>
<!-- /PAGE SCRIPTS -->
</body>
</html>