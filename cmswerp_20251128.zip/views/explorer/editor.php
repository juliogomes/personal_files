<?php
// views/explorer/editor.php
if (!isset($content)) $content = '';
if (!isset($rel)) $rel = '';
if (!isset($csrf)) $csrf = '';
?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>Editor - <?php echo htmlspecialchars($rel); ?></title>
<link rel="stylesheet" href="/assets/bootstrap/css/bootstrap.min.css">
</head>
<body>
<div class="container">
  <h4>Editor: <?php echo htmlspecialchars($rel); ?></h4>
  <form method="post" action="/explorer/saveEdit">
    <input type="hidden" name="_csrf" value="<?php echo htmlspecialchars($csrf); ?>">
    <input type="hidden" name="target" value="<?php echo htmlspecialchars($rel); ?>">
    <div class="form-group">
      <textarea name="content" rows="20" class="form-control" style="font-family:monospace"><?php echo htmlspecialchars($content); ?></textarea>
    </div>
    <button class="btn btn-primary" type="submit">Salvar (backup automático)</button>
    <a href="/explorer" class="btn btn-default">Voltar</a>
  </form>
</div>
</body>
</html>
