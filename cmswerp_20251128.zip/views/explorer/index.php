<?php
// views/explorer/index.php — DARK MODE PREMIUM
if (!isset($baseDir)) $baseDir = '';
if (!isset($items)) $items = array();
if (!isset($rel)) $rel = '';
if (!isset($csrf)) $csrf = '';
?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>Explorer — Dark Premium</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" href="/assets/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
/* ===========================
   DARK MODE PREMIUM
   =========================== */
body {
    background: #0d1117;
    color: #c9d1d9;
    font-family: "Segoe UI","Helvetica Neue",Helvetica,Arial,sans-serif;
    padding-top: 80px;
}

/* TOPBAR */
.topbar {
    position: fixed;
    top:0; left:0; right:0;
    height:64px;
    background:#161b22;
    border-bottom:1px solid #21262d;
    display:flex;
    align-items:center;
    z-index:1030;
    box-shadow:0 2px 6px rgba(0,0,0,.6);
}
.topbar .container {
    height:64px;
    display:flex;
    align-items:center;
    justify-content:space-between;
}
.brand {
    font-weight:700;
    font-size:18px;
    color:#58a6ff;
    display:flex;
    align-items:center;
    gap:10px;
}
.brand .logo { font-size:20px; color:#58a6ff; }

/* SEARCH */
.search-input {
    background:#0d1117;
    border:1px solid #30363d;
    color:#c9d1d9;
}
.search-input:focus {
    border-color:#58a6ff;
    box-shadow:none;
}

/* BUTTONS */
.btn-default,
.btn-primary,
.btn-danger,
.btn-info {
    border-radius:4px !important;
}
.btn-default {
    background:#21262d;
    border-color:#30363d;
    color:#c9d1d9;
}
.btn-default:hover {
    background:#30363d;
}
.btn-primary {
    background:#238636;
    border-color:#2ea043;
}
.btn-primary:hover {
    background:#2ea043;
}
.btn-danger {
    background:#da3633;
    border-color:#f85149;
}
.btn-danger:hover {
    background:#f85149;
}
.btn-info {
    background:#1f6feb;
    border-color:#388bfd;
}
.btn-info:hover {
    background:#388bfd;
}

/* FAB */
.fab {
    position:fixed;
    right:28px;
    bottom:28px;
    width:62px;height:62px;
    border-radius:50%;
    background:linear-gradient(135deg,#1f6feb,#388bfd);
    color:#fff;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:24px;
    cursor:pointer;
    box-shadow:0 10px 25px rgba(0,0,0,.7);
    z-index:1050;
    transition:0.2s;
}
.fab:hover {
    transform:translateY(-4px);
}

/* WORKSPACE */
.workspace { padding:20px 20px 120px; }

/* CONTROLS */
.controls {
    display:flex;
    justify-content:space-between;
    flex-wrap:wrap;
    margin-bottom:20px;
}

/* CARDS (GRID MODE) */
.cards {
    display:flex;
    flex-wrap:wrap;
    gap:16px;
}
.card {
    width:220px;
    background:#161b22;
    border:1px solid #21262d;
    border-radius:10px;
    padding:12px;
    box-shadow:0 6px 16px rgba(0,0,0,.45);
    display:flex;
    flex-direction:column;
    justify-content:space-between;
    transition:0.15s;
    position:relative;
}
.card:hover {
    transform:translateY(-4px);
    box-shadow:0 10px 28px rgba(0,0,0,.7);
}

/* ICON */
.icon {
    width:48px;height:48px;
    border-radius:10px;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:22px;
    margin-bottom:10px;
}
.ic-folder { background:#4c8be6; color:#fff; }
.ic-file   { background:#6e7681; color:#fff; }
.ic-php    { background:#8250df; color:#fff; }

/* CARD TEXT */
.card .name {
    font-weight:600;
    font-size:14px;
    margin-bottom:6px;
    color:#c9d1d9;
    word-break:break-all;
}
.card .meta {
    color:#8b949e;
    font-size:12px;
}

/* ACTIONS */
.card .actions {
    margin-top:8px;
    display:flex;
    gap:6px;
}
.label-danger {
    background:#da3633;
}

/* LIST MODE */
.list {
    background:#161b22;
    border:1px solid #21262d;
    border-radius:8px;
    display:none;
}
.list table {
    color:#c9d1d9;
}
.list tr:hover {
    background:#1c2128;
}

/* CHECKBOX ON CARDS */
.card input.sel-item {
    position:absolute;
    top:8px; right:8px;
}

/* MODALS DARK */
.modal-content {
    background:#161b22;
    color:#c9d1d9;
    border:1px solid #30363d;
}
.modal-header {
    border-bottom:1px solid #30363d;
}
.modal-footer {
    border-top:1px solid #30363d;
}
.form-control {
    background:#0d1117;
    border:1px solid #30363d;
    color:#c9d1d9;
}
.form-control:focus {
    border-color:#58a6ff;
    box-shadow:none;
}
</style>

</head>
<body>

<!-- TOPBAR -->
<div class="topbar">
  <div class="container">
    <div class="brand">
      <i class="fa fa-folder-open logo"></i>
      Explorer <small style="font-weight:400;color:#8b949e;">Dark</small>
    </div>

    <div style="display:flex;align-items:center;gap:10px">
      <form class="form-inline" method="get" action="/explorer/search">
        <input name="q" class="form-control search-input" type="search"
               placeholder="Pesquisar..."
               value="<?php echo isset($q)?htmlspecialchars($q):''; ?>">
      </form>

      <a class="btn btn-default btn-sm" href="/explorer"><i class="fa fa-home"></i></a>
      <button class="btn btn-default btn-sm" id="toggleView"><i class="fa fa-th"></i></button>
    </div>
  </div>
</div>

<!-- MAIN -->
<div class="workspace container">

  <div class="controls">
    <div>
      <strong>Local:</strong> <span class="text-muted"><?php echo $rel ?: '/'; ?></span>
    </div>

    <div>
      <a class="btn btn-default btn-sm" id="selectAllBtn">Selecionar</a>
      <a class="btn btn-default btn-sm" id="deselectAllBtn">Limpar</a>
      <a class="btn btn-default btn-sm" id="bulkDownloadBtn">Baixar</a>
    </div>
  </div>

  <!-- GRID -->
  <div id="gridView" class="cards">
    <?php if ($items): foreach ($items as $it): 
      $isDir = $it['is_dir'];
      $ext = strtolower(pathinfo($it['name'], PATHINFO_EXTENSION));
      $iconClass = $isDir ? 'ic-folder' : ($ext === 'php' ? 'ic-php' : 'ic-file');
    ?>
      <div class="card" data-rel="<?php echo $it['relpath']; ?>" data-name="<?php echo $it['name']; ?>" data-isdir="<?php echo $isDir?1:0; ?>">
        <input type="checkbox" class="sel-item" value="<?php echo $it['relpath']; ?>">

        <div>
          <div class="icon <?php echo $iconClass; ?>"><i class="fa <?php echo $isDir?'fa-folder':'fa-file'; ?>"></i></div>

          <div class="name"><?php echo htmlspecialchars($it['name']); ?>
            <?php if (!empty($it['protected'])): ?>
              <span class="label label-danger">PROT</span>
            <?php endif; ?>
          </div>

          <div class="meta">
            <?php echo $isDir?'Pasta':call_user_func($humanFileSize, $it['size']); ?>
            • <?php echo date('Y-m-d H:i', $it['mtime']); ?>
          </div>
        </div>

        <div class="actions">
          <?php if ($isDir): ?>
            <a class="btn btn-xs btn-default" href="/explorer?p=<?php echo rawurlencode($it['relpath']); ?>"><i class="fa fa-folder-open"></i></a>
          <?php else: ?>
            <a class="btn btn-xs btn-default" href="/explorer/download?target=<?php echo rawurlencode($it['relpath']); ?>"><i class="fa fa-download"></i></a>
            <a class="btn btn-xs btn-default" href="/explorer/view?target=<?php echo rawurlencode($it['relpath']); ?>" target="_blank"><i class="fa fa-eye"></i></a>
            <a class="btn btn-xs btn-info" href="/explorer/edit?target=<?php echo rawurlencode($it['relpath']); ?>"><i class="fa fa-pencil"></i></a>
          <?php endif; ?>

          <?php if (empty($it['protected'])): ?>
            <button class="btn btn-xs btn-default renameBtn" data-rel="<?php echo $it['relpath']; ?>" data-name="<?php echo $it['name']; ?>"><i class="fa fa-edit"></i></button>
            <button class="btn btn-xs btn-default moveBtn" data-rel="<?php echo $it['relpath']; ?>" data-name="<?php echo $it['name']; ?>"><i class="fa fa-arrows"></i></button>
            <button class="btn btn-xs btn-danger deleteBtn" data-rel="<?php echo $it['relpath']; ?>" data-name="<?php echo $it['name']; ?>"><i class="fa fa-trash"></i></button>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; else: ?>
      <div class="alert alert-info">Pasta vazia.</div>
    <?php endif; ?>
  </div>

  <!-- LIST VIEW -->
  <div id="listView" class="list">
    <table class="table table-condensed">
      <thead>
        <tr><th></th><th>Nome</th><th>Tamanho</th><th>Modificado</th><th>Ações</th></tr>
      </thead>
      <tbody>
      <?php if ($items): foreach ($items as $it): ?>
        <tr data-rel="<?php echo $it['relpath']; ?>">
          <td><input type="checkbox" class="sel-item" value="<?php echo $it['relpath']; ?>"></td>
          <td><?php echo $it['is_dir']?'<i class="fa fa-folder"></i> ':'<i class="fa fa-file"></i> '; ?>
              <?php echo htmlspecialchars($it['name']); ?>
          </td>
          <td><?php echo $it['is_dir']?'-':call_user_func($humanFileSize, $it['size']); ?></td>
          <td><?php echo date('Y-m-d H:i', $it['mtime']); ?></td>
          <td>
            <?php if ($it['is_dir']): ?>
              <a class="btn btn-xs btn-default" href="/explorer?p=<?php echo rawurlencode($it['relpath']); ?>">Abrir</a>
            <?php else: ?>
              <a class="btn btn-xs btn-default" href="/explorer/download?target=<?php echo rawurlencode($it['relpath']); ?>">Baixar</a>
              <a class="btn btn-xs btn-default" href="/explorer/view?target=<?php echo rawurlencode($it['relpath']); ?>">Ver</a>
              <a class="btn btn-xs btn-info" href="/explorer/edit?target=<?php echo rawurlencode($it['relpath']); ?>">Editar</a>
            <?php endif; ?>
            <?php if (empty($it['protected'])): ?>
              <button class="btn btn-xs btn-default renameBtn" data-rel="<?php echo $it['relpath']; ?>">Renomear</button>
              <button class="btn btn-xs btn-default moveBtn" data-rel="<?php echo $it['relpath']; ?>">Mover</button>
              <button class="btn btn-xs btn-danger deleteBtn" data-rel="<?php echo $it['relpath']; ?>">Excluir</button>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; else: ?>
        <tr><td colspan="5" class="text-center">Nenhum item</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>

</div>

<!-- FAB -->
<div class="fab" id="fab"><i class="fa fa-plus"></i></div>

<!-- MODALS (renomear, mover, excluir, upload) -->
<?php include __DIR__ . '/_modals_dark.php'; ?>

<script src="/assets/jquery/jquery.min.js"></script>
<script src="/assets/bootstrap/js/bootstrap.min.js"></script>

<script>
(function($){
  var grid = true;

  function showGrid(){ $('#listView').hide(); $('#gridView').show(); grid=true; $('#toggleView i').removeClass('fa-list').addClass('fa-th'); }
  function showList(){ $('#gridView').hide(); $('#listView').show(); grid=false; $('#toggleView i').removeClass('fa-th').addClass('fa-list'); }

  showGrid();

  $('#toggleView').click(function(e){ e.preventDefault(); grid?showList():showGrid(); });
  $('#fab').click(function(){ $('#uploadModal').modal('show'); });

  $('.renameBtn').click(function(){
      $('#rename_target').val($(this).data('rel'));
      $('#rename_newname').val($(this).data('name'));
      $('#renameModal').modal('show');
  });

  $('.moveBtn').click(function(){
      $('#move_target').val($(this).data('rel'));
      $('#move_dest').val('');
      $('#moveModal').modal('show');
  });

  $('.deleteBtn').click(function(){
      $('#del_target').val($(this).data('rel'));
      $('#del_filename').text($(this).data('name'));
      $('#deleteModal').modal('show');
  });

  $('#selectAllBtn').click(function(){ $('.sel-item').prop('checked', true); });
  $('#deselectAllBtn').click(function(){ $('.sel-item').prop('checked', false); });

  $('#bulkDownloadBtn').click(function(){
    var items = $('.sel-item:checked').map(function(){ return $(this).val(); }).get();
    if(!items.length) return alert("Nenhum item selecionado.");
    items.forEach(function(i){
      window.open('/explorer/download?target=' + encodeURIComponent(i), '_blank');
    });
  });
})(jQuery);
</script>

</body>
</html>