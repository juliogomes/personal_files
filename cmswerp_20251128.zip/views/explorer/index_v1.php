<?php
// views/explorer/index.php  (Google Drive Workspace style)
// Variáveis esperadas: $baseDir, $items, $rel, $csrf, $humanFileSize
if (!isset($baseDir)) $baseDir = '';
if (!isset($items)) $items = array();
if (!isset($rel)) $rel = '';
if (!isset($csrf)) $csrf = '';
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Explorer — Workspace</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap 3 CSS (ajuste caminho se necessário) -->
  <link rel="stylesheet" href="/assets/bootstrap/css/bootstrap.min.css">

  <!-- FontAwesome CDN (icons) -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <!-- Custom Workspace Styles -->
  <style>
    /* --- Layout --- */
    body{background:#f4f6f8;font-family:"Helvetica Neue",Helvetica,Arial,sans-serif;color:#333;padding-top:80px}
    .topbar{position:fixed;top:0;left:0;right:0;height:64px;background:#fff;border-bottom:1px solid #e6e9ed;z-index:1030;box-shadow:0 2px 6px rgba(15,23,40,.04)}
    .topbar .container{height:64px;display:flex;align-items:center;justify-content:space-between}
    .brand{font-weight:700;color:#2b6cb0;font-size:18px;display:flex;align-items:center;gap:12px}
    .brand .logo{-webkit-font-smoothing:antialiased; font-size:22px;color:#2b6cb0}
    .search-input{width:420px;max-width:50vw}
    .top-actions{display:flex;align-items:center;gap:10px}

    /* --- FAB --- */
    .fab {
      position: fixed;
      right: 26px;
      bottom: 26px;
      width: 62px;
      height: 62px;
      border-radius: 50%;
      background: linear-gradient(135deg,#2b6cb0,#4fa3ff);
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow:0 8px 20px rgba(43,108,176,.18);
      cursor:pointer;
      z-index:1050;
    }
    .fab .fa{font-size:20px}

    /* --- Container --- */
    .workspace { padding: 20px 20px 120px; max-width:1200px; margin: 0 auto; }

    /* --- Controls --- */
    .controls { display:flex; justify-content:space-between; align-items:center; margin-bottom:18px; flex-wrap:wrap; gap:10px; }
    .view-toggle .btn { min-width:44px; }

    /* --- Grid of cards --- */
    .cards { display:flex; flex-wrap:wrap; gap:16px; }
    .card {
      width: 210px;
      background:#fff;
      border-radius:10px;
      padding:12px;
      box-shadow:0 4px 10px rgba(11,22,44,.04);
      transition:transform .14s ease,box-shadow .14s ease;
      display:flex;
      flex-direction:column;
      justify-content:space-between;
    }
    .card:hover { transform: translateY(-4px); box-shadow:0 10px 30px rgba(11,22,44,.08); }
    .card .icon {
      width:48px;height:48px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:20px;color:#fff;margin-bottom:10px;
    }
    .card .name { font-weight:600; font-size:14px; color:#213547; margin-bottom:6px; word-break:break-all; }
    .card .meta { font-size:12px; color:#7a8899; margin-bottom:8px; }
    .card .actions { display:flex; gap:8px; }

    /* folder / file colors */
    .ic-folder { background: linear-gradient(135deg,#ffd166,#ffba69); color:#5a3c00; }
    .ic-file   { background: linear-gradient(135deg,#b3d4ff,#8cc0ff); color:#054a91; }
    .ic-php    { background: linear-gradient(135deg,#e6e9ff,#c9cfff); color:#2b2b8f; }
    .protected-badge { background:#fbe9e7;color:#a12a2a;padding:3px 6px;border-radius:4px;font-size:11px;margin-left:8px }

    /* --- List view --- */
    .list { display:none; background:#fff;border-radius:6px;box-shadow:0 4px 10px rgba(11,22,44,.04) }
    .list table { margin:0 }
    .list .name-col { font-weight:600 }

    /* --- Responsive --- */
    @media (max-width:800px){
      .cards { justify-content:center }
      .card { width:46%; }
      .search-input{width:200px}
    }
    @media (max-width:480px) {
      .card { width:100%; }
      .search-input{width:120px}
      .top-actions .btn-text { display:none; }
    }
  </style>
</head>
<body>

  <!-- topbar -->
  <div class="topbar">
    <div class="container">
      <div class="brand">
        <span class="logo"><i class="fa fa-folder-open"></i></span>
        <span>Explorer <small style="font-weight:400;color:#6b7b8a;margin-left:6px">Workspace</small></span>
      </div>

      <div style="display:flex;align-items:center;gap:12px">
        <form class="form-inline" method="get" action="/explorer/search" style="margin:0;">
          <input name="q" class="form-control search-input" type="search" placeholder="Pesquisar arquivos..." value="<?php echo isset($q)?htmlspecialchars($q):''; ?>">
        </form>

        <div class="top-actions">
          <a class="btn btn-default btn-sm btn-text" href="/explorer/trash"><i class="fa fa-trash"></i> Lixeira</a>
          <button class="btn btn-default btn-sm view-toggle" id="toggleView" title="Alternar visual"><i class="fa fa-th"></i></button>
          <a class="btn btn-primary btn-sm" href="/explorer"><i class="fa fa-home"></i></a>
        </div>
      </div>
    </div>
  </div>

  <!-- main -->
  <div class="workspace container">
    <div class="controls">
      <div>
        <strong>Local:</strong>
        <span class="text-muted" style="margin-left:8px"><?php echo htmlspecialchars($rel === '' ? '/' : $rel); ?></span>
      </div>

      <div>
        <small class="text-muted">Ações rápidas:</small>
        <a class="btn btn-default btn-sm" href="javascript:;" id="selectAllBtn">Selecionar tudo</a>
        <a class="btn btn-default btn-sm" href="javascript:;" id="deselectAllBtn">Limpar</a>
        <a class="btn btn-default btn-sm" id="bulkDownloadBtn">Baixar selecionados</a>
      </div>
    </div>

    <!-- Grid cards -->
    <div id="gridView" class="cards" aria-live="polite">
      <?php if ($items === false): ?>
        <div class="alert alert-warning">Não foi possível listar a pasta.</div>
      <?php elseif (empty($items)): ?>
        <div class="alert alert-info">Pasta vazia.</div>
      <?php else: foreach ($items as $it): 
          $isDir = $it['is_dir'];
          $ext = strtolower(pathinfo($it['name'], PATHINFO_EXTENSION));
          $iconClass = $isDir ? 'ic-folder' : 'ic-file';
          if (!$isDir && $ext === 'php') $iconClass = 'ic-php';
      ?>
        <div class="card" data-rel="<?php echo htmlspecialchars($it['relpath']); ?>" data-name="<?php echo htmlspecialchars($it['name']); ?>" data-isdir="<?php echo $isDir?1:0; ?>">
          <div>
            <div class="icon <?php echo $iconClass; ?>">
              <?php if ($isDir): ?><i class="fa fa-folder"></i><?php else: ?><i class="fa fa-file"></i><?php endif; ?>
            </div>
            <div class="name"><?php echo htmlspecialchars($it['name']); ?>
              <?php if (!empty($it['protected'])): ?><span class="protected-badge">PROTEGIDO</span><?php endif; ?>
            </div>
            <div class="meta"><?php echo $it['is_dir'] ? 'Pasta' : htmlspecialchars(call_user_func($humanFileSize, $it['size'])); ?> • <?php echo date('Y-m-d H:i', $it['mtime']); ?></div>
          </div>
          <div class="actions">
            <?php if ($it['is_dir']): ?>
              <a class="btn btn-xs btn-default" href="/explorer?p=<?php echo rawurlencode($it['relpath']); ?>"><i class="fa fa-folder-open"></i></a>
            <?php else: ?>
              <a class="btn btn-xs btn-default" href="/explorer/download?target=<?php echo rawurlencode($it['relpath']); ?>" title="Baixar"><i class="fa fa-download"></i></a>
              <a class="btn btn-xs btn-default" href="/explorer/view?target=<?php echo rawurlencode($it['relpath']); ?>" target="_blank" title="Ver"><i class="fa fa-eye"></i></a>
              <a class="btn btn-xs btn-info" href="/explorer/edit?target=<?php echo rawurlencode($it['relpath']); ?>" title="Editar"><i class="fa fa-pencil"></i></a>
            <?php endif; ?>

            <?php if (!empty($it['protected'])): ?>
              <span class="label label-danger">PROT</span>
            <?php else: ?>
              <button class="btn btn-xs btn-default renameBtn" data-rel="<?php echo htmlspecialchars($it['relpath']); ?>" data-name="<?php echo htmlspecialchars($it['name']); ?>" title="Renomear"><i class="fa fa-edit"></i></button>

              <button class="btn btn-xs btn-default moveBtn" data-rel="<?php echo htmlspecialchars($it['relpath']); ?>" data-name="<?php echo htmlspecialchars($it['name']); ?>" title="Mover"><i class="fa fa-arrows"></i></button>

              <button class="btn btn-xs btn-danger deleteBtn" data-rel="<?php echo htmlspecialchars($it['relpath']); ?>" data-name="<?php echo htmlspecialchars($it['name']); ?>" title="Excluir"><i class="fa fa-trash"></i></button>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; endif; ?>
    </div>

    <!-- List view (hidden by default) -->
    <div id="listView" class="list">
      <table class="table table-hover table-condensed">
        <thead><tr><th style="width:40px"></th><th>Nome</th><th>Tamanho</th><th>Modificado</th><th style="width:240px">Ações</th></tr></thead>
        <tbody>
          <?php if ($items !== false && !empty($items)): foreach ($items as $it): ?>
            <tr data-rel="<?php echo htmlspecialchars($it['relpath']); ?>" data-name="<?php echo htmlspecialchars($it['name']); ?>" data-isdir="<?php echo $it['is_dir']?1:0; ?>">
              <td><input type="checkbox" class="sel-item" value="<?php echo htmlspecialchars($it['relpath']); ?>"></td>
              <td class="name-col"><?php echo $it['is_dir']?'<i class="fa fa-folder"></i> ':'<i class="fa fa-file"></i> ';?> <?php echo htmlspecialchars($it['name']); ?> <?php if(!empty($it['protected'])) echo '<span class="label label-danger">PROT</span>'; ?></td>
              <td><?php echo $it['is_dir']?'-':htmlspecialchars(call_user_func($humanFileSize,$it['size'])); ?></td>
              <td><?php echo date('Y-m-d H:i', $it['mtime']); ?></td>
              <td>
                <?php if ($it['is_dir']): ?>
                  <a class="btn btn-xs btn-default" href="/explorer?p=<?php echo rawurlencode($it['relpath']); ?>"><i class="fa fa-folder-open"></i> Abrir</a>
                <?php else: ?>
                  <a class="btn btn-xs btn-default" href="/explorer/download?target=<?php echo rawurlencode($it['relpath']); ?>"><i class="fa fa-download"></i> Baixar</a>
                  <a class="btn btn-xs btn-default" href="/explorer/view?target=<?php echo rawurlencode($it['relpath']); ?>" target="_blank"><i class="fa fa-eye"></i> Ver</a>
                  <a class="btn btn-xs btn-info" href="/explorer/edit?target=<?php echo rawurlencode($it['relpath']); ?>"><i class="fa fa-pencil"></i> Editar</a>
                <?php endif; ?>
                <?php if (empty($it['protected'])): ?>
                  <button class="btn btn-xs btn-default renameBtn" data-rel="<?php echo htmlspecialchars($it['relpath']); ?>" data-name="<?php echo htmlspecialchars($it['name']); ?>">Renomear</button>
                  <button class="btn btn-xs btn-default moveBtn" data-rel="<?php echo htmlspecialchars($it['relpath']); ?>" data-name="<?php echo htmlspecialchars($it['name']); ?>">Mover</button>
                  <button class="btn btn-xs btn-danger deleteBtn" data-rel="<?php echo htmlspecialchars($it['relpath']); ?>" data-name="<?php echo htmlspecialchars($it['name']); ?>">Deletar</button>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; else: ?>
            <tr><td colspan="5" class="text-center">Nenhum item</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

  </div>

  <!-- Floating Action Button -->
  <div class="fab" id="fab" title="Criar / Upload">
    <i class="fa fa-plus"></i>
  </div>

  <!-- Hidden forms & modals -->
  <!-- Rename Modal -->
  <div id="renameModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog"><div class="modal-content">
      <form method="post" action="/explorer/rename">
      <div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button><h4 class="modal-title">Renomear</h4></div>
      <div class="modal-body">
        <input type="hidden" name="_csrf" value="<?php echo htmlspecialchars($csrf); ?>">
        <input type="hidden" name="target" id="rename_target" value="">
        <div class="form-group"><label>Novo nome</label><input type="text" name="newname" id="rename_newname" class="form-control" required></div>
      </div>
      <div class="modal-footer"><button class="btn btn-default" data-dismiss="modal">Cancelar</button><button class="btn btn-primary" type="submit">Salvar</button></div>
      </form>
    </div></div>
  </div>

  <!-- Move Modal -->
  <div id="moveModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog"><div class="modal-content">
      <form method="post" action="/explorer/move">
      <div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button><h4 class="modal-title">Mover</h4></div>
      <div class="modal-body">
        <input type="hidden" name="_csrf" value="<?php echo htmlspecialchars($csrf); ?>">
        <input type="hidden" name="target" id="move_target" value="">
        <div class="form-group"><label>Destino (pasta relativa)</label><input type="text" name="dest" id="move_dest" class="form-control" placeholder="ex: path/to/folder" required></div>
        <p class="small text-muted">Use caminho relativo à raiz do Explorer. Ex.: <code>public/uploads</code></p>
      </div>
      <div class="modal-footer"><button class="btn btn-default" data-dismiss="modal">Cancelar</button><button class="btn btn-primary" type="submit">Mover</button></div>
      </form>
    </div></div>
  </div>

  <!-- Delete Confirm Modal -->
  <div id="deleteModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog"><div class="modal-content">
      <form method="post" action="/explorer/delete">
      <div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button><h4 class="modal-title">Confirmar exclusão</h4></div>
      <div class="modal-body">
        <input type="hidden" name="_csrf" value="<?php echo htmlspecialchars($csrf); ?>">
        <input type="hidden" name="target" id="del_target" value="">
        <p>Deseja mover este item para a Lixeira?</p>
        <p id="del_filename" style="font-weight:600"></p>
      </div>
      <div class="modal-footer"><button class="btn btn-default" data-dismiss="modal">Cancelar</button><button class="btn btn-danger" type="submit">Mover para Lixeira</button></div>
      </form>
    </div></div>
  </div>

  <!-- Upload Modal -->
  <div id="uploadModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog"><div class="modal-content">
      <form method="post" action="/explorer/upload?p=<?php echo rawurlencode($rel); ?>" enctype="multipart/form-data">
      <div class="modal-header"><button type="button" class="close" data-dismiss="modal">&times;</button><h4 class="modal-title">Enviar arquivo</h4></div>
      <div class="modal-body">
        <input type="hidden" name="_csrf" value="<?php echo htmlspecialchars($csrf); ?>">
        <div class="form-group"><label>Arquivo</label><input type="file" name="file" class="form-control"></div>
        <div class="form-group"><label>Enviar para</label><input type="text" class="form-control" value="<?php echo htmlspecialchars($rel); ?>" readonly></div>
      </div>
      <div class="modal-footer"><button class="btn btn-default" data-dismiss="modal">Fechar</button><button class="btn btn-primary" type="submit">Enviar</button></div>
      </form>
    </div></div>
  </div>

  <!-- jQuery + Bootstrap JS (ajuste caminhos se necessário) -->
  <script src="/assets/jquery/jquery.min.js"></script>
  <script src="/assets/bootstrap/js/bootstrap.min.js"></script>

  <!-- Custom JS: interatividade -->
  <script>
    (function($){
      var gridMode = true;
      function showGrid(){ $('#listView').hide(); $('#gridView').show(); gridMode=true; $('#toggleView i').removeClass('fa-list').addClass('fa-th'); }
      function showList(){ $('#gridView').hide(); $('#listView').show(); gridMode=false; $('#toggleView i').removeClass('fa-th').addClass('fa-list'); }

      // initial
      showGrid();

      // toggle view
      $('#toggleView').on('click', function(e){ e.preventDefault(); if(gridMode) showList(); else showGrid(); });

      // FAB opens upload modal
      $('#fab').on('click', function(){ $('#uploadModal').modal('show'); });

      // rename
      $('.renameBtn').on('click', function(){
        var rel = $(this).data('rel'), name = $(this).data('name');
        $('#rename_target').val(rel); $('#rename_newname').val(name);
        $('#renameModal').modal('show');
      });

      // move
      $('.moveBtn').on('click', function(){
        var rel = $(this).data('rel'), name = $(this).data('name');
        $('#move_target').val(rel); $('#move_dest').val('');
        $('#moveModal').modal('show');
      });

      // delete
      $('.deleteBtn').on('click', function(){
        var rel = $(this).data('rel'), name = $(this).data('name');
        $('#del_target').val(rel); $('#del_filename').text(name);
        $('#deleteModal').modal('show');
      });

      // selection helpers
      $('#selectAllBtn').on('click', function(){
        $('.sel-item').prop('checked', true);
        $('.card input.sel-item').prop('checked', true);
      });
      $('#deselectAllBtn').on('click', function(){
        $('.sel-item').prop('checked', false);
        $('.card input.sel-item').prop('checked', false);
      });

      // add checkbox inputs to cards dynamically for uniform selection
      $('.card').each(function(){
        var rel = $(this).data('rel');
        $('<input type="checkbox" class="sel-item" style="position:absolute;top:8px;right:8px;">').val(rel).appendTo(this);
      });

      // bulk download (simple: build multiple download links sequentially)
      $('#bulkDownloadBtn').on('click', function(){
        var items = $('.sel-item:checked').map(function(){ return $(this).val(); }).get();
        if(items.length === 0){ alert('Nenhum item selecionado'); return; }
        // For multiple files we could create zip server-side. Here fallback: open each in new tab for download (browser may block many tabs).
        if(items.length > 5 && !confirm('Baixar ' + items.length + ' arquivos? Isso pode abrir várias janelas. Deseja continuar?')) return;
        for(var i=0;i<items.length;i++){
          var url = '/explorer/download?target=' + encodeURIComponent(items[i]);
          window.open(url, '_blank');
        }
      });

      // keyboard: press "g" for grid, "l" for list
      $(document).on('keydown', function(e){
        if (e.key === 'g') showGrid();
        if (e.key === 'l') showList();
      });

    })(jQuery);
  </script>
</body>
</html>