<?php
// search.php - resultados de busca
// Variáveis: $q, $results, $csrf
?>
<!doctype html>
<html lang="pt-br">
    <head>
    <meta charset="utf-8">
        <title>Busca - File Manager</title>
        <link rel="stylesheet" href="/assets/bootstrap/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container">
            <h4>Resultados para: <?php echo htmlspecialchars($q); ?></h4>
            <a href="/explorer/search" class="btn btn-default">Voltar</a>
            <hr>
        <?php if (empty($results)): ?>
            <div class="alert alert-info">Nenhum resultado.</div>
        <?php else: ?>
            <ul class="list-group">
                <?php foreach ($results as $r): ?>
                    <li class="list-group-item">
                        <?php echo htmlspecialchars($r); ?>
                        <div class="pull-right">
                            <a class="btn btn-xs btn-default" href="/explorer/download?target=<?php echo rawurlencode($r); ?>">Baixar</a>
                            <a class="btn btn-xs btn-default" href="/explorer/view?target=<?php echo rawurlencode($r); ?>" target="_blank">Ver</a>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
        </div>
    </body>
</html>