<?php
// views/explorer/trash.php
if (!isset($files)) $files = array();
if (!isset($csrf)) $csrf = '';
?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<title>Lixeira</title>
<link rel="stylesheet" href="/assets/bootstrap/css/bootstrap.min.css">
</head>
<body>
<div class="container">
  <h4>Lixeira</h4>
  <a href="/explorer" class="btn btn-default">Voltar</a>
  <hr>
  <?php if (empty($files)): ?>
    <div class="alert alert-info">Lixeira vazia.</div>
  <?php else: ?>
    <table class="table table-condensed">
      <thead><tr><th>Nome</th><th>Ações</th></tr></thead>
      <tbody>
      <?php foreach ($files as $f): ?>
        <tr>
          <td><?php echo htmlspecialchars($f); ?></td>
          <td>
            <form method="post" action="/explorer/restore" style="display:inline">
              <input type="hidden" name="_csrf" value="<?php echo htmlspecialchars($csrf); ?>">
              <input type="hidden" name="file" value="<?php echo htmlspecialchars($f); ?>">
              <button class="btn btn-xs btn-success" type="submit">Restaurar</button>
            </form>
            <a class="btn btn-xs btn-danger" href="/explorer/download?target=<?php echo rawurlencode($f); ?>">Baixar</a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>
</body>
</html>
