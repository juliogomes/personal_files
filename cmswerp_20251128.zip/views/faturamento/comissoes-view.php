<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "comissoes";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Faturamento</li>
		<li>Comissoes</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i>Comissoes
		<?= $_POST['data_faturamento'] ?>
	</h4>
	<form class="form-inline page-toolbar" method="post" action="/faturamento/processarComissao/">
	<div class="container-fluid">
	<div class="row">
	<div class="col-md-12">
		<div class="pull-left">
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Nome</div>
					<input class="form-control" type="text" id="search1" style="width:100px;">
				</div>
			</div> 
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Cargo</div>
					<input class="form-control" type="text" id="search2" style="width:100px;">
				</div>
			</div> 
			<!--
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Cliente</div>
					<input class="form-control" type="text" id="search3" style="width:100px;" >
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Produto</div>
					<input class="form-control" type="text" id="search4" style="width:100px;">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Status</div>
					<select class="form-control" name="status" id="search5">
						<option value="pendente" <?= ($this->parametros[1] == 'pendente')?'selected':null; ?>>Pendente</option>
						<option value="agendado" <?= ($this->parametros[1] == 'agendado')?'selected':null; ?> >Agendado</option>
						<option value="pago" <?= ($this->parametros[1] == 'pago')?'selected':null; ?> >Pago</option>
						<option value="all" <?= ($this->parametros[1] == 'all')?'selected':null; ?>>Todos</option>
					</select>
				</div>
			</div>
		-->
		</div>
	</div>
	</div>
	<br>
	<div class="row">
			<div class="col-md-12">
				<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
					<thead>
						<tr role="row">
							<th class="text-center">Nome</th>
							<th class="text-center">Cargo</th>
							<th class="text-center"></th>
						</tr>
					</thead>
					<tbody>
						<?php if (is_array($dados)){ ?>
						<?php foreach($dados as $key => $value) {
						?>
						<tr>
							<td class="text-left"><small class="label-status" ><?= $value->nome; ?></small></td>
							<td class="text-center"><small class="label-status"><?= $value->cargo; ?></small></td>
							<td class="text-center"><a class="btn btn-info" href="/comissoes/extrato/id_comercial/<?= $value->id ?>/<?= $value->cargo ?>"><i class="fa fa-edit"></i> </span> </a></td>
						</tr>
						<?php } ?>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<!-- Modal -->
<div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="myModalLabel">Modal header</h3>
    </div>
    <div class="modal-body">
        <p>One fine body</p>
    </div>
    <div class="modal-footer">
        <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
        <button class="btn btn-primary">Save changes</button>
    </div>
</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript">
		$(function() {
			$('#search5').change(function(e){
				var status = $(this).val();
				window.location.href = "/faturamento/listarcomissoes/filter/"+status;
			});

			oTable = $('#list').DataTable({
				"order": [[ 4, "asc" ]],
				info: true,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				}
			});
			$('#search1').keyup(function(){
				oTable
				.columns( 0 )
				.search( this.value )
				.draw();
			});
			$('#search2').keyup(function(){
				oTable
				.columns( 1 )
				.search( this.value )
				.draw();
			});
			$('#search3').keyup(function(){
				oTable
				.columns( 2 )
				.search( this.value )
				.draw();
			});
			$('#search4').keyup(function(){
				oTable
				.columns( 3 )
				.search( this.value )
				.draw();
			});
			$('.dt_pagamento').mask('00/00/0000', {
				onComplete: function(value, event, field) {
					oTable
					.columns( 0 )
					.search( value )
					.draw();
				}
			}).datepicker({
				format: "dd/mm/yyyy",
				clearBtn: true,
				language: "pt-BR",
				autoclose: true,
				todayBtn: "linked",
				todayHighlight: true
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</form>
</body>
</html>
