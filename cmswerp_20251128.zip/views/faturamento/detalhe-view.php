<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
	<head>
		<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
		<?php include 'template/head-css.inc' ?>
		<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
		<!-- PAGE STYLES -->
		<script type="text/javascript">
			var sidebarItem = "gerar notas fiscais";
		</script>
		<!-- /PAGE STYLES -->
	</head>
	<body>
		<!-- MENU + WRAPPER -->
		<?php include "template/menu-wrapper.php" ?>
		<!-- /MENU + WRAPPER -->
		<!-- HEADER -->
		<ol class="breadcrumb">
			<li>Tarifas.cmsw.com</li>
			<li>Faturamento</li>
			<li>Notas fiscais</li>
			<li><?= $dados->contrato->nome_fantasia; ?></li>
		</ol>
		<h4 class="page-title"></h4>
		<!-- /HEADER -->
		<!-- CONTENT -->
		<form class="form-inline page-toolbar" id="gerar_nf" name="gerar_nf" method="post" action="">
			<div class="container-fluid">
			    <div class="row">
    				<div class="col-sm-12 col-md-12">
    					<?php if (count($this->obj_faturamento->getErro()) > 0) { ?>
    						<div class="alert alert-danger">
    							<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    							<strong>
    								<?php foreach ($this->obj_faturamento->getErroMsg() as $key => $item) { ?>
    									<p>
    									<h4><i class="fa fa-warning"></i> <?= strtoupper($item); ?></h4>
    									</p>
    								<?php } ?>
    							</strong>
    						</div>
    					<?php } ?>
    				</div>
    			</div>
				<div class="row">
					<div class="col-sm-12 col-md-12">
						<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
							<tbody>
								<tr>
									<td colspan="12">Prestador de serviços</td>
								</tr>
								<tr>
									<td colspan="6">
										<?= $dados->contrato->razao_social_cm; ?><br>
										<?= $dados->contrato->endereco_cm; ?><br>
										<?= $dados->contrato->cep_cm.' - '.$dados->contrato->cidade_cm.' - '.$dados->contrato->estado_cm ?><br>
									</td>
									<td colspan="6">
											<?= 'CNPJ/CPF '.mask($dados->contrato->cnpj_cm, '##.###.###/####-##'); ?><br>
											<?= 'Inscrição estadual '.$dados->contrato->inscricao_estadual_cm; ?><br>
									</td>
								</tr>
								<tr>
									<td colspan="4">Tomador de serviços</td>
									<td colspan="4">CNPJ/CPF</td>
									<td colspan="4">PRODUTO</td>
								</tr>
								<tr>
									<td colspan="4"><?= $dados->contrato->nome_fantasia; ?></td>
									<td colspan="4"><?= mask($dados->contrato->cnpj, '##.###.###/####-##'); ?></td>
									<td colspan="4"><?= $dados->contrato->nome_produto; ?></td>
								</tr>
								<tr>
									<td colspan="1">Endereço</td>
									<td colspan="11"><?= $dados->contrato->endereco.', '.$dados->contrato->numero; ?></td>
								</tr>
								<tr>
									<td colspan="6">
										<?= 'CEP: '.$dados->contrato->cep.' - '.$dados->contrato->bairro; ?>
									</td>
									<td colspan="6">
										<?=  $dados->contrato->cidade.' - '.$dados->contrato->estado; ?><br>
									</td>
								</tr>
								<tr>
									<td colspan="12">Email:
										<?= $dados->contrato->email_nf; ?><br>
									</td>
								</tr>
								<tr>
									<td>Serviço</td>
									<td>Pacote</td>
									<td>Prorrata</td>
									<td>Quantidade</td>
									<td>Desc Quantidade</td>
									<td>$ Liquido</td>
									<td>$ Imposto</td>
									<td>Desconto %</td>
									<td>$ Desconto</td>
									<td>$ C/ Desconto</td>
									<td>$ S/ Desconto</td>
									<td>Periodo</td>
								</tr>
								<tr>
									<?php if( $dados->receita->detalhe->faturamento ) { ?>
										<?php foreach ( $dados->receita->detalhe->faturamento as $key => $value ) { ?>
											<?php if( isset($value->valor_liquido) && $value->valor_liquido > 0 ){ ?>
												<?php $transacoes = $value->transacoes; ?>
												<tr>
													<td><?= $value->nome_modulo; ?></td>
													<td><?= ($value->over_pct == 1)?'NÃO':'SIM'; ?></td>
													<td><?= (isset($value->prorrata) && $value->prorrata == 1)?'SIM':'NÃO'; ?></td>
													<td><?= number_format($transacoes, '0', ',', '.'); ?></td>
													<td><?= (isset($value->qtd_desconto))?$value->qtd_desconto:0; ?></td>
													<td><?= number_format($value->valor_liquido, '2', ',', '.'); ?></td>
													<td><?= number_format($value->impostos->totalizadores->semretencao->total, '2', ',', '.'); ?></td>
													<td><?= number_format((isset($value->aliquota_desconto))?$value->aliquota_desconto:0, '2', ',', '.'); ?></td>
													<td><?= number_format((isset($value->valor_desconto))?$value->valor_desconto:0, '2', ',', '.'); ?></td>
													<td><?= number_format((($value->valor_liquido+$value->impostos->totalizadores->semretencao->total)-$value->valor_desconto), '2', ',', '.'); ?></td>
													<td><?= number_format(($value->valor_liquido+$value->impostos->totalizadores->semretencao->total), '2', ',', '.'); ?></td>
													<td><?= convertDate($dados->periodo_de).' - '.convertDate($dados->periodo_ate); ?></td>
												</tr>
											<?php } ?>
										<?php } ?>
									<?php } ?>
								</tr>
								<tr>
									<?php if( $extras['cobrar_multa'] == 1 && isset( $dados->receita->detalhe->multa ) ) { ?>
										<?php foreach( $dados->receita->detalhe->multa as $key => $value ) { ?>
											<tr>
												<td><?= $value->descricao; ?></td>
												<td>NÃO</td>
												<td class="text-center">-</td>
												<td><?= $value->transacoes; number_format( $value->transacoes, '0', ',', '.' ); ?></td>
												<td><?= ( isset( $value->qtd_desconto ) )?$value->qtd_desconto:0; ?></td>
												<td><?= number_format( $value->valor_liquido, '2', ',', '.'); ?></td>
												<td><?= number_format( $value->impostos->totalizadores->semretencao->total, '2', ',', '.'); ?></td>
												<td><?= number_format( $value->aliquota_desconto, '2', ',', '.'); ?></td>
												<td><?= number_format( $value->valor_desconto, '2', ',', '.'); ?></td>
												<td><?= number_format( ( ( $value->valor_liquido + $value->impostos->totalizadores->semretencao->total ) - $value->valor_desconto), '2', ',', '.'); ?></td>
												<td><?= number_format( ( $value->valor_liquido + $value->impostos->totalizadores->semretencao->total ), '2', ',', '.'); ?></td>
												<td class="text-center">--</td>
											</tr>
										<?php } ?>
									<?php } ?>
								</tr>
								<tr>
									<?php if( $extras['cobrar_multa'] == 1 && isset( $dados->receita->detalhe->juros ) ) { ?>
										<?php foreach( $dados->receita->detalhe->juros as $key => $value ) { ?>
											<tr>
												<td><?= $value->descricao; ?></td>
												<td>NÃO</td>
												<td class="text-center">-</td>
												<td><?= $value->transacoes; number_format( $value->transacoes, '0', ',', '.' ); ?></td>
												<td><?= ( isset( $value->qtd_desconto ) )?$value->qtd_desconto:0; ?></td>
												<td><?= number_format( $value->valor_liquido, '2', ',', '.'); ?></td>
												<td><?= number_format( $value->impostos->totalizadores->semretencao->total, '2', ',', '.'); ?></td>
												<td><?= number_format( $value->aliquota_desconto, '2', ',', '.'); ?></td>
												<td><?= number_format( $value->valor_desconto, '2', ',', '.'); ?></td>
												<td><?= number_format( ( ( $value->valor_liquido + $value->impostos->totalizadores->semretencao->total ) - $value->valor_desconto), '2', ',', '.'); ?></td>
												<td><?= number_format( ( $value->valor_liquido + $value->impostos->totalizadores->semretencao->total ), '2', ',', '.'); ?></td>
												<td class="text-center">--</td>
											</tr>
										<?php } ?>
									<?php } ?>
								</tr>
								<tr>
									<?php if( $extras['cobrar_reajuste'] == 1 && isset( $dados->receita->detalhe->reajuste ) ) { ?>
										<?php foreach ( $dados->receita->detalhe->reajuste as $key => $value ) { ?>
											<tr>
												<td><?= $value->descricao; ?></td>
												<td>NÃO</td>
												<td class="text-center">-</td>
												<td><?= $value->transacoes; number_format( $value->transacoes, '0', ',', '.' ); ?></td>
												<td><?= ( isset( $value->qtd_desconto ) )?$value->qtd_desconto:0; ?></td>
												<td><?= number_format( $value->valor_liquido, '2', ',', '.'); ?></td>
												<td><?= number_format( $value->impostos->totalizadores->semretencao->total, '2', ',', '.'); ?></td>
												<td><?= number_format( $value->aliquota_desconto, '2', ',', '.'); ?></td>
												<td><?= number_format( $value->valor_desconto, '2', ',', '.'); ?></td>
												<td><?= number_format( ( ( $value->valor_liquido + $value->impostos->totalizadores->semretencao->total ) - $value->valor_desconto), '2', ',', '.'); ?></td>
												<td><?= number_format( ( $value->valor_liquido + $value->impostos->totalizadores->semretencao->total ), '2', ',', '.'); ?></td>
												<td class="text-center">--</td>
											</tr>
										<?php } ?>
									<?php } ?>
								</tr>
								<tr>
									<?php if( isset($dados->receita->detalhe->lancamento) && $dados->receita->detalhe->lancamento ) { ?>
										<?php foreach ($dados->receita->detalhe->lancamento as $key => $value) { ?>
											<?php if($value->valor_liquido > 0){ ?>
												<?php $transacoes = $value->transacoes; ?>
												<tr>
													<td><?= $value->descricao; ?></td>
													<td><?= ($value->over_pct == 1)?'NÃO':'SIM'; ?></td>
													<td><?= (isset($value->prorrata) && $value->prorrata == 1)?'SIM':'NÃO'; ?></td>
													<td><?= number_format($transacoes, '0', ',', '.'); ?></td>
													<td><?= (isset($value->qtd_desconto))?$value->qtd_desconto:0; ?></td>
													<td><?= number_format($value->valor_liquido, '2', ',', '.'); ?></td>
													<td><?= number_format($value->impostos->totalizadores->semretencao->total, '2', ',', '.'); ?></td>
													<td><?= number_format((isset($value->aliquota_desconto))?$value->aliquota_desconto:0, '2', ',', '.'); ?></td>
													<td><?= number_format((isset($value->valor_desconto))?$value->valor_desconto:0, '2', ',', '.'); ?></td>
													<td><?= number_format((($value->valor_liquido+$value->impostos->totalizadores->semretencao->total)-$value->valor_desconto), '2', ',', '.'); ?></td>
													<td><?= number_format(($value->valor_liquido+$value->impostos->totalizadores->semretencao->total), '2', ',', '.'); ?></td>
													<td><?= convertDate($dados->periodo_de).' - '.convertDate($dados->periodo_ate); ?></td>
												</tr>
											<?php } ?>
										<?php } ?>
									<?php } ?>
								</tr>
								<tr>
									<td colspan="3"><b>TOTAL</b></td>
									<td><b>-</b></td>
									<td><b>-</b></td>
									<td><b><?= number_format($dados->receita->resumo->total_liquido, '2', ',', '.'); ?></b></td>
									<td><b><?= number_format($dados->receita->resumo->total_imposto, '2', ',', '.'); ?></b></td>
									<td><b>-</td>
									<td><b><?= number_format($dados->receita->resumo->total_desconto, '2', ',', '.'); ?></b></td>
									<td><b><?= number_format((($dados->receita->resumo->total_liquido + $dados->receita->resumo->total_imposto) - $dados->receita->resumo->total_desconto), '2', ',', '.'); ?></b></td>
									<td><b><?= number_format(($dados->receita->resumo->total_liquido + $dados->receita->resumo->total_imposto), '2', ',', '.'); ?></b></td>
									<td class="text-center">--</td>
								</tr>
								<tr></tr>
								<tr><td colspan="12"><b>CONTRATO ASSINADO EM:</b> <?= convertDate($dados->contrato->data_assinatura); ?></td></tr>
								<tr><td colspan="12"><b>FATURAMENTO TODO DIA:</b> <?= $dados->contrato->data_corte_faturamento; ?></td></tr>
								<tr><td colspan="12"><b>PRIMEIRO FATURAMENTO EM:</b> <?= (isset($dados->primeiro_faturamento))?convertDate($dados->primeiro_faturamento):null; ?></td></tr>
								<tr>
									<td colspan="12">
										<?php if(!empty($dados->ultimo_faturamento)){ ?>
											<b>ULTIMO  NOTA EMITIDA EM: </b> <?= convertDate($dados->ultimo_faturamento->data_emissao) ?><br><br>
											<b>PERDIODO DE:</b> <?= convertDate($dados->ultimo_faturamento->periodo_de) ?>
											<b>ATÉ:</b> <?= convertDate($dados->ultimo_faturamento->periodo_ate) ?>
										<?php }else{ ?>
											<b><font size="8px" color="blue">PRIMEIRO FATURAMENTO DESTE CLIENTE</font><br>
										<?php } ?>
									</td>
								</tr>
								<tr>
									<td colspan="12">
										<?php if(isset($dados->msg_aviso) && !empty($dados->msg_aviso)){ ?>
											<b><font size="13px" color="red"><?= strtoupper($dados->msg_aviso) ?></font><br>
										<?php } ?>
									</td>
								</tr>
								<tr><td colspan="12"></td></tr>
								<tr>
									<td colspan="1">VENCIMENTO EM <input type="text" name="data_vencimento" value="<?= convertDate($dados->data_vencimento) ?>" class="form-control campo_data" /></td>
									<td colspan="11">
										<label for="periodo_de"> FATURAMENTO DE: </label>
										<input type="text" name="periodo_de" value="<?= convertDate($dados->periodo_de) ?>" class="form-control datepast" />
										<label for="periodo_ate">FATURAMENTO ATÉ:</label>
										<input type="text" name="periodo_ate" value="<?= convertDate($dados->periodo_ate) ?>" class="form-control datepast" />
									</td>
								</tr>
								<tr>
									<td colspan="12"><b>DESCONTOS</b></td>
								</tr>
								<tr>
									<td colspan="12">
										<input type="text" name="valor_desconto" class="form-control mask-money" value="<?= $extras['valor_desconto'] ?>", placeholder="0,00" />
										<select name="tipo_desconto" class="form-control">
											<option value="percentual" <?= ($tipo_desconto == 'percentual')?'selected':null ?> >Porcentagem</option>
											<option value="valor" <?= ($tipo_desconto == 'valor')?'selected':null ?>>Em dinheiro</option>
										</select>
									</td>
								</tr>
								<tr>
									<td colspan="12"><b>COBRAR MULTAS E JUROS SE HOUVER?</b></td>
								</tr>
								<tr>
									<td colspan="12">
										<select name="cobrar_multa" class="form-control">
											<option value="1" <?= ($extras['cobrar_multa'] == 1)?'selected':null ?> >SIM</option>
											<option value="0" <?= ($extras['cobrar_multa'] == 0)?'selected':null ?> >NÃO</option>
										</select>
									</td>
								</tr>
								<tr>
									<td colspan="12"><b>COBRAR REAJUSTE SE HOUVER?</b></td>
								</tr>
								<tr>
									<td colspan="12">
										<select name="cobrar_reajuste" class="form-control">
											<option value="1" <?= ($extras['cobrar_reajuste'] == 1)?'selected':null ?> >SIM</option>
											<option value="0" <?= ($extras['cobrar_reajuste'] == 0)?'selected':null ?> >NÃO</option>
										</select>
									</td>
								</tr>
								<tr><td colspan="12"><b>MODO PRO-RATA?</b></td></tr>
								<tr>
									<td colspan="12">
										<select name="prorrata" class="form-control">
											<option value="1" <?= ($extras['prorrata'] == 1)?'selected':null ?> >SIM</option>
											<option value="0" <?= ($extras['prorrata'] == 0)?'selected':null ?> >NÃO</option>
										</select>
									</td>
								</tr>
								<tr>
									<td colspan="12"><b>FORMA DE PAGAMENTO</b></td>
								</tr>
								<tr>
									<td class="text-left" colspan="2" >
										<select name="id_banco" class="form-control" required class="form-control">
											<?php if($dados->contas_recebimento){ ?>
												<?php foreach ($dados->contas_recebimento as $chave => $valor){ ?>
													<?php if($valor->conta_default == 1){ ?>
														<option value="<?= $valor->id; ?>" selected> <?= $valor->nome_reduzido.' AG: '.$valor->numero_agencia.' Conta: '.$valor->numero_conta.' - '.$valor->digito_conta; ?></option>
													<?php }else{ ?>
														<option value="<?= $valor->id; ?>"><?= $valor->nome_reduzido.' AG: '.$valor->numero_agencia.' Conta: '.$valor->numero_conta.' - '.$valor->digito_agencia; ?></option>
													<?php } ?>
												<?php }  ?>
											<?php }else{ ?>
												<option value="">Nenhuma conta cadastrada para <?= $dados->contrato->razao_social_cm; ?> </option>
											<?php } ?>
										</select>
									</td>
									<td class="text-left" colspan="10" >
										<select name="meio_pagamento" class="form-control" required class="form-control">
											<option value="boleto" <?= (isset($dados->contrato) && $dados->contrato->meio_pagamento == 'boleto')?'selected':null; ?> >BOLETO</option>
											<option value="doc"    <?= (isset($dados->contrato) && $dados->contrato->meio_pagamento == 'doc')?'selected':null; ?> >DOC</option>
											<option value="ted"    <?= (isset($dados->contrato) && $dados->contrato->meio_pagamento == 'ted')?'selected':null; ?> >TED</option>
											<option value="outros" <?= (isset($dados->contrato) && $dados->contrato->meio_pagamento == 'outros')?'selected':null; ?> >OUTROS</option>
										</select>
									</td>
								</tr>
								<tr>
									<td class="text-left" colspan="12" >
										<?php if (!$this->obj_faturamento->getErro()) { ?>
                                			<button type="button" id="btn_gerar_nf" name="btn_gerar_nf" value="gerar_nf" class="form-control btn btn-success"><b>GERAR NOTA</b></button>
                                		<?php } ?>
                                		<button type="button" id="voltar" class="form-control btn btn-primary"><b>VOLTAR</b></button>
                                		<button type="button" id="btn_reprocessar_nf" name="btn_reprocessar_nf" value="reprocessar_nf" class="form-control btn btn-warning"><b>REPROCESSAR</b></button>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</form>
		<!-- /.container-fluid -->
		<!-- /CONTENT -->
		<!-- END WRAPPER -->
		<?php include "template/end-menu-wrapper.html" ?>
		<!-- /END WRAPPER -->
		<!-- MODALS -->
		<!-- /MODALS -->
		<!-- INCLUDE DEFAULT SCRIPTS -->
		<?php include 'template/scripts.inc' ?>
		<!-- /INCLUDE DEFAULT SCRIPTS -->
		<!-- PAGE SCRIPTS -->
		<!-- Error Toaatr -->
		<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
		<!-- /Error Toaatr -->
		<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
		<!-- /PAGE SCRIPTS -->
		<script>
			$('.mask-money').maskMoney({allowNegative: false, thousands:'.', decimal:','});
			$('.mask-money').each(function(){ // function to apply mask on load!
				$(this).maskMoney('mask', $(this).val());
			})
			
			$('#voltar').click(function(){
				window.location.href = "/faturamento/listar";
			});
			$('#btn_gerar_nf').click(function(){
				$('#gerar_nf').attr('action', '/faturamento/gerar_nf/<?= $this->parametros[0] ?>').submit();
			})
			$('#btn_reprocessar_nf').click(function(){
				$('#gerar_nf').attr('action', '/faturamento/detalhe/<?= $this->parametros[0] ?>').submit();
			})
		</script>
	</body>
</html>