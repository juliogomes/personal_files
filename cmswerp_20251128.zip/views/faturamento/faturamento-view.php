<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "gerar notas fiscais";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Contas a receber</li>
		<li>Gerar Notas fiscais</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i>Gerar Notas fiscais
	</h4>
	<form class="form-inline page-toolbar" id="listar_nf" name="listar_nf" method="post" action="/faturamento/listar/">
	<div class="container-fluid">
	<div class="row">
	<div class="col-md-12">
		<div class="pull-left">
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Mostrar contratos ADM</div>
					<select name="show_adm" id="show_adm" class="form-control">
						<option value="0" <?= ($show_adm == 0)?'selected':null ?> >NÃO</option>
						<option value="1" <?= ($show_adm == 1)?'selected':null ?> >SIM</option>
					</select>
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Mostrar clientes com notas emitidas</div>
					<select name="mostrar_notas" id="mostrar_notas" class="form-control">
						<option value="0" <?= ($mostrar_notas == 0)?'selected':null ?>>NÃO</option>
						<option value="1" <?= ($mostrar_notas == 1)?'selected':null ?> >SIM</option>
					</select>
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Empresa CM</div>
					<input class="form-control" type="text" name="empresa_cm" id="search1" value="<?= $empresa_cm ?>" style="width:100px;" >
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Cliente</div>
					<input class="form-control" name="cliente" type="text" id="search2" value="<?= $cliente ?>" style="width:100px;" >
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Produto</div>
					<input class="form-control" name="produto" type="text" value="<?= $produto ?>" id="search3" style="width:100px;">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Dia Faturamento inicio</div>
					<input class="form-control" type="number" name="data_corte_de" id="search4" value = "<?= $dia_corte_ini; ?>" style="width:100px;" autocomplete="off">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Dia faturamento fim</div>
					<input class="form-control" type="number" name="data_corte_ate" id="search5" value = "<?= $dia_corte_fim; ?>" style="width:100px;" autocomplete="off">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<button type="submit" class="form-control btn-primary action" id="search" value="search"><i class="fa fa-search"></i></button>					
				</div>
			</div>
		</div>
	</div>
	</div>
	<br>
	<div class="row">
			<div class="col-md-12">
				<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
					<thead>
						<tr role="row">
							<th class="text-center">Empresa CM</th>
							<th class="text-center">Contrato</th>
							<th class="text-center">Status</th>
							<th class="text-center">Ispb</th>
							<th class="text-center">Cliente</th>
							<th class="text-center">Produto</th>
							<th class="text-center">Assinatura</th>
							<th class="text-center">Dia Corte</th>
							<th class="text-center">Taxa Inat.</th>
							<th class="text-center">Nf Automatica</th>
							<th class="text-center">Ação</th>
						</tr>
					</thead>
					<tbody>
						<?php if (isset($faturar_clientes) && is_array($faturar_clientes)){ ?>
							<?php foreach($faturar_clientes as $key => $value){?>
								<tr>
									<td class="text-left"><small class="label-status"><?= $value->razao_social_cm; ?></small></td>
									<td class="text-left"><small class="label-status"><a href="/contratos/detalhe/id/<?= $value->id_contrato;?>/" target="_blank"><?= $value->id_contrato; ?></a></small></td>
									<td class="text-left"><small class="label-status"><?= strtoupper($value->status_contrato); ?></small></td>
									<td class="text-left"><small class="label-status"><?= $value->codigo_cliente; ?></small></td>
									<td class="text-left"><small class="label-status"><?= $value->nome_fantasia; ?></small></td>
									<td class="text-left"><small class="label-status"><?= $value->nome_produto; ?></small></td>
									<td class="text-left"><small class="label-status"><?= convertDate( $value->data_assinatura ); ?></small></td>
									<td class="text-right"><small class="label-status"><?= $value->data_corte_faturamento; ?></small></td>
									<td class="text-right"><small class="label-status"><?= ($value->data_inicio_inatividade)?convertDate($value->data_inicio_inatividade):'-'; ?></small></td>
									<td class="text-right"><small class="label-status"><?= simNao($value->nf_automatica); ?></small></td>
									<td>
										<div class="pull-right">
											<a class="btn btn-info btn-xs" href="/faturamento/detalhe/<?= $value->id_contrato;?>/"><i class="fa fa-gear"></i> </span>Gerar Nota</a>
										</div>
									</td>
								</tr>
							<?php } ?>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	</form>
<!-- Modal -->
<div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h3 id="myModalLabel">Modal header</h3>
    </div>
    <div class="modal-body">
        <p>One fine body</p>
    </div>
    <div class="modal-footer">
        <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
        <button class="btn btn-primary">Save changes</button>
    </div>
</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- <script type="text/javascript" src="/libs/DataTables-1.10.13/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/dataTables.bootstrap.min.js"></script> -->
	<!-- <script type="text/javascript" src="/assets/js/form-behaviors.js"></script> -->
	<script type="text/javascript">
		$(function(){
			oTable = $('#list').DataTable({
				info: false,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				},
				select: true,
				dom: 'Bfrtip',
				lengthMenu: [
					[ 10, 25, 50, -1 ],
					[ '10 rows', '25 rows', '50 rows', 'Show all' ]
				],
				buttons: [
					{
						extend: 'pageLength',
						text: 'PAGINAS',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'print',
						text: 'PRINT',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'copyHtml5',
						text: 'COPY',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'excelHtml5',
						text: 'EXCEL',
						exportOptions: {
							columns: ':visible'
						}
					},
					{
						extend: 'pdfHtml5',
						text: 'PDF',
						exportOptions: {
							columns: ':visible'
							//columns: [ 0, 1, 2, 5 ]
						}
					},
					{
						extend: 'colvis',
						text: 'COLUNAS',
					},
				]
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
