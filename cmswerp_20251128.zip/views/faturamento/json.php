<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "notas-fiscais";
	</script>
	<!-- /PAGE STYLES -->
	<link href='/assets/css//fullcalendar.min.css' rel='stylesheet' type="text/css"/>
	<link href='/assets/css/fullcalendar.print.min.css' rel='stylesheet' type="text/css" media='print' />
	<script src='/assets/js/moment.min.js'></script>
	<script src='/assets/js/jquery.min.js'></script>
	<script src='/assets/js/fullcalendar.min.js'></script>
	<script src='/assets/js/locale/pt-br.js'></script>
	<script>
		$(function() {
			//var hoje = "<?= $this->data_hora_atual->format('Y-m-d'); ?>";
			$('#calendar').fullCalendar({
				header: {
					left: 'prev,next today',
					center: 'title',
					right: 'month,agendaWeek,agendaDay,listWeek'
				},
				//defaultDate: hoje,
				editable: true,
				buttonIcons: false,
				navLinks: true, // can click day/week names to navigate views
				eventLimit: true, // allow "more" link when too many events
				editable: true,
				events: {
					url: '/faturamento/listaCalendario/',
					error: function(e) {
						console.log(e);
						$('#script-warning').show();
					}
				},
				loading: function(bool) {
					$('#loading').toggle(bool);
				}
			});
		});

	</script>
	<style>

	body {
		margin: 0;
		padding: 0;
		font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;
		font-size: 14px;
	}

	#script-warning {
		display: none;
		background: #eee;
		border-bottom: 1px solid #ddd;
		padding: 0 10px;
		line-height: 40px;
		text-align: center;
		font-weight: bold;
		font-size: 12px;
		color: red;
	}

	#loading {
		display: none;
		position: absolute;
		top: 50px;
		right: 50px;
	}

	#calendar {
		max-width: 900px;
		margin: 5px auto;
		padding: 0 05px;
	}

</style>
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Faturamento</li>
		<li>Notas fiscais</li>
		<li>calendario</li>
	</ol>
	<h4 class="page-title"></h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<form action="/faturamento/savenf" method="post">
		<div class="row">
			<div class="col-sm-12 col-md-12">
				<div id='script-warning'>
					<code>php/get-events.php</code> must be running.
				</div>

				<div id='loading'>loading...</div>

				<div id='calendar'></div>
			</div>
		</div>
		</form>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
	<!-- /PAGE SCRIPTS -->
	<script>
		$('#voltar').click(function(event) {
			window.location.href="/faturamento/detalhenf/id/<?= $this->parametros[1];?>";
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>