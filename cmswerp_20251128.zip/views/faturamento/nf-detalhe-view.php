<!doctype html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]> <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]> <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
	<head>
		<?php include 'template/head-css.inc'; ?>

		<script type="text/javascript">
			var sidebarItem = "contas a receber";
		</script>

		<style>
			.panel-heading {
				background-color: #f5f5f5 !important;
				font-weight: bold;
			}
			.table th {
				background: #f7f7f7;
				width: 25%;
			}
			pre {
				background-color: #fafafa;
				border: 1px solid #ddd;
				padding: 10px;
				white-space: pre-wrap;
				word-wrap: break-word;
			}
			.action-buttons {
				margin: 20px 0;
				text-align: right;
			}
			.page-title {
				margin-bottom: 20px;
				font-weight: bold;
			}
		</style>
	</head>

	<body>
		<?php include "template/menu-wrapper.php"; ?>

		<div class="container-fluid">
			<ol class="breadcrumb">
				<li>Tarifas.cmsw.com</li>
				<li>Faturamento</li>
				<li>Notas fiscais</li>
				<li><?php echo $nota[0]->cliente; ?></li>
			</ol>
			<h4 class="page-title">Visualização da Nota Fiscal</h4>
		</div>
		<form action="/faturamento/editarnf/id/<?= $this->parametros[1]; ?>">
			<div class="container-fluid">

				<div class="panel panel-default">
					<div class="panel-heading">Prestador de Serviços</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-6">
								<p><strong><?php echo $nota[0]->prestador_servico; ?></strong></p>
								<p><?php echo $nota[0]->endereco_prestador; ?></p>
								<p><?php echo mask($nota[0]->cep_prestador, '#####-###').' - '.$nota[0]->municipio_prestador.' - '.$nota[0]->uf_prestador; ?></p>
								<p><?php echo 'CNPJ/CPF '.mask($nota[0]->cnpj_cpf_prestador, '##.###.###/####-##'); ?></p>
								<p>Email:</p>
							</div>
							<div class="col-md-6">
								<p><?php echo 'Inscrição estadual '.$nota[0]->inscricao_estadual_prestador; ?></p>
								<p>Telefone:</p>
							</div>
						</div>
					</div>
				</div>

				<div class="panel panel-info">
					<div class="panel-heading">Tomador de Serviços</div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-6">
								<p><strong><?php echo $nota[0]->cliente; ?></strong></p>
								<p><?php echo $nota[0]->endereco_cliente; ?></p>
								<p><?php echo 'CEP: '.mask($nota[0]->cep_cliente, '#####-###').' - '.$nota[0]->bairro_cliente; ?></p>
								<p><?php echo $nota[0]->municipio_cliente.' - '.$nota[0]->uf_cliente; ?></p>
							</div>
							<div class="col-md-6">
								<p><strong>CNPJ/CPF:</strong> <?php echo mask($nota[0]->cnpj_cpf_cliente, '##.###.###/####-##'); ?></p>
								<p><strong>Email:</strong> <?php echo $nota[0]->email_nf; ?></p>
								<p><strong>Contrato nº:</strong> <?php echo $nota[0]->id_contrato; ?></p>
								<p><strong>Código do Serviço:</strong> <?php echo $nota[0]->codigo_servico; ?></p>
							</div>
						</div>
					</div>
				</div>

				<div class="panel panel-success">
					<div class="panel-heading">Valores e Descrições</div>
					<div class="panel-body">
						<table class="table table-bordered">
							<tbody>
								<tr>
									<th>Total</th>
									<td><strong><?php echo number_format($nota[0]->valor_total, 2, ',', '.'); ?></strong></td>
								</tr>
								<tr>
									<th>Descrição da Nota</th>
									<td>
										<?php
										$descricao_nota = '';
										$arr_descricao_nota = explode('|', $nota[0]->descricao_nota);
										foreach ($arr_descricao_nota as $value) {
											if (!empty($value)) {
												$descricao_nota .= $value . "\n";
											}
										}
										?>
										<pre><?php echo $descricao_nota; ?></pre>
									</td>
								</tr>
								<tr>
									<th>Descrição do Serviço</th>
									<td>
										<?php
										$descricao_servico = '';
										$arr_descricao_servico = explode('|', $nota[0]->descricao_servico);
										foreach ($arr_descricao_servico as $value) {
											if (!empty($value)) {
												$descricao_servico .= $value . "\n";
											}
										}
										?>
										<pre><?php echo $descricao_servico; ?></pre>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>

				<!-- Botões de ação -->
				<div class="action-buttons">
					<?php
						if($nota[0]->status != 'recebido'){
							echo '<button type="submit" class="btn btn-primary" id="editar_contrato"><i class="fa fa-edit"></i> Editar</button>';
						}
					?>
					<button type="button" class="btn btn-warning" id="voltar">
						<i class="fa fa-arrow-left"></i> Voltar
					</button>

					<!-- <button type="button" class="btn btn-default" onclick="window.print();">
						<i class="fa fa-print"></i> Imprimir
					</button>

					<button type="button" class="btn btn-danger" onclick="window.location.href='/faturamento/gerarpdf/id/<?php echo $this->parametros[1]; ?>';">
						<i class="fa fa-file-pdf-o"></i> Exportar PDF
					</button> -->
				</div>
			</div>
		</form>

		<?php include "template/end-menu-wrapper.html"; ?>
		<?php include 'template/scripts.inc'; ?>

		<?php if (!empty($this->modelo->error)) { ?>
			<script type="text/javascript">
				$(function () {
					toastr.error('<?php echo $this->modelo->error; ?>');
				});
			</script>
		<?php } ?>

		<script type="text/javascript">
			$('#voltar').click(function() {
				window.location.href = "/faturamento/listarnf/";
			});
		</script>
	</body>
</html>