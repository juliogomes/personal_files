<!doctype html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>    <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>    <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
	<head>
		<?php include 'template/head-css.inc'; ?>
		<script type="text/javascript">
			var sidebarItem = "faturamento";
		</script>
	</head>
	<body>

		<?php include "template/menu-wrapper.php"; ?>

		<ol class="breadcrumb">
			<li>Tarifas.cmsw.com</li>
			<li>Faturamento</li>
			<li>Notas fiscais</li>
			<li><?php echo isset($nota[0]->cliente) ? $nota[0]->cliente : ''; ?></li>
		</ol>

		<div class="container-fluid">
			<form action="/faturamento/savenf" method="post" id="form_editnf">

				<!-- Prestador -->
				<div class="panel panel-default">
					<div class="panel-heading"><strong>Prestador de Serviços</strong></div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-8">
								<p>
									<?php echo $nota[0]->prestador_servico; ?><br>
									<?php echo $nota[0]->endereco_prestador; ?><br>
									<?php echo $nota[0]->cep_prestador . ' - ' . $nota[0]->municipio_prestador . ' - ' . $nota[0]->uf_prestador; ?><br>
									<?php echo 'CNPJ/CPF ' . $nota[0]->cnpj_cpf_prestador; ?><br>
								</p>
							</div>
							<div class="col-md-4">
								<p><?php echo 'Inscrição estadual ' . $nota[0]->inscricao_estadual_prestador; ?></p>
							</div>
						</div>
					</div>
				</div>

				<!-- Dados principais -->
				<div class="row">
					<div class="col-md-8">
						<div class="form-group">
							<label for="id_empresa">Empresa Vendedora</label>
							<select class="form-control" id="id_empresa" name="id_empresa">
								<?php if(isset($empresa_cm) && !empty($empresa_cm)) {
									foreach ($empresa_cm as $value) { ?>
										<option value="<?php echo $value->id; ?>" <?php echo ($value->razao_social == $nota[0]->prestador_servico) ? 'selected' : ''; ?>>
											<?php echo $value->razao_social; ?>
										</option>
								<?php } } ?>
							</select>
						</div>
					</div>

					<div class="col-md-4">
						<div class="form-group">
							<label for="data_emissao">Data Emissão</label>
							<input type="text" class="form-control datepast" id="data_emissao" name="data_emissao" autocomplete="off"
								value="<?php echo isset($nota[0]->data_emissao) ? convertDate($nota[0]->data_emissao) : ''; ?>">
						</div>
					</div>
				</div>

				<!-- Dados do Cliente -->
				<div class="panel panel-default">
					<div class="panel-heading"><strong>Dados do Cliente</strong></div>
					<div class="panel-body">
						<div class="row">
							<input type="hidden" name="id" value="<?php echo isset($nota[0]) ? $nota[0]->id : ''; ?>">

							<div class="col-md-6">
								<div class="form-group">
									<label for="cnpj_cpf_cliente">CNPJ Cliente</label>
									<input type="text" class="form-control masked" data-masked="00.000.000/0000-00"
										id="cnpj_cpf_cliente" name="cnpj_cpf_cliente"
										value="<?php echo isset($nota[0]) ? $nota[0]->cnpj_cpf_cliente : ''; ?>" required>
								</div>
							</div>

							<div class="col-md-6">
								<div class="form-group">
									<label for="cliente">Razão Social Cliente</label>
									<input type="text" class="form-control" id="cliente" name="cliente"
										value="<?php echo isset($nota[0]) ? $nota[0]->cliente : ''; ?>" required>
								</div>
							</div>

							<div class="col-md-8">
								<div class="form-group">
									<label for="endereco_cliente">Endereço</label>
									<input type="text" class="form-control" id="endereco_cliente" name="endereco_cliente"
										value="<?php echo isset($nota[0]) ? $nota[0]->endereco_cliente : ''; ?>" required>
								</div>
							</div>

							<div class="col-md-4">
								<div class="form-group">
									<label for="numero_cliente">Número</label>
									<input type="text" class="form-control" id="numero_cliente" name="numero_cliente"
										value="<?php echo isset($nota[0]) ? $nota[0]->numero_cliente : ''; ?>" required>
								</div>
							</div>

							<div class="col-md-6">
								<div class="form-group">
									<label for="bairro_cliente">Bairro</label>
									<input type="text" class="form-control" id="bairro_cliente" name="bairro_cliente"
										value="<?php echo isset($nota[0]) ? $nota[0]->bairro_cliente : ''; ?>" required>
								</div>
							</div>

							<div class="col-md-6">
								<div class="form-group">
									<label for="municipio_cliente">Município</label>
									<input type="text" class="form-control" id="municipio_cliente" name="municipio_cliente"
										value="<?php echo isset($nota[0]) ? $nota[0]->municipio_cliente : ''; ?>" required>
								</div>
							</div>

							<div class="col-md-4">
								<div class="form-group">
									<label for="uf_cliente">Estado</label>
									<input type="text" class="form-control" id="uf_cliente" name="uf_cliente"
										value="<?php echo isset($nota[0]) ? $nota[0]->uf_cliente : ''; ?>" required>
								</div>
							</div>

							<div class="col-md-4">
								<div class="form-group">
									<label for="cep_cliente">CEP</label>
									<input type="text" class="form-control masked" id="cep_cliente" name="cep_cliente"
										data-masked="00000-000"
										value="<?php echo isset($nota[0]) ? $nota[0]->cep_cliente : ''; ?>" required>
								</div>
							</div>

							<div class="col-md-4">
								<div class="form-group">
									<label for="email_nf">Email</label>
									<input type="text" class="form-control" id="email_nf" name="email_nf"
										value="<?php echo isset($nota[0]) ? $nota[0]->email_nf : ''; ?>" required>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- Prestador -->
				<div class="panel panel-default">
					<div class="panel-heading"><strong>Faturamento</strong></div>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-2">
								<div class="form-group">
									<label for="numero_fatura">Fatura</label>
									<input type="text" required class="form-control" id="numero_fatura" placeholder="12345678" value="<?php echo isset($nota[0])?$nota[0]->numero_fatura:null ?>" name="numero_fatura" />
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="data_vencimento">Vencimento</label>
									<input type="text" required class="form-control" id="data_vencimento" placeholder="dd/mm/YYYY" value="<?php echo isset($nota[0])?convertDate($nota[0]->data_vencimento):null ?>" name="data_vencimento" />
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="codigo_servico">Codigo de Serviço</label>
									<input type="text" required class="form-control" id="codigo_servico"  value="<?php echo isset($nota[0])?$nota[0]->codigo_servico:null ?>" name="codigo_servico" />
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="valor_fatura">Valor da fatura</label>
									<input type="text" required class="form-control mask-money" id="valor_fatura" value="<?php echo isset($nota[0])?$nota[0]->valor_fatura:null ?>" name="valor_fatura" />
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="valor_total">Valor total</label>
									<input type="text" required class="form-control mask-money" id="valor_total" value="<?php echo isset($nota[0])?$nota[0]->valor_total:null ?>" name="valor_total" />
								</div>
							</div>
							<div class="col-md-2">
								<div class="form-group">
									<label for="valor_impostos">Valor dos impostos</label>
									<input type="text" required class="form-control mask-money" id="valor_impostos"  value="<?php echo isset($nota[0])?$nota[0]->valor_impostos:null ?>" name="valor_impostos" />
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-2">
								<div class="form-group">
									<label for="valor_impostos_retidos">Impostos retidos</label>
									<input type="text" required class="form-control mask-money" id="valor_impostos_retidos" value="<?php echo isset($nota[0])?$nota[0]->valor_impostos_retidos:null ?>" name="valor_impostos_retidos" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="gerar_rps">Gerar RPS novamente?</label>
									<select  required class="form-control" id="gerar_rps" name="gerar_rps">
										<option value="1" <?= ($nota[0]->gerar_rps == 1)?'selected':null; ?>>SIM</option>
										<option value="0" <?= ($nota[0]->gerar_rps == 0)?'selected':null; ?>>NÃO</option>
									</select>
									<!-- <label for="status">Status</label>
									<input type="text" required class="form-control" id="status"  value="<?php echo isset($nota[0])?$nota[0]->status:null ?>" name="status" /> -->
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label for="numero_prefeitura">Numero na prefeitura</label>
									<input type="text" required class="form-control" id="numero_prefeitura"  value="<?php echo isset($nota[0])?$nota[0]->numero_prefeitura:null ?>" name="numero_prefeitura" />
								</div>
							</div>
							<div class="col-md-4">
								<div class="form-group">
									<label for="instrucao_pagamento_nome">Instruções de pagamento</label>
									<input type="text" required class="form-control" id="instrucao_pagamento_nome"  value="<?php echo isset($nota[0])?$nota[0]->instrucao_pagamento_nome:null ?>" name="instrucao_pagamento_nome" />
								</div>
							</div>
							<div class="col-md-2">
							</div>
							<div class="col-md-2">
							</div>
						</div>
					</div>
				</div>
				<!-- Descrição -->
				<div class="panel panel-default">
					<div class="panel-heading"><strong>Descrição</strong></div>
					<div class="panel-body">
						<div class="form-group">
							<label for="descricao_servico">Descrição do Serviço</label>
							<textarea class="form-control" id="descricao_servico" name="descricao_servico" rows="8" required><?php
								$arr_servico = explode('|', $nota[0]->descricao_servico);
								$descricao_ = '';
								foreach ($arr_servico as $v) { if (!empty($v)) $descricao_ .= $v . "\n"; }
								echo trim($descricao_);
							?></textarea>
						</div>

						<div class="form-group">
							<label for="descricao_nota">Descrição da Nota</label>
							<textarea class="form-control" id="descricao_nota" name="descricao_nota" rows="8" maxlength="1000" required><?php
								$arr_desc = explode('|', $nota[0]->descricao_nota);
								$descricao_nota = '';
								foreach ($arr_desc as $v) { if (!empty($v)) $descricao_nota .= $v . "\n"; }
								echo trim($descricao_nota);
							?></textarea>
							<span id="limitChart" style="<?php echo (isset($descricao_nota) && strlen($descricao_nota) === 1000) ? 'color:red' : ''; ?>">
								<?php echo isset($descricao_nota) ? strlen($descricao_nota) : 0; ?>
							</span>/1000
						</div>
					</div>
				</div>

				<!-- Ações -->
				<div class="text-center">
					<button type="button" id="btn_save" class="btn btn-primary"><i class="fa fa-save"></i> Gravar</button>
					<button type="button" class="btn btn-warning" id="voltar"><i class="fa fa-backward"></i> Voltar</button>
				</div>

			</form>
		</div>

		<?php include "template/end-menu-wrapper.html"; ?>
		<?php include 'template/scripts.inc'; ?>

		<?php if(!empty($this->modelo->error)){ ?>
		<script type="text/javascript">$(function(){ toastr.error('<?php echo $this->modelo->error; ?>'); });</script>
		<?php } ?>

		<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
		<script src="<?php echo HOME_URI.'libs/jquery-countable-master/jquery.countable.js'; ?>"></script>
		<script>
		$('#descricao_nota').on('keyup', function() {
			var count = $(this).val().length;
			$('#limitChart').html(count).css('color', count === 1000 ? 'red' : 'black');
		});
		$('.mask-money').maskMoney({allowNegative: false, thousands:'.', decimal:','}).each(function(){
			$(this).maskMoney('mask', $(this).val());
		});
		$('#btn_save').click(function(){ $('#form_editnf').submit(); });
		$('#voltar').click(function(){ window.location.href="/faturamento/detalhenf/id/<?php echo $this->parametros[1]; ?>"; });
		</script>
	</body>
</html>