<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "nota fiscal manual";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>nota fiscal manual</li>
	</ol>
	<h4 class="page-title">
		Nota fiscal Manual		
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-9 col-md-9">
				<form id="form" action="<?php echo HOME_URI.$this->module.'/previanfmanual/'; ?>" name="save" method="post">
					<div class="row">
						<div class="col-md-9">
							<div class="form-group">
								<label for="cliente">Cliente</label>
								<select name="cliente" id="cliente" class="form-control">
									<option>Selecione</option>
									<?php
										foreach ($clientes as $key => $value) {
									?>
											<option value = "<?= $value->codigo_cliente; ?>"><?= strtoupper($value->nome_fantasia); ?></option>
									<?php	
										}
									?>
								</select>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-md-9">
							<div class="form-group">
								<label for="empresa_cm">Empresa C&M</label>
								<select name="empresa_cm" id="empresa_cm" class="form-control">
									<option>Selecione</option>
									<?php
										foreach ($this->empresas_cm as $key => $value) {
									?>
											<option value = "<?= $value->id; ?>"><?= $value->razao_social; ?></option>
									<?php	
										}
									?>
								</select>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-9">
							<div class="form-group">
								<label for="periodo_de">Periodo De</label>
								<input type="text" name="periodo_de" id="periodo_de" class="form-control datepast" autocomplete="off" />
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-9">
							<div class="form-group">
								<label for="periodo_ate">Periodo Até</label>
								<input type="text" name="periodo_ate" id="periodo_ate" class="form-control datepast" autocomplete="off" />
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-9">
							<div class="form-group">
								<label for="data_vencimento">Data vencimento</label>
								<input type="text" name="data_vencimento" id="data_vencimento" class="form-control datepast" autocomplete="off" />
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-9">
							<div class="form-group">
								<label for="forma_pagamento">forma de pagamento</label>
								<select name="meio_pagamento" class="form-control" required class="form-control">
									<option value="boleto"> BOLETO </option>
									<option value="doc" >   DOC</option>
									<option value="ted">    TED</option>
								</select>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-9">
							<div class="form-group">
								<label for="forma_pagamento">forma de pagamento</label>
								<select name="id_conta_bancaria" class="form-control" required class="form-control">
								<?php
									foreach ($this->meios_recebimento as $chave => $valor) {
								?>
											<option value="<?= $valor->id; ?>" selected>
												<?= 'Banco: '.$valor->nome_reduzido.' Agencia '.$valor->numero_agencia.' - Conta corrente '.$valor->numero_conta.'-'.$valor->digito_conta; ?>
											</option>
								<?php
										}
								?>
								</select>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-9">
							<div class="form-group">
								<label for="produto">Produto</label>
								<select name="produto" id="produto" class="form-control">
									<option>Selecione o cliente primeiro</option>
								</select>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-9">
							<div class="form-group">
								<label for="produto">Modulo</label>
								<select name="modulo" id="modulo" class="form-control">
									<option>Selecione o produto primeiro </option>
								</select>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-9">
							<div class="form-group">
								<label for="tipo_lancamento">Tipo Lançamento</label>
								<select name="tipo_lancamento" id="tipo_lancamento" class="form-control">
									<option value="transacoes" >Transações</option>
									<option value="horas" >Horas</option>
									<option value="">Outros</option>
								</select>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-9">
							<div class="form-group">
								<label for="quantidade">Quantidade</label>
								<input type="text" name="quantidade" id="quantidade" class="form-control mask-number" value="1" />
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-9">
							<div class="form-group">
								<label for="valor">Valor</label>
								<input type="text" name="valor" id="valor" class="form-control mask-money" />
							</div>
						</div>
					</div>
<!-- 					<div class="row">
						<div class="col-md-9">
							<div class="form-group">
								<label for="descricao">Descricao da nota</label>
								<textarea name="descricao" id="descricao" class="form-control"></textarea>
							</div>
						</div>
					</div> -->
					<div class="row">
						<div class="col-md-9">
							<div class="form-group">
								<button type="button" id="add_lancamento" class="btn btn-primary form-control"><i class="fa fa-plus"></i> ADICIONAR LANÇAMENTO</button>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-9">
							<div class="form-group">
								<button type="submit" id="add_lancamento" class="btn btn-success form-control"><i class="fa fa-left"></i> VER PRÉVIA DA NOTA FISCAL</button>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-9">
							<div class="form-group" >
								<table class="table" width="100%">
									<thead>
										<tr>
											<td>Produto</td>
											<td>Modulo</td>
											<td>Quantidade</td>
											<td>Tipo lançamento</td>
											<td>valor</td>
										</tr>
									</thead>
									<tbody id="tb_lancamentos">
										
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$(function() {
			$('#produto').change(function(){
				var $item    = 'modulosbyproduto';
				var $id_item = $(this).val();
				var $str     = null;
				$.ajax({
			        url: '/wsrest.php/',
			        //datatype: 'json',
			        data: { item:$item, id_item: $id_item},
			        //contentType: 'application/json; charset=utf-8',
			        type: 'GET',
			        success: function (data) {
			        	//$('#contas_relacionadas').load('fornecedores-detalhe-view.php #contas_relacionadas');
			        	//var modulos = JSON.parse(data);
			        	//console.log(data.dados);
			        	//console.log(data);
			        	$str += '<option value="" selected >Selecione</option>';
			        	$.each(data.dados ,function(i, dados){
			        		//alert(i);
			        		$str += '<option value=' + dados.id_modulo + ' data-codigo='+dados.codigo_modulo+'>' + dados.nome_modulo + '</option>';
			        		console.log(dados);
			        	});
			        	$('#modulo').html($str);
			        },
			        error: function (error) {
			        }
				});
			});

			$('#cliente').change(function(){
				var $item    = 'produtosbycliente';
				var $id_item = $(this).val();
				var $str     = null;
				$.ajax({
			        url: '/wsrest.php/',
			        //datatype: 'json',
			        data: { item:$item, id_item: $id_item},
			        //contentType: 'application/json; charset=utf-8',
			        type: 'GET',
			        success: function (data) {
			        	//$('#contas_relacionadas').load('fornecedores-detalhe-view.php #contas_relacionadas');
			        	//var modulos = JSON.parse(data);
			        	//console.log(data.dados);
			        	//console.log(data);
			        	$str += '<option value="" selected >Selecione</option>';
			        	$.each(data.dados ,function(i, dados){
			        		//alert(i);
			        		$str += '<option value=' + dados.id + ' data-codigo='+dados.codigo+'>' + dados.nome + '</option>';
			        		console.log(dados);
			        	});
			        	$('#produto').html($str);
			        },
			        error: function (error) {
			        }
				});
			});

			$('#add_lancamento').click(function(){
		        if (typeof $count != 'undefined'){
		        	$count++;
		        }else{
		        	$count = 0;
		        }
		        $('#cliente option:not(:selected)').attr('disabled', true);
				$('#empresa_cm  option:not(:selected)').attr('disabled', true);
				$('#produto  option:not(:selected)').attr('disabled', true);
				$('#preco_com_imposto  option:not(:selected)').attr('disabled', true);

				var $str = null;
				var $produto_nome 	 = $('#produto option:selected').text();
				var $produto_codigo  = $('#produto').find(':selected').data('codigo');
				var $produto_id   	 = $('#produto').val();
				var $modulo_codigo   = $('#modulo').find(':selected').data('codigo');
				var $modulo_nome  	 = $('#modulo option:selected').text();
				var $modulo_id    	 = $('#modulo').val();
				var $tipo_lancamento = $('#tipo_lancamento').val();
				var $quantidade      = $('#quantidade').val();
				var $valor           = $('#valor').val();
				
				$('#tb_lancamentos').append('<tr>');
				$('#tb_lancamentos').append('<td><input type="hidden" name="produto['+$count+'][id]" value= "'+$produto_id+'" /><input type="hidden" name="produto['+$count+'][codigo]" value= "'+$produto_codigo+'" /><input type="text" name="produto['+$count+'][nome]" value= "'+$produto_nome+'" class="form-control" /></td>');
				$('#tb_lancamentos').append('<td><input type="hidden" name="modulo['+$count+'][id]" value= "'+$modulo_id+'" /><input type="hidden" name="modulo['+$count+'][codigo]" value= "'+$modulo_codigo+'" /><input type="text" name="modulo['+$count+'][nome]" value= "'+$modulo_nome+'" class="form-control" /></td>');
				$('#tb_lancamentos').append('<td><input type="text" name="quantidade['+$count+']" value= "'+$quantidade+'" class="form-control" /></td>');
				$('#tb_lancamentos').append('<td><input type="text" name="tipo_lancamento['+$count+']" value= "'+$tipo_lancamento+'" class="form-control" /></td>');
				$('#tb_lancamentos').append('<td><input type="text" name="valor['+$count+']" value= "'+$valor+'" class="form-control" /></td>');
				$('#tb_lancamentos').append('</tr>');

				$str = 'R$ '+$valor+' '+$modulo_nome+' referente a '+$quantidade+' '+$tipo_lancamento+'\n';
				$('#descricao').append($str);
				
			});

		});	
	</script>
<!-- /PAGE SCRIPTS -->
</body>
</html>