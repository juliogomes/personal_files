<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "contas-recebidas";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Contas a receber</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i>Contas recebidas</h4>
	<form class="form-inline page-toolbar" name="alterar_nf" method="post" action="">
	<div class="container-fluid">
	<div class="row">
	<div class="col-md-12">
		<div class="pull-left">
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">CNPJ</div>
					<input class="form-control" placeholder="00.000.000/0000-00" type="text" id="searchCNPJ" style="width:155px;" data-mask="00.000.000/0000-00">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Nome</div>
					<input class="form-control" placeholder="Empresa" type="text" id="searchName">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Produto</div>
					<input class="form-control" placeholder="Produto" type="text" id="searchProduto">
				</div>
			</div>
		</div>
	</div>
	</div>
	<br>
	<div class="row">
			<div class="col-md-12">
				<table id='list' class="table table-default table-striped table-bordered table-hover" >
					<thead>
						<tr role="row">
							<th class="text-center"></th>
							<th class="text-center">Empresa</th>
							<th class="text-center">Cliente</th>
							<th class="text-center">Produto</th>
							<th class="text-center">Ano referencia</th>
							<th class="text-center">Vencimento</th>
							<th class="text-center" width="60">Paga em</th>
							<th class="text-center">Valor</th>
							<th class="text-center"></th>
						</tr>
					</thead>
					<tbody>
						<?php if (is_array($dados)){ ?>
						<?php foreach($dados as $key => $value) {
							$totalizador += $value->valor_total;
						?>
						<tr>
							<td><input type="checkbox" name="contrato[<?= $value->id_contrato; ?>][id_contrato]" value="<?= $value->id_contrato; ?>"></td>
							<td class="text-left"><small class="label-status"><?= $value->prestador_servico; ?></small></td>
							<td class="text-left"><small class="label-status"accesskey=""><?= $value->cliente; ?></small></td>
							<td class="text-left"><small class="label-status"><?= $value->inf_adicionais[0]->nome_produto; ?></small></td>
							<td class="text-right"><small class="label-status"><?= $value->ano_mes_referencia; ?></small></td>
							<td class="text-right"><small class="label-status"><?= $value->data_vencimento; ?></small></td>
							<td class="text-right"><small class="label-status"><?= $value->recebido_em; ?></small></td>
							<td class="text-right"><small class="label-status"><?= number_format($value->valor_total, '2', ',', '.'); ?></small></td>
							<td>
								<div class="pull-right">
									<a class="btn btn-info btn-xs" href="/faturamento/detalhenf/id/<?= $value->id; ?>/"<i class="fa fa-edit"></i> </span> Detalhes</a>
								</div>
							</td>
						</tr>
						<?php } ?>
						<?php } ?>
						<tfoot>
							<tr>
							<td colspan="6" class="text-left"><strong>TOTAL</strong></td>
							<td colspan="3" class="text-center"><strong><?= number_format($totalizador, '2', ',', '.'); ?></strong></td>
							</tr>
						</tfoot>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	</form>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="/libs/DataTables-1.10.13/js/dataTables.bootstrap.min.js"></script>
	<script type="text/javascript">
		$(function() {
			oTable = $('#list').DataTable({
				info: false,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				}
			});
			$('#searchCodigo').keyup(function(){
				oTable
				.columns( 0 )
				.search( this.value )
				.draw();
			});
			$('#searchName').keyup(function(){
				oTable
				.columns( 2 )
				.search( this.value )
				.draw();
			});
			$('#searchCNPJ').keyup(function(){
				oTable
				.columns( 1 )
				.search( this.value )
				.draw();
			});
			$('#searchProduto').keyup(function(){
				oTable
				.columns( 3 )
				.search( this.value )
				.draw();
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
