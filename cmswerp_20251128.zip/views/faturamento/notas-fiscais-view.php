<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
	<!--<![endif]-->
	<head>
		<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
		<?php include 'template/head-css.inc' ?>
		<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
		<!-- PAGE STYLES -->
		<script type="text/javascript">
			var sidebarItem = "<?=$menu?>";
		</script>
		<!-- /PAGE STYLES -->
		 <style>
        /* --- ESTILO PERSONALIZADO --- */
        body { background-color: #f7f7f7; }
        .page-title {
            margin: 20px 0 10px;
            font-weight: 600;
            color: #333;
        }
        .page-toolbar {
            background: #fff;
            border-radius: 6px;
            padding: 15px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            margin-bottom: 20px;
        }
        .breadcrumb {
            background: #fff;
            border-radius: 4px;
            padding: 10px 15px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        table.table {
            background: #fff;
            border-radius: 4px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.08);
        }
        table.table th {
            background-color: #f0f3f5;
            color: #333;
            text-transform: uppercase;
            font-size: 12px;
        }
        table.table tfoot {
            background-color: #f8f8f8;
            font-weight: bold;
        }
        .form-group { margin-right: 10px; }
        .btn i { margin-right: 5px; }
        .modal-header { background: #f5f5f5; border-bottom: 1px solid #ddd; }
        .modal-footer { background: #f9f9f9; border-top: 1px solid #ddd; }
    </style>

	</head>
	<body>
		<!-- MENU + WRAPPER -->
		<?php include "template/menu-wrapper.php" ?>
		<!-- /MENU + WRAPPER -->
		<!-- HEADER -->
		<ol class="breadcrumb">
			<li>Tarifas.cmsw.com</li>
			<li>Contas a receber</li>
		</ol>
		<h4 class="page-title"><i class="fa fa-caret-right"></i>Contas a receber</h4>
		<form class="form-inline page-toolbar" id="alterar_nf" method="post" action="#">
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <div class="input-group">
                            <div class="input-group-addon">Tipo Data</div>
                            <select name="tipo_data" id="tipo_data" class="form-control">
                                <option value="emissao" <?= ($tipo_data == 'emissao')?'selected':null ?>>Emissão</option>
                                <option value="vencimento" <?= ($tipo_data == 'vencimento')?'selected':null ?>>Vencimento</option>
                                <option value="pagamento" <?= ($tipo_data == 'pagamento')?'selected':null ?>>Pagamento</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="input-group date">
                            <span class="input-group-addon">De <i class="fa fa-calendar"></i></span>
                            <input type="text" name="vencimento_de" id="vencimento_de" class="form-control datepast"
                                value="<?= $vencimento_de; ?>" size=8 autocomplete="off">
                        </div>
                        <div class="input-group date">
                            <span class="input-group-addon">Até <i class="fa fa-calendar"></i></span>
                            <input type="text" name="vencimento_ate" id="vencimento_ate" class="form-control datepast"
                                value="<?= $vencimento_ate; ?>" size=8 autocomplete="off">
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-calendar-check-o"></i></span>
                            <input type="text" class="form-control datepast" placeholder="Data pagamento"
                                name="dt_pagamento" id="dt_pagamento" autocomplete="off" required>
                        </div>
                    </div>

                    <div class="btn-group">
                        <button type="submit" name="status_nota" id="btn_cancelar" value="cancelar" class="btn btn-danger">
                            <i class="fa fa-times-circle"></i> Cancelar
                        </button>
                        <button type="button" id="btn_gerar_rps" class="btn btn-primary">
                            <i class="fa fa-file-text-o"></i> Gerar RPS
                        </button>
                        <button type="button" id="btn_gerar_invoice" class="btn btn-warning">
                            <i class="fa fa-file-invoice"></i> Invoice
                        </button>
                        <button type="submit" name="status_nota" id="btn_recebido" value="recebido" class="btn btn-info">
                            <i class="fa fa-check-circle"></i> Pagas?
                        </button>
                    </div>
                </div>
            </div>
			<div class="panel panel-default">
				<div class="panel-body">
					<table id="list" class="table table-striped table-bordered table-hover">
						<thead>
							<tr>
								<th><input type="checkbox" id="checkAll"></th>
								<th>ID</th>
								<th>Fatura</th>
								<th>Nro PF</th>
								<th>Contrato</th>
								<th>Empresa</th>
								<th>Cliente</th>
								<th>Produto</th>
								<th>Ano ref.</th>
								<th>Emissão</th>
								<th>Vencimento</th>
								<th>Recebimento</th>
								<th>Status</th>
								<th>R$ S/ Imp</th>
								<th>R$ Fatura</th>
								<th>R$ C/ Imp</th>
							</tr>
						</thead>
						<tbody>
							<?php if(is_array($dados)){ 
								$totalizador_liquido = 0;
								$totalizador_total   = 0;
								foreach($dados as $value){
									$data_vencimento = new dateTime($value->data_vencimento);
									$data_emissao = !empty($value->data_emissao) ? new dateTime($value->data_emissao) : null;
									$recebido_em = !empty($value->recebido_em) ? new dateTime($value->recebido_em) : null;
									$totalizador_liquido += $value->valor_fatura;
									$totalizador_total   += $value->valor_total;
							?>
							<tr>
								<td><input type="checkbox" name="nf[<?= $value->id; ?>][id_nf]" value="<?= $value->id; ?>"></td>
								<td><a href="/faturamento/detalhenf/id/<?= $value->id;?>/" target="_blank"><?= $value->id; ?></a></td>
								<td><?= $value->numero_fatura; ?></td>
								<td><?= $value->numero_prefeitura; ?></td>
								<td><a href="/contratos/detalhe/id/<?= $value->id_contrato;?>/" target="_blank"><?= $value->id_contrato; ?></a></td>
								<td><?= $value->prestador_servico; ?></td>
								<td><?= $value->cliente; ?></td>
								<td><a href="/produtos/detalhe/id/<?= $value->id_produto;?>/" target="_blank"><?= $value->codigo_produto; ?></a></td>
								<td class="text-right"><?= $value->ano_mes_referencia; ?></td>
								<td><?= (!empty($data_emissao))?$data_emissao->format('d/m/Y'):'-'; ?></td>
								<td><?= $data_vencimento->format('d/m/Y'); ?></td>
								<td><?= (!empty($recebido_em))?$recebido_em->format('d/m/Y'):'-'; ?></td>
								<td><?= $value->status_nf ?></td>
								<?php if($value->valor_liquido > 0){ ?>
										<td class="text-right"><small class="label-status"><?= number_format($value->valor_liquido, '2', ',', '.'); ?></small></td>
								<?php }else{ ?>
										<td class="text-right"><small class="label-status"><?= number_format($value->valor_fatura, '2', ',', '.'); ?></small></td>
								<?php } ?>
								<td class="text-right"><?= number_format($value->valor_fatura, 2, ',', '.'); ?></td>
								<td class="text-right"><?= number_format($value->valor_total, 2, ',', '.'); ?></td>
							</tr>
							<?php } } ?>
						</tbody>
						<tfoot>
							<tr>
								<td colspan="14" class="text-right"><strong>Total Geral</strong></td>
								<td class="text-right"><strong><?= (isset($totalizador_liquido))?number_format($totalizador_liquido, 2, ',', '.'):number_format(0, 2, ',', '.'); ?></strong></td>
								<td class="text-right"><strong><?= (isset($totalizador_total))?number_format($totalizador_total, 2, ',', '.'):number_format(0, 2, ',', '.'); ?></strong></td>
							</tr>
						</tfoot>
					</table>
				</div>
			</div>
        </form>
		<!-- /.container-fluid -->
		<!-- /CONTENT -->
		<!-- END WRAPPER -->
		<?php include "template/end-menu-wrapper.html" ?>
		<!-- /END WRAPPER -->
		<!-- MODALS -->
		<div class="modal fade" tabindex="-1" role="dialog" id="statusModal">
			<div class="modal-dialog " role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4><span class="modal-title">Informe usuario e senha para cancelar a(s) nota(s)</span></h4>
					</div>
					<div class="modal-body">
						<div id="mensagem"></div>
						<div id="senha">
								<div class="form-group">
									<label for="email_aprovacao">Email</label>
									<input type="email" class="form-control" id="email_aprovacao" aria-describedby="emailHelp" placeholder="xxx@xx" />
									<small class="form-text text-muted">Digite o email para aprovar as despesas</small>
								</div>	
								<div class="form-group">
									<label for="senha_aprovacao">Senha</label>
									<input type="password" class="form-control" id="senha_aprovacao" aria-describedby="emailHelp" />
									<small class="form-text text-muted">Digite a senha para aprovar as despesas </small>
								</div>
								<button type="button" id="btn-cancelar" class="form-control btn btn-success" value="cancelar">Tem certeza que quer cancelar?</button>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
					</div>
				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>
		<!-- /.modal -->
		<!-- INCLUDE DEFAULT SCRIPTS -->
		<?php include 'template/scripts.inc' ?>
		<?php include "template/modal_sistema.php" ?>
		<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
		<!-- /INCLUDE DEFAULT SCRIPTS -->
		<!-- PAGE SCRIPTS -->
		<script type="text/javascript">
			var $url = '/faturamento/listarnf/';
			$('[name="status_nota"]').click(function(Event){
				Event.preventDefault();
				if($(this).val() == 'cancelar'){
					$("#statusModal").on("shown.bs.modal", function (){}).modal('show');
				}
			});

			$('#btn-cancelar').click(function(){
				var dados_form = oTable.$('input[type="checkbox"]').serialize();
				var data_acao  = $('#dt_pagamento').val();
				var acao = $(this).val();
				console.log(dados_form);
				console.log(data_acao);
				console.log(acao);
				$.ajax({
					url: '/faturamento/processarnf/',
			        data: dados_form+'&acao='+acao+'&data_acao='+data_acao+'&senha_aprovacao='+$('#senha_aprovacao').val()+'&email_aprovacao='+$('#email_aprovacao').val(),
			        type: 'POST',
			        success: function (data){
						console.log(data);
			        	var obj_json = JSON.parse(data);
						var modal = $("#statusModal");
						if(obj_json.codigo == 0){
							$('#painel_success_msg').text(obj_json.mensagem);
							$('#modal_sucesso_sistema').modal('show');
							$('#modal_sucesso_sistema').on('hidden.bs.modal', function () {
								location.reload();
							});
						}else{
							$('#painel_error_msg').text(obj_json.mensagem);
							$('#modal_erro_sistema').modal('show');
						}
			        },
			        error: function (error){	
						console.log(error);
						alert(error);
			        }
				});
			});

			$('#btn_recebido').click(function(){
				var dados_form = oTable.$('input[type="checkbox"]').serialize();
				var data_acao  = $('#dt_pagamento').val();
				var acao = $(this).val();
				// console.log(dados_form);
				// console.log(data_acao);
				// console.log(acao);
				$.ajax({
			        url: '/faturamento/processarnf/',
			        data: dados_form+'&acao='+acao+'&data_acao='+data_acao+'&senha_aprovacao='+$('#senha_aprovacao').val()+'&email_aprovacao='+$('#email_aprovacao').val(),
			        type: 'POST',
			        beforeSend: function() {
						// setting a timeout
						waitingDialog.show('PROCESSANDO...');
					},
					success: function (data){
						waitingDialog.hide();
			        	var obj_json = JSON.parse(data);
						console.log(obj_json);
						if(obj_json.codigo == 0){
							$('#painel_success_msg').text('Ação executada com sucesso');
							$('#modal_sucesso_sistema').modal('show');
							$('#modal_sucesso_sistema').on('hidden.bs.modal', function () {
								location.reload();
							});
						}else{
							console.log(obj_json.processo)
							var mensagem_alerta = '';
							if(obj_json.processo == undefined && obj_json.processo != ''){
								mensagem_alerta = obj_json.mensagem;
							}else{
								$.each(obj_json.processo, function(key, value){
									mensagem_alerta += "<p><b>"+value.mensagem+"</b></p>";
								});
							}
							$('#painel_error_msg').text(mensagem_alerta);
							$('#modal_erro_sistema').modal('show');
						}
			        },
			        error: function (error){	
						$('#painel_error_msg').text(error);
						$('#modal_erro_sistema').modal('show');
			        }
				});
			});

			$('#btn_gerar_rps').click(function(){
			   $('#alterar_nf').attr( 'action', '/faturamento/gerar_rps/' );
			   $('#alterar_nf').submit();
			});

			$('#btn_gerar_invoice').click(function() {
    			var dados_form = oTable.$('input[type="checkbox"]').serialize();
    			$.ajax({
    				url: '/faturamento/gerar_invoice/',
    				data: dados_form,
    				type: 'POST',
    				beforeSend: function() {
    					// setting a timeout
    					waitingDialog.show('PROCESSANDO...');
    				},
    				success: function(data) {
    					waitingDialog.hide();
    					var obj_json = JSON.parse(data);
    					if (obj_json.codigo == 0) {
    						$('#painel_success_msg').text(obj_json.mensagem);
    						$('#modal_sucesso_sistema').modal('show');
    					} else {
    						$('#painel_error_msg').text(obj_json.mensagem);
    						$('#modal_erro_sistema').modal('show');
    					}
    				},
    				error: function(error) {
    					$('#painel_error_msg').text(error);
    					$('#modal_erro_sistema').modal('show');
    				}
    			});
    		});

			$('#btn_gerar_boleto').click(function(){
			   $('#alterar_nf').attr('action', '/boletos/gerar/');
			   $('#alterar_nf').submit();
			});

			$("#checkAll").click(function(){
			    $('input:checkbox').not(this).prop('checked', this.checked);
			});

			$(function() {
				oTable = $('#list').DataTable({
					info: false,
					responsive: true,
					autoFill: true,
					dom: "<'panel panel-default'" +
					"tr" +
					"<'panel-footer'" +
					"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
					">" +
					">",
					language: {
						"decimal": ",",
            			"thousands": ".",
						"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
					},
					select: true,
					dom: 'Bfrtip',
					lengthMenu: [
						[ 10, 25, 50, -1 ],
						[ '10 rows', '25 rows', '50 rows', 'Show all' ]
					],
					buttons: [
						{
							extend: 'pageLength',
							text: 'PAGINAS',
							exportOptions: {
								columns: [ 0, ':visible' ]
							}
						},
						{
							extend: 'print',
							text: 'PRINT',
							exportOptions: {
								columns: [ 0, ':visible' ]
							}
						},
						{
							extend: 'copyHtml5',
							text: 'COPY',
							exportOptions: {
								columns: [ 0, ':visible' ]
							}
						},
						// {
						// 	extend: 'excelHtml5',
						// 	text: 'EXCEL',
						// 	charset: 'utf-8',
						// 	sheetName: 'Exported data',
						// 	bom: true,
						// 	exportOptions: {
						// 		//columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 11, 12, 13 ] // para quando quiser fixar as colunas a serem importadas
						// 		columns: ':visible',
						// 	},
						// },
						{
							extend: 'csvHtml5',
							text: 'CSV',
							charset: 'utf-8',
							bom: true,
							fieldSeparator: ';',
							exportOptions: {
								//columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 11, 12, 13 ] // para quando quiser fixar as colunas a serem importadas
								columns: ':visible'
							}
						},
						// {
						// 	extend: 'csvHtml5',
						// 	text: 'EXCEL',
						// 	charset: 'utf-8',
						// 	fieldSeparator: ';',
						// 	bom: true,
						// 	exportOptions: {
						// 		columns: ':visible'
						// 	}
						// },
						{
							extend: 'pdfHtml5',
							text: 'PDF',
							exportOptions: {
								columns: ':visible'
								//columns: [ 0, 1, 2, 5 ]
							}
						},
						{
							extend: 'colvis',
							text: 'COLUNAS',
						},
					]
				});
				
				oTable.buttons().container().appendTo('#list_wrapper .col-sm-6:eq(0)');
				
				$('#vencimento_ate').change(function(){
					$('#alterar_nf').attr('action', $url).submit();
				});

				$('#status').change(function(){
					$('#alterar_nf').attr('action', $url).submit();
				});

				$('#gerar_rps').change(function(){
					$('#alterar_nf').attr('action', $url).submit();
				});				
			});
		</script>
		<!-- /PAGE SCRIPTS -->
	</body>
</html>
