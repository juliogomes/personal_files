<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "faturamento";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Faturamento</li>
		<li>Notas fiscais</li>
		<li><?= $cliente[0]->nome_fantasia; ?></li>
	</ol>
	<h4 class="page-title"></h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<form class="form-inline page-toolbar" id="gerar_nf" name="gerar_nf" method="post" action="#">
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-12 col-md-12">
					<div class="form-group">
						<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
							<tbody>
								<tr>
									<td colspan="12">Prestador de serviços</td>
								</tr>
								<tr>
									<td colspan="6">
										<?= $empresa_cm[0]->razao_social; ?><br>
										<?= $empresa_cm[0]->endereco; ?><br>
										<?= $empresa_cm[0]->cep.' - '.$empresa_cm[0]->cidade.' - '.$empresa_cm[0]->estado ?><br>
									</td>
									<td colspan="6">
										<?= 'CNPJ/CPF '.mask($empresa_cm[0]->cnpj, '##.###.###/####-##'); ?><br>
											Inscrição estadual:  <?= ( !empty( $empresa_cm[0]->inscricao_estadual ) )?$empresa_cm[0]->inscricao_estadual:'isento'; ?><br>
											Inscrição municipal: <?= ( !empty( $empresa_cm[0]->inscricao_municipal ) )?$empresa_cm[0]->inscricao_municipal:'isento'; ?><br>
									</td>
								</tr>
								<tr>
									<td colspan="6">Tomador de serviços</td>
									<td colspan="6">CNPJ/CPF</td>
								</tr>
								<tr>
									<td colspan="6"><?= $cliente[0]->nome_fantasia; ?></td>
									<td colspan="6"><?= mask($cliente[0]->cnpj, '##.###.###/####-##'); ?></td>
								</tr>
								<tr>
									<td colspan="1">Endereço</td>
									<td colspan="11"><?= $cliente[0]->endereco.', '.$cliente[0]->numero; ?></td>
								</tr>
								<tr>
									<td colspan="6">
										<?= 'CEP: '.$cliente[0]->cep.' - '.$cliente[0]->bairro; ?>
									</td>
									<td colspan="6">
										<?=  $cliente[0]->cidade.' - '.$cliente[0]->estado; ?><br>
									</td>
								</tr>
								<tr>
									<td colspan="12">Email:
										<?= $cliente[0]->email_nf; ?><br>
									</td>
								</tr>
								<tr>
									
									<td colspan=2 class="text-left"><b>MODULO</b></td>
									<td class="text-right"><b>QUANTIDADE</b></td>
									<td class="text-right"><b>TIPO</b></td>
									<td colspan=2 class="text-right"><b>VALOR SEM IMPOSTO</b></td>
									<td class="text-right"><b>IMPOSTO</b></td>
									<td class="text-right"><b>VALOR COM IMPOSTO</b></td>
								</tr>
								<?php
									foreach($nf->modulo as $key => $value){
											$descricao_lancamento .= $value->nome_modulo.' R$ '.number_format($value->valor_total,'2',',','.').' referente a '.$value->qtd_transacoes.' '.$value->tipo_lancamento."\n";
								?>
										<tr>
											<td colspan=2 class="text-left"><?= $value->nome_modulo; ?></td>
											<td class="text-right"><?= $value->qtd_transacoes; ?></td>
											<td class="text-right"><?= $value->tipo_lancamento; ?></td>
											<td colspan=2 class="text-right"><?= number_format($value->valor_liquido,'2',',','.'); ?></td>
											<td class="text-right"><?= number_format($value->impostos->semretencao->total,'2',',','.'); ?></td>
											<td class="text-right"><?= number_format($value->valor_total,'2',',','.'); ?></td>
										</tr>
								<?php
										}
								?>
								<tr>
									<td colspan="2"><b>TOTAL</b></td>
									<td colspan="2" class="text-right"><b> - </b></td>
									<td colspan=2 class="text-right"><b><?= number_format($nf->valor_fatura,'2',',','.'); ?></b></td>
									<td class="text-right"><b><?= number_format($nf->valor_impostos,'2',',','.'); ?></b></td>
									<td class="text-right"><b><?= number_format($nf->valor_total,'2',',','.'); ?></b></td>
								</tr>
								<tr>
									<td colspan="12"></td>
								</tr>
								<tr>
									<td colspan="2">
										<b>CODIGO DO SERVIÇO: </b><?= $nf->codigo_servico; ?>
									</td>
									<td colspan="10">
										<b>DESCRICAO DO SERVIÇO: </b><?= $nf->descricao_servico; ?>
									</td>
								</tr>
								<tr>
									<td colspan="12">
										VENCIMENTO EM <b><?= $_POST['data_vencimento']; ?></b>
									</td>
								</tr>
								<tr>
									<td colspan="12"><b>FORMA DE PAGAMENTO</b></td>
								</tr>
								<tr>
									<td class="text-left" colspan="12">
										<?= (isset($descricao_pagamento))?$descricao_pagamento:null; ?>
									</td>
								</tr>
								<tr>
									<td colspan="12"><b>IMPOSTOS</b></td>
								</tr>
									<?php if(isset($nf->impostos)){ ?>
										<?php foreach ($nf->impostos as $key => $value){ ?>
											<tr>
												<td colspan="03">IRPF SOBRE A NOTA</td>
												<td colspan="03"><?= number_format($value->totalizadores->semretencao->IRPF,'2',',','.'); ?></td>
												<td>IRPF RETIDO</td>
												<td colspan="03"><?= number_format($value->totalizadores->comretencao->IRPF,'2',',','.'); ?></td>
											</tr>
											<tr>
												<td colspan="03">CSLL SOBRE A NOTA</td>
												<td colspan="03"><?= number_format($value->totalizadores->semretencao->CSLL,'2',',','.'); ?></td>
												<td>CSLL RETIDO</td>
												<td colspan="03"><?= number_format($value->totalizadores->comretencao->CSLL,'2',',','.'); ?></td>
											</tr>
											<tr>
												<td colspan="03">COFINS SOBRE A NOTA</td>
												<td colspan="03"><?= number_format($value->totalizadores->semretencao->COFINS,'2',',','.'); ?></td>
												<td>COFINS RETIDO</td>
												<td colspan="03"><?= number_format($value->totalizadores->comretencao->COFINS,'2',',','.'); ?></td>
											</tr>
											<tr>
												<td colspan="03">PIS/PASEP SOBRE A NOTA</td>
												<td colspan="03"><?= number_format($value->totalizadores->semretencao->PISPASEP,'2',',','.'); ?></td>
												<td>PISPASEP RETIDO</td>
												<td colspan="03"><?= number_format($value->totalizadores->comretencao->PISPASEP,'2',',','.'); ?></td>
											</tr>
											<tr>
												<td>TOTAL</td>
												<td colspan="11"><?= number_format($value->totalizadores->semretencao->total,'2',',','.'); ?></td>
											</tr>
										<?php } ?>
									<?php } ?>
								<tr>
									<td colspan="12"><b>DESCRIÇÃO DA NOTA FISCAL</b></td>
								</tr>
								<tr>
									<td class="text-left" colspan="12" >
										<textarea name="descricao_nota" id="descricao_nota" class="form-control col-xs-12" rows="5" style="min-width: 100%"><?= $descricao_inicial.$descricao_nota.$descricao_lancamento.$descricao_pagamento.$descricao_imposto; ?></textarea>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<button type="button" id = "btn_gerar_nf" name = "btn_gerar_nf" value = "gerar_nf" class="btn btn-success">Gerar Nota</button>
		<button type="button" id = "voltar" class="btn btn-primary">Voltar</button>
	</form>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
		<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalTitle" aria-hidden="true">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      	<div class="modal-header">
				<h4 class="modal-title" id="myModalLabel">Resposta do servidor</h4>
			</div>
	      	<div class="modal-body">
	      		<strong></strong>
	      	</div>
	    <div class="modal-footer">
	    	<input type="hidden" name="id_nf" id="id_nf" />
	        <button type="button" id="gerar_nota" class="btn btn-info" data-dismiss="modal" >GERAR NOVA NOTA?</button>
	        <button type="button" id="gerar_rps" class="btn btn-success" data-dismiss="modal" >GERAR RPS?</button>
	    	<button type="button" id="ir_contas_receber" class="btn btn-primary" >IR PARA CONTAS A RECEBER?</button>
	    </div>
	    </div>
	  </div>
	</div>
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<!-- /PAGE SCRIPTS -->
	<script>
		$('.mask-money').maskMoney({allowNegative: false, thousands:'.', decimal:','});
		$('.mask-money').each(function(){ // function to apply mask on load!
		    $(this).maskMoney('mask', $(this).val());
		})
		$('.campo_data').mask('00/00/0000', {
			onComplete: function(value, event, field) {
			oTable
				.columns( 5 )
				.search( value )
				.draw();
			}
		}).datepicker({
			format: "dd/mm/yyyy",
			clearBtn: true,
			language: "pt-BR",
			autoclose: true,
			todayBtn: "linked",
			todayHighlight: true
		});
		
		$('#gerar_rps').click(function(){
			var $id_nf = $('#id_nf').val();
			window.location.href = "/faturamento/gerarrps/id_nf/"+$id_nf;
		});

		$('#gerar_nota').click(function(){
			var $id_nf = $('#id_nf').val();
			window.location.href = "/faturamento/nfmanual/";
		});

		$('#ir_contas_receber').click(function(){
			window.location.href = "/faturamento/listarnf/filter/status/receber/";
		});		

		$('#voltar').click(function(){
			window.location.href = "/faturamento/listar";
		});

		$('#btn_gerar_nf').click(function(){
			$("#btn_gerar_nf").attr("disabled", "disabled");
			var dados          = '<?= json_encode($nf); ?>';
			var $descricao_nota = $('#descricao_nota').val();
			console.log(dados);
			$.ajax({
		        url: '/faturamento/gerarnfmanual/',
		        //datatype: 'json',
		        //contentType: 'application/json; charset=utf-8',
		        data: { dados:dados, descricao_nota:$descricao_nota},
		        type: 'POST',
		        success: function (data){
		        	var $retorno = JSON.parse(data);
		        	console.log($retorno);
		        	$('.modal-body').addClass('label-status');
		        	if($retorno.type == 'success'){
		        		$('#id_nf').val($retorno.dados);
		        		$('.modal-body').addClass('alert alert-success');
		        	}else if($retorno.type == 'warning'){
						$('.modal-body').addClass('alert alert-warning');
		        	}else if($retorno.type == 'danger'){
		        		$('.modal-body').addClass('alert alert-danger');
		        	}
		        	$('.modal-body strong').html($retorno.message);
					$("#myModal").modal("show");		        	
		        },
		        error: function (error){
		        	console.log(error);
		        }				
			});			
		})
	</script>
</body>
</html>