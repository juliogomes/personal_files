<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "faturamento";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Faturamento</li>
		<li>Notas fiscais</li>
		<li><?= $dados->contrato->nome_fantasia; ?></li>
	</ol>
	<h4 class="page-title"></h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<form class="form-inline page-toolbar" id="gerar_nf" name="gerar_nf" method="post" action="/faturamento/gerarnf/<?= $dados->contrato->tipo; ?>">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 col-md-12">
			<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
				<tbody>
					<tr>
						<td colspan="6">Prestador de serviços</td>
					</tr>
					<tr>
						<td colspan="4">
							<?= $dados->contrato->razao_social_cm; ?><br>
							<?= $dados->contrato->endereco_cm; ?><br>
							<?= $dados->contrato->cep_cm.' - '.$dados->contrato->cidade_cm.' - '.$dados->contrato->estado_cm ?><br>
						</td>
						<td colspan="2">
								<?= 'CNPJ/CPF '.mask($dados->contrato->cnpj_cm, '##.###.###/####-##'); ?><br>
								<?= 'Inscrição estadual '.$dados->contrato->inscricao_estadual_cm; ?><br>
						</td>
					</tr>
					<tr>
						<td colspan="4">Tomador de serviços</td>
						<td colspan="2">CNPJ/CPF</td>
					</tr>
					<tr>
						<td colspan="4"><?= $dados->contrato->nome_fantasia; ?></td>
						<td colspan="2"><?= mask($dados->contrato->cnpj, '##.###.###/####-##'); ?></td>
					</tr>
					<tr>
						<td colspan="1">Endereço</td>
						<td colspan="6"><?= $dados->contrato->endereco.', '.$dados->contrato->numero; ?></td>
					</tr>
					<tr>
						<td colspan="5">
							<?= 'CEP: '.$dados->contrato->cep.' - '.$dados->contrato->bairro; ?>
						</td>
						<td>
							<?=  $dados->contrato->cidade.' - '.$dados->contrato->estado; ?><br>
						</td>
					</tr>
					<tr>
						<td colspan="6">Email:
							<?= $dados->contrato->email_nf; ?><br>
						</td>
					</tr>
					<tr>
						<td>Serviço</td>
						<td>Pacote</td>
						<td>Quantidade</td>
						<td>Valor</td>
						<td>Valor Imposto</td>
						<td>Valor Total</td>
					</tr>
					<?php
						foreach ($dados->faturamento as $key => $value) {
							$quantidade_total += $value->qtd_transacoes;
							$total_liquido 	+= $value->valor_total;
							$total_impostos += $value->impostos->total_incidente;
							$total_bruto    += ($value->valor_total + $value->impostos->total_incidente);
					?>
					<tr>
						<td><?= $value->nome_modulo; ?></td>
						<td><?= ($value->pct_excedido == 1)?'NÃO':'SIM'; ?></td>
						<td><?= $value->qtd_transacoes; ?></td>
						<td><?= number_format($value->valor_total, '2', ',', '.'); ?></td>
						<td><?= number_format($value->impostos->total_incidente, '2', ',', '.'); ?></td>
						<td><?= number_format(($value->valor_total+$value->impostos->total_incidente), '2', ',', '.'); ?></td>
					</tr>
					<?php
						}
					?>
					<tr>
						<td colspan="2"><b>TOTAL</b></td>
						<td><b><?= $quantidade_total; ?></b></td>
						<td><b><?= number_format($total_liquido, '2', ',', '.'); ?></b></td>
						<td><b><?= number_format($total_impostos, '2', ',', '.'); ?></b></td>
						<td><b><?= number_format($total_bruto, '2', ',', '.'); ?></b></td>
					</tr>
					<tr>
					</tr>
					<tr>
						<td colspan="6"><b>VENCIMENTO EM</b></td>
					</tr>
					<tr>
						<td colspan="6"><input type="text" name="data_vencimento" value="<?= $dados->data_vencimento ?>" /></td>
					</tr>
					<tr>
						<td colspan="6"><b>PERIODO DE FATURAMENTO</b></td>
					</tr>
					<tr>
						<td colspan="6">
							De: <input type="text" name="periodo_de" value="<?= $dados->periodo_de ?>" />
							Até: <input type="text" name="periodo_ate" value="<?= $dados->periodo_ate ?>" />
						</td>
					</tr>
					<tr>
						<td colspan="6"><b>DESCONTOS</b></td>
					</tr>
					<tr>
						<td colspan="6">
							Tipo desconto:
							<select name="tipo_desconto">
								<option value="percentual">Porcento</option>
								<option value="percentual">Valor</option>
							</select>
							Valor do desconto:
							<input type="text" name="valor_desconto" />
						</td>
					</tr>
					<tr>
						<td colspan="6"><b>FORMA DE PAGAMENTO</b></td>
					</tr>
					<tr>
						<td class="text-left" colspan="7">
							<select name="id_meio_pagamento" class="form-control" required >
							<?php
								foreach ($this->meios_recebimento as $chave => $valor) {
							?>
								<option value="<?= $valor->id; ?>"><?= $valor->descricao; ?></option>
							<?php
								}
							?>
							</select>
						</td>
					</tr>
				</tbody>
			</table>
			</div>
		</div>
	</div>
	<input type="text" name="id_contrato" value="<?= $value->id_contrato; ?>"> <br>
	<button type="submit" id = "btn_processar" name = "btn_processar" value = "processar" class="btn btn-success">Processar</button>
		<button type="button" id = "voltar" class="btn btn-primary">Voltar</button>
	</form>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
	<!-- /Error Toaatr -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<!-- /PAGE SCRIPTS -->
	<script>
		$('#voltar').click(function(){
			window.location.href = "/faturamento/listar";
		});

		$("[name='cancelar_nota']").click(function(){
			$('#gerar_nf').attr({
				action: '/faturamento/alterarStatusFaturamento'
			}).submit();
		});
	</script>
</body>
</html>