<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "arquivos rps";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Mensagens</li>
		<li>Lista</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i>Arquivos RPS</h4>
	<form class="form-inline page-toolbar" id='listar_rps' name="listar_rps" method="post" action="/faturamento/listarrps/">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="pull-left">
						<div class="form-group">
							<div class="input-group">
								<div class="input-group-addon">Prestador</div>
								<select name="empresas_cm" id = "sl_empresa_cm" class="form-control">
									<option value="">Todas</option>
									<?php foreach ($empresas_cm as $key => $value){ ?>
										<option value="<?= $value->cnpj; ?>" <?= ($value->cnpj == $cnpj_cm)?'selected':'null' ?> ><?= $value->razao_social; ?></option>
									<?php } ?>
								</select>
							</div>
						</div>
						<div class="form-group">
							<div class="input-group date">
								<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
								<input type="text" class="form-control datepast" value = "<?= $data_criacao->format('d/m/Y'); ?>" name="data_criacao" id="data_criacao">
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">
								<button type="button" class="action btn btn-warning" value="validar">VALIDAR RPS</button>
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">
								<button type="button" class="action btn btn-success" name="btn_enviar_nfe" value="enviar">ENVIAR NFE</button>
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">
								<button type="button" class="action btn btn-danger" name="btn_update_status" value="update_status">UPDATE STATUS</button>
							</div>
						</div>
					</div>
				</div>
			</div>
			<br>
			<div class="row"><div class="col-md-12"><div class="pull-left"></div></div>
			<div class="row">
				<div class="col-md-12">
					<table id='list' class="table table-default table-striped table-bordered table-hover" >
						<thead>
							<tr role="row">
								<th class="text-center"><label><input class='check_all' type="checkbox"></label></th>
								<th class="text-center">Prestador</th>
								<th class="text-center">Remessa</th>
								<th class="text-center">Referencia</th>
								<th class="text-center">Data</th>
								<th class="text-center">Download</th>
								<th class="text-center">Ver NFS</th>
								<th class="text-center">Status</th>
								<th class="text-center">Info</th>
							</tr>
						</thead>
						<tbody>
							<?php if (is_array($remessas)){ ?>
								<?php foreach($remessas as $key => $value) { $file_name = 'rps_'.$value->cnpj_prestador.'_'.$value->numero_remessa.'.txt'; ?>
									<tr>
										<?php if( $value->status_remessa == 'importado' ){ ?>
											<td class="text-left"><label><i class="btn btn-success fa fa-thumbs-o-up"></i></label></td>
										<?php }elseif( $value->status_remessa == 'erro' ){ ?>
											<td class="text-left"><label><i class="btn btn-danger fa fa-thumbs-o-down"></i></label></td>
										<?php }else{ ?>
											<td class="text-left"><label><input class='ids_remessas' type="checkbox" name="ids_remessas[<?= $value->cnpj_prestador; ?>][<?= $value->numero_remessa; ?>]" value="<?= $file_name; ?>"></label></td>
										<?php } ?>
										<td class="text-left"><small class="label-status"><?= $value->prestador_servico; ?></small></td>
										<td class="text-left"><small class="label-status"><?= $value->numero_remessa; ?></small></td>
										<td class="text-right"><small class="label-status"><?= $value->ano_mes_referencia; ?></small></td>
										<td class="text-left"><small class="label-status"><?= convertDate( $value->data_remessa ); ?></small></td>
										<td class="text-center">
											<a class="form-control btn btn-default" href="/download_rps.php?file=<?= $file_name; ?>"> <i class="fa fa-arrow-down"></i></a>
										</td>
										<td class="text-center">
											<a class="form-control btn btn-primary" href="/faturamento/rpsnotas/<?= $value->numero_remessa; ?>/<?= $value->cnpj_prestador; ?>"><i class="fa fa-eye"></i></a>
										</td>
										<td class="text-center">
											<b><?= strtoupper( $value->status_remessa ); ?></b>
										</td>
										<td class="text-center">
											<a type="button" class="form-control btn btn-warning" href="/faturamento/getInfoRps/<?= $value->cnpj_prestador; ?>/<?= $value->numero_remessa; ?>"><i class="fa fa-list-alt"></i></a>
										</td>
									</tr>
								<?php } ?>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</form>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
		<div class="modal fade" tabindex="-1" role="dialog" id="infoModal">
			<div class="modal-dialog " role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4><span class="modal-title">Informações sobre os envios</span></h4>
					</div>
					<div class="modal-body">
						<table class="table table-hover">
							<thead>
								<tr>
									<th>DATA ENVIO</th>
									<th>DATA RETORNO</th>
									<th>STATUS ENVIO</th>
									<th>STATUS RETORNO</th>
									<th>INFO</th>
									<th>MENSAGEM</th>
								</tr>
							</thead>
							<tbody id="bodyTable">
							</tbody>
						</table>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
					</div>
				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>
		<!-- /.modal -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
    <?php include "template/modal_sistema.php" ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$('#gerar_rps').click(function(){
		   $('#alterar_nf').attr('action', '/faturamento/gerar_rps/');
		   $('#alterar_nf').submit();
		});

		$(function() {
			$('.check_all').click(function(){
				$('input:checkbox').not(this).prop('checked', this.checked);
			});

			$('.action').click(function(){
				var action = $( this ).val();
				exec_action( action );
			})

			function exec_action( action, parametros = null ) {
				var remessas = $("#listar_rps").serialize();
				switch ( action ) {
					case 'update_status':
						var url = '/faturamento/updateStatusNFE/';
					break;
					case 'validar':
					case 'enviar':
						var url = '/faturamento/sendToNFE/action/'+action;
					break;
				}

				$.ajax({
					url: url,
					data: remessas,
					type: 'POST',
					beforeSend: function(){
						waitingDialog.show('PROCESSANDO..');                                 
					},
					success: function (data){
						waitingDialog.hide();
						var obj_json = JSON.parse(data);
						console.log(obj_json.codigo);
						if(obj_json.codigo == 0){
							$('#painel_success_msg').text('Ação executada com sucesso');
							$('#modal_sucesso_sistema').modal('show');
							$('#modal_sucesso_sistema').on('hidden.bs.modal', function () {
								location.reload();
							});
						}else{
							var mensagem_alerta = '';
							if(obj_json.processo == undefined && obj_json.processo != ''){
								mensagem_alerta = obj_json.mensagem;
							}else{
								$.each(obj_json.processo, function(key, value){
									mensagem_alerta += "<p><b>"+value.mensagem+"</b></p>";
								});
							}
							$('#painel_error_msg').text(mensagem_alerta);
							$('#modal_erro_sistema').modal('show');
						}
					},
					error: function (error){
						$('#painel_error_msg').text(error);
						$('#modal_erro_sistema').modal('show');
					}
				});
			}

			oTable = $('#list').DataTable({
				"order": [ [ 2, "desc" ] ],
				info: false,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				}
			});

			$('#data_criacao').change(function(event) {
				$('#listar_rps').submit();
			});

			$('#sl_empresa_cm').change( function(){
				$('#listar_rps').submit();
			})
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
