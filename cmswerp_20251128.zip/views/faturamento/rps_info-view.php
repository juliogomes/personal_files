<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "arquivo-rps";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Mensagens</li>
		<li>Info</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i>INFO RPS</h4>
	<form class="form-inline page-toolbar" id='listar_rps' name="listar_rps" method="post" action="/faturamento/listarrps/">
		<div class="container-fluid">
            <div class="row">
				<div class="col-md-12">
                    <table class="table table-default table-striped table-bordered table-hover" >
						<tbody>
							<td><b>EMPRESA</b></td>
                            <td><b><?= mask( $this->parametros[0], '##.###.###/####-##' ); ?></b></td>
                            <td><b>REMESSA</b></td>
                            <td><b><?= number_format( $this->parametros[1],'0','','.' ); ?></b></td>
						</tbody>
					</table>
                </div>
            </div>
			<div class="row">
				<div class="col-md-12">
					<table id='list' class="table table-default table-striped table-bordered table-hover" >
						<thead>
							<tr role="row">
								<tr>
									<th>DATA ENVIO</th>
									<th>DATA RETORNO</th>
									<th>STATUS ENVIO</th>
									<th>STATUS RETORNO</th>
									<th>INFO</th>
									<th>MENSAGEM</th>
								</tr>
							</tr>
						</thead>
						<tbody>
							<?php if ( $registros ){ ?>
								<?php foreach( $registros as $key => $value ) {?>
                                    <?php
                                        $data_envio   = getDateTime( $value->data_envio );
                                        $data_retorno = getDateTime( $value->data_retorno );
                                    ?>
									<tr>
										<td><?= $data_envio->format('d/m/Y'); ?></td>
                                        <td><?= $data_retorno->format('d/m/Y'); ?></td>
                                        <td><?= $value->status_envio; ?></td>
                                        <td><?= $value->status_retorno; ?></td>
                                        <td><?= $value->info_envio; ?></td>
                                        <td><?= $value->mensagem; ?></td>
									</tr>
								<?php } ?>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</form>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
    <?php include "template/modal_sistema.php" ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$(function() {
			oTable = $('#list').DataTable({
				"order": [ [ 2, "desc" ] ],
				info: false,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				}
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
