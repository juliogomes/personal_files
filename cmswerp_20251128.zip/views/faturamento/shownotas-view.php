<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
	<!--<![endif]-->
	<head>
		<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
		<?php include 'template/head-css.inc' ?>
		<style type="text/css">
			.negrito{
  			font-weight: bold;
			}
		</style>
		<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
		<!-- PAGE STYLES -->
		<script type="text/javascript">
			var sidebarItem = "notas-fiscais";
		</script>
		<!-- /PAGE STYLES -->
	</head>
	<body>
		<!-- MENU + WRAPPER -->
		<?php include "template/menu-wrapper.php" ?>
		<!-- /MENU + WRAPPER -->
		<!-- HEADER -->
		<ol class="breadcrumb">
			<li>Tarifas.cmsw.com</li>
			<li>Contas a receber</li>
		</ol>
		<h4 class="page-title"><i class="fa fa-caret-right"></i>Notas Fiscais</h4>
		<form class="form-inline page-toolbar" id= 'listar_nf' name="alterar_nf" method="post" action="/faturamento/shownotas/">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="pull-left">
						<div class="form-group">
							<div class="input-group date">
								<span class="input-group-addon">Ano <i class="fa fa-calendar"></i></span>
								<input type="text" class="form-control filtro" name="ano" id="search4" value="<?= $ano; ?>">
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">
								<div class="input-group-addon">Cliente</div>
								<input name="cliente" id="search2" class="form-control filtro">
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">
								<div class="input-group-addon">Produto</div>
								<input name="produto" id="search3" class="form-control filtro">
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">
								<div class="input-group-addon">Status</div>
								<select name="status" id="status" class="form-control filtro">
									<option value="" <?= (empty($status))?'selected':null; ?> >Todos</option>
									<option value="receber" <?= ($status == 'receber')?'selected':null; ?> >Pendente</option>
									<option value="recebido"    <?= ($status == 'recebido')?'selected':null; ?>>Pago</option>
								</select>
							</div>
						</div>
					</div>
				</div>
			</div>
			<br>
			<div class="row">
				<div class="col-md-12">
					<table id='list' class="table table-default table-striped table-bordered table-hover" >
						<thead>
							<tr role="row">
								<th class="text-center">Cliente</th>
								<th class="text-center">Produto</th>
								<th class="text-center">Ano referencia</th>
								<th class="text-center">Valor</th>
								<th class="text-center">Valor c/ Impostos</th>
							</tr>
						</thead>
						<tbody>
							<?php if(is_array($dados)){ ?>
								<?php foreach($dados as $key => $value){
									$obj_date = new dateTime($value->data_vencimento);
									if(isset($this->parametros[2]) && !empty($this->parametros[2])){
										if( $this->parametros[2] == $value->data_vencimento){
											$totalizador += $value->valor_total;
										}
									}else{
										$totalizador += $value->valor_total;
									}
								?>
									<tr>
										<td class="text-left"><small class="label-status"><?= $value->cliente; ?></small></td>
										<td class="text-left"><small class="label-status"><?= $value->codigo_produto; ?></small></td>
										<td class="text-right"><small class="label-status"><?= $value->ano_mes_referencia; ?></small></td>
										<td class="text-right"><?= $value->valor_fatura; ?></td>
										<td class="text-right"><?= $value->valor_total; ?></td>
									</tr>
								<?php } ?>
							<?php }; ?>
						</tbody>
						<tfoot>
							<tr>
								<td></td>
								<td></td>
								<td></td>
								<td class="text-right negrito"></td>
								<td class="text-right negrito"></td>
							</tr>
							<tr>
			 					<td colspan="4" class="text-left"><strong>TOTAL</strong></td>
								<td colspan="3" class="text-right"><strong><?= number_format($totalizador, '2', ',', '.'); ?></strong></td>
							</tr>
						</tfoot>
					</table>
				</div>
			</div>
		</div>
		</form>
		<!-- /.container-fluid -->
		<!-- /CONTENT -->
		<!-- END WRAPPER -->
		<?php include "template/end-menu-wrapper.html" ?>
		<!-- /END WRAPPER -->
		<!-- MODALS -->
		<!-- /MODALS -->
		<!-- INCLUDE DEFAULT SCRIPTS -->
		<?php include 'template/scripts.inc' ?>
		<!-- /INCLUDE DEFAULT SCRIPTS -->
		<!-- PAGE SCRIPTS -->
		<script type="text/javascript" src="/libs/DataTables-1.10.13/js/jquery.dataTables.min.js"></script>
		<script type="text/javascript" src="/libs/DataTables-1.10.13/js/dataTables.bootstrap.min.js"></script>
		<script type="text/javascript">
			$(function() {
				oTable = $('#list').DataTable({
					info: false,
					dom: "<'panel panel-default'" +
					"tr" +
					"<'panel-footer'" +
					"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
					">" +
					">",
					language: {
						"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
					},
					"columnDefs": [ {
					    "targets": 3,
					    "data": "valor", // Use the full data source object for the renderer's source
					    'render': function ( data, type, full, meta ) {
								var valor = Number(data);
								return '<span>'+valor.toFixed(2).replace(".", ",").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.")+'</span>';
							}
					  },
					  {
					  "targets": 4,
					  "data": "Valor c/ Impostos", // Use the full data source object for the renderer's source
					  'render': function ( data, type, full, meta ) {
							var valor = Number(data);
							return '<span>'+valor.toFixed(2).replace(".", ",").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.")+'</span>';
						}
					}],
				  "footerCallback": function ( row, data, start, end, display ){

            var api = this.api(), data;
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
            // Total over all pages
            total = api
                .column( 3 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
            // Total over this page
            pageTotal = api
                .column( 3, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
						// Total over this page
            totalImposto = api
                .column( 4, { page: 'current'} )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );

            // Update footer
            $( api.column( 3 ).footer() ).html(
					    pageTotal.toFixed(2).replace(".", ",").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.")
						);
						$( api.column( 4 ).footer() ).html(
					    totalImposto.toFixed(2).replace(".", ",").replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.")
						);
	    		}
				});
				$('#search2').keyup(function(){
					oTable
					.columns( 0 )
					.search( this.value )
					.draw();
				});
				$('#search3').keyup(function(){
					oTable
					.columns( 1 )
					.search( this.value )
					.draw();
				});
				$('#search4').mask('0000', {
					onComplete: function(value, event, field) {
						oTable
						.columns( 5 )
						.search( value )
						.draw();
					}
				}).on('change', function(event) {
					oTable
					.columns( 5 )
					.search( this.value )
					.draw();
				}).on('ready', function(){
					
				}).datepicker({
          minViewMode: 2,
         	format: 'yyyy',
					clearBtn: false,
					language: "pt-BR",
					autoclose: true,
					todayBtn: "linked",
					todayHighlight: true
				});
				$('.filtro').on(function(event) {
					$('#listar_nf').submit();
				});
				$('#search4').change(function(event) {
					$('#listar_nf').submit();
				});
			});
		</script>
		<!-- /PAGE SCRIPTS -->
	</body>
</html>
