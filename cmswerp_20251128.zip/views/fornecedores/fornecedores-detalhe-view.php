<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php

use Mpdf\Tag\Option;

include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "fornecedores";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Cadastros</li>
		<li>Fornecedores</li>
	</ol>
	<h4 class="page-title">
		<?php
		if(empty($this->parametros[1])){
			echo '<i class="fa fa-plus"></i> Novo Fornecedor';
		}else{
			echo '<i class="fa fa-edit"></i> Editar Fornecedor';
		}
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<form id="form" action="<?php echo HOME_URI.$this->module.'/save/id/'.$this->parametros[1].''; ?>" name="save" method="post">
			<div class="row">
				<div class="col-sm-12 col-md-12">
					<fieldset>
						<legend>Fornecedor</legend>
					</fieldset>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="cnpj">TIPO</label>
								<select name="tipo" id="tipo" class="form-control">
									<option value="fisica"   <?= ($records[0]->tipo == 'fisica')?'selected':null ?> >Fisica</option>
									<option value="juridica" <?= ($records[0]->tipo == 'juridica')?'selected':null ?> >Juridica</option>
								</select>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="cnpj_cpf">CNPJ / CPF </label>
								<input type="text" name="cnpj_cpf" id="cnpj" class="form-control masked" placeholder="99.999.999/9999-99" value="<?php echo isset($records[0])?$records[0]->cnpj_cpf:null ?>" required />
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="inscricao_estadual">Inscrição Estadual</label>
								<input type="text" name="inscricao_estadual" id="inscricao_estadual" class="form-control" id="inscricao_estadual" placeholder="99999999" maxlength="8" minlength="8" value="<?php echo isset($records[0])?$records[0]->inscricao_estadual:null ?>" />
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="razao_social">Razao Social / Nome</label>
								<input type="text" name="razao_social" id="razao_social" maxlength="60" class="form-control" value="<?php echo isset($records[0])?$records[0]->razao_social:null ?>" required/>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="nome_fantasia">Nome Fantasia</label>
								<input type="text" name="nome_fantasia" id="nome_fantasia" maxlength="60" class="form-control" value="<?php echo isset($records[0])?$records[0]->nome_fantasia:null ?>" />
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-3">
							<div class="form-group">
								<label for="cep">CEP</label>
								<input type="text" maxlength="9" class="form-control cep" id="cep" placeholder="99999-999"value="<?php echo isset($records[0])?$records[0]->cep:null ?>" name="cep" required />
							</div>
						</div>
						<div class="col-md-9">
							<div class="form-group">
								<label for="endereco">Endereço</label>
								<input type="text" maxlength="75" class="form-control" value="<?php echo isset($records[0])?$records[0]->endereco:null ?>" name="endereco" data-autocep-input="logradouro" required/>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label for="numero">Numero</label>
								<input type="text" maxlength="9" class="form-control" value="<?php echo isset($records[0])?$records[0]->numero:null ?>" name="numero" data-autocep-input="numero" required/>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="complemento">Complemento</label>
								<input type="text" maxlength="30" class="form-control" value="<?php echo isset($records[0])?$records[0]->complemento:null ?>" name="complemento" data-autocep-input="complemento"/>
							</div>
						</div>

						<div class="col-md-4">
							<div class="form-group">
								<label for="bairro">Bairro</label>
								<input type="text" maxlength="40" class="form-control" value="<?php echo isset($records[0])?$records[0]->bairro:null ?>" name="bairro" data-autocep-input="bairro" required />
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label for="estado">Estado</label>
								<select name="estado" id="estado" class="form-control uf-cidade" data-pair="cidade" data-autocep-select="uf" >
									<option value="">Selecione</option>
								</select>
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<label for="cidade">Cidade</label>
								<select name="cidade" maxlength="40" id="cidade" class="form-control cidade-uf" data-autocep-select="localidade">
									<option value=""></option>
								</select>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label for="telefone">Telefone</label>
								<input type="text" class="form-control" value="<?php echo isset($records[0])?$records[0]->telefone:null ?>" name="telefone"/>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="contato">Contato</label>
								<input type="text" class="form-control" placeholder="Nome" value="<?php echo isset($records[0])?$records[0]->contato:null ?>" name="contato"/>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label for="email_contato">Email Contato</label>
								<input type="text" class="form-control" placeholder="email@dominio.com.br" value="<?php echo isset($records[0])?$records[0]->email_contato:null ?>" name="email_contato" />
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								<label for="status">Status</label>
								<select name='status' class="form-control select">
									<option value=''>Selecione</option>
									<option value='inativo' <?php echo (isset($records[0]) && $records[0]->status == 'inativo')?'selected':'' ?> >INATIVO</option>
									<option value='ativo' <?php echo (isset($records[0]) && $records[0]->status == 'ativo')?'selected':'' ?> >ATIVO</option>
									<option value='suspenso' <?php echo (isset($records[0]) && $records[0]->status == 'suspenso')?'selected':'' ?> >SUSPENSO</option>
								</select>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-md-12">
					<fieldset>
						<legend>Bancos Cadastrados</legend>
					</fieldset>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-md-12">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-md-6">
					<div class="form-group">
						<button type="button" id="btn_add_banco" class="form-control btn btn-success"><i class="fa fa-plus"></i> NOVO BANCO</button>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12 col-md-12">
					<div class="form-group">
					<table id="table_bancos" class="table table-responsive">
							<thead>
								<tr>
									<th>ID</th>
									<th>CODIGO</th>
									<th>NOME</th>
									<th>TIPO</th>
									<th>AGENCIA</th>
									<th>CONTA</th>
									<th>CONTA PADRÂO</th>
									<th>AÇAO</th>
								</tr>
							</thead>
							<tbody id='lista_banco'>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-6 col-md-6">
					<button type="submit" class="form-control btn btn-primary"><i class="fa fa-save"></i> Gravar</button>
				</div>
				<div class="col-sm-6 col-md-6">
					<a href="/fornecedores/index/" class="form-control btn btn-warning"><i class="fa fa-times"></i> Voltar</a>
				</div>
			</div>
		</form>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
		<div class="modal fade" tabindex="-1" role="dialog" id="addBancoModal">
			<div class="modal-dialog " role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4><span class="modal-title">Cadastrar Dados Bancarios</span></h4>
					</div>
					<div class="modal-header">
						<div id="div_aviso" style="font-weight:bold"></div>
					</div>
					<form id="frm_add_banco" name="frm_add_banco" method="post">
						<div class="modal-body">
							<div id="mensagem"></div>
							<div id="dados_banco">
								<div class="form-group">
									<input type="hidden" class="form-control" name="id_empresa" id="id_empresa" value="<?= $this->parametros[1]; ?>" />
									<input type="hidden" class="form-control" name="origem_conta" id="origem_conta" value="fornecedor" />
									<input type="hidden" class="form-control" name="id_banco_bacen" id="id_banco_bacen" value="" />
									<label>Banco</label>
									<input type="text" class="form-control" name="nome_banco" id='autocomplete' />
								</div>
								<div class="form-group">
									<label for="tipo_conta">Tipo da Conta</label>
									<select name="tipo_conta" id="tipo_conta" class="form-control select">
										<option value="c">Conta Corrente</option>
										<option value="p">Conta Poupança</option>
									</select>
								</div>
								<div class="row">
									<div class="col-md-12">
										<label>Chave PIX</label>
										<input type="text" class="form-control" name="chave_pix" id='chave_pix' />
									</div>
								</div>
								<div class="form-group">
									<label for="numero_agencia">Agencia</label>
									<input type="text" class="form-control" name="numero_agencia" id="numero_agencia" aria-describedby="" placeholder="" value="" />
								</div>	
								<div class="form-group">
									<label for="digito_agencia">Digito</label>
									<input type="text" class="form-control" name="digito_agencia" id="digito_agencia" aria-describedby="" placeholder="" value="" />
								</div>
								<div class="form-group">
									<label for="numero_conta">Conta</label>
									<input type="text" class="form-control" name="numero_conta" id="numero_conta" aria-describedby="" placeholder="" value="" />
								</div>
								<div class="form-group">
									<label for="digito_conta">Digito</label>
									<input type="text" class="form-control" name="digito_conta" id="digito_conta" aria-describedby="" placeholder="" value="" />
								</div>
								<div class="form-group">
									<label for="email">Email de contato</label>
									<input type="text" class="form-control" name="email" id="email" aria-describedby="" placeholder="" value="" />
								</div>
								<div class="form-group">
									<label for="codigo_convenio_cnab400">Convenio Cobrança/Pagamento CNAB 400 </label>
									<input type="text" class="form-control" name="codigo_convenio_cnab400" id="codigo_convenio_cnab400" aria-describedby="" placeholder="" value="" />
								</div>
								<div class="form-group">
									<label for="codigo_convenio_cnab240">Convenio Cobrança/Pagamento CNAB 240</label>
									<input type="text" class="form-control" name="codigo_convenio_cnab240" id="codigo_convenio_cnab240" aria-describedby="" placeholder="" value="" />
								</div>
								<div>
									<label for="banco_conta_div">Conta Padrão?</label>
									<input type="checkbox" class="form-control" name="conta_default" id="conta_default" aria-describedby="" placeholder="" value="1" />
								</div>
								<button type="button" id="btn_incluir_conta" class="form-control btn btn-success" value="adicionar"><id class="fa fa-plus"></i> Adicionar</button>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Sair</button>
						</div>
					</form>
				</div><!-- /.modal-content -->
			</div><!-- /.modal-dialog -->
		</div>
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<script type="text/javascript">
		$('#autocomplete').autocomplete({
			minLength: 1,
			autoFocus: true,
			delay: 300,
			position: {
				my: 'left top',
				at: 'right top'
			},
			appendTo: '#frm_add_banco',
			source: function(request, response){
				$.ajax({
					url: '/contabancaria/getBancoList',
					type: 'post',
					dataType: 'json',
					data: {
						'search': request.term
					}
				}).done(function(data){
					// obj = JSON.parse(data);   //parse the data in JSON (if not already)
					response($.map(data, function(item){
						return {
							label: item.nome_reduzido,
							value: item.id
						}
					}))
				});
			},
			select:function(event, ui){
				console.log(event); 
				$('#autocomplete').val(ui.item.label);
				$('#id_banco_bacen').val(ui.item.value);
				return false;
			}   
		});
	</script>
	<script type="text/javascript">
		$(function(){
			
			$('#table_bancos').hide();
			var id_fornecedor = "<?= $this->parametros[1]; ?>";
			// alert(id_fornecedor);
			
			if(id_fornecedor > 0 ){
				montaTabelaBancos(id_fornecedor);
			}
			
			$('#btn_add_banco').click(function(){
				var id_empresa = "<?= $this->parametros[1];?>";
				if(id_empresa == 0 || id_empresa ==""){
					alert('É necessario cadastrar o fornecedor antes de atribuir uma conta!');
					return;
				}
				$("#addBancoModal").modal({
        			show: 'true'
    			});
			});

			// $("#frm_add_banco").submit(function(event){
            //     event.preventDefault();
			// 	var dados_form = $(this).serialize();
			// 	console.log(dados_form);
            // });

			//data-masked="00.000.000/0000-00" 
			function cnpjCpfMask(){
				if($('#tipo').val() == 'juridica'){
					var mask_cpf_cnpj = '00.000.000/0000-00';
				}else{
					var mask_cpf_cnpj = '000.000.000-00';
				}
				$('.masked').each(function(index, element) {
					$(element).mask(mask_cpf_cnpj, {
						onChange: function(value, event, field) {
							$(event.target.form).formValidation('revalidateField', field);
						}
					});
				});
			}
			
			cnpjCpfMask();
			$('#tipo').change(function(){
				cnpjCpfMask();
			});
			
			$('#btn_incluir_conta').click(function(){
				var dados_form = $('#frm_add_banco').serialize();
				// var dados_form = $("form[name=frm_add_banco]").serialize();
				console.log(dados_form);
				$.ajax({
					url: '/contabancaria/save/',
					data: dados_form,
					type: 'POST',
					success: function (data){
						var obj_json = JSON.parse(data);
						console.log(obj_json);
						if(obj_json.codigo == 0){
							location.reload();
						}else{
							$('#div_aviso').html('<p style="color:red"><b>'+obj_json.mensagem+'</b></p>');
						}
					},
					error: function (error){	
						console.log(error);
						alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
					}
				});
			});

			function montaTabelaBancos(id_fornecedor){
				// alert(id_fornecedor);
				var bancos = null;
				var table_rows = null;
				$.ajax({
					url: '/contabancaria/getContasBancariasJson/fornecedor/'+id_fornecedor,
					// data: dados_form,
					type: 'POST',
					success: function (data){
						var obj_json = JSON.parse(data);
						console.log(obj_json);
						if(obj_json.codigo == 0){
							bancos = obj_json.output;
							$.each(bancos, function(index, element) {
								if(element.conta_default == 0){
									var conta_default = 'NÂO';
								}else{
									var conta_default = 'SIM';
								}
								table_rows += '<tr>';
								table_rows += '<td>';
								table_rows += element.id;
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += element.codigo_banco;
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += element.nome_reduzido;
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += element.tipo_conta;
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += element.numero_agencia+'-'+element.digito_agencia;
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += element.numero_conta+'-'+element.digito_conta;
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += conta_default;
								table_rows += '</td>';
								table_rows += '<td>';
								table_rows += '<button type="button" data-acao="default" class="uppercase action btn btn-success" value="'+element.id+'"><i class="fa fa-check"></i> </span> </button>';
								table_rows += '<button type="button" data-acao="apagar" class="uppercase action btn btn-danger" value="'+element.id+'"><i class="fa fa-trash"></i> </span> </button>';
								table_rows += '</td>';
								table_rows += '</tr>';
								// console.log(element);
							});
							$('#lista_banco').html(table_rows);
							$('#table_bancos').show();
						}else{
							//implementar erro 
						}
					},
					error: function (error){	
						console.log(error);
						alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
					}
				});
			}

			$(document).on('click', '.action', function(e) {
				e.preventDefault;
				// alert('teste');
				var id            = $(this).val();
				var id_fornecedor = <?= $this->parametros[1]; ?>;
				var acao          = $(this).data('acao');
				
				if(acao == 'default'){
					var url_action = '/contabancaria/checkContaDefault/fornecedor/id/'+id_fornecedor+'/'+id;
				}else if(acao == 'apagar'){
					var url_action = '/contabancaria/apagar/id/'+id;
				}

				$.ajax({
					url: url_action,
					// data: dados_form,
					type: 'POST',
					success: function (data){
						var obj_json = JSON.parse(data);
						console.log(obj_json);
						if(obj_json.codigo == 0){
							montaTabelaBancos(id_fornecedor);
						}else{
							//implementar erro 
						}
					},
					error: function (error){	
						console.log(error);
						alert('Erro na requisição codigo: '+error.status+' mensagem: '+error.statusText);
					}
				});
			})

			$('#addBancoModal').on('hidden.bs.modal', function(){
				montaTabelaBancos(id_fornecedor);
			});
		});

	</script>
<!-- /PAGE SCRIPTS -->
</body>
</html>