<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "ged";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Ged</li>
		<li><?= $records[0]->nome_fantasia ?></li>
	</ol>
	<h4 class="page-title">
		<?php
		if(empty($this->parametros[1])){
			echo '<i class="fa fa-plus"></i> Novo Documento';
		}else{
			echo '<i class="fa fa-edit"></i> Novo Documento '.$records[0]->nome_fantasia;
		}
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div id="loadingDIV" class="row">
			<div class="col-sm-12 col-md-9">
				
			</div>			
		</div>
		<div class="row">
			<div class="col-sm-12 col-md-9">
				<form id="send_file" action="#" name="save" method="post">
					<fieldset>
						<legend>Dados do documento</legend>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group">
									<label for="tipo_documento">Tipo de documento</label>
									<select name='tipo_documento' id='tipo_documento' class="form-control select">
										<option value="">Selecione</option>
										<option value="contrato">Contrato</option>
										<option value="auditoria">Auditoria</option>
										<option value="correspondencia">Correspondência</option>
										<option value="instrucao">Instrução de faturamento</option>
										<option value="nf">Nota Fiscal</option>
										<option value="proposta">Proposta Comercial</option>
										<option value="outros">Outros</option>
									</select>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12" id="r1">
								<input type="hidden" name="codigo_produto" id="codigo_produto" />
							</div>
						</div>
						<div class="row">
							<div class="col-md-12" id="r2">
								
							</div>
						</div>
						<div class="row">
							<div class="col-md-6" id="r3">
								<a href="/ged/listdoc/id/<?= $this->parametros[1] ?>/" class="btn btn-warning"><i class="fa fa-undo"></i> Voltar</a>
							</div>
						</div>
					</fieldset>
					<!-- <button type="submit" class="btn btn-primary"><i class="fa fa-caret-right-o"></i> Próximo</button> -->
				</form>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- Default bootstrap modal example -->
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        <h4 class="modal-title" id="myModalLabel">Transferindo arquivo <i class="fa fa-spinner fa-spin" style="font-size:24px"></i></h4>
	      </div>
<!-- 	      <div class="modal-body">
	      	<div align="center"><i class="fa fa-spinner fa-spin" style="font-size:24px"></div>
	      </div> -->
<!-- 	      <div class="modal-footer">
	        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        <button type="button" class="btn btn-primary">Save changes</button>
	      </div> -->
	    </div>
	  </div>
	</div>
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- <script type="text/javascript" src="/assets/js/form-behaviors.js"></script> -->
	<script type="text/javascript">
	$(document).ready(function() {
	  	var max_fields = 10; //maximum input boxes allowed
	  	var wrapper = $(".input_fields_wrap"); //Fields wrapper
	  	var add_button = $(".add_field_button"); //Add button ID
	  	var x = 1; //initlal text box count
		$('#tipo_documento').change(function(){
			$tipo_doc = $(this).val();
			if($tipo_doc == 'contrato' || $tipo_doc == 'proposta' || $tipo_doc == 'instrucao' || $tipo_doc == 'auditoria'){
				removeElemet('classificacao');
				removeElemet('id_produto');
				removeElemet('data_emissao');
				removeElemet('num_nota');
				removeElemet('num_fatura');
				removeElemet('tipificacao');

				if($('#classificacao').length == 0){

					$('#r1').append('<div class="row"><div class="col-md-12"><label for="classificacao">Classificação</label><select name="classificacao" id="classificacao" class="form-control select"><option value="">Selecione</option><option value="aditivos">Aditivos</option><option value="contrato">Contrato</option><option value="licenciamento">Licenciamento</option><option value="nda">NDA</option><option value="outros">Outros</option><option value="pedido serviço">Pedido de serviço</option><option value="serviços">Serviços</option></select></div></div>');	
				}

			}else if($tipo_doc == 'correspondencia'){
				
				// removeElemet('classificacao');
				$('#r1').append('<div class="row"><div class="col-md-12"><label for="classificacao">Classificação</label><select name="classificacao" id="classificacao" class="form-control select"><option value="">Selecione</option><option value="email">Email</option><option value="bacen">BACEN</option><option value="baixa_spb">Baixa SPB</option><option value="alteracao_tarifador">Alteração tarifador</option></select></div></div>');	
				removeElemet('id_produto');
				removeElemet('data_emissao');
				removeElemet('num_nota');
				removeElemet('num_fatura');
				removeElemet('tipificacao');
				
				showDataEmissao();
				showAssunto();
				showSubmit();

			}else if($tipo_doc == 'nf'){
				removeElemet('id_produto');
				removeElemet('data_assinatura');
				removeElemet('data_emissao');
				removeElemet('tipificacao');
				removeElemet('classificacao');

				if($('#num_nota').length == 0){

					$('#r1').append('<div class="row"><div class="col-md-12"><label for="num_nota">Numero da Nota</label><input type="text" name="num_nota" id="num_nota" class="form-control" /></div></div>');
				}

				if($('#num_fatura').length == 0){
					$('#r1').append('<div class="row"><div class="col-md-12"><label for="num_fatura">Numero da fatura</label><input type="text" name="num_fatura" id="num_fatura" class="form-control" /></div></div>');
				}

				showProdutos();	
				showDataEmissao();
				showSubmit();
			}else if($tipo_doc == 'outros'){
				removeElemet('id_produto');
				removeElemet('data_assinatura');
				removeElemet('data_emissao');
				removeElemet('tipificacao');
				removeElemet('classificacao');

				showTipificacao();
				showSubmit();
			}
		});

		$(document).on("change","#classificacao",function(evt){
			
			if($(this).val() == 'licenciamento' || $(this).val() == 'serviços' || $(this).val() == 'aditivos' || $(this).val() == 'pedido serviço' || $(this).val() == 'contrato'){
				removeElemet('data_assinatura');
				removeElemet('tipificacao');
				showProdutos();
				showDataAssinatura();
				showSubmit();

			}else if($(this).val() == 'nda'){
				removeElemet('id_produto');
				removeElemet('tipificacao');
				showDataAssinatura();
				showSubmit();
				
			}else if($(this).val() == 'outros'){
				removeElemet('data_assinatura');
				removeElemet('id_produto');
				showTipificacao();
				showSubmit();
			}
		});

		$(document).on("change","#id_produto",function(evt){
			var codigo_produto = $('#id_produto :selected').data('codigo_produto');
			$('#codigo_produto').val(codigo_produto);
			if($(this).val() != ''){
				showSubmit();
			}
		});

		function showSubmit(){
			if($('#submit').length == 0){
				$('#r2').append('<div><label for="arquivo">Selecione o arquivo</label><input type="file" id="arquivo" name="arquivo" class="form-control" required /></div>');
				$('#r3').append('<button id = "submit" type="submit" class="btn btn-primary"> Enviar Arquivo</button>');
			}			
		}

		function showProdutos(){
			if($('#id_produto').length == 0){
				$('#r1').append('<div class="row"><div class="col-md-12"><label for="id_produto">Produto</label><select name="id_produto" id="id_produto" class="form-control select" class="form-control select"><option value="">Selecione</option><?php
					foreach($produtos as $key=>$value){
						echo '<option value ="'.$value->id.'" data-codigo_produto = "'.$value->codigo.'" >'.strtoupper($value->nome).'</option>';
					} ?></select></div></div>'
				);
			}
		}

		function showDataAssinatura(){
			if($('#data_assinatura').length == 0){
				$('#r1').append('<div class="row"><div class="col-md-12"><label for="data_assinatura">Data Assinatura / Proposta</label><input type="date" name="data_assinatura" id="data_assinatura" class="form-control" /></div></div>');
			}
		}

		function showDataEmissao(){
			if($('#data_emissao').length == 0){
				$('#r1').append('<div class="row"><div class="col-md-12"><label for="data_emissao">Data de Emissão</label><input type="date" name="data_emissao" id="data_emissao" class="form-control" /</div></div>');
			}
		}

		function showAssunto(){
			$('#r1').append('<div class="row"><div class="col-md-12"><label for="data_emissao">Assunto</label><input type="text" name="assunto" id="assunto" class="form-control" /</div></div>');
		}

		function showTipificacao(){
			if($('#tipificacao').length == 0){
				$('#r1').append('<div class="row"><div class="col-md-12"><label for="tipificacao">Digite a Classificação do arquivo</label><input type="text" id="tipificacao" name="tipificacao" class="form-control" /></div></div>');
			}
		}

		function removeElemet(id){
			$('#'+id).remove();
			$('label[for=' + id + ']').remove();
		}

		$("#send_file").submit(function () {
		    event.preventDefault();
		    var formData = new FormData(this);
		    $.ajax({
		        url: '<?= HOME_URI.$this->module.'/savefile/id/'.$this->parametros[1].''; ?>',
		        type: 'POST',
		        data: formData,
		        beforeSend: function ( xhr ) {    
                    //$("#loadingDIV").show();
                    //// Fill modal with content from link href
					$("#myModal").modal("show");
                },
		        success: function (data){
		            var retorno = JSON.parse(data);
		            if(retorno.codigo == 0){
		            	alert('Upload realizado com sucesso!');
		            	window.location.href = "/ged/listdoc/id/<?= $this->parametros[1] ?>/";
		            }else{
		            	alert('Erro ao fazer upload do documento');
						console.log(data);
		            	console.log(retorno);
		            	$("#myModal").modal("hide");
		            }   
		        },
		        cache: false,
		        contentType: false,
		        processData: false,
		        xhr: function(){  // Custom XMLHttpRequest
		            var myXhr = $.ajaxSettings.xhr();
		            if (myXhr.upload) { // Avalia se tem suporte a propriedade upload
		                myXhr.upload.addEventListener('progress', function () {
		                    /* faz alguma coisa durante o progresso do upload */
		                }, false);
		            }
		        	return myXhr;
		        }
		    });
		});

	});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>