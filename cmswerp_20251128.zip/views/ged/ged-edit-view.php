<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
	<head>
		<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
		<?php include 'template/head-css.inc' ?>
		<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
		<!-- PAGE STYLES -->
		<script type="text/javascript">
			var sidebarItem = "ged";
		</script>
		<!-- /PAGE STYLES -->
	</head>
	<body>
		<!-- MENU + WRAPPER -->
		<?php include "template/menu-wrapper.php" ?>
		<!-- /MENU + WRAPPER -->
		<!-- HEADER -->
		<ol class="breadcrumb">
			<li>Tarifas.cmsw.com</li>
			<li>Ged</li>
			<li><?= $records[0]->nome_fantasia ?></li>
		</ol>
		<h4 class="page-title">
			<?php
				echo '<i class="fa fa-edit"></i> Editar Documento ';
			?>
		</h4>
		<!-- /HEADER -->
		<!-- CONTENT -->
		<div class="container-fluid">
			<div id="loadingDIV" class="row">
				<div class="col-sm-12 col-md-9">
					
				</div>			
			</div>
			<div class="row">
				<div class="col-sm-12 col-md-9">
					<form id="send_file" action="/ged/saveDoc/id/<?= $this->parametros[1] ?>/<?= $this->parametros[2] ?>/" name="save" method="post">
						<fieldset>
							<legend>Dados do documento</legend>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label for="tipo_documento">Tipo de documento</label>
										<select name='tipo_documento' id='tipo_documento' class="form-control select">
											<option value="" selected >Selecione</option>
											<option value="contrato" <?= ($documento[0]->tipo_documento == 'contrato')?'selected':null ?>>Contrato</option>
											<option value="correspondencia" <?= ($documento[0]->tipo_documento == 'correspondencia')?'selected':null ?>>Correspondência</option>
											<option value="instrucao" <?= ($documento[0]->tipo_documento == 'instrucao')?'selected':null ?>>Instrução de faturamento</option>
											<option value="nf" <?= ($documento[0]->tipo_documento == 'nf')?'selected':null ?>>Nota Fiscal</option>
											<option value="proposta" <?= ($documento[0]->tipo_documento == 'proposta')?'selected':null ?>>Proposta Comercial</option>
											<option value="outros" <?= ($documento[0]->tipo_documento == 'outros')?'selected':null ?>>Outros</option>
										</select>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label for="assunto">Assunto</label>
										<input type="text" id="assunto" name="assunto" class="form-control" value="<?= $documento[0]->assunto; ?>">
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<label for="tipo_contrato">Classificação</label>
										<select name="tipo_contrato" id="tipo_contrato" class="form-control select">
											<option value="" selected >Selecione</option>
											<option value="aditivos" <?= ($documento[0]->tipo_contrato == 'aditivos')?'selected':null ?>>Aditivos</option>
											<option value="licenciamento" <?= ($documento[0]->tipo_contrato == 'licenciamento')?'selected':null ?>>Licenciamento</option>
											<option value="bacen" <?= ($documento[0]->tipo_contrato == 'bacen')?'selected':null ?>>BACEN</option>
											<option value="baixa_spb" <?= ($documento[0]->tipo_contrato == 'baixa_spb')?'selected':null ?>>Baixa SPB</option>
											<option value="alteracao_tarifador" <?= ($documento[0]->tipo_contrato == 'alteracao_tarifador')?'selected':null ?>>Alteração tarifador</option>
											<option value="nda" <?= ($documento[0]->tipo_contrato == 'nda')?'selected':null ?>>NDA</option>
											<option value="outros" <?= ($documento[0]->tipo_contrato == 'outros')?'selected':null ?>>Outros</option>
											<option value="pedido serviço" <?= ($documento[0]->tipo_contrato == 'pedido serviço')?'selected':null ?>>Pedido de serviço</option><option value="serviços">Serviços</option></select>	
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12"><label for="produto">Produto</label>
									<div class="form-group">
										<select name="id_produto" id="produto" class="form-control select" class="form-control select">
											<option value="" selected >Selecione</option>
											<?php foreach($produtos as $key=>$value){ ?>
												<?php if( $value->id == $documento[0]->id_produto ){ ?>
													<option value ="<?= $value->id?>" selected><?= strtoupper( $value->nome ); ?></option>
												<?php }else{ ?>
													<option value ="<?= $value->id?>" ><?= strtoupper( $value->nome ); ?></option>
												<?php } ?>
											<?php } ?>		
										</select>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
									<label for="dt_em_ass">Data Assinatura / Proposta</label>
									<input type="text" name="dt_em_ass" id="dt_em_ass" class="form-control datepast" value="<?= convertDate($documento[0]->dt_em_ass) ?> placeholder="Dia/Mês/Ano"" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
									<label for="num_nota">Numero da nota fiscal</label>
									<input type="text" name="num_nota" id="num_nota" class="form-control" value= "<?= $documento[0]->num_nota ?>"/>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
									<label for="num_fatura">Numero da fatura fiscal</label>
									<input type="text" name="num_fatura" id="num_fatura" class="form-control" value="<?= $documento[0]->num_fatura ?>"/>
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
									<label for="observacoes">Digite a Classificação do arquivo (Apenas quando a classificação for outros)</label>
									<input type="text" id="observacoes" name="observacoes" class="form-control" value="<?= $documento[0]->observacoes ?>" />
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
									<a href="/ged/listdoc/id/<?= $this->parametros[1] ?>/" class="form-control btn btn-warning"><i class="fa fa-undo"></i> Voltar</a>
									</div>
								</div>
								<div class="col-md-6">
									<button type="submit" class="form-control btn btn-success"><i class="fa fa-save"></i> Salvar</a></button>
								</div>
							</div>
						</fieldset>
					</form>
				</div>
			</div>
		</div>
		<!-- /.container-fluid -->
		<!-- /CONTENT -->
		<!-- END WRAPPER -->
		<?php include "template/end-menu-wrapper.html" ?>
		<!-- /END WRAPPER -->
		<!-- MODALS -->
		<!-- Default bootstrap modal example -->

		<!-- /MODALS -->
		<!-- INCLUDE DEFAULT SCRIPTS -->
		<?php include 'template/scripts.inc' ?>
		<!-- /INCLUDE DEFAULT SCRIPTS -->
		<!-- PAGE SCRIPTS -->
		<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
		<!-- /PAGE SCRIPTS -->
	</body>
</html>