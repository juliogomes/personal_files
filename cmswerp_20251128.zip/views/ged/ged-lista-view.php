<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript"> var sidebarItem = "<?= $this->sidebarItem; ?>";</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Ged</li>
		<li><?= $documentos[0]->nome_fantasia ?></li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> GED <i class="fa fa-caret-right"></i> <?= $documentos[0]->nome_fantasia ?></h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<form class="form-inline page-toolbar">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<?php if( $this->nivel_acesso > 1 ){ ?>
						<div class="btn-group" role="group">
							<a href="/ged/detalhe/id/<?= $this->parametros[1] ?>/" class="btn btn-default"><i class="fa fa-plus"></i> Novo Documento</a>
						</div>
					<?php } ?>
				</div>
			</div>
			<br />
			<div class="row">
				<div class="col-md-12">
					<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
						<thead>
							<tr role="row">
								<th>Tipo Documento</th>
								<th>Assunto</th>
								<th>Classificação/Observação</th>
								<th>Produto</th>
								<th>Nº Nota</th>
								<th>Nº Fatura</th>
								<th>Assinatura/Emissão</th>
								<th width="90" class="text-center"></th>
								<th width="90" class="text-center"></th>
							</tr>
						</thead>
						<tbody>
							<?php if ( is_array( $documentos ) ){ ?>
								<?php foreach( $documentos as $key => $value ) { ?>
									<?php $link = base64_encode( $value->path_root.'/'.$value->path_file ); ?>
									<tr>
										<td data-toggle="tooltip" data-placement="left" data-container="body" title="<?= $value->razao_social ?>">
											<span class="label-status"><small><?= $value->tipo_documento ?></small></span>
										</td>
										<td data-toggle="tooltip" data-placement="left" data-container="body" title="<?= $value->razao_social ?>">
											<span class="label-status"><small><?= (!empty($value->assunto))?$value->assunto:'-' ?></small></span>
										</td>
										<td data-toggle="tooltip" data-placement="left" data-container="body" title="<?= $value->razao_social ?>">
											<span class="label-status"><small><?= (!empty($value->tipo_contrato))?$value->tipo_contrato:'-' ?> <?= $value->observacoes ?></small></span>
										</td>
										<td data-toggle="tooltip" data-placement="left" data-container="body" title="<?= $value->razao_social ?>">
											<span class="label-status"><small><?= (!empty($value->codigo_produto))?$value->codigo_produto:'-'  ?></small></span>
										</td>
										<td data-toggle="tooltip" data-placement="left" data-container="body" title="<?= $value->razao_social ?>">
											<span class="label-status"><small><?=  (!empty($value->num_nota))?$value->num_nota:'-'; ?></small></span>
										</td>
										<td data-toggle="tooltip" data-placement="left" data-container="body" title="<?= $value->razao_social ?>">
											<span class="label-status"><small><?=  (!empty($value->num_fatura))?$value->num_fatura:'-'; ?></small></span>
										</td>
										<td data-toggle="tooltip" data-placement="left" data-container="body" title="<?= $value->razao_social ?>">
											<span class="label-status"><small><?= convertDate($value->dt_em_ass) ?></small></span>
										</td>
										<td class="text-center">
											<div class="pull-center">
											<span><a href="/download_file.php?file=<?= $link ?>" target="_blank"><i class="fa fa-eye" style="font-size:24px"></i></a></span>
											</div>
										</td>
										<td class="text-center">
											<?php if($this->nivel_acesso > 1){ ?>
												<a href="/ged/edit/id/<?= $value->codigo_cliente ?>/<?= $value->id ?>/"><i class="fa fa-edit" style="font-size:24px"></i></span></a>
												<a href="/ged/deletedoc/id/<?= $value->codigo_cliente ?>/<?= $value->id ?>/"  class="deletedoc" onclick="return confirm('Tem certeza que deseja apagar este arquivo?');"><i class="fa fa-trash" style="font-size:24px"></i></span></a>
											<?php } ?>
										</td>
									</tr>
								<?php } ?>
							<?php } ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</form>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript">
		$(function() {
			oTable = $('#list').DataTable({
				responsive: true,
				"order": [
					[ 1, "asc" ]
				],
				info: false,
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				},
				lengthMenu: [
					[ 10, 25, 50, -1 ],
					[ '10 linhas', '25 linhas', '50 linhas', 'Tudo' ]
				],
				dom: 'Bfrtip',
				lengthChange: true,
				buttons: [
					{
						extend: 'pageLength',
						text: 'PAGINAS',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'copyHtml5',
						text: 'COPY',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'csvHtml5',
						text: 'EXCEL',
						charset: 'utf-8',
						fieldSeparator: ';',
						bom: true,
						exportOptions: {
							columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14 ]
						}
					},
					{
						extend: 'pdfHtml5',
						text: 'PDF',
						exportOptions: {
							columns: [ 0, ':visible' ]
							//columns: [ 0, 1, 2, 5 ]
						}
					},
					{
						extend: 'colvis',
						text: 'COLUNAS',
					},
				],
			});		
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
