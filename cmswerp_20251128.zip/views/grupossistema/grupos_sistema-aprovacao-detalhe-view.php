<!DOCTYPE html>
<html class="no-js" lang="">

<head>
    <!-- INCLUDE DEFAULT HEAD CSS & METAS -->
    <?php include 'template/head-css.inc' ?>
    <!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
    <!-- PAGE STYLES -->
    <script type="text/javascript">
        var sidebarItem = "grupos_sistema";
    </script>
    <!-- <link rel="stylesheet" href="/assets/css/table_cabecalho.css"> -->
    <!-- /PAGE STYLES -->
    <title>Grupos de Sistema</title>

</head>

<body>

    <!-- MENU + WRAPPER -->
    <?php include "template/menu-wrapper.php" ?>
    <!-- /MENU + WRAPPER -->
    <!-- HEADER -->
    <ol class="breadcrumb">
        <li>Tarifas.cmsw.com</li>
        <li>Grupos de Sistema</li>
        <li>Detalhes Aprovação</li>
    </ol>
    <h4 class="page-title"><i class="fa fa-caret-right"></i> DETALHES APROVAÇÃO</h4>

    <div class="container-fluid">
        <form class="form-inline page-toolbar" id="form_filter_espelho" name="form_filter_espelho" method="post">
            <div class="pull-left">
                <div class="form-group">
                    <div class="btn-group" role="group">
                        <button type="button" id="novo_grupo" class="btn btn-success"><i class="fa fa-check"></i>
                            <b>Novo Grupo</b> </button>
                    </div>
                </div>
                <div class="form-group">
                    <div class="btn-group" role="group">
                        <button type="button" id="excluir_grupo" class="btn btn-danger"><i class="fa fa-ban"></i>
                            <b>Excluir Grupo</b> </button>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group">
                        <div class="">
                            &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                        </div>
                    </div>
                </div>
            </div>
            <br></br><br>
        </form>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <div class="tab-content">
                        <div id="home" class="tab-pane fade in active">
                            <div class="table-responsive">
                                <table id='table_jornada' class="datatable table table-hover table-bordered">
                                    <thead>
                                        <tr>
                                            <th width="5"> </th>
                                            <th width="5">ID</th>
                                            <th width="100">Nome</th>
                                            <th width="100">TIPO</th>
                                            <th width="100">VISUALIZAR</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if ($grupos_sistema) { ?>
                                            <?php foreach ($grupos_sistema as $key => $value) { ?>
                                                <tr>
                                                    <td class="text-center" style="vertical-align:middle" width="5%"> <input
                                                            class='form-check-input grupos_sistema' type='checkbox'
                                                            name="grupos_sistema[]" value="<?= $value->id; ?>"> </td>
                                                    <td class="text-center" style="vertical-align:middle" width="5%">
                                                        <?= $value->id; ?>
                                                    </td>
                                                    <td width="60%"><?= $value->nome; ?></td>
                                                    <td width="20%"><?= $value->tipo_grupo; ?></td>
                                                    <td width="10%" style="justify-content: center;text-align: center">
                                                        <a href="/grupossistema/grupodetalhes/<?= $value->id ?>"
                                                            class="btn btn-primary btn-sm open_jornada_dias"> <b><i
                                                                    class="fa fa-eye"></i></b></a>
                                                    </td>
                                                </tr>
                                            <?php } ?>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- </form> -->
    </div>

    <!-- MODAL NOVO GRUPO -->
    <div class="modal" id="modal_novo_grupo" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content modal-lg">
                <div class="modal-header">
                    <button type="button" class="close action_close_pendencia" data-dismiss="modal">
                        <span>x</span>
                    </button>
                    <div class="col-md-12">
                        <h4 class="modal-title" id="descricao">NOVO GRUPO </h4>
                    </div>
                </div>

                <div class="modal-body">
                    <form id="form_novo_grupo" method="POST">
                        <div class="container-fluid">
                            <div class="span12">

                                <div class="form-group col-md-4" style="margin-right:5%;margin-left:5%">
                                    <label>NOME:</label>
                                    <input type="text" class="form-control" placeholder="Nome do grupo" name="nome"
                                        id="nome" required> </input>
                                </div>

                                <div class="col-md-4">
                                    <label>TIPO:</label>
                                    <select class="search form-control" name="tipo" id="tipo" required>
                                        <option value=""> Selecione </option>
                                        <option value="aprovacao">Aprovação</option>
                                        <option value="combo">Combo</option>
                                        <option value="equipe">Equipe</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-success" style="font-size:10px;font-weight:bold">
                                    <b>SALVAR</b> </button>
                                <button type="button" class="btn btn-danger" data-dismiss="modal"
                                    style="font-size:10px;font-weight:bold"> <b>FECHAR</b> </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- END MODAL NOVA JORNADA -->

    <!-- MODAL JORNADA -->
    <div class="modal" id="modal_jornada" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-xl" role="document" style="width:80%;">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close action_close_pendencia" data-dismiss="modal">
                        <span>x</span>
                    </button>
                    <div class="text-left" role="group" style="margin-right:4%">
                        <div class="col-md-12">
                            <h4 class="modal-title" id="descricao_jornada"> <b id="b_descricao_jornada"> </b></h4>
                        </div>
                    </div>
                </div>
                <div class="modal-body">
                    <div class="col-md-12">
                        <div class="col-md-12">
                            <fieldset>
                                <legend style="text-align:center;font-size:16px; letter-spacing: 0.8em;">ADICIONAR
                                    FUNCIONÁRIO</legend>
                            </fieldset>
                            <br>
                            <div class="col-md-12">
                                <div class="col-md-6">
                                    <select class='search form-control' name='funcionarios_jornada'
                                        id='funcionarios_escala'>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <div class="input-group col-md-12">
                                        <span class="input-group-addon">A partir: <i class="fa fa-calendar"></i></span>
                                        <input type="text" name="data_jornada" id="data_inicio"
                                            class="form-control datepast" value="<?= date('d/m/Y') ?>" size=8
                                            autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <button type="button" class="btn btn-success processa_jornada" style="width:100%">
                                        <i class="fa fa-plus"> </i>
                                        Adicionar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <br>
                        <hr>
                        <fieldset>
                            <legend style="text-align:center;font-size:16px; letter-spacing: 0.8em;">FUNCIONÁRIOS
                            </legend>
                        </fieldset>
                    </div>
                    <div class="container-fluid">
                        <div class="col-md-12">
                            <div class="table_fixo" style="overflow-y:scroll;max-height: 500px">
                                <table
                                    class=" table-default table-striped table-bordered table-hover display responsive nowrap"
                                    width="100%" id="table_modal_jornada">
                                    <thead>
                                        <tr>
                                            <th style="text-align:center">ID</th>
                                            <th style="text-align:center">Nome</th>
                                            <th>Departamento</th>
                                            <th style="text-align:center">Data Inicio</th>
                                            <th style="text-align:center">Data Fim</th>
                                            <th>Excluir</th>
                                        </tr>
                                    </thead>
                                    <tbody id="usuarios_jornada">

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <br><br>
                </div>
                <div class="modal-footer">
                    <div class="col-md-12">
                        <label type="hidden" id="erro_modal_jornada" style="margin-right:40%;color:red;"></label>
                        <label type="hidden" id="sucesso_modal_jornada" style="margin-right:45%;color:green;"></label>
                        <button type="button" class="btn btn-danger" id="button_close"
                            style="font-size:10px;font-weight:bold"> <b>FECHAR</b> </button>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- END JORNADA -->

    <!-- MODAL JORNADA DIAS -->
    <div class="modal fade" id="modal_jornada_dias" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close action_close_jornada_dias" data-dismiss="modal">
                        <span>x</span>
                    </button>
                    <h4 class="modal-title"><b id="b_nome_jornada"> </b></h4>
                </div>
                <form name="jornada_dias" id="jornada_dias" method="POST">
                    <div class="modal-body">
                        <br>
                        <div id="table_jornada_dias">
                            <table
                                class="datatable table-default table-striped table-bordered table-hover display responsive nowrap"
                                width="100%">
                                <thead style="background-color: #EFEFEF;" id="thead_registro">
                                    <tr role="row" style="">
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> DIA SEMANA </th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> ENTRADA </th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> ENTRADA MIN </th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> ENTRADA MAX </th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> SAÍDA </th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> SAÍDA MIN</th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> SAÍDA MAX</th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> HORAS ALMOÇO</th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> HORAS ALMOÇO MÁXIMA</th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> SAÍDA MÍN ALMOÇO</th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> RETORNO ALMOÇO MAX</th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> NÚCLEO INICIO</th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> NÚCLEO FIM </th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> EXTRA MIN</th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> EXTRA MAX </th>
                                    </tr>
                                </thead>
                                <tbody id="tbody_jornada_dias">

                                </tbody>
                            </table>
                        </div>

                    </div>
                </form>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger action_close_demais_batidas" data-dismiss="modal"
                        style="font-size:10px;font-weight:bold">FECHAR</button>
                </div>
            </div>
        </div>
    </div>
    <!-- END MODAL JORNADA DIAS -->

    <!-- INCLUDE DEFAULT SCRIPTS -->
    <?php include 'template/scripts.inc'; ?>
    <?php include "template/modal_sistema.php"; ?>
    <?php include "template/end-menu-wrapper.html"; ?>
    <script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
    <script>
        $(document).ready(function () {
            oTable = $('.datatable').DataTable({
                'select': { style: 'multi' },
                'columnDefs': [{
                    'targets': 0,
                    "orderable": false,
                }],
                'order': [
                    [1, 'asc']
                ],
                language: {
                    "url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
                },
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    ['10 rows', '25 rows', '50 rows', 'Show all']
                ],

                lengthChange: false,
                buttons: [{
                    extend: 'pageLength',
                    text: 'PAGINAS',
                    exportOptions: {
                        columns: [0, ':visible']
                    }
                },
                {
                    extend: 'copyHtml5',
                    text: 'COPY',
                    exportOptions: {
                        columns: [0, ':visible']
                    }
                },
                {
                    extend: 'excelHtml5',
                    text: 'EXCEL',
                    charset: 'utf-8',
                    bom: true,
                    exportOptions: {
                        //columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 11, 12, 13 ] // para quando quiser fixar as colunas a serem importadas
                        columns: ':visible'
                    }
                },
                {
                    extend: 'pdfHtml5',
                    text: 'PDF',
                    charset: 'utf-8',
                    bom: true,
                    exportOptions: {
                        columns: ':visible'
                        //columns: [ 0, 1, 2, 5 ]
                    }
                },
                {
                    extend: 'colvis',
                    text: 'COLUNAS',
                },
                ]
            });

            $('#novo_grupo').click(function () {
                $('#modal_novo_grupo').modal('show');
            });

            $('#form_novo_grupo').submit(function (e) {
                e.preventDefault();
                $.ajax({
                    url: "<?= HOME_URI . $this->nome_modulo . '/novoGrupo' ?>",
                    type: 'POST',
                    data: new FormData(this),
                    contentType: false,
                    cache: false,
                    processData: false,
                    beforeSend: function () {
                        waitingDialog.show("PROCESSANDO...")
                    },
                    success: function (dados) {
                        waitingDialog.hide();
                        retorno_json = JSON.parse(dados);
                        if (retorno_json.codigo == 0) {
                            $('#painel_success_msg').html(retorno_json.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            // $('#modal_sucesso_sistema').on('hide.bs.modal', function () {
                            //     location.reload();
                            // });
                        } else {
                            $('#painel_error_msg').html(retorno_json.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function (erro) {
                        $('#painel_error_msg').html(retorno_json.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }
                })
            })

            //EXCLUIR GRUPO 

            $('#excluir_grupo').click(function () {
                grupos = [];
                $.each($("input[name='grupos_sistema[]']:checked"), function () {
                    grupos.push($(this).val());
                });
                if (grupos.length == 0) {
                    alert('Selecione ao menos um grupo!');
                    return;
                }
                if (confirm("Tem certeza que deseja excluir esse grupo?")) {
                    excluirGrupos(grupos);
                }
            })

            function excluirGrupos(grupos) {
                $.ajax({
                    type: 'POST',
                    url: "/grupossistema/excluirGrupo/" + grupos,
                    data: JSON.stringify(grupos),
                    contentType: 'json',
                    processData: false,
                    beforeSend: function () {
                        waitingDialog.show("PROCESSANDO ..");
                    },
                    success: function (dados) {
                        waitingDialog.hide();
                        let retorno = JSON.parse(dados);
                        if (retorno.codigo == 0) {
                            $('#painel_success_msg').html(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('#modal_sucesso_sistema').on('hidden.bs.modal', function () {
                                $('#modal_pendencias').modal('hide');
                                window.location.reload();
                            });
                        } else {
                            $('#painel_error_msg').html(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function (erro) {
                        $('#painel_error_msg').html(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }
                });
            };

        });
    </script>