<!DOCTYPE html>
<html class="no-js" lang="">

<head>
    <!-- INCLUDE DEFAULT HEAD CSS & METAS -->
    <?php include 'template/head-css.inc' ?>
    <!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
    <!-- PAGE STYLES -->
    <script type="text/javascript">
        var sidebarItem = "grupos_sistema";
    </script>
    <!-- <link rel="stylesheet" href="/assets/css/table_cabecalho.css"> -->
    <!-- /PAGE STYLES -->
    <title>Grupos de Sistema</title>

</head>

<body>

    <!-- MENU + WRAPPER -->
    <?php include "template/menu-wrapper.php" ?>
    <!-- /MENU + WRAPPER -->
    <!-- HEADER -->
    <ol class="breadcrumb">
        <li>Tarifas.cmsw.com</li>
        <li>Grupos de Sistema</li>
        <li>Detalhes Combo</li>
    </ol>
    <h4 class="page-title"><i class="fa fa-caret-right"></i> DETALHES COMBO - <?= $grupo[0]->nome ?></h4>

    <form type="post" id="form_edita_combo" name="form_edita_combo">
        <input type="hidden" name="id" value="<?= $grupo[0]->id ?>">
        <div class="container-fluid" style="background-color: #EFEFEF;margin: 10px;padding: 10px">
            <div class="col-md-12" style="padding: 10px">
                <div class="col-md-4">
                    <label>NOME:</label>
                    <input type="text" class="form-control" value=" <?= $grupo[0]->nome ?>" readonly disabled/>
                </div>
                <div class="col-md-2">
                    <label>TIPO:</label>
                    <input type="text" class="form-control" value=" <?= $grupo[0]->tipo_grupo ?>" readonly disabled/>
                </div>
            </div>
            <div class="">
                <div class="col-md-12">
                    <button type="button" class="btn btn-success" id="btn_add_regra"
                        style="font-size:10px;font-weight:bold;margin-top: 10px"> <b> <i class="fa fa-plus"></i> ADD
                            REGRA</b> </button>
                    <button type="button" class="btn btn-warning" id="btn_show_regras"
                        style="font-size:10px;font-weight:bold;margin-top: 10px"> <b> <i class="fa fa-eye"></i> REGRAS
                            APLICADAS</b> </button>
                </div>
            </div>
        </div>
    </form>
    </br>
    <form class="form-inline page-toolbar" id="" name="" method="post" style="margin-left: 0;">
        <div class="pull-left">
            <div class="form-group">
                <div class="btn-group" role="group">
                    <button type="button" id="novo_grupo" class="btn btn-success"><i class="fa fa-plus"></i>
                        <b>Adicionar Módulo</b> </button>
                </div>
            </div>
            <div class="form-group">
                <div class="btn-group" role="group">
                    <button type="button" id="excluir_modulos" class="btn btn-danger"><i class="fa fa-ban"></i>
                        <b>Remover Módulos</b> </button>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="">
                        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                    </div>
                </div>
            </div>
        </div>
        <br><br>
    </form>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="tab-content">
                    <div id="home" class="tab-pane fade in active">
                        <div class="table-responsive">
                            <table id='' class="datatable table table-hover table-bordered">
                                <thead>
                                    <tr>
                                        <th width="5"> </th>
                                        <th width="10">ID</th>
                                        <th width="20">CÓDIGO</th>
                                        <th width="50">DESCRIÇÃO</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $selecionados = [];
                                    if ($dadosGrupo) { ?>
                                        <?php foreach ($dadosGrupo as $key => $value) {
                                            $selecionados[] = $value->id_modulo; ?>
                                            <tr>
                                                <td class="text-center" style="vertical-align:middle" width="5%"> <input
                                                        class='form-check-input curr_modulo' type='checkbox'
                                                        name="curr_modulo[]" value="<?= $value->id; ?>"> </td>
                                                <td class="text-center" style="vertical-align:middle" width="5%">
                                                    <?= $value->id; ?>
                                                </td>
                                                <td><?= $value->codigo; ?></td>
                                                <td><?= $value->descricao; ?></td>
                                            </tr>
                                        <?php } ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- </form> -->
    </div>

    <!-- MODAL ADICIONAR MÓDULO -->
    <div class="modal" id="modal_add_modulo" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content modal-lg">
                <div class="modal-header">
                    <button type="button" class="close action_close_pendencia" data-dismiss="modal">
                        <span>x</span>
                    </button>
                    <div class="col-md-12">
                        <h4 class="modal-title" id="descricao">ADICIONAR MÓDULO </h4>
                    </div>
                </div>
                <div class="modal-body">
                    <div class="container-fluid">
                        <table class=" table table-hover table-bordered datatable2">
                            <thead>
                                <tr>
                                    <th width="10"></th>
                                    <th width="10">ID</th>
                                    <th width="20">CÓDIGO</th>
                                    <th width="50">DESCRIÇÃO</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($modulos) { ?>

                                    <?php foreach ($modulos as $key => $value) {
                                        if (in_array($value->id, $selecionados, true)) { ?>
                                            <tr>
                                                <td class="text-center" style="vertical-align:middle" width="5%">
                                                    <input class='form-check-input add_modulo' type='checkbox' name="add_modulo[]"
                                                        value="<?= $value->id; ?>" checked>
                                                </td>
                                                <td><?= $value->id; ?></td>
                                                <td><?= $value->codigo; ?></td>
                                                <td><?= $value->descricao; ?></td>
                                            </tr>
                                        <?php }
                                    }
                                    foreach ($modulos as $key => $value) {
                                        if (!in_array($value->id, $selecionados, true)) { ?>
                                            <tr>
                                                <td class="text-center" style="vertical-align:middle" width="5%">
                                                    <input class='form-check-input add_modulo' type='checkbox' name="add_modulo[]"
                                                        value="<?= $value->id; ?>">
                                                </td>
                                                <td><?= $value->id; ?></td>
                                                <td><?= $value->codigo; ?></td>
                                                <td><?= $value->descricao; ?></td>
                                            </tr>
                                        <?php }
                                    }
                                } ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <div class="col-md-12">
                            <button id="btn-add-module" type="button" class="btn btn-success"
                                style="font-size:10px;font-weight:bold">
                                <b>SALVAR</b> </button>
                            <button type="button" class="btn btn-danger" data-dismiss="modal"
                                style="font-size:10px;font-weight:bold"> <b>FECHAR</b> </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL MOSTRAR REGRAS -->
    <div class="modal" id="modal_regras" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content modal-lg">
                <div class="modal-header">
                    <button type="button" class="close action_close_pendencia" data-dismiss="modal">
                        <span>x</span>
                    </button>
                    <div class="col-md-12">
                        <h4 class="modal-title" id="descricao">LISTA DE REGRAS </h4>
                    </div>
                </div>
                <div class="modal-body">
                    <div class="container-fluid">
                        <table class=" table table-hover table-bordered datatable2">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th width="10">TIPO REGRA</th>
                                    <th width="20">BASE EM</th>
                                    <!-- <th width="50">BASE REGRA</th> -->
                                    <th width="50">BASE CONDICIONAL</th>
                                    <th width="50">BASE VALOR</th>
                                    <th width="50">REGRA TIPO</th>
                                    <th width="50">REGRA VALOR</th>
                                    <th>STATUS</th>
                                    <th></th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($regras) {
                                    $base_regra = [
                                        '>' => 'MAIOR QUE',
                                        '>=' => 'MAIOR OU IGUAL A',
                                        '<' => 'MENOR QUE',
                                        '<=' => 'MENOR OU IGUAL A',
                                        '=' => 'IGUAL A',
                                        '!=' => 'DIFERENTE DE'
                                    ];

                                    foreach ($regras as $key => $value) { ?>
                                        <tr>
                                            <td><?= $value->id; ?></td>
                                            <td><?= $value->tipo_regra; ?></td>
                                            <td><?= $value->base_tipo; ?></td>
                                            <td><?= $base_regra[$value->base_regra]; ?></td>
                                            <td><?= $value->base_tipo == 'valor' ? 'R$ ' . $value->base_valor : $value->base_valor; ?>
                                            </td>
                                            <td><?= $value->regra_tipo; ?></td>
                                            <td><?= $value->regra_tipo == 'valor' ? 'R$ ' . $value->regra_valor : $value->regra_valor . '%'; ?>
                                            </td>
                                            <td><?= $value->deleted == 0 ? 'ATIVO' : 'DELETADO'; ?></td>
                                            <td>
                                                <?php if ($value->deleted == 0) { ?>
                                                    <button type='button' class='btn btn-danger btn-sm btn_deletar_regra'
                                                        value='<?= $value->id ?>'><i class='fa fa-trash'></i></button>
                                                <?php } else { ?>
                                                    <button type='button' class='btn btn-warning btn-sm btn_historico_regra'
                                                        value='<?= $value->id ?>'><i class='fa fa-eye'></i></button>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                    <?php }
                                } ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <div class="col-md-12">
                            <button type="button" class="btn btn-danger" data-dismiss="modal"
                                style="font-size:10px;font-weight:bold"> <b>FECHAR</b> </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- MODAL MOSTRAR HISTORICO EXCLUSAO REGRA -->
    <div class="modal" id="modal_historico_regras" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content modal-lg">
                <div class="modal-header">
                    <button type="button" class="close action_close_pendencia" data-dismiss="modal">
                        <span>x</span>
                    </button>
                    <div class="col-md-12">
                        <h4 class="modal-title" id="descricao">HISTORICO EXCLUSAO REGRA </h4>
                    </div>
                </div>
                <div class="modal-body">
                    <div class="container-fluid">
                            <table class=" table table-hover table-bordered" id="table_historico_regras">
                                <thead>
                                <tr>
                                    <th width="10">EXCLUÍDO POR</th>
                                    <th width="20">EXCLUÍDO EM</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                    <div class="modal-footer">
                        <div class="col-md-12">
                            <button type="button" class="btn btn-danger" data-dismiss="modal"
                                style="font-size:10px;font-weight:bold"> <b>FECHAR</b> </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL ADICIONAR REGRA -->
    <div class="modal" id="modal_regra" tabindex="-1" role="dialog">
        <form id="form_add_regra" method="post">
            <input type="hidden" name="id" value="<?= $grupo[0]->id ?>">
            <div class="modal-dialog modal-xl" role="document" style="width:80%;">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close action_close_pendencia" data-dismiss="modal">
                            <span>x</span>
                        </button>
                        <div class="text-left" role="group" style="margin-right:4%">
                            <div class="col-md-12">
                                <h4 class="modal-title" id="descricao_jornada"> <b id="b_descricao_jornada"> </b></h4>
                            </div>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="col-md-12">
                            <fieldset>
                                <legend style="text-align:center;font-size:16px; letter-spacing: 0.8em;">ADICIONAR REGRA
                                </legend>
                            </fieldset>
                        </div>
                        <div class="container-fluid">
                            <div class="col-md-2">
                                <label>APLICAR:</label>
                                <select class="search form-control" name="tipo_regra" id="tipo_regra" required>
                                    <option value=""> Selecione </option>
                                    <option value="desconto"> Desconto </option>
                                    <option value="acrescimo">Acréscimo</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label>BASE EM:</label>
                                <select class="search form-control ref_element" name="base_tipo" id="base_tipo" required
                                    data-ref="base_valor">
                                    <option value=""> Selecione </option>
                                    <option value="transacoes"> Transações</option>
                                    <option value="valor">Valor </option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label>BASE CONDICIONAL:</label>
                                <select class="form-control" name="base_regra" id="base_regra" required>
                                    <option value=""> Selecione </option>
                                    <option value=">">Maior que</option>
                                    <option value=">=">Maior ou igual a</option>
                                    <option value="<">Menor que</option>
                                    <option value="<=">Menor ou igual a</option>
                                    <option value="=">Igual a</option>
                                    <option value="!=">Diferente de</option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label>BASE VALOR:</label>
                                <input type="text" class="form-control my_money" placeholder="Valor" name="base_valor"
                                    id="base_valor" required> </input>
                            </div>
                            <div class="col-md-2">
                                <label>REGRA TIPO:</label>
                                <select class="form-control ref_element" name="regra_tipo" id="regra_tipo" required
                                    data-ref="regra_valor">
                                    <option value=""> Selecione </option>
                                    <option value="porcentagem"> Porcentagem </option>
                                    <option value="valor">Valor </option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label>REGRA VALOR:</label>
                                <input type="text" class="form-control my_money" placeholder="Valor" name="regra_valor"
                                    id="regra_valor" required> </input>
                            </div>
                        </div>
                        <br><br>
                    </div>
                    <div class="modal-footer">
                        <div class="col-md-12">
                            <label type="hidden" id="erro_modal_jornada" style="margin-right:40%;color:red;"></label>
                            <label type="hidden" id="sucesso_modal_jornada"
                                style="margin-right:45%;color:green;"></label>
                            <button type="submit" class="btn btn-success" style="font-size:10px;font-weight:bold">
                                <b>SALVAR</b> </button>
                            <button type="button" class="btn btn-danger" id="button_close" data-dismiss="modal"
                                style="font-size:10px;font-weight:bold"> <b>FECHAR</b> </button>
                        </div>
                    </div>

                </div>
            </div>
        </form>
    </div>
    <!-- END JORNADA -->

    <!-- MODAL JORNADA DIAS -->
    <div class="modal fade" id="modal_jornada_dias" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close action_close_jornada_dias" data-dismiss="modal">
                        <span>x</span>
                    </button>
                    <h4 class="modal-title"><b id="b_nome_jornada"> </b></h4>
                </div>
                <form name="jornada_dias" id="jornada_dias" method="POST">
                    <div class="modal-body">
                        <br>
                        <div id="table_jornada_dias">
                            <table
                                class="datatable table-default table-striped table-bordered table-hover display responsive nowrap"
                                width="100%">
                                <thead style="background-color: #EFEFEF;" id="thead_registro">
                                    <tr role="row" style="">
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> DIA SEMANA </th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> ENTRADA </th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> ENTRADA MIN </th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> ENTRADA MAX </th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> SAÍDA </th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> SAÍDA MIN</th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> SAÍDA MAX</th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> HORAS ALMOÇO</th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> HORAS ALMOÇO MÁXIMA</th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> SAÍDA MÍN ALMOÇO</th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> RETORNO ALMOÇO MAX</th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> NÚCLEO INICIO</th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> NÚCLEO FIM </th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> EXTRA MIN</th>
                                        <th id="th_id" class="text-center"
                                            style="font-size:11px;vertical-align:middle;"> EXTRA MAX </th>
                                    </tr>
                                </thead>
                                <tbody id="tbody_jornada_dias">

                                </tbody>
                            </table>
                        </div>

                    </div>
                </form>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger action_close_demais_batidas" data-dismiss="modal"
                        style="font-size:10px;font-weight:bold">FECHAR</button>
                </div>
            </div>
        </div>
    </div>
    <!-- END MODAL JORNADA DIAS -->

    <!-- INCLUDE DEFAULT SCRIPTS -->
    <?php include 'template/scripts.inc'; ?>
    <?php include "template/modal_sistema.php"; ?>
    <?php include "template/end-menu-wrapper.html"; ?>
    <script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
    <script>
        $(document).ready(function () {

            $('.my_money').maskMoney({ allowNegative: false, thousands: '.', decimal: ',', prefix: 'R$ ' });

            $.each($("input[name='add_modulo[]']:checked"), function () {
                $(this).attr("disabled", 'disabled');
            });

            oTable = $('.datatable').DataTable({
                'select': { style: 'multi' },
                'columnDefs': [{
                    'targets': 0,
                    "orderable": false,
                }],
                'order': [
                    [1, 'asc']
                ],
                language: {
                    "url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
                },
                dom: 'Bfrtip',
                lengthMenu: [
                    [10, 25, 50, -1],
                    ['10 rows', '25 rows', '50 rows', 'Show all']
                ],

                lengthChange: false,
                buttons: [{
                    extend: 'pageLength',
                    text: 'PAGINAS',
                    exportOptions: {
                        columns: [0, ':visible']
                    }
                },
                {
                    extend: 'copyHtml5',
                    text: 'COPY',
                    exportOptions: {
                        columns: [0, ':visible']
                    }
                },
                {
                    extend: 'excelHtml5',
                    text: 'EXCEL',
                    charset: 'utf-8',
                    bom: true,
                    exportOptions: {
                        //columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 11, 12, 13 ] // para quando quiser fixar as colunas a serem importadas
                        columns: ':visible'
                    }
                },
                {
                    extend: 'pdfHtml5',
                    text: 'PDF',
                    charset: 'utf-8',
                    bom: true,
                    exportOptions: {
                        columns: ':visible'
                        //columns: [ 0, 1, 2, 5 ]
                    }
                },
                {
                    extend: 'colvis',
                    text: 'COLUNAS',
                },
                ]
            });

            $('.datatable2').DataTable({
                'select': { style: 'multi' },
                'columnDefs': [{
                    'targets': 0,
                    "orderable": false,
                }],
                language: {
                    "url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
                },
                dom: 'Bfrtip',
                lengthChange: false,
            });

            $('#novo_grupo').click(function () {
                $('#modal_add_modulo').modal('show');
            });

            $('#btn_show_regras').click(function () {
                $('#modal_regras').modal('show');
            });

            $('#form_novo_grupo').submit(function (e) {
                e.preventDefault();
                $.ajax({
                    url: "<?= HOME_URI . $this->nome_modulo . '/novoGrupo' ?>",
                    type: 'POST',
                    data: new FormData(this),
                    contentType: false,
                    cache: false,
                    processData: false,
                    beforeSend: function () {
                        waitingDialog.show("PROCESSANDO...")
                    },
                    success: function (dados) {
                        waitingDialog.hide();
                        retorno_json = JSON.parse(dados);
                        if (retorno_json.codigo == 0) {
                            $('#painel_success_msg').html(retorno_json.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            // $('#modal_sucesso_sistema').on('hide.bs.modal', function () {
                            //     location.reload();
                            // });
                        } else {
                            $('#painel_error_msg').html(retorno_json.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function (erro) {
                        $('#painel_error_msg').html(retorno_json.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }
                })
            })
            $('#form_add_regra').submit(function (e) {
                e.preventDefault();
                $.ajax({
                    url: "<?= HOME_URI . $this->nome_modulo . '/salvarregra' ?>",
                    type: 'POST',
                    data: new FormData(this),
                    contentType: false,
                    cache: false,
                    processData: false,
                    beforeSend: function () {
                        waitingDialog.show("PROCESSANDO...")
                    },
                    success: function (dados) {
                        waitingDialog.hide();
                        retorno_json = JSON.parse(dados);
                        if (retorno_json.codigo == 0) {
                            $('#painel_success_msg').html(retorno_json.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('#modal_sucesso_sistema').on('hide.bs.modal', function () {
                                location.reload();
                            });
                        } else {
                            $('#painel_error_msg').html(retorno_json.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function (erro) {
                        $('#painel_error_msg').html(retorno_json.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }
                })
            })

            //EXCLUIR MOÓDULOS 

            $('#excluir_modulos').click(function () {
                modulos = [];
                $.each($("input[name='curr_modulo[]']:checked"), function () {
                    modulos.push($(this).val());
                });

                if (modulos.length == 0) {
                    alert('Selecione ao menos um módulo!');
                    return;
                }

                if (confirm("Tem certeza que deseja excluir esse(s) módulo(s)?")) {
                    excluirModulos(modulos);
                }
            })

            function excluirModulos(modulos) {
                $.ajax({
                    type: 'POST',
                    url: "/grupossistema/excluirModulos/<?= $this->parametros[0] ?>" + "/" + modulos,
                    contentType: 'json',
                    processData: false,
                    beforeSend: function () {
                        waitingDialog.show("PROCESSANDO ..");
                    },
                    success: function (dados) {
                        waitingDialog.hide();
                        let retorno = JSON.parse(dados);
                        if (retorno.codigo == 0) {
                            $('#painel_success_msg').html(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('#modal_sucesso_sistema').on('hidden.bs.modal', function () {
                                $('#modal_pendencias').modal('hide');
                                window.location.reload();
                            });
                        } else {
                            $('#painel_error_msg').html(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function (erro) {
                        $('#painel_error_msg').html(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }
                });
            };

            $('#btn-add-module').click(function () {
                modulos = [];
                $.each($("input[name='add_modulo[]']:checked"), function () {
                    if (!$(this).attr('disabled')) {
                        modulos.push($(this).val());
                    }
                });
                if (modulos.length == 0) {
                    alert('Selecione ao menos um módulo!');
                    return;
                }

                $.ajax({
                    type: 'POST',
                    url: "<?= HOME_URI . $this->nome_modulo ?>/adicionarModulo/<?= $this->parametros[0] ?>/" + modulos,
                    beforeSend: function () {
                        waitingDialog.show("PROCESSANDO ..");
                    },
                    success: function (dados) {
                        waitingDialog.hide();
                        let retorno = JSON.parse(dados);
                        if (retorno.codigo == 0) {
                            $('#painel_success_msg').html(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('#modal_sucesso_sistema').on('hidden.bs.modal', function () {
                                $('#modal_pendencias').modal('hide');
                                window.location.reload();
                            });
                        } else {
                            $('#painel_error_msg').html(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function (erro) {
                        $('#painel_error_msg').html(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }
                });
            });

            $('#form_edita_combo').on('submit', function (e) {
                e.preventDefault();
                $.ajax({
                    url: "<?= HOME_URI . $this->nome_modulo . '/editarCombo' ?>",
                    type: 'POST',
                    data: new FormData(this),
                    contentType: false,
                    cache: false,
                    processData: false,
                    beforeSend: function () {
                        waitingDialog.show("PROCESSANDO...")
                    },
                    success: function (dados) {
                        waitingDialog.hide();
                        retorno_json = JSON.parse(dados);
                        if (retorno_json.codigo == 0) {
                            $('#painel_success_msg').html(retorno_json.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('#modal_sucesso_sistema').on('hide.bs.modal', function () {
                                location.reload();
                            });
                        } else {
                            $('#painel_error_msg').html(retorno_json.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function (erro) {
                        $('#painel_error_msg').html(retorno_json.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }
                })
            })


            $('#btn_add_regra').click(function () {
                $('#modal_regra').modal('show');
            });

            $('.ref_element').change(function () {
                const ref = $(this).attr('data-ref');
                const value = $(this).val();
                const target = '#' + ref;
                const value_target = $(target).maskMoney('unmasked')[0]

                $(target).unmask();
                $(target).off();

                if (value == 'valor') {
                    $(target).maskMoney({ allowNegative: false, thousands: '.', decimal: ',', prefix: 'R$ ' }).maskMoney('mask', value_target);
                } else if (value == 'porcentagem') {
                    $(target).mask('##0,00%', {
                        reverse: true,
                    })
                } else {
                    $(target).val(value_target);
                }
            })

            $('#regra_valor').on('keyup ', function () {
                if ($('#regra_tipo :selected').val() !== 'porcentagem') return;
                let val = $(this).val();

                if (!val) return;

                let cleanVal = val.replace('%', '').replace('.', '').replace(',', '.');

                let num = parseFloat(cleanVal);

                if (!isNaN(num)) {
                    let novoVal = num.toFixed(2).replace('.', ',') + '%';
                    $(this).val(novoVal);
                }
            });


            $('.btn_deletar_regra').click(function () {
                if (confirm('Tem certeza que deseja excluir essa regra?')) {
                    deletar_regra($(this).val());
                }
            });

            function deletar_regra(id) {
                $.ajax({
                    type: 'POST',
                    url: "<?= HOME_URI . $this->nome_modulo ?>/deletarRegra/" + id,
                    beforeSend: function () {
                        waitingDialog.show("PROCESSANDO ..");
                    },
                    success: function (dados) {
                        waitingDialog.hide();
                        let retorno = JSON.parse(dados);
                        if (retorno.codigo == 0) {
                            $('#painel_success_msg').html(retorno.mensagem);
                            $('#modal_sucesso_sistema').modal('show');
                            $('.btn_deletar_regra[value="' + id + '"]').closest('tr').remove()

                        } else {
                            $('#painel_error_msg').html(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function (erro) {
                        $('#painel_error_msg').html(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }
                });

            }

            $('.btn_historico_regra').click(function () {

                $.ajax({
                    type: 'GET',
                    url: "<?= HOME_URI . $this->nome_modulo ?>/historicoRegra/" + $(this).val(),
                    contentType: 'json',
                    beforeSend: function () {
                        waitingDialog.show("PROCESSANDO ..");
                    },
                    success: function (dados) {
                        waitingDialog.hide();
                        let retorno = JSON.parse(dados);
                        if (retorno.codigo == 0) {
                            const table = $('#table_historico_regras');
                            table.find('tbody').html('');
                            const historico = JSON.parse(retorno.output);
                            for (let i = 0; i < historico.length; i++) {
                                const tr = `<tr>
                                    <td>${historico[i].nome}</td>
                                    <td>${new Date(historico[i].alterado_em).toLocaleDateString()}</td>
                                </tr>`;
                                table.find('tbody').append(tr);
                            }

                            $('#modal_historico_regras').modal('show');

                        } else {
                            $('#painel_error_msg').html(retorno.mensagem);
                            $('#modal_erro_sistema').modal('show');
                        }
                    },
                    erro: function (erro) {
                        $('#painel_error_msg').html(retorno.mensagem);
                        $('#modal_erro_sistema').modal('show');
                    }
                });
            });

        });
    </script>