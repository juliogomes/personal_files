<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "home";
	</script>
	<!-- /PAGE STYLES -->

	
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Home</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> Home</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<form name="form_contrato" >
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">

				</div>
			</div>
		</div>
	</form>
	
	<?php if($session->modulos->Sales->{68}->alcadas >= 2){ ?>

		<div id="dashboard" >

			<div class="col-md-12">
				<fieldset style="margin-top: 20px">
                    <legend>Dashboard</legend>
                </fieldset>
			</div>
			
			<!-- /.row -->

			<div class="row" style="margin:2%">
				
				<div class="col-lg-3 col-md-6">
					<div class="panel" style="background-color:#C0392B ; border:solid 2px; border-color:#F1948A ;  border-radius:20px 20px 20px 20px;">
						<div class="panel-heading">
							<div class="row">
								<div class="col-xs-3">
									<i class="fa fa-ban fa-5x" style="color:white"></i>
								</div>
								<div class="col-xs-9 text-right">
									<div class="huge"><span style="font-size:34px; font-weight:bold; color:white"><?=count($proposta_fora_padrao)?></span></div>
									<div style="color:white">Propostas pendentes fora do padrão!</div>
								</div>
							</div>
						</div>
						<a href="/propostas/fora_padrao">
							<div class="panel-footer" style="background-color:#C0392B ; border:solid 2px; border-color:#F1948A ;  border-radius:0px 0px 20px 20px;">
								<span class="pull-left" style="color:white; font-weight:bold">PROPOSTAS FORA DO PADRÃO</span>
								<div class="clearfix"></div>
							</div>
						</a>
					</div>
				</div>
											
				<div class="col-lg-3 col-md-6">
					<div class="panel" style="background-color:#D4AC0D ; border:solid 2px; border-color:#F4D03F ;  border-radius:20px 20px 20px 20px;">
						<div class="panel-heading">
							<div class="row">
							<div class="col-xs-3">
								<i class="fa fa-warning fa-5x" style="color:white"></i>
							</div>
							<div class="col-xs-9 text-right">
								<div class="huge"><span style="font-size:34px; font-weight:bold; color:white;"><?=count($propostas_pendente)?></span></div>
								<div style="color:white">Propostas Pendentes!</div>
							</div>
						</div>
					</div>
						<a href="/propostas/pendente">
							<div class="panel-footer" style="background-color:#D4AC0D; border:solid 2px; border-color:#F4D03F ;  border-radius:0px 0px 20px 20px;">
							<span class="pull-left" style="color:white; font-weight:bold">PROPOSTAS PENDENTES</span>
							
							<div class="clearfix"></div>
							</div>
						</a>
					</div>
				</div>

				<div class="col-lg-3 col-md-6">
					<div class="panel" style="background-color:#1E8449; border:solid 2px; border-color:#D5F5E3 ;  border-radius:20px 20px 20px 20px;">
						<div class="panel-heading">
							<div class="row">
								<div class="col-xs-3">
									<i class="fa fa-check fa-5x" style="color:white"></i>
								</div>
								<div class="col-xs-9 text-right">
									<div class="huge"><span style="font-size:34px; font-weight:bold; color:white"><?=count($propostas_fechada)?></span></div>
									<div style="color:white">Propostas Aprovadas!</div>
								</div>
							</div>
						</div>
						<a href="/propostas/aprovada">
							<div class="panel-footer" style="background-color:#1E8449; border:solid 2px; border-color:#D5F5E3 ;  border-radius:0px 0px 20px 20px;">
								<span class="pull-left" style="color:white; font-weight:bold">PROPOSTAS APROVADAS</span>
								<div class="clearfix"></div>
							</div>
						</a>
					</div>
				</div>

				<div class="col-lg-3 col-md-6">
					<div class="panel"  style="background-color:#2874A6 ; border:solid 2px; border-color:#D6EAF8  ;  border-radius:20px 20px 20px 20px;">
						<div class="panel-heading">
							<div class="row">
							<div class="col-xs-3">
								<i class="fa fa-plus fa-5x" style="color:white"></i>
							</div>
							<div class="col-xs-9 text-right">
								<div class="huge"><span style="font-size:34px; font-weight:bold; color:white;"><?=count($records)?></span></div>
								<div style="color:white">Propostas Criadas!</div>
							</div>
							</div>
						</div>
						<a href="/propostas">
							<div class="panel-footer" style="background-color:#2874A6; border:solid 2px; border-color:#D6EAF8  ;  border-radius:0px 0px 20px 20px;">
							<span class="pull-left" style="color:white; font-weight:bold"> PROPOSTAS CRIADAS</span>
							
							<div class="clearfix"></div>
							</div>
						</a>
					</div>
				</div>
			
			</div>
			<br>

			<div class="" style="margin-left:5%">
						
				<div class="col-lg-7">
					
					<div class="panel panel-default">
						<div class="panel-heading">
							<i class="fa fa-bar-chart-o fa-fw"></i> Propostas aprovadas por mês
							<div class="pull-right">
								
							</div>
						</div>
						<div class="panel-body">
							<div id="morris-area-chart"></div>
						</div>
					</div>

					<div class="panel panel-default">
						<div class="panel-heading">
							<i class="fa fa-bar-chart-o fa-fw"></i> Propostas aprovadas por Owner	
							<div class="pull-right"> Mês: <?php echo $data_extenso ?> </div>						
						</div>
						<div id="morris-bar-chart"></div>
              		</div>

				</div>
						
				<div class="col-lg-5">
					<div class="panel panel-default">
						<div class="panel-heading">
							<i class="fa fa-bell fa-fw"></i> Painel de notificações
						</div>
						
						<div class="panel-body">
							<div class="list-group-header">
							
							</div>
							<div class="list-group">

							<a href="#" class="list-group-item">
								<div class="list-group-column">Ultimas propostas:  </div> <span class="pull-right"> <?= $this->data_hora_atual->format('Y-m-d'); ?> <span>
							</a>

							<a href="/propostas/detalhe/id_propostas/<?=$records[0]->id?>/" class="list-group-item">
								<i class="fa fa-plus fa-fw"></i> <?=$records[0]->cliente?> | ID: <?=$records[0]->id?>
								<span class="pull-right text-muted small"><em><?=$records[0]->data_criacao?></em></span>
							</a>

							<a href="/propostas/detalhe/id_propostas/<?=$records[1]->id?>/" class="list-group-item">
								<i class="fa fa-plus fa-fw"></i> <?=$records[1]->cliente?> | ID: <?=$records[1]->id?>
								<span class="pull-right text-muted small"><em><?=$records[1]->data_criacao?></em></span>
							</a>

							<a href="/propostas/detalhe/id_propostas/<?=$records[2]->id?>/" class="list-group-item">
								<i class="fa fa-plus fa-fw"></i>  <?=$records[2]->cliente?> | ID: <?=$records[2]->id?>
								<span class="pull-right text-muted small"><em><?=$records[2]->data_criacao?></em></span>
							</a>

							<a href="/propostas/detalhe/id_propostas/<?=$records[3]->id?>/" class="list-group-item">
								<i class="fa fa-plus fa-fw"></i> <?=$records[3]->cliente?> | ID: <?=$records[3]->id?>
								<span class="pull-right text-muted small"><em><?=$records[3]->data_criacao?></em></span>
							</a>

							<a href="/propostas/detalhe/id_propostas/<?=$records[4]->id?>/" class="list-group-item">
								<i class="fa fa-plus fa-fw"></i> <?=$records[4]->cliente?> | ID: <?=$records[4]->id?>
								<span class="pull-right text-muted small"><em><?=$records[4]->data_criacao?></em></span>
							</a>
							
						</div>
						
					</div>
				</div>	
				<br>
				<div class="panel panel-default">
					<div class="panel-heading">
						<i class="fa fa-bar-chart-o fa-fw"></i> Grafico de Pizza
					</div>
					<div class="panel-body">
						<div id="morris-donut-chart"></div>
						
					</div>
				</div>

			</div>

		</div>		
	
	<?php } ?>

	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc'; ?>
	<?php include "template/modal_sistema.php"; ?>

	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script>

	<?php if($session->modulos->Sales->{68}->alcadas >= 2){ ?>
			
			var MorrisBarReturnObject;
			var MorrisDonutReturnObject;

			var janeiro = <?=count($proposta_janeiro)?>;
			var fevereiro = <?=count($proposta_fevereiro)?>;
			var marco = <?=count($proposta_marco)?>;
			var abril = <?=count($proposta_abril)?>;
			var maio = <?=count($proposta_maio)?>;
			var junho = <?=count($proposta_junho)?>;

			var julho = <?=count($proposta_julho)?>;
			var agosto = <?=count($proposta_agosto)?>;
			var setembro = <?=count($proposta_setembro)?>;
			var outubro = <?=count($proposta_outubro)?>;
			var novembro = <?=count($proposta_novembro)?>;
			var dezembro = <?=count($proposta_dezembro)?>;

			var data = new Date();
			var ano = data.getFullYear();

			$(function() {

				Morris.Area({
					element: 'morris-area-chart',
					
					xkey: 'year',
					ykeys: ['propostas'],
					
					data: [

						<?php if($mes_atual <= 06){ ?>

							<?php if($mes_atual >= 01){ ?>						
								{ year: ano+'-01', propostas: janeiro, },
							<?php } ?>
							<?php if($mes_atual >= 02){ ?>
								{ year: ano+'-02', propostas: favereiro, },
							<?php } ?>
							<?php if($mes_atual >= 03){ ?>
								{ year: ano+'-03', propostas: marco, },
							<?php } ?>
							<?php if($mes_atual >= 04){ ?>
								{ year: ano+'-04', propostas: abril, },
							<?php } ?>
							<?php if($mes_atual >= 05){ ?>
								{ year: ano+'-05', propostas: maio, },
							<?php } ?>
							<?php if($mes_atual == 06){ ?>
								{ year: ano+'-06', propostas: junho, },
							<?php } ?>

						<?php }else{ ?>

							<?php if($mes_atual >= 07){ ?>						
								{ year: ano+'-07', propostas: julho, },
							<?php } ?>
							<?php if($mes_atual >= 08){ ?>
								{ year: ano+'-08', propostas: agosto, },
							<?php } ?>
							<?php if($mes_atual >= 09){ ?>
								{ year: ano+'-09', propostas: setembro, },
							<?php } ?>
							<?php if($mes_atual >= 10){ ?>
								{ year: ano+'-10', propostas: outubro, },
							<?php } ?>
							<?php if($mes_atual >= 11){ ?>
								{ year: ano+'-11', propostas: novembro, },
							<?php } ?>
							<?php if($mes_atual == 12){ ?>
								{ year: ano+'-12', propostas: dezembro, },
							<?php } ?>
						
						<?php } ?>
					
					],

					labels: ['Propostas Criadas'],
					lineColors: ['#1E8449'],
					pointSize: 2,
					hideHover: 'false',
					resize: true
				});

			});

			MorrisBarReturnObject = Morris.Bar({
				element: 'morris-bar-chart',

				xkey: 'y',
				ykeys: ['a'],	
				
				data: [
					{ y: 'Analy', a: <?=count($proposta_aprovada_analy)?>, }, 
					{ y: 'Camila',	a: <?=count($proposta_aprovada_camila)?>, }, 
					{ y: 'Joseane', a: <?=count($proposta_aprovada_joseane)?>, }, 
					{ y: 'Kaique', a: <?=count($proposta_aprovada_kaique)?>, },
					{ y: 'Bruno', a: <?=count($proposta_aprovada_bruno)?>, }, 
					{ y: 'Fabiana', a: <?=count($proposta_aprovada_fabiana)?>, }, 
				],
				
				labels: ['Propostas'],
				barColors: ['#1E8449'],
				hideHover: 'false',
				resize: true
			});

			MorrisDonutReturnObject = Morris.Donut({
				element: 'morris-donut-chart',
				data: [{
				label: "Pendentes",
				value: <?=count($propostas_pendente)?>,
				
				}, {
				label: "Criadas",
				value: <?=count($records)?>
				}, {
				label: "Aprovadas",
				value: <?=count($propostas_fechada)?>
				}],
				resize: true,
				colors: ['#D4AC0D', '#2874A6', '#1E8449' ]
			});

			

			// This updates the data table beside the Morris.Bar 
			function buildTable(localTableDataJson, tagId) {
				console.log('building table for ' + tagId);
				var content = "";
				var header = "<thead><tr>";
				console.log(localTableDataJson.headers)
				for (var index in localTableDataJson.headers) {
					console.log('added header');
					header += "<th>" + localTableDataJson.headers[index] + "</th>";
				}
				header += "</tr></thead>";
				content += header + "<tbody>";

				for (var index in localTableDataJson.data) {

					content += "<tr>";
					jQuery.each(localTableDataJson.data[index], function(index2, dataColumn) {
					content += "<td>" + dataColumn + "</td>";
					});
					content += "</tr>";

				}

				content += "</tbody>"

				$('#' + tagId).empty();
				$('#' + tagId).append(content);
			}


	<?php } ?>

		
	</script>
	<!-- /PAGE SCRIPTS -->
	

</body>
</html>
