<?php
if ( !$this->logged_in )
{
	echo 'Efetue o login para acessar esse registro, clicando <a href="'.HOME_URI.'login/"> aqui </a>';
	exit;
}
?>
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
	<head>
		<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
		<?php include 'template/head-css.inc' ?>
		<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
		<!-- PAGE STYLES -->
		<script type="text/javascript">
			var sidebarItem = "impostos";
		</script>
		<style type="text/css" media="screen">
			input[type="radio"].styled:checked+label:after {
				font-family: 'FontAwesome';
				content: '';
			}
		</style>
		<!-- /PAGE STYLES -->
	</head>
	<body>
		<!-- MENU + WRAPPER -->
		<?php include "template/menu-wrapper.php" ?>
		<!-- /MENU + WRAPPER -->
		<!-- HEADER -->
		<ol class="breadcrumb">
			<li>Tarifas.cmsw.com</li>
			<li>Cadastros</li>
			<li>Impostos</li>
		</ol>
		<h4 class="page-title">
			<?php
			if(empty($this->parametros[1])){
				echo '<i class="fa fa-plus"></i> Novo imposto';
			}else{
				echo '<i class="fa fa-edit"></i> Editar imposto';
			}
			?>
		</h4>
		<!-- /HEADER -->
		<!-- CONTENT -->
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-12 col-md-6">
					<form id="form" action="<?php echo HOME_URI.'impostos/save/id/'.$this->parametros[1]; ?>" class="" method="post">
						<fieldset>
							<legend>Dados do Imposto</legend>
							<div class="form-group">
								<label for="nome_imposto">Nome:</label>
								<input type="text" class="form-control" placeholder="Nome" name="nome_imposto" id="nome_imposto" value="<?php echo isset($records)?$records[0]->nome_imposto:null ?>"/>
							</div>
							<div class="form-group">
								<label for="id_empresa_vendedora">EMPRESA C&M:</label>
								<select name="id_empresa_vendedora" id="id_empresa_vendedora" class="form-control select" >
									<?php if( $this->empresa_cm ){ ?>
										<option value="" > Selecione a empresa.... </option>
										<?php foreach( $this->empresa_cm as $key => $value ) { ?>
											<option value=" <?= $value->id ?>" <?= ( isset( $records[0]->id_empresa_vendedora ) && $records[0]->id_empresa_vendedora == $value->id )?'selected':null; ?> > <?= $value->razao_social; ?> </option>
										<?php } ?>
									<?php } ?>
								</select>
							</div>
							<div class="form-group">
								<label for="tipo">Tipo imposto:</label>
								<select class="form-control" name="tipo" id="tipo">
									<option value="municipal" <?= (isset($records) && $records[0]->tipo =='municipal')?'selected':null; ?>>Municipal</option>
									<option value="estadual" <?= (isset($records) && $records[0]->tipo =='estadual')?'selected':null; ?>>Estadual</option>
									<option value="federal" <?= (isset($records) && $records[0]->tipo =='federal')?'selected':null; ?>>Federal</option>
								</select>
							</div>
							<div class="form-group">
								<label for="imposto_incidente">Imposto incidente em:</label>
								<select class="form-control" name="imposto_incidente" id="imposto_incidente">
									<option value="com retencao" <?= (isset($records) && $records[0]->imposto_incidente =='com retencao')?'selected':null; ?>>Com retenção</option>
									<option value="sem retencao" <?= (isset($records) && $records[0]->imposto_incidente =='sem retencao')?'selected':null; ?> >Sem retenção</option>
									<option value="nao incidente" <?= (isset($records) && $records[0]->imposto_incidente =='nao incidente')?'selected':null; ?>>Não Incidente</option>
								</select>
							</div>
							<div class="form-group">
								<label for="aliquota">Aliquota:</label>
								<input type="text" class="form-control mask-money" placeholder="00.00%" name="aliquota" id="aliquota" value="<?php echo isset($records)?$records[0]->aliquota:null ?>"/>
							</div>
							<div class="form-group">
								<label for="descricao">Descrição:</label>
								<textarea class="form-control" name="descricao" id="descricao"><?php echo isset($records)?$records[0]->descricao:null ?></textarea>
							</div>
						</fieldset>
						<a href="/usuarios/lista/" class="btn btn-default"><i class="fa fa-times"></i> Cancelar</a>
						<button type="submit" class="btn btn-primary pull-right"><i class="fa fa-floppy-o"></i> Salvar</button>
					</form>
				</div>
			</div>
		</div>
		<!-- /.container-fluid -->
		<!-- /CONTENT -->
		<!-- END WRAPPER -->
		<?php include "template/end-menu-wrapper.html" ?>
		<!-- /END WRAPPER -->
		<!-- MODALS -->
		<!-- /MODALS -->
		<!-- INCLUDE DEFAULT SCRIPTS -->
		<?php include 'template/scripts.inc' ?>
		<!-- /INCLUDE DEFAULT SCRIPTS -->
		<!-- PAGE SCRIPTS -->
		<!-- Error Toaatr -->
		<?php if(!empty($this->modelo->error)){?> <script type="text/javascript"> $(function() {toastr.error('<?= $this->modelo->error ?>'); }); </script> <?php } ?>
		<!-- /Error Toaatr -->
		<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
		<script type="text/javascript">
			$(function() {
				$form = $('#form');
				$form.formValidation({
					framework: 'bootstrap',
					excluded: ':disabled',
					icon: {
						valid: 'fa fa-check',
						invalid: 'fa fa-times',
						validating: 'fa fa-refresh'
					},
					addOns: {
						mandatoryIcon: {
							icon: 'fa fa-asterisk'
						}
					},
					live: 'enabled',
					fields: {
						'nome':{
							validators:{
								notEmpty:{
									message:"Campo Obrigatório"
								}
							}
						},
						'email':{
							validators:{
								notEmpty:{
									message:"Campo Obrigatório"
								},
								regexp: {
									regexp: /^([\w\.\-_]+)?\w+@[\w-_]+(\.\w+){1,}$/i,
									message: 'Email mão é válido'
								}
							}
						},
						'perfil':{
							validators:{
								notEmpty:{
									message:"Campo Obrigatório"
								}
							}
						}
					}
				});
			});
		</script>
		<!-- /PAGE SCRIPTS -->
	</body>
</html>