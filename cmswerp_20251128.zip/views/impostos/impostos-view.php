<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "impostos";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Cadastros</li>
	</ol>
	<h4 class="page-title"><i class="fa fa-caret-right"></i> impostos</h4>
	<form class="form-inline page-toolbar">
		<div class="btn-group" role="group">
			<a href="/impostos/detalhe/id/0/" class="btn btn-default"><i class="fa fa-plus"></i> Novo Imposto</a>
		</div>
		<div class="pull-right">
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Imposto</div>
					<input class="form-control" type="text" id="search1" style="width:100px;">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Empresa</div>
					<input class="form-control" type="text" id="search2" style="width:155px;" >
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Tipo</div>
					<input class="form-control"  type="text" id="search3">
				</div>
			</div>
			<div class="form-group">
				<div class="input-group">
					<div class="input-group-addon">Incidente</div>
					<input class="form-control" type="text" id="search4">
				</div>
			</div>
		</div>
	</form>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<table id='list' class="table table-default table-striped table-bordered table-hover" width="100%">
					<thead>
						<tr role="row">
							<th class="text-left">Imposto</th>
							<th class="text-left">Empresa</th>
							<th class="text-left">Tipo</th>
							<th class="text-left">Incidente em</th>
							<th width="50" class="text-right">Aliquota</th>
							<th width="70" class="text-center"></th>
						</tr>
					</thead>
					<tbody>
						<?php if (is_array($records)){ ?>
						<?php foreach($records as $key => $value) {
						?>
						<tr>
							<td class="text-left"><span class="label-status"><small><?= $value->nome_imposto; ?></small></span></td>
							<td class="text-left"><span class="label-status"><small><?= $value->razao_social; ?></small></span></td>
							<td class="text-left"><span class="label-status"><small><?= $value->tipo; ?></small></span></td>
							<td class="text-left"><span class="label-status"><small><?= $value->imposto_incidente; ?></small></span></td>
							<td class="text-right"><span class="label-status"><small><?= $value->aliquota; ?></small></span></td>
							<td class="text-center">
								<div class="pull-right">
									<a class="btn btn-info btn-xs" href="/impostos/detalhe/id/<?= $value->id_imposto; ?>/"><i class="fa fa-edit"></i> </span> Editar</a>
								</div>
							</td>
						</tr>
						<?php } ?>
						<?php } ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<script type="text/javascript">
		$(function() {
			oTable = $('#list').DataTable({
				info: false,
				responsive: true,
				autoFill: true,
				dom: "<'panel panel-default'" +
				"tr" +
				"<'panel-footer'" +
				"<'row'<'col-sm-5'l><'col-sm-7'p>>" +
				">" +
				">",
				language: {
					"url": "/libs/DataTables-1.10.13/js/Portuguese-Brasil.json"
				},
				dom: 'Bfrtip',
				lengthMenu: [
					[ 10, 25, 50, -1 ],
					[ '10 rows', '25 rows', '50 rows', 'Show all' ]
				],
				lengthChange: false,
				buttons: [
					{
						extend: 'pageLength',
						text: 'PAGINAS',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'copyHtml5',
						text: 'COPY',
						exportOptions: {
							columns: [ 0, ':visible' ]
						}
					},
					{
						extend: 'excelHtml5',
						text: 'EXCEL',
						charset: 'utf-8',
						bom: true,
						exportOptions: {
							//columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 11, 12, 13 ] // para quando quiser fixar as colunas a serem importadas
							columns: ':visible'
						}
					},
					{
						extend: 'pdfHtml5',
						text: 'PDF',
						charset: 'utf-8',
						bom: true,
						exportOptions: {
							columns: ':visible'
							//columns: [ 0, 1, 2, 5 ]
						}
					},
					{
						extend: 'colvis',
						text: 'COLUNAS',
					},
				]
			});
			oTable.buttons().container().appendTo('#list_wrapper .col-sm-6:eq(0)');
			
			$('#search1').keyup(function(){
				oTable
				.columns( 0 )
				.search( this.value )
				.draw();
			});

			$('#search2').keyup(function(){
				oTable
				.columns( 1 )
				.search( this.value )
				.draw();
			});

			$('#search3').keyup(function(){
				oTable
				.columns( 2 )
				.search( this.value )
				.draw();
			});

			$('#search4').keyup(function(){
				oTable
				.columns( 3 )
				.search( this.value )
				.draw();
			});
		});
	</script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>
