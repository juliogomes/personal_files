<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->
<head>
	<!-- INCLUDE DEFAULT HEAD CSS & METAS -->
	<?php include 'template/head-css.inc' ?>
	<!-- /INCLUDE DEFAULT HEAD CSS & METAS -->
	<!-- PAGE STYLES -->
	<script type="text/javascript">
		var sidebarItem = "indices";
	</script>
	<!-- /PAGE STYLES -->
</head>
<body>
	<!-- MENU + WRAPPER -->
	<?php include "template/menu-wrapper.php" ?>
	<!-- /MENU + WRAPPER -->
	<!-- HEADER -->
	<ol class="breadcrumb">
		<li>Tarifas.cmsw.com</li>
		<li>Cadastros</li>
		<li>Índices de Reajuste</li>
	</ol>
	<h4 class="page-title">
		<?php
			if(empty($this->parametros[2])){
				echo '<i class="fa fa-plus"></i> Novo Índice';
			}else{
				echo '<i class="fa fa-edit"></i> Editar Índice';
			}
		?>
	</h4>
	<!-- /HEADER -->
	<!-- CONTENT -->
	<div class="container-fluid">
		<form id="form_save" action="#" name="form_save" method="post">
            <div class="row">
				<div class="col-sm-12 col-md-12">
                    <fieldset>
                        <legend>Dados do Índice</legend>
                    </fieldset>
                </div>
            </div>
            <div class="row">
				<div class="col-sm-12 col-md-12">
                    <div class="form-group">
						<label class="control-label" for="indice">Índice</label>
						<select id="indice" name="indice" class="form-control select" required>
							<option value="">Selecione</option>}
							<option value="igpm" <?php echo (isset($records[0]->indice) && $records[0]->indice == 'igpm')?'selected':'' ?> >IGPM</option>
							<option value="ipca" <?php echo ( isset($records[0]->indice) && $records[0]->indice == 'ipca')?'selected':'' ?> >IPCA</option>
						</select>
					</div>
                </div>
            </div>
            <div class="row">
				<div class="col-sm-12 col-md-12">
                    <div class="form-group">
						<label class="control-label" for="mes">Mês</label>
						<select class="form-control select" name="mes" id="mes" required >
							<option value="" selected >Selecione...</option>
							<?php foreach ($meses as $key => $value) { ?>
								<?php if(isset($records[0]->mes) && $records[0]->mes == $key){ ?>
									<option value="<?= $key; ?>" selected ><?= $value; ?></option>
								<?php }else{ ?>
									<option value="<?= $key; ?>"><?= $value; ?></option>
								<?php } ?>
							<?php } ?>
						</select>
					</div>
                </div>
            </div>
            <div class="row">
				<div class="col-sm-12 col-md-12">
                    <div class="form-group">
						<label class="control-label" for="ano">Ano</label>
						<select class="form-control select" name="ano" id="ano" required >
							<option value="" selected >Selecione...</option>
							<?php foreach ($anos as $key => $value) { ?>
								<?php if($records[0]->ano == $key){ ?>
									<option value="<?= $key; ?>" selected ><?= $value; ?></option>
								<?php }else{ ?>
									<option value="<?= $key; ?>"><?= $value; ?></option>
								<?php } ?>
							<?php } ?>
						</select>
					</div>
                </div>
            </div>
            <div class="row">
				<div class="col-sm-12 col-md-12">
                    <div class="form-group">
						<label class="control-label" for="percentual">PERCENTUAL</label>
						<input type="text" class="form-control" placeholder="0.00%" value="<?= isset($records[0])?number_format($records[0]->percentual, 4, ',','.'):null ?>" name="percentual" id="percentual"/>
					</div>
                </div>
            </div>
            <div class="row">
				<div class="col-sm-12 col-md-12">
                    <div class="form-group">
                        <?php if(isset($records[0]) && $records[0]->lp_processado == 1){ ?>
                            <div class="alert alert-danger" role="alert">
                                Não é possivel editar um indice já cadastrado
                            </div>
                        <?php }else{ ?>
                            <button type="button" id="btn_gravar" class="form-control btn btn-success" value="gravar"><i class="fa fa-save"></i> GRAVAR</button>
                        <?php } ?>
                    </div>
                </div>
            </div>
		</form>
	</div>
	<!-- /.container-fluid -->
	<!-- /CONTENT -->
	<!-- END WRAPPER -->
	<?php include "template/end-menu-wrapper.html" ?>
	<!-- /END WRAPPER -->
	<!-- MODALS -->
	<!-- /MODALS -->
	<!-- INCLUDE DEFAULT SCRIPTS -->
	<?php include 'template/scripts.inc' ?>
	<?php include "template/modal_sistema.php" ?>
	<!-- /INCLUDE DEFAULT SCRIPTS -->
	<!-- PAGE SCRIPTS -->
	<!-- Error Toaatr -->
	<?php if(!empty($this->modelo->error)){ ?> 
		<script type="text/javascript">
			$(function(){
				toastr.error('<?= $this->modelo->error ?>'); 
			});
		</script>
	<?php } ?>
    <script type="text/javascript">
			$(function(){
                $('#btn_gravar').click(function(){
                    var dados_form = $('#form_save').serialize();
                    $.ajax({
                        url: '/indices/save/id/<?= $this->parametros[1]; ?>',
                        data: dados_form,
                        type: 'POST',
                        beforeSend: function() {
                            // setting a timeout
                            waitingDialog.show('PROCESSANDO...');
                        },
                        success: function (data){
                            waitingDialog.hide();
                            var obj_json = JSON.parse(data);
                            if(obj_json.codigo == 0){
                                // console.log(mensagem_alerta);
                                $('#painel_success_msg').text(obj_json.mensagem);
                                $('#modal_sucesso_sistema').modal('show');
                                $('#modal_sucesso_sistema').on('hidden.bs.modal', function () {
								    window.location.href = "/indices/listar/";
							    });
                            }else{
                                // console.log(mensagem_alerta);
                                $('#painel_error_msg').text(obj_json.mensagem);
                                $('#modal_erro_sistema').modal('show');
                            }
                        },
                        error: function (error){	
                            $('#painel_error_msg').text(error);
                            $('#modal_erro_sistema').modal('show');
                        }
                    });
                });
			});
		</script>
	<!-- /Error Toaatr -->
	<script type="text/javascript" src="/assets/js/form-behaviors.js"></script>
	<!-- /PAGE SCRIPTS -->
</body>
</html>